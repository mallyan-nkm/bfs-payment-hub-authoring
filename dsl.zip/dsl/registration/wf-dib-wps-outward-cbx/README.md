# Registering `WF_DIB_WPS_Outward_CBX` 1.0.0 and its routing rule

These are the exact requests that put the CBX salary-file workflow into service. **Nothing here has been sent.** They
write to shared services (`platform.WorkflowDefinitions`, `platform.RoutingRules`), so they are run only by an authorised
person, per environment, after review.

| File | Request | Effect |
|---|---|---|
| `01-create-definition.json` | `POST /api/workflow-engine/definitions` | Files the definition as a **Draft** (not live). The engine re-runs its structure validator and refuses an invalid definition. Name + version can be created once only. |
| `02-submit-review.json` | `POST /api/workflow-engine/definitions/WF_DIB_WPS_Outward_CBX/1.0.0/review` | Draft → Review |
| `03-approve-review.json` | `POST /api/workflow-engine/definitions/WF_DIB_WPS_Outward_CBX/1.0.0/approve-review` | Review → Approved |
| `04-promote.json` | `POST /api/workflow-engine/definitions/WF_DIB_WPS_Outward_CBX/1.0.0/promote` | Approved → **Production**: selected for new runs, immutable from here |
| `05-routing-rule.json` | `POST /api/routing/rules` | Routes `WPS / DIB / CBX / SIF` uploads to the CBX workflow. **Live immediately.** |

## Order and preconditions

1. Deploy the code first (WpsBusiness, `platform-worker-dib`, CB file watcher, `sftp-gateway` mount), and apply the
   pending `wps` migrations (`ReseedWpsParametersWithIdentityIds` seeds `DIBRoutingCode` and the CBX rule parameters;
   `TuneCbxIntakeEventIndexes`). Without them a CBX file is refused (`CBX_CONFIG_MISSING`) or parks
   (`SIF_GENERATION_CONFIG_MISSING`) — safely, but it will not run.
2. Send 01 → 02 → 03 → 04. **Four-eyes is enforced by the API:** the reviewer (03) must differ from the maker
   (01/02), and the promoter (04) must differ from the reviewer. Replace the `<… user id>` placeholders accordingly.
3. Send 05 **last**, once the definition is in Production. Until then a CBX upload still starts
   `WF_DIB_WPS_Outward_CBX` (the upload API's own CBX default), so the rule's job is visibility and explicit routing,
   not a switch-over.

## Authorisation

- Workflow definition endpoints: an authenticated caller (through the Envoy edge, a user token).
- Routing rules: permission `routing:rule:write`.

## Sending (PowerShell, from the repository root)

```powershell
$base    = 'http://localhost:8080'                      # Envoy edge; adjust per environment
$headers = @{ Authorization = "Bearer $token" }         # a token for the person performing each step
$name    = 'WF_DIB_WPS_Outward_CBX'; $version = '1.0.0'
$dir     = 'dsl/registration/wf-dib-wps-outward-cbx'

Invoke-RestMethod -Method Post -Uri "$base/api/workflow-engine/definitions" -Headers $headers `
  -ContentType 'application/json' -InFile "$dir/01-create-definition.json"
Invoke-RestMethod -Method Post -Uri "$base/api/workflow-engine/definitions/$name/$version/review" -Headers $headers `
  -ContentType 'application/json' -InFile "$dir/02-submit-review.json"
# … 03 and 04 the same way, each by its own person …
Invoke-RestMethod -Method Post -Uri "$base/api/routing/rules" -Headers $headers `
  -ContentType 'application/json' -InFile "$dir/05-routing-rule.json"
```

## Verifying

```sql
SELECT WorkflowName, Version, Status FROM platform.WorkflowDefinitions WHERE WorkflowName = 'WF_DIB_WPS_Outward_CBX';  -- Status 3 = Production
SELECT Id, RuleName, ChannelType, TargetWorkflow, IsActive FROM platform.RoutingRules WHERE ProductCode = 'WPS' ORDER BY Priority;
```

The IB rule `WPS-DIB-OUTWARD-CHANNEL-IB-SIF-V1` is unaffected: routing matches `ChannelType` exactly, so a `CBX` rule
never catches an `IB` request and the reverse.

## Rolling back

- Routing rule: `DELETE /api/routing/rules/{id}` (deactivates it). CBX uploads still start the CBX workflow.
- Definition: `POST …/WF_DIB_WPS_Outward_CBX/1.0.0/deprecate`. Runs already started finish on it; a fix is a new
  version (`1.0.1`), never an edit of `1.0.0`.

## Keeping 01 in step with the DSL

`01-create-definition.json` carries the DSL file `dsl/workflows/dib-wps-outward-cbx.v1.workflow.json` as its
`dslJson` string. A unit test (`DibWpsOutwardCbxDslTests`) fails if the two ever differ — after changing the DSL,
regenerate 01 (and register it as a new version).
