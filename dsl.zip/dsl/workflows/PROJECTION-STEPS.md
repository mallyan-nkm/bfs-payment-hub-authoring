# DSL Projection Steps — Integration Guide

## Overview

Two new Temporal activities are available for CQRS projection:

| Activity Name | Purpose | When to Use |
|---|---|---|
| `ProjectTransaction` | Upserts header + appends timeline | After every meaningful state change |
| `ProjectTransactionDetail` | Inserts per-rail fields (once) | After initial validation/parsing |

## Step Templates

### ProjectTransaction (header + timeline)

```json
{
  "id": "project_<stepname>",
  "activity_name": "ProjectTransaction",
  "type": "sequential",
  "platform_activity": "PROJECTION",
  "activity_tier": "Platform",
  "description": "Project transaction state to SQL for queryability",
  "timeout_seconds": 10,
  "retry_policy": { "max_attempts": 3, "initial_interval_seconds": 1, "backoff_coefficient": 2.0 },
  "input_mapping": {
    "status": "${step_<previous_step>_status}",
    "stepName": "<human readable step name>",
    "direction": "${direction}",
    "tenantId": "${tenantId}",
    "amount": "${amount}",
    "currency": "${currency}"
  }
}
```

### ProjectTransactionDetail (per-rail, once)

```json
{
  "id": "project_detail",
  "activity_name": "ProjectTransactionDetail",
  "type": "sequential",
  "platform_activity": "PROJECTION",
  "activity_tier": "Platform",
  "description": "Project rail-specific fields to per-scheme table (insert-once)",
  "timeout_seconds": 10,
  "retry_policy": { "max_attempts": 3, "initial_interval_seconds": 1, "backoff_coefficient": 2.0 }
}
```

> **Note:** `ProjectTransactionDetail` automatically uses ALL `input.Data` fields (excluding keys starting with `_`). No explicit `input_mapping` is needed — the activity forwards the full workflow context.

## Recommended Placement

For a typical outward payment workflow:

1. **After validation** — `ProjectTransaction` with status `"Validated"`
2. **After save/dedup** — `ProjectTransactionDetail` (per-rail fields are now available)
3. **After CB response** — `ProjectTransaction` with status `"Completed"` / `"Rejected"`
4. **On failure** — `ProjectTransaction` with status `"Failed"` (in error branches)

## Example: IPI Outward

```
channel_validation → routing → basic_validation
  → [project_validated]          ← ProjectTransaction (status=Validated)
  → core_data_retrieval → aml_screening → reference_assignment
  → [project_detail]             ← ProjectTransactionDetail (IPI fields)
  → core_posting → send_ffts0001 → await_response
  → [project_completed]          ← ProjectTransaction (status=Completed)
```

## Data Flow

```
Temporal Workflow
  ├── Activity: ProjectTransaction
  │     └── HTTP POST → Operations API /api/projection/upsert
  │           └── ProjectionService.ProjectTransactionAsync()
  │                 ├── UPSERT platform.Transactions
  │                 └── INSERT platform.TransactionTimeline
  │
  └── Activity: ProjectTransactionDetail
        └── HTTP POST → Operations API /api/projection/detail
              └── ProjectionService.ProjectDetailAsync()
                    └── INSERT ipi.Transactions (or fts/wps/edda/npss/xbdr)
```
