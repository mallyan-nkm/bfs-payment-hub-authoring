import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, retry, timer, throwError } from 'rxjs';
import { ToastService } from '../services/toast.service';
import { environment } from '../../../environments/environment';

const RETRYABLE_STATUSES = [408, 429, 502, 503, 504];

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const toastService = inject(ToastService);

  return next(req).pipe(
    retry({
      count: environment.production ? environment.maxRetries : 0,
      delay: (error: HttpErrorResponse, retryCount: number) => {
        if (!RETRYABLE_STATUSES.includes(error.status)) {
          throw error;
        }
        return timer(Math.min(1000 * Math.pow(2, retryCount), 30000));
      },
    }),
    catchError((error: HttpErrorResponse) => {
      // In dev mode, suppress connection errors (no backend running)
      if (error.status === 0 && !environment.production) {
        // Silently fail — no backend available in dev
      } else if (error.status === 0) {
        toastService.show('warning', 'Network Error', 'Unable to reach the server. Please check your connection.');
      } else if (error.status === 403) {
        toastService.show('error', 'Access Denied', 'You do not have permission to perform this action.');
      } else if (error.status === 404) {
        toastService.show('warning', 'Not Found', 'The requested resource was not found.');
      } else if (error.status >= 500) {
        toastService.show('error', 'Server Error', 'An unexpected error occurred. Please try again later.');
      }
      return throwError(() => error);
    })
  );
};
