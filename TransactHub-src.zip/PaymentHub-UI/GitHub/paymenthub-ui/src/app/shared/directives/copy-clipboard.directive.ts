import { Directive, HostListener, Input, inject } from '@angular/core';
import { ToastService } from '../services/toast.service';

@Directive({
  selector: '[appCopy]',
  standalone: true,
  host: { 'title': 'Click to copy', 'style': 'cursor:pointer' },
})
export class CopyClipboardDirective {
  @Input('appCopy') text = '';
  private toast = inject(ToastService);

  @HostListener('click', ['$event'])
  async onClick(e: Event): Promise<void> {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(this.text);
      this.toast.info('Copied', this.text.length > 40 ? this.text.slice(0, 40) + '…' : this.text);
    } catch {
      this.toast.error('Copy failed', 'Clipboard access denied');
    }
  }
}
