import { Directive, Input, OnChanges, ElementRef, SimpleChanges } from '@angular/core';

@Directive({ selector: '[appCountUp]', standalone: true })
export class CountUpDirective implements OnChanges {
  @Input('appCountUp') target = 0;
  @Input() countDuration = 800;
  @Input() countDecimals = 0;

  constructor(private el: ElementRef<HTMLElement>) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['target']) this.animate(changes['target'].previousValue ?? 0, this.target);
  }

  private animate(from: number, to: number): void {
    const start = performance.now();
    const step = (now: number) => {
      const progress = Math.min((now - start) / this.countDuration, 1);
      const ease = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      const current = from + (to - from) * ease;
      this.el.nativeElement.textContent = current.toFixed(this.countDecimals);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
}
