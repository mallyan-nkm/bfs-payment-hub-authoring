import { Directive, Input, TemplateRef, ViewContainerRef, inject, effect } from '@angular/core';
import { PersonaService } from '../services/persona.service';

@Directive({ selector: '[appHasPermission]', standalone: true })
export class HasPermissionDirective {
  private templateRef = inject(TemplateRef<unknown>);
  private viewContainer = inject(ViewContainerRef);
  private personaService = inject(PersonaService);
  private hasView = false;

  @Input() set appHasPermission(permission: string | string[]) {
    const perms = Array.isArray(permission) ? permission : [permission];

    effect(() => {
      const allowed = this.personaService.hasAnyPermission(perms);
      if (allowed && !this.hasView) {
        this.viewContainer.createEmbeddedView(this.templateRef);
        this.hasView = true;
      } else if (!allowed && this.hasView) {
        this.viewContainer.clear();
        this.hasView = false;
      }
    });
  }
}
