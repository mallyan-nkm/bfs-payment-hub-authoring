import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { PersonaService } from './persona.service';

export interface WidgetDefinition {
  id: string;
  name: string;
  description: string;
  category: 'kpi' | 'chart' | 'queue' | 'status' | 'action';
  defaultSize: { cols: number; rows: number };
  minSize: { cols: number; rows: number };
}

export interface WidgetInstance {
  instanceId: string;
  widgetId: string;
  title: string;
  size: { cols: number; rows: number };
  position: number;
}

export interface WorkspaceLayout {
  name: string;
  isDefault: boolean;
  widgets: WidgetInstance[];
  createdAt: string;
}

const WIDGET_CATALOG: WidgetDefinition[] = [
  { id: 'kpi-payments', name: 'Payments KPI', description: 'Key payment metrics', category: 'kpi', defaultSize: { cols: 3, rows: 2 }, minSize: { cols: 2, rows: 1 } },
  { id: 'kpi-compliance', name: 'Compliance KPI', description: 'Compliance case metrics', category: 'kpi', defaultSize: { cols: 3, rows: 2 }, minSize: { cols: 2, rows: 1 } },
  { id: 'kpi-fraud', name: 'Fraud KPI', description: 'Fraud detection metrics', category: 'kpi', defaultSize: { cols: 3, rows: 2 }, minSize: { cols: 2, rows: 1 } },
  { id: 'kpi-treasury', name: 'Treasury KPI', description: 'Treasury position summary', category: 'kpi', defaultSize: { cols: 3, rows: 2 }, minSize: { cols: 2, rows: 1 } },
  { id: 'kpi-recon', name: 'Reconciliation KPI', description: 'Recon status summary', category: 'kpi', defaultSize: { cols: 3, rows: 2 }, minSize: { cols: 2, rows: 1 } },
  { id: 'chart-volume', name: 'Volume Chart', description: 'Transaction volume over time', category: 'chart', defaultSize: { cols: 6, rows: 3 }, minSize: { cols: 4, rows: 2 } },
  { id: 'chart-rail-health', name: 'Rail Health', description: 'Health status of all rails', category: 'chart', defaultSize: { cols: 6, rows: 2 }, minSize: { cols: 4, rows: 2 } },
  { id: 'chart-sla', name: 'SLA Performance', description: 'SLA compliance trends', category: 'chart', defaultSize: { cols: 6, rows: 3 }, minSize: { cols: 4, rows: 2 } },
  { id: 'queue-status', name: 'Queue Status', description: 'Payment queue summary', category: 'queue', defaultSize: { cols: 6, rows: 3 }, minSize: { cols: 4, rows: 2 } },
  { id: 'queue-exceptions', name: 'Exception Queue', description: 'Open exceptions by severity', category: 'queue', defaultSize: { cols: 6, rows: 3 }, minSize: { cols: 4, rows: 2 } },
  { id: 'queue-approvals', name: 'Pending Approvals', description: 'Approval queue summary', category: 'queue', defaultSize: { cols: 4, rows: 2 }, minSize: { cols: 3, rows: 2 } },
  { id: 'status-rails', name: 'Rail Status Panel', description: 'Live rail operational status', category: 'status', defaultSize: { cols: 12, rows: 1 }, minSize: { cols: 6, rows: 1 } },
  { id: 'status-system', name: 'System Health', description: 'Infrastructure health', category: 'status', defaultSize: { cols: 4, rows: 2 }, minSize: { cols: 3, rows: 1 } },
  { id: 'action-quick', name: 'Quick Actions', description: 'Frequently used actions', category: 'action', defaultSize: { cols: 3, rows: 2 }, minSize: { cols: 2, rows: 1 } },
];

const DEFAULT_WIDGETS: WidgetInstance[] = [
  { instanceId: 'default-1', widgetId: 'status-rails', title: 'Rail Status Panel', size: { cols: 12, rows: 1 }, position: 0 },
  { instanceId: 'default-2', widgetId: 'kpi-payments', title: 'Payments KPI', size: { cols: 3, rows: 2 }, position: 1 },
  { instanceId: 'default-3', widgetId: 'queue-approvals', title: 'Pending Approvals', size: { cols: 3, rows: 2 }, position: 2 },
  { instanceId: 'default-4', widgetId: 'queue-exceptions', title: 'Exception Queue', size: { cols: 3, rows: 2 }, position: 3 },
  { instanceId: 'default-5', widgetId: 'action-quick', title: 'Quick Actions', size: { cols: 3, rows: 2 }, position: 4 },
  { instanceId: 'default-6', widgetId: 'chart-volume', title: 'Volume Chart', size: { cols: 6, rows: 3 }, position: 5 },
  { instanceId: 'default-7', widgetId: 'chart-sla', title: 'SLA Performance', size: { cols: 6, rows: 3 }, position: 6 },
];

@Injectable({ providedIn: 'root' })
export class WorkspaceService {
  private http = inject(HttpClient);
  private personaService = inject(PersonaService);

  private _widgets = signal<WidgetInstance[]>(DEFAULT_WIDGETS);
  private _savedLayouts = signal<WorkspaceLayout[]>([]);
  private _currentLayoutName = signal<string>('Default');

  readonly activeWidgets = this._widgets.asReadonly();
  readonly savedLayouts = this._savedLayouts.asReadonly();
  readonly currentLayoutName = this._currentLayoutName.asReadonly();

  readonly availableWidgets = computed<WidgetDefinition[]>(() => {
    return WIDGET_CATALOG.filter(w => this.personaService.isWidgetAllowed(w.id));
  });

  loadUserLayout(): void {
    try {
      const saved = localStorage.getItem('ph-workspace-layout');
      if (saved) {
        const layout: WorkspaceLayout = JSON.parse(saved);
        this._widgets.set(layout.widgets);
        this._currentLayoutName.set(layout.name);
      }
    } catch {}

    try {
      const layouts = localStorage.getItem('ph-workspace-layouts');
      if (layouts) this._savedLayouts.set(JSON.parse(layouts));
    } catch {}
  }

  addWidget(widgetId: string): void {
    const def = WIDGET_CATALOG.find(w => w.id === widgetId);
    if (!def) return;
    const instance: WidgetInstance = {
      instanceId: `widget-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      widgetId: def.id,
      title: def.name,
      size: { ...def.defaultSize },
      position: this._widgets().length,
    };
    this._widgets.update(w => [...w, instance]);
    this.persistCurrent();
  }

  removeWidget(instanceId: string): void {
    this._widgets.update(w => w.filter(i => i.instanceId !== instanceId));
    this.persistCurrent();
  }

  resizeWidget(instanceId: string, size: { cols: number; rows: number }): void {
    this._widgets.update(widgets =>
      widgets.map(w => w.instanceId === instanceId ? { ...w, size } : w)
    );
    this.persistCurrent();
  }

  reorderWidgets(widgets: WidgetInstance[]): void {
    this._widgets.set(widgets.map((w, i) => ({ ...w, position: i })));
    this.persistCurrent();
  }

  saveLayout(name: string): void {
    const layout: WorkspaceLayout = {
      name,
      isDefault: false,
      widgets: this._widgets(),
      createdAt: new Date().toISOString(),
    };
    this._savedLayouts.update(layouts => {
      const filtered = layouts.filter(l => l.name !== name);
      return [...filtered, layout];
    });
    this._currentLayoutName.set(name);
    this.persistCurrent();
    this.persistLayouts();
  }

  loadLayout(name: string): void {
    const layout = this._savedLayouts().find(l => l.name === name);
    if (layout) {
      this._widgets.set([...layout.widgets]);
      this._currentLayoutName.set(name);
      this.persistCurrent();
    }
  }

  resetToDefault(): void {
    this._widgets.set([...DEFAULT_WIDGETS]);
    this._currentLayoutName.set('Default');
    this.persistCurrent();
  }

  private persistCurrent(): void {
    try {
      const layout: WorkspaceLayout = { name: this._currentLayoutName(), isDefault: false, widgets: this._widgets(), createdAt: new Date().toISOString() };
      localStorage.setItem('ph-workspace-layout', JSON.stringify(layout));
    } catch {}
  }

  private persistLayouts(): void {
    try { localStorage.setItem('ph-workspace-layouts', JSON.stringify(this._savedLayouts())); } catch {}
  }
}
