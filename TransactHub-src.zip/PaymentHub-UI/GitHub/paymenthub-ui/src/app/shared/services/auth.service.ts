import { Injectable, signal, computed } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';

export interface AuthenticatedUser {
  userId: string;
  username: string;
  fullName: string;
  email: string;
  primaryPersona: string;
  secondaryPersonas: string[];
  activePersona: string;
  permissions: string[];
  tenantId: string;
  mfaVerified: boolean;
  sessionExpiresAt: Date;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _user = signal<AuthenticatedUser | null>(null);
  private _token = signal<string | null>(null);
  private sessionTimer: ReturnType<typeof setInterval> | null = null;

  readonly user = this._user.asReadonly();
  readonly isAuthenticated = computed(() => this._user() !== null);
  readonly currentPersona = computed(() => this._user()?.activePersona ?? '');

  constructor(private router: Router) {
    this.restoreSession();
  }

  getAccessToken(): string | null {
    return this._token();
  }

  hasPermission(permission: string): boolean {
    return this._user()?.permissions.includes(permission) ?? false;
  }

  hasAnyPermission(permissions: string[]): boolean {
    const userPerms = this._user()?.permissions ?? [];
    return permissions.some(p => userPerms.includes(p));
  }

  switchPersona(persona: string): void {
    const user = this._user();
    if (!user) return;
    const allPersonas = [user.primaryPersona, ...user.secondaryPersonas];
    if (!allPersonas.includes(persona)) return;
    this._user.set({ ...user, activePersona: persona });
    this.persistSession();
  }

  login(token: string, user: AuthenticatedUser): void {
    this._token.set(token);
    this._user.set(user);
    this.persistSession();
    this.startSessionMonitor();
  }

  logout(): void {
    this._token.set(null);
    this._user.set(null);
    this.clearSession();
    if (this.sessionTimer) {
      clearInterval(this.sessionTimer);
      this.sessionTimer = null;
    }
  }

  refreshSession(): void {
    const user = this._user();
    if (user) {
      const newExpiry = new Date(Date.now() + environment.sessionTimeoutMinutes * 60 * 1000);
      this._user.set({ ...user, sessionExpiresAt: newExpiry });
      this.persistSession();
    }
  }

  getSessionRemainingSeconds(): number {
    const user = this._user();
    if (!user) return 0;
    return Math.max(0, Math.floor((user.sessionExpiresAt.getTime() - Date.now()) / 1000));
  }

  isSessionWarning(): boolean {
    return this.getSessionRemainingSeconds() <= environment.sessionWarningMinutes * 60;
  }

  private startSessionMonitor(): void {
    if (this.sessionTimer) clearInterval(this.sessionTimer);
    this.sessionTimer = setInterval(() => {
      if (this.getSessionRemainingSeconds() <= 0) {
        this.logout();
        this.router.navigate(['/auth/login'], { queryParams: { reason: 'timeout' } });
      }
    }, 10000);
  }

  private persistSession(): void {
    try {
      const user = this._user();
      const token = this._token();
      if (user && token) {
        sessionStorage.setItem('ph-session', JSON.stringify({ user, token }));
      }
    } catch {}
  }

  private restoreSession(): void {
    try {
      const raw = sessionStorage.getItem('ph-session');
      if (raw) {
        const { user, token } = JSON.parse(raw);
        user.sessionExpiresAt = new Date(user.sessionExpiresAt);
        if (user.sessionExpiresAt.getTime() > Date.now()) {
          this._user.set(user);
          this._token.set(token);
          this.startSessionMonitor();
        } else {
          this.clearSession();
        }
      }
    } catch {
      this.clearSession();
    }
  }

  private clearSession(): void {
    try { sessionStorage.removeItem('ph-session'); } catch {}
  }
}
