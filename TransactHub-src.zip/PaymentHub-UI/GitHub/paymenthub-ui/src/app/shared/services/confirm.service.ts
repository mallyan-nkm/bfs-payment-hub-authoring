import { Injectable } from '@angular/core';
import { BehaviorSubject, firstValueFrom } from 'rxjs';
import { filter, take } from 'rxjs/operators';

export interface ConfirmOptions {
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  count?: number;
}

interface ConfirmState {
  options: ConfirmOptions;
  resolve: (value: boolean) => void;
}

@Injectable({ providedIn: 'root' })
export class ConfirmService {
  private _state$ = new BehaviorSubject<ConfirmState | null>(null);
  readonly state$ = this._state$.asObservable();

  confirm(options: ConfirmOptions): Promise<boolean> {
    return new Promise(resolve => {
      this._state$.next({ options, resolve });
    });
  }

  respond(result: boolean): void {
    const state = this._state$.value;
    if (state) {
      state.resolve(result);
      this._state$.next(null);
    }
  }
}
