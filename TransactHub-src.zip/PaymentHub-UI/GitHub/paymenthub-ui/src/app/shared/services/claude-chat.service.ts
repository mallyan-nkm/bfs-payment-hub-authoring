import Anthropic from "@anthropic-ai/sdk";

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export class ClaudeChatService {
  private client: Anthropic;
  private conversationHistory: ChatMessage[] = [];
  private model: string = "claude-3-5-sonnet-20241022";

  constructor() {
    this.client = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
  }

  /**
   * Send a message to Claude and get a response
   */
  async sendMessage(userMessage: string): Promise<string> {
    // Add user message to history
    this.conversationHistory.push({
      role: "user",
      content: userMessage,
    });

    try {
      // Create message with full conversation history
      const response = await this.client.messages.create({
        model: this.model,
        max_tokens: 2048,
        system:
          "You are Claude, an AI assistant for PaymentHub Operations Console. Help users with payment operations, transactions, and system management. Be concise and professional.",
        messages: this.conversationHistory,
      });

      // Extract assistant response
      const assistantMessage =
        response.content[0].type === "text" ? response.content[0].text : "";

      // Add assistant response to history
      this.conversationHistory.push({
        role: "assistant",
        content: assistantMessage,
      });

      return assistantMessage;
    } catch (error) {
      console.error("Error communicating with Claude:", error);
      throw error;
    }
  }

  /**
   * Clear conversation history
   */
  clearHistory(): void {
    this.conversationHistory = [];
  }

  /**
   * Get conversation history
   */
  getHistory(): ChatMessage[] {
    return [...this.conversationHistory];
  }

  /**
   * Set system prompt for specific domain
   */
  setSystemContext(context: string): void {
    // Can be used to set domain-specific context for the conversation
  }
}
