import { Injectable, signal } from '@angular/core';

export interface TourStep {
  target: string;
  title: string;
  content: string;
  position: 'top' | 'bottom' | 'left' | 'right';
}

export interface Tour {
  id: string;
  name: string;
  steps: TourStep[];
}

const TOURS: Tour[] = [
  {
    id: 'getting-started',
    name: 'Getting Started',
    steps: [
      { target: '.rail-switcher', title: 'Rail Switcher', content: 'Switch between payment rails (UAEFTS, IPI, WPS, etc.) to focus your dashboard.', position: 'bottom' },
      { target: '.sidebar', title: 'Navigation', content: 'Access all operational modules from the sidebar.', position: 'right' },
      { target: '.global-search', title: 'Global Search', content: 'Search transactions, cases, and entities across all rails.', position: 'bottom' },
      { target: '.notifications-btn', title: 'Notifications', content: 'Real-time alerts for approvals, exceptions, and system events.', position: 'bottom' },
    ]
  },
  {
    id: 'payment-queue',
    name: 'Payment Queue',
    steps: [
      { target: '.queue-filters', title: 'Filters', content: 'Filter payments by status, rail, date, and amount.', position: 'bottom' },
      { target: '.queue-table', title: 'Payment List', content: 'Click any payment to view details. Use bulk actions for batch operations.', position: 'top' },
      { target: '.bulk-actions', title: 'Bulk Actions', content: 'Select multiple payments to approve, reject, or escalate in batch.', position: 'top' },
    ]
  },
  {
    id: 'compliance',
    name: 'Compliance Module',
    steps: [
      { target: '.compliance-cases', title: 'Cases', content: 'View and manage compliance cases. Click to see full details.', position: 'bottom' },
      { target: '.sanctions-hits', title: 'Sanctions', content: 'Adjudicate sanctions screening hits with match scores.', position: 'bottom' },
    ]
  },
];

@Injectable({ providedIn: 'root' })
export class OnboardingService {
  activeTour = signal<Tour | null>(null);
  currentStepIndex = signal(0);
  completedTours = signal<string[]>([]);

  constructor() {
    const saved = localStorage.getItem('completed-tours');
    if (saved) this.completedTours.set(JSON.parse(saved));
  }

  getAvailableTours(): Tour[] { return TOURS; }

  startTour(tourId: string): void {
    const tour = TOURS.find(t => t.id === tourId);
    if (tour) {
      this.activeTour.set(tour);
      this.currentStepIndex.set(0);
    }
  }

  nextStep(): void {
    const tour = this.activeTour();
    if (!tour) return;
    if (this.currentStepIndex() < tour.steps.length - 1) {
      this.currentStepIndex.update(i => i + 1);
    } else {
      this.completeTour();
    }
  }

  previousStep(): void {
    if (this.currentStepIndex() > 0) this.currentStepIndex.update(i => i - 1);
  }

  completeTour(): void {
    const tour = this.activeTour();
    if (tour) {
      const completed = [...this.completedTours(), tour.id];
      this.completedTours.set(completed);
      localStorage.setItem('completed-tours', JSON.stringify(completed));
    }
    this.activeTour.set(null);
    this.currentStepIndex.set(0);
  }

  dismissTour(): void {
    this.activeTour.set(null);
    this.currentStepIndex.set(0);
  }

  isTourCompleted(tourId: string): boolean {
    return this.completedTours().includes(tourId);
  }
}
