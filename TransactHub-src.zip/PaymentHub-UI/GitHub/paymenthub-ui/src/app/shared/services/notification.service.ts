import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { AppNotification, NotificationCategory, Rail } from '../types';

const now = Date.now();
const minsAgo = (m: number) => new Date(now - m * 60_000);
const hoursAgo = (h: number) => new Date(now - h * 3_600_000);
const daysAgo  = (d: number) => new Date(now - d * 86_400_000);

const MOCK: Omit<AppNotification, 'id'>[] = [
  // ── Unread (10) ─────────────────────────────────────────────────────────
  {
    category: 'exception',   priority: 'critical',
    title: 'Critical Exception: Sanctions Advisory',
    body: 'EX-SAN-004 triggered on SWIFT rail — mandatory compliance review required immediately',
    timestamp: minsAgo(5), isRead: false, route: '/exceptions', railRef: Rail.SWIFT
  },
  {
    category: 'compliance',  priority: 'critical',
    title: 'AML Alert: High-Value Threshold',
    body: 'UAEFTS transaction AED 4.2M flagged — Compliance L1 review required within 30 minutes',
    timestamp: minsAgo(8), isRead: false, route: '/exceptions', railRef: Rail.UAEFTS
  },
  {
    category: 'approval',    priority: 'high',
    title: 'Senior Approval Pending',
    body: 'WF-00047: AED 2.4M SWIFT payment awaiting Senior Officer approval — 45 min SLA',
    timestamp: minsAgo(15), isRead: false, route: '/operations/approvals', railRef: Rail.SWIFT
  },
  {
    category: 'exception',   priority: 'high',
    title: 'SLA Breach: 3 Exceptions Overdue',
    body: '3 Payments L1 exceptions have breached SLA — triage required immediately',
    timestamp: minsAgo(22), isRead: false, route: '/exceptions'
  },
  {
    category: 'system',      priority: 'high',
    title: 'IPI Rail: Elevated Latency',
    body: 'IPI P95 latency at 245ms — exceeds 200ms threshold. Operations monitoring.',
    timestamp: minsAgo(45), isRead: false, route: '/dashboard/ipi', railRef: Rail.IPI
  },
  {
    category: 'payment',     priority: 'normal',
    title: 'UAEFTS Settlement Window: 30 Minutes',
    body: 'Settlement window opens in 30 minutes. Ensure pending items are processed.',
    timestamp: minsAgo(35), isRead: false, route: '/dashboard/uaefts', railRef: Rail.UAEFTS
  },
  {
    category: 'approval',    priority: 'normal',
    title: 'Approval Escalated to Your Queue',
    body: 'WF-00023: AED 850,000 UAEFTS payment escalated to L2 approval queue',
    timestamp: hoursAgo(1), isRead: false, route: '/operations/approvals', railRef: Rail.UAEFTS
  },
  {
    category: 'exception',   priority: 'normal',
    title: 'Auto-Resolution Complete',
    body: '5 format error exceptions (EX-FMT-006) auto-resolved by resolution engine',
    timestamp: hoursAgo(1.5), isRead: false, route: '/exceptions'
  },
  {
    category: 'payment',     priority: 'normal',
    title: 'High Volume Alert: UAEFTS',
    body: 'UAEFTS processing 40% above typical hourly volume — rail performing normally',
    timestamp: hoursAgo(2), isRead: false, route: '/dashboard/uaefts', railRef: Rail.UAEFTS
  },
  {
    category: 'system',      priority: 'normal',
    title: 'Daily Reconciliation Report Ready',
    body: "Yesterday's reconciliation report generated. 2 breaks identified for review.",
    timestamp: hoursAgo(3), isRead: false, route: '/reporting'
  },

  // ── Read — Today ──────────────────────────────────────────────────────────
  {
    category: 'approval',    priority: 'normal',
    title: 'Approval Completed',
    body: 'WF-00039: AED 125,000 IPP payment approved by L1 Officer',
    timestamp: hoursAgo(4), isRead: true, route: '/operations/approvals', railRef: Rail.IPP
  },
  {
    category: 'exception',   priority: 'normal',
    title: 'Exception Resolved: EX-VAL-001',
    body: 'Beneficiary IBAN verified and resubmitted — TXN-783421 processing resumed',
    timestamp: hoursAgo(5), isRead: true, route: '/exceptions'
  },
  {
    category: 'system',      priority: 'normal',
    title: 'WPS Cycle Completed',
    body: 'ADNOC-2847 WPS payroll cycle complete — 1,240 employee credits processed',
    timestamp: hoursAgo(6), isRead: true, route: '/dashboard/wps', railRef: Rail.WPS
  },
  {
    category: 'compliance',  priority: 'normal',
    title: 'Compliance Case Closed: CF-8821',
    body: 'AML case closed after review — transaction cleared, no further action required',
    timestamp: hoursAgo(8), isRead: true, route: '/exceptions'
  },
  {
    category: 'payment',     priority: 'normal',
    title: 'SWIFT GPI: 18 Confirmations',
    body: '18 GPI transactions confirmed by correspondent banks in the last hour',
    timestamp: hoursAgo(10), isRead: true, route: '/dashboard/swift', railRef: Rail.SWIFT
  },

  // ── Read — Yesterday ──────────────────────────────────────────────────────
  {
    category: 'system',      priority: 'high',
    title: 'UAEFTS Connectivity Restored',
    body: 'Temporary connectivity degraded for 12 minutes — all transactions recovered',
    timestamp: hoursAgo(26), isRead: true, route: '/dashboard/uaefts', railRef: Rail.UAEFTS
  },
  {
    category: 'approval',    priority: 'normal',
    title: 'Bulk Approval: 12 Payments',
    body: '12 low-value IPI payments approved in bulk by L1 Officer Rashed Al Hamdan',
    timestamp: hoursAgo(28), isRead: true, route: '/operations/approvals', railRef: Rail.IPI
  },
  {
    category: 'exception',   priority: 'normal',
    title: 'Reconciliation Break Resolved',
    body: 'EX-RCO-010 cleared — UAEFTS settlement ledger balanced after break investigation',
    timestamp: hoursAgo(30), isRead: true, route: '/exceptions', railRef: Rail.UAEFTS
  },

  // ── Read — Earlier ────────────────────────────────────────────────────────
  {
    category: 'system',      priority: 'normal',
    title: 'Monthly SLA Report Available',
    body: 'April 2026 SLA compliance report is ready for review in Reporting',
    timestamp: daysAgo(3), isRead: true, route: '/reporting'
  },
  {
    category: 'compliance',  priority: 'high',
    title: 'Sanctions List Updated: 23 New Entries',
    body: 'OFAC SDN list updated — re-screening recommended for transactions in the last 7 days',
    timestamp: daysAgo(4), isRead: true, route: '/exceptions'
  },
];

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private _items: AppNotification[] = MOCK.map((n, i) => ({
    ...n,
    id: `NTF-${String(i + 1).padStart(4, '0')}`
  }));

  private _change$ = new Subject<void>();
  readonly change$ = this._change$.asObservable();

  getAll(category?: NotificationCategory): AppNotification[] {
    let items = [...this._items];
    if (category) items = items.filter(n => n.category === category);
    return items.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  getUnreadCount(): number { return this._items.filter(n => !n.isRead).length; }

  markRead(id: string): void {
    const n = this._items.find(n => n.id === id);
    if (n && !n.isRead) { n.isRead = true; this._change$.next(); }
  }

  markAllRead(): void {
    this._items.forEach(n => n.isRead = true);
    this._change$.next();
  }

  archive(id: string): void {
    const idx = this._items.findIndex(n => n.id === id);
    if (idx >= 0) { this._items.splice(idx, 1); this._change$.next(); }
  }

  timeAgo(date: Date): string {
    const mins = Math.round((Date.now() - date.getTime()) / 60_000);
    if (mins < 1)   return 'just now';
    if (mins < 60)  return `${mins}m ago`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24)   return `${hrs}h ago`;
    const days = Math.round(hrs / 24);
    return `${days}d ago`;
  }

  groupLabel(date: Date): 'today' | 'yesterday' | 'earlier' {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today.getTime() - 86_400_000);
    if (date >= today)     return 'today';
    if (date >= yesterday) return 'yesterday';
    return 'earlier';
  }
}
