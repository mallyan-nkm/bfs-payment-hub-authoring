import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ToastMessage, ToastType } from '../types';

let _id = 1;

@Injectable({ providedIn: 'root' })
export class ToastService {
  private _toasts$ = new BehaviorSubject<ToastMessage[]>([]);
  readonly toasts$ = this._toasts$.asObservable();

  show(type: ToastType, title: string, body?: string, durationMs = 4000): void {
    const id = `toast-${_id++}`;
    this._toasts$.next([...this._toasts$.value, { id, type, title, body, durationMs }]);
    setTimeout(() => this.dismiss(id), durationMs);
  }

  dismiss(id: string): void {
    this._toasts$.next(this._toasts$.value.filter(t => t.id !== id));
  }

  success(title: string, body?: string): void { this.show('success', title, body); }
  error(title: string, body?: string): void   { this.show('error',   title, body); }
  warning(title: string, body?: string): void { this.show('warning', title, body); }
  info(title: string, body?: string): void    { this.show('info',    title, body); }
}
