import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map, catchError, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  Rail, QueueItem, QueueItemStatus, QueuePriority, QueueType,
  QueueFilter, QueueSort, QueuePage, SlaStatus, QueueItemType, PaymentType
} from '../types';

// ─── API Response Models ─────────────────────────────────────────────────────

export interface TransactionReportDto {
  id: number;
  transactionId: string;
  schemaType: string;        // IPI, WPS, FTS, CBFT, NPSS
  tenantId: string;
  direction: string;         // Outward, Inward
  category: string;
  status: string;
  cbStatusCode?: string;
  rail?: string;
  amount: number;
  currency: string;
  debtorAccountNumber?: string;
  debtorName?: string;
  debtorAddress?: string;
  creditorAccountNumber?: string;
  creditorName?: string;
  creditorAgentName?: string;
  endToEndId?: string;
  instructionId?: string;
  postingReferenceNumber?: string;
  batchReferenceNumber?: string;
  transactionDate: string;
  createdAt: string;
  processingTimeMs?: number;
  mode?: string;
  initiationType?: string;
  originatorName?: string;
  beneficiaryName?: string;
  benBankStatus?: string;
  penaltyAmount?: number;
  uetr?: string;
  logTrackingId?: string;
  externalPurposeCode?: string;
  categoryPurpose?: string;
  chargeDetails?: string;
  departmentName?: string;
  batchPacs008FileName?: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface ExceptionDto {
  exceptionId: string;
  transactionId: string;
  exceptionType: string;
  severity: string;
  status: string;
  tenantId: string;
  entityId?: string;
  productCode?: string;
  rail?: string;
  priority?: string;
  slaDeadline?: string;
  assignedTo?: string;
  createdAt: string;
  resolvedAt?: string;
  description?: string;
}

export interface TransactionTimelineStep {
  transactionId: string;
  stepOrder: number;
  stepName: string;
  stepLabel: string;
  status: string;
  startedAt: string;
  completedAt?: string;
  durationMs?: number;
  actor?: string;
  details?: string;
}

export interface Transaction360Dto {
  transactionId: string;
  status: string;
  paymentScheme: string;
  direction: string;
  amount: number;
  currency: string;
  tenantId: string;
  senderIban: string;
  beneficiaryIban: string;
  initiatedAt: string;
  completedAt: string;
  processingDurationMs: number;
  traceId: string;
  traceViewUrl: string;
  workflow: any;
  workflowState: any;
  workflowJourney: any[];
  temporalHistory: any[];
  timeline: any[];
  auditTrail: any[];
  settlementEntries: any[];
  exceptions: any[];
  notifications: any[];
}

export interface KpiDashboardDto {
  timestamp: string;
  uptime: string;
  registeredWorkflows: number;
  activeWorkflows: number;
  draftWorkflows: number;
  workflowsByScheme: Record<string, number>;
  system: {
    workingSetMb: number;
    threadCount: number;
  };
}

// ─── Rail/SchemaType Mapping ─────────────────────────────────────────────────

const RAIL_TO_SCHEMA: Record<string, string> = {
  [Rail.IPI]: 'IPI',
  [Rail.UAEFTS]: 'FTS',
  [Rail.WPS]: 'WPS',
  [Rail.SWIFT]: 'CBFT',
  [Rail.IPP]: 'NPSS',
};

const SCHEMA_TO_RAIL: Record<string, Rail> = {
  'IPI': Rail.IPI,
  'FTS': Rail.UAEFTS,
  'UAEFTS': Rail.UAEFTS,
  'WPS': Rail.WPS,
  'CBFT': Rail.SWIFT,
  'SWIFT': Rail.SWIFT,
  'NPSS': Rail.IPP,
  'IPP': Rail.IPP,
  // SchemaType values
  'IPI_OUTWARD': Rail.IPI,
  'FTS_OUTWARD': Rail.UAEFTS,
  'FTS_INWARD': Rail.UAEFTS,
  'WPS_SALARY_OUTBOUND': Rail.WPS,
  'SWIFT_OUTWARD': Rail.SWIFT,
};

function mapStatusToQueueStatus(apiStatus: string): QueueItemStatus {
  const map: Record<string, QueueItemStatus> = {
    'PENDING': QueueItemStatus.PENDING,
    'PENDING_APPROVAL': QueueItemStatus.PENDING,
    'PROCESSING': QueueItemStatus.IN_REVIEW,
    'HELD': QueueItemStatus.HELD,
    'ESCALATED': QueueItemStatus.ESCALATED,
    'COMPLETED': QueueItemStatus.APPROVED,
    'SETTLED': QueueItemStatus.APPROVED,
    'REJECTED': QueueItemStatus.REJECTED,
    'FAILED': QueueItemStatus.REJECTED,
    'RETURNED': QueueItemStatus.RESOLVED,
    'CANCELLED': QueueItemStatus.REJECTED,
    'AML_HOLD': QueueItemStatus.HELD,
    'COMPLIANCE_HOLD': QueueItemStatus.HELD,
    'AWAITING_APPROVAL': QueueItemStatus.PENDING,
    'APPROVED': QueueItemStatus.APPROVED,
    'IN_REVIEW': QueueItemStatus.IN_REVIEW,
    'RESOLVED': QueueItemStatus.RESOLVED,
    'EXCEPTION': QueueItemStatus.HELD,
    'REFUND_REQUESTED': QueueItemStatus.REFUND_REQUESTED,
  };
  return map[apiStatus?.toUpperCase()] ?? QueueItemStatus.PENDING;
}

function computePriority(amount: number, status: string): QueuePriority {
  if (status === 'ESCALATED' || amount >= 1_000_000) return QueuePriority.CRITICAL;
  if (amount >= 500_000) return QueuePriority.HIGH;
  if (amount < 10_000) return QueuePriority.LOW;
  return QueuePriority.NORMAL;
}

function computeSlaStatus(createdAt: Date, processingTimeMs?: number): { slaStatus: SlaStatus; slaMinutesRemaining: number; slaDeadline: Date } {
  // SLA is 30 minutes from creation for instant, 120 for standard
  const slaMinutes = (processingTimeMs && processingTimeMs > 0) ? 30 : 120;
  const deadline = new Date(createdAt.getTime() + slaMinutes * 60_000);
  const now = Date.now();
  const remaining = Math.floor((deadline.getTime() - now) / 60_000);
  let slaStatus: SlaStatus = 'ok';
  if (remaining < 0) slaStatus = 'breach';
  else if (remaining < 15) slaStatus = 'warning';
  return { slaStatus, slaMinutesRemaining: remaining, slaDeadline: deadline };
}

function mapSchemaToPaymentSubType(schemaType: string, mode?: string): PaymentType | undefined {
  const subTypes: Record<string, PaymentType> = {
    'IPI': 'ipi-instant',
    'FTS': 'cb103',
    'WPS': 'wps-single',
    'CBFT': 'mt103',
    'NPSS': 'ipp-card',
  };
  if (schemaType === 'IPI' && mode === 'ALIAS') return 'ipi-alias';
  if (schemaType === 'FTS' && mode === '202') return 'cb202';
  if (schemaType === 'WPS' && mode === 'BATCH') return 'wps-batch';
  if (schemaType === 'CBFT' && mode === '202') return 'mt202';
  return subTypes[schemaType];
}

// ─── Service ─────────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class TransactionApiService {
  private http = inject(HttpClient);
  private baseUrl = environment.apiBaseUrl;

  // ─── Transaction Reports (from PaymentHub DB via Operations Service) ──────

  /** Fetch all workflow instances from backend (backend maintains in-memory cache) */
  private fetchAllWorkflowInstances(
    filter: QueueFilter, sort: QueueSort
  ): Observable<any[]> {
    let params = new HttpParams()
      .set('take', '1000')
      .set('sortColumn', sort.column || 'startTime')
      .set('sortDirection', sort.direction || 'desc');

    // Push search and status to backend for initial narrowing
    if (filter.search?.trim()) params = params.set('search', filter.search.trim());
    if (filter.statuses?.length === 1) params = params.set('status', filter.statuses[0]);

    return this.http.get<any>(`${this.baseUrl}/workflows/instances`, { params }).pipe(
      map(resp => {
        // Handle both paginated response { items, total } and legacy array
        if (resp && resp.items) return resp.items;
        return Array.isArray(resp) ? resp : [];
      }),
      catchError(() => of([]))
    );
  }

  getTransactions(
    filter: QueueFilter,
    sort: QueueSort,
    page: number,
    pageSize: number
  ): Observable<QueuePage> {
    // Fetch all workflows, apply all filters client-side, then paginate for correct counts
    return this.fetchAllWorkflowInstances(filter, sort).pipe(
      map(workflows => {
        // Convert all workflow instances to QueueItems
        let allItems: QueueItem[] = workflows.map(wf => this.mapWorkflowToQueueItem(wf, new Map()));

        const totalCount = allItems.length;

        // Apply ALL client-side filters (search already applied server-side but re-check for safety)
        allItems = this.applyClientFilters(allItems, filter);

        // Sort client-side
        allItems = this.applyClientSort(allItems, sort);

        const filteredCount = allItems.length;

        // Apply pagination
        const startIdx = (page - 1) * pageSize;
        const pageItems = allItems.slice(startIdx, startIdx + pageSize);

        return {
          items: pageItems,
          totalCount,
          filteredCount,
          page,
          pageSize
        };
      }),
      catchError(() => of({ items: [], totalCount: 0, filteredCount: 0, page, pageSize }))
    );
  }

  private mapWorkflowToQueueItem(wf: any, reportMap: Map<string, TransactionReportDto>): QueueItem {
    const wfId = (wf.id ?? '') as string;

    // Extract transaction ID from workflow ID (e.g., "ADIB_IPI_OUTWARD_INITIATE103-TXN-OUT-1779181390183")
    const txnMatch = wfId.match(/(TXN-[A-Z]+-\d+)/i);
    // If no TXN-XXX-NNN pattern, take last segment after the last hyphen-group or truncate
    const transactionId = txnMatch ? txnMatch[1] : (wfId.length > 20 ? wfId.slice(-20) : wfId);

    // Determine rail from workflow ID
    const rail = this.extractRailFromWorkflowId(wfId);

    // Check if we have enrichment data from report transactions
    const report = reportMap.get(transactionId);

    // Map workflow status to queue status
    const queueStatus = this.mapWorkflowStatusToQueueStatus(wf.status);

    const startTime = wf.startTime ? new Date(wf.startTime) : new Date();
    const closeTime = wf.closeTime ? new Date(wf.closeTime) : undefined;
    const now = Date.now();
    const ageMinutes = Math.floor((now - startTime.getTime()) / 60_000);

    // SLA: 30 min for instant rails, 120 for others
    const slaMinutes = (rail === Rail.IPI || rail === Rail.IPP) ? 30 : 120;
    const slaDeadline = new Date(startTime.getTime() + slaMinutes * 60_000);
    const slaMinutesRemaining = Math.floor((slaDeadline.getTime() - now) / 60_000);
    const slaStatus = slaMinutesRemaining < 0 ? 'breach' as const
      : slaMinutesRemaining < 15 ? 'warning' as const : 'ok' as const;

    const amount = report?.amount ?? 0;
    const priority = wf.status === 'FAILED' ? QueuePriority.HIGH
      : amount >= 1_000_000 ? QueuePriority.CRITICAL
      : amount >= 500_000 ? QueuePriority.HIGH
      : QueuePriority.NORMAL;

    return {
      id: transactionId,
      reference: report?.endToEndId || report?.instructionId || transactionId,
      type: QueueItemType.PAYMENT,
      status: queueStatus,
      priority,
      rail,
      paymentSubType: report ? mapSchemaToPaymentSubType(report.schemaType, report.mode ?? undefined) : undefined,
      amount: report?.amount ?? 0,
      currency: report?.currency || 'AED',
      originatorName: report?.debtorName || report?.originatorName || wf.tenantId || '',
      originatorAccount: report?.debtorAccountNumber || '',
      beneficiaryName: report?.creditorName || report?.beneficiaryName || '',
      beneficiaryAccount: report?.creditorAccountNumber || '',
      submittedAt: startTime,
      updatedAt: closeTime ?? startTime,
      slaDeadline,
      assignedTo: undefined,
      tags: wf.status === 'FAILED' ? ['failed'] : [],
      isUrgent: priority === QueuePriority.CRITICAL || slaStatus === 'breach',
      ageMinutes,
      slaStatus,
      slaMinutesRemaining,
      queueType: QueueType.ALL,
    };
  }

  private extractRailFromWorkflowId(wfId: string): Rail {
    const id = wfId.toUpperCase();
    if (id.includes('IPI_OUTWARD') || id.includes('IPI_INWARD') || id.includes('_IPI_') || id.includes('IPI-')) return Rail.IPI;
    if (id.includes('FTS_OUTWARD') || id.includes('FTS_INWARD') || id.includes('_FTS_') || id.includes('FTS-')) return Rail.UAEFTS;
    if (id.includes('WPS_SALARY') || id.includes('_WPS_') || id.includes('WPS-') || id.includes('WPS_')) return Rail.WPS;
    if (id.includes('SWIFT_OUTWARD') || id.includes('SWIFT_INWARD') || id.includes('_SWIFT_') || id.includes('SWIFT-')) return Rail.SWIFT;
    if (id.includes('IPP_') || id.includes('_IPP_') || id.includes('NPSS') || id.includes('IPP-')) return Rail.IPP;
    // Fallback: retry workflows usually have the original transaction embedded
    if (id.includes('RETRY')) {
      if (id.includes('IPI')) return Rail.IPI;
      if (id.includes('FTS')) return Rail.UAEFTS;
      if (id.includes('WPS')) return Rail.WPS;
      if (id.includes('SWIFT')) return Rail.SWIFT;
    }
    return Rail.UAEFTS; // default
  }

  private mapWorkflowStatusToQueueStatus(status: string): QueueItemStatus {
    const map: Record<string, QueueItemStatus> = {
      'RUNNING': QueueItemStatus.IN_REVIEW,
      'COMPLETED': QueueItemStatus.APPROVED,
      'FAILED': QueueItemStatus.HELD,
      'CANCELLED': QueueItemStatus.REJECTED,
      'TERMINATED': QueueItemStatus.REJECTED,
      'TIMED_OUT': QueueItemStatus.ESCALATED,
      'REJECTED': QueueItemStatus.REJECTED,
    };
    return map[status?.toUpperCase()] ?? QueueItemStatus.PENDING;
  }

  private applyClientFilters(items: QueueItem[], filter: QueueFilter): QueueItem[] {
    return items.filter(item => {
      if (filter.search?.trim()) {
        const s = filter.search.toLowerCase();
        const searchable = `${item.id} ${item.reference} ${item.originatorName} ${item.beneficiaryName}`.toLowerCase();
        if (!searchable.includes(s)) return false;
      }
      if (filter.rails?.length && !filter.rails.includes(item.rail)) return false;
      if (filter.statuses?.length && !filter.statuses.includes(item.status)) return false;
      if (filter.priorities?.length && !filter.priorities.includes(item.priority)) return false;
      if (filter.urgentOnly && !item.isUrgent) return false;
      if (filter.slaStatuses?.length && !filter.slaStatuses.includes(item.slaStatus!)) return false;
      if (filter.amountMin != null && item.amount < filter.amountMin) return false;
      if (filter.amountMax != null && item.amount > filter.amountMax) return false;
      return true;
    });
  }

  private applyClientSort(items: QueueItem[], sort: QueueSort): QueueItem[] {
    return [...items].sort((a, b) => {
      const col = sort.column as keyof QueueItem;
      const aVal = a[col];
      const bVal = b[col];
      let cmp = 0;
      if (aVal instanceof Date && bVal instanceof Date) cmp = aVal.getTime() - bVal.getTime();
      else if (typeof aVal === 'number' && typeof bVal === 'number') cmp = aVal - bVal;
      else cmp = String(aVal ?? '').localeCompare(String(bVal ?? ''));
      return sort.direction === 'desc' ? -cmp : cmp;
    });
  }

  getTransactionDetail(id: number): Observable<TransactionReportDto | null> {
    return this.http.get<TransactionReportDto>(`${this.baseUrl}/reports/transactions/${id}`).pipe(
      catchError(() => of(null))
    );
  }

  getTransaction360(transactionId: string, scheme?: string): Observable<Transaction360Dto | null> {
    let params = new HttpParams();
    if (scheme) params = params.set('scheme', scheme);
    return this.http.get<Transaction360Dto>(
      `${this.baseUrl}/transactions/${encodeURIComponent(transactionId)}/360`, { params }
    ).pipe(catchError(() => of(null)));
  }

  getTransactionTimeline(transactionId: string): Observable<TransactionTimelineStep[]> {
    return this.http.get<TransactionTimelineStep[]>(
      `${this.baseUrl}/reports/transactions/${encodeURIComponent(transactionId)}/timeline`
    ).pipe(catchError(() => of([])));
  }

  getTransactionStatus(transactionId: string, scheme?: string): Observable<any> {
    let params = new HttpParams();
    if (scheme) params = params.set('scheme', scheme);
    return this.http.get<any>(
      `${this.baseUrl}/payment/${encodeURIComponent(transactionId)}/status`, { params }
    ).pipe(catchError(() => of(null)));
  }

  // ─── Exceptions ───────────────────────────────────────────────────────────

  getExceptions(tenantId?: string, exceptionType?: string, take = 100): Observable<ExceptionDto[]> {
    let params = new HttpParams();
    if (tenantId) params = params.set('tenantId', tenantId);
    if (exceptionType) params = params.set('exceptionType', exceptionType);
    params = params.set('take', take);
    return this.http.get<any>(`${this.baseUrl}/exceptions`, { params }).pipe(
      map(resp => {
        // API returns { value: [...], Count: N } or plain array
        const items = Array.isArray(resp) ? resp : (resp?.value ?? resp?.items ?? []);
        return items as ExceptionDto[];
      }),
      catchError(() => of([]))
    );
  }

  assignException(exceptionId: string, assignedTo: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/assign`, { assignedTo });
  }

  resolveException(exceptionId: string, resolvedBy: string, notes: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/resolve`, { resolvedBy, notes });
  }

  escalateException(exceptionId: string, notes?: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/escalate`, notes ? { notes } : null);
  }

  retryException(exceptionId: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/retry`, {});
  }

  // ─── Workflow Actions ─────────────────────────────────────────────────────

  pauseWorkflow(workflowId: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/workflow/${workflowId}/pause`, {});
  }

  resumeWorkflow(workflowId: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/workflow/${workflowId}/resume`, {});
  }

  cancelWorkflow(workflowId: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/workflow/${workflowId}/cancel`, {});
  }

  submitMakerCheckerDecision(workflowId: string, decision: string, reviewer: string, comments?: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/workflow/${workflowId}/maker-checker-decision`, {
      decision, reviewer, comments
    });
  }

  submitAmlDecision(workflowId: string, body: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/workflow/${workflowId}/aml-decision`, body);
  }

  // ─── KPI Dashboard ────────────────────────────────────────────────────────

  getKpiDashboard(): Observable<KpiDashboardDto | null> {
    return this.http.get<KpiDashboardDto>(`${this.baseUrl}/kpi/dashboard`).pipe(
      catchError(() => of(null))
    );
  }

  // ─── Settlement ───────────────────────────────────────────────────────────

  getSettlementPositions(tenantId?: string): Observable<any[]> {
    let params = new HttpParams();
    if (tenantId) params = params.set('tenantId', tenantId);
    return this.http.get<any[]>(`${this.baseUrl}/settlement/positions`, { params }).pipe(
      catchError(() => of([]))
    );
  }

  // ─── Audit Trail ──────────────────────────────────────────────────────────

  getAuditEntries(filter: {
    eventType?: string; eventSource?: string; tenantId?: string;
    userId?: string; resourceType?: string; resourceId?: string;
    correlationId?: string; fromDate?: string; toDate?: string;
    page?: number; pageSize?: number;
  }): Observable<PaginatedResponse<any>> {
    let params = new HttpParams();
    Object.entries(filter).forEach(([key, value]) => {
      if (value != null && value !== '') params = params.set(key, String(value));
    });
    return this.http.get<PaginatedResponse<any>>(`${this.baseUrl}/audit`, { params }).pipe(
      catchError(() => of({ items: [], total: 0, page: 1, pageSize: 25 }))
    );
  }

  // ─── Reports (from PaymentHub_Ops via Operations Service) ─────────────────

  executeReport(request: any, page = 1, pageSize = 50): Observable<any> {
    let params = new HttpParams().set('page', page).set('pageSize', pageSize);
    return this.http.post<any>(`${this.baseUrl}/reports/execute`, request, { params }).pipe(
      catchError(() => of({ items: [], total: 0, page, pageSize }))
    );
  }

  exportReportCsv(request: any): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/reports/export/csv`, request, {
      responseType: 'blob'
    });
  }

  exportReportExcel(request: any): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/reports/export/excel`, request, {
      responseType: 'blob'
    });
  }

  exportReportPdf(request: any): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/reports/export/pdf`, request, {
      responseType: 'blob'
    });
  }

  getTatViolations(filter: any, page = 1, pageSize = 50): Observable<PaginatedResponse<any>> {
    let params = new HttpParams().set('page', page).set('pageSize', pageSize);
    Object.entries(filter).forEach(([key, value]) => {
      if (value != null && value !== '') params = params.set(key, String(value));
    });
    return this.http.get<PaginatedResponse<any>>(`${this.baseUrl}/reports/tat-violations`, { params }).pipe(
      catchError(() => of({ items: [], total: 0, page, pageSize }))
    );
  }

  getMisOverview(tenantId?: string, dateFrom?: string, dateTo?: string): Observable<any> {
    let params = new HttpParams();
    if (tenantId) params = params.set('tenantId', tenantId);
    if (dateFrom) params = params.set('dateFrom', dateFrom);
    if (dateTo) params = params.set('dateTo', dateTo);
    return this.http.get<any>(`${this.baseUrl}/reports/mis/overview`, { params }).pipe(
      catchError(() => of(null))
    );
  }

  // ─── Mapping Helpers ──────────────────────────────────────────────────────

  private mapToQueuePage(resp: PaginatedResponse<TransactionReportDto>, page: number, pageSize: number): QueuePage {
    const items: QueueItem[] = resp.items.map(dto => this.mapDtoToQueueItem(dto));
    return {
      items,
      totalCount: resp.total,
      filteredCount: resp.total,
      page,
      pageSize
    };
  }

  mapDtoToQueueItem(dto: TransactionReportDto): QueueItem {
    const rail = (dto.rail ? SCHEMA_TO_RAIL[dto.rail] : null) ?? SCHEMA_TO_RAIL[dto.schemaType] ?? Rail.UAEFTS;
    const queueStatus = mapStatusToQueueStatus(dto.status);
    const createdAt = new Date(dto.createdAt || dto.transactionDate);
    const priority = computePriority(dto.amount, dto.status);
    const { slaStatus, slaMinutesRemaining, slaDeadline } = computeSlaStatus(createdAt, dto.processingTimeMs ?? undefined);
    const now = Date.now();
    const ageMinutes = Math.floor((now - createdAt.getTime()) / 60_000);

    return {
      id: dto.transactionId,
      reference: dto.endToEndId || dto.instructionId || dto.transactionId,
      type: QueueItemType.PAYMENT,
      status: queueStatus,
      priority,
      rail,
      paymentSubType: mapSchemaToPaymentSubType(dto.schemaType, dto.mode ?? undefined),
      amount: dto.amount,
      currency: dto.currency || 'AED',
      originatorName: dto.debtorName || dto.originatorName || '',
      originatorAccount: dto.debtorAccountNumber || '',
      beneficiaryName: dto.creditorName || dto.beneficiaryName || '',
      beneficiaryAccount: dto.creditorAccountNumber || '',
      counterpartyBic: dto.creditorAgentName || undefined,
      submittedAt: createdAt,
      updatedAt: createdAt,
      slaDeadline,
      assignedTo: undefined,
      tags: [],
      isUrgent: priority === QueuePriority.CRITICAL || slaStatus === 'breach',
      ageMinutes,
      slaStatus,
      slaMinutesRemaining,
      exceptionCode: undefined,
      queueType: QueueType.ALL,
      correlationId: dto.logTrackingId || undefined,
    };
  }
}
