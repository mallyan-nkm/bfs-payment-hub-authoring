import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type Theme = 'dark' | 'dark-navy' | 'dark-midnight' | 'light' | 'high-contrast';

const ALL_THEMES: Theme[] = ['dark', 'dark-navy', 'dark-midnight', 'light', 'high-contrast'];
const THEME_CLASSES = ALL_THEMES.filter(t => t !== 'dark').map(t => `theme-${t}`);
const STORAGE_KEY_BASE = 'ph_theme';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private _theme$ = new BehaviorSubject<Theme>(this.loadTheme());
  readonly theme$ = this._theme$.asObservable();

  get current(): Theme { return this._theme$.value; }

  set(theme: Theme): void {
    this._theme$.next(theme);
    document.body.classList.remove(...THEME_CLASSES);
    if (theme !== 'dark') document.body.classList.add(`theme-${theme}`);
    // Also set data-theme attribute for cross-app CSS compatibility
    const resolved = theme.startsWith('dark') ? 'dark' : theme;
    document.documentElement.setAttribute('data-theme', resolved);
    try { localStorage.setItem(this.storageKey, theme); } catch {}
  }

  private get storageKey(): string {
    const username = this.getCurrentUsername();
    return username ? `${STORAGE_KEY_BASE}_${username}` : STORAGE_KEY_BASE;
  }

  private getCurrentUsername(): string | null {
    try {
      const raw = localStorage.getItem('ph_user');
      if (raw) {
        const user = JSON.parse(raw);
        return user.username || null;
      }
    } catch {}
    return null;
  }

  private loadTheme(): Theme {
    try {
      const saved = localStorage.getItem(this.storageKey) as Theme | null;
      if (saved && ALL_THEMES.includes(saved)) return saved;
    } catch {}
    return 'dark';
  }

  init(): void { this.set(this._theme$.value); }
}
