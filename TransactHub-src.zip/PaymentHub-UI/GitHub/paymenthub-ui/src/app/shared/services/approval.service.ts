﻿import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, forkJoin, map, catchError, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ApprovalWorkflow,
  ApprovalStep,
  ApprovalStatus,
  ApprovalLevelFilter,
  ApprovalSummary,
  ApprovalDecisionRequest,
  ApprovalPage,
  ApprovalFilter,
  ApprovalSort,
  QueueItemType,
  QueuePriority,
  Rail,
  SlaStatus,
  ComplianceFlag
} from '../types';

const SCHEMA_TO_RAIL: Record<string, Rail> = {
  'IPI_OUTWARD': Rail.IPI,
  'FTS_OUTWARD': Rail.UAEFTS,
  'FTS_INWARD': Rail.UAEFTS,
  'WPS_SALARY_OUTBOUND': Rail.WPS,
  'SWIFT_OUTWARD': Rail.SWIFT,
  'IPI': Rail.IPI,
  'FTS': Rail.UAEFTS,
  'WPS': Rail.WPS,
  'CBFT': Rail.SWIFT,
  'NPSS': Rail.IPP,
};

@Injectable({ providedIn: 'root' })
export class ApprovalService {
  private http = inject(HttpClient);
  private baseUrl = environment.apiBaseUrl;

  getApprovers(): string[] {
    return [
      'Rashed Al Hamdan', 'Layla Al Nuaimi', 'Saeed Al Marzooqi', 'Hessa Al Falasi',
      'Dr. Khalid Al Zahra', 'Mariam Al Suwaidi', 'H.E. Mohammed Al Ketbi'
    ];
  }

  /** Fetch real pending-approval transactions from workflow instances */
  getPage(filter: ApprovalFilter, sort: ApprovalSort, page: number, pageSize: number): Observable<ApprovalPage> {
    // Server-side paginated fetch — request only REJECTED workflows with search/sort
    let params = new HttpParams()
      .set('page', page)
      .set('pageSize', pageSize)
      .set('status', 'REJECTED')
      .set('sortColumn', sort.column || 'submittedAt')
      .set('sortDirection', sort.direction || 'desc');

    if (filter.search?.trim()) params = params.set('search', filter.search.trim());

    return this.http.get<any>(`${this.baseUrl}/workflows/instances`, { params }).pipe(
      map(resp => {
        // Handle paginated response { items, total } or legacy array
        const workflows = resp?.items ?? (Array.isArray(resp) ? resp : []);
        const total = resp?.total ?? workflows.length;

        let items: ApprovalWorkflow[] = workflows.map((wf: any) => this.mapWorkflowToApproval(wf));

        // Apply client-side rail filter (not supported in backend yet)
        if (filter.rails?.length) {
          items = items.filter(i => filter.rails!.includes(i.rail));
        }

        return { items, totalCount: total, filteredCount: total, page, pageSize };
      }),
      catchError(() => of({ items: [], totalCount: 0, filteredCount: 0, page, pageSize }))
    );
  }

  /** Get summary — lightweight query without full data (uses take=1 and counts from cache) */
  getSummary(): Observable<ApprovalSummary> {
    // Fetch counts by status from backend
    return forkJoin({
      rejected: this.http.get<any>(`${this.baseUrl}/workflows/instances`, {
        params: new HttpParams().set('status', 'REJECTED').set('page', 1).set('pageSize', 1)
      }).pipe(map(r => r?.total ?? (Array.isArray(r) ? r.length : 0)), catchError(() => of(0))),
      completed: this.http.get<any>(`${this.baseUrl}/workflows/instances`, {
        params: new HttpParams().set('status', 'COMPLETED').set('page', 1).set('pageSize', 1)
      }).pipe(map(r => r?.total ?? (Array.isArray(r) ? r.length : 0)), catchError(() => of(0))),
    }).pipe(
      map(({ rejected, completed }) => ({
        pendingL1: rejected,
        pendingL2: 0,
        pendingSenior: 0,
        slaBreachCount: 0,
        approvedToday: completed,
        rejectedToday: rejected,
        expiredToday: 0,
        avgDecisionMinutes: 0,
      })),
      catchError(() => of({
        pendingL1: 0, pendingL2: 0, pendingSenior: 0,
        slaBreachCount: 0, approvedToday: 0, rejectedToday: 0,
        expiredToday: 0, avgDecisionMinutes: 0
      }))
    );
  }

  /** Submit approval decision via workflow signal */
  submitDecision(req: ApprovalDecisionRequest): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/workflow/${req.workflowId}/maker-checker-decision`,
      { decision: req.decision, reviewer: 'current-user', comments: req.reason }
    ).pipe(catchError(() => of({ success: false })));
  }

  private mapWorkflowToApproval(wf: any): ApprovalWorkflow {
    const wfId = (wf.id ?? '') as string;
    const txnMatch = wfId.match(/(TXN-[A-Z]+-\d+)/i);
    const transactionId = txnMatch ? txnMatch[1] : wfId;
    const rail = this.extractRailFromWorkflowId(wfId);
    const createdAt = wf.startTime ? new Date(wf.startTime) : new Date();
    const closeTime = wf.closeTime ? new Date(wf.closeTime) : createdAt;
    const now = Date.now();

    const totalLevels: 1 | 2 | 3 = 1;
    const slaMinutes = 240;
    const slaDeadline = new Date(createdAt.getTime() + slaMinutes * 60_000);
    const slaMinutesRemaining = Math.floor((slaDeadline.getTime() - now) / 60_000);
    const slaStatus: SlaStatus = slaMinutesRemaining < 0 ? 'breach'
      : slaMinutesRemaining < 30 ? 'warning' : 'ok';

    return {
      id: transactionId,
      reference: transactionId,
      type: QueueItemType.APPROVAL,
      rail,
      amount: 0,
      currency: 'AED',
      originatorName: wf.tenantId || '',
      originatorAccount: '',
      beneficiaryName: '',
      beneficiaryAccount: '',
      submittedBy: 'System',
      submittedAt: createdAt,
      updatedAt: closeTime,
      currentLevel: 1,
      totalLevels,
      steps: this.buildSteps(totalLevels, createdAt),
      approvalStatus: ApprovalStatus.REJECTED,
      priority: QueuePriority.HIGH,
      slaDeadline,
      slaStatus,
      slaMinutesRemaining,
      tags: ['rejected'],
      isUrgent: slaStatus === 'breach',
      ruleId: 'RULE-L1-001',
      ruleDescription: 'Workflow rejected during processing',
      complianceFlags: [],
    };
  }

  private extractRailFromWorkflowId(wfId: string): Rail {
    const id = wfId.toUpperCase();
    if (id.includes('IPI')) return Rail.IPI;
    if (id.includes('FTS')) return Rail.UAEFTS;
    if (id.includes('WPS')) return Rail.WPS;
    if (id.includes('SWIFT')) return Rail.SWIFT;
    if (id.includes('IPP') || id.includes('NPSS')) return Rail.IPP;
    return Rail.UAEFTS;
  }

  private mapToApproval(dto: any): ApprovalWorkflow {
    const rail = SCHEMA_TO_RAIL[dto.schemaType] ?? Rail.UAEFTS;
    const createdAt = new Date(dto.createdAt || dto.transactionDate);
    const amount = dto.amount ?? 0;
    const priority = amount >= 1_000_000 ? QueuePriority.CRITICAL
      : amount >= 500_000 ? QueuePriority.HIGH
      : amount >= 100_000 ? QueuePriority.NORMAL
      : QueuePriority.LOW;

    const totalLevels: 1 | 2 | 3 = amount >= 1_000_000 ? 3 : amount >= 100_000 ? 2 : 1;
    const slaMinutes = totalLevels * 240;
    const slaDeadline = new Date(createdAt.getTime() + slaMinutes * 60_000);
    const now = Date.now();
    const slaMinutesRemaining = Math.floor((slaDeadline.getTime() - now) / 60_000);
    const slaStatus: SlaStatus = slaMinutesRemaining < 0 ? 'breach'
      : slaMinutesRemaining < 30 ? 'warning' : 'ok';

    return {
      id: dto.transactionId ?? dto.id?.toString() ?? '',
      reference: dto.endToEndId || dto.instructionId || dto.transactionId || '',
      type: QueueItemType.APPROVAL,
      rail,
      amount,
      currency: dto.currency || 'AED',
      originatorName: dto.debtorName || dto.originatorName || '',
      originatorAccount: dto.debtorAccountNumber || '',
      beneficiaryName: dto.creditorName || dto.beneficiaryName || '',
      beneficiaryAccount: dto.creditorAccountNumber || '',
      submittedBy: dto.departmentName || 'Maker',
      submittedAt: createdAt,
      updatedAt: createdAt,
      currentLevel: 1,
      totalLevels,
      steps: this.buildSteps(totalLevels, createdAt),
      approvalStatus: ApprovalStatus.PENDING_L1,
      priority,
      slaDeadline,
      slaStatus,
      slaMinutesRemaining,
      tags: [],
      isUrgent: priority === QueuePriority.CRITICAL || slaStatus === 'breach',
      ruleId: totalLevels === 3 ? 'RULE-SEN-003' : totalLevels === 2 ? 'RULE-L2-002' : 'RULE-L1-001',
      ruleDescription: totalLevels === 3 ? 'Senior approval: amount > AED 1M'
        : totalLevels === 2 ? 'Dual-control: amount AED 100K-1M'
        : 'Single approval: amount < AED 100K',
      purpose: dto.categoryPurpose || dto.externalPurposeCode || undefined,
      complianceFlags: [],
    };
  }

  private buildSteps(totalLevels: 1 | 2 | 3, submittedAt: Date): ApprovalStep[] {
    const dueBy = new Date(submittedAt.getTime() + 4 * 60 * 60_000);
    const steps: ApprovalStep[] = [
      { level: 1, levelLabel: 'L1 - Checker', requiredRole: 'checker', status: 'pending', dueBy }
    ];
    if (totalLevels >= 2) {
      steps.push({ level: 2, levelLabel: 'L2 - Senior Checker', requiredRole: 'senior_checker', status: 'pending', dueBy });
    }
    if (totalLevels >= 3) {
      steps.push({ level: 3, levelLabel: 'Senior Management', requiredRole: 'senior_management', status: 'pending', dueBy });
    }
    return steps;
  }
}
