import { Injectable, signal, computed, OnDestroy } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface ServerEvent {
  type: string;
  channel: string;
  payload: unknown;
  timestamp: string;
}

export type ConnectionStatus = 'connected' | 'connecting' | 'disconnected';

@Injectable({ providedIn: 'root' })
export class RealTimeService implements OnDestroy {
  private eventSources = new Map<string, EventSource>();
  private subjects = new Map<string, Subject<ServerEvent>>();
  private reconnectTimers = new Map<string, ReturnType<typeof setTimeout>>();
  private reconnectAttempts = new Map<string, number>();

  private _status = signal<ConnectionStatus>('disconnected');
  readonly status = this._status.asReadonly();
  readonly isConnected = computed(() => this._status() === 'connected');

  ngOnDestroy(): void {
    this.disconnectAll();
  }

  connect(channel: string): Observable<ServerEvent> {
    if (this.subjects.has(channel)) {
      return this.subjects.get(channel)!.asObservable();
    }

    const subject = new Subject<ServerEvent>();
    this.subjects.set(channel, subject);
    this.openConnection(channel);

    return subject.asObservable();
  }

  disconnect(channel: string): void {
    const es = this.eventSources.get(channel);
    if (es) {
      es.close();
      this.eventSources.delete(channel);
    }
    const timer = this.reconnectTimers.get(channel);
    if (timer) {
      clearTimeout(timer);
      this.reconnectTimers.delete(channel);
    }
    const subject = this.subjects.get(channel);
    if (subject) {
      subject.complete();
      this.subjects.delete(channel);
    }
    this.reconnectAttempts.delete(channel);
    this.updateGlobalStatus();
  }

  disconnectAll(): void {
    const channels = [...this.subjects.keys()];
    channels.forEach(ch => this.disconnect(ch));
  }

  private openConnection(channel: string): void {
    this._status.set('connecting');
    const url = `${environment.sseBaseUrl}/${channel}`;

    try {
      const es = new EventSource(url);
      this.eventSources.set(channel, es);

      es.onopen = () => {
        this.reconnectAttempts.set(channel, 0);
        this.updateGlobalStatus();
      };

      es.onmessage = (event) => {
        const subject = this.subjects.get(channel);
        if (subject) {
          try {
            const parsed: ServerEvent = JSON.parse(event.data);
            parsed.channel = channel;
            subject.next(parsed);
          } catch {
            subject.next({ type: 'raw', channel, payload: event.data, timestamp: new Date().toISOString() });
          }
        }
      };

      es.onerror = () => {
        es.close();
        this.eventSources.delete(channel);
        this.updateGlobalStatus();
        this.scheduleReconnect(channel);
      };
    } catch {
      this.scheduleReconnect(channel);
    }
  }

  private scheduleReconnect(channel: string): void {
    const attempts = this.reconnectAttempts.get(channel) ?? 0;
    const delay = Math.min(
      environment.sseReconnectDelayMs * Math.pow(2, attempts),
      60000
    );
    this.reconnectAttempts.set(channel, attempts + 1);

    const timer = setTimeout(() => {
      this.reconnectTimers.delete(channel);
      if (this.subjects.has(channel)) {
        this.openConnection(channel);
      }
    }, delay);

    this.reconnectTimers.set(channel, timer);
  }

  private updateGlobalStatus(): void {
    if (this.eventSources.size === 0 && this.subjects.size === 0) {
      this._status.set('disconnected');
    } else if (this.eventSources.size > 0) {
      this._status.set('connected');
    } else {
      this._status.set('connecting');
    }
  }
}
