import { Injectable } from '@angular/core';
import { SearchResult, SearchResultGroup, RecentSearch, SearchCategory, Rail } from '../types';

const CATEGORY_META: Record<SearchCategory, { label: string; icon: string }> = {
  transaction:   { label: 'Transactions',   icon: 'M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z M13 2v7h7' },
  exception:     { label: 'Exceptions',     icon: 'M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z M12 9v4 M12 17h.01' },
  approval:      { label: 'Approvals',      icon: 'M9 11l3 3L22 4 M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11' },
  customer:      { label: 'Customers',      icon: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z' },
  counterparty:  { label: 'Counterparties', icon: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M23 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75' },
  report:        { label: 'Reports',        icon: 'M18 20V10 M12 20V4 M6 20v-6' },
};

const MOCK_INDEX: SearchResult[] = [
  // Transactions
  { id: 'txn-001', category: 'transaction', title: 'TXN-UAEFTS-2024-089234', subtitle: 'Al Zaabi Trading → ADCB · AED 1,250,000', meta: 'PENDING_SETTLEMENT', route: '/operations/queues', rail: Rail.UAEFTS, status: 'Pending', amount: 'AED 1,250,000' },
  { id: 'txn-002', category: 'transaction', title: 'TXN-UAEFTS-2024-089190', subtitle: 'Emirates NBD → ADIB · AED 450,000', meta: 'SETTLED', route: '/operations/queues', rail: Rail.UAEFTS, status: 'Settled', amount: 'AED 450,000' },
  { id: 'txn-003', category: 'transaction', title: 'TXN-IPI-2024-044512', subtitle: 'Hamad Al Rashidi → Careem Pay · AED 2,800', meta: 'PROCESSING', route: '/operations/queues', rail: Rail.IPI, status: 'Processing', amount: 'AED 2,800' },
  { id: 'txn-004', category: 'transaction', title: 'TXN-IPI-2024-044498', subtitle: 'Fatima Investments → Wio Bank · AED 18,500', meta: 'HELD', route: '/operations/queues', rail: Rail.IPI, status: 'Held', amount: 'AED 18,500' },
  { id: 'txn-005', category: 'transaction', title: 'TXN-WPS-2024-031102', subtitle: 'Gulf Contractors LLC · WPS Payroll Batch · AED 8,450,000', meta: 'PROCESSING', route: '/operations/queues', rail: Rail.WPS, status: 'Processing', amount: 'AED 8,450,000' },
  { id: 'txn-006', category: 'transaction', title: 'TXN-WPS-2024-031099', subtitle: 'Nakheel Properties · WPS Payroll Batch · AED 3,200,000', meta: 'SETTLED', route: '/operations/queues', rail: Rail.WPS, status: 'Settled', amount: 'AED 3,200,000' },
  { id: 'txn-007', category: 'transaction', title: 'TXN-SWIFT-2024-007812', subtitle: 'ADCB → Deutsche Bank Frankfurt · EUR 2,400,000', meta: 'PENDING_ACK', route: '/operations/queues', rail: Rail.SWIFT, status: 'Pending ACK', amount: 'EUR 2,400,000' },
  { id: 'txn-008', category: 'transaction', title: 'TXN-SWIFT-2024-007799', subtitle: 'FAB → HSBC London · USD 5,750,000', meta: 'SETTLED', route: '/operations/queues', rail: Rail.SWIFT, status: 'Settled', amount: 'USD 5,750,000' },
  { id: 'txn-009', category: 'transaction', title: 'TXN-IPP-2024-022341', subtitle: 'Dubai Mall Merchant · Card Payment · AED 4,200', meta: 'COMPLETED', route: '/operations/queues', rail: Rail.IPP, status: 'Completed', amount: 'AED 4,200' },
  { id: 'txn-010', category: 'transaction', title: 'TXN-IPP-2024-022298', subtitle: 'ADNOC Petrol Station · Card Payment · AED 320', meta: 'COMPLETED', route: '/operations/queues', rail: Rail.IPP, status: 'Completed', amount: 'AED 320' },
  { id: 'txn-011', category: 'transaction', title: 'TXN-UAEFTS-2024-089178', subtitle: 'Mashreq Bank → RAK Bank · AED 980,000', meta: 'FAILED', route: '/operations/queues', rail: Rail.UAEFTS, status: 'Failed', amount: 'AED 980,000' },
  { id: 'txn-012', category: 'transaction', title: 'TXN-IPI-2024-044477', subtitle: 'Khalid Al Mansoori → Liv. Digital Bank · AED 750', meta: 'SETTLED', route: '/operations/queues', rail: Rail.IPI, status: 'Settled', amount: 'AED 750' },

  // Exceptions
  { id: 'exc-001', category: 'exception', title: 'EX-VAL-001 · EXC-20240115-0001', subtitle: 'Invalid IBAN Format · AED 15,000 · Payments L1', meta: 'CRITICAL', route: '/exceptions', rail: Rail.UAEFTS, status: 'Open' },
  { id: 'exc-002', category: 'exception', title: 'EX-AML-004 · EXC-20240115-0002', subtitle: 'AML Screening Hold · AED 890,000 · Compliance L1', meta: 'CRITICAL', route: '/exceptions', rail: Rail.SWIFT, status: 'Escalated' },
  { id: 'exc-003', category: 'exception', title: 'EX-LIQ-007 · EXC-20240115-0008', subtitle: 'Insufficient Liquidity · AED 4,200,000 · Payments L2', meta: 'HIGH', route: '/exceptions', rail: Rail.UAEFTS, status: 'In Triage' },
  { id: 'exc-004', category: 'exception', title: 'EX-FRD-006 · EXC-20240115-0012', subtitle: 'Fraud Pattern Detected · AED 45,000 · Fraud Ops', meta: 'CRITICAL', route: '/exceptions', rail: Rail.IPI, status: 'Held' },
  { id: 'exc-005', category: 'exception', title: 'EX-RCO-010 · EXC-20240115-0019', subtitle: 'Reconciliation Break · AED 2,100 · Reconciliation', meta: 'MEDIUM', route: '/exceptions', rail: Rail.WPS, status: 'Open' },
  { id: 'exc-006', category: 'exception', title: 'EX-SLA-003 · EXC-20240115-0024', subtitle: 'SLA Breach — Settlement Delay · Correspondent', meta: 'HIGH', route: '/exceptions', rail: Rail.SWIFT, status: 'Escalated' },
  { id: 'exc-007', category: 'exception', title: 'EX-CMP-005 · EXC-20240115-0031', subtitle: 'Compliance Sanction Hit · AED 78,000 · Compliance L2', meta: 'CRITICAL', route: '/exceptions', rail: Rail.UAEFTS, status: 'In Triage' },
  { id: 'exc-008', category: 'exception', title: 'EX-VAL-002 · EXC-20240115-0038', subtitle: 'Missing Beneficiary Details · AED 230,000 · Payments L1', meta: 'HIGH', route: '/exceptions', rail: Rail.IPI, status: 'Open' },

  // Approvals
  { id: 'apr-001', category: 'approval', title: 'APR-2024-00891 · High Value Payment', subtitle: 'AED 8,500,000 · Emirates Steel → ENBD · Awaiting Manager', meta: 'PENDING', route: '/operations/approvals', rail: Rail.UAEFTS, status: 'Pending', amount: 'AED 8,500,000' },
  { id: 'apr-002', category: 'approval', title: 'APR-2024-00887 · International Wire', subtitle: 'USD 3,200,000 · FAB → Citibank NY · Awaiting Dual Auth', meta: 'PENDING', route: '/operations/approvals', rail: Rail.SWIFT, status: 'Pending', amount: 'USD 3,200,000' },
  { id: 'apr-003', category: 'approval', title: 'APR-2024-00882 · WPS Batch Release', subtitle: 'AED 12,400,000 · Emaar Properties · Payroll Approval', meta: 'PENDING', route: '/operations/approvals', rail: Rail.WPS, status: 'Pending', amount: 'AED 12,400,000' },
  { id: 'apr-004', category: 'approval', title: 'APR-2024-00876 · Exception Escalation', subtitle: 'EX-AML-004 Escalated · Awaiting Compliance Head', meta: 'ESCALATED', route: '/operations/approvals', status: 'Escalated' },
  { id: 'apr-005', category: 'approval', title: 'APR-2024-00871 · Counterparty Limit Override', subtitle: 'Deutsche Bank Limit +EUR 5M · Awaiting Risk Officer', meta: 'PENDING', route: '/operations/approvals', status: 'Pending', amount: 'EUR 5,000,000' },
  { id: 'apr-006', category: 'approval', title: 'APR-2024-00864 · Sanctions Override', subtitle: 'Manual Sanctions Clear · AED 620,000 · Dual Auth Required', meta: 'PENDING', route: '/operations/approvals', rail: Rail.UAEFTS, status: 'Pending', amount: 'AED 620,000' },
  { id: 'apr-007', category: 'approval', title: 'APR-2024-00857 · Queue Re-route', subtitle: 'Bulk Re-route 45 items · Payments L1 → L2 · Ops Manager', meta: 'APPROVED', route: '/operations/approvals', status: 'Approved' },

  // Customers
  { id: 'cus-001', category: 'customer', title: 'Ahmed Al Zaabi', subtitle: 'CIF-001234 · Premium · ADCB Dubai Main', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-002', category: 'customer', title: 'Fatima Investment LLC', subtitle: 'CIF-002891 · Corporate · ADCB Business Banking', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-003', category: 'customer', title: 'Khalid Al Mansoori', subtitle: 'CIF-003412 · Retail · ADCB Abu Dhabi Corniche', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-004', category: 'customer', title: 'Gulf Contractors LLC', subtitle: 'CIF-004567 · SME · ADCB Industrial City Branch', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-005', category: 'customer', title: 'Emirates Steel Industries', subtitle: 'CIF-005123 · Corporate · ADCB Trade Finance', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-006', category: 'customer', title: 'Nakheel Properties PJSC', subtitle: 'CIF-006789 · Corporate · ADCB Real Estate', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-007', category: 'customer', title: 'Hamad Al Rashidi', subtitle: 'CIF-007234 · Retail · ADCB Sharjah Branch', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-008', category: 'customer', title: 'Emaar Properties PJSC', subtitle: 'CIF-008901 · Corporate · ADCB Downtown Dubai', meta: 'ACTIVE', route: '/operations/queues' },
  { id: 'cus-009', category: 'customer', title: 'Al Zaabi Trading Co.', subtitle: 'CIF-009456 · SME · ADCB Deira Branch', meta: 'WATCHLIST', route: '/operations/queues' },

  // Counterparties
  { id: 'ctp-001', category: 'counterparty', title: 'Deutsche Bank AG', subtitle: 'BIC: DEUTDEFF · Frankfurt · EUR Correspondent', meta: 'ACTIVE', route: '/dashboard/swift' },
  { id: 'ctp-002', category: 'counterparty', title: 'HSBC Bank plc', subtitle: 'BIC: MIDLGB22 · London · GBP / USD Correspondent', meta: 'ACTIVE', route: '/dashboard/swift' },
  { id: 'ctp-003', category: 'counterparty', title: 'Emirates NBD', subtitle: 'BIC: EBILAEAD · Dubai · UAEFTS Participant', meta: 'ACTIVE', route: '/dashboard/uaefts' },
  { id: 'ctp-004', category: 'counterparty', title: 'Abu Dhabi Islamic Bank', subtitle: 'BIC: ADIBAEAA · Abu Dhabi · UAEFTS / IPI Participant', meta: 'ACTIVE', route: '/dashboard/uaefts' },
  { id: 'ctp-005', category: 'counterparty', title: 'Mashreq Bank', subtitle: 'BIC: BOMLAEAD · Dubai · UAEFTS Participant', meta: 'ACTIVE', route: '/dashboard/uaefts' },
  { id: 'ctp-006', category: 'counterparty', title: 'Citibank N.A.', subtitle: 'BIC: CITIUS33 · New York · USD Correspondent', meta: 'ACTIVE', route: '/dashboard/swift' },
  { id: 'ctp-007', category: 'counterparty', title: 'Careem Pay', subtitle: 'IPI Participant · Digital Wallet · Aani Enabled', meta: 'ACTIVE', route: '/dashboard/ipi' },
  { id: 'ctp-008', category: 'counterparty', title: 'Wio Bank', subtitle: 'IPI Participant · Digital Bank · Aani Enabled', meta: 'ACTIVE', route: '/dashboard/ipi' },
  { id: 'ctp-009', category: 'counterparty', title: 'RAK Bank', subtitle: 'BIC: NRAKAEAK · Ras Al Khaimah · UAEFTS Participant', meta: 'DEGRADED', route: '/dashboard/uaefts' },

  // Reports
  { id: 'rpt-001', category: 'report', title: 'Daily Settlement Report', subtitle: 'UAEFTS — Today · AED 4.2B settled · Generated 18:00', meta: 'AVAILABLE', route: '/reporting', rail: Rail.UAEFTS },
  { id: 'rpt-002', category: 'report', title: 'WPS Payroll Compliance Report', subtitle: 'WPS — May 2024 · 12,450 employees · MOL Compliant', meta: 'AVAILABLE', route: '/reporting', rail: Rail.WPS },
  { id: 'rpt-003', category: 'report', title: 'Exception Resolution SLA Report', subtitle: 'All Rails — Last 7 Days · 94.2% SLA Compliance', meta: 'AVAILABLE', route: '/reporting' },
  { id: 'rpt-004', category: 'report', title: 'GPI Tracker Summary Report', subtitle: 'SWIFT — Today · 124 tracked transfers · 98.4% on-track', meta: 'AVAILABLE', route: '/reporting', rail: Rail.SWIFT },
  { id: 'rpt-005', category: 'report', title: 'Approval Workflow Audit Report', subtitle: 'All Queues — Last 30 Days · 3,892 approvals', meta: 'AVAILABLE', route: '/reporting' },
  { id: 'rpt-006', category: 'report', title: 'IPI / Aani Transaction Volume Report', subtitle: 'IPI — Today · 89,234 transactions · AED 142M', meta: 'AVAILABLE', route: '/reporting', rail: Rail.IPI },
  { id: 'rpt-007', category: 'report', title: 'Counterparty Exposure Report', subtitle: 'SWIFT — Live · Top 10 Correspondents by Exposure', meta: 'AVAILABLE', route: '/reporting', rail: Rail.SWIFT },
  { id: 'rpt-008', category: 'report', title: 'Fraud Detection Trends Report', subtitle: 'All Rails — Last 90 Days · Pattern Analysis', meta: 'AVAILABLE', route: '/reporting' },
];

const RECENT_SEARCHES: RecentSearch[] = [
  { query: 'EXC-20240115', timestamp: new Date(Date.now() - 3 * 60000) },
  { query: 'Ahmed Al Zaabi', timestamp: new Date(Date.now() - 18 * 60000) },
  { query: 'TXN-UAEFTS-2024', timestamp: new Date(Date.now() - 45 * 60000) },
  { query: 'WPS payroll batch', timestamp: new Date(Date.now() - 2 * 3600000) },
  { query: 'Deutsche Bank', timestamp: new Date(Date.now() - 5 * 3600000) },
];

@Injectable({ providedIn: 'root' })
export class SearchService {
  private recent: RecentSearch[] = [...RECENT_SEARCHES];

  search(query: string, limitPerCategory = 4): SearchResultGroup[] {
    if (!query.trim()) return [];
    const q = query.toLowerCase();

    const matched = MOCK_INDEX.filter(r =>
      r.title.toLowerCase().includes(q) ||
      r.subtitle.toLowerCase().includes(q) ||
      (r.meta ?? '').toLowerCase().includes(q) ||
      (r.rail ?? '').toLowerCase().includes(q)
    );

    const grouped = new Map<SearchCategory, SearchResult[]>();
    for (const r of matched) {
      if (!grouped.has(r.category)) grouped.set(r.category, []);
      const arr = grouped.get(r.category)!;
      if (arr.length < limitPerCategory) arr.push(r);
    }

    const order: SearchCategory[] = ['exception', 'approval', 'transaction', 'customer', 'counterparty', 'report'];
    const groups: SearchResultGroup[] = [];
    for (const cat of order) {
      const results = grouped.get(cat);
      if (results?.length) {
        groups.push({ category: cat, label: CATEGORY_META[cat].label, icon: CATEGORY_META[cat].icon, results });
      }
    }
    return groups;
  }

  getTotalCount(query: string): number {
    if (!query.trim()) return 0;
    const q = query.toLowerCase();
    return MOCK_INDEX.filter(r =>
      r.title.toLowerCase().includes(q) ||
      r.subtitle.toLowerCase().includes(q) ||
      (r.meta ?? '').toLowerCase().includes(q) ||
      (r.rail ?? '').toLowerCase().includes(q)
    ).length;
  }

  getRecent(): RecentSearch[] {
    return this.recent.slice(0, 5);
  }

  saveSearch(query: string): void {
    const q = query.trim();
    if (!q) return;
    this.recent = [{ query: q, timestamp: new Date() }, ...this.recent.filter(r => r.query !== q)].slice(0, 10);
  }

  getSuggestions(query: string): string[] {
    if (!query.trim() || query.length < 2) return [];
    const q = query.toLowerCase();
    const seen = new Set<string>();
    const suggestions: string[] = [];
    for (const r of MOCK_INDEX) {
      if (r.title.toLowerCase().startsWith(q) && !seen.has(r.title)) {
        seen.add(r.title);
        suggestions.push(r.title);
        if (suggestions.length >= 5) break;
      }
    }
    return suggestions;
  }
}
