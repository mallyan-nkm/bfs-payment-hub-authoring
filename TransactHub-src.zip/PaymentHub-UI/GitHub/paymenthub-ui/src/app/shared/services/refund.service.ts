import { Injectable } from '@angular/core';
import {
  Rail, QueueItem, QueueItemStatus, ApprovalStatus,
  RefundReasonCode, RefundRequestStatus, RefundEligibility,
  RefundRequest, BulkRefundCampaign, BulkActionResult,
  AuditEvent, ApprovalTier, PaymentType,
} from '../types';

// ── Eligibility windows per rail (banking days) ──────────────────────────────

const ELIGIBILITY_WINDOWS: Partial<Record<Rail, { days: number; label: string }>> = {
  [Rail.UAEFTS]: { days: 5,  label: 'T+5 banking days' },
  [Rail.IPI]:    { days: 5,  label: 'T+5 banking days (via UAEFTS network)' },
  [Rail.IPP]:    { days: 1,  label: 'T+1 same-day reversal window' },
  [Rail.WPS]:    { days: 30, label: 'Per MoHRE protocol (no strict window)' },
  [Rail.SWIFT]:  { days: 10, label: 'T+10 banking days (correspondent chain)' },
};

// ── Statuses from which a refund can be initiated ────────────────────────────

const REFUNDABLE_STATUSES: QueueItemStatus[] = [
  QueueItemStatus.APPROVED,
  QueueItemStatus.RESOLVED,
];

// ── Approval tier thresholds ─────────────────────────────────────────────────

const APPROVAL_TIERS: { threshold: number; tier: ApprovalTier }[] = [
  {
    threshold: 0,
    tier: { step: 1, label: 'Operations Manager', approvers: ['Operations Manager'], required: true, reason: 'All refund requests require Operations Manager approval' },
  },
  {
    threshold: 1_000_000,
    tier: { step: 2, label: 'Senior Manager', approvers: ['Senior Manager'], required: true, reason: 'Refund > AED 1M requires Senior Manager sign-off' },
  },
  {
    threshold: 2_000_000,
    tier: { step: 3, label: 'Dual Authority (Ops Head + Risk Officer)', approvers: ['Operations Head', 'Risk Officer'], required: true, reason: 'Refund > AED 2M requires dual authority' },
  },
];

const FRAUD_TIER: ApprovalTier = {
  step: 99, label: 'Risk Officer Co-Sign', approvers: ['Risk Officer'], required: true,
  reason: 'Fraud-reason refunds always require Risk Officer co-sign',
};

const SWIFT_COMPLIANCE_TIER: ApprovalTier = {
  step: 99, label: 'Compliance Sign-Off', approvers: ['Compliance Officer'], required: true,
  reason: 'SWIFT refunds require Compliance sign-off per AML policy',
};

function addBankingDays(from: Date, days: number): Date {
  const d = new Date(from);
  let added = 0;
  while (added < days) {
    d.setDate(d.getDate() + 1);
    const dow = d.getDay();
    if (dow !== 0 && dow !== 6) added++; // skip weekends
  }
  return d;
}

function generateRef(prefix: string): string {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

function buildApprovalTiers(amount: number, reasonCode: RefundReasonCode, rail: Rail): ApprovalTier[] {
  const tiers: ApprovalTier[] = APPROVAL_TIERS
    .filter(t => amount >= t.threshold)
    .map(t => ({ ...t.tier }));

  if (reasonCode === RefundReasonCode.FRAD) tiers.push({ ...FRAUD_TIER });
  if (rail === Rail.SWIFT) tiers.push({ ...SWIFT_COMPLIANCE_TIER });

  // Re-number steps
  return tiers.map((t, i) => ({ ...t, step: i + 1 }));
}

// ─────────────────────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class RefundService {

  private readonly requests = new Map<string, RefundRequest>();
  private readonly campaigns = new Map<string, BulkRefundCampaign>();

  // ── Eligibility ───────────────────────────────────────────────────────────

  checkEligibility(item: QueueItem, requestedAmount?: number): RefundEligibility {
    const amount = requestedAmount ?? item.amount;
    const now = new Date();

    // Must be in a terminal settled status
    if (!REFUNDABLE_STATUSES.includes(item.status)) {
      return {
        isEligible: false,
        ineligibilityReason: `Payment must be in APPROVED or RESOLVED state (current: ${item.status})`,
        requiresBeneficiaryConsent: false,
        requiresCounterpartyAction: false,
        approvalTiersRequired: [],
      };
    }

    // Already has an active refund request
    const existing = [...this.requests.values()].find(
      r => r.originalItemId === item.id && !['DECLINED', 'CANCELLED'].includes(r.status)
    );
    if (existing) {
      return {
        isEligible: false,
        ineligibilityReason: `Active refund request already exists: ${existing.reference}`,
        requiresBeneficiaryConsent: false,
        requiresCounterpartyAction: false,
        approvalTiersRequired: [],
      };
    }

    const window = ELIGIBILITY_WINDOWS[item.rail];
    const windowExpiry = window ? addBankingDays(item.submittedAt, window.days) : undefined;
    const windowExpired = windowExpiry ? now > windowExpiry : false;

    // IPP card — beyond same-day reversal window, must go through card network
    if (item.rail === Rail.IPP && windowExpired) {
      return {
        isEligible: true,
        windowExpiry,
        windowLabel: 'Chargeback window (120 days via card network)',
        ineligibilityReason: undefined,
        requiresBeneficiaryConsent: false,
        requiresCounterpartyAction: true,
        routedVia: Rail.IPP,
        routingNote: 'Beyond same-day reversal — chargeback initiated via card network rules',
        approvalTiersRequired: buildApprovalTiers(amount, RefundReasonCode.CUST, item.rail),
      };
    }

    if (windowExpired && item.rail !== Rail.WPS) {
      return {
        isEligible: false,
        ineligibilityReason: `Refund eligibility window expired (${window?.label}). Bilateral negotiation only.`,
        windowExpiry,
        windowLabel: window?.label,
        requiresBeneficiaryConsent: false,
        requiresCounterpartyAction: true,
        approvalTiersRequired: [],
      };
    }

    // IPI refunds are routed via UAEFTS network (confirmed by business)
    const isIpi = item.rail === Rail.IPI;
    const effectiveRail = isIpi ? Rail.UAEFTS : item.rail;
    const routingNote = isIpi
      ? 'IPI refunds are processed through the UAEFTS network'
      : undefined;

    const requiresBeneficiaryConsent = isIpi || item.rail === Rail.UAEFTS;

    return {
      isEligible: true,
      windowExpiry,
      windowLabel: window?.label,
      requiresBeneficiaryConsent,
      requiresCounterpartyAction: item.rail === Rail.SWIFT || item.rail === Rail.UAEFTS || isIpi,
      routedVia: effectiveRail,
      routingNote,
      approvalTiersRequired: buildApprovalTiers(amount, RefundReasonCode.CUST, effectiveRail),
    };
  }

  // ── Single refund request ─────────────────────────────────────────────────

  submitRefundRequest(
    item: QueueItem,
    reasonCode: RefundReasonCode,
    narrativeReason: string,
    requestedAmount: number,
    raisedBy = 'Current User',
    bulkCampaignId?: string,
  ): RefundRequest {
    const eligibility = this.checkEligibility(item, requestedAmount);
    const isIpi = item.rail === Rail.IPI;
    const effectiveRail = isIpi ? Rail.UAEFTS : item.rail;

    const req: RefundRequest = {
      id: generateRef('RFQ'),
      reference: generateRef('RFR'),
      originalPaymentRef: item.reference,
      originalItemId: item.id,
      rail: item.rail,
      paymentSubType: item.paymentSubType,
      effectiveRail,
      reasonCode,
      narrativeReason: narrativeReason || undefined,
      requestedAmount,
      originalAmount: item.amount,
      currency: item.currency,
      status: eligibility.isEligible ? 'PENDING_APPROVAL' : 'DRAFT',
      raisedBy,
      raisedAt: new Date(),
      approvalStatus: eligibility.isEligible ? ApprovalStatus.PENDING_L1 : undefined,
      beneficiaryConsentRequired: eligibility.requiresBeneficiaryConsent,
      counterpartyDeadline: eligibility.windowExpiry,
      bulkCampaignId,
      auditTrail: [
        {
          id: `aud-${Date.now()}`,
          timestamp: new Date(),
          actor: raisedBy,
          actorType: 'user',
          action: 'REFUND_REQUEST_RAISED',
          description: `Refund request raised for ${item.reference} — Reason: ${reasonCode}${narrativeReason ? ' — ' + narrativeReason : ''}`,
        } satisfies AuditEvent,
      ],
    };

    this.requests.set(req.id, req);
    return req;
  }

  // ── Bulk refund ───────────────────────────────────────────────────────────

  submitBulkRefund(
    items: QueueItem[],
    reasonCode: RefundReasonCode,
    narrativeReason: string,
    raisedBy = 'Current User',
  ): { campaign: BulkRefundCampaign; result: BulkActionResult } {

    const campaignId = generateRef('BRC');
    const eligibleItems: QueueItem[] = [];
    const ineligibleItems: { item: QueueItem; reason: string }[] = [];

    for (const item of items) {
      const elig = this.checkEligibility(item);
      if (elig.isEligible) {
        eligibleItems.push(item);
      } else {
        ineligibleItems.push({ item, reason: elig.ineligibilityReason ?? 'Not eligible' });
      }
    }

    const totalAmount = eligibleItems.reduce((s, i) => s + i.amount, 0);
    const currency = eligibleItems[0]?.currency ?? 'AED';

    // Build per-item refund requests linked to campaign
    const campaignItems = eligibleItems.map(item => {
      const req = this.submitRefundRequest(item, reasonCode, narrativeReason, item.amount, raisedBy, campaignId);
      return {
        itemId: item.id,
        originalRef: item.reference,
        refundRequestRef: req.reference,
        status: req.status as RefundRequestStatus,
        amount: item.amount,
      };
    });

    // Ineligible items appear as failed in the campaign record
    const failedItems = ineligibleItems.map(({ item, reason }) => ({
      itemId: item.id,
      originalRef: item.reference,
      refundRequestRef: '',
      status: 'CANCELLED' as RefundRequestStatus,
      amount: item.amount,
      eligibilityReason: reason,
    }));

    const approvalTiersRequired = buildApprovalTiers(totalAmount, reasonCode, Rail.ALL);

    // Approval status based on total amount
    let approvalStatus = ApprovalStatus.PENDING_L1;
    if (totalAmount >= 2_000_000) approvalStatus = ApprovalStatus.PENDING_SENIOR;
    else if (totalAmount >= 1_000_000) approvalStatus = ApprovalStatus.PENDING_L2;

    const campaign: BulkRefundCampaign = {
      campaignId,
      raisedBy,
      raisedAt: new Date(),
      reasonCode,
      narrativeReason: narrativeReason || undefined,
      totalItems: items.length,
      totalAmount,
      currency,
      approvalStatus,
      approvalTiersRequired,
      items: [...campaignItems, ...failedItems],
      counterpartyProgress: {
        responded: 0,
        pending: eligibleItems.length,
        accepted: 0,
        declined: 0,
      },
      slaDeadline: addBankingDays(new Date(), 5),
      createdAt: new Date(),
    };

    this.campaigns.set(campaignId, campaign);

    const result: BulkActionResult = {
      actionId: 'refund',
      total: items.length,
      succeeded: eligibleItems.length,
      failed: ineligibleItems.length,
      errors: ineligibleItems.map(({ item, reason }) => ({ itemId: item.id, message: reason })),
      bulkRefundCampaignId: campaignId,
    };

    return { campaign, result };
  }

  // ── Queries ───────────────────────────────────────────────────────────────

  getRefundRequest(id: string): RefundRequest | undefined {
    return this.requests.get(id);
  }

  getRefundRequestsForItem(itemId: string): RefundRequest[] {
    return [...this.requests.values()].filter(r => r.originalItemId === itemId);
  }

  getCampaigns(): BulkRefundCampaign[] {
    return [...this.campaigns.values()].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  getCampaign(campaignId: string): BulkRefundCampaign | undefined {
    return this.campaigns.get(campaignId);
  }

  formatReasonCode(code: RefundReasonCode): string {
    const labels: Record<RefundReasonCode, string> = {
      [RefundReasonCode.DUPL]: 'Duplicate Payment',
      [RefundReasonCode.FRAD]: 'Fraud / Unauthorised',
      [RefundReasonCode.TECH]: 'Technical / Processing Error',
      [RefundReasonCode.CUST]: 'Customer Request',
      [RefundReasonCode.CXLD]: 'Cancellation',
      [RefundReasonCode.NARR]: 'See Narrative',
    };
    return labels[code];
  }

  railLabel(rail: Rail): string {
    const labels: Record<Rail, string> = {
      [Rail.UAEFTS]: 'UAEFTS', [Rail.IPI]: 'IPI', [Rail.IPP]: 'IPP',
      [Rail.WPS]: 'WPS', [Rail.SWIFT]: 'SWIFT', [Rail.ALL]: 'All Rails',
    };
    return labels[rail];
  }
}
