import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ExportService {

  toCsv(rows: Record<string, unknown>[], filename: string): void {
    if (!rows.length) return;
    const headers = Object.keys(rows[0]);
    const lines = [
      headers.join(','),
      ...rows.map(row =>
        headers.map(h => {
          const val = row[h] ?? '';
          const s = String(val instanceof Date ? val.toISOString() : val);
          return s.includes(',') || s.includes('"') || s.includes('\n')
            ? `"${s.replace(/"/g, '""')}"`
            : s;
        }).join(',')
      )
    ];
    this.download(lines.join('\r\n'), `${filename}.csv`, 'text/csv;charset=utf-8;');
  }

  private download(content: string, filename: string, mime: string): void {
    const blob = new Blob(['﻿' + content], { type: mime });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
