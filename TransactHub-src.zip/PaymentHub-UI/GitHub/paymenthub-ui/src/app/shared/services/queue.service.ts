﻿import { Injectable } from '@angular/core';
import {
  Rail, QueueItem, QueueItemType, QueueItemStatus, QueuePriority, QueueType,
  QueueFilter, QueueSort, QueuePage, QuickFilter, BulkAction, BulkActionResult,
  BulkActionRequest, SavedFilterSet, QueueTypeTab, SlaStatus,
  TransactionDetail, RefundReasonCode, BatchLineItem, BatchSummary
} from '../types';
import { RefundService } from './refund.service';

@Injectable({ providedIn: 'root' })
export class QueueService {

  constructor(private refundSvc: RefundService) {}

  // --- UI Configuration (static definitions, no mock data) ---

  getQueueTypeTabs(): QueueTypeTab[] {
    return [
      { type: QueueType.ALL,           label: 'All Queues',     count: 0, urgentCount: 0 },
      { type: QueueType.PAYMENTS_L1,   label: 'Payments L1',   count: 0, urgentCount: 0 },
      { type: QueueType.PAYMENTS_L2,   label: 'Payments L2',   count: 0, urgentCount: 0 },
      { type: QueueType.COMPLIANCE_L1, label: 'Compliance L1', count: 0, urgentCount: 0 },
      { type: QueueType.COMPLIANCE_L2, label: 'Compliance L2', count: 0, urgentCount: 0 },
      { type: QueueType.FRAUD_OPS,     label: 'Fraud Ops',     count: 0, urgentCount: 0 },
      { type: QueueType.WPS_OPS,       label: 'WPS Ops',       count: 0, urgentCount: 0 },
      { type: QueueType.CORRESPONDENT, label: 'Correspondent', count: 0, urgentCount: 0 },
      { type: QueueType.INVESTIGATION, label: 'Investigation', count: 0, urgentCount: 0 },
      { type: QueueType.REFUND_OPS,    label: 'Refund Ops',    count: 0, urgentCount: 0 },
    ];
  }

  getQuickFilters(queueType: QueueType): QuickFilter[] {
    return [
      { id: 'all',        label: 'All Items',    count: 0, filter: {},                                         color: 'accent'  },
      { id: 'urgent',     label: 'Urgent',       count: 0, filter: { urgentOnly: true },                       color: 'danger'  },
      { id: 'breach',     label: 'SLA Breached', count: 0, filter: { slaStatuses: ['breach'] },                color: 'danger'  },
      { id: 'warning',    label: 'SLA Warning',  count: 0, filter: { slaStatuses: ['warning'] },               color: 'warning' },
      { id: 'unassigned', label: 'Unassigned',   count: 0, filter: { assignedTo: '__unassigned__' },           color: 'info'    },
      { id: 'escalated',  label: 'Escalated',    count: 0, filter: { statuses: [QueueItemStatus.ESCALATED] },  color: 'warning' },
      { id: 'refundable', label: 'Refundable',   count: 0, filter: { statuses: [QueueItemStatus.APPROVED, QueueItemStatus.RESOLVED] }, color: 'success' },
    ];
  }

  getBulkActions(): BulkAction[] {
    return [
      { id: 'approve',  label: 'Approve',        type: 'primary',   requiresConfirmation: true  },
      { id: 'reject',   label: 'Reject',         type: 'danger',    requiresConfirmation: true, requiresReason: true  },
      { id: 'reassign', label: 'Reassign',       type: 'secondary', requiresConfirmation: false, requiresReason: false },
      { id: 'escalate', label: 'Escalate',       type: 'secondary', requiresConfirmation: true  },
      { id: 'refund',   label: 'Request Refund', type: 'danger',    requiresConfirmation: true, requiresReason: true  },
      { id: 'tag',      label: 'Tag',            type: 'secondary', requiresConfirmation: false },
      { id: 'export',   label: 'Export CSV',     type: 'secondary', requiresConfirmation: false },
    ];
  }

  getSavedFilters(): SavedFilterSet[] {
    return [...this.savedFilterStore];
  }

  executeBulkAction(req: BulkActionRequest): BulkActionResult {
    return {
      actionId: req.actionId,
      total: req.itemIds.length,
      succeeded: req.itemIds.length,
      failed: 0,
      errors: []
    };
  }

  getAgents(): string[] {
    return [
      'Ahmed Al Zaabi', 'Sara Al Mansoori', 'Khalid Ibrahim', 'Fatima Hassan',
      'Mohammed Al Rashidi', 'Aisha Al Blooshi', 'Omar Saeed', 'Noura Al Kaabi'
    ];
  }

  private savedFilterStore: SavedFilterSet[] = [];

  saveFilter(name: string, filter: QueueFilter): void {
    this.savedFilterStore.push({
      id: `sf_${Date.now()}`,
      name,
      filter: { ...filter },
      isDefault: false,
      createdAt: new Date(),
    });
  }

  getAlertCount(): number {
    return 0;
  }

  formatAmount(amount: number, currency: string): string {
    if (amount >= 1_000_000) return `${(amount / 1_000_000).toFixed(2)}M ${currency}`;
    if (amount >= 1_000) return `${(amount / 1_000).toFixed(1)}K ${currency}`;
    return `${amount.toLocaleString()} ${currency}`;
  }

  formatSlaRemaining(minutes: number): string {
    if (minutes < 0) return `${Math.abs(minutes)}m overdue`;
    if (minutes < 60) return `${minutes}m left`;
    return `${Math.floor(minutes / 60)}h ${minutes % 60}m left`;
  }

  getBatchSummary(items: BatchLineItem[]): BatchSummary {
    return {
      totalRecords: items.length,
      processed: items.filter(i => i.status === 'processed').length,
      failed: items.filter(i => i.status === 'failed').length,
      pending: items.filter(i => i.status === 'pending').length,
      totalAmount: items.reduce((s, i) => s + i.amount, 0),
    };
  }

  /** Build TransactionDetail from API 360 response */
  buildDetailFromApi(item: QueueItem, dto: any): Partial<TransactionDetail> {
    // workflowJourney is the primary source for routing/workflow steps
    const journey: any[] = dto.workflowJourney ?? dto.temporalHistory ?? [];

    return {
      originatorBank: dto.workflow?.debtorAgent ?? '',
      originatorBic: dto.workflow?.debtorAgentBic ?? '',
      beneficiaryBank: dto.workflow?.creditorAgent ?? '',
      purpose: dto.workflow?.purpose ?? '',
      remittanceInfo: dto.workflow?.remittanceInfo ?? '',
      instructedAmount: dto.workflow?.instructedAmount ?? dto.amount,
      instructedCurrency: dto.workflow?.instructedCurrency ?? dto.currency,
      amount: dto.amount ?? item.amount,
      currency: dto.currency ?? item.currency,
      routingPath: journey.map((h: any, i: number) => ({
        step: i + 1,
        system: h.stepName ?? h.eventType ?? `Step ${i + 1}`,
        status: this.mapStepStatus(h.status),
        enteredAt: h.startedAt ? new Date(h.startedAt) : (h.timestamp ? new Date(h.timestamp) : undefined),
        exitedAt: h.completedAt ? new Date(h.completedAt) : undefined,
        latencyMs: h.durationMs ?? undefined,
        note: h.errorMessage ?? h.stepType ?? '',
      })),
      auditTrail: (dto.auditTrail ?? []).map((a: any) => ({
        timestamp: new Date(a.timestamp ?? a.occurredAt ?? Date.now()),
        actor: a.actor ?? a.changedBy ?? 'System',
        action: a.action ?? a.eventType ?? '',
        details: a.details ?? a.changeReason ?? '',
        channel: a.channel ?? 'system',
      })),
      comments: [],
      complianceFlags: (dto.exceptions ?? []).map((e: any) => ({
        code: e.exceptionType ?? 'EXCEPTION',
        label: e.description ?? e.exceptionType ?? '',
        severity: e.severity ?? 'medium',
        raisedAt: new Date(e.createdAt ?? Date.now()),
        resolvedAt: e.resolvedAt ? new Date(e.resolvedAt) : undefined,
      })),
    };
  }

  private mapStepStatus(status: string): 'completed' | 'in_progress' | 'pending' | 'failed' | 'skipped' {
    switch (status?.toUpperCase()) {
      case 'COMPLETED': case 'EVALUATED': case 'CONDITION_TRUE': case 'CONDITION_FALSE':
        return 'completed';
      case 'RUNNING': case 'IN_PROGRESS':
        return 'in_progress';
      case 'FAILED': case 'ERROR':
        return 'failed';
      case 'SKIPPED':
        return 'skipped';
      default:
        return 'pending';
    }
  }
}
