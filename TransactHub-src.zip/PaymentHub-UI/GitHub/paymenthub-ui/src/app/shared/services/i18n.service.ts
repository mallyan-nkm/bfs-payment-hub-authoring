import { Injectable, signal, computed } from '@angular/core';

export type SupportedLocale = 'en' | 'ar';
export type TextDirection = 'ltr' | 'rtl';

@Injectable({ providedIn: 'root' })
export class I18nService {
  private _locale = signal<SupportedLocale>(this.loadLocale());
  private _translations = signal<Record<string, string>>({});

  readonly locale = this._locale.asReadonly();
  readonly direction = computed<TextDirection>(() => this._locale() === 'ar' ? 'rtl' : 'ltr');
  readonly isRtl = computed(() => this._locale() === 'ar');

  async init(): Promise<void> {
    await this.loadTranslations(this._locale());
    this.applyDirection();
  }

  async setLocale(locale: SupportedLocale): Promise<void> {
    this._locale.set(locale);
    try { localStorage.setItem('ph-locale', locale); } catch {}
    await this.loadTranslations(locale);
    this.applyDirection();
  }

  translate(key: string, params?: Record<string, string | number>): string {
    let value = this._translations()[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        value = value.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), String(v));
      });
    }
    return value;
  }

  private async loadTranslations(locale: SupportedLocale): Promise<void> {
    try {
      const response = await fetch(`/assets/i18n/${locale}.json`);
      if (response.ok) {
        const data = await response.json();
        this._translations.set(this.flattenKeys(data));
      }
    } catch {
      // Fall back to empty — keys will show as-is (English fallback)
      this._translations.set({});
    }
  }

  private flattenKeys(obj: Record<string, unknown>, prefix = ''): Record<string, string> {
    const result: Record<string, string> = {};
    for (const [key, value] of Object.entries(obj)) {
      const fullKey = prefix ? `${prefix}.${key}` : key;
      if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
        Object.assign(result, this.flattenKeys(value as Record<string, unknown>, fullKey));
      } else {
        result[fullKey] = String(value);
      }
    }
    return result;
  }

  private applyDirection(): void {
    const dir = this.direction();
    document.documentElement.setAttribute('dir', dir);
    document.documentElement.setAttribute('lang', this._locale());
  }

  private loadLocale(): SupportedLocale {
    try {
      const saved = localStorage.getItem('ph-locale');
      if (saved === 'en' || saved === 'ar') return saved;
    } catch {}
    return 'en';
  }
}
