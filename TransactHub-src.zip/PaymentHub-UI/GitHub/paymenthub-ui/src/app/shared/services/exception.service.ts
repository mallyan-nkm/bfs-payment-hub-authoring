import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import {
  ExceptionItem, ExceptionFilter, ExceptionPage, ExceptionSort,
  ExceptionQueueTab, ExceptionSummary, ExceptionTrendPoint,
  ExceptionSeverity, ExceptionStatus, ExceptionQueue,
  Rail, SlaStatus, ComplianceFlag, AuditEvent, TransactionComment
} from '../types';

export interface CodeStat {
  code: string;
  desc: string;
  total: number;
  open: number;
  count: number;
  pct: number;
  avgMttr: number;
  trend: 'up' | 'down' | 'flat';
}

export interface RailStat {
  rail: Rail;
  total: number;
  open: number;
  criticalCount: number;
  resolvedPct: number;
  avgMttr: number;
  slaBreach: number;
}

@Injectable({ providedIn: 'root' })
export class ExceptionService {
  private http = inject(HttpClient);
  private baseUrl = environment.apiBaseUrl;

  // Real data from API — populated on first fetch
  private cachedItems: ExceptionItem[] = [];

  // ─── API methods (fetch from PaymentHub DB) ─────────────────────────────

  /** Fetch open exceptions from the real backend with server-side pagination */
  fetchExceptions(tenantId?: string, exceptionType?: string, take = 200): Observable<ExceptionItem[]> {
    let params = new HttpParams();
    if (tenantId) params = params.set('tenantId', tenantId);
    if (exceptionType) params = params.set('exceptionType', exceptionType);
    params = params.set('take', take);
    return this.http.get<any>(`${this.baseUrl}/exceptions`, { params }).pipe(
      map(resp => {
        // API returns { value: [...], Count: N } or plain array or paginated { items, total }
        const items = Array.isArray(resp) ? resp : (resp?.items ?? resp?.value ?? []);
        return items.map((dto: any) => this.mapApiToExceptionItem(dto));
      }),
      tap(items => { this.cachedItems = items; }),
      catchError(() => of([]))
    );
  }

  /** Fetch paginated exceptions from backend — server-side filtering and pagination */
  fetchExceptionsPaginated(
    filter: ExceptionFilter, sort: ExceptionSort, page: number, pageSize: number
  ): Observable<ExceptionPage> {
    let params = new HttpParams()
      .set('page', page)
      .set('pageSize', pageSize)
      .set('sortColumn', sort.column || 'createdAt')
      .set('sortDirection', sort.direction || 'desc');

    if (filter.search?.trim()) params = params.set('search', filter.search.trim());

    return this.http.get<any>(`${this.baseUrl}/exceptions`, { params }).pipe(
      map(resp => {
        // Handle paginated response { items, total } or legacy array
        const rawItems = resp?.items ?? (Array.isArray(resp) ? resp : resp?.value ?? []);
        const total = resp?.total ?? rawItems.length;
        const items = rawItems.map((dto: any) => this.mapApiToExceptionItem(dto));

        // Apply client-side filters not handled by backend (queue, severities, rails, slaStatuses)
        const filtered = this.applyFilterToItems(items, { ...filter, search: '' });

        return { items: filtered, totalCount: total, filteredCount: total, page, pageSize };
      }),
      tap(result => { this.cachedItems = result.items; }),
      catchError(() => of({ items: [], totalCount: 0, filteredCount: 0, page, pageSize }))
    );
  }

  /** Map API exception DTO to the UI ExceptionItem shape */
  private mapApiToExceptionItem(dto: any): ExceptionItem {
    const now = Date.now();
    const createdAt = new Date(dto.createdAt);
    const ageMinutes = Math.floor((now - createdAt.getTime()) / 60_000);

    // Use SLA deadline from DB if available, otherwise compute
    const slaDeadline = dto.slaDeadline
      ? new Date(dto.slaDeadline)
      : new Date(createdAt.getTime() + (dto.severity === 'CRITICAL' ? 4 : 8) * 3600_000);
    const msRemaining = slaDeadline.getTime() - now;
    const slaMinutesRemaining = Math.round(msRemaining / 60_000);
    let slaStatus: SlaStatus = 'ok';
    if (dto.resolvedAt) slaStatus = 'ok';
    else if (msRemaining < 0) slaStatus = 'breach';
    else if (msRemaining < 30 * 60_000) slaStatus = 'warning';

    const severityMap: Record<string, ExceptionSeverity> = {
      'CRITICAL': ExceptionSeverity.CRITICAL,
      'HIGH': ExceptionSeverity.HIGH,
      'MEDIUM': ExceptionSeverity.MEDIUM,
      'NORMAL': ExceptionSeverity.MEDIUM,
      'LOW': ExceptionSeverity.LOW,
    };

    const statusMap: Record<string, ExceptionStatus> = {
      'OPEN': ExceptionStatus.OPEN,
      'IN_TRIAGE': ExceptionStatus.IN_TRIAGE,
      'HELD': ExceptionStatus.HELD,
      'ESCALATED': ExceptionStatus.ESCALATED,
      'RESOLVED': ExceptionStatus.RESOLVED,
      'AUTO_RESOLVED': ExceptionStatus.AUTO_RESOLVED,
      'REJECTED': ExceptionStatus.REJECTED,
    };

    // Map rail string from API to Rail enum
    const railFromDto: Record<string, Rail> = {
      'IPI': Rail.IPI,
      'UAEFTS': Rail.UAEFTS,
      'FTS': Rail.UAEFTS,
      'WPS': Rail.WPS,
      'SWIFT': Rail.SWIFT,
      'CBFT': Rail.SWIFT,
      'NPSS': Rail.IPP,
      'IPP': Rail.IPP,
    };

    // Derive queue from exceptionType + rail
    const resolvedRail = railFromDto[dto.rail] ?? railFromDto[dto.schemaType] ?? Rail.UAEFTS;
    let queue = ExceptionQueue.PAYMENTS_L1;
    if (dto.exceptionType === 'AML_HOLD' || dto.exceptionType === 'SANCTIONS_HIT') {
      queue = ExceptionQueue.COMPLIANCE_L1;
    } else if (dto.exceptionType === 'FRAUD_ALERT') {
      queue = ExceptionQueue.FRAUD_OPS;
    } else if (resolvedRail === Rail.WPS) {
      queue = ExceptionQueue.WPS_OPS;
    } else if (resolvedRail === Rail.SWIFT) {
      queue = ExceptionQueue.CORRESPONDENT;
    }

    return {
      id: dto.exceptionId,
      reference: dto.transactionId || dto.exceptionId,
      exceptionCode: dto.exceptionType || 'UNKNOWN',
      description: dto.description || dto.exceptionType || '',
      module: dto.workflowName || 'Payment Processing',
      severity: severityMap[dto.severity] ?? ExceptionSeverity.MEDIUM,
      status: statusMap[dto.status] ?? ExceptionStatus.OPEN,
      queue,
      rail: resolvedRail,
      ageMinutes,
      createdAt,
      updatedAt: dto.lastRetryAt ? new Date(dto.lastRetryAt) : createdAt,
      slaDeadline,
      slaStatus,
      slaMinutesRemaining,
      assignedTo: dto.assignedTo || undefined,
      originatorName: dto.tenantId || '',
      beneficiaryName: undefined,
      amount: undefined,
      currency: undefined,
      relatedRef: dto.transactionId,
      resolutionPath: dto.resolutionNotes || '',
      resolutionCode: undefined,
      resolvedAt: dto.resolvedAt ? new Date(dto.resolvedAt) : undefined,
      resolvedBy: dto.resolvedBy || undefined,
      isAutoResolvable: false,
      complianceFlags: [],
      auditTrail: [],
      comments: [],
    };
  }

  /** Assign exception to an agent */
  assignException(exceptionId: string, assignedTo: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/assign`, { assignedTo }).pipe(
      catchError(() => of(null))
    );
  }

  /** Resolve an exception */
  resolveException(exceptionId: string, resolvedBy: string, notes: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/resolve`, { resolvedBy, notes }).pipe(
      catchError(() => of(null))
    );
  }

  /** Escalate an exception */
  escalateException(exceptionId: string, notes?: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/escalate`, notes ? { notes } : null).pipe(
      catchError(() => of(null))
    );
  }

  /** Retry a failed exception */
  retryException(exceptionId: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/exceptions/${exceptionId}/retry`, {}).pipe(
      catchError(() => of(null))
    );
  }

  // ─── Computed views from real data ──────────────────────────────────────

  getPageFromApi(filter: ExceptionFilter, sort: ExceptionSort, page: number, pageSize: number): ExceptionPage {
    let items = this.applyFilterToItems(this.cachedItems, filter);
    items = this.applySortToItems(items, sort);
    const totalCount = this.cachedItems.length;
    const filteredCount = items.length;
    const start = page * pageSize;
    return { items: items.slice(start, start + pageSize), totalCount, filteredCount, page, pageSize };
  }

  getQueueTabsFromApi(): ExceptionQueueTab[] {
    const queues = Object.values(ExceptionQueue);
    return queues.map(q => {
      const items = q === ExceptionQueue.ALL ? this.cachedItems : this.cachedItems.filter(i => i.queue === q);
      return {
        queue: q,
        label: q.replace(/_/g, ' '),
        count: items.length,
        criticalCount: items.filter(i => i.severity === ExceptionSeverity.CRITICAL).length,
      };
    });
  }

  getSummaryFromApi(): ExceptionSummary {
    const open = this.cachedItems.filter(i => i.status !== ExceptionStatus.RESOLVED && i.status !== ExceptionStatus.AUTO_RESOLVED);
    return {
      totalOpen: open.length,
      critical: open.filter(i => i.severity === ExceptionSeverity.CRITICAL).length,
      high: open.filter(i => i.severity === ExceptionSeverity.HIGH).length,
      slaBreaches: open.filter(i => i.slaStatus === 'breach').length,
      resolvedToday: this.cachedItems.filter(i => i.resolvedAt && (Date.now() - i.resolvedAt.getTime()) < 86_400_000).length,
      autoResolvedToday: this.cachedItems.filter(i => i.status === ExceptionStatus.AUTO_RESOLVED).length,
      avgResolutionMinutes: 0,
      escalationRate: 0,
    };
  }

  getTopCodesFromApi(): CodeStat[] {
    const codeMap = new Map<string, { code: string; desc: string; total: number; open: number }>();
    this.cachedItems.forEach(i => {
      if (!codeMap.has(i.exceptionCode)) {
        codeMap.set(i.exceptionCode, { code: i.exceptionCode, desc: i.description, total: 0, open: 0 });
      }
      const entry = codeMap.get(i.exceptionCode)!;
      entry.total++;
      if (i.status !== ExceptionStatus.RESOLVED && i.status !== ExceptionStatus.AUTO_RESOLVED) entry.open++;
    });
    return Array.from(codeMap.values())
      .sort((a, b) => b.total - a.total)
      .slice(0, 10)
      .map(s => ({
        code: s.code,
        desc: s.desc,
        total: s.total,
        open: s.open,
        count: s.total,
        pct: this.cachedItems.length > 0 ? Math.round(s.total / this.cachedItems.length * 100) : 0,
        avgMttr: 0,
        trend: 'flat' as const
      }));
  }

  getRailStatsFromApi(): RailStat[] {
    const railItems = new Map<Rail, ExceptionItem[]>();
    this.cachedItems.forEach(i => {
      const arr = railItems.get(i.rail) ?? [];
      arr.push(i);
      railItems.set(i.rail, arr);
    });
    return Array.from(railItems.entries()).map(([rail, items]) => {
      const open = items.filter(i => i.status !== ExceptionStatus.RESOLVED && i.status !== ExceptionStatus.AUTO_RESOLVED).length;
      return {
        rail,
        total: items.length,
        open,
        criticalCount: items.filter(i => i.severity === ExceptionSeverity.CRITICAL).length,
        resolvedPct: items.length > 0 ? Math.round((items.length - open) / items.length * 100) : 0,
        avgMttr: 0,
        slaBreach: items.filter(i => i.slaStatus === 'breach').length,
      };
    });
  }

  private applyFilterToItems(items: ExceptionItem[], f: ExceptionFilter): ExceptionItem[] {
    return items.filter(item => {
      if (f.queue && f.queue !== ExceptionQueue.ALL && item.queue !== f.queue) return false;
      if (f.severities?.length && !f.severities.includes(item.severity)) return false;
      if (f.statuses?.length && !f.statuses.includes(item.status)) return false;
      if (f.rails?.length && !f.rails.includes(item.rail)) return false;
      if (f.slaStatuses?.length && !f.slaStatuses.includes(item.slaStatus)) return false;
      if (f.search?.trim()) {
        const s = f.search.toLowerCase();
        if (!item.exceptionCode.toLowerCase().includes(s) &&
            !item.description.toLowerCase().includes(s) &&
            !item.reference.toLowerCase().includes(s)) return false;
      }
      return true;
    });
  }

  private applySortToItems(items: ExceptionItem[], sort: ExceptionSort): ExceptionItem[] {
    return [...items].sort((a, b) => {
      const av = a[sort.column] as any;
      const bv = b[sort.column] as any;
      let cmp = 0;
      if (av instanceof Date && bv instanceof Date) cmp = av.getTime() - bv.getTime();
      else if (typeof av === 'number') cmp = (av as number) - (bv as number);
      else cmp = String(av ?? '').localeCompare(String(bv ?? ''));
      return sort.direction === 'desc' ? -cmp : cmp;
    });
  }

  getDefaultFilter(): ExceptionFilter {
    return {
      search: '',
      queue: ExceptionQueue.ALL,
      severities: [],
      statuses: [],
      rails: [],
      slaStatuses: []
    };
  }

  getItem(id: string): ExceptionItem | null {
    return this.cachedItems.find(i => i.id === id) ?? null;
  }

  submitAction(id: string, action: string, note?: string): void {
    const item = this.cachedItems.find(i => i.id === id);
    if (!item) return;
    const now = new Date();
    const actionMap: Record<string, ExceptionStatus> = {
      resolve: ExceptionStatus.RESOLVED,
      escalate: ExceptionStatus.ESCALATED,
      hold: ExceptionStatus.HELD,
      reject: ExceptionStatus.REJECTED,
    };
    const newStatus = actionMap[action];
    if (newStatus) {
      item.status = newStatus;
      if (action === 'resolve') {
        item.resolvedAt = now;
        item.resolvedBy = 'Current User';
      }
    }
    item.updatedAt = now;
  }

  submitComment(id: string, body: string): void {
    const item = this.cachedItems.find(i => i.id === id);
    if (!item || !body.trim()) return;
    item.comments.push({
      id: `CMT-${Date.now()}`,
      timestamp: new Date(),
      author: 'Current User',
      body: body.trim(),
      isSystem: false
    });
  }

  getAlertCount(): number {
    return this.cachedItems.filter(i =>
      i.severity === ExceptionSeverity.CRITICAL &&
      i.status !== ExceptionStatus.RESOLVED &&
      i.status !== ExceptionStatus.AUTO_RESOLVED
    ).length;
  }
}
