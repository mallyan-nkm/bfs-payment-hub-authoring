import { Injectable } from '@angular/core';
import {
  Rail, PaymentType, PaymentTypeOption, PaymentFormData,
  FormFieldError, ApprovalTier, PaymentFeeEstimate, SubmittedTransaction
} from '../types';

export const PAYMENT_TYPES: Record<Rail, PaymentTypeOption[]> = {
  [Rail.UAEFTS]: [
    { type: 'cb103',       label: 'CB103 Credit Transfer',   description: 'Standard AED credit transfer between UAE banks',                  currency: 'AED' },
    { type: 'cb202',       label: 'CB202 High Value',         description: 'Large value interbank transfer via UAEFTS HVPS',                   currency: 'AED' },
    { type: 'ufp',         label: 'UFP Urgent Payment',       description: 'Urgent same-day payment with priority processing',                currency: 'AED' },
    { type: 'uaefts-bulk', label: 'FTS Bulk Batch (Salary / Pension)', description: 'Upload batch file for bulk salary, pension or EOSB disbursement via UAEFTS FTS channel', currency: 'AED' },
  ],
  [Rail.IPI]: [
    { type: 'ipi-instant', label: 'Instant Credit (IPI)',  description: 'Real-time credit via Aani network, settles in <5 sec', currency: 'AED', maxAmount: 250000 },
    { type: 'ipi-alias',   label: 'Alias-Based (Aani)',    description: 'Send to mobile number or registered Aani alias',       currency: 'AED', maxAmount: 250000 },
  ],
  [Rail.IPP]: [
    { type: 'ipp-card', label: 'Merchant / Card Payment', description: 'Initiate card-based or merchant payment instruction', currency: 'AED' },
  ],
  [Rail.WPS]: [
    { type: 'wps-single',  label: 'Individual WPS Payment',        description: 'Single employee WPS salary disbursement',                                     currency: 'AED' },
    { type: 'wps-batch',   label: 'WPS Salary Batch',               description: 'Bulk salary file upload for MOL WPS processing — CSV/XLSX accepted',           currency: 'AED' },
    { type: 'wps-pension', label: 'WPS Pension / EOSB Batch',       description: 'Pension payments and end-of-service gratuity batch submission to MOL',        currency: 'AED' },
  ],
  [Rail.SWIFT]: [
    { type: 'mt103', label: 'MT103 Customer Transfer', description: 'Cross-border customer credit transfer (FIN MT103)' },
    { type: 'mt202', label: 'MT202 Bank Transfer',     description: 'Interbank funds transfer (FIN MT202/COV)' },
  ],
  [Rail.ALL]: [],
};

export const PURPOSE_CODES: { code: string; label: string }[] = [
  { code: 'SALA', label: 'SALA — Salary Payment' },
  { code: 'PENS', label: 'PENS — Pension Payment' },
  { code: 'TAXS', label: 'TAXS — Tax Payment' },
  { code: 'SUPP', label: 'SUPP — Supplier Payment' },
  { code: 'TRAD', label: 'TRAD — Trade Settlement' },
  { code: 'GDDS', label: 'GDDS — Purchase of Goods' },
  { code: 'SCVE', label: 'SCVE — Purchase of Services' },
  { code: 'LOAR', label: 'LOAR — Loan Repayment' },
  { code: 'RINP', label: 'RINP — Recurring Instalment Payment' },
  { code: 'DIVI', label: 'DIVI — Dividend Payment' },
  { code: 'INTP', label: 'INTP — Interest Payment' },
  { code: 'GOVT', label: 'GOVT — Government Payment' },
  { code: 'PROP', label: 'PROP — Property Purchase' },
  { code: 'RENT', label: 'RENT — Rent Payment' },
  { code: 'CHAR', label: 'CHAR — Charitable Donation' },
  { code: 'TREA', label: 'TREA — Treasury Transfer' },
  { code: 'INTC', label: 'INTC — Intra-Company Transfer' },
  { code: 'OTHR', label: 'OTHR — Other' },
];

export const CATEGORY_PURPOSES: { code: string; label: string; rails: string[] }[] = [
  { code: 'SALA', label: 'SALA — Salary',              rails: ['UAEFTS', 'IPI', 'WPS'] },
  { code: 'PENS', label: 'PENS — Pension',             rails: ['UAEFTS', 'WPS'] },
  { code: 'TAXS', label: 'TAXS — Tax',                 rails: ['UAEFTS'] },
  { code: 'SUPP', label: 'SUPP — Supplier',            rails: ['UAEFTS', 'IPI'] },
  { code: 'TRAD', label: 'TRAD — Trade',               rails: ['UAEFTS', 'IPI', 'SWIFT'] },
  { code: 'IVPT', label: 'IVPT — Invoice Payment',     rails: ['IPI'] },
  { code: 'BONU', label: 'BONU — Bonus',               rails: ['UAEFTS', 'WPS'] },
  { code: 'INTC', label: 'INTC — Intra-Company',       rails: ['UAEFTS', 'SWIFT'] },
  { code: 'TREA', label: 'TREA — Treasury',            rails: ['UAEFTS', 'SWIFT'] },
  { code: 'OTHR', label: 'OTHR — Other',               rails: ['UAEFTS', 'IPI', 'WPS', 'SWIFT'] },
];

export const CURRENCIES = ['AED', 'USD', 'EUR', 'GBP', 'SAR', 'QAR', 'KWD', 'BHD', 'OMR', 'JPY', 'CHF'];

export const UAE_BANKS: { bic: string; name: string }[] = [
  { bic: 'ADCBAEAA', name: 'ADCB' },
  { bic: 'EBILAEAD', name: 'Emirates NBD' },
  { bic: 'ADIBAEAA', name: 'Abu Dhabi Islamic Bank (ADIB)' },
  { bic: 'NBADAEAA', name: 'First Abu Dhabi Bank (FAB)' },
  { bic: 'BOMLAEAD', name: 'Mashreq Bank' },
  { bic: 'NRAKAEAK', name: 'RAK Bank' },
  { bic: 'DUIBAEAD', name: 'Dubai Islamic Bank (DIB)' },
  { bic: 'WIOBAEAAYYY', name: 'Wio Bank' },
  { bic: 'LIVBAEAD', name: 'Liv. Digital Bank' },
  { bic: 'CBILAEAD', name: 'Commercial Bank of Dubai' },
];

const REQUIRED_IBAN_RAILS: PaymentType[] = ['cb103', 'cb202', 'ufp', 'ipi-instant', 'mt103', 'mt202'];

let refCounter = 89400;

@Injectable({ providedIn: 'root' })
export class TransactionInitiationService {

  getDefaultForm(): PaymentFormData {
    const today = new Date().toISOString().split('T')[0];
    const e2eRef = 'E2E' + Date.now().toString(36).toUpperCase();
    return {
      rail: null, paymentType: null,
      originatorIban: 'AE070331234567890123456', originatorName: 'ADCB Operations Account', originatorBank: 'ADCBAEAA',
      beneficiaryIban: '', beneficiaryName: '', beneficiaryBank: '', beneficiaryBic: '',
      beneficiaryAddress: '', beneficiaryMobile: '',
      ipiAliasType: 'mobile',
      endToEndRef: e2eRef,
      chargeCode: 'SLEV',
      creditorAgentBic: '',
      categoryPurpose: '',
      settlementMethod: 'CLRG' as 'RTGS' | 'CLRG',
      employeeEmiratesId: '', employeeBasicSalary: '', employeeAllowance: '',
      employeeNumber: '',
      housingAllowance: '',
      transportAllowance: '',
      otherAllowance: '',
      daysWorked: '',
      daysInPeriod: '',
      salaryType: 'monthly' as 'monthly' | 'daily',
      amount: '', currency: 'AED', valueDate: today, priority: 'NORMAL',
      purposeCode: 'OTHR', remittanceInfo: '',
      employerId: '', wpsEmployerNumber: '', payPeriod: '',
      batchFileName: '', batchRecordCount: 0, batchSubType: 'salary', ftsBatchFileType: 'SIF',
    };
  }

  validate(data: PaymentFormData): FormFieldError[] {
    const errors: FormFieldError[] = [];
    const amt = parseFloat(data.amount);
    if (!data.paymentType) return errors;

    const isBatch = data.paymentType === 'wps-batch' || data.paymentType === 'wps-pension' || data.paymentType === 'uaefts-bulk';

    // ── IBAN validation (non-WPS domestic rails) ─────────────────────────────
    if (REQUIRED_IBAN_RAILS.includes(data.paymentType)) {
      if (!data.beneficiaryIban.match(/^AE\d{21}$/)) {
        errors.push({ field: 'beneficiaryIban', message: 'Enter a valid UAE IBAN (AE + 21 digits)' });
      }
    }

    // ── SWIFT BIC ────────────────────────────────────────────────────────────
    if (data.paymentType === 'mt103' || data.paymentType === 'mt202') {
      if (!data.beneficiaryBic.match(/^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/)) {
        errors.push({ field: 'beneficiaryBic', message: 'Enter a valid BIC / SWIFT code (8 or 11 chars)' });
      }
    }

    // ── IPI / Aani alias (CBUAE RPSF — alias type aware) ────────────────────
    if (data.paymentType === 'ipi-alias') {
      const aliasType = data.ipiAliasType ?? 'mobile';
      if (aliasType === 'email') {
        if (!data.beneficiaryMobile.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
          errors.push({ field: 'beneficiaryMobile', message: 'Enter a valid email address for the Aani alias' });
        }
      } else if (aliasType === 'emiratesId') {
        if (!data.beneficiaryMobile.match(/^784-\d{4}-\d{7}-\d$/)) {
          errors.push({ field: 'beneficiaryMobile', message: 'Enter a valid Emirates ID (784-XXXX-XXXXXXX-X)' });
        }
      } else if (aliasType === 'tradeLicense') {
        if (!data.beneficiaryMobile.trim()) {
          errors.push({ field: 'beneficiaryMobile', message: 'Enter a valid UAE Trade License Number' });
        }
      } else if (aliasType === 'virtualAccount') {
        if (!data.beneficiaryMobile.trim()) {
          errors.push({ field: 'beneficiaryMobile', message: 'Enter a valid Virtual Account Number' });
        }
      } else {
        if (!data.beneficiaryMobile.match(/^\+971[0-9]{9}$/)) {
          errors.push({ field: 'beneficiaryMobile', message: 'Enter a valid UAE mobile (+971XXXXXXXXX)' });
        }
      }
    }

    // ── WPS Single — CBUAE / MoHRE mandatory fields ──────────────────────────
    if (data.paymentType === 'wps-single') {
      if (!data.beneficiaryIban.match(/^AE\d{21}$/)) {
        errors.push({ field: 'beneficiaryIban', message: 'Employee WPS-registered IBAN required (AE + 21 digits)' });
      }
      if (!data.employeeEmiratesId?.trim()) {
        errors.push({ field: 'employeeEmiratesId', message: 'Employee Emirates ID or Passport Number is required for WPS' });
      }
      if (!data.employeeBasicSalary || parseFloat(data.employeeBasicSalary) <= 0) {
        errors.push({ field: 'employeeBasicSalary', message: 'Basic salary amount is required for WPS Single payment' });
      }
      if (!data.employeeNumber?.trim()) {
        errors.push({ field: 'employeeNumber', message: 'Employee number (internal ID) is required for WPS' });
      }
    }

    // ── UAEFTS CB202 / UFP — creditor bank BIC mandatory for routing ─────────
    if (data.paymentType === 'cb202' || data.paymentType === 'ufp') {
      if (!data.creditorAgentBic?.trim()) {
        errors.push({ field: 'creditorAgentBic', message: 'Creditor bank BIC is required for CB202/UFP' });
      }
    }

    // ── WPS Batch / Pension — MoHRE WPS employer registration ───────────────
    if (data.paymentType === 'wps-batch' || data.paymentType === 'wps-pension') {
      if (!data.wpsEmployerNumber?.trim()) {
        errors.push({ field: 'wpsEmployerNumber', message: 'MoHRE WPS Employer Registration Number is required' });
      }
      if (!data.batchFileName) {
        errors.push({ field: 'batchFileName', message: 'Please upload a batch file' });
      }
      if (!data.payPeriod) {
        errors.push({ field: 'payPeriod', message: 'Pay period is required' });
      }
    }

    // ── FTS Bulk ─────────────────────────────────────────────────────────────
    if (data.paymentType === 'uaefts-bulk') {
      if (!data.batchFileName) {
        errors.push({ field: 'batchFileName', message: 'Please upload a batch file' });
      }
      if (!data.payPeriod) {
        errors.push({ field: 'payPeriod', message: 'Pay period is required' });
      }
    }

    // ── MOL Employer ID (all WPS) ─────────────────────────────────────────────
    if (data.paymentType === 'wps-single' || data.paymentType === 'wps-batch' || data.paymentType === 'wps-pension') {
      if (!data.employerId.trim()) {
        errors.push({ field: 'employerId', message: 'MOL Employer ID is required for WPS' });
      }
    }

    // ── Beneficiary name (not required for batch — comes from file) ──────────
    if (!isBatch && !data.beneficiaryName.trim()) {
      errors.push({ field: 'beneficiaryName', message: 'Beneficiary name is required' });
    }

    // ── Amount (not validated for batch — total comes from file) ─────────────
    if (!isBatch) {
      if (!data.amount || isNaN(amt) || amt <= 0) {
        errors.push({ field: 'amount', message: 'Enter a valid positive amount' });
      } else {
        const opt = this.getPaymentTypes(data.rail!).find(p => p.type === data.paymentType);
        if (opt?.maxAmount && amt > opt.maxAmount) {
          errors.push({ field: 'amount', message: `Maximum allowed is ${opt.maxAmount.toLocaleString()} ${data.currency} for this payment type` });
        }
      }
    }

    if (!data.purposeCode) {
      errors.push({ field: 'purposeCode', message: 'Purpose code is required' });
    }

    return errors;
  }

  getApprovalChain(data: PaymentFormData): ApprovalTier[] {
    const amt = parseFloat(data.amount) || 0;
    const inAed = data.currency === 'AED' ? amt : amt * 3.67; // rough USD→AED
    const chain: ApprovalTier[] = [];

    if (inAed >= 100_000) {
      chain.push({ step: 1, label: 'Operations Manager', approvers: ['Mariam Al Qassimi'], required: true, reason: 'Amount ≥ AED 100,000' });
    }
    if (inAed >= 500_000) {
      chain.push({ step: 2, label: 'Senior Manager', approvers: ['Khalid Al Hamdan'], required: true, reason: 'Amount ≥ AED 500,000' });
    }
    if (inAed >= 2_000_000) {
      chain.push({ step: 3, label: 'Operations Head', approvers: ['Sara Al Blooshi'], required: true, reason: 'Amount ≥ AED 2,000,000 — Dual Authority' });
      chain.push({ step: 4, label: 'Risk Officer',    approvers: ['Faisal Al Naqbi'],  required: true, reason: 'Amount ≥ AED 2,000,000 — Dual Authority' });
    }
    if (data.rail === Rail.SWIFT && inAed >= 3_670_000) {
      chain.push({ step: chain.length + 1, label: 'Compliance Review', approvers: ['Hessa Al Mazrouei'], required: true, reason: 'SWIFT transfer ≥ USD 1,000,000 — Compliance sign-off' });
    }
    return chain;
  }

  getFeeEstimate(data: PaymentFormData): PaymentFeeEstimate {
    const map: Partial<Record<PaymentType, PaymentFeeEstimate>> = {
      'cb103':      { fee: 0,    currency: 'AED', settlementTime: 'Same day (within UAEFTS window)', settlementWindow: 'Next UAEFTS cycle' },
      'cb202':      { fee: 15,   currency: 'AED', settlementTime: 'Real-time gross settlement', settlementWindow: 'Immediate (HVPS)' },
      'ufp':        { fee: 25,   currency: 'AED', settlementTime: 'Urgent — within 30 minutes' },
      'ipi-instant':{ fee: 0,    currency: 'AED', settlementTime: 'Real-time (< 5 seconds)' },
      'ipi-alias':  { fee: 0,    currency: 'AED', settlementTime: 'Real-time (< 5 seconds)' },
      'ipp-card':   { fee: 0,    currency: 'AED', settlementTime: 'T+1 business day' },
      'wps-single': { fee: 0,    currency: 'AED', settlementTime: 'Same day (MOL SLA: D+0)' },
      'wps-batch':  { fee: 0,    currency: 'AED', settlementTime: 'Same day (MOL SLA: D+0)' },
      'mt103':      { fee: 45,   currency: 'AED', fxRate: data.currency !== 'AED' ? `1 ${data.currency} = ${(3.67).toFixed(4)} AED` : undefined, settlementTime: 'T+1 to T+2 (SWIFT standard)' },
      'mt202':      { fee: 35,   currency: 'AED', settlementTime: 'T+0 to T+1 (correspondent agreement)' },
    };
    return map[data.paymentType!] ?? { fee: 0, currency: 'AED', settlementTime: 'Standard processing' };
  }

  submit(data: PaymentFormData): SubmittedTransaction {
    const railTag = data.rail === Rail.ALL ? 'TXN' : `TXN-${data.rail}`;
    const ref = `${railTag}-2024-0${++refCounter}`;
    const chain = this.getApprovalChain(data);
    return {
      reference: ref,
      status: chain.length > 0 ? 'PENDING_APPROVAL' : 'PROCESSING',
      submittedAt: new Date(),
      estimatedSettlement: this.getFeeEstimate(data).settlementTime,
      approvalRequired: chain.length > 0,
    };
  }

  getPaymentTypes(rail: Rail): PaymentTypeOption[] {
    return PAYMENT_TYPES[rail] ?? [];
  }
}
