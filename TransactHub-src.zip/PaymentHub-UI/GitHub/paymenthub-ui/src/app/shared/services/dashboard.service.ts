import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, forkJoin, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import {
  Rail, StatusIndicator,
  LiveOpsData, RailHealth, HourlyVolume, MessageTypeStatus,
  UaeftsDashboardData, IpiDashboardData, IppDashboardData,
  WpsDashboardData, SwiftDashboardData,
  DashboardRefreshConfig
} from '../types';

/** Shape returned by /api/workflows/instances */
interface WorkflowInstance {
  id: string;
  runId: string;
  workflowName: string;
  status: string;
  startTime: string;
  closeTime?: string;
  taskQueue: string;
  tenantId?: string;
}

@Injectable({ providedIn: 'root' })
export class DashboardService {

  private http = inject(HttpClient);
  private baseUrl = environment.apiBaseUrl;

  private refreshConfig$ = new BehaviorSubject<DashboardRefreshConfig>({
    autoRefresh: true,
    intervalSeconds: 30,
    lastRefreshed: new Date(),
    isPaused: false
  });

  getRefreshConfig(): Observable<DashboardRefreshConfig> {
    return this.refreshConfig$.asObservable();
  }

  togglePause(): void {
    const cfg = this.refreshConfig$.getValue();
    this.refreshConfig$.next({ ...cfg, isPaused: !cfg.isPaused });
  }

  markRefreshed(): void {
    const cfg = this.refreshConfig$.getValue();
    this.refreshConfig$.next({ ...cfg, lastRefreshed: new Date() });
  }

  setInterval(seconds: number): void {
    const cfg = this.refreshConfig$.getValue();
    this.refreshConfig$.next({ ...cfg, intervalSeconds: seconds });
  }

  // ─── API-driven data (fetches from PaymentHub_Ops KPI tables) ───────────

  /** Fetch live operations dashboard from real API endpoints */
  fetchLiveOpsData(): Observable<LiveOpsData> {
    return forkJoin({
      kpi: this.http.get<any>(`${this.baseUrl}/kpi/dashboard`).pipe(catchError(() => of(null))),
      workflows: this.fetchWorkflowInstances(),
      exceptions: this.http.get<any[]>(`${this.baseUrl}/exceptions`).pipe(
        map(resp => Array.isArray(resp) ? resp : (resp as any)?.value ?? []),
        catchError(() => of([]))
      )
    }).pipe(
      map(({ kpi, workflows, exceptions }) => this.buildLiveOpsData(kpi, workflows, exceptions))
    );
  }

  /** Fetch all workflow instances from Temporal */
  fetchWorkflowInstances(): Observable<WorkflowInstance[]> {
    return this.http.get<any[]>(`${this.baseUrl}/workflows/instances`).pipe(
      map(items => (Array.isArray(items) ? items : (items as any)?.value ?? []) as WorkflowInstance[]),
      catchError(() => of([]))
    );
  }

  /** Fetch transaction data for a specific rail — server-side paginated */
  fetchRailTransactions(rail: Rail, page = 1, pageSize = 50): Observable<any> {
    // Schema prefix map for client-side filtering (DB uses workflow names like IPI_OUTWARD)
    const schemaPrefixMap: Partial<Record<Rail, string[]>> = {
      [Rail.IPI]: ['IPI'],
      [Rail.UAEFTS]: ['FTS'],
      [Rail.WPS]: ['WPS'],
      [Rail.SWIFT]: ['SWIFT', 'CBFT'],
      [Rail.IPP]: ['NPSS', 'IPP']
    };
    const prefixes = schemaPrefixMap[rail] ?? [];

    // Fetch paginated report transactions
    const params = new HttpParams().set('page', page).set('pageSize', pageSize);

    return forkJoin({
      reports: this.http.get<any>(`${this.baseUrl}/reports/transactions`, { params }).pipe(
        catchError(() => of({ items: [], total: 0 }))
      ),
      workflows: this.fetchWorkflowInstances()
    }).pipe(
      map(({ reports, workflows }) => {
        // Client-side filter report items by schema prefix
        const allItems = reports.items ?? [];
        const railItems = allItems.filter((item: any) => {
          const schema = (item.schemaType ?? '').toUpperCase();
          return prefixes.some(p => schema.startsWith(p));
        });

        // Filter workflow instances to this rail
        const railWorkflows = this.filterWorkflowsByRail(workflows, rail);
        const workflowTotal = railWorkflows.length;
        const reportTotal = railItems.length;
        return {
          items: railItems,
          total: reports.total ?? Math.max(reportTotal, workflowTotal),
          page,
          pageSize,
          workflowInstances: railWorkflows
        };
      })
    );
  }

  /** Fetch MIS overview (from PaymentHub_Ops) */
  fetchMisOverview(tenantId?: string): Observable<any> {
    let params = new HttpParams();
    if (tenantId) params = params.set('tenantId', tenantId);
    const today = new Date().toISOString().slice(0, 10);
    params = params.set('dateFrom', today).set('dateTo', today);
    return this.http.get<any>(`${this.baseUrl}/reports/mis/overview`, { params }).pipe(
      catchError(() => of(null))
    );
  }

  private buildLiveOpsData(kpi: any, workflows: WorkflowInstance[], exceptions: any[]): LiveOpsData {
    const exArr = Array.isArray(exceptions) ? exceptions : (exceptions as any)?.value ?? [];
    const sevCounts = { critical: 0, high: 0, medium: 0, low: 0 };
    for (const ex of exArr) {
      const s = (ex.severity ?? '').toUpperCase();
      if (s === 'CRITICAL') sevCounts.critical++;
      else if (s === 'HIGH') sevCounts.high++;
      else if (s === 'MEDIUM' || s === 'NORMAL') sevCounts.medium++;
      else sevCounts.low++;
    }

    // Count in-flight (RUNNING) workflows
    const running = workflows.filter(w => w.status === 'RUNNING');
    const today = new Date().toISOString().slice(0, 10);
    const todayWorkflows = workflows.filter(w => w.startTime?.startsWith(today));
    const completedToday = todayWorkflows.filter(w => w.status === 'COMPLETED').length;
    const totalToday = todayWorkflows.length;

    // Build rail health from live workflow data
    const railHealth = this.buildRailHealth(workflows);

    // SLA: compute from actual workflow data
    const sla24h = totalToday > 0 ? Math.round((completedToday / totalToday) * 100 * 10) / 10 : 0;
    const sla1h = totalToday > 0 ? Math.round((completedToday / totalToday) * 100 * 10) / 10 : 0;

    // Pending approvals: count workflows that might need approval (no dedicated API)
    const pendingApprovals = workflows.filter(w => w.status === 'RUNNING').length;

    return {
      inFlightCount: Math.max(running.length, kpi?.activeWorkflows ?? 0),
      inFlightValue: 0,
      inFlightCurrency: 'AED',
      exceptions: sevCounts,
      pendingApprovals,
      slaCompliance24h: sla24h,
      slaComplianceLastHour: sla1h,
      railHealth,
      lastUpdated: new Date(kpi?.timestamp ?? Date.now())
    };
  }

  /** Extract rail from workflow instance ID */
  private getWorkflowRail(wf: WorkflowInstance): Rail | null {
    const id = wf.id.toUpperCase();
    if (id.includes('IPI_OUTWARD') || id.includes('IPI_INWARD') || id.includes('_IPI_')) return Rail.IPI;
    if (id.includes('FTS_OUTWARD') || id.includes('FTS_INWARD') || id.includes('_FTS_')) return Rail.UAEFTS;
    if (id.includes('WPS_SALARY') || id.includes('_WPS_')) return Rail.WPS;
    if (id.includes('SWIFT_OUTWARD') || id.includes('SWIFT_INWARD') || id.includes('_SWIFT_')) return Rail.SWIFT;
    if (id.includes('IPP_') || id.includes('_IPP_') || id.includes('NPSS')) return Rail.IPP;
    // Retry workflows: look up parent transaction ID to determine rail
    if (id.startsWith('RETRY-') || id.includes('-RETRY-')) {
      // Extract the parent TXN ID and check known IPI transaction patterns
      const txnMatch = id.match(/TXN-OUT-(\d+)/);
      if (txnMatch) {
        // Check if this TXN ID belongs to a known IPI workflow
        // IPI transactions use TXN-OUT-* pattern from ADIB_IPI_OUTWARD workflows
        return Rail.IPI;
      }
    }
    return null;
  }

  /** Filter workflow instances to a specific rail */
  private filterWorkflowsByRail(workflows: WorkflowInstance[], rail: Rail): WorkflowInstance[] {
    return workflows.filter(wf => this.getWorkflowRail(wf) === rail);
  }

  /** Build rail health from live workflow instances */
  private buildRailHealth(workflows: WorkflowInstance[]): RailHealth[] {
    const rails = [Rail.UAEFTS, Rail.IPI, Rail.IPP, Rail.WPS, Rail.SWIFT];
    const today = new Date().toISOString().slice(0, 10);
    return rails.map(rail => {
      const railWf = this.filterWorkflowsByRail(workflows, rail);
      const todayWf = railWf.filter(w => w.startTime?.startsWith(today));
      const completed = todayWf.filter(w => w.status === 'COMPLETED').length;
      const failed = todayWf.filter(w => w.status === 'FAILED').length;
      const running = railWf.filter(w => w.status === 'RUNNING').length;
      const total = todayWf.length;
      const errorRate = total > 0 ? failed / total : 0;

      let status = StatusIndicator.UNKNOWN;
      if (total > 0) {
        status = errorRate > 0.5 ? StatusIndicator.OUTAGE
          : errorRate > 0.2 ? StatusIndicator.DEGRADED
          : StatusIndicator.OPERATIONAL;
      }

      return {
        rail,
        status,
        throughput: total,
        throughputTypical: Math.max(total, 10),
        latency_p50: 0,
        latency_p95: 0,
        latency_p99: 0,
        error_rate: Math.round(errorRate * 100),
        open_exceptions: 0,
        last_updated: new Date()
      };
    });
  }

  private emptyRailHealth(): RailHealth[] {
    const rails = [Rail.UAEFTS, Rail.IPI, Rail.IPP, Rail.WPS, Rail.SWIFT];
    return rails.map(rail => ({
      rail,
      status: StatusIndicator.UNKNOWN,
      throughput: 0,
      throughputTypical: 0,
      latency_p50: 0,
      latency_p95: 0,
      latency_p99: 0,
      error_rate: 0,
      open_exceptions: 0,
      last_updated: new Date()
    }));
  }

  /** Build hourly volume chart data from workflow instances */
  private buildHourlyVolume(workflows: WorkflowInstance[]): HourlyVolume[] {
    const hourCounts = new Array(24).fill(0);
    for (const wf of workflows) {
      if (wf.startTime) {
        const hour = new Date(wf.startTime).getHours();
        hourCounts[hour]++;
      }
    }
    return hourCounts.map((count, hour) => ({ hour, count }));
  }

  /** Build IPI message status table from report transactions + workflow data */
  private buildIpiMessageStatus(reportItems: any[], workflows: WorkflowInstance[]): MessageTypeStatus[] {
    const outward = workflows.filter(w => w.id.toUpperCase().includes('OUTWARD') || w.id.toUpperCase().includes('TXN-OUT'));
    const inward = workflows.filter(w => w.id.toUpperCase().includes('INWARD'));

    const outCompleted = outward.filter(w => w.status === 'COMPLETED').length;
    const outFailed = outward.filter(w => w.status === 'FAILED').length;
    const outRejected = outward.filter(w => w.status === 'REJECTED').length;
    const inCompleted = inward.filter(w => w.status === 'COMPLETED').length;
    const inFailed = inward.filter(w => w.status === 'FAILED').length;

    const rows: MessageTypeStatus[] = [];

    if (outward.length > 0 || reportItems.length > 0) {
      const outTotal = Math.max(outward.length, reportItems.filter(r => (r.direction ?? '').toUpperCase() === 'OUTWARD').length);
      rows.push({
        messageType: 'pacs.008',
        label: 'IPI Credit Transfer (Outward)',
        direction: 'outbound',
        total: outTotal,
        sanctionCompleted: outCompleted + outRejected,
        sentToNetwork: outCompleted,
        ackReceived: outCompleted,
        nakReceived: outRejected,
        confirmed: outCompleted,
        returned: 0,
        failed: outFailed
      });
    }

    if (inward.length > 0) {
      rows.push({
        messageType: 'pacs.008',
        label: 'IPI Credit Transfer (Inward)',
        direction: 'inbound',
        total: inward.length,
        sanctionCompleted: inCompleted,
        sentToNetwork: null,
        ackReceived: null,
        nakReceived: 0,
        confirmed: inCompleted,
        returned: 0,
        failed: inFailed
      });
    }

    // Add a row for retries if any
    const retries = workflows.filter(w => w.id.toUpperCase().includes('RETRY'));
    if (retries.length > 0) {
      const retryCompleted = retries.filter(w => w.status === 'COMPLETED').length;
      const retryFailed = retries.filter(w => w.status === 'FAILED').length;
      rows.push({
        messageType: 'pacs.008',
        label: 'IPI Retry Attempts',
        direction: 'outbound',
        total: retries.length,
        sanctionCompleted: retries.length,
        sentToNetwork: retryCompleted,
        ackReceived: retryCompleted,
        nakReceived: 0,
        confirmed: retryCompleted,
        returned: 0,
        failed: retryFailed
      });
    }

    return rows;
  }

  // ─── Rail Dashboard Data (fetched from API) ─────────────────────────────

  getUaeftsDashboardData(): Observable<UaeftsDashboardData> {
    return this.fetchRailTransactions(Rail.UAEFTS, 1, 100).pipe(
      map(resp => {
        const wf = resp.workflowInstances ?? [];
        const outbound = wf.filter((w: WorkflowInstance) => w.id.toUpperCase().includes('OUTWARD'));
        const inbound = wf.filter((w: WorkflowInstance) => w.id.toUpperCase().includes('INWARD'));
        return {
          cb103OutboundCount: outbound.length || (resp.total ?? 0),
          cb103InboundCount: inbound.length,
          cb202Count: 0,
          cb202CovCount: 0,
          cb101UfpCount: 0,
          settlementWindowStatus: 'closed' as const,
          settlementWindowCountdownSec: 0,
          cycleProgress: [],
          cb940IngestStatus: 'pending' as const,
          cb950IngestStatus: 'pending' as const,
          treasuryVolume: 0,
          customerVolume: 0,
          messageStatus: [],
          kpis: { dispatchLatencyMs: 0, settlementConfirmLatencyMs: 0, exceptionRate: 0, recoBreakRate: 0 },
          railHealth: this.emptyRailHealth().find(r => r.rail === Rail.UAEFTS)!,
          lastUpdated: new Date()
        };
      })
    );
  }

  getIpiDashboardData(): Observable<IpiDashboardData> {
    return this.fetchRailTransactions(Rail.IPI, 1, 100).pipe(
      map(resp => {
        const wf = resp.workflowInstances ?? [];
        const reportItems = resp.items ?? [];
        const today = new Date().toISOString().slice(0, 10);
        const todayWf = wf.filter((w: WorkflowInstance) => w.startTime?.startsWith(today));
        const completed = todayWf.filter((w: WorkflowInstance) => w.status === 'COMPLETED').length;
        const failed = todayWf.filter((w: WorkflowInstance) => w.status === 'FAILED').length;
        const rejected = todayWf.filter((w: WorkflowInstance) => w.status === 'REJECTED').length;
        const total = todayWf.length;

        // Build hourly volume from ALL workflow instances (not just today)
        const hourlyVolume = this.buildHourlyVolume(wf);

        // Build message status from report transactions + workflow data
        const messageStatus = this.buildIpiMessageStatus(reportItems, wf);

        // Calculate processing times for latency KPIs
        const durations: number[] = wf
          .filter((w: WorkflowInstance) => w.startTime && w.closeTime)
          .map((w: WorkflowInstance) => new Date(w.closeTime!).getTime() - new Date(w.startTime).getTime())
          .sort((a: number, b: number) => a - b);
        const p50 = durations.length > 0 ? durations[Math.floor(durations.length * 0.5)] : 0;
        const p95 = durations.length > 0 ? durations[Math.floor(durations.length * 0.95)] : 0;
        const p99 = durations.length > 0 ? durations[Math.floor(durations.length * 0.99)] : 0;

        return {
          volumePerSecond: 0,
          volumePerMinute: wf.length,
          subSecondSlaCompliancePct: wf.length > 0 ? Math.round((completed / Math.max(wf.length, 1)) * 100) : 0,
          aaniAliasResolutionHealth: wf.length > 0 ? StatusIndicator.OPERATIONAL : StatusIndicator.UNKNOWN,
          copHealth: wf.length > 0 ? StatusIndicator.OPERATIONAL : StatusIndicator.UNKNOWN,
          hourlyVolume,
          messageStatus,
          kpis: {
            throughputPerSec: wf.length > 0 ? +(wf.length / 3600).toFixed(2) : 0,
            latencyP50Ms: p50,
            latencyP95Ms: p95,
            latencyP99Ms: p99,
            instantConfirmRatePct: wf.length > 0 ? Math.round((completed / Math.max(wf.length, 1)) * 100) : 0
          },
          railHealth: this.emptyRailHealth().find(r => r.rail === Rail.IPI)!,
          lastUpdated: new Date()
        };
      })
    );
  }

  getIppDashboardData(): Observable<IppDashboardData> {
    return this.fetchRailTransactions(Rail.IPP, 1, 100).pipe(
      map(resp => {
        const wf = resp.workflowInstances ?? [];
        const total = wf.length;
        const completed = wf.filter((w: WorkflowInstance) => w.status === 'COMPLETED').length;
        return {
          volumePerSecond: 0,
          volumePerMinute: total,
          slaCompliancePct: total > 0 ? Math.round((completed / total) * 100) : 0,
          hourlyVolume: [],
          messageStatus: [],
          kpis: { throughputPerSec: 0, latencyP50Ms: 0, latencyP95Ms: 0, successRatePct: total > 0 ? Math.round((completed / total) * 100) : 0, pendingCount: 0 },
          railHealth: this.emptyRailHealth().find(r => r.rail === Rail.IPP)!,
          lastUpdated: new Date()
        };
      })
    );
  }

  getWpsDashboardData(): Observable<WpsDashboardData> {
    return this.fetchRailTransactions(Rail.WPS, 1, 100).pipe(
      map(resp => {
        const wf = resp.workflowInstances ?? [];
        const completed = wf.filter((w: WorkflowInstance) => w.status === 'COMPLETED').length;
        const failed = wf.filter((w: WorkflowInstance) => w.status === 'FAILED').length;
        const total = wf.length;
        return {
          activeFiles: [],
          refundFlows: [],
          mohreComplianceStatus: 'compliant' as const,
          employerEstablishments: 0,
          messageStatus: [],
          kpis: {
            fileCompletionRatePct: total > 0 ? Math.round((completed / total) * 100) : 0,
            employeeCreditSuccessRatePct: total > 0 ? Math.round((completed / total) * 100) : 0,
            activeCycles: wf.filter((w: WorkflowInstance) => w.status === 'RUNNING').length,
            failedCredits: failed,
            totalEmployeesCredited: completed
          },
          railHealth: this.emptyRailHealth().find(r => r.rail === Rail.WPS)!,
          lastUpdated: new Date()
        };
      })
    );
  }

  getSwiftDashboardData(): Observable<SwiftDashboardData> {
    return this.fetchRailTransactions(Rail.SWIFT, 1, 100).pipe(
      map(resp => {
        const wf = resp.workflowInstances ?? [];
        const outbound = wf.filter((w: WorkflowInstance) => w.id.toUpperCase().includes('OUTWARD'));
        const inbound = wf.filter((w: WorkflowInstance) => w.id.toUpperCase().includes('INWARD'));
        return {
          outboundVolume: outbound.length,
          inboundVolume: inbound.length,
          gpiSubscriptions: 0,
          gpiPending: wf.filter((w: WorkflowInstance) => w.status === 'RUNNING').length,
          gpiConfirmed: wf.filter((w: WorkflowInstance) => w.status === 'COMPLETED').length,
          fxLegHealth: wf.length > 0 ? StatusIndicator.OPERATIONAL : StatusIndicator.UNKNOWN,
          nostroCurrencies: [],
          messageStatus: [],
          kpis: { gpiComplianceRatePct: 0, endToEndLatencyMs: 0, disputeRatePct: 0, correspondentCount: 0 },
          railHealth: this.emptyRailHealth().find(r => r.rail === Rail.SWIFT)!,
          lastUpdated: new Date()
        };
      })
    );
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────

  formatCurrency(value: number, currency = 'AED'): string {
    if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2)}B ${currency}`;
    if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M ${currency}`;
    if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K ${currency}`;
    return `${value} ${currency}`;
  }

  formatCountdown(seconds: number): string {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m ${s.toString().padStart(2, '0')}s`;
  }

  formatLatency(ms: number): string {
    if (ms >= 1000) return `${(ms / 1000).toFixed(1)}s`;
    return `${ms}ms`;
  }

  getThroughputPct(current: number, typical: number): number {
    return Math.min(Math.round((current / typical) * 100), 100);
  }
}
