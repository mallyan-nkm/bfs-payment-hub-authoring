import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import {
  Rail, ReportFilter,
  VolumeReport, VolumePoint, RailVolumeStat,
  SlaReport, SlaPoint, RailSlaStat,
  ExceptionReport, ExceptionBreakdown,
  ApprovalReport, ApprovalStat
} from '../types';

@Injectable({ providedIn: 'root' })
export class ReportingService {

  private http = inject(HttpClient);
  private baseUrl = environment.apiBaseUrl;

  // ─── API-driven reporting methods (PaymentHub_Ops database) ─────────────

  /** Execute a report query against the Ops DB */
  executeReport(request: any, page = 1, pageSize = 50): Observable<any> {
    let params = new HttpParams().set('page', page).set('pageSize', pageSize);
    return this.http.post<any>(`${this.baseUrl}/reports/execute`, request, { params }).pipe(
      catchError(() => of({ items: [], total: 0, page, pageSize }))
    );
  }

  /** Get transaction reports (filtered by rail/schema, date, status) */
  getTransactionReportsFromApi(filter: ReportFilter, page = 1, pageSize = 50): Observable<any> {
    let params = new HttpParams().set('page', page).set('pageSize', pageSize);
    if (filter.rails?.length) {
      const schemaMap: Partial<Record<Rail, string>> = {
        [Rail.IPI]: 'IPI', [Rail.UAEFTS]: 'FTS', [Rail.WPS]: 'WPS',
        [Rail.SWIFT]: 'CBFT', [Rail.IPP]: 'NPSS'
      };
      const schemas = filter.rails.map(r => schemaMap[r]).filter(Boolean);
      if (schemas.length === 1) params = params.set('schemaType', schemas[0]!);
    }
    if (filter.dateFrom) params = params.set('dateFrom', filter.dateFrom);
    if (filter.dateTo) params = params.set('dateTo', filter.dateTo);
    return this.http.get<any>(`${this.baseUrl}/reports/transactions`, { params }).pipe(
      catchError(() => of({ items: [], total: 0, page, pageSize }))
    );
  }

  /** Get MIS overview for dashboard KPIs */
  getMisOverview(tenantId?: string, dateFrom?: string, dateTo?: string): Observable<any> {
    let params = new HttpParams();
    if (tenantId) params = params.set('tenantId', tenantId);
    if (dateFrom) params = params.set('dateFrom', dateFrom);
    if (dateTo) params = params.set('dateTo', dateTo);
    return this.http.get<any>(`${this.baseUrl}/reports/mis/overview`, { params }).pipe(
      catchError(() => of(null))
    );
  }

  /** Export report as CSV (returns Blob for download) */
  exportCsvFromApi(request: any): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/reports/export/csv`, request, { responseType: 'blob' });
  }

  /** Export report as Excel */
  exportExcelFromApi(request: any): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/reports/export/excel`, request, { responseType: 'blob' });
  }

  /** Export report as PDF */
  exportPdfFromApi(request: any): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/reports/export/pdf`, request, { responseType: 'blob' });
  }

  /** Get TAT violations from Ops DB */
  getTatViolations(filter: any, page = 1, pageSize = 50): Observable<any> {
    let params = new HttpParams().set('page', page).set('pageSize', pageSize);
    Object.entries(filter).forEach(([key, value]) => {
      if (value != null && value !== '') params = params.set(key, String(value));
    });
    return this.http.get<any>(`${this.baseUrl}/reports/tat-violations`, { params }).pipe(
      catchError(() => of({ items: [], total: 0, page, pageSize }))
    );
  }

  // ─── Utility methods ─────────────────────────────────────────────────────

  getDefaultFilter(): ReportFilter {
    const today = new Date();
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(today.getDate() - 7);

    const toIso = (d: Date): string => d.toISOString().slice(0, 10);

    return {
      preset:   'last7d',
      dateFrom: toIso(sevenDaysAgo),
      dateTo:   toIso(today),
      rails:    [],
      groupBy:  'day',
    };
  }

  exportCsv(rows: Record<string, unknown>[], filename: string): void {
    if (!rows || rows.length === 0) { return; }

    const headers = Object.keys(rows[0]);
    const escape = (v: unknown): string => {
      const s = v === null || v === undefined ? '' : String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n')
        ? `"${s.replace(/"/g, '""')}"`
        : s;
    };

    const csvLines: string[] = [
      headers.map(escape).join(','),
      ...rows.map(row => headers.map(h => escape(row[h])).join(',')),
    ];

    const csvContent = csvLines.join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }
}
