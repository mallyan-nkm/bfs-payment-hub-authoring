import { Injectable, inject, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';
import { environment } from '../../../environments/environment';

export enum PersonaTier {
  OPERATIONAL = 'OPERATIONAL',
  MANAGER = 'MANAGER',
  EXECUTIVE = 'EXECUTIVE',
  CSUITE = 'CSUITE',
  AUDIT = 'AUDIT',
}

export interface PersonaDefinition {
  id: string;
  name: string;
  displayName: string;
  tier: PersonaTier;
  permissions: string[];
  allowedSections: string[];
  allowedWidgets: string[];
}

const DEFAULT_PERSONA_DEFINITIONS: PersonaDefinition[] = [
  { id: 'PAYMENTS_OPS_L1', name: 'PAYMENTS_OPS_L1', displayName: 'Payments Ops L1', tier: PersonaTier.OPERATIONAL, permissions: ['payments.view', 'payments.create', 'payments.queue.manage', 'exceptions.view', 'exceptions.triage'], allowedSections: ['dashboard', 'operations', 'exceptions', 'reporting'], allowedWidgets: ['kpi-payments', 'queue-status', 'exception-summary'] },
  { id: 'PAYMENTS_OPS_L2', name: 'PAYMENTS_OPS_L2', displayName: 'Payments Ops L2', tier: PersonaTier.OPERATIONAL, permissions: ['payments.view', 'payments.create', 'payments.queue.manage', 'payments.approve.l1', 'exceptions.view', 'exceptions.triage', 'exceptions.resolve'], allowedSections: ['dashboard', 'operations', 'exceptions', 'reporting'], allowedWidgets: ['kpi-payments', 'queue-status', 'exception-summary', 'sla-monitor'] },
  { id: 'COMPLIANCE_OFFICER_L1', name: 'COMPLIANCE_OFFICER_L1', displayName: 'Compliance Officer L1', tier: PersonaTier.OPERATIONAL, permissions: ['compliance.cases.view', 'compliance.cases.create', 'compliance.sanctions.view', 'compliance.sanctions.adjudicate'], allowedSections: ['dashboard', 'compliance', 'exceptions', 'reporting'], allowedWidgets: ['kpi-compliance', 'sanctions-queue', 'case-summary'] },
  { id: 'COMPLIANCE_OFFICER_L2', name: 'COMPLIANCE_OFFICER_L2', displayName: 'Compliance Officer L2', tier: PersonaTier.OPERATIONAL, permissions: ['compliance.cases.view', 'compliance.cases.create', 'compliance.cases.escalate', 'compliance.sanctions.view', 'compliance.sanctions.adjudicate', 'compliance.sar.create'], allowedSections: ['dashboard', 'compliance', 'exceptions', 'reporting'], allowedWidgets: ['kpi-compliance', 'sanctions-queue', 'case-summary', 'sar-queue'] },
  { id: 'COMPLIANCE_MANAGER', name: 'COMPLIANCE_MANAGER', displayName: 'Compliance Manager', tier: PersonaTier.MANAGER, permissions: ['compliance.cases.view', 'compliance.cases.create', 'compliance.cases.escalate', 'compliance.cases.approve', 'compliance.sanctions.view', 'compliance.sanctions.adjudicate', 'compliance.sanctions.override', 'compliance.sar.create', 'compliance.sar.approve', 'compliance.team.manage'], allowedSections: ['dashboard', 'compliance', 'exceptions', 'reporting', 'admin'], allowedWidgets: ['kpi-compliance', 'sanctions-queue', 'case-summary', 'sar-queue', 'team-workload'] },
  { id: 'COMPLIANCE_HEAD', name: 'COMPLIANCE_HEAD', displayName: 'Compliance Head', tier: PersonaTier.EXECUTIVE, permissions: ['compliance.*', 'audit.read', 'reporting.compliance'], allowedSections: ['dashboard', 'compliance', 'exceptions', 'reporting', 'admin', 'audit'], allowedWidgets: ['*'] },
  { id: 'FRAUD_OPS', name: 'FRAUD_OPS', displayName: 'Fraud Ops', tier: PersonaTier.OPERATIONAL, permissions: ['fraud.cases.view', 'fraud.cases.create', 'fraud.cases.investigate', 'fraud.alerts.view'], allowedSections: ['dashboard', 'fraud', 'exceptions', 'reporting'], allowedWidgets: ['kpi-fraud', 'fraud-queue', 'fraud-alerts'] },
  { id: 'FRAUD_MANAGER', name: 'FRAUD_MANAGER', displayName: 'Fraud Manager', tier: PersonaTier.MANAGER, permissions: ['fraud.cases.view', 'fraud.cases.create', 'fraud.cases.investigate', 'fraud.cases.approve', 'fraud.alerts.view', 'fraud.rules.manage', 'fraud.team.manage'], allowedSections: ['dashboard', 'fraud', 'exceptions', 'reporting', 'admin'], allowedWidgets: ['kpi-fraud', 'fraud-queue', 'fraud-alerts', 'team-workload'] },
  { id: 'TREASURY_OPS', name: 'TREASURY_OPS', displayName: 'Treasury Ops', tier: PersonaTier.OPERATIONAL, permissions: ['treasury.nostro.view', 'treasury.funding.create', 'treasury.liquidity.view', 'treasury.fx.view'], allowedSections: ['dashboard', 'treasury', 'reporting'], allowedWidgets: ['kpi-treasury', 'nostro-grid', 'liquidity-monitor'] },
  { id: 'TREASURY_HEAD', name: 'TREASURY_HEAD', displayName: 'Treasury Head', tier: PersonaTier.EXECUTIVE, permissions: ['treasury.*', 'treasury.funding.approve', 'treasury.limits.manage', 'reporting.treasury'], allowedSections: ['dashboard', 'treasury', 'reporting', 'admin'], allowedWidgets: ['*'] },
  { id: 'RECON_OPS', name: 'RECON_OPS', displayName: 'Reconciliation Ops', tier: PersonaTier.OPERATIONAL, permissions: ['recon.view', 'recon.breaks.manage', 'recon.match.manual'], allowedSections: ['dashboard', 'reconciliation', 'reporting'], allowedWidgets: ['kpi-recon', 'recon-breaks', 'match-queue'] },
  { id: 'RECON_MANAGER', name: 'RECON_MANAGER', displayName: 'Reconciliation Manager', tier: PersonaTier.MANAGER, permissions: ['recon.view', 'recon.breaks.manage', 'recon.match.manual', 'recon.rules.manage', 'recon.team.manage'], allowedSections: ['dashboard', 'reconciliation', 'reporting', 'admin'], allowedWidgets: ['kpi-recon', 'recon-breaks', 'match-queue', 'team-workload'] },
  { id: 'WPS_OPS', name: 'WPS_OPS', displayName: 'WPS Ops', tier: PersonaTier.OPERATIONAL, permissions: ['wps.view', 'wps.files.manage', 'wps.batches.process'], allowedSections: ['dashboard', 'operations', 'reporting'], allowedWidgets: ['kpi-wps', 'wps-batches', 'wps-files'] },
  { id: 'WPS_HEAD', name: 'WPS_HEAD', displayName: 'WPS Head', tier: PersonaTier.EXECUTIVE, permissions: ['wps.*', 'wps.config.manage', 'reporting.wps'], allowedSections: ['dashboard', 'operations', 'reporting', 'admin'], allowedWidgets: ['*'] },
  { id: 'CORRESPONDENT_OPS', name: 'CORRESPONDENT_OPS', displayName: 'Correspondent Ops', tier: PersonaTier.OPERATIONAL, permissions: ['correspondent.view', 'correspondent.manage', 'counterparty.view'], allowedSections: ['dashboard', 'operations', 'counterparties', 'reporting'], allowedWidgets: ['kpi-correspondent', 'counterparty-status', 'nostro-grid'] },
  { id: 'BRANCH_OPS', name: 'BRANCH_OPS', displayName: 'Branch Ops', tier: PersonaTier.OPERATIONAL, permissions: ['payments.view', 'payments.create', 'customers.view'], allowedSections: ['dashboard', 'operations', 'customers'], allowedWidgets: ['kpi-payments', 'queue-status'] },
  { id: 'OPERATIONS_HEAD', name: 'OPERATIONS_HEAD', displayName: 'Operations Head', tier: PersonaTier.EXECUTIVE, permissions: ['payments.*', 'exceptions.*', 'operations.config', 'operations.levers', 'team.manage', 'reporting.operations'], allowedSections: ['dashboard', 'operations', 'exceptions', 'reporting', 'admin', 'incidents'], allowedWidgets: ['*'] },
  { id: 'PAYMENTS_HEAD', name: 'PAYMENTS_HEAD', displayName: 'Payments Head', tier: PersonaTier.EXECUTIVE, permissions: ['payments.*', 'exceptions.*', 'operations.config', 'reporting.payments'], allowedSections: ['dashboard', 'operations', 'exceptions', 'reporting', 'admin'], allowedWidgets: ['*'] },
  { id: 'CRO', name: 'CRO', displayName: 'Chief Risk Officer', tier: PersonaTier.CSUITE, permissions: ['*.view', 'risk.*', 'compliance.view', 'fraud.view', 'reporting.*'], allowedSections: ['dashboard', 'compliance', 'fraud', 'reporting', 'audit'], allowedWidgets: ['*'] },
  { id: 'CFO', name: 'CFO', displayName: 'Chief Financial Officer', tier: PersonaTier.CSUITE, permissions: ['*.view', 'treasury.*', 'reporting.*'], allowedSections: ['dashboard', 'treasury', 'reporting', 'audit'], allowedWidgets: ['*'] },
  { id: 'CEO', name: 'CEO', displayName: 'Chief Executive Officer', tier: PersonaTier.CSUITE, permissions: ['*.view', 'reporting.*'], allowedSections: ['dashboard', 'reporting', 'audit'], allowedWidgets: ['*'] },
  { id: 'INTERNAL_AUDIT', name: 'INTERNAL_AUDIT', displayName: 'Internal Audit', tier: PersonaTier.AUDIT, permissions: ['audit.read', '*.view', 'reporting.*'], allowedSections: ['dashboard', 'audit', 'reporting', 'compliance', 'fraud', 'treasury', 'reconciliation', 'operations', 'exceptions'], allowedWidgets: ['*'] },
  { id: 'IT_SUPPORT', name: 'IT_SUPPORT', displayName: 'IT Support', tier: PersonaTier.OPERATIONAL, permissions: ['system.view', 'system.health', 'system.config.view', 'incidents.view', 'incidents.manage'], allowedSections: ['dashboard', 'admin', 'incidents'], allowedWidgets: ['system-health', 'incident-summary'] },
];

@Injectable({ providedIn: 'root' })
export class PersonaService {
  private http = inject(HttpClient);
  private authService = inject(AuthService);

  private _definitions = signal<PersonaDefinition[]>(DEFAULT_PERSONA_DEFINITIONS);
  private _activePersona = computed<PersonaDefinition | null>(() => {
    const persona = this.authService.currentPersona();
    return this._definitions().find(d => d.id === persona) ?? null;
  });

  readonly definitions = this._definitions.asReadonly();
  readonly activePersona = this._activePersona;
  readonly activeTier = computed(() => this._activePersona()?.tier ?? PersonaTier.OPERATIONAL);

  hasPermission(permission: string): boolean {
    const persona = this._activePersona();
    if (!persona) return true; // Dev mode: no auth = allow all
    return persona.permissions.some(p =>
      p === permission || p === '*' || (p.endsWith('.*') && permission.startsWith(p.slice(0, -1)))
    );
  }

  hasAnyPermission(permissions: string[]): boolean {
    return permissions.some(p => this.hasPermission(p));
  }

  isSectionAllowed(section: string): boolean {
    const persona = this._activePersona();
    if (!persona) return true; // Dev mode: no auth = allow all
    return persona.allowedSections.includes(section);
  }

  isWidgetAllowed(widgetId: string): boolean {
    const persona = this._activePersona();
    if (!persona) return false;
    return persona.allowedWidgets.includes('*') || persona.allowedWidgets.includes(widgetId);
  }

  getAvailablePersonas(): PersonaDefinition[] {
    const user = this.authService.user();
    if (!user) return [];
    const all = [user.primaryPersona, ...user.secondaryPersonas];
    return this._definitions().filter(d => all.includes(d.id));
  }

  switchPersona(personaId: string): void {
    this.authService.switchPersona(personaId);
  }

  loadDefinitions(): void {
    this.http.get<PersonaDefinition[]>(`${environment.apiBaseUrl}/personas/definitions`).subscribe({
      next: (defs) => {
        if (defs.length > 0) this._definitions.set(defs);
      },
      error: () => { /* Keep defaults */ }
    });
  }
}
