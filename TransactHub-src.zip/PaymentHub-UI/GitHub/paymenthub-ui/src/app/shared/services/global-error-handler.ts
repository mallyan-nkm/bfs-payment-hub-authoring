import { ErrorHandler, Injectable, inject } from '@angular/core';
import { ToastService } from './toast.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  private toastService = inject(ToastService);

  handleError(error: unknown): void {
    // Log to console in development
    console.error('[GlobalErrorHandler]', error);

    // Avoid showing toast for Angular-internal or navigation errors
    const message = error instanceof Error ? error.message : String(error);
    if (this.isIgnorable(message)) return;

    this.toastService.show('error', 'Unexpected Error', 'Something went wrong. Please try again or contact support.');
  }

  private isIgnorable(message: string): boolean {
    const ignoredPatterns = [
      'ExpressionChangedAfterItHasBeenCheckedError',
      'Navigation ID',
      'NG0100',
      'Loading chunk',
    ];
    return ignoredPatterns.some(p => message.includes(p));
  }
}
