import { Injectable, signal, computed, OnDestroy } from '@angular/core';

export type ConnectionState = 'online' | 'offline' | 'slow';

@Injectable({ providedIn: 'root' })
export class ConnectionService implements OnDestroy {
  private _state = signal<ConnectionState>(navigator.onLine ? 'online' : 'offline');
  private onlineHandler = () => this._state.set('online');
  private offlineHandler = () => this._state.set('offline');

  readonly state = this._state.asReadonly();
  readonly isOnline = computed(() => this._state() !== 'offline');
  readonly isOffline = computed(() => this._state() === 'offline');

  constructor() {
    window.addEventListener('online', this.onlineHandler);
    window.addEventListener('offline', this.offlineHandler);
  }

  ngOnDestroy(): void {
    window.removeEventListener('online', this.onlineHandler);
    window.removeEventListener('offline', this.offlineHandler);
  }
}
