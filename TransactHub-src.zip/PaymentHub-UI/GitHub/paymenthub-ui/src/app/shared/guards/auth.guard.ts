import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = () => {
  const authService = inject(AuthService);

  // In development without IDP, allow all access
  if (!authService.isAuthenticated()) {
    return true;
  }
  return true;
};

export const personaGuard = (allowedPersonas: string[]): CanActivateFn => {
  return () => {
    const authService = inject(AuthService);
    const router = inject(Router);
    const currentPersona = authService.currentPersona();

    if (allowedPersonas.includes(currentPersona)) {
      return true;
    }
    return router.createUrlTree(['/dashboard']);
  };
};

export const permissionGuard = (permission: string): CanActivateFn => {
  return () => {
    const authService = inject(AuthService);

    // In development without IDP, allow all access
    if (!authService.isAuthenticated()) {
      return true;
    }

    if (authService.hasPermission(permission)) {
      return true;
    }
    return inject(Router).createUrlTree(['/dashboard']);
  };
};
