import { Component, inject } from '@angular/core';
import { ConnectionService } from '../../services/connection.service';

@Component({
  selector: 'app-offline-banner',
  standalone: true,
  template: `
    @if (connectionService.isOffline()) {
      <div class="offline-banner" role="alert" aria-live="assertive">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
          <path d="M8 1a7 7 0 100 14A7 7 0 008 1zm0 10.5a.75.75 0 110-1.5.75.75 0 010 1.5zM8.75 8a.75.75 0 01-1.5 0V4.5a.75.75 0 011.5 0V8z" fill="currentColor"/>
        </svg>
        <span>You are offline. Some features may be unavailable.</span>
      </div>
    }
  `,
  styles: [`
    .offline-banner {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 1rem;
      background: var(--warning, #f59e0b);
      color: #000;
      font-size: 0.8125rem;
      font-weight: 500;
      z-index: 9999;
    }
  `]
})
export class OfflineBannerComponent {
  readonly connectionService = inject(ConnectionService);
}
