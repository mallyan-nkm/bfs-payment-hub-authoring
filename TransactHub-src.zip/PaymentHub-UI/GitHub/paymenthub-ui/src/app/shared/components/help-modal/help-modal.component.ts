import { Component, Output, EventEmitter, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Shortcut { keys: string[]; desc: string; }
interface ShortcutGroup { label: string; shortcuts: Shortcut[]; }

@Component({
  selector: 'app-help-modal',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './help-modal.component.html',
  styleUrls: ['./help-modal.component.scss'],
})
export class HelpModalComponent {
  @Output() close = new EventEmitter<void>();

  readonly groups: ShortcutGroup[] = [
    {
      label: 'Navigation',
      shortcuts: [
        { keys: ['Cmd', 'K'],       desc: 'Open global search' },
        { keys: ['G', 'D'],         desc: 'Go to Dashboard' },
        { keys: ['G', 'Q'],         desc: 'Go to Payment Queues' },
        { keys: ['G', 'A'],         desc: 'Go to Approvals' },
        { keys: ['G', 'E'],         desc: 'Go to Exceptions' },
        { keys: ['G', 'R'],         desc: 'Go to Reports' },
        { keys: ['G', 'N'],         desc: 'New Payment wizard' },
      ],
    },
    {
      label: 'Queue & Tables',
      shortcuts: [
        { keys: ['↑', '↓'],         desc: 'Navigate rows' },
        { keys: ['Enter'],           desc: 'Open selected item' },
        { keys: ['Esc'],             desc: 'Close panel / dismiss' },
        { keys: ['Shift', 'A'],      desc: 'Select all visible rows' },
        { keys: ['Shift', 'C'],      desc: 'Clear selection' },
        { keys: ['E'],               desc: 'Quick escalate selected' },
      ],
    },
    {
      label: 'Search',
      shortcuts: [
        { keys: ['Cmd', 'K'],        desc: 'Focus search / open panel' },
        { keys: ['↑', '↓'],          desc: 'Navigate results' },
        { keys: ['Enter'],            desc: 'Navigate to result' },
        { keys: ['Esc'],              desc: 'Close search panel' },
      ],
    },
    {
      label: 'Actions',
      shortcuts: [
        { keys: ['Cmd', 'S'],        desc: 'Save current form / draft' },
        { keys: ['Cmd', 'Z'],        desc: 'Undo last action' },
        { keys: ['Cmd', 'Shift', 'N'], desc: 'New payment (anywhere)' },
        { keys: ['?'],               desc: 'Open this help panel' },
      ],
    },
  ];

  @HostListener('document:keydown', ['$event'])
  onKey(e: KeyboardEvent): void {
    if (e.key === 'Escape') this.close.emit();
  }
}
