import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="es">
      <div class="es__icon">
        <svg [attr.width]="40" [attr.height]="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" [attr.stroke-width]="1.5">
          <path [attr.d]="iconPath"></path>
        </svg>
      </div>
      <div class="es__title">{{ title }}</div>
      <div class="es__message" *ngIf="message">{{ message }}</div>
      <button class="es__cta" *ngIf="ctaLabel" (click)="ctaClick.emit()">{{ ctaLabel }}</button>
    </div>
  `,
  styles: [`
    :host { display: flex; justify-content: center; align-items: center; padding: 48px 16px; }
    .es { display: flex; flex-direction: column; align-items: center; gap: 8px; max-width: 320px; text-align: center; }
    .es__icon { width: 64px; height: 64px; border-radius: 50%; background: var(--bg-3); border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; color: var(--text-3); margin-bottom: 4px; }
    .es__title { font-size: 13px; font-weight: 600; color: var(--text-1); }
    .es__message { font-size: 12px; color: var(--text-3); line-height: 1.5; }
    .es__cta { margin-top: 8px; padding: 7px 18px; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; font-size: 12px; font-weight: 500; color: var(--accent); cursor: pointer; font-family: inherit; transition: all 0.12s; &:hover { border-color: var(--accent); background: rgba(76,158,255,0.08); } }
  `],
})
export class EmptyStateComponent {
  @Input() title = 'No items found';
  @Input() message = '';
  @Input() ctaLabel = '';
  @Input() iconPath = 'M3 7h18M3 12h18M3 17h18';
  @Output() ctaClick = new EventEmitter<void>();
}
