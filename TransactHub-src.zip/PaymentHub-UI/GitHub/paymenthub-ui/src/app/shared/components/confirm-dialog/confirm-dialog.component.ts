import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmService, ConfirmOptions } from '../../services/confirm.service';

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss'],
})
export class ConfirmDialogComponent {
  constructor(public confirmSvc: ConfirmService) {}
  get state() { return this.confirmSvc.state$; }
  confirm()  { this.confirmSvc.respond(true); }
  cancel()   { this.confirmSvc.respond(false); }
}
