import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface PageEvent {
  page: number;
  pageSize: number;
}

@Component({
  selector: 'app-pagination',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <footer class="pg" *ngIf="totalItems > 0" role="navigation" aria-label="Table pagination">
      <span class="pg__info">
        Showing {{ rangeStart }}–{{ rangeEnd }} of {{ totalItems | number }}
      </span>

      <div class="pg__controls">
        <label class="pg__size-label" for="pg-page-size">Rows:</label>
        <select id="pg-page-size" class="pg__size-select"
          [ngModel]="pageSize" (ngModelChange)="onPageSizeChange($event)">
          <option *ngFor="let ps of pageSizeOptions" [value]="ps">{{ ps }}</option>
        </select>

        <button class="pg__btn" (click)="goToPage(1)"
          [disabled]="currentPage === 1" aria-label="First page">«</button>
        <button class="pg__btn" (click)="goToPage(currentPage - 1)"
          [disabled]="currentPage === 1" aria-label="Previous page">‹</button>

        <ng-container *ngFor="let p of pageNumbers">
          <span *ngIf="p === -1" class="pg__ellipsis" aria-hidden="true">…</span>
          <button *ngIf="p !== -1" class="pg__btn"
            [class.pg__btn--active]="p === currentPage"
            (click)="goToPage(p)"
            [attr.aria-current]="p === currentPage ? 'page' : null"
            [attr.aria-label]="'Page ' + p">
            {{ p }}
          </button>
        </ng-container>

        <button class="pg__btn" (click)="goToPage(currentPage + 1)"
          [disabled]="currentPage === totalPages" aria-label="Next page">›</button>
        <button class="pg__btn" (click)="goToPage(totalPages)"
          [disabled]="currentPage === totalPages" aria-label="Last page">»</button>
      </div>
    </footer>
  `,
  styles: [`
    .pg {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem 0.75rem;
      border-top: 1px solid var(--border);
      background: var(--bg-1);
      font-size: 0.75rem;
      color: var(--text-2);
      flex-shrink: 0;
    }
    .pg__info { white-space: nowrap; }
    .pg__controls { display: flex; align-items: center; gap: 0.25rem; }
    .pg__size-label { margin-right: 0.25rem; color: var(--text-3); }
    .pg__size-select {
      padding: 0.125rem 0.375rem;
      background: var(--bg-2);
      border: 1px solid var(--border);
      border-radius: 4px;
      color: var(--text-1);
      font-size: 0.75rem;
      margin-right: 0.5rem;
    }
    .pg__btn {
      min-width: 1.5rem;
      height: 1.5rem;
      padding: 0 0.375rem;
      border: 1px solid var(--border);
      border-radius: 4px;
      background: var(--bg-2);
      color: var(--text-1);
      font-size: 0.75rem;
      cursor: pointer;
      transition: background 0.1s, border-color 0.1s;
    }
    .pg__btn:hover:not(:disabled) { background: var(--bg-3); border-color: var(--accent); }
    .pg__btn:disabled { opacity: 0.4; cursor: not-allowed; }
    .pg__btn--active { background: var(--accent); color: #fff; border-color: var(--accent); }
    .pg__ellipsis { padding: 0 0.25rem; color: var(--text-3); }
  `]
})
export class PaginationComponent implements OnChanges {
  @Input() currentPage = 1;
  @Input() pageSize = 25;
  @Input() totalItems = 0;
  @Input() pageSizeOptions: number[] = [10, 25, 50, 100];

  @Output() pageChange = new EventEmitter<PageEvent>();

  totalPages = 1;
  pageNumbers: number[] = [];

  ngOnChanges(): void {
    this.totalPages = Math.max(1, Math.ceil(this.totalItems / this.pageSize));
    if (this.currentPage > this.totalPages) this.currentPage = this.totalPages;
    this.pageNumbers = this.computePageNumbers();
  }

  get rangeStart(): number {
    return this.totalItems === 0 ? 0 : (this.currentPage - 1) * this.pageSize + 1;
  }

  get rangeEnd(): number {
    return Math.min(this.currentPage * this.pageSize, this.totalItems);
  }

  goToPage(p: number): void {
    if (p < 1 || p > this.totalPages || p === this.currentPage) return;
    this.currentPage = p;
    this.pageChange.emit({ page: this.currentPage, pageSize: this.pageSize });
  }

  onPageSizeChange(newSize: string | number): void {
    this.pageSize = +newSize;
    this.currentPage = 1;
    this.totalPages = Math.max(1, Math.ceil(this.totalItems / this.pageSize));
    this.pageNumbers = this.computePageNumbers();
    this.pageChange.emit({ page: 1, pageSize: this.pageSize });
  }

  private computePageNumbers(): number[] {
    const total = this.totalPages;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: number[] = [1];
    if (this.currentPage > 3) pages.push(-1);
    for (let p = Math.max(2, this.currentPage - 1); p <= Math.min(total - 1, this.currentPage + 1); p++) {
      pages.push(p);
    }
    if (this.currentPage < total - 2) pages.push(-1);
    pages.push(total);
    return pages;
  }
}
