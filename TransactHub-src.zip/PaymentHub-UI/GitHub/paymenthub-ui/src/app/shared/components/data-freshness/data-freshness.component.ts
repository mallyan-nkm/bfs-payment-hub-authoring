import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-data-freshness',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="df">
      <div class="df__dot" [class.df__dot--stale]="isStale"></div>
      <span class="df__label">{{ label }}</span>
      <button class="df__refresh" (click)="refresh.emit()" title="Refresh data">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <polyline points="23 4 23 10 17 10"></polyline>
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
        </svg>
      </button>
    </div>
  `,
  styles: [`
    .df { display: flex; align-items: center; gap: 6px; font-size: 10px; color: var(--text-3); font-family: 'IBM Plex Mono', monospace; }
    .df__dot { width: 6px; height: 6px; border-radius: 50%; background: var(--success); flex-shrink: 0; animation: dfPulse 2s infinite; &--stale { background: var(--warning); animation: none; } }
    .df__label { white-space: nowrap; }
    .df__refresh { background: transparent; border: none; color: var(--text-3); cursor: pointer; padding: 2px; display: flex; align-items: center; &:hover { color: var(--accent); } svg { transition: transform 0.3s; } &:hover svg { transform: rotate(180deg); } }
    @keyframes dfPulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }
  `],
})
export class DataFreshnessComponent implements OnInit, OnDestroy {
  @Input() lastUpdated: Date = new Date();
  @Output() refresh = new EventEmitter<void>();

  label = 'Just updated';
  isStale = false;
  private timer?: ReturnType<typeof setInterval>;

  ngOnInit(): void {
    this.tick();
    this.timer = setInterval(() => this.tick(), 10_000);
  }

  ngOnDestroy(): void { if (this.timer) clearInterval(this.timer); }

  private tick(): void {
    const secs = Math.floor((Date.now() - this.lastUpdated.getTime()) / 1000);
    this.isStale = secs > 90;
    if (secs < 10)  this.label = 'Just updated';
    else if (secs < 60)  this.label = `${secs}s ago`;
    else if (secs < 3600) this.label = `${Math.floor(secs/60)}m ago`;
    else this.label = `${Math.floor(secs/3600)}h ago`;
  }
}
