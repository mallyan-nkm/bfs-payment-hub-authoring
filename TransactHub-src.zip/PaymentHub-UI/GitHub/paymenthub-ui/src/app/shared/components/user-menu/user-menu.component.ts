import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { UserPersona } from '../../types';
import { ToastService } from '../../services/toast.service';

const PERSONAS = [
  { id: UserPersona.OPERATOR,           label: 'Ops Operator',        tag: 'OPS'    },
  { id: UserPersona.MANAGER,            label: 'Ops Manager',         tag: 'MGR'    },
  { id: UserPersona.EXECUTIVE,          label: 'Executive',           tag: 'EXEC'   },
  { id: UserPersona.RISK_OFFICER,       label: 'Risk Officer',        tag: 'RISK'   },
  { id: UserPersona.COMPLIANCE_OFFICER, label: 'Compliance Officer',  tag: 'COMP'   },
  { id: UserPersona.ADMINISTRATOR,      label: 'Administrator',       tag: 'ADMIN'  },
];

@Component({
  selector: 'app-user-menu',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.scss'],
})
export class UserMenuComponent {
  @Output() close = new EventEmitter<void>();

  readonly personas = PERSONAS;
  activePersona = PERSONAS[0];

  username = 'Ahmed Al Zaabi';
  email    = 'ahmed.zaabi@bank.ae';
  mfa      = true;
  sessionStart = new Date(Date.now() - 47 * 60 * 1000);

  constructor(private toast: ToastService, private router: Router) {}

  switchPersona(p: typeof PERSONAS[0]): void {
    this.activePersona = p;
    this.toast.info('Persona switched', `Now viewing as ${p.label}`);
    this.close.emit();
  }

  logout(): void {
    this.toast.warning('Session ended', 'You have been logged out');
    this.close.emit();
  }

  get sessionAge(): string {
    const mins = Math.floor((Date.now() - this.sessionStart.getTime()) / 60000);
    return mins < 60 ? `${mins}m` : `${Math.floor(mins/60)}h ${mins%60}m`;
  }

  get initials(): string {
    return this.username.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }
}
