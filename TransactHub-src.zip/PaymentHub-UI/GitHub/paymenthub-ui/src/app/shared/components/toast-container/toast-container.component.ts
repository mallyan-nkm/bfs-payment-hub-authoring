import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { ToastMessage } from '../../types';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-toast-container',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './toast-container.component.html',
  styleUrls: ['./toast-container.component.scss']
})
export class ToastContainerComponent implements OnInit, OnDestroy {
  toasts: ToastMessage[] = [];
  private sub?: Subscription;

  constructor(private toastSvc: ToastService) {}

  ngOnInit(): void {
    this.sub = this.toastSvc.toasts$.subscribe(t => this.toasts = t);
  }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  dismiss(id: string): void { this.toastSvc.dismiss(id); }

  trackById(_: number, t: ToastMessage): string { return t.id; }
}
