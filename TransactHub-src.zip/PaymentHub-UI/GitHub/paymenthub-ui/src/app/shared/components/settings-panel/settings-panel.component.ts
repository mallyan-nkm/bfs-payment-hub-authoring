import { Component, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { ThemeService, Theme } from '../../services/theme.service';

interface ThemeOption { id: Theme; label: string; desc: string; icon: string; }
interface RefreshOption { label: string; value: number; }

@Component({
  selector: 'app-settings-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './settings-panel.component.html',
  styleUrls: ['./settings-panel.component.scss'],
})
export class SettingsPanelComponent implements OnInit, OnDestroy {
  @Output() close = new EventEmitter<void>();

  readonly themes: ThemeOption[] = [
    { id: 'dark',           label: 'Dark',           desc: 'Default dark interface',        icon: 'M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z' },
    { id: 'dark-navy',      label: 'Dark Navy',      desc: 'Teal-accent operational',       icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z' },
    { id: 'dark-midnight',  label: 'Dark Midnight',  desc: 'Deep blue banking ops',         icon: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z' },
    { id: 'light',          label: 'Light',          desc: 'High-brightness interface',     icon: 'M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42M12 5a7 7 0 1 0 0 14A7 7 0 0 0 12 5z' },
    { id: 'high-contrast',  label: 'High Contrast',  desc: 'Maximum readability',           icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18V4a8 8 0 0 1 0 16z' },
  ];

  readonly refreshOptions: RefreshOption[] = [
    { label: '15 seconds', value: 15 },
    { label: '30 seconds', value: 30 },
    { label: '1 minute',   value: 60 },
    { label: '5 minutes',  value: 300 },
  ];

  currentTheme: Theme = 'dark';
  refreshInterval = 30;
  defaultRail = 'ALL';
  showTimezone = true;
  compactMode = false;

  private themeSub!: Subscription;

  constructor(private themeSvc: ThemeService) {}

  ngOnInit(): void {
    this.themeSub = this.themeSvc.theme$.subscribe(t => this.currentTheme = t);
  }

  ngOnDestroy(): void {
    this.themeSub.unsubscribe();
  }

  setTheme(t: Theme): void { this.themeSvc.set(t); }
}
