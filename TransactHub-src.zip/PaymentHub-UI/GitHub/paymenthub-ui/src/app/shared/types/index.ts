/**
 * Shared Types and Interfaces for PaymentHub Operations Console
 */

// ─── Pagination ─────────────────────────────────────────────────────────────

/** Standard paginated API response envelope */
export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

/** Request params for paginated endpoints */
export interface PaginationParams {
  page: number;
  pageSize: number;
  sortColumn?: string;
  sortDirection?: 'asc' | 'desc';
  search?: string;
}

// ─── Core Enums ─────────────────────────────────────────────────────────────

export enum Rail {
  UAEFTS = 'UAEFTS',
  IPI = 'IPI',
  IPP = 'IPP',
  WPS = 'WPS',
  SWIFT = 'SWIFT',
  ALL = 'ALL'
}

export enum UserPersona {
  OPERATOR = 'OPERATOR',
  MANAGER = 'MANAGER',
  EXECUTIVE = 'EXECUTIVE',
  ADMINISTRATOR = 'ADMINISTRATOR',
  RISK_OFFICER = 'RISK_OFFICER',
  COMPLIANCE_OFFICER = 'COMPLIANCE_OFFICER'
}

export enum NavigationSection {
  DASHBOARD = 'dashboard',
  OPERATIONS = 'operations',
  APPROVAL = 'approval',
  EXCEPTIONS = 'exceptions',
  REPORTING = 'reporting',
  ADMIN = 'admin'
}

export enum StatusIndicator {
  OPERATIONAL = 'operational',
  DEGRADED = 'degraded',
  OUTAGE = 'outage',
  UNKNOWN = 'unknown'
}

export enum BadgeSeverity {
  URGENT = 'urgent',
  WARNING = 'warning',
  INFO = 'info'
}

export enum ExceptionSeverity {
  CRITICAL = 'critical',
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low'
}

// ─── Phase 1 Interfaces ──────────────────────────────────────────────────────

export interface NavigationItem {
  id: string;
  label: string;
  icon: string;
  route: string;
  section: NavigationSection;
  badge?: NavigationBadge;
  children?: NavigationItem[];
  hidden?: boolean;
  permissions?: string[];
}

export interface NavigationBadge {
  count: number;
  severity: BadgeSeverity;
}

export interface UserSession {
  userId: string;
  username: string;
  email: string;
  avatar?: string;
  persona: UserPersona;
  persona_display: string;
  permissions: string[];
  session_start: Date;
  session_timeout: number;
  last_activity: Date;
  mfa_verified: boolean;
}

export interface RailHealth {
  rail: Rail;
  status: StatusIndicator;
  throughput: number;
  throughputTypical?: number;
  latency_p50?: number;
  latency_p95?: number;
  latency_p99?: number;
  error_rate?: number;
  open_exceptions?: number;
  last_updated: Date;
}

export interface KPIMetric {
  id: string;
  label: string;
  value: string | number;
  delta?: number;
  deltaType?: 'up' | 'down' | 'neutral';
  unit?: string;
  color?: 'accent' | 'success' | 'warning' | 'danger' | 'info' | 'purple' | 'teal';
}

export interface Breadcrumb {
  label: string;
  route?: string;
  current?: boolean;
}

export interface ActionPanelContext {
  title: string;
  description?: string;
  actions: ActionItem[];
  quickInfo?: Record<string, any>;
}

export interface ActionItem {
  id: string;
  label: string;
  icon?: string;
  type: 'primary' | 'secondary' | 'danger';
  disabled?: boolean;
  loading?: boolean;
}

export interface LayoutState {
  sidebarCollapsed: boolean;
  actionPanelCollapsed: boolean;
  activeRail: Rail;
  activeNavSection?: NavigationSection;
  breadcrumbs?: Breadcrumb[];
}

// ─── Phase 2 — Dashboard Data Models ────────────────────────────────────────

export interface MessageTypeStatus {
  messageType: string;          // e.g. 'CB103', 'MT103', 'SIF'
  label: string;                // display name e.g. 'CB103 Credit Transfer'
  direction: 'outbound' | 'inbound';
  total: number;
  sanctionCompleted: number;
  sentToNetwork: number | null; // null = N/A (inbound doesn't "send" to network)
  ackReceived: number | null;   // null = N/A for inbound
  nakReceived: number;
  confirmed: number;            // settled / posted / credited / confirmed
  returned: number;
  failed: number;
}

export interface DashboardKPI {
  id: string;
  label: string;
  value: number | string;
  rawValue?: number;
  rawDecimals?: number;
  unit?: string;
  delta?: number;
  deltaType?: 'up' | 'down' | 'neutral';
  trend?: number[];
  color?: 'accent' | 'success' | 'warning' | 'danger' | 'info' | 'purple' | 'teal';
  icon?: string;
  subtitle?: string;
  clickRoute?: string;
}

export interface ExceptionCount {
  critical: number;
  high: number;
  medium: number;
  low: number;
}

export interface LiveOpsData {
  inFlightCount: number;
  inFlightValue: number;
  inFlightCurrency: string;
  exceptions: ExceptionCount;
  pendingApprovals: number;
  slaCompliance24h: number;
  slaComplianceLastHour: number;
  railHealth: RailHealth[];
  lastUpdated: Date;
}

export interface HourlyVolume {
  hour: number;
  count: number;
}

export interface UaeftsDashboardData {
  cb103OutboundCount: number;
  cb103InboundCount: number;
  cb202Count: number;
  cb202CovCount: number;
  cb101UfpCount: number;
  settlementWindowStatus: 'open' | 'closed' | 'suspended';
  settlementWindowCountdownSec: number;
  cycleProgress: HourlyVolume[];
  cb940IngestStatus: 'ok' | 'pending' | 'failed';
  cb950IngestStatus: 'ok' | 'pending' | 'failed';
  treasuryVolume: number;
  customerVolume: number;
  messageStatus: MessageTypeStatus[];
  kpis: {
    dispatchLatencyMs: number;
    settlementConfirmLatencyMs: number;
    exceptionRate: number;
    recoBreakRate: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface IpiDashboardData {
  volumePerSecond: number;
  volumePerMinute: number;
  subSecondSlaCompliancePct: number;
  aaniAliasResolutionHealth: StatusIndicator;
  copHealth: StatusIndicator;
  hourlyVolume: HourlyVolume[];
  messageStatus: MessageTypeStatus[];
  kpis: {
    throughputPerSec: number;
    latencyP50Ms: number;
    latencyP95Ms: number;
    latencyP99Ms: number;
    instantConfirmRatePct: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface IppDashboardData {
  volumePerSecond: number;
  volumePerMinute: number;
  slaCompliancePct: number;
  hourlyVolume: HourlyVolume[];
  messageStatus: MessageTypeStatus[];
  kpis: {
    throughputPerSec: number;
    latencyP50Ms: number;
    latencyP95Ms: number;
    successRatePct: number;
    pendingCount: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface WpsFile {
  fileType: 'SIF' | 'PIF' | 'DIF' | 'RFA' | 'RTC';
  count: number;
  status: 'processing' | 'completed' | 'failed' | 'pending';
}

export interface WpsRefundFlow {
  flowType: 'RFR' | 'RRI' | 'RRR' | 'DCR' | 'RSU';
  count: number;
  status: 'active' | 'pending' | 'completed';
}

export interface WpsDashboardData {
  activeFiles: WpsFile[];
  refundFlows: WpsRefundFlow[];
  mohreComplianceStatus: 'compliant' | 'non-compliant' | 'pending';
  employerEstablishments: number;
  messageStatus: MessageTypeStatus[];
  kpis: {
    fileCompletionRatePct: number;
    employeeCreditSuccessRatePct: number;
    activeCycles: number;
    failedCredits: number;
    totalEmployeesCredited: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface NostroPosition {
  currency: string;
  balance: number;
  threshold: number;
  status: 'adequate' | 'low' | 'critical';
}

export interface SwiftDashboardData {
  outboundVolume: number;
  inboundVolume: number;
  gpiSubscriptions: number;
  gpiPending: number;
  gpiConfirmed: number;
  fxLegHealth: StatusIndicator;
  nostroCurrencies: NostroPosition[];
  messageStatus: MessageTypeStatus[];
  kpis: {
    gpiComplianceRatePct: number;
    endToEndLatencyMs: number;
    disputeRatePct: number;
    correspondentCount: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface DashboardRefreshConfig {
  autoRefresh: boolean;
  intervalSeconds: number;
  lastRefreshed: Date;
  isPaused: boolean;
}

// ─── Phase 3 — Queue Management ─────────────────────────────────────────────

export enum QueueItemType {
  PAYMENT         = 'PAYMENT',
  RECALL          = 'RECALL',
  RETURN          = 'RETURN',
  EXCEPTION       = 'EXCEPTION',
  APPROVAL        = 'APPROVAL',
  ENQUIRY         = 'ENQUIRY',
  REFUND_REQUEST  = 'REFUND_REQUEST'
}

export enum QueueItemStatus {
  PENDING                  = 'PENDING',
  IN_REVIEW                = 'IN_REVIEW',
  HELD                     = 'HELD',
  ESCALATED                = 'ESCALATED',
  APPROVED                 = 'APPROVED',
  REJECTED                 = 'REJECTED',
  RESOLVED                 = 'RESOLVED',
  REFUND_REQUESTED         = 'REFUND_REQUESTED',
  REFUND_PENDING_RESPONSE  = 'REFUND_PENDING_RESPONSE',
  REFUND_ACCEPTED          = 'REFUND_ACCEPTED',
  REFUND_DECLINED          = 'REFUND_DECLINED',
  REFUND_PARTIAL           = 'REFUND_PARTIAL'
}

export enum QueuePriority {
  CRITICAL = 'CRITICAL',
  HIGH     = 'HIGH',
  NORMAL   = 'NORMAL',
  LOW      = 'LOW'
}

export enum QueueType {
  ALL            = 'ALL',
  PAYMENTS_L1    = 'PAYMENTS_L1',
  PAYMENTS_L2    = 'PAYMENTS_L2',
  COMPLIANCE_L1  = 'COMPLIANCE_L1',
  COMPLIANCE_L2  = 'COMPLIANCE_L2',
  FRAUD_OPS      = 'FRAUD_OPS',
  WPS_OPS        = 'WPS_OPS',
  CORRESPONDENT  = 'CORRESPONDENT',
  INVESTIGATION  = 'INVESTIGATION',
  REFUND_OPS     = 'REFUND_OPS'
}

export type SlaStatus = 'ok' | 'warning' | 'breach';

export interface QueueItem {
  id: string;
  reference: string;
  type: QueueItemType;
  status: QueueItemStatus;
  priority: QueuePriority;
  rail: Rail;
  paymentSubType?: PaymentType;
  amount: number;
  currency: string;
  originatorName: string;
  originatorAccount: string;
  beneficiaryName: string;
  beneficiaryAccount: string;
  counterpartyBic?: string;
  submittedAt: Date;
  updatedAt: Date;
  slaDeadline: Date;
  assignedTo?: string;
  tags: string[];
  isUrgent: boolean;
  ageMinutes: number;
  slaStatus: SlaStatus;
  slaMinutesRemaining: number;
  exceptionCode?: string;
  queueType: QueueType;
  correlationId?: string;
}

export interface QueueFilter {
  search: string;
  rails: Rail[];
  statuses: QueueItemStatus[];
  priorities: QueuePriority[];
  types: QueueItemType[];
  paymentSubTypes: PaymentType[];
  dateFrom: string | null;
  dateTo: string | null;
  amountMin: number | null;
  amountMax: number | null;
  assignedTo: string;
  urgentOnly: boolean;
  slaStatuses: SlaStatus[];
  queueType: QueueType;
  logic: 'AND' | 'OR';
}

export interface QuickFilter {
  id: string;
  label: string;
  count: number;
  filter: Partial<QueueFilter>;
  color: 'accent' | 'warning' | 'danger' | 'info' | 'success';
}

export interface QueueSort {
  column: keyof QueueItem;
  direction: 'asc' | 'desc';
}

export interface QueuePage {
  items: QueueItem[];
  totalCount: number;
  filteredCount: number;
  page: number;
  pageSize: number;
}

export interface BulkAction {
  id: string;
  label: string;
  type: 'primary' | 'secondary' | 'danger';
  requiresConfirmation: boolean;
  requiresReason?: boolean;
}

export interface BulkActionRequest {
  actionId: string;
  itemIds: string[];
  reason?: string;
  refundReasonCode?: RefundReasonCode;
  refundAmount?: number;
}

export interface BulkActionResult {
  actionId: string;
  total: number;
  succeeded: number;
  failed: number;
  errors: { itemId: string; message: string }[];
  bulkRefundCampaignId?: string;
}

export interface SavedFilterSet {
  id: string;
  name: string;
  filter: QueueFilter;
  createdAt: Date;
  isDefault: boolean;
}

export interface QueueTypeTab {
  type: QueueType;
  label: string;
  count: number;
  urgentCount: number;
}

// ─── Phase 4 — Transaction Detail ───────────────────────────────────────────

export type AuditEventType = 'system' | 'user' | 'automated';

export interface AuditEvent {
  id: string;
  timestamp: Date;
  actor: string;
  actorType: AuditEventType;
  action: string;
  description: string;
  previousValue?: string;
  newValue?: string;
}

export interface TransactionComment {
  id: string;
  timestamp: Date;
  author: string;
  body: string;
  isSystem: boolean;
}

export type ComplianceSeverity = 'info' | 'warning' | 'critical';

export interface ComplianceFlag {
  id: string;
  code: string;
  description: string;
  severity: ComplianceSeverity;
  engine: string;
  detectedAt: Date;
  disposition: 'pending' | 'cleared' | 'escalated';
}

export interface RoutingHop {
  step: number;
  system: string;
  status: 'completed' | 'in_progress' | 'pending' | 'failed' | 'skipped';
  enteredAt?: Date;
  exitedAt?: Date;
  latencyMs?: number;
  note?: string;
}

export interface TransactionDetail extends QueueItem {
  originatorBank?: string;
  originatorBic?: string;
  beneficiaryBank?: string;
  purpose?: string;
  remittanceInfo?: string;
  instructedAmount?: number;
  instructedCurrency?: string;
  exchangeRate?: number;
  charges?: 'OUR' | 'BEN' | 'SHA';
  gpiUetr?: string;
  mohreRef?: string;
  // IPI / Aani — CBUAE RPSF fields
  ipiAliasType?: 'mobile' | 'email' | 'emiratesId' | 'tradeLicense' | 'virtualAccount';
  ipiAliasValue?: string;
  endToEndRef?: string;
  // UAEFTS — CBUAE UAEFTS fields
  chargeCode?: 'SLEV' | 'DEBT' | 'CRED' | 'SHAR' | 'SHA' | 'BEN' | 'OUR';
  valueDate?: Date;
  // UAEFTS — additional CBUAE fields
  creditorAgentBic?: string;     // Receiving bank BIC (mandatory for UAEFTS routing)
  debtorAgentBic?: string;       // Sending bank BIC
  categoryPurpose?: string;      // Category purpose (SALA/PENS/TAXS/SUPP/OTHR)
  settlementMethod?: 'RTGS' | 'CLRG';  // CB202=RTGS, CB103=CLRG
  // WPS — MoHRE / CBUAE WPS fields
  employeeEmiratesId?: string;
  employeeBasicSalary?: number;
  employeeAllowance?: number;
  wpsEmployerNumber?: string;
  payPeriod?: string;
  // WPS — MoHRE SIF fields (salary breakdown per WPS Technical Spec v2.x)
  employeeNumber?: string;       // Employer's internal employee ID
  housingAllowance?: number;     // Housing allowance (AED)
  transportAllowance?: number;   // Transport allowance (AED)
  otherAllowance?: number;       // Other allowances (AED)
  grossWage?: number;            // Total gross = basic + all allowances
  daysWorked?: number;           // Actual days worked (partial month)
  daysInPeriod?: number;         // Calendar days in pay period (28/29/30/31)
  salaryType?: 'monthly' | 'daily';
  wpsRecordType?: 'DTL' | 'AJT'; // Detail or Adjustment record
  // Batch header
  batchFileName?: string;
  ftsBatchFileType?: 'SIF' | 'PIF' | 'DIF';
  batchSubType?: 'salary' | 'pension' | 'eosb' | 'allowance';
  batchRecordCount?: number;
  batchLineItems?: BatchLineItem[];
  routingPath: RoutingHop[];
  complianceFlags: ComplianceFlag[];
  fraudScore?: number;
  auditTrail: AuditEvent[];
  comments: TransactionComment[];
  relatedItemIds: string[];
}

export type BatchLineItemStatus = 'processed' | 'failed' | 'pending';

export type BatchLineItemRefundStatus =
  | 'not_requested'
  | 'rfa_pending'
  | 'rfr_sent'
  | 'refund_received'
  | 'refund_declined';

export interface BatchLineItem {
  lineNumber: number;
  employeeName: string;
  emiratesId: string;
  bankName: string;
  iban: string;
  amount: number;
  status: BatchLineItemStatus;
  failureReason?: string;
  employeeNumber?: string;
  basicWage?: number;
  housingAllowance?: number;
  transportAllowance?: number;
  otherAllowance?: number;
  grossWage?: number;
  daysWorked?: number;
  daysInPeriod?: number;
  salaryType?: 'monthly' | 'daily';
  bankCode?: string;
  refundStatus?: BatchLineItemRefundStatus;
  refundRef?: string;
}

export interface BatchSummary {
  totalRecords: number;
  processed: number;
  failed: number;
  pending: number;
  totalAmount: number;
}

export interface DetailActionEvent {
  action: 'approve' | 'reject' | 'hold' | 'release' | 'escalate' | 'assign' | 'comment' | 'resolve' | 'refund';
  itemId: string;
  reason?: string;
  comment?: string;
  assignTo?: string;
}

// ─── Phase 5 — Approval Workflows ───────────────────────────────────────────

export enum ApprovalStatus {
  PENDING_L1     = 'PENDING_L1',
  PENDING_L2     = 'PENDING_L2',
  PENDING_SENIOR = 'PENDING_SENIOR',
  APPROVED       = 'APPROVED',
  REJECTED       = 'REJECTED',
  EXPIRED        = 'EXPIRED',
  DELEGATED      = 'DELEGATED',
}

export type ApprovalLevelFilter = 'ALL' | 'L1' | 'L2' | 'SENIOR' | 'HISTORY';

export interface ApprovalStep {
  level: 1 | 2 | 3;
  levelLabel: string;
  requiredRole: string;
  status: 'pending' | 'approved' | 'rejected' | 'skipped';
  actor?: string;
  decidedAt?: Date;
  reason?: string;
  dueBy: Date;
}

export interface ApprovalWorkflow {
  id: string;
  reference: string;
  type: QueueItemType;
  rail: Rail;
  amount: number;
  currency: string;
  originatorName: string;
  originatorAccount: string;
  beneficiaryName: string;
  beneficiaryAccount: string;
  counterpartyBic?: string;
  submittedBy: string;
  submittedAt: Date;
  updatedAt: Date;
  currentLevel: 1 | 2 | 3;
  totalLevels: 1 | 2 | 3;
  steps: ApprovalStep[];
  approvalStatus: ApprovalStatus;
  priority: QueuePriority;
  slaDeadline: Date;
  slaStatus: SlaStatus;
  slaMinutesRemaining: number;
  tags: string[];
  isUrgent: boolean;
  ruleId: string;
  ruleDescription: string;
  purpose?: string;
  exceptionCode?: string;
  correlationId?: string;
  complianceFlags: ComplianceFlag[];
}

export interface ApprovalSummary {
  pendingL1: number;
  pendingL2: number;
  pendingSenior: number;
  slaBreachCount: number;
  approvedToday: number;
  rejectedToday: number;
  expiredToday: number;
  avgDecisionMinutes: number;
}

export interface ApprovalDecisionRequest {
  workflowId: string;
  decision: 'approve' | 'reject' | 'delegate';
  reason?: string;
  delegateTo?: string;
}

export interface ApprovalPage {
  items: ApprovalWorkflow[];
  totalCount: number;
  filteredCount: number;
  page: number;
  pageSize: number;
}

export interface ApprovalFilter {
  search: string;
  rails: Rail[];
  types: QueueItemType[];
  priorities: QueuePriority[];
  slaStatuses: SlaStatus[];
  amountMin: number | null;
  amountMax: number | null;
  dateFrom: string | null;
  dateTo: string | null;
  urgentOnly: boolean;
  levelFilter: ApprovalLevelFilter;
}

export interface ApprovalSort {
  column: keyof ApprovalWorkflow;
  direction: 'asc' | 'desc';
}

// ─── Phase 6 — Reporting & Analytics ────────────────────────────────────────

export type DatePreset = 'today' | 'yesterday' | 'last7d' | 'last30d' | 'custom';
export type ReportGroupBy = 'hour' | 'day' | 'week';
export type ReportType = 'volume' | 'sla' | 'exceptions' | 'approvals';

export interface ReportFilter {
  preset: DatePreset;
  dateFrom: string;
  dateTo: string;
  rails: Rail[];
  groupBy: ReportGroupBy;
}

export interface VolumePoint {
  label: string;
  total: number;
  byRail: Partial<Record<Rail, number>>;
}

export interface SlaPoint {
  label: string;
  compliancePct: number;
  breachCount: number;
  warningCount: number;
  okCount: number;
}

export interface ExceptionBreakdown {
  code: string;
  description: string;
  count: number;
  pct: number;
  openCount: number;
  avgResolutionMinutes: number;
  trend: 'up' | 'down' | 'flat';
}

export interface RailVolumeStat {
  rail: Rail;
  count: number;
  value: number;
  pct: number;
  successRatePct: number;
}

export interface RailSlaStat {
  rail: Rail;
  compliancePct: number;
  breachCount: number;
  warningCount: number;
  avgResolutionMinutes: number;
}

export interface ApprovalStat {
  level: string;
  pendingCount: number;
  approvedCount: number;
  rejectedCount: number;
  expiredCount: number;
  avgDecisionMinutes: number;
  slaCompliancePct: number;
}

export interface VolumeReport {
  points: VolumePoint[];
  totalCount: number;
  totalValue: number;
  peakLabel: string;
  peakCount: number;
  avgPerInterval: number;
  byRail: RailVolumeStat[];
}

export interface SlaReport {
  points: SlaPoint[];
  overallPct: number;
  totalBreaches: number;
  totalWarnings: number;
  avgResolutionMinutes: number;
  byRail: RailSlaStat[];
}

export interface ExceptionReport {
  byType: ExceptionBreakdown[];
  totalOpen: number;
  resolvedToday: number;
  mttrMinutes: number;
  byRail: { rail: Rail; count: number; resolvedPct: number }[];
}

export interface ApprovalReport {
  byLevel: ApprovalStat[];
  totalProcessed: number;
  overallApprovalRatePct: number;
  totalPending: number;
  slaBreachCount: number;
}

// ─── Phase 8 — Exception Management ─────────────────────────────────────────

export enum ExceptionStatus {
  OPEN          = 'OPEN',
  IN_TRIAGE     = 'IN_TRIAGE',
  HELD          = 'HELD',
  ESCALATED     = 'ESCALATED',
  RESOLVED      = 'RESOLVED',
  AUTO_RESOLVED = 'AUTO_RESOLVED',
  REJECTED      = 'REJECTED'
}

export enum ExceptionQueue {
  ALL           = 'ALL',
  PAYMENTS_L1   = 'PAYMENTS_L1',
  PAYMENTS_L2   = 'PAYMENTS_L2',
  COMPLIANCE_L1 = 'COMPLIANCE_L1',
  COMPLIANCE_L2 = 'COMPLIANCE_L2',
  FRAUD_OPS     = 'FRAUD_OPS',
  RECONCILIATION = 'RECONCILIATION',
  WPS_OPS       = 'WPS_OPS',
  CORRESPONDENT = 'CORRESPONDENT',
  INVESTIGATION = 'INVESTIGATION'
}

export interface ExceptionItem {
  id: string;
  reference: string;
  exceptionCode: string;
  description: string;
  module: string;
  severity: ExceptionSeverity;
  status: ExceptionStatus;
  queue: ExceptionQueue;
  rail: Rail;
  ageMinutes: number;
  createdAt: Date;
  updatedAt: Date;
  slaDeadline: Date;
  slaStatus: SlaStatus;
  slaMinutesRemaining: number;
  assignedTo?: string;
  originatorName: string;
  beneficiaryName?: string;
  amount?: number;
  currency?: string;
  relatedRef?: string;
  resolutionPath: string;
  resolutionCode?: string;
  resolvedAt?: Date;
  resolvedBy?: string;
  isAutoResolvable: boolean;
  complianceFlags: ComplianceFlag[];
  auditTrail: AuditEvent[];
  comments: TransactionComment[];
}

export interface ExceptionFilter {
  search: string;
  queue: ExceptionQueue;
  severities: ExceptionSeverity[];
  statuses: ExceptionStatus[];
  rails: Rail[];
  slaStatuses: SlaStatus[];
}

export interface ExceptionSort {
  column: keyof ExceptionItem;
  direction: 'asc' | 'desc';
}

export interface ExceptionPage {
  items: ExceptionItem[];
  totalCount: number;
  filteredCount: number;
  page: number;
  pageSize: number;
}

export interface ExceptionQueueTab {
  queue: ExceptionQueue;
  label: string;
  count: number;
  criticalCount: number;
}

export interface ExceptionSummary {
  totalOpen: number;
  critical: number;
  high: number;
  slaBreaches: number;
  resolvedToday: number;
  autoResolvedToday: number;
  avgResolutionMinutes: number;
  escalationRate: number;
}

export interface ExceptionTrendPoint {
  label: string;
  opened: number;
  resolved: number;
  escalated: number;
}

// ─── Phase 9 — Notifications & Alerts ────────────────────────────────────────

export type NotificationCategory = 'exception' | 'approval' | 'payment' | 'system' | 'compliance';
export type NotificationPriority = 'critical' | 'high' | 'normal';

export interface AppNotification {
  id: string;
  category: NotificationCategory;
  priority: NotificationPriority;
  title: string;
  body: string;
  timestamp: Date;
  isRead: boolean;
  route?: string;
  railRef?: Rail;
}

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastMessage {
  id: string;
  type: ToastType;
  title: string;
  body?: string;
  durationMs?: number;
}

// ─── Search & Discovery (Phase 10 / FSD §19) ─────────────────────────────────

export type SearchCategory = 'transaction' | 'exception' | 'approval' | 'customer' | 'counterparty' | 'report';

export interface SearchResult {
  id: string;
  category: SearchCategory;
  title: string;
  subtitle: string;
  meta?: string;
  route: string;
  rail?: Rail;
  status?: string;
  amount?: string;
}

export interface SearchResultGroup {
  category: SearchCategory;
  label: string;
  icon: string;
  results: SearchResult[];
}

export interface RecentSearch {
  query: string;
  timestamp: Date;
}

// ─── Transaction Initiation (Phase 11 / FSD §13) ─────────────────────────────

export type TransactionFormStep = 'rail' | 'details' | 'preview' | 'submitted';

export type PaymentType =
  | 'cb103'        // UAEFTS CB103 Credit Transfer
  | 'cb202'        // UAEFTS CB202 High Value
  | 'ufp'          // UAEFTS UFP Urgent
  | 'uaefts-bulk'  // UAEFTS FTS Bulk Batch
  | 'ipi-instant'  // IPI Instant Credit
  | 'ipi-alias'    // IPI Alias-Based (Aani)
  | 'ipp-card'     // IPP Card / Merchant
  | 'wps-single'   // WPS Individual
  | 'wps-batch'    // WPS Salary Batch File
  | 'wps-pension'  // WPS Pension / EOSB Batch File
  | 'mt103'        // SWIFT MT103 Customer Transfer
  | 'mt202';       // SWIFT MT202 Bank Transfer

export interface PaymentTypeOption {
  type: PaymentType;
  label: string;
  description: string;
  maxAmount?: number;   // AED equivalent limit
  currency?: string;    // locked currency if applicable
}

export interface PaymentFormData {
  rail: Rail | null;
  paymentType: PaymentType | null;
  // Originator
  originatorIban: string;
  originatorName: string;
  originatorBank: string;
  // Beneficiary
  beneficiaryIban: string;
  beneficiaryName: string;
  beneficiaryBank: string;
  beneficiaryBic: string;
  beneficiaryAddress: string;
  beneficiaryMobile: string;           // IPI alias value (mobile / email / Emirates ID)
  // IPI / Aani — CBUAE Retail Payment Services Framework
  ipiAliasType?: 'mobile' | 'email' | 'emiratesId' | 'tradeLicense' | 'virtualAccount';  // Aani alias resolution type
  endToEndRef?: string;                // E2E traceability reference (IPI + UAEFTS mandate)
  // UAEFTS — charge instruction per CBUAE UAEFTS rules
  chargeCode?: 'SLEV' | 'DEBT' | 'CRED' | 'SHAR' | 'SHA' | 'BEN' | 'OUR';
  // UAEFTS — additional CBUAE fields
  creditorAgentBic?: string;
  categoryPurpose?: string;
  settlementMethod?: 'RTGS' | 'CLRG';
  // WPS Single — MoHRE / CBUAE WPS mandatory fields
  employeeEmiratesId?: string;         // Employee Emirates ID or Passport No.
  employeeBasicSalary?: string;        // Basic salary component (AED)
  employeeAllowance?: string;          // Total allowances component (AED) — legacy field kept for backward compat
  // WPS — MoHRE SIF fields
  employeeNumber?: string;
  housingAllowance?: string;
  transportAllowance?: string;
  otherAllowance?: string;
  daysWorked?: string;
  daysInPeriod?: string;
  salaryType?: 'monthly' | 'daily';
  // Transfer
  amount: string;
  currency: string;
  valueDate: string;
  priority: 'URGENT' | 'NORMAL';
  purposeCode: string;
  remittanceInfo: string;
  // WPS
  employerId: string;                  // MOL Employer ID
  wpsEmployerNumber?: string;          // MoHRE WPS Employer Registration Number
  payPeriod: string;
  // Batch upload
  batchFileName?: string;
  batchRecordCount?: number;
  batchSubType?: 'salary' | 'pension' | 'eosb' | 'allowance';
  ftsBatchFileType?: 'SIF' | 'PIF' | 'DIF';  // FTS file type per CBUAE UAEFTS spec
  // Draft
  draftSavedAt?: Date;
}

export interface FormFieldError {
  field: string;
  message: string;
}

export interface ApprovalTier {
  step: number;
  label: string;
  approvers: string[];
  required: boolean;
  reason: string;
}

export interface PaymentFeeEstimate {
  fee: number;
  currency: string;
  fxRate?: string;
  settlementTime: string;
  settlementWindow?: string;
}

export interface SubmittedTransaction {
  reference: string;
  status: string;
  submittedAt: Date;
  estimatedSettlement: string;
  approvalRequired: boolean;
}

// ─── Refund Request (all rails) ──────────────────────────────────────────────

export enum RefundReasonCode {
  DUPL = 'DUPL',  // Duplicate payment
  FRAD = 'FRAD',  // Fraud / unauthorised
  TECH = 'TECH',  // Technical / processing error
  CUST = 'CUST',  // Customer request
  CXLD = 'CXLD',  // Cancellation
  NARR = 'NARR',  // See narrative (free text)
}

export const REFUND_REASON_LABELS: Record<RefundReasonCode, string> = {
  [RefundReasonCode.DUPL]: 'Duplicate Payment',
  [RefundReasonCode.FRAD]: 'Fraud / Unauthorised',
  [RefundReasonCode.TECH]: 'Technical / Processing Error',
  [RefundReasonCode.CUST]: 'Customer Request',
  [RefundReasonCode.CXLD]: 'Cancellation',
  [RefundReasonCode.NARR]: 'See Narrative',
};

export type RefundRequestStatus =
  | 'DRAFT'
  | 'PENDING_APPROVAL'
  | 'APPROVED'
  | 'SENT'
  | 'ACCEPTED'
  | 'DECLINED'
  | 'PARTIAL'
  | 'CANCELLED';

export interface RefundEligibility {
  isEligible: boolean;
  ineligibilityReason?: string;
  windowExpiry?: Date;
  windowLabel?: string;
  requiresBeneficiaryConsent: boolean;
  requiresCounterpartyAction: boolean;
  routedVia?: Rail;
  routingNote?: string;
  approvalTiersRequired: ApprovalTier[];
}

export interface RefundRequest {
  id: string;
  reference: string;
  originalPaymentRef: string;
  originalItemId: string;
  rail: Rail;
  paymentSubType?: PaymentType;
  effectiveRail: Rail;
  reasonCode: RefundReasonCode;
  narrativeReason?: string;
  requestedAmount: number;
  originalAmount: number;
  currency: string;
  status: RefundRequestStatus;
  raisedBy: string;
  raisedAt: Date;
  approvalStatus?: ApprovalStatus;
  counterpartyRef?: string;
  counterpartyDeadline?: Date;
  counterpartyResponse?: 'accepted' | 'declined' | 'partial' | 'pending';
  bulkCampaignId?: string;
  beneficiaryConsentRequired: boolean;
  consentCaseRef?: string;
  fxDelta?: number;
  resolvedAt?: Date;
  auditTrail: AuditEvent[];
}

export interface BulkRefundCampaign {
  campaignId: string;
  raisedBy: string;
  raisedAt: Date;
  reasonCode: RefundReasonCode;
  narrativeReason?: string;
  totalItems: number;
  totalAmount: number;
  currency: string;
  approvalStatus: ApprovalStatus;
  approvalTiersRequired: ApprovalTier[];
  items: {
    itemId: string;
    originalRef: string;
    refundRequestRef: string;
    status: RefundRequestStatus;
    amount: number;
    eligibilityReason?: string;
  }[];
  counterpartyProgress: {
    responded: number;
    pending: number;
    accepted: number;
    declined: number;
  };
  slaDeadline: Date;
  createdAt: Date;
}
