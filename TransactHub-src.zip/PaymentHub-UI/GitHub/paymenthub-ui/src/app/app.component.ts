import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { ThemeService } from './shared/services/theme.service';
import { HeaderComponent } from './components/layout/header/header.component';
import { SidebarComponent } from './components/layout/sidebar/sidebar.component';
import { MainPanelComponent } from './components/layout/main-panel/main-panel.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { ToastContainerComponent } from './shared/components/toast-container/toast-container.component';
import { ConfirmDialogComponent } from './shared/components/confirm-dialog/confirm-dialog.component';
import { OfflineBannerComponent } from './shared/components/offline-banner/offline-banner.component';
import { Rail, LayoutState, Breadcrumb } from './shared/types';

const RAIL_ROUTES: Partial<Record<Rail, string>> = {
  [Rail.ALL]:    '/dashboard',
  [Rail.UAEFTS]: '/dashboard/uaefts',
  [Rail.IPI]:    '/dashboard/ipi',
  [Rail.IPP]:    '/dashboard/ipp',
  [Rail.WPS]:    '/dashboard/wps',
  [Rail.SWIFT]:  '/dashboard/swift'
};

type BreadcrumbRule = { match: (url: string) => boolean; crumbs: Breadcrumb[] };

const BREADCRUMB_RULES: BreadcrumbRule[] = [
  { match: u => u === '/dashboard' || u === '/',
    crumbs: [{ label: 'Dashboard', current: true }] },
  { match: u => u.startsWith('/dashboard/uaefts'),
    crumbs: [{ label: 'Dashboard', route: '/dashboard' }, { label: 'UAEFTS', current: true }] },
  { match: u => u.startsWith('/dashboard/ipi'),
    crumbs: [{ label: 'Dashboard', route: '/dashboard' }, { label: 'IPI / Aani', current: true }] },
  { match: u => u.startsWith('/dashboard/ipp'),
    crumbs: [{ label: 'Dashboard', route: '/dashboard' }, { label: 'IPP', current: true }] },
  { match: u => u.startsWith('/dashboard/wps'),
    crumbs: [{ label: 'Dashboard', route: '/dashboard' }, { label: 'WPS', current: true }] },
  { match: u => u.startsWith('/dashboard/swift'),
    crumbs: [{ label: 'Dashboard', route: '/dashboard' }, { label: 'SWIFT', current: true }] },
  { match: u => u.startsWith('/operations/queues'),
    crumbs: [{ label: 'Operations', route: '/operations/queues' }, { label: 'Payment Queues', current: true }] },
  { match: u => u.startsWith('/operations/approvals'),
    crumbs: [{ label: 'Operations', route: '/operations/approvals' }, { label: 'Approvals', current: true }] },
  { match: u => u.startsWith('/reporting'),
    crumbs: [{ label: 'Reporting', route: '/reporting' }, { label: 'Reports & Analytics', current: true }] },
  { match: u => u.startsWith('/exceptions'),
    crumbs: [{ label: 'Exceptions', route: '/exceptions' }, { label: 'Exception Queue', current: true }] },
  { match: u => u.startsWith('/operations/transactions/new'),
    crumbs: [{ label: 'Operations', route: '/operations/queues' }, { label: 'New Payment', current: true }] },
];

const DEFAULT_CRUMBS: Breadcrumb[] = [{ label: 'Dashboard', current: true }];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    HeaderComponent,
    SidebarComponent,
    MainPanelComponent,
    FooterComponent,
    ToastContainerComponent,
    ConfirmDialogComponent,
    OfflineBannerComponent,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'PaymentHub Operations Console';

  layoutState: LayoutState = {
    sidebarCollapsed: false,
    actionPanelCollapsed: false,
    activeRail: Rail.ALL,
    breadcrumbs: DEFAULT_CRUMBS
  };

  constructor(private router: Router, private themeSvc: ThemeService) {}

  ngOnInit(): void {
    this.themeSvc.init();
    this.loadLayoutState();
    this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe(e => {
      const url = (e as NavigationEnd).urlAfterRedirects;
      const rule = BREADCRUMB_RULES.find(r => r.match(url));
      this.layoutState.breadcrumbs = rule ? rule.crumbs : DEFAULT_CRUMBS;
      this.syncActiveRail(url);
    });
  }

  onRailChange(rail: Rail): void {
    this.layoutState.activeRail = rail;
    this.saveLayoutState();
    this.router.navigate([RAIL_ROUTES[rail] ?? '/dashboard']);
  }

  onToggleSidebar(): void {
    this.layoutState.sidebarCollapsed = !this.layoutState.sidebarCollapsed;
    this.saveLayoutState();
  }

  onSidebarCollapsed(collapsed: boolean): void {
    this.layoutState.sidebarCollapsed = collapsed;
    this.saveLayoutState();
  }

  private syncActiveRail(url: string): void {
    if (url.startsWith('/dashboard/uaefts')) this.layoutState.activeRail = Rail.UAEFTS;
    else if (url.startsWith('/dashboard/ipi'))   this.layoutState.activeRail = Rail.IPI;
    else if (url.startsWith('/dashboard/ipp'))   this.layoutState.activeRail = Rail.IPP;
    else if (url.startsWith('/dashboard/wps'))   this.layoutState.activeRail = Rail.WPS;
    else if (url.startsWith('/dashboard/swift')) this.layoutState.activeRail = Rail.SWIFT;
    else if (url.startsWith('/dashboard'))       this.layoutState.activeRail = Rail.ALL;
    // Non-dashboard routes: keep existing rail selection
  }

  private loadLayoutState(): void {
    try {
      const saved = localStorage.getItem('layoutState');
      if (saved) this.layoutState = { ...this.layoutState, ...JSON.parse(saved) };
    } catch {}
  }

  private saveLayoutState(): void {
    try { localStorage.setItem('layoutState', JSON.stringify(this.layoutState)); } catch {}
  }
}
