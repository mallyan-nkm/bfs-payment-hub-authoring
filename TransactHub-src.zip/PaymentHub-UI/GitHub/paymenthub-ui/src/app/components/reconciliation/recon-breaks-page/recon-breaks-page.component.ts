import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface ReconBreak {
  id: string;
  breakRef: string;
  rail: string;
  type: 'missing-internal' | 'missing-external' | 'amount-mismatch' | 'status-mismatch' | 'date-mismatch';
  internalRef: string;
  externalRef: string;
  internalAmount?: number;
  externalAmount?: number;
  currency: string;
  difference?: number;
  age: number;
  status: 'open' | 'investigating' | 'resolved' | 'written-off';
  assignedTo: string;
  createdAt: string;
}

@Component({
  selector: 'app-recon-breaks-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Reconciliation Breaks</h1>
        <span class="break-count">{{ breaks().length }} breaks</span>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterType" (ngModelChange)="loadBreaks()" class="filter-select">
          <option value="">All Types</option>
          <option value="missing-internal">Missing Internal</option>
          <option value="missing-external">Missing External</option>
          <option value="amount-mismatch">Amount Mismatch</option>
          <option value="status-mismatch">Status Mismatch</option>
          <option value="date-mismatch">Date Mismatch</option>
        </select>
        <select [(ngModel)]="filterStatus" (ngModelChange)="loadBreaks()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="open">Open</option>
          <option value="investigating">Investigating</option>
          <option value="resolved">Resolved</option>
          <option value="written-off">Written Off</option>
        </select>
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Ref</th><th>Rail</th><th>Type</th><th>Internal</th><th>External</th><th>Difference</th><th>Age</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            @for (b of breaks(); track b.id) {
              <tr>
                <td class="mono">{{ b.breakRef }}</td>
                <td><span class="rail-badge">{{ b.rail }}</span></td>
                <td>{{ b.type }}</td>
                <td class="mono">{{ b.internalRef }}</td>
                <td class="mono">{{ b.externalRef }}</td>
                <td class="amount" [class.mismatch]="b.difference">{{ b.difference ? (b.currency + ' ' + (b.difference | number)) : '—' }}</td>
                <td [class.aged]="b.age > 3">{{ b.age }}d</td>
                <td><span class="status-badge status--{{ b.status }}">{{ b.status }}</span></td>
                <td>
                  @if (b.status === 'open') {
                    <button class="btn-sm" (click)="manualMatch(b)">Match</button>
                    <button class="btn-sm" (click)="investigate(b)">Investigate</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .break-count { font-size: 0.8125rem; color: var(--warning); font-weight: 600; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .rail-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; }
    .amount { font-family: monospace; }
    .mismatch { color: var(--danger); font-weight: 600; }
    .aged { color: var(--danger); font-weight: 600; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--open { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--investigating { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--resolved { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--written-off { background: var(--bg-3); color: var(--text-3); }
    .btn-sm { padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.6875rem; background: var(--bg-3); color: var(--text-1); margin-right: 0.25rem; }
  `]
})
export class ReconBreaksPageComponent implements OnInit {
  private http = inject(HttpClient);
  breaks = signal<ReconBreak[]>([]);
  filterType = '';
  filterStatus = '';

  ngOnInit(): void { this.loadBreaks(); }

  loadBreaks(): void {
    this.http.get<ReconBreak[]>(`${environment.apiBaseUrl}/reconciliation/breaks`).subscribe({
      next: (data) => this.breaks.set(data), error: () => {}
    });
  }

  manualMatch(b: ReconBreak): void {}
  investigate(b: ReconBreak): void {}
}
