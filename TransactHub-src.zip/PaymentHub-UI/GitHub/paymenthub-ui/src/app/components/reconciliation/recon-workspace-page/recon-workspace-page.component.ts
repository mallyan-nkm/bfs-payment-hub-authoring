import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface ReconSummary {
  rail: string;
  totalRecords: number;
  matched: number;
  unmatched: number;
  breaks: number;
  matchRate: number;
  lastRunAt: string;
  status: 'complete' | 'running' | 'failed';
}

@Component({
  selector: 'app-recon-workspace-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Reconciliation Workspace</h1>
        <button class="btn-primary" (click)="triggerRecon()">Run Reconciliation</button>
      </div>

      <div class="summary-grid">
        @for (summary of summaries(); track summary.rail) {
          <div class="summary-card">
            <div class="card-header">
              <span class="rail-name">{{ summary.rail }}</span>
              <span class="status-dot status--{{ summary.status }}"></span>
            </div>
            <div class="card-kpis">
              <div class="kpi"><span class="kpi-value">{{ summary.matchRate }}%</span><span class="kpi-label">Match Rate</span></div>
              <div class="kpi"><span class="kpi-value">{{ summary.breaks }}</span><span class="kpi-label">Breaks</span></div>
              <div class="kpi"><span class="kpi-value">{{ summary.totalRecords | number }}</span><span class="kpi-label">Records</span></div>
            </div>
            <div class="card-bar">
              <div class="bar-matched" [style.width.%]="summary.matchRate"></div>
            </div>
            <div class="card-footer">
              <span>Last run: {{ summary.lastRunAt }}</span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .summary-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
    .summary-card { padding: 1.25rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; }
    .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
    .rail-name { font-weight: 600; color: var(--text-0); font-size: 0.9375rem; }
    .status-dot { width: 8px; height: 8px; border-radius: 50%; }
    .status--complete { background: var(--success); }
    .status--running { background: var(--warning); animation: pulse 1.5s infinite; }
    .status--failed { background: var(--danger); }
    .card-kpis { display: flex; justify-content: space-between; margin-bottom: 0.75rem; }
    .kpi { display: flex; flex-direction: column; align-items: center; }
    .kpi-value { font-size: 1.25rem; font-weight: 700; color: var(--text-0); }
    .kpi-label { font-size: 0.6875rem; color: var(--text-3); text-transform: uppercase; }
    .card-bar { height: 6px; background: var(--bg-3); border-radius: 3px; overflow: hidden; margin-bottom: 0.75rem; }
    .bar-matched { height: 100%; background: var(--success); border-radius: 3px; }
    .card-footer { font-size: 0.75rem; color: var(--text-3); }
  `]
})
export class ReconWorkspacePageComponent implements OnInit {
  private http = inject(HttpClient);
  summaries = signal<ReconSummary[]>([]);

  ngOnInit(): void {
    this.http.get<ReconSummary[]>(`${environment.apiBaseUrl}/reconciliation/summary`).subscribe({
      next: (data) => this.summaries.set(data), error: () => {}
    });
  }

  triggerRecon(): void {
    this.http.post(`${environment.apiBaseUrl}/reconciliation/run`, {}).subscribe();
  }
}
