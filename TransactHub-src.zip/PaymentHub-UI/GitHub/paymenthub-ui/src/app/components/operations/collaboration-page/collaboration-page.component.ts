import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface Message {
  id: string;
  channel: string;
  sender: string;
  content: string;
  timestamp: string;
  type: 'text' | 'system' | 'alert';
}

interface Channel {
  id: string;
  name: string;
  type: 'case' | 'team' | 'incident' | 'general';
  unread: number;
  lastMessage?: string;
  lastMessageAt?: string;
}

@Component({
  selector: 'app-collaboration-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="sidebar-panel">
        <h2 class="panel-title">Channels</h2>
        <div class="channel-list">
          @for (ch of channels(); track ch.id) {
            <div class="channel-item" [class.active]="ch.id === activeChannelId()" (click)="selectChannel(ch)">
              <span class="channel-icon">#</span>
              <span class="channel-name">{{ ch.name }}</span>
              @if (ch.unread > 0) {
                <span class="unread-badge">{{ ch.unread }}</span>
              }
            </div>
          }
        </div>
      </div>

      <div class="main-panel">
        <div class="messages-area">
          @for (msg of messages(); track msg.id) {
            <div class="message" [class.system-msg]="msg.type === 'system'" [class.alert-msg]="msg.type === 'alert'">
              <div class="msg-header">
                <span class="msg-sender">{{ msg.sender }}</span>
                <span class="msg-time">{{ msg.timestamp }}</span>
              </div>
              <p class="msg-content">{{ msg.content }}</p>
            </div>
          }
        </div>
        <div class="compose-bar">
          <input class="compose-input" placeholder="Type a message..." [(ngModel)]="newMessage" (keyup.enter)="sendMessage()">
          <button class="btn-send" (click)="sendMessage()">Send</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-container { display: grid; grid-template-columns: 240px 1fr; height: 100%; }
    .sidebar-panel { padding: 1rem; border-right: 1px solid var(--border); overflow-y: auto; background: var(--bg-1); }
    .panel-title { font-size: 0.875rem; color: var(--text-0); margin: 0 0 1rem; }
    .channel-list { display: flex; flex-direction: column; gap: 0.25rem; }
    .channel-item { display: flex; align-items: center; gap: 0.5rem; padding: 0.5rem 0.75rem; border-radius: 6px; cursor: pointer; font-size: 0.8125rem; color: var(--text-1); }
    .channel-item:hover { background: var(--bg-2); }
    .channel-item.active { background: var(--bg-3); color: var(--text-0); font-weight: 500; }
    .channel-icon { color: var(--text-3); font-weight: 700; }
    .channel-name { flex: 1; }
    .unread-badge { background: var(--accent); color: #fff; border-radius: 10px; padding: 0.0625rem 0.375rem; font-size: 0.625rem; font-weight: 600; min-width: 16px; text-align: center; }
    .main-panel { display: flex; flex-direction: column; height: 100%; }
    .messages-area { flex: 1; padding: 1rem; overflow-y: auto; display: flex; flex-direction: column; gap: 0.75rem; }
    .message { padding: 0.5rem 0; }
    .system-msg { opacity: 0.6; font-style: italic; }
    .alert-msg .msg-content { color: var(--danger); }
    .msg-header { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.125rem; }
    .msg-sender { font-weight: 600; font-size: 0.8125rem; color: var(--text-0); }
    .msg-time { font-size: 0.6875rem; color: var(--text-3); }
    .msg-content { margin: 0; font-size: 0.8125rem; color: var(--text-1); line-height: 1.4; }
    .compose-bar { display: flex; gap: 0.5rem; padding: 0.75rem 1rem; border-top: 1px solid var(--border); background: var(--bg-2); }
    .compose-input { flex: 1; padding: 0.5rem 0.75rem; background: var(--bg-1); border: 1px solid var(--border); border-radius: 6px; color: var(--text-0); font-size: 0.8125rem; }
    .btn-send { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
  `]
})
export class CollaborationPageComponent implements OnInit {
  private http = inject(HttpClient);
  channels = signal<Channel[]>([]);
  messages = signal<Message[]>([]);
  activeChannelId = signal('');
  newMessage = '';

  ngOnInit(): void {
    this.http.get<Channel[]>(`${environment.apiBaseUrl}/collaboration/channels`).subscribe({
      next: (data) => {
        this.channels.set(data);
        if (data.length > 0) this.selectChannel(data[0]);
      },
      error: () => {}
    });
  }

  selectChannel(ch: Channel): void {
    this.activeChannelId.set(ch.id);
    this.http.get<Message[]>(`${environment.apiBaseUrl}/collaboration/channels/${ch.id}/messages`).subscribe({
      next: (data) => this.messages.set(data), error: () => {}
    });
  }

  sendMessage(): void {
    if (!this.newMessage.trim()) return;
    this.http.post(`${environment.apiBaseUrl}/collaboration/channels/${this.activeChannelId()}/messages`, { content: this.newMessage }).subscribe({
      next: () => { this.newMessage = ''; this.selectChannel({ id: this.activeChannelId() } as Channel); },
      error: () => {}
    });
  }
}
