import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface OperationalLever {
  id: string;
  category: string;
  name: string;
  description: string;
  currentValue: string;
  type: 'toggle' | 'threshold' | 'schedule' | 'enum';
  enabled: boolean;
  lastModifiedBy: string;
  lastModifiedAt: string;
  requiresApproval: boolean;
}

@Component({
  selector: 'app-operational-levers-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Operational Control Levers</h1>
        <span class="info-badge">Changes require approval</span>
      </div>

      <div class="lever-groups">
        @for (group of leverGroups(); track group.category) {
          <div class="lever-group">
            <h2 class="group-title">{{ group.category }}</h2>
            <div class="lever-list">
              @for (lever of group.levers; track lever.id) {
                <div class="lever-row" [class.disabled]="!lever.enabled">
                  <div class="lever-info">
                    <span class="lever-name">{{ lever.name }}</span>
                    <span class="lever-desc">{{ lever.description }}</span>
                  </div>
                  <div class="lever-control">
                    @if (lever.type === 'toggle') {
                      <label class="toggle-switch">
                        <input type="checkbox" [checked]="lever.enabled" (change)="toggleLever(lever)">
                        <span class="toggle-slider"></span>
                      </label>
                    } @else {
                      <span class="lever-value">{{ lever.currentValue }}</span>
                      <button class="btn-sm" (click)="editLever(lever)">Edit</button>
                    }
                  </div>
                  <div class="lever-meta">
                    <span>{{ lever.lastModifiedBy }} — {{ lever.lastModifiedAt }}</span>
                  </div>
                </div>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .info-badge { padding: 0.25rem 0.625rem; background: rgba(251,191,36,0.1); color: var(--warning); border-radius: 4px; font-size: 0.75rem; }
    .lever-groups { display: flex; flex-direction: column; gap: 1.5rem; }
    .group-title { font-size: 0.875rem; font-weight: 600; color: var(--text-0); margin: 0 0 0.75rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--border); }
    .lever-list { display: flex; flex-direction: column; gap: 0.5rem; }
    .lever-row { display: grid; grid-template-columns: 1fr auto auto; align-items: center; gap: 1rem; padding: 0.75rem 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; }
    .lever-row.disabled { opacity: 0.5; }
    .lever-name { font-weight: 500; color: var(--text-0); font-size: 0.875rem; display: block; }
    .lever-desc { font-size: 0.75rem; color: var(--text-3); }
    .lever-control { display: flex; align-items: center; gap: 0.5rem; }
    .lever-value { font-family: monospace; font-size: 0.875rem; color: var(--accent); font-weight: 500; padding: 0.25rem 0.5rem; background: var(--bg-3); border-radius: 4px; }
    .lever-meta { font-size: 0.6875rem; color: var(--text-3); }
    .toggle-switch { position: relative; display: inline-block; width: 36px; height: 20px; }
    .toggle-switch input { opacity: 0; width: 0; height: 0; }
    .toggle-slider { position: absolute; cursor: pointer; inset: 0; background: var(--bg-3); border-radius: 20px; transition: 0.2s; }
    .toggle-slider::before { content: ''; position: absolute; width: 14px; height: 14px; left: 3px; bottom: 3px; background: var(--text-2); border-radius: 50%; transition: 0.2s; }
    .toggle-switch input:checked + .toggle-slider { background: var(--accent); }
    .toggle-switch input:checked + .toggle-slider::before { transform: translateX(16px); background: #fff; }
    .btn-sm { padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.6875rem; background: var(--bg-3); color: var(--text-1); }
  `]
})
export class OperationalLeversPageComponent implements OnInit {
  private http = inject(HttpClient);
  leverGroups = signal<{ category: string; levers: OperationalLever[] }[]>([]);

  ngOnInit(): void {
    this.http.get<OperationalLever[]>(`${environment.apiBaseUrl}/config/levers`).subscribe({
      next: (data) => {
        const groups = data.reduce((acc, lever) => {
          const g = acc.find(x => x.category === lever.category);
          if (g) g.levers.push(lever); else acc.push({ category: lever.category, levers: [lever] });
          return acc;
        }, [] as { category: string; levers: OperationalLever[] }[]);
        this.leverGroups.set(groups);
      },
      error: () => {}
    });
  }

  toggleLever(lever: OperationalLever): void {}
  editLever(lever: OperationalLever): void {}
}
