import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface ShiftHandover {
  id: string;
  fromShift: string;
  toShift: string;
  handoverTime: string;
  createdBy: string;
  status: 'draft' | 'submitted' | 'acknowledged';
  openItems: number;
  escalations: number;
  notes: string;
}

interface TeamMember {
  id: string;
  name: string;
  role: string;
  shift: string;
  activeItems: number;
  completedToday: number;
  status: 'online' | 'away' | 'offline';
}

@Component({
  selector: 'app-shift-handover-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Shift Handover & Team Workload</h1>
        <button class="btn-primary" (click)="createHandover()">New Handover</button>
      </div>

      <div class="two-col">
        <div class="col">
          <h2 class="section-title">Team Workload</h2>
          <div class="team-list">
            @for (member of team(); track member.id) {
              <div class="member-row">
                <div class="member-status">
                  <span class="status-dot status--{{ member.status }}"></span>
                  <span class="member-name">{{ member.name }}</span>
                </div>
                <span class="member-role">{{ member.role }}</span>
                <div class="member-stats">
                  <span class="stat-active">{{ member.activeItems }} active</span>
                  <span class="stat-done">{{ member.completedToday }} done</span>
                </div>
              </div>
            }
          </div>
        </div>

        <div class="col">
          <h2 class="section-title">Recent Handovers</h2>
          <div class="handover-list">
            @for (h of handovers(); track h.id) {
              <div class="handover-card">
                <div class="handover-header">
                  <span class="shift-tag">{{ h.fromShift }} → {{ h.toShift }}</span>
                  <span class="status-badge status--{{ h.status }}">{{ h.status }}</span>
                </div>
                <div class="handover-meta">
                  <span>By {{ h.createdBy }}</span>
                  <span>{{ h.handoverTime }}</span>
                </div>
                <div class="handover-stats">
                  <span>{{ h.openItems }} open items</span>
                  <span class="esc" [class.has-esc]="h.escalations > 0">{{ h.escalations }} escalations</span>
                </div>
                <p class="handover-notes">{{ h.notes }}</p>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    .section-title { font-size: 0.9375rem; color: var(--text-0); margin: 0 0 1rem; }
    .team-list { display: flex; flex-direction: column; gap: 0.5rem; }
    .member-row { display: grid; grid-template-columns: 1fr auto auto; align-items: center; gap: 0.75rem; padding: 0.625rem 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; }
    .member-status { display: flex; align-items: center; gap: 0.5rem; }
    .status-dot { width: 8px; height: 8px; border-radius: 50%; }
    .status--online { background: var(--success); }
    .status--away { background: var(--warning); }
    .status--offline { background: var(--text-3); }
    .member-name { font-weight: 500; color: var(--text-0); font-size: 0.875rem; }
    .member-role { font-size: 0.75rem; color: var(--text-2); }
    .member-stats { display: flex; gap: 0.75rem; font-size: 0.75rem; }
    .stat-active { color: var(--accent); }
    .stat-done { color: var(--success); }
    .handover-list { display: flex; flex-direction: column; gap: 0.75rem; }
    .handover-card { padding: 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; }
    .handover-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.375rem; }
    .shift-tag { font-weight: 600; color: var(--text-0); font-size: 0.8125rem; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--draft { background: var(--bg-3); color: var(--text-2); }
    .status--submitted { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--acknowledged { background: rgba(74,222,128,0.1); color: var(--success); }
    .handover-meta { font-size: 0.75rem; color: var(--text-3); display: flex; gap: 1rem; margin-bottom: 0.375rem; }
    .handover-stats { display: flex; gap: 1rem; font-size: 0.75rem; color: var(--text-2); margin-bottom: 0.375rem; }
    .has-esc { color: var(--danger); font-weight: 600; }
    .handover-notes { margin: 0; font-size: 0.8125rem; color: var(--text-2); line-height: 1.4; }
  `]
})
export class ShiftHandoverPageComponent implements OnInit {
  private http = inject(HttpClient);
  team = signal<TeamMember[]>([]);
  handovers = signal<ShiftHandover[]>([]);

  ngOnInit(): void {
    this.http.get<TeamMember[]>(`${environment.apiBaseUrl}/team/members`).subscribe({
      next: (data) => this.team.set(data), error: () => {}
    });
    this.http.get<ShiftHandover[]>(`${environment.apiBaseUrl}/team/handovers`).subscribe({
      next: (data) => this.handovers.set(data), error: () => {}
    });
  }

  createHandover(): void {}
}
