import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface Document {
  id: string;
  name: string;
  type: 'pdf' | 'image' | 'excel' | 'word' | 'other';
  category: string;
  relatedEntity: string;
  relatedEntityId: string;
  uploadedBy: string;
  uploadedAt: string;
  size: number;
  status: 'active' | 'archived' | 'pending-review';
}

@Component({
  selector: 'app-document-management-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Document & Evidence Management</h1>
        <button class="btn-primary" (click)="uploadDocument()">Upload Document</button>
      </div>

      <div class="filters-bar">
        <input class="search-input" placeholder="Search documents..." [(ngModel)]="searchQuery">
        <select [(ngModel)]="filterCategory" (ngModelChange)="loadDocuments()" class="filter-select">
          <option value="">All Categories</option>
          <option value="compliance">Compliance</option>
          <option value="fraud">Fraud</option>
          <option value="kyc">KYC</option>
          <option value="evidence">Evidence</option>
          <option value="regulatory">Regulatory</option>
        </select>
      </div>

      <div class="doc-grid">
        @for (doc of documents(); track doc.id) {
          <div class="doc-card">
            <div class="doc-icon doc-icon--{{ doc.type }}">
              @switch (doc.type) {
                @case ('pdf') { PDF }
                @case ('image') { IMG }
                @case ('excel') { XLS }
                @case ('word') { DOC }
                @default { FILE }
              }
            </div>
            <div class="doc-info">
              <span class="doc-name">{{ doc.name }}</span>
              <span class="doc-meta">{{ doc.category }} · {{ formatSize(doc.size) }}</span>
              <span class="doc-meta">{{ doc.uploadedBy }} · {{ doc.uploadedAt }}</span>
            </div>
            <div class="doc-actions">
              <button class="btn-icon" title="Download" (click)="download(doc)">↓</button>
              <button class="btn-icon" title="Preview" (click)="preview(doc)">⧉</button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .search-input { flex: 1; padding: 0.5rem 0.75rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; color: var(--text-0); font-size: 0.8125rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .doc-grid { display: flex; flex-direction: column; gap: 0.5rem; }
    .doc-card { display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 0.75rem; padding: 0.75rem 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; }
    .doc-icon { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 6px; font-size: 0.6875rem; font-weight: 700; }
    .doc-icon--pdf { background: rgba(248,113,113,0.15); color: var(--danger); }
    .doc-icon--image { background: rgba(168,85,247,0.15); color: #a855f7; }
    .doc-icon--excel { background: rgba(74,222,128,0.15); color: var(--success); }
    .doc-icon--word { background: rgba(76,158,255,0.15); color: var(--accent); }
    .doc-icon--other { background: var(--bg-3); color: var(--text-2); }
    .doc-info { display: flex; flex-direction: column; gap: 0.125rem; }
    .doc-name { font-weight: 500; color: var(--text-0); font-size: 0.875rem; }
    .doc-meta { font-size: 0.75rem; color: var(--text-3); }
    .doc-actions { display: flex; gap: 0.25rem; }
    .btn-icon { width: 28px; height: 28px; border-radius: 4px; border: 1px solid var(--border); background: var(--bg-3); color: var(--text-1); cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 0.8125rem; }
  `]
})
export class DocumentManagementPageComponent implements OnInit {
  private http = inject(HttpClient);
  documents = signal<Document[]>([]);
  searchQuery = '';
  filterCategory = '';

  ngOnInit(): void { this.loadDocuments(); }

  loadDocuments(): void {
    this.http.get<Document[]>(`${environment.apiBaseUrl}/documents`).subscribe({
      next: (data) => this.documents.set(data), error: () => {}
    });
  }

  formatSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  }

  uploadDocument(): void {}
  download(doc: Document): void {}
  preview(doc: Document): void {}
}
