import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface WorkflowExecution {
  id: string;
  workflowId: string;
  runId: string;
  type: string;
  status: 'running' | 'completed' | 'failed' | 'cancelled' | 'timed_out';
  startedAt: string;
  completedAt?: string;
  duration?: number;
  currentStep: string;
  totalSteps: number;
  completedSteps: number;
  errorMessage?: string;
}

@Component({
  selector: 'app-workflow-replay-page',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Workflow Replay & Forensics</h1>
      </div>

      <div class="search-bar">
        <input class="search-input" placeholder="Search by Workflow ID or Run ID..." [(ngModel)]="searchQuery" (keyup.enter)="search()">
        <select [(ngModel)]="filterStatus" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="running">Running</option>
          <option value="completed">Completed</option>
          <option value="failed">Failed</option>
          <option value="cancelled">Cancelled</option>
          <option value="timed_out">Timed Out</option>
        </select>
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Workflow ID</th><th>Type</th><th>Status</th><th>Progress</th><th>Current Step</th><th>Started</th><th>Duration</th><th>Actions</th></tr>
          </thead>
          <tbody>
            @for (exec of pagedItems(); track exec.id) {
              <tr>
                <td class="mono">{{ exec.workflowId }}</td>
                <td>{{ exec.type }}</td>
                <td><span class="status-badge status--{{ exec.status }}">{{ exec.status }}</span></td>
                <td>
                  <div class="progress-bar"><div class="progress-fill" [style.width.%]="(exec.completedSteps / exec.totalSteps) * 100"></div></div>
                  <span class="progress-label">{{ exec.completedSteps }}/{{ exec.totalSteps }}</span>
                </td>
                <td>{{ exec.currentStep }}</td>
                <td>{{ exec.startedAt }}</td>
                <td>{{ exec.duration ? exec.duration + 'ms' : '—' }}</td>
                <td>
                  <button class="btn-sm" (click)="viewTimeline(exec)">Timeline</button>
                  @if (exec.status === 'failed') {
                    <button class="btn-sm btn-replay" (click)="replay(exec)">Replay</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>

    <!-- Timeline slide-over panel -->
    @if (selectedExec()) {
      <div class="timeline-overlay" (click)="closeTimeline()"></div>
      <aside class="timeline-panel">
        <div class="timeline-header">
          <h2>Workflow Timeline</h2>
          <button class="btn-close" (click)="closeTimeline()">✕</button>
        </div>
        <div class="timeline-meta">
          <span class="mono">{{ selectedExec()!.workflowId }}</span>
          <span class="status-badge status--{{ selectedExec()!.status }}">{{ selectedExec()!.status }}</span>
        </div>
        @if (timelineLoading()) {
          <div class="timeline-loading">Loading workflow steps...</div>
        } @else if (timelineSteps().length === 0) {
          <div class="timeline-empty">No workflow steps found.</div>
        } @else {
          <div class="timeline-summary">{{ timelineSteps().length }} total steps · {{ selectedExec()!.completedSteps }} completed</div>
          <ol class="timeline-list">
            @for (step of timelineSteps(); track step.step) {
              <li class="tl-step tl-step--{{ step.status.toLowerCase() }}">
                <span class="tl-dot"></span>
                <div class="tl-body">
                  <div class="tl-name">{{ step.stepName }}</div>
                  <div class="tl-info">
                    <span class="tl-type">{{ step.stepType }}</span>
                    <span class="tl-status">{{ step.status }}</span>
                    @if (step.durationMs) { <span class="tl-dur">{{ step.durationMs }}ms</span> }
                  </div>
                  @if (step.errorMessage) { <div class="tl-error">{{ step.errorMessage }}</div> }
                </div>
              </li>
            }
          </ol>
        }
      </aside>
    }
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .search-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .search-input { flex: 1; padding: 0.5rem 0.75rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; color: var(--text-0); font-size: 0.8125rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .progress-bar { width: 60px; height: 4px; background: var(--bg-3); border-radius: 2px; display: inline-block; vertical-align: middle; margin-right: 0.375rem; }
    .progress-fill { height: 100%; background: var(--accent); border-radius: 2px; }
    .progress-label { font-size: 0.6875rem; color: var(--text-3); }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--running { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--completed { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--failed { background: rgba(248,113,113,0.1); color: var(--danger); }
    .status--cancelled { background: var(--bg-3); color: var(--text-3); }
    .status--timed_out { background: rgba(251,191,36,0.1); color: var(--warning); }
    .btn-sm { padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.6875rem; background: var(--bg-3); color: var(--text-1); margin-right: 0.25rem; }
    .btn-replay { background: var(--accent); color: #fff; border-color: var(--accent); }

    /* Timeline panel */
    .timeline-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 900; }
    .timeline-panel { position: fixed; top: 0; right: 0; bottom: 0; width: 480px; background: var(--bg-1); border-left: 1px solid var(--border); z-index: 901; display: flex; flex-direction: column; overflow-y: auto; padding: 1.25rem; }
    .timeline-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; }
    .timeline-header h2 { font-size: 1rem; color: var(--text-0); margin: 0; }
    .btn-close { background: none; border: none; color: var(--text-3); font-size: 1.25rem; cursor: pointer; }
    .timeline-meta { display: flex; gap: 0.5rem; align-items: center; margin-bottom: 0.75rem; flex-wrap: wrap; }
    .timeline-loading, .timeline-empty { padding: 2rem; text-align: center; color: var(--text-3); }
    .timeline-summary { font-size: 0.75rem; color: var(--text-2); margin-bottom: 1rem; padding: 0.5rem 0.75rem; background: var(--bg-2); border-radius: 4px; }
    .timeline-list { list-style: none; padding: 0; margin: 0; }
    .tl-step { display: flex; gap: 0.75rem; padding: 0.5rem 0; border-left: 2px solid var(--border); margin-left: 0.5rem; padding-left: 1rem; position: relative; }
    .tl-dot { position: absolute; left: -5px; top: 0.75rem; width: 8px; height: 8px; border-radius: 50%; background: var(--border); }
    .tl-step--completed .tl-dot { background: var(--success); }
    .tl-step--evaluated .tl-dot { background: var(--accent); }
    .tl-step--failed .tl-dot { background: var(--danger); }
    .tl-step--pending .tl-dot { background: var(--text-3); }
    .tl-body { flex: 1; }
    .tl-name { font-size: 0.8125rem; color: var(--text-0); font-weight: 500; }
    .tl-info { display: flex; gap: 0.5rem; font-size: 0.6875rem; color: var(--text-3); margin-top: 0.125rem; }
    .tl-type { background: var(--bg-3); padding: 0 0.375rem; border-radius: 3px; }
    .tl-status { font-weight: 500; }
    .tl-step--completed .tl-status { color: var(--success); }
    .tl-step--evaluated .tl-status { color: var(--accent); }
    .tl-step--failed .tl-status { color: var(--danger); }
    .tl-dur { color: var(--text-2); }
    .tl-error { font-size: 0.6875rem; color: var(--danger); margin-top: 0.25rem; }
  `]
})
export class WorkflowReplayPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allItems = signal<WorkflowExecution[]>([]);
  pagedItems = signal<WorkflowExecution[]>([]);
  totalItems = signal(0);

  // Timeline panel state
  selectedExec = signal<WorkflowExecution | null>(null);
  timelineSteps = signal<any[]>([]);
  timelineLoading = signal(false);

  searchQuery = '';
  filterStatus = '';
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadExecutions(); }

  loadExecutions(): void {
    let params = new HttpParams();
    if (this.filterStatus) params = params.set('status', this.filterStatus);
    if (this.searchQuery) params = params.set('search', this.searchQuery);
    params = params.set('take', '1000');

    this.http.get<any>(`${environment.apiBaseUrl}/workflows/instances`, { params }).subscribe({
      next: (resp) => {
        // Support both paginated { items, total } and plain array responses
        const raw = resp?.items ?? (Array.isArray(resp) ? resp : []);
        const items: WorkflowExecution[] = raw.map((wf: any) => this.mapToExecution(wf));
        this.allItems.set(items);
        this.applyClientPagination();
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private mapToExecution(wf: any): WorkflowExecution {
    const id = wf.id ?? '';
    const status = (wf.status ?? 'RUNNING').toLowerCase() as WorkflowExecution['status'];
    const startTime = wf.startTime ? new Date(wf.startTime).toISOString() : '';
    const closeTime = wf.closeTime ? new Date(wf.closeTime) : null;
    const startDate = wf.startTime ? new Date(wf.startTime) : new Date();
    const duration = closeTime ? closeTime.getTime() - startDate.getTime() : undefined;

    return {
      id,
      workflowId: id,
      runId: wf.runId ?? '',
      type: wf.workflowName ?? 'PaymentDslWorkflow',
      status,
      startedAt: startTime,
      completedAt: closeTime?.toISOString(),
      duration,
      currentStep: status === 'completed' ? 'Done' : 'Processing',
      totalSteps: 0,
      completedSteps: 0,
      errorMessage: undefined,
    };
  }

  private applyClientPagination(): void {
    let filtered = this.allItems();
    if (this.filterStatus) filtered = filtered.filter(e => e.status === this.filterStatus);
    if (this.searchQuery) {
      const q = this.searchQuery.toLowerCase();
      filtered = filtered.filter(e => e.workflowId.toLowerCase().includes(q) || e.runId.toLowerCase().includes(q));
    }
    this.totalItems.set(filtered.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(filtered.slice(start, start + this.pageSize));
  }

  onFilterChange(): void { this.currentPage = 1; this.loadExecutions(); }
  search(): void { this.currentPage = 1; this.loadExecutions(); }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allItems().length > 0) {
      this.applyClientPagination();
    } else {
      this.loadExecutions();
    }
  }

  viewTimeline(exec: WorkflowExecution): void {
    // Extract transaction ID from workflow ID (e.g., "ADIB_IPI_OUTWARD_INITIATE103-TXN-OUT-1779308487406")
    const txnMatch = exec.workflowId.match(/(TXN-[A-Z]+-\d+)/i);
    const transactionId = txnMatch ? txnMatch[1] : exec.workflowId;

    this.selectedExec.set(exec);
    this.timelineSteps.set([]);
    this.timelineLoading.set(true);

    this.http.get<any>(`${environment.apiBaseUrl}/transactions/${encodeURIComponent(transactionId)}/360`).subscribe({
      next: (dto) => {
        const steps = (dto?.workflowJourney ?? []).map((s: any, i: number) => ({
          step: i + 1,
          stepName: s.stepName ?? `Step ${i + 1}`,
          stepType: s.stepType ?? '',
          status: s.status ?? 'PENDING',
          startedAt: s.startedAt,
          completedAt: s.completedAt,
          durationMs: s.durationMs,
          errorMessage: s.errorMessage,
        }));
        this.timelineSteps.set(steps);
        this.timelineLoading.set(false);

        // Update execution step counts
        exec.totalSteps = steps.length;
        exec.completedSteps = steps.filter((s: any) => s.status === 'COMPLETED' || s.status === 'EVALUATED').length;
      },
      error: () => { this.timelineLoading.set(false); }
    });
  }

  closeTimeline(): void {
    this.selectedExec.set(null);
    this.timelineSteps.set([]);
  }

  replay(exec: WorkflowExecution): void {}
}
