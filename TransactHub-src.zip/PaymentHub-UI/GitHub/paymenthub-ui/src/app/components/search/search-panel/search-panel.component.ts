import {
  Component, Input, Output, EventEmitter, OnChanges, SimpleChanges,
  HostListener, ChangeDetectionStrategy, ChangeDetectorRef
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { SearchService } from '../../../shared/services/search.service';
import { SearchResultGroup, SearchResult, RecentSearch } from '../../../shared/types';

@Component({
  selector: 'app-search-panel',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './search-panel.component.html',
  styleUrls: ['./search-panel.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SearchPanelComponent implements OnChanges {
  @Input() query = '';
  @Input() visible = false;
  @Output() close = new EventEmitter<void>();

  groups: SearchResultGroup[] = [];
  recent: RecentSearch[] = [];
  totalCount = 0;

  private flatResults: SearchResult[] = [];
  private focusIndex = -1;

  constructor(
    private searchSvc: SearchService,
    private router: Router,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['visible'] && this.visible) {
      this.recent = this.searchSvc.getRecent();
      this.focusIndex = -1;
    }
    if (changes['query'] || (changes['visible'] && this.visible)) {
      this.runSearch();
    }
  }

  private runSearch(): void {
    this.groups = this.searchSvc.search(this.query);
    this.totalCount = this.searchSvc.getTotalCount(this.query);
    this.flatResults = this.groups.flatMap(g => g.results);
    this.focusIndex = -1;
    this.cdr.markForCheck();
  }

  get hasQuery(): boolean { return this.query.trim().length > 0; }
  get hasResults(): boolean { return this.groups.length > 0; }

  onResultClick(result: SearchResult): void {
    this.searchSvc.saveSearch(this.query);
    this.router.navigate([result.route]);
    this.close.emit();
  }

  onRecentClick(query: string): void {
    this.close.emit();
  }

  @HostListener('document:keydown', ['$event'])
  onKeydown(event: KeyboardEvent): void {
    if (!this.visible) return;

    if (event.key === 'Escape') {
      this.close.emit();
      return;
    }

    if (!this.hasResults) return;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      this.focusIndex = Math.min(this.focusIndex + 1, this.flatResults.length - 1);
      this.cdr.markForCheck();
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      this.focusIndex = Math.max(this.focusIndex - 1, -1);
      this.cdr.markForCheck();
    } else if (event.key === 'Enter' && this.focusIndex >= 0) {
      event.preventDefault();
      this.onResultClick(this.flatResults[this.focusIndex]);
    }
  }

  isFocused(result: SearchResult): boolean {
    return this.flatResults[this.focusIndex]?.id === result.id;
  }

  timeAgo(date: Date): string {
    const diffMs = Date.now() - date.getTime();
    const mins = Math.floor(diffMs / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  }

  railLabel(rail?: string): string { return rail ?? ''; }

  statusClass(status?: string): string {
    if (!status) return '';
    const s = status.toLowerCase();
    if (s.includes('fail') || s.includes('reject') || s.includes('critical')) return 'sp__status--danger';
    if (s.includes('held') || s.includes('escalat') || s.includes('pend') || s.includes('triage')) return 'sp__status--warning';
    if (s.includes('settl') || s.includes('complet') || s.includes('approv') || s.includes('resolved')) return 'sp__status--success';
    return 'sp__status--neutral';
  }
}
