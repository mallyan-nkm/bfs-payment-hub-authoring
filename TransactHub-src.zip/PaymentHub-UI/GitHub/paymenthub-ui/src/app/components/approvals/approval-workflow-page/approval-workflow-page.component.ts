import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ApprovalWorkflow, ApprovalFilter, ApprovalSort, ApprovalPage,
  ApprovalSummary, ApprovalDecisionRequest, ApprovalLevelFilter,
  Rail, QueueItemType, QueuePriority, SlaStatus
} from '../../../shared/types';
import { ApprovalService } from '../../../shared/services/approval.service';
import { ToastService } from '../../../shared/services/toast.service';
import { ConfirmService } from '../../../shared/services/confirm.service';
import { ExportService } from '../../../shared/services/export.service';
import { ApprovalDetailComponent, ApprovalDetailDecision } from '../approval-detail/approval-detail.component';
import { CopyClipboardDirective } from '../../../shared/directives/copy-clipboard.directive';
import { CountUpDirective } from '../../../shared/directives/count-up.directive';
import { DataFreshnessComponent } from '../../../shared/components/data-freshness/data-freshness.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';

const DEFAULT_FILTER: ApprovalFilter = {
  search: '',
  rails: [],
  types: [],
  priorities: [],
  slaStatuses: [],
  amountMin: null,
  amountMax: null,
  dateFrom: null,
  dateTo: null,
  urgentOnly: false,
  levelFilter: 'ALL',
};

@Component({
  selector: 'app-approval-workflow-page',
  standalone: true,
  imports: [CommonModule, FormsModule, ApprovalDetailComponent, CopyClipboardDirective, CountUpDirective, DataFreshnessComponent, EmptyStateComponent],
  templateUrl: './approval-workflow-page.component.html',
  styleUrls: ['./approval-workflow-page.component.scss']
})
export class ApprovalWorkflowPageComponent implements OnInit, OnDestroy {

  filter: ApprovalFilter = { ...DEFAULT_FILTER };
  sort: ApprovalSort = { column: 'slaDeadline', direction: 'asc' };
  currentPage = 1;
  pageSize = 25;

  page: ApprovalPage = { items: [], totalCount: 0, filteredCount: 0, page: 1, pageSize: 25 };
  summary: ApprovalSummary = { pendingL1: 0, pendingL2: 0, pendingSenior: 0, slaBreachCount: 0, approvedToday: 0, rejectedToday: 0, expiredToday: 0, avgDecisionMinutes: 0 };
  isLoading = false;

  selectedWorkflow: ApprovalWorkflow | null = null;
  detailLoading = false;
  selectedIds: string[] = [];

  availableApprovers: string[] = [];

  lastUpdated = new Date();
  private refreshTimer: ReturnType<typeof setInterval> | null = null;

  readonly LEVEL_TABS: { id: ApprovalLevelFilter; label: string; count: () => number }[] = [
    { id: 'ALL',     label: 'All Pending', count: () => this.summary.pendingL1 + this.summary.pendingL2 + this.summary.pendingSenior },
    { id: 'L1',     label: 'L1',          count: () => this.summary.pendingL1 },
    { id: 'L2',     label: 'L2',          count: () => this.summary.pendingL2 },
    { id: 'SENIOR', label: 'Senior',       count: () => this.summary.pendingSenior },
    { id: 'HISTORY',label: 'History',      count: () => 0 },
  ];

  readonly Rails = Object.values(Rail).filter(r => r !== Rail.ALL);
  readonly Types = Object.values(QueueItemType);
  readonly Priorities = Object.values(QueuePriority);
  readonly SlaOptions: { id: SlaStatus; label: string }[] = [
    { id: 'ok', label: 'On Track' }, { id: 'warning', label: 'Warning' }, { id: 'breach', label: 'Breach' }
  ];

  constructor(
    public svc: ApprovalService,
    private toastSvc: ToastService,
    private confirmSvc: ConfirmService,
    private exportSvc: ExportService,
  ) {}

  ngOnInit(): void {
    this.availableApprovers = this.svc.getApprovers();
    this.load();
    this.refreshTimer = setInterval(() => this.load(true), 30_000);
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  // ── Data ──────────────────────────────────────────────────────────────────

  load(silent = false): void {
    if (!silent) this.isLoading = true;
    this.svc.getPage(this.filter, this.sort, this.currentPage, this.pageSize)
      .subscribe(page => {
        this.page = page;
        this.isLoading = false;
        this.lastUpdated = new Date();
      });
    this.svc.getSummary().subscribe(summary => {
      this.summary = summary;
    });
  }

  exportCsv(): void {
    const rows = this.page.items.map(i => ({
      TxnID: i.id,
      Reference: i.reference,
      Type: i.type,
      Rail: i.rail,
      Amount: i.amount,
      Currency: i.currency,
      Originator: i.originatorName,
      Beneficiary: i.beneficiaryName,
      Status: i.approvalStatus,
      Priority: i.priority,
      SLA_Status: i.slaStatus,
      Submitted_At: i.submittedAt.toISOString(),
    }));
    this.exportSvc.toCsv(rows, `approvals-${new Date().toISOString().slice(0, 10)}`);
    this.toastSvc.success('Export complete', `${rows.length} items exported`);
  }

  // ── Level tabs ─────────────────────────────────────────────────────────────

  onLevelChange(level: ApprovalLevelFilter): void {
    this.filter = { ...this.filter, levelFilter: level };
    this.currentPage = 1;
    this.load();
  }

  // ── Filters ────────────────────────────────────────────────────────────────

  onSearchChange(v: string): void { this.filter = { ...this.filter, search: v }; this.currentPage = 1; this.load(); }
  onUrgentToggle(): void { this.filter = { ...this.filter, urgentOnly: !this.filter.urgentOnly }; this.currentPage = 1; this.load(); }
  onResetFilters(): void { this.filter = { ...DEFAULT_FILTER, levelFilter: this.filter.levelFilter }; this.currentPage = 1; this.load(); }

  toggleRail(r: Rail): void         { this.filter = { ...this.filter, rails: this.toggle(this.filter.rails, r) }; this.currentPage = 1; this.load(); }
  toggleType(t: QueueItemType): void{ this.filter = { ...this.filter, types: this.toggle(this.filter.types, t) }; this.currentPage = 1; this.load(); }
  togglePriority(p: QueuePriority): void { this.filter = { ...this.filter, priorities: this.toggle(this.filter.priorities, p) }; this.currentPage = 1; this.load(); }
  toggleSla(s: SlaStatus): void     { this.filter = { ...this.filter, slaStatuses: this.toggle(this.filter.slaStatuses, s) }; this.currentPage = 1; this.load(); }

  private toggle<T>(arr: T[], val: T): T[] {
    const i = arr.indexOf(val);
    return i === -1 ? [...arr, val] : arr.filter((_, idx) => idx !== i);
  }

  isRailActive(r: Rail): boolean          { return this.filter.rails.includes(r); }
  isTypeActive(t: QueueItemType): boolean { return this.filter.types.includes(t); }
  isPriActive(p: QueuePriority): boolean  { return this.filter.priorities.includes(p); }
  isSlaActive(s: SlaStatus): boolean      { return this.filter.slaStatuses.includes(s); }

  get activeFilterCount(): number {
    let n = 0;
    if (this.filter.search?.trim()) n++;
    if (this.filter.rails.length) n++;
    if (this.filter.types.length) n++;
    if (this.filter.priorities.length) n++;
    if (this.filter.slaStatuses.length) n++;
    if (this.filter.urgentOnly) n++;
    if (this.filter.amountMin !== null) n++;
    if (this.filter.amountMax !== null) n++;
    return n;
  }

  // ── Sort & Pagination ─────────────────────────────────────────────────────

  onSort(col: keyof ApprovalWorkflow): void {
    const dir = this.sort.column === col && this.sort.direction === 'asc' ? 'desc' : 'asc';
    this.sort = { column: col, direction: dir };
    this.currentPage = 1;
    this.load();
  }

  sortIndicator(col: keyof ApprovalWorkflow): string {
    if (this.sort.column !== col) return '';
    return this.sort.direction === 'asc' ? '↑' : '↓';
  }

  goToPage(p: number): void { if (p > 0 && p <= this.totalPages) { this.currentPage = p; this.load(); } }
  onPageSizeChange(v: string): void { this.pageSize = +v; this.currentPage = 1; this.load(); }
  get totalPages(): number { return Math.ceil(this.page.filteredCount / this.pageSize) || 1; }
  get rangeStart(): number { return (this.currentPage - 1) * this.pageSize + 1; }
  get rangeEnd(): number   { return Math.min(this.currentPage * this.pageSize, this.page.filteredCount); }

  get pageNumbers(): number[] {
    const total = this.totalPages;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: number[] = [1];
    if (this.currentPage > 3) pages.push(-1);
    for (let p = Math.max(2, this.currentPage - 1); p <= Math.min(total - 1, this.currentPage + 1); p++) pages.push(p);
    if (this.currentPage < total - 2) pages.push(-1);
    pages.push(total);
    return pages;
  }

  // ── Selection ─────────────────────────────────────────────────────────────

  get allPageSelected(): boolean { return this.page.items.length > 0 && this.page.items.every(i => this.selectedIds.includes(i.id)); }
  get somePageSelected(): boolean { return this.page.items.some(i => this.selectedIds.includes(i.id)) && !this.allPageSelected; }

  toggleAll(): void {
    if (this.allPageSelected) {
      this.selectedIds = this.selectedIds.filter(id => !this.page.items.find(i => i.id === id));
    } else {
      const existing = new Set(this.selectedIds);
      this.page.items.forEach(i => existing.add(i.id));
      this.selectedIds = [...existing];
    }
  }

  toggleItem(id: string): void {
    this.selectedIds = this.selectedIds.includes(id)
      ? this.selectedIds.filter(x => x !== id)
      : [...this.selectedIds, id];
  }

  get pendingSelectedCount(): number {
    return this.page.items.filter(i => this.selectedIds.includes(i.id) && this.isPending(i)).length;
  }

  isPending(wf: ApprovalWorkflow): boolean {
    return wf.approvalStatus === 'PENDING_L1' || wf.approvalStatus === 'PENDING_L2' || wf.approvalStatus === 'PENDING_SENIOR';
  }

  // ── Row click & detail ─────────────────────────────────────────────────────

  onRowClick(wf: ApprovalWorkflow): void {
    this.selectedWorkflow = wf;
    this.detailLoading = false;
  }

  closeDetail(): void { this.selectedWorkflow = null; this.detailLoading = false; }

  onDecide(evt: ApprovalDetailDecision): void {
    this.svc.submitDecision(evt.request).subscribe(() => {
      this.closeDetail();
      this.load(true);
      const action = evt.request.decision;
      const label = action === 'approve' ? 'Approved' : action === 'reject' ? 'Rejected' : 'Decision recorded';
      if (action === 'approve') this.toastSvc.success(label, evt.request.workflowId);
      else if (action === 'reject') this.toastSvc.error(label, evt.request.workflowId);
      else this.toastSvc.info(label, evt.request.workflowId);
    });
  }

  // ── Bulk approve ──────────────────────────────────────────────────────────

  async bulkApprove(): Promise<void> {
    const pendingIds = this.page.items
      .filter(i => this.selectedIds.includes(i.id) && this.isPending(i))
      .map(i => i.id);
    const count = pendingIds.length;
    const confirmed = await this.confirmSvc.confirm({
      title: `Approve ${count} Item${count !== 1 ? 's' : ''}`,
      message: `This will approve all ${count} selected pending workflow${count !== 1 ? 's' : ''} and advance them to the next stage.`,
      confirmLabel: 'Approve All',
      count,
    });
    if (!confirmed) return;
    pendingIds.forEach(id => this.svc.submitDecision({ workflowId: id, decision: 'approve' }).subscribe());
    this.selectedIds = [];
    this.load(true);
    this.toastSvc.success(`${count} item${count !== 1 ? 's' : ''} approved`);
  }

  trackById(_: number, wf: ApprovalWorkflow): string { return wf.id; }

  statusClass(wf: ApprovalWorkflow): string {
    const m: Record<string, string> = {
      PENDING_L1: 'badge--l1', PENDING_L2: 'badge--l2', PENDING_SENIOR: 'badge--senior',
      APPROVED: 'badge--approved', REJECTED: 'badge--rejected', EXPIRED: 'badge--expired', DELEGATED: 'badge--delegated',
    };
    return m[wf.approvalStatus] ?? '';
  }

  statusLabel(wf: ApprovalWorkflow): string {
    const m: Record<string, string> = {
      PENDING_L1: 'L1 Pending', PENDING_L2: 'L2 Pending', PENDING_SENIOR: 'Senior Pending',
      APPROVED: 'Approved', REJECTED: 'Rejected', EXPIRED: 'Expired', DELEGATED: 'Delegated',
    };
    return m[wf.approvalStatus] ?? wf.approvalStatus;
  }

  railClass(rail: Rail): string { return `rail--${rail.toLowerCase()}`; }

  slaClass(wf: ApprovalWorkflow): string { return `sla--${wf.slaStatus}`; }

  priorityClass(p: QueuePriority): string { return `pri--${p.toLowerCase()}`; }

  formatAmount(a: number, c: string): string {
    if (a >= 1_000_000) return `${(a / 1_000_000).toFixed(2)}M ${c}`;
    if (a >= 1_000)     return `${(a / 1_000).toFixed(1)}K ${c}`;
    return `${a.toLocaleString()} ${c}`;
  }

  formatSla(wf: ApprovalWorkflow): string {
    const m = wf.slaMinutesRemaining;
    if (m < 0) return `${Math.abs(m)}m overdue`;
    if (m < 60) return `${m}m left`;
    return `${Math.floor(m / 60)}h ${m % 60}m left`;
  }
}
