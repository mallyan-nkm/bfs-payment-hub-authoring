import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ApprovalWorkflow, ApprovalStatus, ApprovalStep, ApprovalDecisionRequest,
  Rail, QueuePriority, QueueItemType, ComplianceSeverity
} from '../../../shared/types';

export interface ApprovalDetailDecision {
  request: ApprovalDecisionRequest;
}

@Component({
  selector: 'app-approval-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './approval-detail.component.html',
  styleUrls: ['./approval-detail.component.scss']
})
export class ApprovalDetailComponent implements OnChanges {
  @Input() workflow: ApprovalWorkflow | null = null;
  @Input() isLoading = false;
  @Input() availableApprovers: string[] = [];
  @Output() closePanel = new EventEmitter<void>();
  @Output() decide     = new EventEmitter<ApprovalDetailDecision>();

  activeTab: 'detail' | 'chain' | 'compliance' = 'detail';
  pendingDecision: 'approve' | 'reject' | 'delegate' | null = null;
  reason = '';
  delegateTo = '';

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['workflow'] && this.workflow) {
      this.activeTab = 'detail';
      this.pendingDecision = null;
      this.reason = '';
      this.delegateTo = '';
    }
  }

  get isPending(): boolean {
    return this.workflow?.approvalStatus === ApprovalStatus.PENDING_L1
      || this.workflow?.approvalStatus === ApprovalStatus.PENDING_L2
      || this.workflow?.approvalStatus === ApprovalStatus.PENDING_SENIOR;
  }

  get isTerminal(): boolean {
    const s = this.workflow?.approvalStatus;
    return s === ApprovalStatus.APPROVED || s === ApprovalStatus.REJECTED || s === ApprovalStatus.EXPIRED;
  }

  get currentStep(): ApprovalStep | null {
    if (!this.workflow) return null;
    return this.workflow.steps.find(s => s.status === 'pending') ?? null;
  }

  startDecision(d: 'approve' | 'reject' | 'delegate'): void {
    this.pendingDecision = d;
    this.reason = '';
    this.delegateTo = '';
  }

  cancelDecision(): void { this.pendingDecision = null; this.reason = ''; this.delegateTo = ''; }

  confirmDecision(): void {
    if (!this.workflow || !this.pendingDecision) return;
    const needsReason = this.pendingDecision === 'reject' && !this.reason.trim();
    const needsDelegate = this.pendingDecision === 'delegate' && !this.delegateTo.trim();
    if (needsReason || needsDelegate) return;
    this.decide.emit({
      request: {
        workflowId: this.workflow.id,
        decision: this.pendingDecision,
        reason: this.reason.trim() || undefined,
        delegateTo: this.delegateTo.trim() || undefined,
      }
    });
    this.pendingDecision = null;
  }

  stepStatusClass(step: ApprovalStep): string { return `step--${step.status}`; }

  statusLabel(status: ApprovalStatus): string {
    const m: Record<ApprovalStatus, string> = {
      [ApprovalStatus.PENDING_L1]:     'Pending L1',
      [ApprovalStatus.PENDING_L2]:     'Pending L2',
      [ApprovalStatus.PENDING_SENIOR]: 'Pending Senior',
      [ApprovalStatus.APPROVED]:       'Approved',
      [ApprovalStatus.REJECTED]:       'Rejected',
      [ApprovalStatus.EXPIRED]:        'Expired',
      [ApprovalStatus.DELEGATED]:      'Delegated',
    };
    return m[status] ?? status;
  }

  statusClass(status: ApprovalStatus): string {
    const m: Record<ApprovalStatus, string> = {
      [ApprovalStatus.PENDING_L1]:     'badge--l1',
      [ApprovalStatus.PENDING_L2]:     'badge--l2',
      [ApprovalStatus.PENDING_SENIOR]: 'badge--senior',
      [ApprovalStatus.APPROVED]:       'badge--approved',
      [ApprovalStatus.REJECTED]:       'badge--rejected',
      [ApprovalStatus.EXPIRED]:        'badge--expired',
      [ApprovalStatus.DELEGATED]:      'badge--delegated',
    };
    return m[status] ?? '';
  }

  railClass(rail: Rail): string { return `rail--${rail.toLowerCase()}`; }
  priorityClass(p: QueuePriority): string { return `pri--${p.toLowerCase()}`; }
  severityClass(s: ComplianceSeverity): string { return `sev--${s}`; }

  slaClass(wf: ApprovalWorkflow): string { return `sla--${wf.slaStatus}`; }

  formatAmount(amount: number, currency: string): string {
    return new Intl.NumberFormat('en-AE', { style: 'currency', currency, maximumFractionDigits: 2 }).format(amount);
  }

  formatTs(d: Date): string {
    return new Intl.DateTimeFormat('en-AE', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: false
    }).format(d);
  }

  stepIcon(step: ApprovalStep): string {
    return { approved: '✓', rejected: '✕', pending: '○', skipped: '–' }[step.status] ?? '○';
  }
}
