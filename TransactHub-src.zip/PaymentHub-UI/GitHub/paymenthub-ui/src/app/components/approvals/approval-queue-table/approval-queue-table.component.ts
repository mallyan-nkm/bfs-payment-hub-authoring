import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ApprovalWorkflow, ApprovalStatus, ApprovalSort, ApprovalStep,
  QueuePriority, Rail, QueueItemType, SlaStatus
} from '../../../shared/types';

@Component({
  selector: 'app-approval-queue-table',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './approval-queue-table.component.html',
  styleUrls: ['./approval-queue-table.component.scss']
})
export class ApprovalQueueTableComponent implements OnChanges {
  @Input({ required: true }) items: ApprovalWorkflow[] = [];
  @Input() totalCount = 0;
  @Input() filteredCount = 0;
  @Input() currentPage = 1;
  @Input() pageSize = 25;
  @Input() sort: ApprovalSort = { column: 'submittedAt', direction: 'desc' };
  @Input() isLoading = false;

  @Output() sortChange      = new EventEmitter<ApprovalSort>();
  @Output() pageChange      = new EventEmitter<number>();
  @Output() pageSizeChange  = new EventEmitter<number>();
  @Output() selectionChange = new EventEmitter<string[]>();
  @Output() rowClick        = new EventEmitter<ApprovalWorkflow>();
  @Output() quickDecide     = new EventEmitter<{ action: 'approve' | 'reject'; item: ApprovalWorkflow }>();

  selectedIds = new Set<string>();
  hoveredRowId: string | null = null;
  readonly pageSizeOptions = [10, 25, 50, 100];

  // ─── Lifecycle ────────────────────────────────────────────────────────────

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['items']) {
      const ids = new Set(this.items.map(i => i.id));
      this.selectedIds.forEach(id => { if (!ids.has(id)) this.selectedIds.delete(id); });
    }
  }

  // ─── Tracking ─────────────────────────────────────────────────────────────

  trackById(_: number, item: ApprovalWorkflow): string {
    return item.id;
  }

  // ─── Sort ─────────────────────────────────────────────────────────────────

  sortIndicator(col: keyof ApprovalWorkflow): string {
    if (this.sort.column !== col) return '';
    return this.sort.direction === 'asc' ? '↑' : '↓';
  }

  onSort(col: keyof ApprovalWorkflow): void {
    const direction = this.sort.column === col && this.sort.direction === 'asc' ? 'desc' : 'asc';
    this.sortChange.emit({ column: col, direction });
  }

  // ─── Selection ────────────────────────────────────────────────────────────

  get allPageSelected(): boolean {
    return this.items.length > 0 && this.items.every(i => this.selectedIds.has(i.id));
  }

  get somePageSelected(): boolean {
    return this.items.some(i => this.selectedIds.has(i.id)) && !this.allPageSelected;
  }

  toggleAll(): void {
    if (this.allPageSelected) {
      this.items.forEach(i => this.selectedIds.delete(i.id));
    } else {
      this.items.forEach(i => this.selectedIds.add(i.id));
    }
    this.emitSelection();
  }

  toggleRow(id: string, event: Event): void {
    event.stopPropagation();
    this.selectedIds.has(id) ? this.selectedIds.delete(id) : this.selectedIds.add(id);
    this.emitSelection();
  }

  emitSelection(): void {
    this.selectionChange.emit([...this.selectedIds]);
  }

  // ─── Pagination ───────────────────────────────────────────────────────────

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.filteredCount / this.pageSize));
  }

  get pageNumbers(): number[] {
    const total = this.totalPages;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: number[] = [1];
    if (this.currentPage > 3) pages.push(-1);
    for (let p = Math.max(2, this.currentPage - 1); p <= Math.min(total - 1, this.currentPage + 1); p++) {
      pages.push(p);
    }
    if (this.currentPage < total - 2) pages.push(-1);
    pages.push(total);
    return pages;
  }

  goToPage(p: number): void {
    if (p > 0 && p <= this.totalPages) this.pageChange.emit(p);
  }

  onPageSizeChange(v: string): void {
    this.pageSizeChange.emit(+v);
  }

  get rangeStart(): number {
    return (this.currentPage - 1) * this.pageSize + 1;
  }

  get rangeEnd(): number {
    return Math.min(this.currentPage * this.pageSize, this.filteredCount);
  }

  // ─── Row actions ─────────────────────────────────────────────────────────

  onRowClick(item: ApprovalWorkflow): void {
    this.rowClick.emit(item);
  }

  onQuickDecide(action: 'approve' | 'reject', item: ApprovalWorkflow, event: Event): void {
    event.stopPropagation();
    this.quickDecide.emit({ action, item });
  }

  isPending(wf: ApprovalWorkflow): boolean {
    return (
      wf.approvalStatus === ApprovalStatus.PENDING_L1 ||
      wf.approvalStatus === ApprovalStatus.PENDING_L2 ||
      wf.approvalStatus === ApprovalStatus.PENDING_SENIOR
    );
  }

  // ─── Level helpers ────────────────────────────────────────────────────────

  levelLabel(wf: ApprovalWorkflow): string {
    if (wf.currentLevel === 3) return 'Senior';
    if (wf.currentLevel === 2) return 'L2';
    return 'L1';
  }

  levelClass(wf: ApprovalWorkflow): string {
    if (wf.currentLevel === 3) return 'lvl--senior';
    if (wf.currentLevel === 2) return 'lvl--l2';
    return 'lvl--l1';
  }

  // ─── CSS class helpers ────────────────────────────────────────────────────

  statusClass(status: ApprovalStatus): string {
    const m: Record<ApprovalStatus, string> = {
      [ApprovalStatus.PENDING_L1]:     'astatus--pending-l1',
      [ApprovalStatus.PENDING_L2]:     'astatus--pending-l2',
      [ApprovalStatus.PENDING_SENIOR]: 'astatus--pending-senior',
      [ApprovalStatus.APPROVED]:       'astatus--approved',
      [ApprovalStatus.REJECTED]:       'astatus--rejected',
      [ApprovalStatus.EXPIRED]:        'astatus--expired',
      [ApprovalStatus.DELEGATED]:      'astatus--delegated',
    };
    return m[status] ?? '';
  }

  railClass(rail: Rail): string {
    return `rail--${rail.toLowerCase()}`;
  }

  slaClass(wf: ApprovalWorkflow): string {
    return `sla--${wf.slaStatus}`;
  }

  priorityClass(p: QueuePriority): string {
    return `pri--${p.toLowerCase()}`;
  }

  typeLabel(type: QueueItemType): string {
    const m: Record<QueueItemType, string> = {
      [QueueItemType.PAYMENT]:        'Pymt',
      [QueueItemType.RECALL]:         'Recall',
      [QueueItemType.RETURN]:         'Return',
      [QueueItemType.EXCEPTION]:      'Exc',
      [QueueItemType.APPROVAL]:       'Appr',
      [QueueItemType.ENQUIRY]:        'Enq',
      [QueueItemType.REFUND_REQUEST]: 'Refund',
    };
    return m[type] ?? type;
  }

  // ─── Amount formatting ────────────────────────────────────────────────────

  formatAmount(amount: number, currency: string): string {
    if (amount >= 1_000_000) return `${(amount / 1_000_000).toFixed(2)}M ${currency}`;
    if (amount >= 1_000) return `${(amount / 1_000).toFixed(1)}K ${currency}`;
    return `${amount.toLocaleString()} ${currency}`;
  }

  // ─── Age formatting ───────────────────────────────────────────────────────

  ageLabel(wf: ApprovalWorkflow): string {
    const diffMs = Date.now() - new Date(wf.submittedAt).getTime();
    const minutes = Math.floor(diffMs / 60_000);
    if (minutes < 60) return `${minutes}m ago`;
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return m > 0 ? `${h}h ${m}m ago` : `${h}h ago`;
  }

  // ─── SLA label ────────────────────────────────────────────────────────────

  slaLabel(wf: ApprovalWorkflow): string {
    const min = wf.slaMinutesRemaining;
    if (min < 0) return `${Math.abs(min)}m overdue`;
    if (min < 60) return `${min}m`;
    const h = Math.floor(min / 60);
    const m = min % 60;
    return m > 0 ? `${h}h ${m}m` : `${h}h`;
  }

  // ─── Step dot helpers ─────────────────────────────────────────────────────

  stepDotClass(step: ApprovalStep, wf: ApprovalWorkflow): string {
    if (step.status === 'approved') return 'dot--approved';
    if (step.status === 'rejected') return 'dot--rejected';
    if (step.level === wf.currentLevel && (step.status === 'pending' || step.status === 'skipped')) {
      return 'dot--active';
    }
    return 'dot--future';
  }
}
