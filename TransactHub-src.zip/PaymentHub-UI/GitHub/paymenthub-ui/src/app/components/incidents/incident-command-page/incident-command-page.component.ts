import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface Incident {
  id: string;
  incidentRef: string;
  title: string;
  severity: 'P1' | 'P2' | 'P3' | 'P4';
  status: 'active' | 'investigating' | 'mitigating' | 'resolved' | 'post-mortem';
  impactedRails: string[];
  startedAt: string;
  resolvedAt?: string;
  commander: string;
  teamSize: number;
  description: string;
  affectedTransactions: number;
}

@Component({
  selector: 'app-incident-command-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Incident Command Center</h1>
        <button class="btn-danger" (click)="declareIncident()">Declare Incident</button>
      </div>

      @if (activeIncidents().length > 0) {
        <div class="active-banner">
          <span class="pulse-dot"></span>
          {{ activeIncidents().length }} active incident(s)
        </div>
      }

      <div class="incident-list">
        @for (inc of incidents(); track inc.id) {
          <div class="incident-card severity--{{ inc.severity }}" [class.active]="inc.status === 'active' || inc.status === 'investigating' || inc.status === 'mitigating'">
            <div class="inc-header">
              <span class="inc-ref">{{ inc.incidentRef }}</span>
              <span class="severity-badge">{{ inc.severity }}</span>
              <span class="status-badge status--{{ inc.status }}">{{ inc.status }}</span>
            </div>
            <h3 class="inc-title">{{ inc.title }}</h3>
            <p class="inc-desc">{{ inc.description }}</p>
            <div class="inc-meta">
              <span>Commander: {{ inc.commander }}</span>
              <span>Team: {{ inc.teamSize }}</span>
              <span>Affected Txns: {{ inc.affectedTransactions | number }}</span>
            </div>
            <div class="inc-rails">
              @for (rail of inc.impactedRails; track rail) {
                <span class="rail-chip">{{ rail }}</span>
              }
            </div>
            <div class="inc-actions">
              @if (inc.status !== 'resolved' && inc.status !== 'post-mortem') {
                <button class="btn-sm" (click)="escalate(inc)">Escalate</button>
                <button class="btn-sm btn-resolve" (click)="resolve(inc)">Resolve</button>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-danger { padding: 0.5rem 1rem; background: var(--danger); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .active-banner { display: flex; align-items: center; gap: 0.5rem; padding: 0.75rem 1rem; background: rgba(248,113,113,0.1); border: 1px solid var(--danger); border-radius: 6px; color: var(--danger); font-weight: 600; margin-bottom: 1rem; }
    .pulse-dot { width: 10px; height: 10px; border-radius: 50%; background: var(--danger); animation: pulse 1.5s infinite; }
    @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }
    .incident-list { display: flex; flex-direction: column; gap: 1rem; }
    .incident-card { padding: 1.25rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; border-left: 4px solid var(--border); }
    .incident-card.active { border-left-color: var(--danger); background: rgba(248,113,113,0.02); }
    .severity--P1 { border-left-color: var(--danger); }
    .severity--P2 { border-left-color: var(--warning); }
    .severity--P3 { border-left-color: var(--accent); }
    .inc-header { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem; }
    .inc-ref { font-family: monospace; font-size: 0.75rem; color: var(--text-2); }
    .severity-badge { padding: 0.125rem 0.375rem; border-radius: 3px; font-size: 0.6875rem; font-weight: 700; background: rgba(248,113,113,0.15); color: var(--danger); }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--active { background: rgba(248,113,113,0.1); color: var(--danger); }
    .status--investigating { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--mitigating { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--resolved { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--post-mortem { background: var(--bg-3); color: var(--text-2); }
    .inc-title { margin: 0.25rem 0; font-size: 1rem; color: var(--text-0); }
    .inc-desc { margin: 0 0 0.5rem; font-size: 0.8125rem; color: var(--text-2); }
    .inc-meta { display: flex; gap: 1.5rem; font-size: 0.75rem; color: var(--text-2); margin-bottom: 0.5rem; }
    .inc-rails { display: flex; gap: 0.25rem; margin-bottom: 0.5rem; }
    .rail-chip { padding: 0.125rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; color: var(--text-1); }
    .inc-actions { display: flex; gap: 0.5rem; }
    .btn-sm { padding: 0.375rem 0.75rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.75rem; background: var(--bg-3); color: var(--text-1); }
    .btn-resolve { background: var(--success); color: #fff; border-color: var(--success); }
  `]
})
export class IncidentCommandPageComponent implements OnInit {
  private http = inject(HttpClient);
  incidents = signal<Incident[]>([]);
  activeIncidents = signal<Incident[]>([]);

  ngOnInit(): void { this.loadIncidents(); }

  private loadIncidents(): void {
    this.http.get<Incident[]>(`${environment.apiBaseUrl}/incidents`).subscribe({
      next: (data) => {
        this.incidents.set(data);
        this.activeIncidents.set(data.filter(i => i.status !== 'resolved' && i.status !== 'post-mortem'));
      },
      error: () => {}
    });
  }

  declareIncident(): void {}
  escalate(inc: Incident): void {}
  resolve(inc: Incident): void {}
}
