import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface FraudCase {
  id: string;
  caseNumber: string;
  status: 'open' | 'investigating' | 'confirmed' | 'dismissed' | 'escalated' | 'closed';
  severity: 'critical' | 'high' | 'medium' | 'low';
  fraudType: string;
  customer: string;
  amount: number;
  currency: string;
  rail: string;
  detectionMethod: string;
  assignedTo: string;
  createdAt: string;
  description: string;
}

@Component({
  selector: 'app-fraud-cases-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Fraud Cases</h1>
        <button class="btn-primary" (click)="createCase()">+ New Case</button>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterStatus" (ngModelChange)="loadCases()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="open">Open</option>
          <option value="investigating">Investigating</option>
          <option value="confirmed">Confirmed</option>
          <option value="dismissed">Dismissed</option>
          <option value="escalated">Escalated</option>
        </select>
        <select [(ngModel)]="filterSeverity" (ngModelChange)="loadCases()" class="filter-select">
          <option value="">All Severities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <input type="text" [(ngModel)]="searchQuery" placeholder="Search fraud cases..." class="filter-input" (input)="loadCases()" />
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Case #</th><th>Severity</th><th>Type</th><th>Customer</th><th>Amount</th><th>Rail</th><th>Detection</th><th>Status</th><th>Assigned</th><th>Created</th></tr>
          </thead>
          <tbody>
            @for (c of cases(); track c.id) {
              <tr [routerLink]="['/fraud/cases', c.id]" class="clickable-row">
                <td class="mono">{{ c.caseNumber }}</td>
                <td><span class="severity-badge severity--{{ c.severity }}">{{ c.severity }}</span></td>
                <td>{{ c.fraudType }}</td>
                <td>{{ c.customer }}</td>
                <td class="amount">{{ c.currency }} {{ c.amount | number }}</td>
                <td><span class="rail-badge">{{ c.rail }}</span></td>
                <td>{{ c.detectionMethod }}</td>
                <td><span class="status-badge status--{{ c.status }}">{{ c.status }}</span></td>
                <td>{{ c.assignedTo }}</td>
                <td>{{ c.createdAt }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .filter-select, .filter-input { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .clickable-row { cursor: pointer; } .clickable-row:hover { background: var(--bg-2); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .severity-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .severity--critical { background: rgba(248,113,113,0.15); color: var(--danger); }
    .severity--high { background: rgba(251,191,36,0.15); color: var(--warning); }
    .severity--medium { background: rgba(76,158,255,0.15); color: var(--accent); }
    .severity--low { background: rgba(74,222,128,0.15); color: var(--success); }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--open { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--investigating { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--confirmed { background: rgba(248,113,113,0.1); color: var(--danger); }
    .status--dismissed { background: var(--bg-3); color: var(--text-2); }
    .status--escalated { background: rgba(168,85,247,0.1); color: #a855f7; }
    .rail-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; }
    .amount { font-weight: 500; }
  `]
})
export class FraudCasesPageComponent implements OnInit {
  private http = inject(HttpClient);
  cases = signal<FraudCase[]>([]);
  filterStatus = '';
  filterSeverity = '';
  searchQuery = '';

  ngOnInit(): void { this.loadCases(); }

  loadCases(): void {
    this.http.get<FraudCase[]>(`${environment.apiBaseUrl}/fraud/cases`).subscribe({
      next: (data) => this.cases.set(data), error: () => {}
    });
  }

  createCase(): void {}
}
