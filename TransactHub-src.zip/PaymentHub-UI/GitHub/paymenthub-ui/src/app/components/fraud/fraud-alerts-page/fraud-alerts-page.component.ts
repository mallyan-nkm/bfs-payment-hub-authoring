import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface FraudAlert {
  id: string;
  alertType: string;
  ruleId: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  customer: string;
  transactionRef: string;
  amount: number;
  currency: string;
  rail: string;
  status: 'new' | 'acknowledged' | 'investigating' | 'dismissed';
  triggeredAt: string;
  description: string;
}

@Component({
  selector: 'app-fraud-alerts-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Fraud Alerts</h1>
        <div class="header-stats">
          <span class="stat stat--new">{{ newCount() }} new</span>
        </div>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterSeverity" (ngModelChange)="loadAlerts()" class="filter-select">
          <option value="">All Severities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <select [(ngModel)]="filterStatus" (ngModelChange)="loadAlerts()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="new">New</option>
          <option value="acknowledged">Acknowledged</option>
          <option value="investigating">Investigating</option>
          <option value="dismissed">Dismissed</option>
        </select>
      </div>

      <div class="alerts-list">
        @for (alert of alerts(); track alert.id) {
          <div class="alert-card alert--{{ alert.severity }}">
            <div class="alert-header">
              <span class="alert-type">{{ alert.alertType }}</span>
              <span class="severity-badge severity--{{ alert.severity }}">{{ alert.severity }}</span>
              <span class="alert-time">{{ alert.triggeredAt }}</span>
            </div>
            <p class="alert-desc">{{ alert.description }}</p>
            <div class="alert-meta">
              <span>Customer: {{ alert.customer }}</span>
              <span>Txn: {{ alert.transactionRef }}</span>
              <span>{{ alert.currency }} {{ alert.amount | number }}</span>
              <span class="rail-badge">{{ alert.rail }}</span>
            </div>
            <div class="alert-actions">
              @if (alert.status === 'new') {
                <button class="btn-sm" (click)="acknowledge(alert)">Acknowledge</button>
                <button class="btn-sm" (click)="createCase(alert)">Create Case</button>
                <button class="btn-sm btn--dismiss" (click)="dismissAlert(alert)">Dismiss</button>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .stat--new { color: var(--danger); font-weight: 600; font-size: 0.875rem; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .alerts-list { display: flex; flex-direction: column; gap: 0.5rem; overflow-y: auto; flex: 1; }
    .alert-card { padding: 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; border-left: 3px solid var(--border); }
    .alert--critical { border-left-color: var(--danger); }
    .alert--high { border-left-color: var(--warning); }
    .alert--medium { border-left-color: var(--accent); }
    .alert-header { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.375rem; }
    .alert-type { font-weight: 600; color: var(--text-0); font-size: 0.875rem; }
    .severity-badge { padding: 0.0625rem 0.375rem; border-radius: 3px; font-size: 0.6875rem; font-weight: 500; }
    .severity--critical { background: rgba(248,113,113,0.15); color: var(--danger); }
    .severity--high { background: rgba(251,191,36,0.15); color: var(--warning); }
    .severity--medium { background: rgba(76,158,255,0.15); color: var(--accent); }
    .alert-time { font-size: 0.75rem; color: var(--text-3); margin-left: auto; }
    .alert-desc { font-size: 0.8125rem; color: var(--text-1); margin: 0 0 0.5rem; }
    .alert-meta { display: flex; gap: 1rem; font-size: 0.75rem; color: var(--text-2); margin-bottom: 0.5rem; }
    .rail-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; }
    .alert-actions { display: flex; gap: 0.5rem; }
    .btn-sm { padding: 0.25rem 0.625rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.75rem; background: var(--bg-3); color: var(--text-1); }
    .btn-sm:hover { border-color: var(--accent); }
    .btn--dismiss { color: var(--text-3); }
  `]
})
export class FraudAlertsPageComponent implements OnInit {
  private http = inject(HttpClient);
  alerts = signal<FraudAlert[]>([]);
  newCount = signal(0);
  filterSeverity = '';
  filterStatus = '';

  ngOnInit(): void { this.loadAlerts(); }

  loadAlerts(): void {
    this.http.get<FraudAlert[]>(`${environment.apiBaseUrl}/fraud/alerts`).subscribe({
      next: (data) => { this.alerts.set(data); this.newCount.set(data.filter(a => a.status === 'new').length); },
      error: () => {}
    });
  }

  acknowledge(alert: FraudAlert): void {
    this.http.post(`${environment.apiBaseUrl}/fraud/alerts/${alert.id}/acknowledge`, {}).subscribe({ next: () => this.loadAlerts() });
  }

  createCase(alert: FraudAlert): void {}

  dismissAlert(alert: FraudAlert): void {
    this.http.post(`${environment.apiBaseUrl}/fraud/alerts/${alert.id}/dismiss`, {}).subscribe({ next: () => this.loadAlerts() });
  }
}
