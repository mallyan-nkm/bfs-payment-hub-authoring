import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-fraud-case-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-container">
      <div class="page-header">
        <a routerLink="/fraud/cases" class="back-link">← Back to Cases</a>
        <h1>Fraud Case Detail</h1>
      </div>
      <div class="placeholder-content">
        <p>Fraud case detail for ID: {{ caseId }}</p>
        <p>Full investigation view with evidence timeline, transaction graph, customer history, and action panel.</p>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; }
    .page-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .back-link { color: var(--accent); text-decoration: none; font-size: 0.8125rem; }
    .placeholder-content { padding: 2rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; color: var(--text-1); }
  `]
})
export class FraudCaseDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  caseId = '';

  ngOnInit(): void {
    this.caseId = this.route.snapshot.paramMap.get('id') ?? '';
  }
}
