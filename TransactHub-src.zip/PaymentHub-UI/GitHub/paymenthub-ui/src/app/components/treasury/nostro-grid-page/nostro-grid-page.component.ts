import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface NostroPosition {
  id: string;
  accountName: string;
  counterparty: string;
  bic: string;
  currency: string;
  openingBalance: number;
  credits: number;
  debits: number;
  closingBalance: number;
  projectedBalance: number;
  minimumBalance: number;
  status: 'normal' | 'low' | 'critical' | 'excess';
  lastUpdated: string;
}

@Component({
  selector: 'app-nostro-grid-page',
  standalone: true,
  imports: [CommonModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Nostro Positions</h1>
        <div class="header-stats">
          <span class="stat">Total Accounts: {{ totalItems() }}</span>
          <span class="stat stat--alert">{{ alertCount() }} alerts</span>
        </div>
      </div>

      <div class="grid-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>Account</th><th>Counterparty</th><th>BIC</th><th>Currency</th>
              <th class="num">Opening</th><th class="num">Credits</th><th class="num">Debits</th>
              <th class="num">Closing</th><th class="num">Projected</th><th class="num">Minimum</th><th>Status</th>
            </tr>
          </thead>
          <tbody>
            @for (pos of pagedItems(); track pos.id) {
              <tr [class.row--alert]="pos.status === 'critical' || pos.status === 'low'">
                <td>{{ pos.accountName }}</td>
                <td>{{ pos.counterparty }}</td>
                <td class="mono">{{ pos.bic }}</td>
                <td><span class="currency-badge">{{ pos.currency }}</span></td>
                <td class="num">{{ pos.openingBalance | number:'1.0-0' }}</td>
                <td class="num credit">+{{ pos.credits | number:'1.0-0' }}</td>
                <td class="num debit">-{{ pos.debits | number:'1.0-0' }}</td>
                <td class="num closing">{{ pos.closingBalance | number:'1.0-0' }}</td>
                <td class="num">{{ pos.projectedBalance | number:'1.0-0' }}</td>
                <td class="num">{{ pos.minimumBalance | number:'1.0-0' }}</td>
                <td><span class="status-badge status--{{ pos.status }}">{{ pos.status }}</span></td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .header-stats { display: flex; gap: 1.5rem; }
    .stat { font-size: 0.8125rem; color: var(--text-2); }
    .stat--alert { color: var(--danger); font-weight: 600; }
    .grid-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table th.num { text-align: right; }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .data-table td.num { text-align: right; font-family: monospace; font-size: 0.75rem; }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .credit { color: var(--success); }
    .debit { color: var(--danger); }
    .closing { font-weight: 700; color: var(--text-0); }
    .currency-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; font-weight: 600; }
    .row--alert { background: rgba(248,113,113,0.04); }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--normal { background: rgba(74,222,128,0.15); color: var(--success); }
    .status--low { background: rgba(251,191,36,0.15); color: var(--warning); }
    .status--critical { background: rgba(248,113,113,0.15); color: var(--danger); }
    .status--excess { background: rgba(76,158,255,0.15); color: var(--accent); }
  `]
})
export class NostroGridPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allPositions = signal<NostroPosition[]>([]);
  pagedItems = signal<NostroPosition[]>([]);
  totalItems = signal(0);
  alertCount = signal(0);
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadPositions(); }

  private loadPositions(): void {
    let params = new HttpParams().set('page', this.currentPage).set('pageSize', this.pageSize);
    this.http.get<any>(`${environment.apiBaseUrl}/treasury/nostro`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
          this.alertCount.set(resp.alertCount ?? 0);
        } else {
          const data = Array.isArray(resp) ? resp : [];
          this.allPositions.set(data);
          this.alertCount.set(data.filter((p: NostroPosition) => p.status === 'critical' || p.status === 'low').length);
          this.applyClientPagination();
        }
      },
      error: () => {}
    });
  }

  private applyClientPagination(): void {
    const all = this.allPositions();
    this.totalItems.set(all.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(all.slice(start, start + this.pageSize));
  }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allPositions().length > 0) this.applyClientPagination();
    else this.loadPositions();
  }
}
