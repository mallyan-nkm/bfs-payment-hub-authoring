import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface FundingRequest {
  id: string;
  requestNumber: string;
  type: 'intraday' | 'overnight' | 'term' | 'emergency';
  status: 'pending' | 'approved' | 'rejected' | 'executed' | 'expired';
  currency: string;
  amount: number;
  sourceAccount: string;
  destinationAccount: string;
  requestedBy: string;
  approvedBy?: string;
  requestedAt: string;
  executeBy: string;
  reason: string;
}

@Component({
  selector: 'app-funding-page',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Funding Requests</h1>
        <button class="btn-primary" (click)="createRequest()">+ New Request</button>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterType" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Types</option>
          <option value="intraday">Intraday</option>
          <option value="overnight">Overnight</option>
          <option value="term">Term</option>
          <option value="emergency">Emergency</option>
        </select>
        <select [(ngModel)]="filterStatus" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="executed">Executed</option>
        </select>
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Request #</th><th>Type</th><th>Currency</th><th>Amount</th><th>Source</th><th>Destination</th><th>Status</th><th>Requested By</th><th>Execute By</th></tr>
          </thead>
          <tbody>
            @for (req of pagedItems(); track req.id) {
              <tr>
                <td class="mono">{{ req.requestNumber }}</td>
                <td><span class="type-badge type--{{ req.type }}">{{ req.type }}</span></td>
                <td>{{ req.currency }}</td>
                <td class="amount">{{ req.amount | number:'1.0-0' }}</td>
                <td>{{ req.sourceAccount }}</td>
                <td>{{ req.destinationAccount }}</td>
                <td><span class="status-badge status--{{ req.status }}">{{ req.status }}</span></td>
                <td>{{ req.requestedBy }}</td>
                <td>{{ req.executeBy }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .amount { font-weight: 600; font-family: monospace; }
    .type-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .type--intraday { background: rgba(76,158,255,0.1); color: var(--accent); }
    .type--overnight { background: rgba(168,85,247,0.1); color: #a855f7; }
    .type--term { background: var(--bg-3); color: var(--text-1); }
    .type--emergency { background: rgba(248,113,113,0.15); color: var(--danger); }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--pending { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--approved { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--rejected { background: rgba(248,113,113,0.1); color: var(--danger); }
    .status--executed { background: rgba(76,158,255,0.1); color: var(--accent); }
  `]
})
export class FundingPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allRequests = signal<FundingRequest[]>([]);
  pagedItems = signal<FundingRequest[]>([]);
  totalItems = signal(0);
  filterType = '';
  filterStatus = '';
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadRequests(); }

  loadRequests(): void {
    let params = new HttpParams();
    if (this.filterType) params = params.set('type', this.filterType);
    if (this.filterStatus) params = params.set('status', this.filterStatus);
    params = params.set('page', this.currentPage).set('pageSize', this.pageSize);

    this.http.get<any>(`${environment.apiBaseUrl}/treasury/funding`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
        } else {
          const data = Array.isArray(resp) ? resp : [];
          this.allRequests.set(data);
          this.applyClientPagination();
        }
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private applyClientPagination(): void {
    let filtered = this.allRequests();
    if (this.filterType) filtered = filtered.filter(r => r.type === this.filterType);
    if (this.filterStatus) filtered = filtered.filter(r => r.status === this.filterStatus);
    this.totalItems.set(filtered.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(filtered.slice(start, start + this.pageSize));
  }

  onFilterChange(): void { this.currentPage = 1; this.loadRequests(); }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allRequests().length > 0) this.applyClientPagination();
    else this.loadRequests();
  }

  createRequest(): void {}
}
