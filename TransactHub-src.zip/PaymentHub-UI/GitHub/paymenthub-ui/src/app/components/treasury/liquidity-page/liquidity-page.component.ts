import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface LiquidityPool {
  id: string;
  name: string;
  currency: string;
  totalAvailable: number;
  allocated: number;
  reserved: number;
  projectedInflows: number;
  projectedOutflows: number;
  netPosition: number;
  utilizationPercent: number;
  status: 'healthy' | 'warning' | 'critical';
}

@Component({
  selector: 'app-liquidity-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Liquidity Orchestration</h1>
      </div>

      <div class="pool-grid">
        @for (pool of pools(); track pool.id) {
          <div class="pool-card pool--{{ pool.status }}">
            <div class="pool-header">
              <span class="pool-name">{{ pool.name }}</span>
              <span class="pool-currency">{{ pool.currency }}</span>
            </div>
            <div class="pool-balance">
              <span class="balance-label">Available</span>
              <span class="balance-value">{{ pool.totalAvailable | number:'1.0-0' }}</span>
            </div>
            <div class="pool-bar">
              <div class="pool-fill" [style.width.%]="pool.utilizationPercent"></div>
            </div>
            <div class="pool-details">
              <div class="detail"><span>Allocated</span><span>{{ pool.allocated | number:'1.0-0' }}</span></div>
              <div class="detail"><span>Reserved</span><span>{{ pool.reserved | number:'1.0-0' }}</span></div>
              <div class="detail"><span>Inflows</span><span class="inflow">+{{ pool.projectedInflows | number:'1.0-0' }}</span></div>
              <div class="detail"><span>Outflows</span><span class="outflow">-{{ pool.projectedOutflows | number:'1.0-0' }}</span></div>
              <div class="detail"><span>Net</span><span [class.positive]="pool.netPosition >= 0" [class.negative]="pool.netPosition < 0">{{ pool.netPosition | number:'1.0-0' }}</span></div>
            </div>
            <div class="pool-footer">
              <span class="utilization">{{ pool.utilizationPercent }}% utilized</span>
              <span class="status-dot status-dot--{{ pool.status }}"></span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .pool-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem; }
    .pool-card { padding: 1.25rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; border-top: 3px solid var(--success); }
    .pool--warning { border-top-color: var(--warning); }
    .pool--critical { border-top-color: var(--danger); }
    .pool-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; }
    .pool-name { font-weight: 600; color: var(--text-0); font-size: 0.875rem; }
    .pool-currency { padding: 0.125rem 0.5rem; background: var(--bg-3); border-radius: 4px; font-size: 0.75rem; font-weight: 600; color: var(--text-1); }
    .pool-balance { margin-bottom: 0.5rem; }
    .balance-label { font-size: 0.6875rem; color: var(--text-3); text-transform: uppercase; }
    .balance-value { display: block; font-size: 1.5rem; font-weight: 700; color: var(--text-0); font-family: monospace; }
    .pool-bar { height: 6px; background: var(--bg-3); border-radius: 3px; margin-bottom: 0.75rem; overflow: hidden; }
    .pool-fill { height: 100%; background: var(--accent); border-radius: 3px; }
    .pool-details { display: flex; flex-direction: column; gap: 0.375rem; margin-bottom: 0.75rem; }
    .detail { display: flex; justify-content: space-between; font-size: 0.75rem; }
    .detail span:first-child { color: var(--text-3); }
    .detail span:last-child { color: var(--text-1); font-family: monospace; }
    .inflow { color: var(--success) !important; }
    .outflow { color: var(--danger) !important; }
    .positive { color: var(--success) !important; }
    .negative { color: var(--danger) !important; }
    .pool-footer { display: flex; justify-content: space-between; align-items: center; }
    .utilization { font-size: 0.75rem; color: var(--text-2); }
    .status-dot { width: 8px; height: 8px; border-radius: 50%; }
    .status-dot--healthy { background: var(--success); }
    .status-dot--warning { background: var(--warning); }
    .status-dot--critical { background: var(--danger); }
  `]
})
export class LiquidityPageComponent implements OnInit {
  private http = inject(HttpClient);
  pools = signal<LiquidityPool[]>([]);

  ngOnInit(): void {
    this.http.get<LiquidityPool[]>(`${environment.apiBaseUrl}/treasury/liquidity`).subscribe({
      next: (data) => this.pools.set(data), error: () => {}
    });
  }
}
