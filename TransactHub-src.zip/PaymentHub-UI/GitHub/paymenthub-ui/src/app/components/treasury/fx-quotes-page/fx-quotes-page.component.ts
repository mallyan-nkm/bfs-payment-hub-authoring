import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface FxQuote {
  id: string;
  currencyPair: string;
  bidRate: number;
  askRate: number;
  midRate: number;
  spread: number;
  provider: string;
  validUntil: string;
  status: 'active' | 'expired' | 'accepted' | 'rejected';
}

@Component({
  selector: 'app-fx-quotes-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>FX Quotes & Treasury</h1>
      </div>

      <div class="quotes-grid">
        @for (quote of quotes(); track quote.id) {
          <div class="quote-card" [class.expired]="quote.status === 'expired'">
            <div class="quote-pair">{{ quote.currencyPair }}</div>
            <div class="quote-rates">
              <div class="rate"><span class="rate-label">Bid</span><span class="rate-value">{{ quote.bidRate | number:'1.4-4' }}</span></div>
              <div class="rate"><span class="rate-label">Ask</span><span class="rate-value">{{ quote.askRate | number:'1.4-4' }}</span></div>
              <div class="rate"><span class="rate-label">Mid</span><span class="rate-value mid">{{ quote.midRate | number:'1.4-4' }}</span></div>
            </div>
            <div class="quote-meta">
              <span>Spread: {{ quote.spread | number:'1.2-2' }} pips</span>
              <span>{{ quote.provider }}</span>
            </div>
            <div class="quote-footer">
              <span class="status-badge status--{{ quote.status }}">{{ quote.status }}</span>
              <span class="validity">Valid until {{ quote.validUntil }}</span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .quotes-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1rem; }
    .quote-card { padding: 1.25rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; }
    .quote-card.expired { opacity: 0.6; }
    .quote-pair { font-size: 1.125rem; font-weight: 700; color: var(--text-0); margin-bottom: 0.75rem; }
    .quote-rates { display: flex; gap: 1rem; margin-bottom: 0.75rem; }
    .rate { display: flex; flex-direction: column; gap: 0.125rem; }
    .rate-label { font-size: 0.6875rem; color: var(--text-3); text-transform: uppercase; }
    .rate-value { font-size: 1rem; font-family: monospace; color: var(--text-0); font-weight: 500; }
    .rate-value.mid { color: var(--accent); }
    .quote-meta { display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--text-2); margin-bottom: 0.5rem; }
    .quote-footer { display: flex; justify-content: space-between; align-items: center; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--active { background: rgba(74,222,128,0.15); color: var(--success); }
    .status--expired { background: var(--bg-3); color: var(--text-3); }
    .status--accepted { background: rgba(76,158,255,0.1); color: var(--accent); }
    .validity { font-size: 0.6875rem; color: var(--text-3); }
  `]
})
export class FxQuotesPageComponent implements OnInit {
  private http = inject(HttpClient);
  quotes = signal<FxQuote[]>([]);

  ngOnInit(): void {
    this.http.get<FxQuote[]>(`${environment.apiBaseUrl}/treasury/fx-quotes`).subscribe({
      next: (data) => this.quotes.set(data), error: () => {}
    });
  }
}
