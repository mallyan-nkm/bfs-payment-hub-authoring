import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  username: string;
  persona: string;
  actionType: string;
  resourceType: string;
  resourceId: string;
  outcome: 'success' | 'failure' | 'denied';
  details: string;
  ipAddress: string;
  sessionId: string;
}

interface AuditFilters {
  user: string;
  actionType: string;
  resourceType: string;
  outcome: string;
  dateFrom: string;
  dateTo: string;
}

@Component({
  selector: 'app-audit-log-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="audit-page">
      <div class="page-header">
        <h1>Audit Trail</h1>
        <div class="header-actions">
          <button class="btn-export" (click)="exportCsv()">Export CSV</button>
        </div>
      </div>

      <div class="filters-panel">
        <div class="filter-row">
          <input type="text" placeholder="User..." [(ngModel)]="filters.user" (ngModelChange)="onFilterChange()" class="filter-input" />
          <select [(ngModel)]="filters.actionType" (ngModelChange)="onFilterChange()" class="filter-select">
            <option value="">All Actions</option>
            <option value="CREATE">Create</option>
            <option value="UPDATE">Update</option>
            <option value="DELETE">Delete</option>
            <option value="APPROVE">Approve</option>
            <option value="REJECT">Reject</option>
            <option value="LOGIN">Login</option>
            <option value="LOGOUT">Logout</option>
            <option value="ESCALATE">Escalate</option>
            <option value="SWITCH_PERSONA">Switch Persona</option>
            <option value="EXPORT">Export</option>
            <option value="VIEW">View</option>
          </select>
          <select [(ngModel)]="filters.resourceType" (ngModelChange)="onFilterChange()" class="filter-select">
            <option value="">All Resources</option>
            <option value="PAYMENT">Payment</option>
            <option value="EXCEPTION">Exception</option>
            <option value="APPROVAL">Approval</option>
            <option value="COMPLIANCE_CASE">Compliance Case</option>
            <option value="FRAUD_CASE">Fraud Case</option>
            <option value="CUSTOMER">Customer</option>
            <option value="COUNTERPARTY">Counterparty</option>
            <option value="REPORT">Report</option>
            <option value="CONFIG">Configuration</option>
            <option value="USER">User</option>
          </select>
          <select [(ngModel)]="filters.outcome" (ngModelChange)="onFilterChange()" class="filter-select">
            <option value="">All Outcomes</option>
            <option value="success">Success</option>
            <option value="failure">Failure</option>
            <option value="denied">Denied</option>
          </select>
          <input type="date" [(ngModel)]="filters.dateFrom" (ngModelChange)="onFilterChange()" class="filter-input filter-date" />
          <input type="date" [(ngModel)]="filters.dateTo" (ngModelChange)="onFilterChange()" class="filter-input filter-date" />
        </div>
      </div>

      <div class="results-info">
        <span>{{ totalCount() }} entries</span>
        @if (loading()) { <span class="loading-indicator">Loading...</span> }
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>User</th>
              <th>Persona</th>
              <th>Action</th>
              <th>Resource</th>
              <th>Resource ID</th>
              <th>Outcome</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            @for (entry of entries(); track entry.id) {
              <tr>
                <td class="mono timestamp">{{ entry.timestamp }}</td>
                <td>{{ entry.username }}</td>
                <td><span class="persona-badge">{{ entry.persona }}</span></td>
                <td><span class="action-badge action--{{ entry.actionType.toLowerCase() }}">{{ entry.actionType }}</span></td>
                <td>{{ entry.resourceType }}</td>
                <td class="mono">{{ entry.resourceId }}</td>
                <td><span class="outcome-badge outcome--{{ entry.outcome }}">{{ entry.outcome }}</span></td>
                <td class="details-cell" [title]="entry.details">{{ entry.details }}</td>
              </tr>
            }
            @if (entries().length === 0 && !loading()) {
              <tr><td colspan="8" class="empty-row">No audit entries found</td></tr>
            }
          </tbody>
        </table>
      </div>

      <div class="pagination">
        <button class="btn-page" [disabled]="page() <= 1" (click)="prevPage()">← Previous</button>
        <span class="page-info">Page {{ page() }} of {{ totalPages() }}</span>
        <button class="btn-page" [disabled]="page() >= totalPages()" (click)="nextPage()">Next →</button>
      </div>
    </div>
  `,
  styles: [`
    :host { display: flex; flex-direction: column; flex: 1; min-height: 0; overflow: hidden; }
    .audit-page { padding: 1.5rem; flex: 1; min-height: 0; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-export { padding: 0.375rem 0.875rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; color: var(--text-1); cursor: pointer; font-size: 0.8125rem; }
    .btn-export:hover { border-color: var(--accent); color: var(--accent); }
    .filters-panel { padding: 0.75rem; background: var(--bg-1); border: 1px solid var(--border); border-radius: 8px; margin-bottom: 0.75rem; }
    .filter-row { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    .filter-input, .filter-select {
      padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border);
      border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; min-width: 120px;
    }
    .filter-date { min-width: 140px; }
    .results-info { display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.5rem; font-size: 0.75rem; color: var(--text-2); }
    .loading-indicator { color: var(--accent); }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; text-align: left; padding: 0.5rem 0.625rem; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); z-index: 1; }
    .data-table td { padding: 0.4rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); white-space: nowrap; }
    .mono { font-family: 'JetBrains Mono', monospace; font-size: 0.75rem; }
    .timestamp { font-size: 0.6875rem; }
    .persona-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; }
    .action-badge { padding: 0.0625rem 0.375rem; border-radius: 3px; font-size: 0.6875rem; font-weight: 500; background: var(--accent-dim); color: var(--accent); }
    .action--create { background: rgba(74,222,128,0.15); color: var(--success); }
    .action--delete { background: rgba(248,113,113,0.15); color: var(--danger); }
    .action--approve { background: rgba(74,222,128,0.15); color: var(--success); }
    .action--reject { background: rgba(248,113,113,0.15); color: var(--danger); }
    .outcome-badge { padding: 0.0625rem 0.375rem; border-radius: 3px; font-size: 0.6875rem; font-weight: 500; }
    .outcome--success { background: rgba(74,222,128,0.15); color: var(--success); }
    .outcome--failure { background: rgba(248,113,113,0.15); color: var(--danger); }
    .outcome--denied { background: rgba(251,191,36,0.15); color: var(--warning); }
    .details-cell { max-width: 200px; overflow: hidden; text-overflow: ellipsis; }
    .empty-row { text-align: center; color: var(--text-3); }
    .pagination { display: flex; align-items: center; justify-content: center; gap: 1rem; padding: 0.75rem; border-top: 1px solid var(--border); }
    .btn-page { padding: 0.375rem 0.75rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); cursor: pointer; font-size: 0.8125rem; }
    .btn-page:disabled { opacity: 0.4; cursor: not-allowed; }
    .btn-page:not(:disabled):hover { border-color: var(--accent); color: var(--accent); }
    .page-info { font-size: 0.75rem; color: var(--text-2); }
  `]
})
export class AuditLogPageComponent implements OnInit {
  private http = inject(HttpClient);

  entries = signal<AuditLogEntry[]>([]);
  loading = signal(false);
  page = signal(1);
  pageSize = 50;
  totalCount = signal(0);
  totalPages = computed(() => Math.ceil(this.totalCount() / this.pageSize) || 1);

  filters: AuditFilters = { user: '', actionType: '', resourceType: '', outcome: '', dateFrom: '', dateTo: '' };

  private computed = () => Math.ceil(this.totalCount() / this.pageSize) || 1;

  ngOnInit(): void {
    this.loadEntries();
  }

  onFilterChange(): void {
    this.page.set(1);
    this.loadEntries();
  }

  prevPage(): void {
    if (this.page() > 1) { this.page.update(p => p - 1); this.loadEntries(); }
  }

  nextPage(): void {
    if (this.page() < this.totalPages()) { this.page.update(p => p + 1); this.loadEntries(); }
  }

  exportCsv(): void {
    const params = this.buildParams();
    window.open(`${environment.apiBaseUrl}/audit/export?${params.toString()}&format=csv`, '_blank');
  }

  private loadEntries(): void {
    this.loading.set(true);
    const params = this.buildParams();
    params.set('page', this.page().toString());
    params.set('pageSize', this.pageSize.toString());

    this.http.get<{ items: AuditLogEntry[]; totalCount: number }>(`${environment.apiBaseUrl}/audit?${params.toString()}`).subscribe({
      next: (res) => {
        this.entries.set(res.items);
        this.totalCount.set(res.totalCount);
        this.loading.set(false);
      },
      error: () => { this.loading.set(false); }
    });
  }

  private buildParams(): URLSearchParams {
    const params = new URLSearchParams();
    if (this.filters.user) params.set('user', this.filters.user);
    if (this.filters.actionType) params.set('actionType', this.filters.actionType);
    if (this.filters.resourceType) params.set('resourceType', this.filters.resourceType);
    if (this.filters.outcome) params.set('outcome', this.filters.outcome);
    if (this.filters.dateFrom) params.set('dateFrom', this.filters.dateFrom);
    if (this.filters.dateTo) params.set('dateTo', this.filters.dateTo);
    return params;
  }
}
