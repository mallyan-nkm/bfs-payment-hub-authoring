import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface CounterpartyProfile {
  counterpartyId: string;
  bic: string;
  name: string;
  country: string;
  city: string;
  riskRating: string;
  status: string;
  participantRails: string[];
  agreementCount: number;
  createdAt: string;
}

interface ExposureData {
  currency: string;
  currentExposure: number;
  limit: number;
  utilization: number;
}

interface SlaPerformance {
  metric: string;
  target: string;
  actual: string;
  status: 'met' | 'breached' | 'at-risk';
}

type Tab = 'profile' | 'exposure' | 'sla' | 'transactions' | 'agreements';

@Component({
  selector: 'app-counterparty-360-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="counterparty-360">
      <div class="page-header">
        <a routerLink="/counterparties" class="back-link">← Back to Search</a>
        <h1>Counterparty 360°</h1>
      </div>

      @if (loading()) {
        <div class="loading-state">Loading counterparty data...</div>
      } @else if (counterparty()) {
        <div class="profile-card">
          <div class="profile-avatar">{{ counterparty()!.name.charAt(0) }}</div>
          <div class="profile-info">
            <h2>{{ counterparty()!.name }}</h2>
            <div class="profile-meta">
              <span class="badge badge--bic">{{ counterparty()!.bic }}</span>
              <span class="badge badge--country">{{ counterparty()!.country }}</span>
              <span class="badge badge--risk" [class]="'badge--risk-' + counterparty()!.riskRating.toLowerCase()">{{ counterparty()!.riskRating }}</span>
              <span class="badge badge--status">{{ counterparty()!.status }}</span>
            </div>
            <div class="profile-details">
              <span>Rails: {{ counterparty()!.participantRails.join(', ') }}</span>
              <span>Agreements: {{ counterparty()!.agreementCount }}</span>
            </div>
          </div>
        </div>

        <div class="tab-bar">
          @for (tab of tabs; track tab.id) {
            <button class="tab-btn" [class.active]="activeTab() === tab.id" (click)="activeTab.set(tab.id)">{{ tab.label }}</button>
          }
        </div>

        <div class="tab-content">
          @switch (activeTab()) {
            @case ('profile') {
              <div class="detail-grid">
                <div class="detail-item"><label>Name</label><span>{{ counterparty()!.name }}</span></div>
                <div class="detail-item"><label>BIC</label><span>{{ counterparty()!.bic }}</span></div>
                <div class="detail-item"><label>Country</label><span>{{ counterparty()!.country }}</span></div>
                <div class="detail-item"><label>City</label><span>{{ counterparty()!.city }}</span></div>
                <div class="detail-item"><label>Risk Rating</label><span>{{ counterparty()!.riskRating }}</span></div>
                <div class="detail-item"><label>Status</label><span>{{ counterparty()!.status }}</span></div>
                <div class="detail-item"><label>Participant Rails</label><span>{{ counterparty()!.participantRails.join(', ') }}</span></div>
                <div class="detail-item"><label>Since</label><span>{{ counterparty()!.createdAt }}</span></div>
              </div>
            }
            @case ('exposure') {
              <div class="exposure-grid">
                @for (exp of exposures(); track exp.currency) {
                  <div class="exposure-card">
                    <div class="exposure-header">
                      <span class="exposure-currency">{{ exp.currency }}</span>
                      <span class="exposure-util" [class.high]="exp.utilization > 80">{{ exp.utilization }}%</span>
                    </div>
                    <div class="exposure-bar">
                      <div class="exposure-fill" [style.width.%]="exp.utilization"></div>
                    </div>
                    <div class="exposure-details">
                      <span>Current: {{ exp.currency }} {{ exp.currentExposure | number }}</span>
                      <span>Limit: {{ exp.currency }} {{ exp.limit | number }}</span>
                    </div>
                  </div>
                }
                @if (exposures().length === 0) { <div class="empty-state">No exposure data available</div> }
              </div>
            }
            @case ('sla') {
              <table class="data-table">
                <thead><tr><th>Metric</th><th>Target</th><th>Actual</th><th>Status</th></tr></thead>
                <tbody>
                  @for (sla of slaData(); track sla.metric) {
                    <tr>
                      <td>{{ sla.metric }}</td>
                      <td>{{ sla.target }}</td>
                      <td>{{ sla.actual }}</td>
                      <td><span class="sla-badge sla--{{ sla.status }}">{{ sla.status }}</span></td>
                    </tr>
                  }
                </tbody>
              </table>
            }
            @case ('transactions') {
              <div class="empty-state">Transaction history loaded from API</div>
            }
            @case ('agreements') {
              <div class="empty-state">Agreement details loaded from API</div>
            }
          }
        </div>
      } @else {
        <div class="error-state">Counterparty not found</div>
      }
    </div>
  `,
  styles: [`
    .counterparty-360 { padding: 1.5rem; max-width: 1200px; }
    .page-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .back-link { color: var(--accent); text-decoration: none; font-size: 0.8125rem; }
    .loading-state, .error-state, .empty-state { padding: 3rem; text-align: center; color: var(--text-2); }
    .profile-card {
      display: flex; align-items: center; gap: 1.25rem; padding: 1.25rem;
      background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; margin-bottom: 1.5rem;
    }
    .profile-avatar {
      width: 56px; height: 56px; border-radius: 50%; background: var(--accent-dim);
      display: flex; align-items: center; justify-content: center;
      font-size: 1.5rem; font-weight: 700; color: var(--accent);
    }
    .profile-info h2 { font-size: 1.125rem; color: var(--text-0); margin: 0 0 0.375rem; }
    .profile-meta { display: flex; gap: 0.5rem; margin-bottom: 0.375rem; flex-wrap: wrap; }
    .profile-details { display: flex; gap: 1.5rem; font-size: 0.75rem; color: var(--text-2); }
    .badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 600; }
    .badge--bic { background: var(--bg-3); color: var(--text-0); font-family: monospace; }
    .badge--country { background: var(--bg-3); color: var(--text-1); }
    .badge--status { background: rgba(74,222,128,0.15); color: var(--success); }
    .badge--risk-high { background: rgba(248,113,113,0.15); color: var(--danger); }
    .badge--risk-medium { background: rgba(251,191,36,0.15); color: var(--warning); }
    .badge--risk-low { background: rgba(74,222,128,0.15); color: var(--success); }
    .tab-bar { display: flex; gap: 0; border-bottom: 1px solid var(--border); margin-bottom: 1rem; }
    .tab-btn { padding: 0.625rem 1rem; border: none; background: none; color: var(--text-2); font-size: 0.8125rem; cursor: pointer; border-bottom: 2px solid transparent; }
    .tab-btn.active { color: var(--accent); border-bottom-color: var(--accent); }
    .detail-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1rem; }
    .detail-item { display: flex; flex-direction: column; gap: 0.25rem; }
    .detail-item label { font-size: 0.6875rem; color: var(--text-3); text-transform: uppercase; }
    .detail-item span { font-size: 0.875rem; color: var(--text-0); }
    .exposure-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
    .exposure-card { padding: 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; }
    .exposure-header { display: flex; justify-content: space-between; margin-bottom: 0.5rem; }
    .exposure-currency { font-weight: 600; color: var(--text-0); }
    .exposure-util { font-size: 0.875rem; font-weight: 600; color: var(--success); }
    .exposure-util.high { color: var(--danger); }
    .exposure-bar { height: 6px; background: var(--bg-3); border-radius: 3px; overflow: hidden; margin-bottom: 0.5rem; }
    .exposure-fill { height: 100%; background: var(--accent); border-radius: 3px; transition: width 0.3s; }
    .exposure-details { display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--text-2); }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { text-align: left; padding: 0.5rem 0.75rem; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); }
    .data-table td { padding: 0.5rem 0.75rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .sla-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .sla--met { background: rgba(74,222,128,0.15); color: var(--success); }
    .sla--breached { background: rgba(248,113,113,0.15); color: var(--danger); }
    .sla--at-risk { background: rgba(251,191,36,0.15); color: var(--warning); }
  `]
})
export class Counterparty360PageComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private http = inject(HttpClient);

  loading = signal(true);
  counterparty = signal<CounterpartyProfile | null>(null);
  exposures = signal<ExposureData[]>([]);
  slaData = signal<SlaPerformance[]>([]);
  activeTab = signal<Tab>('profile');

  tabs: { id: Tab; label: string }[] = [
    { id: 'profile', label: 'Profile' },
    { id: 'exposure', label: 'Exposure' },
    { id: 'sla', label: 'SLA Performance' },
    { id: 'transactions', label: 'Transactions' },
    { id: 'agreements', label: 'Agreements' },
  ];

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) this.loadCounterparty(id);
  }

  private loadCounterparty(id: string): void {
    this.http.get<CounterpartyProfile>(`${environment.apiBaseUrl}/counterparties/${id}`).subscribe({
      next: (data) => {
        this.counterparty.set(data);
        this.loading.set(false);
        this.loadExposure(id);
        this.loadSla(id);
      },
      error: () => { this.loading.set(false); }
    });
  }

  private loadExposure(id: string): void {
    this.http.get<ExposureData[]>(`${environment.apiBaseUrl}/counterparties/${id}/exposure`).subscribe({
      next: (data) => this.exposures.set(data),
      error: () => {}
    });
  }

  private loadSla(id: string): void {
    this.http.get<SlaPerformance[]>(`${environment.apiBaseUrl}/counterparties/${id}/sla`).subscribe({
      next: (data) => this.slaData.set(data),
      error: () => {}
    });
  }
}
