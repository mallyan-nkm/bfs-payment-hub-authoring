import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  Rail, PaymentType, PaymentTypeOption, PaymentFormData, FormFieldError,
  ApprovalTier, PaymentFeeEstimate, SubmittedTransaction, TransactionFormStep
} from '../../../shared/types';
import {
  TransactionInitiationService,
  PURPOSE_CODES, CATEGORY_PURPOSES, CURRENCIES, UAE_BANKS
} from '../../../shared/services/transaction-initiation.service';
import { ToastService } from '../../../shared/services/toast.service';
import { CopyClipboardDirective } from '../../../shared/directives/copy-clipboard.directive';

const RAIL_LABELS: Partial<Record<Rail, { label: string; desc: string; icon: string }>> = {
  [Rail.UAEFTS]: { label: 'UAEFTS',    desc: 'UAE Funds Transfer System — AED interbank', icon: 'M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5' },
  [Rail.IPI]:    { label: 'IPI / Aani', desc: 'Instant Payment Infrastructure — real-time AED',  icon: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z' },
  [Rail.IPP]:    { label: 'IPP',        desc: 'Instant Payment Platform — card & merchant', icon: 'M1 4h22v16H1z M1 10h22' },
  [Rail.WPS]:    { label: 'WPS',        desc: 'Wage Protection System — MOL salary compliance', icon: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z' },
  [Rail.SWIFT]:  { label: 'SWIFT',      desc: 'Cross-border wire transfer — FIN MT103 / MT202',  icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93V18c0-.55.45-1 1-1s1 .45 1 1v1.93c-3.06-.45-5.46-2.85-5.91-5.93H9c.55 0 1-.45 1-1s-.45-1-1-1H6.07C6.52 8.92 8.92 6.52 11 6.07V8c0 .55.45 1 1 1s1-.45 1-1V6.07c2.08.45 4.48 2.85 4.93 4.93H16c-.55 0-1 .45-1 1s.45 1 1 1h1.93c-.45 3.08-2.85 5.48-5.93 5.93z' },
};

const STEPS: { id: TransactionFormStep; label: string }[] = [
  { id: 'rail',      label: 'Rail & Type' },
  { id: 'details',   label: 'Payment Details' },
  { id: 'preview',   label: 'Preview' },
];

@Component({
  selector: 'app-new-transaction',
  standalone: true,
  imports: [CommonModule, FormsModule, CopyClipboardDirective],
  templateUrl: './new-transaction.component.html',
  styleUrls: ['./new-transaction.component.scss'],
})
export class NewTransactionComponent implements OnInit {
  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;

  readonly Rails      = [Rail.UAEFTS, Rail.IPI, Rail.IPP, Rail.WPS, Rail.SWIFT];
  readonly railMeta   = RAIL_LABELS;
  readonly steps      = STEPS;
  readonly purposeCodes = PURPOSE_CODES;
  readonly categoryPurposes = CATEGORY_PURPOSES;
  readonly currencies   = CURRENCIES;
  readonly uaeBanks     = UAE_BANKS;

  currentStep: TransactionFormStep = 'rail';
  formData!: PaymentFormData;
  errors: FormFieldError[] = [];
  paymentTypes: PaymentTypeOption[] = [];
  approvalChain: ApprovalTier[] = [];
  feeEstimate: PaymentFeeEstimate | null = null;
  submitted: SubmittedTransaction | null = null;
  submitting = false;

  constructor(
    private svc: TransactionInitiationService,
    private toastSvc: ToastService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.formData = this.svc.getDefaultForm();
  }

  // ── Step helpers ─────────────────────────────────────────────────────────────

  get stepIndex(): number {
    const idx = this.steps.findIndex(s => s.id === this.currentStep);
    return idx >= 0 ? idx : 0;
  }

  get progressPct(): number {
    if (this.currentStep === 'submitted') return 100;
    return ((this.stepIndex + 1) / this.steps.length) * 100;
  }

  isStepDone(step: TransactionFormStep): boolean {
    const order: TransactionFormStep[] = ['rail', 'details', 'preview', 'submitted'];
    return order.indexOf(step) < order.indexOf(this.currentStep);
  }

  isStepActive(step: TransactionFormStep): boolean {
    return step === this.currentStep;
  }

  // ── Rail / type selection ────────────────────────────────────────────────────

  selectRail(rail: Rail): void {
    this.formData.rail = rail;
    this.formData.paymentType = null;
    this.paymentTypes = this.svc.getPaymentTypes(rail);
    // Auto-select if only one type
    if (this.paymentTypes.length === 1) {
      this.formData.paymentType = this.paymentTypes[0].type;
    }
    // Lock currency for AED-only rails
    const locked = this.paymentTypes.find(p => p.currency);
    if (locked?.currency) this.formData.currency = locked.currency;
  }

  selectPaymentType(type: PaymentType): void {
    this.formData.paymentType = type;
    const opt = this.paymentTypes.find(p => p.type === type);
    if (opt?.currency) this.formData.currency = opt.currency;
  }

  get railLabel(): string {
    return this.formData.rail ? (RAIL_LABELS[this.formData.rail]?.label ?? '') : '';
  }

  get selectedTypeLabel(): string {
    return this.paymentTypes.find(p => p.type === this.formData.paymentType)?.label ?? '';
  }

  // ── Currency lock for certain rails ──────────────────────────────────────────

  isCurrencyLocked(): boolean {
    return this.formData.rail !== Rail.SWIFT;
  }

  // ── Field-specific visibility ─────────────────────────────────────────────────

  get isSwift(): boolean      { return this.formData.rail === Rail.SWIFT; }
  get isWps(): boolean        { return this.formData.rail === Rail.WPS; }
  get isIpi(): boolean        { return this.formData.rail === Rail.IPI; }
  get isUaefts(): boolean     { return this.formData.rail === Rail.UAEFTS; }
  get isWpsSingle(): boolean  { return this.formData.paymentType === 'wps-single'; }
  get isAlias(): boolean      { return this.formData.paymentType === 'ipi-alias'; }
  get isBatch(): boolean {
    return this.formData.paymentType === 'wps-batch'   ||
           this.formData.paymentType === 'wps-pension'  ||
           this.formData.paymentType === 'uaefts-bulk';
  }

  get aliasLabel(): string {
    switch (this.formData.ipiAliasType) {
      case 'email':          return 'Email Address (Aani Alias)';
      case 'emiratesId':     return 'Emirates ID (Aani Alias)';
      case 'tradeLicense':   return 'Trade License Number (Aani Business Alias)';
      case 'virtualAccount': return 'Virtual Account Number';
      default:               return 'Mobile Number (Aani Alias)';
    }
  }

  get aliasPlaceholder(): string {
    switch (this.formData.ipiAliasType) {
      case 'email':          return 'name@domain.com';
      case 'emiratesId':     return '784-1234-1234567-1';
      case 'tradeLicense':   return 'TL-XXXXXXXXX (Dubai/Abu Dhabi format)';
      case 'virtualAccount': return 'VAN-XXXXXXXXXXX';
      default:               return '+971501234567';
    }
  }

  get grossWageComputed(): number {
    const basic     = parseFloat(this.formData.employeeBasicSalary || '0') || 0;
    const housing   = parseFloat(this.formData.housingAllowance   || '0') || 0;
    const transport = parseFloat(this.formData.transportAllowance || '0') || 0;
    const other     = parseFloat(this.formData.otherAllowance     || '0') || 0;
    return basic + housing + transport + other;
  }

  get filteredCategoryPurposes() {
    if (!this.formData.rail) return [];
    const railStr = this.formData.rail as string;
    return this.categoryPurposes.filter(cp => cp.rails.includes(railStr));
  }

  get isCb202OrUfp(): boolean {
    return this.formData.paymentType === 'cb202' || this.formData.paymentType === 'ufp';
  }

  // ── Batch file upload ────────────────────────────────────────────────────────

  onFileSelected(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    this.formData.batchFileName    = file.name;
    this.formData.batchRecordCount = Math.max(1, Math.floor(file.size / 120));
  }

  onFileDrop(event: DragEvent): void {
    event.preventDefault();
    const file = event.dataTransfer?.files?.[0];
    if (!file) return;
    this.formData.batchFileName    = file.name;
    this.formData.batchRecordCount = Math.max(1, Math.floor(file.size / 120));
  }

  clearBatchFile(): void {
    this.formData.batchFileName    = '';
    this.formData.batchRecordCount = 0;
    if (this.fileInputRef?.nativeElement) this.fileInputRef.nativeElement.value = '';
  }

  get batchSubTypes(): { value: string; label: string }[] {
    if (this.formData.paymentType === 'wps-pension') {
      return [
        { value: 'pension',    label: 'Pension' },
        { value: 'eosb',       label: 'End of Service Gratuity (EOSB)' },
        { value: 'allowance',  label: 'Special Allowance' },
      ];
    }
    return [
      { value: 'salary',    label: 'Monthly Salary' },
      { value: 'allowance', label: 'Allowance / Bonus' },
      { value: 'eosb',      label: 'End of Service Gratuity (EOSB)' },
    ];
  }

  // ── Validation & navigation ──────────────────────────────────────────────────

  fieldError(field: string): string {
    return this.errors.find(e => e.field === field)?.message ?? '';
  }

  nextStep(): void {
    this.errors = [];
    if (this.currentStep === 'rail') {
      if (!this.formData.rail || !this.formData.paymentType) {
        this.errors = [{ field: 'rail', message: 'Please select a rail and payment type to continue.' }];
        return;
      }
      this.currentStep = 'details';
    } else if (this.currentStep === 'details') {
      this.errors = this.svc.validate(this.formData);
      if (this.errors.length > 0) return;
      this.approvalChain = this.svc.getApprovalChain(this.formData);
      this.feeEstimate   = this.svc.getFeeEstimate(this.formData);
      this.currentStep   = 'preview';
    }
  }

  prevStep(): void {
    this.errors = [];
    if (this.currentStep === 'details')  this.currentStep = 'rail';
    else if (this.currentStep === 'preview') this.currentStep = 'details';
  }

  async submit(): Promise<void> {
    this.submitting = true;
    await new Promise(r => setTimeout(r, 900));
    this.submitted  = this.svc.submit(this.formData);
    this.submitting = false;
    this.currentStep = 'submitted';
    const msg = this.submitted.approvalRequired
      ? 'Sent for approval — ' + this.submitted.reference
      : 'Payment initiated — ' + this.submitted.reference;
    this.toastSvc.success('Payment submitted', msg);
  }

  cancel(): void {
    this.router.navigate(['/operations/queues']);
  }

  newPayment(): void {
    this.formData   = this.svc.getDefaultForm();
    this.currentStep = 'rail';
    this.submitted  = null;
    this.errors     = [];
    this.paymentTypes = [];
  }

  goToQueue(): void {
    this.router.navigate(['/operations/queues']);
  }

  // ── Display helpers ───────────────────────────────────────────────────────────

  formatAmount(): string {
    const n = parseFloat(this.formData.amount);
    if (isNaN(n)) return '—';
    return n.toLocaleString('en-AE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + this.formData.currency;
  }

  bankName(bic: string): string {
    return this.uaeBanks.find(b => b.bic === bic)?.name ?? bic;
  }
}
