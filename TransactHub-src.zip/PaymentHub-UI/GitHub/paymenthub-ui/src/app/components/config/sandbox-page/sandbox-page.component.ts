import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface SandboxTransaction {
  id: string;
  type: string;
  rail: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: string;
  createdBy: string;
  testScenario: string;
}

@Component({
  selector: 'app-sandbox-page',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Sandbox & Test Transactions</h1>
        <div class="header-actions">
          <span class="env-badge">SANDBOX</span>
          <button class="btn-primary" (click)="createTestTransaction()">+ Test Transaction</button>
        </div>
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Type</th><th>Rail</th><th>Scenario</th><th>Amount</th><th>Status</th><th>Created By</th><th>Created At</th><th>Actions</th></tr>
          </thead>
          <tbody>
            @for (txn of pagedItems(); track txn.id) {
              <tr>
                <td>{{ txn.type }}</td>
                <td><span class="rail-badge">{{ txn.rail }}</span></td>
                <td>{{ txn.testScenario }}</td>
                <td class="mono">{{ txn.currency }} {{ txn.amount | number:'1.2-2' }}</td>
                <td><span class="status-badge status--{{ txn.status }}">{{ txn.status }}</span></td>
                <td>{{ txn.createdBy }}</td>
                <td>{{ txn.createdAt }}</td>
                <td>
                  <button class="btn-sm" (click)="rerun(txn)">Rerun</button>
                  <button class="btn-sm" (click)="viewLogs(txn)">Logs</button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .header-actions { display: flex; align-items: center; gap: 0.75rem; }
    .env-badge { padding: 0.25rem 0.625rem; background: rgba(251,191,36,0.15); color: var(--warning); border-radius: 4px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .rail-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; font-weight: 500; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--pending { background: var(--bg-3); color: var(--text-2); }
    .status--processing { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--completed { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--failed { background: rgba(248,113,113,0.1); color: var(--danger); }
    .btn-sm { padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.6875rem; background: var(--bg-3); color: var(--text-1); margin-right: 0.25rem; }
  `]
})
export class SandboxPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allTransactions = signal<SandboxTransaction[]>([]);
  pagedItems = signal<SandboxTransaction[]>([]);
  totalItems = signal(0);
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadData(); }

  private loadData(): void {
    let params = new HttpParams().set('page', this.currentPage).set('pageSize', this.pageSize);
    this.http.get<any>(`${environment.apiBaseUrl}/sandbox/transactions`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
        } else {
          const data = Array.isArray(resp) ? resp : [];
          this.allTransactions.set(data);
          this.applyClientPagination();
        }
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private applyClientPagination(): void {
    const all = this.allTransactions();
    this.totalItems.set(all.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(all.slice(start, start + this.pageSize));
  }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allTransactions().length > 0) this.applyClientPagination();
    else this.loadData();
  }

  createTestTransaction(): void {}
  rerun(txn: SandboxTransaction): void {}
  viewLogs(txn: SandboxTransaction): void {}
}
