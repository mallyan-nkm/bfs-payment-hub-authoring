import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface UfpEntry {
  id: string;
  cycleDate: string;
  rail: string;
  direction: 'inward' | 'outward';
  totalTransactions: number;
  totalAmount: number;
  currency: string;
  settledCount: number;
  pendingCount: number;
  failedCount: number;
  status: 'open' | 'settling' | 'settled' | 'exception';
  cutoffTime: string;
}

@Component({
  selector: 'app-ufp-register-page',
  standalone: true,
  imports: [CommonModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>UFP Register & Cycle</h1>
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Cycle Date</th><th>Rail</th><th>Direction</th><th>Txns</th><th>Amount</th><th>Settled</th><th>Pending</th><th>Failed</th><th>Status</th><th>Cutoff</th></tr>
          </thead>
          <tbody>
            @for (entry of pagedItems(); track entry.id) {
              <tr>
                <td>{{ entry.cycleDate }}</td>
                <td><span class="rail-badge">{{ entry.rail }}</span></td>
                <td>{{ entry.direction }}</td>
                <td class="num">{{ entry.totalTransactions | number }}</td>
                <td class="num">{{ entry.currency }} {{ entry.totalAmount | number:'1.0-0' }}</td>
                <td class="num success">{{ entry.settledCount }}</td>
                <td class="num warning">{{ entry.pendingCount }}</td>
                <td class="num danger">{{ entry.failedCount }}</td>
                <td><span class="status-badge status--{{ entry.status }}">{{ entry.status }}</span></td>
                <td>{{ entry.cutoffTime }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .num { text-align: right; font-family: monospace; font-size: 0.75rem; }
    .success { color: var(--success); }
    .warning { color: var(--warning); }
    .danger { color: var(--danger); }
    .rail-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; font-weight: 500; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--open { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--settling { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--settled { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--exception { background: rgba(248,113,113,0.1); color: var(--danger); }
  `]
})
export class UfpRegisterPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allEntries = signal<UfpEntry[]>([]);
  pagedItems = signal<UfpEntry[]>([]);
  totalItems = signal(0);
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadData(); }

  private loadData(): void {
    let params = new HttpParams().set('page', this.currentPage).set('pageSize', this.pageSize);
    this.http.get<any>(`${environment.apiBaseUrl}/ufp/register`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
        } else {
          const data = Array.isArray(resp) ? resp : [];
          this.allEntries.set(data);
          this.applyClientPagination();
        }
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private applyClientPagination(): void {
    const all = this.allEntries();
    this.totalItems.set(all.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(all.slice(start, start + this.pageSize));
  }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allEntries().length > 0) this.applyClientPagination();
    else this.loadData();
  }
}
