import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  events: string[];
  status: 'active' | 'inactive' | 'failing';
  lastTriggered?: string;
  successRate: number;
  secret?: string;
  retryPolicy: string;
}

@Component({
  selector: 'app-webhook-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Webhook & Corporate Integration</h1>
        <button class="btn-primary" (click)="createWebhook()">+ New Webhook</button>
      </div>

      <div class="webhook-list">
        @for (wh of webhooks(); track wh.id) {
          <div class="webhook-card" [class.failing]="wh.status === 'failing'">
            <div class="wh-header">
              <span class="wh-name">{{ wh.name }}</span>
              <span class="status-badge status--{{ wh.status }}">{{ wh.status }}</span>
            </div>
            <div class="wh-url mono">{{ wh.url }}</div>
            <div class="wh-events">
              @for (evt of wh.events; track evt) {
                <span class="event-chip">{{ evt }}</span>
              }
            </div>
            <div class="wh-meta">
              <span>Success: {{ wh.successRate }}%</span>
              <span>Retry: {{ wh.retryPolicy }}</span>
              @if (wh.lastTriggered) {
                <span>Last: {{ wh.lastTriggered }}</span>
              }
            </div>
            <div class="wh-actions">
              <button class="btn-sm" (click)="testWebhook(wh)">Test</button>
              <button class="btn-sm" (click)="editWebhook(wh)">Edit</button>
              <button class="btn-sm" (click)="toggleWebhook(wh)">{{ wh.status === 'active' ? 'Disable' : 'Enable' }}</button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .webhook-list { display: flex; flex-direction: column; gap: 0.75rem; }
    .webhook-card { padding: 1.25rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; }
    .webhook-card.failing { border-color: var(--danger); background: rgba(248,113,113,0.02); }
    .wh-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; }
    .wh-name { font-weight: 600; color: var(--text-0); font-size: 0.9375rem; }
    .wh-url { font-size: 0.75rem; color: var(--text-2); margin-bottom: 0.5rem; padding: 0.25rem 0.5rem; background: var(--bg-3); border-radius: 4px; }
    .mono { font-family: monospace; }
    .wh-events { display: flex; gap: 0.25rem; flex-wrap: wrap; margin-bottom: 0.5rem; }
    .event-chip { padding: 0.125rem 0.375rem; background: rgba(76,158,255,0.1); color: var(--accent); border-radius: 3px; font-size: 0.6875rem; }
    .wh-meta { display: flex; gap: 1rem; font-size: 0.75rem; color: var(--text-3); margin-bottom: 0.75rem; }
    .wh-actions { display: flex; gap: 0.5rem; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--active { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--inactive { background: var(--bg-3); color: var(--text-3); }
    .status--failing { background: rgba(248,113,113,0.1); color: var(--danger); }
    .btn-sm { padding: 0.25rem 0.625rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.75rem; background: var(--bg-3); color: var(--text-1); }
  `]
})
export class WebhookPageComponent implements OnInit {
  private http = inject(HttpClient);
  webhooks = signal<WebhookConfig[]>([]);

  ngOnInit(): void {
    this.http.get<WebhookConfig[]>(`${environment.apiBaseUrl}/config/webhooks`).subscribe({
      next: (data) => this.webhooks.set(data), error: () => {}
    });
  }

  createWebhook(): void {}
  editWebhook(wh: WebhookConfig): void {}
  testWebhook(wh: WebhookConfig): void {}
  toggleWebhook(wh: WebhookConfig): void {}
}
