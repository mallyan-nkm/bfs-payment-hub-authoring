import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface ConfigChange {
  id: string;
  entity: string;
  field: string;
  oldValue: string;
  newValue: string;
  changedBy: string;
  changedAt: string;
  approvedBy?: string;
  status: 'applied' | 'pending-approval' | 'rejected' | 'rolled-back';
  reason?: string;
}

@Component({
  selector: 'app-config-history-page',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Configuration Change History</h1>
      </div>

      <div class="filters-bar">
        <input class="search-input" placeholder="Filter by entity, user..." [(ngModel)]="searchQuery" (keyup.enter)="onFilterChange()">
        <select [(ngModel)]="filterStatus" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="applied">Applied</option>
          <option value="pending-approval">Pending</option>
          <option value="rejected">Rejected</option>
          <option value="rolled-back">Rolled Back</option>
        </select>
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Entity</th><th>Field</th><th>Old Value</th><th>New Value</th><th>Changed By</th><th>Changed At</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            @for (change of pagedItems(); track change.id) {
              <tr>
                <td class="entity">{{ change.entity }}</td>
                <td>{{ change.field }}</td>
                <td class="mono old-val">{{ change.oldValue }}</td>
                <td class="mono new-val">{{ change.newValue }}</td>
                <td>{{ change.changedBy }}</td>
                <td>{{ change.changedAt }}</td>
                <td><span class="status-badge status--{{ change.status }}">{{ change.status }}</span></td>
                <td>
                  @if (change.status === 'applied') {
                    <button class="btn-sm btn-rollback" (click)="rollback(change)">Rollback</button>
                  }
                  @if (change.status === 'pending-approval') {
                    <button class="btn-sm btn-approve" (click)="approve(change)">Approve</button>
                    <button class="btn-sm" (click)="reject(change)">Reject</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .search-input { flex: 1; padding: 0.5rem 0.75rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; color: var(--text-0); font-size: 0.8125rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .entity { font-weight: 500; color: var(--text-0); }
    .old-val { color: var(--danger); text-decoration: line-through; }
    .new-val { color: var(--success); }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--applied { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--pending-approval { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--rejected { background: rgba(248,113,113,0.1); color: var(--danger); }
    .status--rolled-back { background: var(--bg-3); color: var(--text-3); }
    .btn-sm { padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.6875rem; background: var(--bg-3); color: var(--text-1); margin-right: 0.25rem; }
    .btn-rollback { color: var(--warning); border-color: var(--warning); }
    .btn-approve { color: var(--success); border-color: var(--success); }
  `]
})
export class ConfigHistoryPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allChanges = signal<ConfigChange[]>([]);
  pagedItems = signal<ConfigChange[]>([]);
  totalItems = signal(0);
  searchQuery = '';
  filterStatus = '';
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadHistory(); }

  loadHistory(): void {
    let params = new HttpParams();
    if (this.searchQuery) params = params.set('search', this.searchQuery);
    if (this.filterStatus) params = params.set('status', this.filterStatus);
    params = params.set('page', this.currentPage).set('pageSize', this.pageSize);

    this.http.get<any>(`${environment.apiBaseUrl}/config/history`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
        } else {
          const data = Array.isArray(resp) ? resp : [];
          this.allChanges.set(data);
          this.applyClientPagination();
        }
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private applyClientPagination(): void {
    let filtered = this.allChanges();
    if (this.filterStatus) filtered = filtered.filter(c => c.status === this.filterStatus);
    if (this.searchQuery) {
      const q = this.searchQuery.toLowerCase();
      filtered = filtered.filter(c => c.entity.toLowerCase().includes(q) || c.changedBy.toLowerCase().includes(q));
    }
    this.totalItems.set(filtered.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(filtered.slice(start, start + this.pageSize));
  }

  onFilterChange(): void { this.currentPage = 1; this.loadHistory(); }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allChanges().length > 0) this.applyClientPagination();
    else this.loadHistory();
  }

  rollback(change: ConfigChange): void {}
  approve(change: ConfigChange): void {}
  reject(change: ConfigChange): void {}
}
