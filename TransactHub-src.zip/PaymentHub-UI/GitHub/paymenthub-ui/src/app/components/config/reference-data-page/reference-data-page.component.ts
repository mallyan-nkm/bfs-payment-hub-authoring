import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface ReferenceDataEntity {
  id: string;
  type: 'bank' | 'currency' | 'country' | 'holiday' | 'fee' | 'cutoff' | 'bic';
  code: string;
  name: string;
  status: 'active' | 'inactive' | 'pending';
  lastModified: string;
  modifiedBy: string;
}

@Component({
  selector: 'app-reference-data-page',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Reference Data Administration</h1>
        <button class="btn-primary" (click)="createEntry()">+ New Entry</button>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterType" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Types</option>
          <option value="bank">Banks</option>
          <option value="currency">Currencies</option>
          <option value="country">Countries</option>
          <option value="holiday">Holidays</option>
          <option value="fee">Fees</option>
          <option value="cutoff">Cutoffs</option>
          <option value="bic">BIC Directory</option>
        </select>
        <input class="search-input" placeholder="Search..." [(ngModel)]="searchQuery" (keyup.enter)="onFilterChange()">
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Type</th><th>Code</th><th>Name</th><th>Status</th><th>Modified</th><th>By</th><th>Actions</th></tr>
          </thead>
          <tbody>
            @for (entry of pagedItems(); track entry.id) {
              <tr>
                <td><span class="type-badge">{{ entry.type }}</span></td>
                <td class="mono">{{ entry.code }}</td>
                <td>{{ entry.name }}</td>
                <td><span class="status-badge status--{{ entry.status }}">{{ entry.status }}</span></td>
                <td>{{ entry.lastModified }}</td>
                <td>{{ entry.modifiedBy }}</td>
                <td>
                  <button class="btn-sm" (click)="edit(entry)">Edit</button>
                  <button class="btn-sm btn-danger-sm" (click)="deactivate(entry)">Deactivate</button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .search-input { flex: 1; padding: 0.5rem 0.75rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; color: var(--text-0); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .type-badge { padding: 0.125rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; font-weight: 500; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--active { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--inactive { background: var(--bg-3); color: var(--text-3); }
    .status--pending { background: rgba(251,191,36,0.1); color: var(--warning); }
    .btn-sm { padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.6875rem; background: var(--bg-3); color: var(--text-1); margin-right: 0.25rem; }
    .btn-danger-sm { color: var(--danger); border-color: var(--danger); }
  `]
})
export class ReferenceDataPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allEntries = signal<ReferenceDataEntity[]>([]);
  pagedItems = signal<ReferenceDataEntity[]>([]);
  totalItems = signal(0);
  filterType = '';
  searchQuery = '';
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadData(); }

  loadData(): void {
    let params = new HttpParams();
    if (this.filterType) params = params.set('type', this.filterType);
    if (this.searchQuery) params = params.set('search', this.searchQuery);
    params = params.set('page', this.currentPage).set('pageSize', this.pageSize);

    this.http.get<any>(`${environment.apiBaseUrl}/config/reference-data`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
        } else {
          const data = Array.isArray(resp) ? resp : [];
          this.allEntries.set(data);
          this.applyClientPagination();
        }
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private applyClientPagination(): void {
    let filtered = this.allEntries();
    if (this.filterType) filtered = filtered.filter(e => e.type === this.filterType);
    if (this.searchQuery) {
      const q = this.searchQuery.toLowerCase();
      filtered = filtered.filter(e => e.code.toLowerCase().includes(q) || e.name.toLowerCase().includes(q));
    }
    this.totalItems.set(filtered.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(filtered.slice(start, start + this.pageSize));
  }

  onFilterChange(): void { this.currentPage = 1; this.loadData(); }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allEntries().length > 0) this.applyClientPagination();
    else this.loadData();
  }

  createEntry(): void {}
  edit(entry: ReferenceDataEntity): void {}
  deactivate(entry: ReferenceDataEntity): void {}
}
