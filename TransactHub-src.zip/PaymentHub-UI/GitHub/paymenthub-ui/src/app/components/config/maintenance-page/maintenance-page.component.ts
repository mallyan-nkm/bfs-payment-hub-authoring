import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface MaintenanceWindow {
  id: string;
  title: string;
  description: string;
  scheduledStart: string;
  scheduledEnd: string;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  affectedSystems: string[];
  createdBy: string;
}

interface SystemStatus {
  service: string;
  status: 'operational' | 'degraded' | 'outage' | 'maintenance';
  latency?: number;
  lastChecked: string;
}

@Component({
  selector: 'app-maintenance-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Maintenance Window & System Status</h1>
      </div>

      <div class="two-col">
        <div class="col">
          <h2 class="section-title">System Status</h2>
          <div class="status-list">
            @for (svc of systemStatuses(); track svc.service) {
              <div class="status-row">
                <span class="status-indicator status-ind--{{ svc.status }}"></span>
                <span class="svc-name">{{ svc.service }}</span>
                <span class="svc-status">{{ svc.status }}</span>
                @if (svc.latency) {
                  <span class="svc-latency">{{ svc.latency }}ms</span>
                }
              </div>
            }
          </div>
        </div>

        <div class="col">
          <h2 class="section-title">Maintenance Windows</h2>
          <div class="window-list">
            @for (w of windows(); track w.id) {
              <div class="window-card window--{{ w.status }}">
                <div class="win-header">
                  <span class="win-title">{{ w.title }}</span>
                  <span class="status-badge status--{{ w.status }}">{{ w.status }}</span>
                </div>
                <p class="win-desc">{{ w.description }}</p>
                <div class="win-meta">
                  <span>{{ w.scheduledStart }} — {{ w.scheduledEnd }}</span>
                </div>
                <div class="win-affected">
                  @for (sys of w.affectedSystems; track sys) {
                    <span class="affected-chip">{{ sys }}</span>
                  }
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; overflow-y: auto; }
    .page-header { margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    .section-title { font-size: 0.9375rem; color: var(--text-0); margin: 0 0 1rem; }
    .status-list { display: flex; flex-direction: column; gap: 0.5rem; }
    .status-row { display: flex; align-items: center; gap: 0.75rem; padding: 0.625rem 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; }
    .status-indicator { width: 10px; height: 10px; border-radius: 50%; }
    .status-ind--operational { background: var(--success); }
    .status-ind--degraded { background: var(--warning); }
    .status-ind--outage { background: var(--danger); }
    .status-ind--maintenance { background: var(--accent); }
    .svc-name { flex: 1; font-weight: 500; color: var(--text-0); font-size: 0.8125rem; }
    .svc-status { font-size: 0.75rem; color: var(--text-2); text-transform: capitalize; }
    .svc-latency { font-size: 0.75rem; font-family: monospace; color: var(--text-3); }
    .window-list { display: flex; flex-direction: column; gap: 0.75rem; }
    .window-card { padding: 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 6px; }
    .win-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.375rem; }
    .win-title { font-weight: 600; color: var(--text-0); font-size: 0.875rem; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--scheduled { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--in-progress { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--completed { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--cancelled { background: var(--bg-3); color: var(--text-3); }
    .win-desc { margin: 0 0 0.375rem; font-size: 0.8125rem; color: var(--text-2); }
    .win-meta { font-size: 0.75rem; color: var(--text-3); margin-bottom: 0.375rem; }
    .win-affected { display: flex; gap: 0.25rem; flex-wrap: wrap; }
    .affected-chip { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; color: var(--text-1); }
  `]
})
export class MaintenancePageComponent implements OnInit {
  private http = inject(HttpClient);
  systemStatuses = signal<SystemStatus[]>([]);
  windows = signal<MaintenanceWindow[]>([]);

  ngOnInit(): void {
    this.http.get<SystemStatus[]>(`${environment.apiBaseUrl}/system/status`).subscribe({
      next: (data) => this.systemStatuses.set(data), error: () => {}
    });
    this.http.get<MaintenanceWindow[]>(`${environment.apiBaseUrl}/system/maintenance`).subscribe({
      next: (data) => this.windows.set(data), error: () => {}
    });
  }
}
