import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface SanctionsHit {
  id: string;
  transactionRef: string;
  matchType: 'exact' | 'fuzzy' | 'partial';
  matchScore: number;
  listSource: string;
  matchedName: string;
  customerName: string;
  status: 'pending' | 'confirmed' | 'false-positive' | 'escalated';
  amount: number;
  currency: string;
  rail: string;
  createdAt: string;
}

@Component({
  selector: 'app-sanctions-page',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Sanctions Hit Adjudication</h1>
        <div class="header-stats">
          <span class="stat stat--pending">{{ pendingCount() }} pending</span>
          <span class="stat stat--escalated">{{ escalatedCount() }} escalated</span>
        </div>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterStatus" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="pending">Pending Review</option>
          <option value="confirmed">Confirmed</option>
          <option value="false-positive">False Positive</option>
          <option value="escalated">Escalated</option>
        </select>
        <select [(ngModel)]="filterMatchType" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Match Types</option>
          <option value="exact">Exact</option>
          <option value="fuzzy">Fuzzy</option>
          <option value="partial">Partial</option>
        </select>
        <input type="text" [(ngModel)]="searchQuery" placeholder="Search..." class="filter-input" (input)="onFilterChange()" />
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>Transaction</th><th>Customer</th><th>Matched Name</th><th>Score</th>
              <th>List</th><th>Amount</th><th>Rail</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            @for (hit of pagedItems(); track hit.id) {
              <tr>
                <td class="mono">{{ hit.transactionRef }}</td>
                <td>{{ hit.customerName }}</td>
                <td class="match-name">{{ hit.matchedName }}</td>
                <td><span class="score" [class.high-score]="hit.matchScore >= 90">{{ hit.matchScore }}%</span></td>
                <td>{{ hit.listSource }}</td>
                <td class="amount">{{ hit.currency }} {{ hit.amount | number }}</td>
                <td><span class="rail-badge">{{ hit.rail }}</span></td>
                <td><span class="status-badge status--{{ hit.status }}">{{ hit.status }}</span></td>
                <td class="actions-cell">
                  @if (hit.status === 'pending') {
                    <button class="btn-sm btn--fp" (click)="markFalsePositive(hit)">FP</button>
                    <button class="btn-sm btn--confirm" (click)="confirm(hit)">Confirm</button>
                    <button class="btn-sm btn--escalate" (click)="escalate(hit)">↑</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .header-stats { display: flex; gap: 1rem; }
    .stat { font-size: 0.8125rem; font-weight: 600; }
    .stat--pending { color: var(--warning); }
    .stat--escalated { color: var(--danger); }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .filter-select, .filter-input { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .match-name { font-weight: 600; color: var(--warning); }
    .score { font-weight: 600; }
    .high-score { color: var(--danger); }
    .amount { font-weight: 500; }
    .rail-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--pending { background: rgba(251,191,36,0.15); color: var(--warning); }
    .status--confirmed { background: rgba(248,113,113,0.15); color: var(--danger); }
    .status--false-positive { background: rgba(74,222,128,0.15); color: var(--success); }
    .status--escalated { background: rgba(168,85,247,0.15); color: #a855f7; }
    .actions-cell { display: flex; gap: 0.25rem; }
    .btn-sm { padding: 0.25rem 0.5rem; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; font-size: 0.6875rem; font-weight: 500; }
    .btn--fp { background: rgba(74,222,128,0.1); color: var(--success); }
    .btn--confirm { background: rgba(248,113,113,0.1); color: var(--danger); }
    .btn--escalate { background: rgba(168,85,247,0.1); color: #a855f7; }
  `]
})
export class SanctionsPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allHits = signal<SanctionsHit[]>([]);
  pagedItems = signal<SanctionsHit[]>([]);
  totalItems = signal(0);
  pendingCount = signal(0);
  escalatedCount = signal(0);
  filterStatus = '';
  filterMatchType = '';
  searchQuery = '';
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadHits(); }

  loadHits(): void {
    let params = new HttpParams();
    if (this.filterStatus) params = params.set('status', this.filterStatus);
    if (this.filterMatchType) params = params.set('matchType', this.filterMatchType);
    if (this.searchQuery) params = params.set('search', this.searchQuery);
    params = params.set('page', this.currentPage).set('pageSize', this.pageSize);

    this.http.get<any>(`${environment.apiBaseUrl}/compliance/sanctions`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
          this.pendingCount.set(resp.pendingCount ?? 0);
          this.escalatedCount.set(resp.escalatedCount ?? 0);
        } else {
          const items = Array.isArray(resp) ? resp : [];
          this.allHits.set(items);
          this.pendingCount.set(items.filter((h: SanctionsHit) => h.status === 'pending').length);
          this.escalatedCount.set(items.filter((h: SanctionsHit) => h.status === 'escalated').length);
          this.applyClientPagination();
        }
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private applyClientPagination(): void {
    let filtered = this.allHits();
    if (this.filterStatus) filtered = filtered.filter(h => h.status === this.filterStatus);
    if (this.filterMatchType) filtered = filtered.filter(h => h.matchType === this.filterMatchType);
    if (this.searchQuery) {
      const q = this.searchQuery.toLowerCase();
      filtered = filtered.filter(h =>
        h.transactionRef.toLowerCase().includes(q) || h.customerName.toLowerCase().includes(q) || h.matchedName.toLowerCase().includes(q)
      );
    }
    this.totalItems.set(filtered.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(filtered.slice(start, start + this.pageSize));
  }

  onFilterChange(): void { this.currentPage = 1; this.loadHits(); }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allHits().length > 0) this.applyClientPagination();
    else this.loadHits();
  }

  markFalsePositive(hit: SanctionsHit): void {
    this.http.post(`${environment.apiBaseUrl}/compliance/sanctions/${hit.id}/false-positive`, {}).subscribe({ next: () => this.loadHits() });
  }

  confirm(hit: SanctionsHit): void {
    this.http.post(`${environment.apiBaseUrl}/compliance/sanctions/${hit.id}/confirm`, {}).subscribe({ next: () => this.loadHits() });
  }

  escalate(hit: SanctionsHit): void {
    this.http.post(`${environment.apiBaseUrl}/compliance/sanctions/${hit.id}/escalate`, {}).subscribe({ next: () => this.loadHits() });
  }
}
