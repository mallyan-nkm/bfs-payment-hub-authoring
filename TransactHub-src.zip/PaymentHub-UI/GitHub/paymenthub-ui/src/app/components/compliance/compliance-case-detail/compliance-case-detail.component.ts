import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface CaseDetail {
  id: string;
  caseNumber: string;
  type: string;
  status: string;
  severity: string;
  customer: string;
  customerId: string;
  description: string;
  assignedTo: string;
  createdAt: string;
  updatedAt: string;
  dueDate: string;
  rail: string;
  transactionRef: string;
  amount: number;
  currency: string;
  riskScore: number;
  findings: string;
  recommendation: string;
}

interface CaseTimeline {
  id: string;
  action: string;
  user: string;
  timestamp: string;
  note: string;
}

@Component({
  selector: 'app-compliance-case-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="case-detail-page">
      <div class="page-header">
        <a routerLink="/compliance/cases" class="back-link">← Back to Cases</a>
        @if (caseData()) {
          <h1>{{ caseData()!.caseNumber }}</h1>
          <div class="header-badges">
            <span class="badge severity--{{ caseData()!.severity }}">{{ caseData()!.severity }}</span>
            <span class="badge status--{{ caseData()!.status }}">{{ caseData()!.status }}</span>
          </div>
        }
      </div>

      @if (caseData()) {
        <div class="case-layout">
          <div class="case-main">
            <section class="detail-section">
              <h3>Case Information</h3>
              <div class="detail-grid">
                <div class="detail-item"><label>Type</label><span>{{ caseData()!.type }}</span></div>
                <div class="detail-item"><label>Customer</label><a [routerLink]="['/customers', caseData()!.customerId]">{{ caseData()!.customer }}</a></div>
                <div class="detail-item"><label>Assigned To</label><span>{{ caseData()!.assignedTo }}</span></div>
                <div class="detail-item"><label>Due Date</label><span>{{ caseData()!.dueDate }}</span></div>
                <div class="detail-item"><label>Transaction</label><span class="mono">{{ caseData()!.transactionRef }}</span></div>
                <div class="detail-item"><label>Amount</label><span>{{ caseData()!.currency }} {{ caseData()!.amount | number }}</span></div>
                <div class="detail-item"><label>Risk Score</label><span class="risk-score">{{ caseData()!.riskScore }}/100</span></div>
                <div class="detail-item"><label>Rail</label><span>{{ caseData()!.rail }}</span></div>
              </div>
            </section>

            <section class="detail-section">
              <h3>Description</h3>
              <p class="description-text">{{ caseData()!.description }}</p>
            </section>

            <section class="detail-section">
              <h3>Findings</h3>
              <p class="description-text">{{ caseData()!.findings || 'No findings recorded yet' }}</p>
            </section>

            <section class="detail-section">
              <h3>Add Note</h3>
              <textarea [(ngModel)]="newNote" placeholder="Enter investigation notes..." class="note-input"></textarea>
              <button class="btn-secondary" (click)="addNote()">Add Note</button>
            </section>
          </div>

          <div class="case-sidebar">
            <section class="sidebar-section">
              <h3>Actions</h3>
              <div class="action-buttons">
                <button class="btn-action btn--escalate" (click)="escalate()">Escalate</button>
                <button class="btn-action btn--approve" (click)="approve()">Approve</button>
                <button class="btn-action btn--dismiss" (click)="dismiss()">Dismiss</button>
                <button class="btn-action btn--sar" (click)="fileSar()">File SAR</button>
              </div>
            </section>

            <section class="sidebar-section">
              <h3>Timeline</h3>
              <div class="timeline">
                @for (event of timeline(); track event.id) {
                  <div class="timeline-entry">
                    <div class="timeline-dot"></div>
                    <div class="timeline-content">
                      <span class="timeline-action">{{ event.action }}</span>
                      <span class="timeline-user">{{ event.user }}</span>
                      <span class="timeline-time">{{ event.timestamp }}</span>
                      @if (event.note) { <p class="timeline-note">{{ event.note }}</p> }
                    </div>
                  </div>
                }
              </div>
            </section>
          </div>
        </div>
      } @else {
        <div class="loading-state">Loading case...</div>
      }
    </div>
  `,
  styles: [`
    .case-detail-page { padding: 1.5rem; overflow-y: auto; height: 100%; }
    .page-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; font-family: monospace; }
    .back-link { color: var(--accent); text-decoration: none; font-size: 0.8125rem; }
    .header-badges { display: flex; gap: 0.5rem; }
    .badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .severity--critical { background: rgba(248,113,113,0.15); color: var(--danger); }
    .severity--high { background: rgba(251,191,36,0.15); color: var(--warning); }
    .status--open, .status--investigating { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--escalated { background: rgba(248,113,113,0.1); color: var(--danger); }
    .case-layout { display: grid; grid-template-columns: 1fr 320px; gap: 1.5rem; }
    .case-main { display: flex; flex-direction: column; gap: 1.25rem; }
    .detail-section { padding: 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; }
    .detail-section h3 { font-size: 0.875rem; color: var(--text-0); margin: 0 0 0.75rem; }
    .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; }
    .detail-item { display: flex; flex-direction: column; gap: 0.125rem; }
    .detail-item label { font-size: 0.6875rem; color: var(--text-3); text-transform: uppercase; }
    .detail-item span, .detail-item a { font-size: 0.8125rem; color: var(--text-0); }
    .detail-item a { color: var(--accent); text-decoration: none; }
    .mono { font-family: monospace; }
    .risk-score { font-weight: 700; color: var(--warning); }
    .description-text { font-size: 0.8125rem; color: var(--text-1); line-height: 1.5; margin: 0; }
    .note-input { width: 100%; min-height: 80px; padding: 0.625rem; background: var(--bg-1); border: 1px solid var(--border); border-radius: 6px; color: var(--text-0); font-size: 0.8125rem; resize: vertical; margin-bottom: 0.5rem; }
    .btn-secondary { padding: 0.375rem 0.875rem; background: var(--bg-3); border: 1px solid var(--border); border-radius: 6px; color: var(--text-1); cursor: pointer; font-size: 0.8125rem; }
    .case-sidebar { display: flex; flex-direction: column; gap: 1rem; }
    .sidebar-section { padding: 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; }
    .sidebar-section h3 { font-size: 0.875rem; color: var(--text-0); margin: 0 0 0.75rem; }
    .action-buttons { display: flex; flex-direction: column; gap: 0.5rem; }
    .btn-action { padding: 0.5rem; border: 1px solid var(--border); border-radius: 6px; cursor: pointer; font-size: 0.8125rem; font-weight: 500; }
    .btn--escalate { background: rgba(248,113,113,0.1); color: var(--danger); border-color: rgba(248,113,113,0.3); }
    .btn--approve { background: rgba(74,222,128,0.1); color: var(--success); border-color: rgba(74,222,128,0.3); }
    .btn--dismiss { background: var(--bg-3); color: var(--text-2); }
    .btn--sar { background: rgba(168,85,247,0.1); color: #a855f7; border-color: rgba(168,85,247,0.3); }
    .timeline { display: flex; flex-direction: column; gap: 0.75rem; }
    .timeline-entry { display: flex; gap: 0.75rem; }
    .timeline-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); margin-top: 0.375rem; flex-shrink: 0; }
    .timeline-content { display: flex; flex-direction: column; gap: 0.125rem; }
    .timeline-action { font-size: 0.8125rem; font-weight: 500; color: var(--text-0); }
    .timeline-user { font-size: 0.75rem; color: var(--text-2); }
    .timeline-time { font-size: 0.6875rem; color: var(--text-3); }
    .timeline-note { font-size: 0.75rem; color: var(--text-1); margin: 0.25rem 0 0; }
    .loading-state { padding: 3rem; text-align: center; color: var(--text-2); }
  `]
})
export class ComplianceCaseDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private http = inject(HttpClient);

  caseData = signal<CaseDetail | null>(null);
  timeline = signal<CaseTimeline[]>([]);
  newNote = '';

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) this.loadCase(id);
  }

  private loadCase(id: string): void {
    this.http.get<CaseDetail>(`${environment.apiBaseUrl}/compliance/cases/${id}`).subscribe({
      next: (data) => { this.caseData.set(data); this.loadTimeline(id); },
      error: () => {}
    });
  }

  private loadTimeline(id: string): void {
    this.http.get<CaseTimeline[]>(`${environment.apiBaseUrl}/compliance/cases/${id}/timeline`).subscribe({
      next: (data) => this.timeline.set(data),
      error: () => {}
    });
  }

  addNote(): void { if (this.newNote.trim()) { this.newNote = ''; } }
  escalate(): void {}
  approve(): void {}
  dismiss(): void {}
  fileSar(): void {}
}
