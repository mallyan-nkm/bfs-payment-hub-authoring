import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface ComplianceCase {
  id: string;
  caseNumber: string;
  type: 'AML' | 'KYC' | 'SANCTIONS' | 'PEP' | 'TF' | 'OTHER';
  status: 'open' | 'investigating' | 'escalated' | 'pending-approval' | 'closed' | 'dismissed';
  severity: 'critical' | 'high' | 'medium' | 'low';
  customer: string;
  customerId: string;
  description: string;
  assignedTo: string;
  createdAt: string;
  updatedAt: string;
  dueDate: string;
  rail: string;
  transactionRef?: string;
  amount?: number;
  currency?: string;
}

@Component({
  selector: 'app-compliance-cases-page',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>Compliance Cases</h1>
        <button class="btn-primary" (click)="createCase()">+ New Case</button>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterType" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Types</option>
          <option value="AML">AML</option>
          <option value="KYC">KYC</option>
          <option value="SANCTIONS">Sanctions</option>
          <option value="PEP">PEP</option>
          <option value="TF">Terrorism Financing</option>
        </select>
        <select [(ngModel)]="filterStatus" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="open">Open</option>
          <option value="investigating">Investigating</option>
          <option value="escalated">Escalated</option>
          <option value="pending-approval">Pending Approval</option>
          <option value="closed">Closed</option>
          <option value="dismissed">Dismissed</option>
        </select>
        <select [(ngModel)]="filterSeverity" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Severities</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <input type="text" [(ngModel)]="searchQuery" placeholder="Search cases..." class="filter-input" (input)="onFilterChange()" />
      </div>

      <div class="cases-grid">
        @for (c of cases(); track c.id) {
          <div class="case-card" [routerLink]="['/compliance/cases', c.id]">
            <div class="case-header">
              <span class="case-number">{{ c.caseNumber }}</span>
              <span class="severity-badge severity--{{ c.severity }}">{{ c.severity }}</span>
            </div>
            <div class="case-type">
              <span class="type-badge type--{{ c.type.toLowerCase() }}">{{ c.type }}</span>
              <span class="status-badge status--{{ c.status }}">{{ c.status }}</span>
            </div>
            <p class="case-description">{{ c.description }}</p>
            <div class="case-meta">
              <span>Customer: {{ c.customer }}</span>
              <span>Assigned: {{ c.assignedTo }}</span>
            </div>
            <div class="case-footer">
              <span class="case-date">{{ c.createdAt }}</span>
              @if (c.amount) { <span class="case-amount">{{ c.currency }} {{ c.amount | number }}</span> }
            </div>
          </div>
        }
        @if (cases().length === 0 && !loading()) {
          <div class="empty-state">No compliance cases found</div>
        }
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; overflow: hidden; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; font-size: 0.8125rem; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; flex-wrap: wrap; }
    .filter-select, .filter-input { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .filter-input { min-width: 200px; }
    .cases-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 0.75rem; overflow-y: auto; flex: 1; align-content: start; }
    .case-card { padding: 1rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; cursor: pointer; transition: border-color 0.15s; display: flex; flex-direction: column; gap: 0.5rem; }
    .case-card:hover { border-color: var(--accent); }
    .case-header { display: flex; justify-content: space-between; align-items: center; }
    .case-number { font-family: monospace; font-size: 0.8125rem; font-weight: 600; color: var(--text-0); }
    .case-type { display: flex; gap: 0.5rem; }
    .type-badge, .status-badge, .severity-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .severity--critical { background: rgba(248,113,113,0.15); color: var(--danger); }
    .severity--high { background: rgba(251,191,36,0.15); color: var(--warning); }
    .severity--medium { background: rgba(76,158,255,0.15); color: var(--accent); }
    .severity--low { background: rgba(74,222,128,0.15); color: var(--success); }
    .type--aml { background: rgba(248,113,113,0.1); color: #f87171; }
    .type--kyc { background: rgba(251,191,36,0.1); color: #fbbf24; }
    .type--sanctions { background: rgba(168,85,247,0.1); color: #a855f7; }
    .type--pep { background: rgba(76,158,255,0.1); color: var(--accent); }
    .type--tf { background: rgba(248,113,113,0.15); color: var(--danger); }
    .status--open { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--investigating { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--escalated { background: rgba(248,113,113,0.1); color: var(--danger); }
    .status--closed { background: rgba(74,222,128,0.1); color: var(--success); }
    .case-description { font-size: 0.8125rem; color: var(--text-1); line-height: 1.4; margin: 0; }
    .case-meta { display: flex; gap: 1rem; font-size: 0.75rem; color: var(--text-2); }
    .case-footer { display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--text-3); }
    .case-amount { font-weight: 600; color: var(--text-1); }
    .empty-state { grid-column: 1 / -1; padding: 3rem; text-align: center; color: var(--text-2); }
  `]
})
export class ComplianceCasesPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allCases = signal<ComplianceCase[]>([]);
  cases = signal<ComplianceCase[]>([]);
  totalItems = signal(0);
  loading = signal(false);
  filterType = '';
  filterStatus = '';
  filterSeverity = '';
  searchQuery = '';
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadCases(); }

  loadCases(): void {
    this.loading.set(true);
    let params = new HttpParams();
    if (this.filterType) params = params.set('type', this.filterType);
    if (this.filterStatus) params = params.set('status', this.filterStatus);
    if (this.filterSeverity) params = params.set('severity', this.filterSeverity);
    if (this.searchQuery) params = params.set('q', this.searchQuery);
    params = params.set('page', this.currentPage).set('pageSize', this.pageSize);

    this.http.get<any>(`${environment.apiBaseUrl}/compliance/cases`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.cases.set(resp.items);
          this.totalItems.set(resp.total);
        } else {
          // Backend returns flat array — paginate client-side
          const items = Array.isArray(resp) ? resp : [];
          this.allCases.set(items);
          this.applyClientPagination();
        }
        this.loading.set(false);
      },
      error: () => { this.loading.set(false); }
    });
  }

  private applyClientPagination(): void {
    let filtered = this.allCases();
    if (this.filterType) filtered = filtered.filter(c => c.type === this.filterType);
    if (this.filterStatus) filtered = filtered.filter(c => c.status === this.filterStatus);
    if (this.filterSeverity) filtered = filtered.filter(c => c.severity === this.filterSeverity);
    if (this.searchQuery) {
      const q = this.searchQuery.toLowerCase();
      filtered = filtered.filter(c =>
        c.caseNumber.toLowerCase().includes(q) || c.customer.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)
      );
    }
    this.totalItems.set(filtered.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.cases.set(filtered.slice(start, start + this.pageSize));
  }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allCases().length > 0) {
      this.applyClientPagination();
    } else {
      this.loadCases();
    }
  }

  onFilterChange(): void { this.currentPage = 1; this.loadCases(); }

  createCase(): void {
    // Opens case creation modal/wizard
  }
}
