import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { PaginationComponent, PageEvent } from '../../../shared/components/pagination/pagination.component';

interface SarReport {
  id: string;
  reportNumber: string;
  type: 'SAR' | 'STR';
  status: 'draft' | 'review' | 'submitted' | 'acknowledged' | 'returned';
  caseRef: string;
  customer: string;
  filingDeadline: string;
  createdBy: string;
  createdAt: string;
  submittedAt?: string;
  regulatoryBody: string;
}

@Component({
  selector: 'app-sar-str-page',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent],
  template: `
    <div class="page-container">
      <div class="page-header">
        <h1>SAR/STR Filing</h1>
        <button class="btn-primary" (click)="createReport()">+ New Report</button>
      </div>

      <div class="filters-bar">
        <select [(ngModel)]="filterType" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Types</option>
          <option value="SAR">SAR</option>
          <option value="STR">STR</option>
        </select>
        <select [(ngModel)]="filterStatus" (ngModelChange)="onFilterChange()" class="filter-select">
          <option value="">All Statuses</option>
          <option value="draft">Draft</option>
          <option value="review">Under Review</option>
          <option value="submitted">Submitted</option>
          <option value="acknowledged">Acknowledged</option>
          <option value="returned">Returned</option>
        </select>
      </div>

      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr><th>Report #</th><th>Type</th><th>Status</th><th>Case</th><th>Customer</th><th>Deadline</th><th>Regulatory Body</th><th>Created</th></tr>
          </thead>
          <tbody>
            @for (r of pagedItems(); track r.id) {
              <tr>
                <td class="mono">{{ r.reportNumber }}</td>
                <td><span class="type-badge type--{{ r.type.toLowerCase() }}">{{ r.type }}</span></td>
                <td><span class="status-badge status--{{ r.status }}">{{ r.status }}</span></td>
                <td class="mono">{{ r.caseRef }}</td>
                <td>{{ r.customer }}</td>
                <td [class.overdue]="isOverdue(r)">{{ r.filingDeadline }}</td>
                <td>{{ r.regulatoryBody }}</td>
                <td>{{ r.createdAt }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <app-pagination
        [currentPage]="currentPage"
        [pageSize]="pageSize"
        [totalItems]="totalItems()"
        (pageChange)="onPageChange($event)">
      </app-pagination>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; height: 100%; display: flex; flex-direction: column; }
    .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .btn-primary { padding: 0.5rem 1rem; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; }
    .filters-bar { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
    .filter-select { padding: 0.375rem 0.625rem; background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px; color: var(--text-1); font-size: 0.8125rem; }
    .table-container { flex: 1; overflow: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { position: sticky; top: 0; padding: 0.5rem 0.625rem; text-align: left; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); background: var(--bg-1); }
    .data-table td { padding: 0.5rem 0.625rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: monospace; font-size: 0.75rem; }
    .type-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 600; }
    .type--sar { background: rgba(248,113,113,0.15); color: var(--danger); }
    .type--str { background: rgba(168,85,247,0.15); color: #a855f7; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--draft { background: var(--bg-3); color: var(--text-2); }
    .status--review { background: rgba(251,191,36,0.1); color: var(--warning); }
    .status--submitted { background: rgba(76,158,255,0.1); color: var(--accent); }
    .status--acknowledged { background: rgba(74,222,128,0.1); color: var(--success); }
    .status--returned { background: rgba(248,113,113,0.1); color: var(--danger); }
    .overdue { color: var(--danger); font-weight: 600; }
  `]
})
export class SarStrPageComponent implements OnInit {
  private http = inject(HttpClient);

  private allReports = signal<SarReport[]>([]);
  pagedItems = signal<SarReport[]>([]);
  totalItems = signal(0);
  filterType = '';
  filterStatus = '';
  currentPage = 1;
  pageSize = 25;

  ngOnInit(): void { this.loadReports(); }

  loadReports(): void {
    let params = new HttpParams();
    if (this.filterType) params = params.set('type', this.filterType);
    if (this.filterStatus) params = params.set('status', this.filterStatus);
    params = params.set('page', this.currentPage).set('pageSize', this.pageSize);

    this.http.get<any>(`${environment.apiBaseUrl}/compliance/sar`, { params }).subscribe({
      next: (resp) => {
        if (resp && resp.items) {
          this.pagedItems.set(resp.items);
          this.totalItems.set(resp.total);
        } else {
          const items = Array.isArray(resp) ? resp : [];
          this.allReports.set(items);
          this.applyClientPagination();
        }
      },
      error: () => { this.pagedItems.set([]); this.totalItems.set(0); }
    });
  }

  private applyClientPagination(): void {
    let filtered = this.allReports();
    if (this.filterType) filtered = filtered.filter(r => r.type === this.filterType);
    if (this.filterStatus) filtered = filtered.filter(r => r.status === this.filterStatus);
    this.totalItems.set(filtered.length);
    const start = (this.currentPage - 1) * this.pageSize;
    this.pagedItems.set(filtered.slice(start, start + this.pageSize));
  }

  onPageChange(event: PageEvent): void {
    this.currentPage = event.page;
    this.pageSize = event.pageSize;
    if (this.allReports().length > 0) this.applyClientPagination();
    else this.loadReports();
  }

  onFilterChange(): void { this.currentPage = 1; this.loadReports(); }
  createReport(): void {}

  isOverdue(r: SarReport): boolean {
    return r.status !== 'submitted' && r.status !== 'acknowledged' && new Date(r.filingDeadline) < new Date();
  }
}
