import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ExceptionItem, ExceptionFilter, ExceptionPage, ExceptionSort,
  ExceptionQueueTab, ExceptionSummary, ExceptionTrendPoint,
  ExceptionSeverity, ExceptionStatus, ExceptionQueue, Rail, SlaStatus
} from '../../../shared/types';
import { ExceptionService, CodeStat, RailStat } from '../../../shared/services/exception.service';
import { ToastService } from '../../../shared/services/toast.service';
import { ConfirmService } from '../../../shared/services/confirm.service';
import { ExportService } from '../../../shared/services/export.service';
import { SvgIconComponent } from '../../../shared/components/svg-icon/svg-icon.component';
import { CopyClipboardDirective } from '../../../shared/directives/copy-clipboard.directive';
import { CountUpDirective } from '../../../shared/directives/count-up.directive';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
import { DataFreshnessComponent } from '../../../shared/components/data-freshness/data-freshness.component';

const QUEUE_LABELS: Record<ExceptionQueue, string> = {
  [ExceptionQueue.ALL]:           'All Exceptions',
  [ExceptionQueue.PAYMENTS_L1]:   'Payments L1',
  [ExceptionQueue.PAYMENTS_L2]:   'Payments L2',
  [ExceptionQueue.COMPLIANCE_L1]: 'Compliance L1',
  [ExceptionQueue.COMPLIANCE_L2]: 'Compliance L2',
  [ExceptionQueue.FRAUD_OPS]:     'Fraud Ops',
  [ExceptionQueue.RECONCILIATION]:'Reconciliation',
  [ExceptionQueue.WPS_OPS]:       'WPS Ops',
  [ExceptionQueue.CORRESPONDENT]: 'Correspondent',
  [ExceptionQueue.INVESTIGATION]: 'Investigation',
};

const STATUS_LABELS: Record<ExceptionStatus, string> = {
  [ExceptionStatus.OPEN]:         'Open',
  [ExceptionStatus.IN_TRIAGE]:    'In Triage',
  [ExceptionStatus.HELD]:         'Held',
  [ExceptionStatus.ESCALATED]:    'Escalated',
  [ExceptionStatus.RESOLVED]:     'Resolved',
  [ExceptionStatus.AUTO_RESOLVED]:'Auto-Resolved',
  [ExceptionStatus.REJECTED]:     'Rejected',
};

@Component({
  selector: 'app-exceptions-page',
  standalone: true,
  imports: [CommonModule, FormsModule, SvgIconComponent, CopyClipboardDirective, CountUpDirective, EmptyStateComponent, DataFreshnessComponent],
  templateUrl: './exceptions-page.component.html',
  styleUrls: ['./exceptions-page.component.scss']
})
export class ExceptionsPageComponent implements OnInit, OnDestroy {
  readonly ExceptionSeverity = ExceptionSeverity;
  readonly ExceptionStatus   = ExceptionStatus;
  readonly ExceptionQueue    = ExceptionQueue;

  readonly severities = [ExceptionSeverity.CRITICAL, ExceptionSeverity.HIGH, ExceptionSeverity.MEDIUM, ExceptionSeverity.LOW];
  readonly rails      = [Rail.UAEFTS, Rail.IPI, Rail.IPP, Rail.WPS, Rail.SWIFT];

  activeTab: 'queue' | 'tracking' = 'queue';

  filter: ExceptionFilter = this.exSvc.getDefaultFilter();
  sort: ExceptionSort = { column: 'createdAt', direction: 'desc' };
  page     = 0;
  pageSize = 25;
  railFilter = '';

  queuePage: ExceptionPage    = { items: [], totalCount: 0, filteredCount: 0, page: 0, pageSize: 25 };
  queueTabs: ExceptionQueueTab[] = [];
  summary:   ExceptionSummary | null = null;
  trend:     ExceptionTrendPoint[]   = [];
  topCodes:  CodeStat[] = [];
  railStats: RailStat[] = [];

  selectedIds = new Set<string>();
  triageItem: ExceptionItem | null = null;
  commentText = '';
  showAudit   = true;

  // SVG chart dimensions
  readonly trendW   = 620;
  readonly trendH   = 190;
  readonly chartTop = 10;
  readonly chartBot = 28;
  readonly barW     = 13;

  lastUpdated = new Date();
  private refreshTimer?: ReturnType<typeof setInterval>;

  constructor(
    private exSvc: ExceptionService,
    private toastSvc: ToastService,
    private confirmSvc: ConfirmService,
    private exportSvc: ExportService,
  ) {}

  ngOnInit(): void {
    this.loadData();
    this.refreshTimer = setInterval(() => this.loadData(), 30_000);
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  loadData(): void {
    // Server-side paginated fetch
    this.exSvc.fetchExceptionsPaginated(this.filter, this.sort, this.page, this.pageSize).subscribe(result => {
      this.queuePage = result;
      this.queueTabs = this.exSvc.getQueueTabsFromApi();
      this.summary   = this.exSvc.getSummaryFromApi();
      this.trend     = []; // Trend requires time-series KPI data from Ops DB
      this.topCodes  = this.exSvc.getTopCodesFromApi();
      this.railStats = this.exSvc.getRailStatsFromApi();
      this.lastUpdated = new Date();
    });
  }

  exportCsv(): void {
    const rows = this.queuePage.items.map(i => ({
      Reference: i.reference,
      Code: i.exceptionCode,
      Description: i.description,
      Rail: i.rail,
      Severity: i.severity,
      Status: i.status,
      Queue: i.queue,
      Age_Minutes: i.ageMinutes,
      SLA_Status: i.slaStatus,
      Assigned_To: i.assignedTo ?? '',
      Amount: i.amount ?? '',
      Currency: i.currency ?? '',
      Created_At: i.createdAt.toISOString(),
    }));
    this.exportSvc.toCsv(rows, `exceptions-${new Date().toISOString().slice(0,10)}`);
    this.toastSvc.success('Export complete', `${rows.length} exceptions exported`);
  }

  // ── Queue tab ──────────────────────────────────────────────────────────────

  get activeQueue(): ExceptionQueue { return this.filter.queue; }

  setQueue(q: ExceptionQueue): void {
    this.filter = { ...this.filter, queue: q };
    this.page = 0;
    this.selectedIds.clear();
    this.loadData();
  }

  onFilterChange(): void {
    this.page = 0;
    this.loadData();
  }

  onRailFilterChange(): void {
    this.filter = { ...this.filter, rails: this.railFilter ? [this.railFilter as Rail] : [] };
    this.onFilterChange();
  }

  isSeverityActive(sev: ExceptionSeverity): boolean { return this.filter.severities.includes(sev); }

  toggleSeverity(sev: ExceptionSeverity): void {
    const sevs = [...this.filter.severities];
    const idx = sevs.indexOf(sev);
    if (idx >= 0) sevs.splice(idx, 1); else sevs.push(sev);
    this.filter = { ...this.filter, severities: sevs };
    this.onFilterChange();
  }

  isSlaActive(s: SlaStatus): boolean { return this.filter.slaStatuses.includes(s); }

  toggleSla(s: SlaStatus): void {
    const slas = [...this.filter.slaStatuses];
    const idx = slas.indexOf(s);
    if (idx >= 0) slas.splice(idx, 1); else slas.push(s);
    this.filter = { ...this.filter, slaStatuses: slas };
    this.onFilterChange();
  }

  get hasActiveFilters(): boolean {
    return !!(this.filter.search || this.filter.severities.length || this.filter.rails.length || this.filter.slaStatuses.length);
  }

  clearFilters(): void {
    this.filter = this.exSvc.getDefaultFilter();
    this.railFilter = '';
    this.onFilterChange();
  }

  // ── Table interaction ──────────────────────────────────────────────────────

  onSort(col: keyof ExceptionItem): void {
    this.sort = this.sort.column === col
      ? { column: col, direction: this.sort.direction === 'asc' ? 'desc' : 'asc' }
      : { column: col, direction: 'asc' };
    this.loadData();
  }

  sortIndicator(col: string): string {
    if (this.sort.column !== col) return '';
    return this.sort.direction === 'asc' ? ' ↑' : ' ↓';
  }

  onRowClick(item: ExceptionItem): void {
    this.triageItem = this.exSvc.getItem(item.id);
    this.commentText = '';
    this.showAudit = true;
  }

  closePanel(): void { this.triageItem = null; }

  toggleSelection(id: string, event: Event): void {
    event.stopPropagation();
    if (this.selectedIds.has(id)) { this.selectedIds.delete(id); } else { this.selectedIds.add(id); }
  }

  toggleAll(event: Event): void {
    const checked = (event.target as HTMLInputElement).checked;
    if (checked) { this.queuePage.items.forEach(i => this.selectedIds.add(i.id)); }
    else { this.selectedIds.clear(); }
  }

  get allSelected(): boolean {
    return this.queuePage.items.length > 0 && this.queuePage.items.every(i => this.selectedIds.has(i.id));
  }

  clearSelection(): void { this.selectedIds.clear(); }

  async onBulkAction(action: 'reroute' | 'retry' | 'escalate'): Promise<void> {
    const svcAction = action === 'retry' ? 'reroute' : action;
    const count = this.selectedIds.size;
    const actionLabel = svcAction === 'escalate' ? 'Escalate' : 'Re-route';
    const danger = svcAction === 'escalate';

    const confirmed = await this.confirmSvc.confirm({
      title: `${actionLabel} ${count} Exception${count !== 1 ? 's' : ''}`,
      message: `This will ${actionLabel.toLowerCase()} all selected exceptions and update their status accordingly.`,
      confirmLabel: actionLabel,
      count,
      danger,
    });
    if (!confirmed) return;

    Array.from(this.selectedIds).forEach(id => this.exSvc.submitAction(id, svcAction));
    this.selectedIds.clear();
    this.loadData();
    const labels: Record<string, string> = { reroute: 'Re-routed', escalate: 'Escalated' };
    this.toastSvc.success(`${labels[svcAction] ?? 'Updated'} ${count} exception${count !== 1 ? 's' : ''}`);
  }

  quickEscalate(item: ExceptionItem, event: Event): void {
    event.stopPropagation();
    this.exSvc.submitAction(item.id, 'escalate');
    this.loadData();
    this.toastSvc.warning('Escalated', item.reference);
  }

  // ── Triage panel ──────────────────────────────────────────────────────────

  submitTriageAction(action: string): void {
    if (!this.triageItem) return;
    const ref = this.triageItem.reference;
    this.exSvc.submitAction(this.triageItem.id, action, this.commentText);
    this.commentText = '';
    this.triageItem = this.exSvc.getItem(this.triageItem.id);
    this.loadData();
    const toastMap: Record<string, () => void> = {
      resolve:   () => this.toastSvc.success('Exception resolved', ref),
      escalate:  () => this.toastSvc.warning('Escalated to next queue', ref),
      hold:      () => this.toastSvc.info('Exception held', ref),
      reject:    () => this.toastSvc.error('Exception rejected', ref),
      reroute:   () => this.toastSvc.info('Exception re-routed', ref),
    };
    (toastMap[action] ?? (() => this.toastSvc.info('Action applied', ref)))();
  }

  submitComment(): void {
    if (!this.triageItem || !this.commentText.trim()) return;
    this.exSvc.submitComment(this.triageItem.id, this.commentText);
    this.commentText = '';
    this.triageItem = this.exSvc.getItem(this.triageItem.id);
    this.toastSvc.info('Comment added');
  }

  isActionable(item: ExceptionItem): boolean {
    return item.status !== ExceptionStatus.RESOLVED &&
           item.status !== ExceptionStatus.AUTO_RESOLVED &&
           item.status !== ExceptionStatus.REJECTED;
  }

  // ── Pagination ─────────────────────────────────────────────────────────────

  onPageSizeChange(): void { this.page = 0; this.loadData(); }

  goPage(p: number): void { this.page = p; this.loadData(); }

  get totalPages(): number { return Math.max(1, Math.ceil(this.queuePage.filteredCount / this.pageSize)); }
  get paginationStart(): number { return this.queuePage.filteredCount === 0 ? 0 : this.page * this.pageSize + 1; }
  get paginationEnd(): number { return Math.min((this.page + 1) * this.pageSize, this.queuePage.filteredCount); }

  // ── Formatters ────────────────────────────────────────────────────────────

  formatAge(minutes: number): string {
    const m = Math.abs(minutes);
    if (m < 60) return `${m}m`;
    if (m < 1440) return `${Math.floor(m / 60)}h ${m % 60}m`;
    return `${Math.floor(m / 1440)}d ${Math.floor((m % 1440) / 60)}h`;
  }

  formatAmount(amount: number | undefined, currency: string | undefined): string {
    if (!amount) return '';
    return new Intl.NumberFormat('en-AE', { style: 'currency', currency: currency ?? 'AED', maximumFractionDigits: 0 }).format(amount);
  }

  formatSlaRemaining(item: ExceptionItem): string {
    if (item.slaStatus === 'breach') return `Breach (${this.formatAge(Math.abs(item.slaMinutesRemaining))} ago)`;
    return `${this.formatAge(item.slaMinutesRemaining)} left`;
  }

  getSlaClass(status: SlaStatus): string {
    if (status === 'breach')  return 'ep__sla--breach';
    if (status === 'warning') return 'ep__sla--warn';
    return 'ep__sla--ok';
  }

  getStatusClass(status: ExceptionStatus): string {
    const m: Record<ExceptionStatus, string> = {
      [ExceptionStatus.OPEN]:         'ep__st--open',
      [ExceptionStatus.IN_TRIAGE]:    'ep__st--triage',
      [ExceptionStatus.HELD]:         'ep__st--held',
      [ExceptionStatus.ESCALATED]:    'ep__st--escalated',
      [ExceptionStatus.RESOLVED]:     'ep__st--resolved',
      [ExceptionStatus.AUTO_RESOLVED]:'ep__st--auto',
      [ExceptionStatus.REJECTED]:     'ep__st--rejected',
    };
    return m[status] ?? '';
  }

  queueLabel(q: ExceptionQueue): string   { return QUEUE_LABELS[q] ?? q; }
  statusLabel(s: ExceptionStatus): string  { return STATUS_LABELS[s] ?? s; }

  // ── SVG Trend chart helpers ───────────────────────────────────────────────

  get chartUsableH(): number { return this.trendH - this.chartTop - this.chartBot; }
  get chartLeft(): number    { return 42; }
  get chartRight(): number   { return this.trendW - 8; }
  get groupW(): number       { return (this.chartRight - this.chartLeft) / Math.max(1, this.trend.length); }

  get trendMax(): number {
    return Math.max(...this.trend.flatMap(p => [p.opened, p.resolved, p.escalated]), 10);
  }

  get gridLines(): { y: number; label: string }[] {
    return [0, 1, 2, 3, 4].map(i => {
      const val = Math.round((this.trendMax * i) / 4);
      const y   = this.chartTop + this.chartUsableH - (val / this.trendMax) * this.chartUsableH;
      return { y, label: String(val) };
    });
  }

  trendGroupX(i: number): number {
    const totalBarsW = this.barW * 3 + 4;
    return this.chartLeft + i * this.groupW + (this.groupW - totalBarsW) / 2;
  }

  trendBarH(val: number): number { return Math.max(2, (val / this.trendMax) * this.chartUsableH); }
  trendBarY(val: number): number { return this.chartTop + this.chartUsableH - this.trendBarH(val); }
  trendLabelX(i: number): number { return this.chartLeft + i * this.groupW + this.groupW / 2; }
  trendLabelY(): number          { return this.trendH - 6; }
}
