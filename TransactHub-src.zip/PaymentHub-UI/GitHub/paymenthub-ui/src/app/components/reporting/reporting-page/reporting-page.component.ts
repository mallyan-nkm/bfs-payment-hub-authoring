import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {
  Rail, ReportFilter, ReportType, ReportGroupBy, DatePreset,
  VolumeReport, VolumePoint, RailVolumeStat,
  SlaReport, SlaPoint, RailSlaStat,
  ExceptionReport, ExceptionBreakdown,
  ApprovalReport, ApprovalStat
} from '../../../shared/types';
import { ReportingService } from '../../../shared/services/reporting.service';
import { ExceptionService } from '../../../shared/services/exception.service';
import { ToastService } from '../../../shared/services/toast.service';
import { DataFreshnessComponent } from '../../../shared/components/data-freshness/data-freshness.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';

interface BarSeg { x: number; y: number; w: number; h: number; color: string; rail: string; count: number; }
interface BarGroup { label: string; total: number; x: number; barW: number; segs: BarSeg[]; }

const RAIL_COLORS: Partial<Record<Rail, string>> = {
  [Rail.UAEFTS]: '#3b82f6',
  [Rail.IPI]:    '#22c55e',
  [Rail.IPP]:    '#f59e0b',
  [Rail.WPS]:    '#a855f7',
  [Rail.SWIFT]:  '#06b6d4',
};

@Component({
  selector: 'app-reporting-page',
  standalone: true,
  imports: [CommonModule, FormsModule, DataFreshnessComponent, EmptyStateComponent],
  templateUrl: './reporting-page.component.html',
  styleUrls: ['./reporting-page.component.scss']
})
export class ReportingPageComponent implements OnInit {

  filter: ReportFilter = this.svc.getDefaultFilter();
  activeReport: ReportType = 'volume';
  isLoading = false;

  volumeReport:    VolumeReport    | null = null;
  slaReport:       SlaReport       | null = null;
  exceptionReport: ExceptionReport | null = null;
  approvalReport:  ApprovalReport  | null = null;

  readonly CHART_W = 580;
  readonly CHART_H = 160;

  readonly REPORT_TABS: { id: ReportType; label: string; icon: string }[] = [
    { id: 'volume',     label: 'Volume & Throughput', icon: '▦' },
    { id: 'sla',        label: 'SLA Performance',     icon: '◎' },
    { id: 'exceptions', label: 'Exception Analysis',  icon: '⚠' },
    { id: 'approvals',  label: 'Approval Stats',      icon: '✓' },
  ];

  readonly PRESETS: { id: DatePreset; label: string }[] = [
    { id: 'today',     label: 'Today'       },
    { id: 'yesterday', label: 'Yesterday'   },
    { id: 'last7d',    label: 'Last 7 days' },
    { id: 'last30d',   label: 'Last 30 days'},
    { id: 'custom',    label: 'Custom range'},
  ];

  readonly GROUP_OPTIONS: { id: ReportGroupBy; label: string }[] = [
    { id: 'hour', label: 'Hourly' },
    { id: 'day',  label: 'Daily'  },
    { id: 'week', label: 'Weekly' },
  ];

  readonly RAILS = Object.values(Rail).filter(r => r !== Rail.ALL) as Rail[];

  readonly RAIL_COLORS = RAIL_COLORS;

  lastUpdated = new Date();

  constructor(private svc: ReportingService, private exSvc: ExceptionService, private toastSvc: ToastService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.isLoading = true;

    const txn$ = this.svc.getTransactionReportsFromApi(this.filter, 1, 200).pipe(
      catchError(() => of({ items: [], total: 0 }))
    );
    const exc$ = this.exSvc.fetchExceptions(undefined, undefined, 200).pipe(
      catchError(() => of([]))
    );

    forkJoin({ txn: txn$, exc: exc$ }).subscribe(({ txn, exc }) => {
      const items: any[] = txn?.items ?? [];
      const total = txn?.total ?? items.length;
      const exceptions: any[] = Array.isArray(exc) ? exc : [];

      this.volumeReport = this.buildVolumeFromApi(items, total);
      this.slaReport = this.buildSlaFromApi(items);
      this.exceptionReport = this.buildExceptionFromApi(items, exceptions);
      this.approvalReport = this.buildApprovalFromApi(items);

      this.isLoading = false;
      this.lastUpdated = new Date();
    });
  }

  private buildVolumeFromApi(items: any[], total: number): VolumeReport {
    const groupBy = this.filter.groupBy || 'day';

    // Group items by time period
    const grouped: Record<string, any[]> = {};
    items.forEach(item => {
      const date = new Date(item.transactionDate || item.createdAt);
      let label: string;
      if (groupBy === 'hour') {
        label = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ' ' +
                date.getHours().toString().padStart(2, '0') + ':00';
      } else if (groupBy === 'week') {
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        label = 'W' + this.getWeekNumber(weekStart) + ' ' + weekStart.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
      } else {
        label = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
      }
      if (!grouped[label]) grouped[label] = [];
      grouped[label].push(item);
    });

    // Build points with rail breakdown
    const schemaToRail: Record<string, Rail> = {
      'IPI': Rail.IPI, 'FTS': Rail.UAEFTS, 'WPS': Rail.WPS,
      'CBFT': Rail.SWIFT, 'NPSS': Rail.IPP
    };

    const points: VolumePoint[] = Object.entries(grouped)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([label, groupItems]) => {
        const byRail: Partial<Record<Rail, number>> = {};
        groupItems.forEach(item => {
          const rail = schemaToRail[item.schemaType] || Rail.UAEFTS;
          byRail[rail] = (byRail[rail] ?? 0) + 1;
        });
        return { label, total: groupItems.length, byRail };
      });

    // Build rail summary
    const railCounts: Record<string, { count: number; value: number; successCount: number }> = {};
    items.forEach(item => {
      const rail = schemaToRail[item.schemaType] || 'UAEFTS';
      if (!railCounts[rail]) railCounts[rail] = { count: 0, value: 0, successCount: 0 };
      railCounts[rail].count++;
      railCounts[rail].value += item.amount || 0;
      if (item.status === 'COMPLETED' || item.status === 'SETTLED' || item.status === 'ACCEPTED') {
        railCounts[rail].successCount++;
      }
    });

    const byRail: RailVolumeStat[] = Object.entries(railCounts).map(([rail, stats]) => ({
      rail: rail as Rail,
      count: stats.count,
      value: stats.value,
      pct: total > 0 ? Math.round(stats.count / total * 100) : 0,
      successRatePct: stats.count > 0 ? Math.round(stats.successCount / stats.count * 100) : 0
    }));

    const peakPoint = points.length > 0 ? points.reduce((max, p) => p.total > max.total ? p : max, points[0]) : null;
    const totalValue = items.reduce((sum, i) => sum + (i.amount || 0), 0);

    return {
      points,
      totalCount: total,
      totalValue,
      peakLabel: peakPoint?.label ?? '',
      peakCount: peakPoint?.total ?? 0,
      avgPerInterval: points.length > 0 ? Math.round(total / points.length) : 0,
      byRail
    };
  }

  private buildSlaFromApi(items: any[]): SlaReport {
    const groupBy = this.filter.groupBy || 'day';
    // SLA thresholds in milliseconds
    const SLA_BREACH_MS = 30000;   // 30 seconds
    const SLA_WARNING_MS = 20000;  // 20 seconds

    // Group items by time period
    const grouped: Record<string, any[]> = {};
    items.forEach(item => {
      const date = new Date(item.transactionDate || item.createdAt);
      let label: string;
      if (groupBy === 'hour') {
        label = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ' ' +
                date.getHours().toString().padStart(2, '0') + ':00';
      } else if (groupBy === 'week') {
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        label = 'W' + this.getWeekNumber(weekStart) + ' ' + weekStart.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
      } else {
        label = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
      }
      if (!grouped[label]) grouped[label] = [];
      grouped[label].push(item);
    });

    // Build SLA points
    const points: SlaPoint[] = Object.entries(grouped)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([label, groupItems]) => {
        let breachCount = 0, warningCount = 0, okCount = 0;
        groupItems.forEach(item => {
          const procTime = item.processingTimeMs ?? 0;
          if (procTime > SLA_BREACH_MS) breachCount++;
          else if (procTime > SLA_WARNING_MS) warningCount++;
          else okCount++;
        });
        const total = groupItems.length;
        const compliancePct = total > 0 ? Math.round((okCount / total) * 1000) / 10 : 100;
        return { label, compliancePct, breachCount, warningCount, okCount };
      });

    // Rail SLA breakdown
    const schemaToRail: Record<string, Rail> = {
      'IPI': Rail.IPI, 'FTS': Rail.UAEFTS, 'WPS': Rail.WPS,
      'CBFT': Rail.SWIFT, 'NPSS': Rail.IPP
    };
    const railStats: Record<string, { total: number; breaches: number; warnings: number; totalProcMs: number }> = {};
    items.forEach(item => {
      const rail = schemaToRail[item.schemaType] || 'UAEFTS';
      if (!railStats[rail]) railStats[rail] = { total: 0, breaches: 0, warnings: 0, totalProcMs: 0 };
      railStats[rail].total++;
      railStats[rail].totalProcMs += item.processingTimeMs ?? 0;
      const procTime = item.processingTimeMs ?? 0;
      if (procTime > SLA_BREACH_MS) railStats[rail].breaches++;
      else if (procTime > SLA_WARNING_MS) railStats[rail].warnings++;
    });

    const byRail: RailSlaStat[] = Object.entries(railStats).map(([rail, stats]) => ({
      rail: rail as Rail,
      compliancePct: stats.total > 0
        ? Math.round(((stats.total - stats.breaches - stats.warnings) / stats.total) * 1000) / 10
        : 100,
      breachCount: stats.breaches,
      warningCount: stats.warnings,
      avgResolutionMinutes: stats.total > 0 ? Math.round(stats.totalProcMs / stats.total / 60000 * 10) / 10 : 0
    }));

    const totalBreaches = items.filter(i => (i.processingTimeMs ?? 0) > SLA_BREACH_MS).length;
    const totalWarnings = items.filter(i => {
      const pt = i.processingTimeMs ?? 0;
      return pt > SLA_WARNING_MS && pt <= SLA_BREACH_MS;
    }).length;
    const totalProcMs = items.reduce((sum, i) => sum + (i.processingTimeMs ?? 0), 0);
    const overallPct = items.length > 0
      ? Math.round(((items.length - totalBreaches - totalWarnings) / items.length) * 1000) / 10
      : 100;

    return {
      points,
      overallPct,
      totalBreaches,
      totalWarnings,
      avgResolutionMinutes: items.length > 0 ? Math.round(totalProcMs / items.length / 60000 * 10) / 10 : 0,
      byRail
    };
  }

  private buildExceptionFromApi(items: any[], exceptions: any[]): ExceptionReport {
    const schemaToRail: Record<string, Rail> = {
      'IPI': Rail.IPI, 'FTS': Rail.UAEFTS, 'WPS': Rail.WPS,
      'CBFT': Rail.SWIFT, 'NPSS': Rail.IPP
    };

    // Group exceptions by code
    const codeMap: Record<string, { desc: string; count: number; open: number; totalMttr: number; resolved: number }> = {};
    exceptions.forEach(exc => {
      const code = exc.exceptionCode || 'UNKNOWN';
      if (!codeMap[code]) codeMap[code] = { desc: exc.description || code, count: 0, open: 0, totalMttr: 0, resolved: 0 };
      codeMap[code].count++;
      if (exc.status === 'OPEN' || exc.status === 'IN_TRIAGE' || exc.status === 'HELD' || exc.status === 'ESCALATED') {
        codeMap[code].open++;
      } else {
        codeMap[code].resolved++;
        codeMap[code].totalMttr += exc.ageMinutes || 0;
      }
    });

    const totalExc = exceptions.length || 1;
    const byType: ExceptionBreakdown[] = Object.entries(codeMap)
      .sort(([, a], [, b]) => b.count - a.count)
      .map(([code, stats]) => ({
        code,
        description: stats.desc,
        count: stats.count,
        pct: Math.round(stats.count / totalExc * 100),
        openCount: stats.open,
        avgResolutionMinutes: stats.resolved > 0 ? Math.round(stats.totalMttr / stats.resolved) : 0,
        trend: (stats.open > stats.resolved ? 'up' : stats.open < stats.resolved ? 'down' : 'flat') as 'up' | 'down' | 'flat'
      }));

    // Group by rail
    const railMap: Record<string, { count: number; resolved: number }> = {};
    exceptions.forEach(exc => {
      const rail = exc.rail || 'UAEFTS';
      if (!railMap[rail]) railMap[rail] = { count: 0, resolved: 0 };
      railMap[rail].count++;
      if (exc.status === 'RESOLVED' || exc.status === 'AUTO_RESOLVED') railMap[rail].resolved++;
    });

    const byRail = Object.entries(railMap).map(([rail, stats]) => ({
      rail: rail as Rail,
      count: stats.count,
      resolvedPct: stats.count > 0 ? Math.round(stats.resolved / stats.count * 100) : 0
    }));

    const totalOpen = exceptions.filter(e => e.status === 'OPEN' || e.status === 'IN_TRIAGE' || e.status === 'HELD' || e.status === 'ESCALATED').length;
    const today = new Date().toDateString();
    const resolvedToday = exceptions.filter(e =>
      e.resolvedAt && new Date(e.resolvedAt).toDateString() === today
    ).length;
    const resolvedExc = exceptions.filter(e => e.status === 'RESOLVED' || e.status === 'AUTO_RESOLVED');
    const mttrMinutes = resolvedExc.length > 0
      ? Math.round(resolvedExc.reduce((sum, e) => sum + (e.ageMinutes || 0), 0) / resolvedExc.length)
      : 0;

    // If no exceptions from the exception service, derive from failed transactions
    if (exceptions.length === 0 && items.length > 0) {
      const failedItems = items.filter(i =>
        i.status === 'FAILED' || i.status === 'REJECTED' || i.status === 'EXCEPTION'
      );
      if (failedItems.length > 0) {
        const statusMap: Record<string, number> = {};
        failedItems.forEach(i => {
          const key = i.status || 'FAILED';
          statusMap[key] = (statusMap[key] ?? 0) + 1;
        });
        const derivedByType: ExceptionBreakdown[] = Object.entries(statusMap).map(([status, count]) => ({
          code: status,
          description: `Transactions with status: ${status}`,
          count,
          pct: Math.round(count / failedItems.length * 100),
          openCount: count,
          avgResolutionMinutes: 0,
          trend: 'flat' as const
        }));

        const railAcc: Record<string, { count: number; resolved: number }> = {};
        failedItems.forEach(i => {
          const rail = schemaToRail[i.schemaType] || 'UAEFTS';
          if (!railAcc[rail]) railAcc[rail] = { count: 0, resolved: 0 };
          railAcc[rail].count++;
        });
        const derivedByRail = Object.entries(railAcc).map(([rail, stats]) => ({
          rail: rail as Rail,
          count: stats.count,
          resolvedPct: 0
        }));

        return { byType: derivedByType, totalOpen: failedItems.length, resolvedToday: 0, mttrMinutes: 0, byRail: derivedByRail };
      }
    }

    return { byType, totalOpen, resolvedToday, mttrMinutes, byRail };
  }

  private buildApprovalFromApi(items: any[]): ApprovalReport {
    // Categorize items by approval-related statuses
    const approvalStatuses = ['APPROVED', 'REJECTED', 'PENDING_APPROVAL', 'PENDING', 'EXPIRED'];
    const approvalItems = items.filter(i => approvalStatuses.includes(i.status));

    // If no explicit approval status items, derive from all statuses
    const workItems = approvalItems.length > 0 ? approvalItems : items;

    // Group by category/module as approval levels
    const levelMap: Record<string, { pending: number; approved: number; rejected: number; expired: number; totalProcMs: number; count: number }> = {};

    workItems.forEach(item => {
      const level = item.category || item.schemaType || 'General';
      if (!levelMap[level]) levelMap[level] = { pending: 0, approved: 0, rejected: 0, expired: 0, totalProcMs: 0, count: 0 };
      levelMap[level].count++;
      levelMap[level].totalProcMs += item.processingTimeMs ?? 0;

      const status = (item.status || '').toUpperCase();
      if (status === 'APPROVED' || status === 'COMPLETED' || status === 'SETTLED' || status === 'ACCEPTED') {
        levelMap[level].approved++;
      } else if (status === 'REJECTED' || status === 'FAILED') {
        levelMap[level].rejected++;
      } else if (status === 'EXPIRED') {
        levelMap[level].expired++;
      } else {
        levelMap[level].pending++;
      }
    });

    const byLevel: ApprovalStat[] = Object.entries(levelMap).map(([level, stats]) => {
      const total = stats.approved + stats.rejected;
      return {
        level,
        pendingCount: stats.pending,
        approvedCount: stats.approved,
        rejectedCount: stats.rejected,
        expiredCount: stats.expired,
        avgDecisionMinutes: stats.count > 0 ? Math.round(stats.totalProcMs / stats.count / 60000 * 10) / 10 : 0,
        slaCompliancePct: total > 0 ? Math.round(stats.approved / total * 100) : 0
      };
    });

    const totalProcessed = workItems.filter(i => {
      const s = (i.status || '').toUpperCase();
      return s === 'APPROVED' || s === 'COMPLETED' || s === 'SETTLED' || s === 'ACCEPTED' || s === 'REJECTED' || s === 'FAILED';
    }).length;
    const totalPending = workItems.filter(i => {
      const s = (i.status || '').toUpperCase();
      return s === 'PENDING' || s === 'PENDING_APPROVAL' || s === 'IN_PROGRESS';
    }).length;
    const totalApproved = workItems.filter(i => {
      const s = (i.status || '').toUpperCase();
      return s === 'APPROVED' || s === 'COMPLETED' || s === 'SETTLED' || s === 'ACCEPTED';
    }).length;
    const overallApprovalRatePct = totalProcessed > 0 ? Math.round(totalApproved / totalProcessed * 100) : 0;
    const slaBreachCount = workItems.filter(i => (i.processingTimeMs ?? 0) > 30000).length;

    return { byLevel, totalProcessed, overallApprovalRatePct, totalPending, slaBreachCount };
  }

  private getWeekNumber(date: Date): number {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  }

  // ── Filters ───────────────────────────────────────────────────────────────

  onPreset(p: DatePreset): void {
    const now = new Date();
    const iso = (d: Date) => d.toISOString().slice(0, 10);
    const today = iso(now);
    const yesterday = iso(new Date(now.getTime() - 86400000));
    const weekAgo   = iso(new Date(now.getTime() - 6 * 86400000));
    const monthAgo  = iso(new Date(now.getTime() - 29 * 86400000));

    const groupBy: ReportGroupBy = p === 'today' || p === 'yesterday' ? 'hour'
      : p === 'last7d' ? 'day' : 'week';

    this.filter = {
      ...this.filter, preset: p, groupBy,
      dateFrom: p === 'yesterday' ? yesterday : p === 'today' ? today : p === 'last7d' ? weekAgo : monthAgo,
      dateTo: today,
    };
    this.load();
  }

  onGroupBy(g: ReportGroupBy): void { this.filter = { ...this.filter, groupBy: g }; this.load(); }

  toggleRail(r: Rail): void {
    const rails = this.filter.rails.includes(r)
      ? this.filter.rails.filter(x => x !== r)
      : [...this.filter.rails, r];
    this.filter = { ...this.filter, rails };
    this.load();
  }

  isRailActive(r: Rail): boolean { return this.filter.rails.includes(r); }

  get activeFilterCount(): number {
    return this.filter.rails.length + (this.filter.preset !== 'last7d' ? 1 : 0);
  }

  onReset(): void { this.filter = this.svc.getDefaultFilter(); this.load(); }

  exportCsv(): void {
    const report = this.activeReport;
    let rowCount = 0;
    if (report === 'volume' && this.volumeReport) {
      const rows = this.volumeReport.points.map(p => ({ Label: p.label, Total: p.total, ...p.byRail }));
      this.svc.exportCsv(rows as Record<string, unknown>[], `volume-report-${this.filter.preset}.csv`);
      rowCount = rows.length;
    } else if (report === 'sla' && this.slaReport) {
      const rows = this.slaReport.points.map(p => ({ Label: p.label, Compliance_Pct: p.compliancePct, Breaches: p.breachCount, Warnings: p.warningCount }));
      this.svc.exportCsv(rows, `sla-report-${this.filter.preset}.csv`);
      rowCount = rows.length;
    } else if (report === 'exceptions' && this.exceptionReport) {
      const rows = this.exceptionReport.byType.map(e => ({ Code: e.code, Description: e.description, Count: e.count, Open: e.openCount, Avg_Resolution_Min: e.avgResolutionMinutes }));
      this.svc.exportCsv(rows, `exception-report-${this.filter.preset}.csv`);
      rowCount = rows.length;
    }
    if (rowCount > 0) this.toastSvc.success('Export complete', `${rowCount} rows exported`);
  }

  // ── Volume chart ──────────────────────────────────────────────────────────

  get volumeBars(): BarGroup[] {
    if (!this.volumeReport?.points.length) return [];
    const pts = this.volumeReport.points;
    const max = Math.max(...pts.map(p => p.total), 1);
    const n = pts.length;
    const totalW = this.CHART_W;
    const rawBarW = totalW / n;
    const gap = Math.max(1, rawBarW * 0.15);
    const barW = rawBarW - gap;
    const H = this.CHART_H;
    const rails = this.RAILS;

    return pts.map((pt, i) => {
      let stackY = H;
      const segs: BarSeg[] = rails.map(rail => {
        const count = pt.byRail[rail] ?? 0;
        const h = (count / max) * H;
        stackY -= h;
        return { x: i * rawBarW + gap / 2, y: stackY, w: barW, h, color: RAIL_COLORS[rail] ?? '#94a3b8', rail, count };
      }).filter(s => s.h > 0.5);
      return { label: pt.label, total: pt.total, x: i * rawBarW + rawBarW / 2, barW, segs };
    });
  }

  get volumeXLabels(): { x: number; label: string }[] {
    const bars = this.volumeBars;
    if (bars.length <= 8) return bars.map(b => ({ x: b.x, label: b.label }));
    const step = Math.ceil(bars.length / 8);
    return bars.filter((_, i) => i % step === 0).map(b => ({ x: b.x, label: b.label }));
  }

  get volumeYLines(): { y: number; label: string }[] {
    if (!this.volumeReport?.points.length) return [];
    const max = Math.max(...this.volumeReport.points.map(p => p.total), 1);
    return [0, 0.25, 0.5, 0.75, 1].map(pct => ({
      y: this.CHART_H - pct * this.CHART_H,
      label: this.fmtCount(Math.round(pct * max)),
    }));
  }

  // ── SLA chart ─────────────────────────────────────────────────────────────

  get slaLinePath(): string {
    if (!this.slaReport?.points.length) return '';
    const pts = this.slaReport.points;
    const W = this.CHART_W; const H = this.CHART_H;
    const minPct = 80;
    return pts.map((p, i) => {
      const x = pts.length > 1 ? (i / (pts.length - 1)) * W : W / 2;
      const y = H - ((p.compliancePct - minPct) / (100 - minPct)) * H;
      return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  }

  get slaAreaPath(): string {
    if (!this.slaReport?.points.length) return '';
    const pts = this.slaReport.points;
    const W = this.CHART_W; const H = this.CHART_H;
    const minPct = 80;
    const linePoints = pts.map((p, i) => {
      const x = pts.length > 1 ? (i / (pts.length - 1)) * W : W / 2;
      const y = H - ((p.compliancePct - minPct) / (100 - minPct)) * H;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
    const lastX = W.toFixed(1);
    return `M 0,${H} L ${linePoints} L ${lastX},${H} Z`;
  }

  get slaGridLines(): { y: number; label: string }[] {
    const H = this.CHART_H; const minPct = 80;
    return [80, 85, 90, 95, 100].map(pct => ({
      y: H - ((pct - minPct) / (100 - minPct)) * H,
      label: pct + '%',
    }));
  }

  get slaXLabels(): { x: number; label: string }[] {
    if (!this.slaReport?.points.length) return [];
    const pts = this.slaReport.points;
    const W = this.CHART_W;
    const step = Math.ceil(pts.length / 8);
    return pts.filter((_, i) => i % step === 0).map((p, _, arr) => {
      const i = pts.indexOf(p);
      return { x: pts.length > 1 ? (i / (pts.length - 1)) * W : W / 2, label: p.label };
    });
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  fmtCount(n: number): string {
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
    if (n >= 1_000)     return (n / 1_000).toFixed(1) + 'K';
    return n.toString();
  }

  fmtValue(n: number): string {
    if (n >= 1_000_000_000) return 'AED ' + (n / 1_000_000_000).toFixed(2) + 'B';
    if (n >= 1_000_000)     return 'AED ' + (n / 1_000_000).toFixed(1) + 'M';
    return 'AED ' + (n / 1_000).toFixed(0) + 'K';
  }

  fmtPct(n: number): string { return n.toFixed(1) + '%'; }

  fmtMins(m: number): string {
    if (m < 60) return m + 'm';
    return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
  }

  trendIcon(t: 'up' | 'down' | 'flat'): string {
    return { up: '↑', down: '↓', flat: '→' }[t];
  }

  trendClass(t: 'up' | 'down' | 'flat', isException = true): string {
    if (t === 'flat') return 'trend--flat';
    return (isException ? t === 'up' : t === 'down') ? 'trend--bad' : 'trend--good';
  }

  railColor(rail: Rail): string { return RAIL_COLORS[rail] ?? '#94a3b8'; }

  approvalRatePct(stat: ApprovalStat): number {
    const total = stat.approvedCount + stat.rejectedCount;
    return total > 0 ? (stat.approvedCount / total) * 100 : 0;
  }
}
