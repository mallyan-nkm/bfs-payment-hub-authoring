import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppNotification, NotificationCategory } from '../../../shared/types';
import { NotificationService } from '../../../shared/services/notification.service';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';

type FilterTab = 'all' | 'unread' | NotificationCategory;

const CATEGORY_ICON: Record<NotificationCategory, string> = {
  exception:  'alert-circle',
  approval:   'check-square',
  payment:    'credit-card',
  system:     'activity',
  compliance: 'shield',
};

const CATEGORY_LABEL: Record<string, string> = {
  all:        'All',
  unread:     'Unread',
  exception:  'Exceptions',
  approval:   'Approvals',
  payment:    'Payments',
  system:     'System',
  compliance: 'Compliance',
};

@Component({
  selector: 'app-notification-center',
  standalone: true,
  imports: [CommonModule, EmptyStateComponent],
  templateUrl: './notification-center.component.html',
  styleUrls: ['./notification-center.component.scss']
})
export class NotificationCenterComponent implements OnInit, OnDestroy {
  @Output() close = new EventEmitter<void>();

  readonly tabs: FilterTab[] = ['all', 'unread', 'exception', 'approval', 'payment', 'system', 'compliance'];
  activeTab: FilterTab = 'all';

  notifications: AppNotification[] = [];
  private sub?: Subscription;

  constructor(
    private notifSvc: NotificationService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.loadNotifications();
    this.sub = this.notifSvc.change$.subscribe(() => this.loadNotifications());
  }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  private loadNotifications(): void {
    const cat = this.activeTab === 'all' || this.activeTab === 'unread'
      ? undefined
      : this.activeTab as NotificationCategory;

    let items = this.notifSvc.getAll(cat);
    if (this.activeTab === 'unread') items = items.filter(n => !n.isRead);
    this.notifications = items;
  }

  setTab(tab: FilterTab): void {
    this.activeTab = tab;
    this.loadNotifications();
  }

  tabLabel(tab: FilterTab): string { return CATEGORY_LABEL[tab] ?? tab; }

  get unreadCount(): number { return this.notifSvc.getUnreadCount(); }

  get todayItems(): AppNotification[] {
    return this.notifications.filter(n => this.notifSvc.groupLabel(n.timestamp) === 'today');
  }

  get yesterdayItems(): AppNotification[] {
    return this.notifications.filter(n => this.notifSvc.groupLabel(n.timestamp) === 'yesterday');
  }

  get earlierItems(): AppNotification[] {
    return this.notifications.filter(n => this.notifSvc.groupLabel(n.timestamp) === 'earlier');
  }

  markAllRead(): void { this.notifSvc.markAllRead(); }

  onNotifClick(n: AppNotification): void {
    this.notifSvc.markRead(n.id);
    if (n.route) {
      this.router.navigate([n.route]);
      this.close.emit();
    }
  }

  archive(n: AppNotification, event: Event): void {
    event.stopPropagation();
    this.notifSvc.archive(n.id);
  }

  timeAgo(date: Date): string { return this.notifSvc.timeAgo(date); }

  categoryIcon(cat: NotificationCategory): string { return CATEGORY_ICON[cat] ?? 'circle'; }

  priorityClass(n: AppNotification): string {
    if (n.priority === 'critical') return 'nc__item--critical';
    if (n.priority === 'high')     return 'nc__item--high';
    return '';
  }

  categoryClass(cat: NotificationCategory): string { return `nc__icon--${cat}`; }

  svgPath(cat: NotificationCategory): string {
    const paths: Record<NotificationCategory, string> = {
      exception:  '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
      approval:   '<polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
      payment:    '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
      system:     '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
      compliance: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    };
    return paths[cat] ?? '';
  }
}
