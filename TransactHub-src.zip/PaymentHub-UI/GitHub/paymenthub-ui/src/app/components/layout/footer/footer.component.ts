import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Rail, RailHealth, StatusIndicator } from '../../../shared/types';

/**
 * FooterComponent
 * 
 * Bottom status bar (28px)
 * - System health indicator per rail
 * - Active session info
 * - Keyboard shortcuts hint
 * - Real-time system status
 */
@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit, OnDestroy {
  @Input() activeRail: Rail = Rail.ALL;

  // Rail health data
  railsHealth: RailHealth[] = [];
  
  // Session info
  sessionDuration: string = '0m';
  sessionStartTime: Date = new Date();
  
  // Status indicator
  systemStatus: StatusIndicator = StatusIndicator.OPERATIONAL;
  systemStatusMessage: string = 'All systems operational';

  // Refresh interval
  private refreshInterval: any;
  private sessionInterval: any;

  ngOnInit(): void {
    this.initializeRailsHealth();
    this.startSessionTimer();
    this.startHealthRefresh();
  }

  ngOnDestroy(): void {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
    if (this.sessionInterval) {
      clearInterval(this.sessionInterval);
    }
  }

  /**
   * Initialize rail health data
   */
  private initializeRailsHealth(): void {
    this.railsHealth = [
      {
        rail: Rail.UAEFTS,
        status: StatusIndicator.OPERATIONAL,
        throughput: 1250,
        latency_p50: 45,
        latency_p95: 120,
        latency_p99: 250,
        error_rate: 0.02,
        last_updated: new Date()
      },
      {
        rail: Rail.IPI,
        status: StatusIndicator.OPERATIONAL,
        throughput: 3500,
        latency_p50: 25,
        latency_p95: 60,
        latency_p99: 150,
        error_rate: 0.01,
        last_updated: new Date()
      },
      {
        rail: Rail.IPP,
        status: StatusIndicator.OPERATIONAL,
        throughput: 2100,
        latency_p50: 30,
        latency_p95: 80,
        latency_p99: 180,
        error_rate: 0.01,
        last_updated: new Date()
      },
      {
        rail: Rail.WPS,
        status: StatusIndicator.DEGRADED,
        throughput: 850,
        latency_p50: 120,
        latency_p95: 300,
        latency_p99: 450,
        error_rate: 0.05,
        last_updated: new Date()
      },
      {
        rail: Rail.SWIFT,
        status: StatusIndicator.OPERATIONAL,
        throughput: 680,
        latency_p50: 200,
        latency_p95: 500,
        latency_p99: 900,
        error_rate: 0.02,
        last_updated: new Date()
      }
    ];
  }

  /**
   * Start session timer
   */
  private startSessionTimer(): void {
    this.sessionInterval = setInterval(() => {
      const now = new Date();
      const diff = Math.floor((now.getTime() - this.sessionStartTime.getTime()) / 1000);
      
      const hours = Math.floor(diff / 3600);
      const minutes = Math.floor((diff % 3600) / 60);
      
      if (hours > 0) {
        this.sessionDuration = `${hours}h ${minutes}m`;
      } else {
        this.sessionDuration = `${minutes}m`;
      }
    }, 60000); // Update every minute
  }

  /**
   * Start health refresh interval
   */
  private startHealthRefresh(): void {
    this.refreshInterval = setInterval(() => {
      this.refreshRailsHealth();
    }, 30000); // Refresh every 30 seconds
  }

  /**
   * Refresh rails health data
   */
  private refreshRailsHealth(): void {
    // In production, this would fetch from an API
    this.railsHealth.forEach(rail => {
      rail.last_updated = new Date();
    });
    this.updateSystemStatus();
  }

  /**
   * Update overall system status based on rail health
   */
  private updateSystemStatus(): void {
    const hasOutage = this.railsHealth.some(r => r.status === StatusIndicator.OUTAGE);
    const hasDegraded = this.railsHealth.some(r => r.status === StatusIndicator.DEGRADED);

    if (hasOutage) {
      this.systemStatus = StatusIndicator.OUTAGE;
      this.systemStatusMessage = 'System outage detected';
    } else if (hasDegraded) {
      this.systemStatus = StatusIndicator.DEGRADED;
      this.systemStatusMessage = 'Some systems degraded';
    } else {
      this.systemStatus = StatusIndicator.OPERATIONAL;
      this.systemStatusMessage = 'All systems operational';
    }
  }

  /**
   * Get status indicator class
   */
  getStatusClass(status: StatusIndicator): string {
    return `status-${status}`;
  }

  /**
   * Get rail display name
   */
  getRailLabel(rail: Rail): string {
    const labels: Record<Rail, string> = {
      [Rail.UAEFTS]: 'UAEFTS',
      [Rail.IPI]: 'IPI',
      [Rail.IPP]: 'IPP',
      [Rail.WPS]: 'WPS',
      [Rail.SWIFT]: 'SWIFT',
      [Rail.ALL]: 'ALL'
    };
    return labels[rail];
  }

  /**
   * Format throughput for display
   */
  formatThroughput(throughput: number): string {
    if (throughput > 1000) {
      return (throughput / 1000).toFixed(1) + 'k';
    }
    return throughput.toString();
  }

  /**
   * Get tooltip for rail status
   */
  getRailTooltip(rail: RailHealth): string {
    return `${rail.rail}: ${rail.status} - TP: ${rail.throughput}/s, P95: ${rail.latency_p95}ms`;
  }
}
