import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Rail, NavigationSection, BadgeSeverity } from '../../../shared/types';
import { ApprovalService } from '../../../shared/services/approval.service';
import { QueueService } from '../../../shared/services/queue.service';
import { ExceptionService } from '../../../shared/services/exception.service';
import { PersonaService } from '../../../shared/services/persona.service';
import { SvgIconComponent } from '../../../shared/components/svg-icon/svg-icon.component';

interface NavEntry {
  id: string;
  label: string;
  icon: string;
  route: string;
  exact?: boolean;
  badge?: { count: number; severity: BadgeSeverity };
  comingSoon?: boolean;
  permission?: string;
}

interface NavSection {
  section: NavigationSection;
  label: string;
  expanded: boolean;
  items: NavEntry[];
  requiredSection?: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, SvgIconComponent],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit, OnDestroy {
  @Input() collapsed = false;
  @Input() activeRail: Rail = Rail.ALL;

  @Output() collapsedChanged = new EventEmitter<boolean>();

  searchQuery = '';

  sections: NavSection[] = [
    {
      section: NavigationSection.DASHBOARD,
      label: 'Dashboard',
      expanded: true,
      items: [
        { id: 'dash-home',  label: 'Overview',    icon: 'home',        route: '/dashboard',       exact: true },
        { id: 'dash-uaefts',label: 'UAEFTS',      icon: 'layers',      route: '/dashboard/uaefts' },
        { id: 'dash-ipi',   label: 'IPI / Aani',  icon: 'zap',         route: '/dashboard/ipi'    },
        { id: 'dash-ipp',   label: 'IPP',          icon: 'credit-card', route: '/dashboard/ipp'    },
        { id: 'dash-wps',   label: 'WPS',          icon: 'users',       route: '/dashboard/wps'    },
        { id: 'dash-swift', label: 'SWIFT',        icon: 'globe',       route: '/dashboard/swift'  },
      ]
    },
    {
      section: NavigationSection.OPERATIONS,
      label: 'Operations',
      expanded: true,
      items: [
        { id: 'ops-new-txn',   label: 'New Payment',    icon: 'plus-circle',  route: '/operations/transactions/new' },
        { id: 'ops-queues',    label: 'Payment Queues', icon: 'list',         route: '/operations/queues'    },
        { id: 'ops-approvals', label: 'Approvals',      icon: 'check-square', route: '/operations/approvals' },
        { id: 'ops-levers',    label: 'Control Levers', icon: 'sliders',      route: '/operations/levers', permission: 'operations.levers.view' },
        { id: 'ops-replay',    label: 'Workflow Replay', icon: 'refresh-cw',  route: '/operations/workflow-replay', permission: 'operations.replay.view' },
        { id: 'ops-handover',  label: 'Shift Handover', icon: 'clock',        route: '/operations/shift-handover', permission: 'operations.handover.view' },
        { id: 'ops-docs',      label: 'Documents',      icon: 'file',         route: '/operations/documents', permission: 'operations.documents.view' },
        { id: 'ops-collab',    label: 'Collaboration',  icon: 'message-square', route: '/operations/collaboration' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Reporting',
      expanded: true,
      items: [
        { id: 'report-main', label: 'Reports & Analytics', icon: 'bar-chart-2', route: '/reporting' },
      ]
    },
    {
      section: NavigationSection.EXCEPTIONS,
      label: 'Exceptions',
      expanded: true,
      items: [
        { id: 'exc-queue',   label: 'Exception Queue', icon: 'alert-circle', route: '/exceptions'              },
        { id: 'exc-invest',  label: 'Investigation',   icon: 'search',       route: '/exceptions/investigate', comingSoon: true },
      ]
    },
    {
      section: NavigationSection.ADMIN,
      label: 'Administration',
      expanded: false,
      requiredSection: 'admin',
      items: [
        { id: 'admin-main',      label: 'Admin Console',   icon: 'settings',       route: '/admin', comingSoon: true },
        { id: 'cfg-ref-data',    label: 'Reference Data',  icon: 'database',       route: '/config/reference-data', permission: 'config.reference.manage' },
        { id: 'cfg-ufp',         label: 'UFP Register',    icon: 'layers',         route: '/config/ufp', permission: 'config.ufp.view' },
        { id: 'cfg-maintenance', label: 'System Status',   icon: 'activity',       route: '/config/maintenance', permission: 'config.maintenance.view' },
        { id: 'cfg-webhooks',    label: 'Webhooks',        icon: 'link',           route: '/config/webhooks', permission: 'config.webhooks.manage' },
        { id: 'cfg-sandbox',     label: 'Sandbox',         icon: 'code',           route: '/config/sandbox', permission: 'config.sandbox.manage' },
        { id: 'cfg-history',     label: 'Change History',  icon: 'clock',          route: '/config/history', permission: 'config.history.view' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Compliance',
      expanded: false,
      requiredSection: 'compliance',
      items: [
        { id: 'comp-cases',      label: 'Cases',              icon: 'briefcase',    route: '/compliance/cases', permission: 'compliance.cases.view' },
        { id: 'comp-sanctions',  label: 'Sanctions',          icon: 'shield',       route: '/compliance/sanctions', permission: 'compliance.sanctions.view' },
        { id: 'comp-sar',        label: 'SAR/STR',            icon: 'file-text',    route: '/compliance/sar', permission: 'compliance.sar.create' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Fraud',
      expanded: false,
      requiredSection: 'fraud',
      items: [
        { id: 'fraud-cases',   label: 'Fraud Cases',    icon: 'alert-triangle', route: '/fraud/cases', permission: 'fraud.cases.view' },
        { id: 'fraud-alerts',  label: 'Alerts',         icon: 'bell',           route: '/fraud/alerts', permission: 'fraud.alerts.view' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Treasury',
      expanded: false,
      requiredSection: 'treasury',
      items: [
        { id: 'treas-nostro',    label: 'Nostro Positions', icon: 'database',   route: '/treasury/nostro', permission: 'treasury.nostro.view' },
        { id: 'treas-liquidity', label: 'Liquidity',        icon: 'droplet',    route: '/treasury/liquidity', permission: 'treasury.liquidity.view' },
        { id: 'treas-funding',   label: 'Funding',          icon: 'dollar-sign', route: '/treasury/funding', permission: 'treasury.funding.create' },
        { id: 'treas-fx',        label: 'FX Quotes',        icon: 'trending-up', route: '/treasury/fx', permission: 'treasury.fx.view' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Reconciliation',
      expanded: false,
      requiredSection: 'reconciliation',
      items: [
        { id: 'recon-workspace', label: 'Recon Workspace', icon: 'check-circle', route: '/reconciliation', permission: 'recon.view' },
        { id: 'recon-breaks',    label: 'Breaks',          icon: 'x-circle',     route: '/reconciliation/breaks', permission: 'recon.breaks.manage' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Customers',
      expanded: false,
      requiredSection: 'customers',
      items: [
        { id: 'cust-search', label: 'Customer Search', icon: 'users', route: '/customers', permission: 'customers.view' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Counterparties',
      expanded: false,
      requiredSection: 'counterparties',
      items: [
        { id: 'cpty-search', label: 'Counterparty Search', icon: 'globe', route: '/counterparties', permission: 'counterparty.view' },
      ]
    },
    {
      section: NavigationSection.REPORTING,
      label: 'Incidents',
      expanded: false,
      requiredSection: 'incidents',
      items: [
        { id: 'inc-center', label: 'Command Center', icon: 'activity', route: '/incidents', permission: 'incidents.view' },
      ]
    },
    {
      section: NavigationSection.ADMIN,
      label: 'Audit',
      expanded: false,
      requiredSection: 'audit',
      items: [
        { id: 'audit-log', label: 'Audit Trail', icon: 'eye', route: '/audit', permission: 'audit.read' },
      ]
    },
  ];

  private badgeTimer: ReturnType<typeof setInterval> | null = null;

  constructor(
    private approvalSvc: ApprovalService,
    private queueSvc: QueueService,
    private exceptionSvc: ExceptionService,
    private personaSvc: PersonaService,
  ) {}

  ngOnInit(): void {
    this.loadSectionState();
    this.refreshBadges();
    this.badgeTimer = setInterval(() => this.refreshBadges(), 30_000);
  }

  ngOnDestroy(): void {
    if (this.badgeTimer) clearInterval(this.badgeTimer);
  }

  private refreshBadges(): void {
    this.approvalSvc.getSummary().subscribe(summary => {
      const pendingTotal = summary.pendingL1 + summary.pendingL2 + summary.pendingSenior;
      this.setItemBadge('ops-approvals', pendingTotal,
        pendingTotal > 0 ? (summary.slaBreachCount > 0 ? BadgeSeverity.URGENT : BadgeSeverity.WARNING) : null);
    });
    const urgentQueues = this.queueSvc.getAlertCount();
    const criticalExceptions = this.exceptionSvc.getAlertCount();

    this.setItemBadge('ops-queues', urgentQueues,
      urgentQueues > 0 ? (urgentQueues > 5 ? BadgeSeverity.URGENT : BadgeSeverity.WARNING) : null);
    this.setItemBadge('exc-queue', criticalExceptions,
      criticalExceptions > 0 ? BadgeSeverity.URGENT : null);
  }

  private setItemBadge(id: string, count: number, severity: BadgeSeverity | null): void {
    for (const sec of this.sections) {
      const item = sec.items.find(i => i.id === id);
      if (item) {
        item.badge = count > 0 && severity ? { count, severity } : undefined;
        return;
      }
    }
  }

  private _cachedFilteredSections: NavSection[] = [];
  private _lastSearchQuery = '';
  private _filterDirty = true;

  get filteredSections(): NavSection[] {
    if (!this._filterDirty && this.searchQuery === this._lastSearchQuery) {
      return this._cachedFilteredSections;
    }
    this._lastSearchQuery = this.searchQuery;
    this._filterDirty = false;

    const q = this.searchQuery.trim().toLowerCase();
    let result = this.sections
      .filter(sec => !sec.requiredSection || this.personaSvc.isSectionAllowed(sec.requiredSection))
      .map(sec => ({
        ...sec,
        items: sec.items.filter(it => !it.permission || this.personaSvc.hasPermission(it.permission))
      }))
      .filter(sec => sec.items.length > 0);

    if (q) {
      result = result
        .map(sec => ({ ...sec, items: sec.items.filter(it => it.label.toLowerCase().includes(q)) }))
        .filter(sec => sec.items.length > 0);
    }
    this._cachedFilteredSections = result;
    return result;
  }

  markFilterDirty(): void {
    this._filterDirty = true;
  }

  trackSection(_: number, sec: NavSection): string { return sec.section; }
  trackItem(_: number, item: NavEntry): string { return item.id; }

  toggleSection(section: NavigationSection): void {
    const sec = this.sections.find(s => s.section === section);
    if (sec) { sec.expanded = !sec.expanded; this.saveSectionState(); }
  }

  toggleCollapse(): void {
    this.collapsed = !this.collapsed;
    this.collapsedChanged.emit(this.collapsed);
    try { localStorage.setItem('sidebarCollapsed', JSON.stringify(this.collapsed)); } catch {}
  }

  badgeClass(sev: BadgeSeverity): string { return `badge--${sev}`; }

  private saveSectionState(): void {
    try {
      const state: Record<string, boolean> = {};
      this.sections.forEach(s => { state[s.section] = s.expanded; });
      localStorage.setItem('sidebarSections', JSON.stringify(state));
    } catch {}
  }

  private loadSectionState(): void {
    try {
      const saved = localStorage.getItem('sidebarSections');
      if (saved) {
        const state = JSON.parse(saved) as Record<string, boolean>;
        this.sections.forEach(s => { if (s.section in state) s.expanded = state[s.section]; });
      }
      const col = localStorage.getItem('sidebarCollapsed');
      if (col) this.collapsed = JSON.parse(col);
    } catch {}
  }
}
