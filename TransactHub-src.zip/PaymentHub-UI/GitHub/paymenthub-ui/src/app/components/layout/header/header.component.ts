import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Rail, UserSession, UserPersona } from '../../../shared/types';
import { NotificationService } from '../../../shared/services/notification.service';
import { SearchService } from '../../../shared/services/search.service';
import { PersonaService, PersonaDefinition } from '../../../shared/services/persona.service';
import { NotificationCenterComponent } from '../../../components/notifications/notification-center/notification-center.component';
import { SearchPanelComponent } from '../../../components/search/search-panel/search-panel.component';
import { SettingsPanelComponent } from '../../../shared/components/settings-panel/settings-panel.component';
import { UserMenuComponent } from '../../../shared/components/user-menu/user-menu.component';
import { HelpModalComponent } from '../../../shared/components/help-modal/help-modal.component';

/**
 * HeaderComponent
 * 
 * Fixed header (48px) containing:
 * - Logo with glow effect
 * - Rail switcher (UAEFTS, IPI, IPP, WPS, SWIFT, ALL)
 * - Global search box with keyboard shortcut hint
 * - Icon buttons (notifications, settings, help)
 * - User chip with avatar and persona badge
 * - Session timer
 */
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, FormsModule, NotificationCenterComponent, SearchPanelComponent, SettingsPanelComponent, UserMenuComponent, HelpModalComponent],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  @Input() activeRail: Rail = Rail.ALL;
  @Input() sessionTimeout: number = 900; // 15 minutes in seconds
  
  @Output() railChanged = new EventEmitter<Rail>();
  @Output() sidebarToggled = new EventEmitter<void>();
  @Output() search = new EventEmitter<string>();
  @Output() settingsClicked = new EventEmitter<void>();
  @Output() helpClicked = new EventEmitter<void>();
  @Output() notificationsClicked = new EventEmitter<void>();
  @Output() userClicked = new EventEmitter<void>();

  // Mock user session (would come from auth service)
  userSession: UserSession = {
    userId: 'USR-001',
    username: 'Ahmed Al Zaabi',
    email: 'ahmed.zaabi@bank.ae',
    persona: UserPersona.OPERATOR,
    persona_display: 'OPS',
    permissions: ['read:all', 'approve:payment'],
    session_start: new Date(),
    session_timeout: 900,
    last_activity: new Date(),
    mfa_verified: true
  };

  // Rail list
  railsList = [
    { id: Rail.ALL, label: 'All Rails' },
    { id: Rail.UAEFTS, label: 'UAEFTS' },
    { id: Rail.IPI, label: 'IPI' },
    { id: Rail.IPP, label: 'IPP' },
    { id: Rail.WPS, label: 'WPS' },
    { id: Rail.SWIFT, label: 'SWIFT' }
  ];

  searchQuery = '';
  showSearchPanel = false;
  showNotificationCenter = false;
  showSettingsPanel = false;
  showUserMenu = false;
  showHelpModal = false;
  unreadCount = 0;
  timeUntilTimeout = '';
  showSessionWarning = false;

  private notifSub?: Subscription;
  private sessionTimer?: ReturnType<typeof setInterval>;

  showPersonaSwitcher = false;
  availablePersonas: PersonaDefinition[] = [];

  constructor(private notifSvc: NotificationService, private searchSvc: SearchService, private personaSvc: PersonaService) {}

  ngOnInit(): void {
    this.unreadCount = this.notifSvc.getUnreadCount();
    this.notifSub = this.notifSvc.change$.subscribe(() => {
      this.unreadCount = this.notifSvc.getUnreadCount();
    });
    this.updateSessionTimer();
    this.sessionTimer = setInterval(() => this.updateSessionTimer(), 1000);
  }

  ngOnDestroy(): void {
    this.notifSub?.unsubscribe();
    if (this.sessionTimer) clearInterval(this.sessionTimer);
  }

  /**
   * Handle rail selection change
   */
  onRailChange(rail: Rail): void {
    if (this.activeRail !== rail) {
      this.activeRail = rail;
      this.railChanged.emit(rail);
    }
  }

  onSearch(query: string): void {
    this.searchQuery = query;
    this.showSearchPanel = true;
    if (query.trim().length > 0) {
      this.search.emit(query);
    }
  }

  onSearchFocus(): void {
    this.showSearchPanel = true;
    this.showNotificationCenter = false;
  }

  closeSearchPanel(): void {
    this.showSearchPanel = false;
  }

  onKeyboardShortcut(event: KeyboardEvent): void {
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
      event.preventDefault();
      const searchInput = document.querySelector('.search') as HTMLInputElement;
      if (searchInput) {
        searchInput.focus();
        this.showSearchPanel = true;
      }
    }
  }

  /**
   * Toggle sidebar visibility
   */
  toggleSidebar(): void {
    this.sidebarToggled.emit();
  }

  /**
   * Update session timeout display
   */
  private updateSessionTimer(): void {
    const remainingSeconds = this.sessionTimeout;
    
    if (remainingSeconds < 120) {
      this.showSessionWarning = true;
    }

    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    this.timeUntilTimeout = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  /**
   * Handle settings button click
   */
  onSettingsClick(): void {
    this.showSettingsPanel = !this.showSettingsPanel;
    this.showUserMenu = false;
    this.showHelpModal = false;
    this.settingsClicked.emit();
  }

  onHelpClick(): void {
    this.showHelpModal = !this.showHelpModal;
    this.showSettingsPanel = false;
    this.showUserMenu = false;
    this.helpClicked.emit();
  }

  onUserClick(): void {
    this.showUserMenu = !this.showUserMenu;
    this.showSettingsPanel = false;
    this.showHelpModal = false;
    this.userClicked.emit();
  }

  closeAll(): void {
    this.showSettingsPanel = false;
    this.showUserMenu = false;
    this.showHelpModal = false;
    this.showNotificationCenter = false;
    this.showSearchPanel = false;
  }

  onNotificationsClick(): void {
    this.showNotificationCenter = !this.showNotificationCenter;
    if (this.showNotificationCenter) this.showSearchPanel = false;
    this.notificationsClicked.emit();
  }

  closeNotificationCenter(): void {
    this.showNotificationCenter = false;
  }

  /**
   * Get user avatar initials
   */
  getUserInitials(): string {
    const names = this.userSession.username.split(' ');
    return names.map(n => n.charAt(0).toUpperCase()).join('').substring(0, 2);
  }

  /**
   * Get user persona color/badge
   */
  getPersonaBadgeClass(): string {
    return `persona-${this.userSession.persona.toLowerCase()}`;
  }

  togglePersonaSwitcher(): void {
    this.showPersonaSwitcher = !this.showPersonaSwitcher;
    if (this.showPersonaSwitcher) {
      this.availablePersonas = this.personaSvc.getAvailablePersonas();
    }
  }

  switchPersona(personaId: string): void {
    this.personaSvc.switchPersona(personaId);
    this.showPersonaSwitcher = false;
    const def = this.availablePersonas.find(p => p.id === personaId);
    if (def) {
      this.userSession = { ...this.userSession, persona_display: def.displayName };
    }
  }

  getActivePersonaDisplay(): string {
    const active = this.personaSvc.activePersona();
    return active?.displayName ?? this.userSession.persona_display;
  }
}
