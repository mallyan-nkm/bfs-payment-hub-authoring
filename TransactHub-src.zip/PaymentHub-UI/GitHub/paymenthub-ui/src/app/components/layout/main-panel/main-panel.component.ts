import { Component, Input, ContentChild, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Breadcrumb } from '../../../shared/types';

/**
 * MainPanelComponent
 * 
 * Center content area of the application
 * - Breadcrumb navigation
 * - Page title area
 * - Tab support (for tabbed layouts)
 * - Scrollable content area
 * - Supports single-pane, tabbed, and split-pane layouts
 */
@Component({
  selector: 'app-main-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './main-panel.component.html',
  styleUrls: ['./main-panel.component.scss']
})
export class MainPanelComponent {
  @Input() breadcrumbs: Breadcrumb[] = [];
  @Input() sidebarCollapsed: boolean = false;
  @Input() pageTitle: string = '';
  @Input() pageSubtitle: string = '';

  // Template for custom header content
  @ContentChild('panelHeader') panelHeader: TemplateRef<any> | null = null;

  /**
   * Navigate to breadcrumb route
   */
  navigateTo(route: string | undefined): void {
    if (route) {
      // TODO: Implement router navigation
      console.log('Navigating to:', route);
    }
  }

  /**
   * Check if breadcrumb is the current page
   */
  isCurrent(breadcrumb: Breadcrumb): boolean {
    return breadcrumb.current === true;
  }
}
