import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { KpiCardComponent } from '../kpi-card/kpi-card.component';
import { RailHealthCardComponent } from '../rail-health-card/rail-health-card.component';
import { RefreshBarComponent } from '../refresh-bar/refresh-bar.component';
import {
  WpsDashboardData,
  WpsFile,
  WpsRefundFlow,
  DashboardKPI,
  DashboardRefreshConfig
} from '../../../shared/types';
import { DashboardService } from '../../../shared/services/dashboard.service';

@Component({
  selector: 'app-wps-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, KpiCardComponent, RailHealthCardComponent, RefreshBarComponent],
  templateUrl: './wps-dashboard.component.html',
  styleUrls: ['./wps-dashboard.component.scss']
})
export class WpsDashboardComponent implements OnInit, OnDestroy {

  data!: WpsDashboardData;
  kpis: DashboardKPI[] = [];
  recentTransactions: {
    id: string;
    reference: string;
    workflowType: string;
    status: string;
    direction: string;
    tenant: string;
    startTime: Date;
    duration: string;
  }[] = [];
  refreshConfig: DashboardRefreshConfig = {
    autoRefresh: true,
    intervalSeconds: 60,
    lastRefreshed: new Date(),
    isPaused: false
  };

  private refreshTimer: ReturnType<typeof setInterval> | null = null;

  constructor(readonly svc: DashboardService) {}

  ngOnInit(): void {
    this.loadData();
    this.scheduleAutoRefresh();
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  private loadData(): void {
    this.svc.getWpsDashboardData().subscribe(data => {
      this.data = data;
      this.kpis = this.buildKpis();
      this.refreshConfig = { ...this.refreshConfig, lastRefreshed: new Date() };
    });

    this.svc.fetchWorkflowInstances().subscribe(workflows => {
      const railWf = workflows.filter(wf => {
        const id = wf.id.toUpperCase();
        return id.includes('WPS_SALARY') || id.includes('_WPS_');
      });
      this.recentTransactions = railWf.slice(0, 20).map(wf => ({
        id: this.extractTransactionId(wf.id),
        reference: wf.id,
        workflowType: this.extractWorkflowType(wf.workflowName || wf.id),
        status: wf.status,
        direction: this.resolveDirection(wf.id),
        tenant: wf.tenantId || '—',
        startTime: new Date(wf.startTime),
        duration: wf.closeTime ? this.calcDuration(new Date(wf.startTime), new Date(wf.closeTime)) : 'In Progress'
      }));
    });
  }

  private buildKpis(): DashboardKPI[] {
    const k = this.data.kpis;
    return [
      {
        id: 'file-completion-rate',
        label: 'File Completion Rate',
        value: k.fileCompletionRatePct.toFixed(1),
        unit: '%',
        color: k.fileCompletionRatePct >= 98 ? 'success' : k.fileCompletionRatePct >= 95 ? 'warning' : 'danger',
        trend: [94.0, 95.2, 95.8, 96.4, 96.6, k.fileCompletionRatePct],
        subtitle: 'All file types'
      },
      {
        id: 'credit-success-rate',
        label: 'Employee Credit Success',
        value: k.employeeCreditSuccessRatePct.toFixed(1),
        unit: '%',
        color: k.employeeCreditSuccessRatePct >= 99 ? 'success' : k.employeeCreditSuccessRatePct >= 97 ? 'warning' : 'danger',
        trend: [98.5, 98.7, 98.9, 99.0, 99.0, k.employeeCreditSuccessRatePct],
        subtitle: 'Current cycle'
      },
      {
        id: 'active-cycles',
        label: 'Active Cycles',
        value: k.activeCycles,
        color: k.activeCycles > 5 ? 'warning' : 'accent',
        subtitle: 'In progress'
      },
      {
        id: 'failed-credits',
        label: 'Failed Credits',
        value: k.failedCredits.toLocaleString(),
        color: k.failedCredits > 100 ? 'danger' : k.failedCredits > 50 ? 'warning' : 'success',
        subtitle: 'Require remediation',
        clickRoute: '/exceptions/active'
      },
      {
        id: 'total-employees-credited',
        label: 'Employees Credited',
        value: k.totalEmployeesCredited.toLocaleString(),
        color: 'teal',
        subtitle: 'Current cycle total'
      }
    ];
  }

  private scheduleAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (!this.refreshConfig.isPaused && this.refreshConfig.autoRefresh) {
        this.loadData();
      }
    }, this.refreshConfig.intervalSeconds * 1000);
  }

  onRefresh(): void {
    this.loadData();
  }

  onPauseToggle(): void {
    this.refreshConfig = { ...this.refreshConfig, isPaused: !this.refreshConfig.isPaused };
    this.svc.togglePause();
  }

  onIntervalChange(seconds: number): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    this.refreshConfig = { ...this.refreshConfig, intervalSeconds: seconds };
    this.scheduleAutoRefresh();
  }

  getMohreClass(s: string): string {
    const map: Record<string, string> = {
      'compliant':     'mohre--compliant',
      'non-compliant': 'mohre--non-compliant',
      'pending':       'mohre--pending'
    };
    return map[s] ?? '';
  }

  getFileStatusClass(s: WpsFile['status']): string {
    const map: Record<WpsFile['status'], string> = {
      processing: 'file-status--processing',
      completed:  'file-status--completed',
      failed:     'file-status--failed',
      pending:    'file-status--pending'
    };
    return map[s];
  }

  getFlowStatusClass(s: WpsRefundFlow['status']): string {
    const map: Record<WpsRefundFlow['status'], string> = {
      active:    'flow-status--active',
      pending:   'flow-status--pending',
      completed: 'flow-status--completed'
    };
    return map[s];
  }

  getFileTypeDesc(t: WpsFile['fileType']): string {
    const map: Record<WpsFile['fileType'], string> = {
      SIF: 'Salary Information File',
      PIF: 'Payment Instruction File',
      DIF: 'Direct Instruction File',
      RFA: 'Return File Acknowledgement',
      RTC: 'Return Transaction Credit'
    };
    return map[t];
  }

  getFlowTypeDesc(t: WpsRefundFlow['flowType']): string {
    const map: Record<WpsRefundFlow['flowType'], string> = {
      RFR: 'Refund Request',
      RRI: 'Refund Response Initiation',
      RRR: 'Refund Response Return',
      DCR: 'Direct Credit Return',
      RSU: 'Return Status Update'
    };
    return map[t];
  }

  private extractTransactionId(workflowId: string): string {
    const match = workflowId.match(/TXN-[A-Z]*-?\d+/i);
    return match ? match[0] : workflowId;
  }

  private extractWorkflowType(nameOrId: string): string {
    // Map known WPS workflow names to user-friendly labels
    const id = nameOrId.toUpperCase();
    if (id.includes('WPS_SALARY_OUTBOUND')) return 'Salary Payment';
    if (id.includes('WPS_SALARY_INBOUND')) return 'Salary Return';
    if (id.includes('WPS_REFUND')) return 'Refund';
    if (id.includes('WPS_RETURN')) return 'Return';
    if (id.includes('WPS_CREDIT')) return 'Credit';
    if (id.includes('WPS')) return 'WPS Payment';
    return nameOrId.split('_').slice(0, 3).join(' ');
  }

  private resolveDirection(workflowId: string): string {
    const id = workflowId.toUpperCase();
    if (id.includes('OUTWARD') || id.includes('OUTBOUND')) return 'Outward';
    if (id.includes('INWARD') || id.includes('INBOUND') || id.includes('RETURN')) return 'Inward';
    // WPS Salary is always outbound by nature
    if (id.includes('WPS_SALARY')) return 'Outward';
    return 'Outward';
  }

  private calcDuration(start: Date, end: Date): string {
    const ms = end.getTime() - start.getTime();
    if (ms < 1000) return `${ms}ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
    return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
  }
}
