import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { RailHealth, StatusIndicator, Rail } from '../../../shared/types';
import { DashboardService } from '../../../shared/services/dashboard.service';

@Component({
  selector: 'app-rail-health-card',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './rail-health-card.component.html',
  styleUrls: ['./rail-health-card.component.scss']
})
export class RailHealthCardComponent {
  @Input({ required: true }) health!: RailHealth;

  readonly StatusIndicator = StatusIndicator;

  constructor(private svc: DashboardService) {}

  get railRoute(): string {
    const map: Partial<Record<Rail, string>> = {
      [Rail.UAEFTS]: '/dashboard/uaefts',
      [Rail.IPI]:    '/dashboard/ipi',
      [Rail.IPP]:    '/dashboard/ipp',
      [Rail.WPS]:    '/dashboard/wps',
      [Rail.SWIFT]:  '/dashboard/swift'
    };
    return map[this.health.rail] ?? '/dashboard';
  }

  get throughputPct(): number {
    if (!this.health.throughputTypical) return 0;
    return this.svc.getThroughputPct(this.health.throughput, this.health.throughputTypical);
  }

  get statusLabel(): string {
    const labels: Record<StatusIndicator, string> = {
      [StatusIndicator.OPERATIONAL]: 'Operational',
      [StatusIndicator.DEGRADED]:    'Degraded',
      [StatusIndicator.OUTAGE]:      'Outage',
      [StatusIndicator.UNKNOWN]:     'Unknown'
    };
    return labels[this.health.status];
  }

  formatLatency(ms: number | undefined): string {
    if (ms === undefined) return '—';
    return this.svc.formatLatency(ms);
  }
}
