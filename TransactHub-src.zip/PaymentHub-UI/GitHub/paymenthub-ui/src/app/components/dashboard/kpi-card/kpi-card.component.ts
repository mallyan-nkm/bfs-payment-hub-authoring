import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DashboardKPI } from '../../../shared/types';
import { CountUpDirective } from '../../../shared/directives/count-up.directive';

@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [CommonModule, RouterLink, CountUpDirective],
  templateUrl: './kpi-card.component.html',
  styleUrls: ['./kpi-card.component.scss']
})
export class KpiCardComponent {
  @Input({ required: true }) kpi!: DashboardKPI;

  get deltaSymbol(): string {
    if (!this.kpi.delta) return '';
    return this.kpi.delta > 0 ? '▲' : '▼';
  }

  get deltaClass(): string {
    if (!this.kpi.deltaType) return '';
    // For exceptions/errors, 'up' is bad; for throughput/SLA, 'up' is good
    return `delta--${this.kpi.deltaType}`;
  }

  get sparklinePoints(): string {
    const trend = this.kpi.trend;
    if (!trend || trend.length < 2) return '';
    const max = Math.max(...trend);
    const min = Math.min(...trend);
    const range = max - min || 1;
    const w = 80;
    const h = 24;
    const step = w / (trend.length - 1);
    return trend
      .map((v, i) => `${i * step},${h - ((v - min) / range) * h}`)
      .join(' ');
  }
}
