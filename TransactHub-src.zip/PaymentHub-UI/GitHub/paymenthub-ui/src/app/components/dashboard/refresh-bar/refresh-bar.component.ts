import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRefreshConfig } from '../../../shared/types';

@Component({
  selector: 'app-refresh-bar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './refresh-bar.component.html',
  styleUrls: ['./refresh-bar.component.scss']
})
export class RefreshBarComponent implements OnInit, OnDestroy {
  @Input({ required: true }) config!: DashboardRefreshConfig;
  @Output() refresh = new EventEmitter<void>();
  @Output() pauseToggle = new EventEmitter<void>();
  @Output() intervalChange = new EventEmitter<number>();

  readonly intervalOptions = [10, 30, 60, 120];
  timeSinceRefresh = '0s ago';
  private ticker: ReturnType<typeof setInterval> | null = null;

  ngOnInit(): void {
    this.ticker = setInterval(() => this.updateTimeSince(), 1000);
  }

  ngOnDestroy(): void {
    if (this.ticker) clearInterval(this.ticker);
  }

  private updateTimeSince(): void {
    const diffMs = Date.now() - this.config.lastRefreshed.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    if (diffSec < 60) {
      this.timeSinceRefresh = `${diffSec}s ago`;
    } else {
      this.timeSinceRefresh = `${Math.floor(diffSec / 60)}m ago`;
    }
  }

  onRefresh(): void {
    this.refresh.emit();
  }

  onPauseToggle(): void {
    this.pauseToggle.emit();
  }

  onIntervalChange(seconds: number): void {
    this.intervalChange.emit(seconds);
  }
}
