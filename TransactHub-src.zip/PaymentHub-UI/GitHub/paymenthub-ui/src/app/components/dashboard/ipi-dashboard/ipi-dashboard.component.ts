import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { KpiCardComponent } from '../kpi-card/kpi-card.component';
import { RailHealthCardComponent } from '../rail-health-card/rail-health-card.component';
import { RefreshBarComponent } from '../refresh-bar/refresh-bar.component';
import {
  IpiDashboardData,
  DashboardKPI,
  DashboardRefreshConfig,
  StatusIndicator
} from '../../../shared/types';
import { DashboardService } from '../../../shared/services/dashboard.service';

@Component({
  selector: 'app-ipi-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, KpiCardComponent, RailHealthCardComponent, RefreshBarComponent],
  templateUrl: './ipi-dashboard.component.html',
  styleUrls: ['./ipi-dashboard.component.scss']
})
export class IpiDashboardComponent implements OnInit, OnDestroy {

  data!: IpiDashboardData;
  kpis: DashboardKPI[] = [];
  recentTransactions: { id: string; status: string; direction: string; startTime: Date; duration: string }[] = [];
  refreshConfig: DashboardRefreshConfig = {
    autoRefresh: true,
    intervalSeconds: 30,
    lastRefreshed: new Date(),
    isPaused: false
  };

  private refreshTimer: ReturnType<typeof setInterval> | null = null;

  constructor(readonly svc: DashboardService) {}

  ngOnInit(): void {
    this.loadData();
    this.scheduleAutoRefresh();
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  private loadData(): void {
    this.svc.getIpiDashboardData().subscribe(data => {
      this.data = data;
      this.kpis = this.buildKpis();
      this.refreshConfig = { ...this.refreshConfig, lastRefreshed: new Date() };
    });

    this.svc.fetchWorkflowInstances().subscribe(workflows => {
      const railWf = workflows.filter(wf => {
        const id = wf.id.toUpperCase();
        return id.includes('IPI_OUTWARD') || id.includes('IPI_INWARD') || id.includes('_IPI_')
          || id.startsWith('RETRY-') || id.includes('-RETRY-');
      });
      this.recentTransactions = railWf.slice(0, 20).map(wf => ({
        id: this.extractTransactionId(wf.id),
        status: wf.status,
        direction: wf.id.toUpperCase().includes('OUTWARD') ? 'Outward' : wf.id.toUpperCase().includes('INWARD') ? 'Inward' : 'N/A',
        startTime: new Date(wf.startTime),
        duration: wf.closeTime ? this.calcDuration(new Date(wf.startTime), new Date(wf.closeTime)) : 'In Progress'
      }));
    });
  }

  private buildKpis(): DashboardKPI[] {
    const k = this.data.kpis;
    return [
      {
        id: 'throughput-per-sec',
        label: 'Throughput / sec',
        value: k.throughputPerSec.toFixed(1),
        unit: 'tps',
        color: 'accent',
        trend: [14.2, 15.8, 16.1, 17.3, 18.0, k.throughputPerSec],
        subtitle: 'Live rate'
      },
      {
        id: 'latency-p50',
        label: 'P50 Latency',
        value: this.svc.formatLatency(k.latencyP50Ms),
        color: k.latencyP50Ms > 400 ? 'warning' : 'success',
        trend: [160, 170, 175, 180, 178, k.latencyP50Ms],
        subtitle: 'Median'
      },
      {
        id: 'latency-p95',
        label: 'P95 Latency',
        value: this.svc.formatLatency(k.latencyP95Ms),
        color: k.latencyP95Ms > 800 ? 'warning' : 'success',
        trend: [390, 400, 415, 420, 418, k.latencyP95Ms],
        subtitle: '95th percentile'
      },
      {
        id: 'latency-p99',
        label: 'P99 Latency',
        value: this.svc.formatLatency(k.latencyP99Ms),
        color: k.latencyP99Ms > 1200 ? 'danger' : k.latencyP99Ms > 900 ? 'warning' : 'success',
        trend: [640, 655, 668, 680, 672, k.latencyP99Ms],
        subtitle: '99th percentile'
      },
      {
        id: 'instant-confirm-rate',
        label: 'Instant Confirm Rate',
        value: k.instantConfirmRatePct.toFixed(2),
        unit: '%',
        color: k.instantConfirmRatePct >= 99.5 ? 'success' : k.instantConfirmRatePct >= 99 ? 'warning' : 'danger',
        trend: [99.50, 99.55, 99.60, 99.68, 99.70, k.instantConfirmRatePct],
        subtitle: 'Sub-second SLA'
      }
    ];
  }

  private scheduleAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (!this.refreshConfig.isPaused && this.refreshConfig.autoRefresh) {
        this.loadData();
      }
    }, this.refreshConfig.intervalSeconds * 1000);
  }

  onRefresh(): void {
    this.loadData();
  }

  onPauseToggle(): void {
    this.refreshConfig = { ...this.refreshConfig, isPaused: !this.refreshConfig.isPaused };
    this.svc.togglePause();
  }

  onIntervalChange(seconds: number): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    this.refreshConfig = { ...this.refreshConfig, intervalSeconds: seconds };
    this.scheduleAutoRefresh();
  }

  get slaColorClass(): string {
    const pct = this.data.subSecondSlaCompliancePct;
    if (pct >= 99.5) return 'sla--green';
    if (pct >= 99)   return 'sla--yellow';
    return 'sla--red';
  }

  get hourlyBarMax(): number {
    if (!this.data?.hourlyVolume?.length) return 1;
    return Math.max(...this.data.hourlyVolume.map(h => h.count));
  }

  getBarHeightPct(count: number): number {
    const max = this.hourlyBarMax;
    return max > 0 ? Math.round((count / max) * 100) : 0;
  }

  getStatusIndicatorClass(s: StatusIndicator): string {
    const map: Record<StatusIndicator, string> = {
      [StatusIndicator.OPERATIONAL]: 'si--operational',
      [StatusIndicator.DEGRADED]:    'si--degraded',
      [StatusIndicator.OUTAGE]:      'si--outage',
      [StatusIndicator.UNKNOWN]:     'si--unknown'
    };
    return map[s] ?? 'si--unknown';
  }

  getStatusIndicatorLabel(s: StatusIndicator): string {
    const map: Record<StatusIndicator, string> = {
      [StatusIndicator.OPERATIONAL]: 'Operational',
      [StatusIndicator.DEGRADED]:    'Degraded',
      [StatusIndicator.OUTAGE]:      'Outage',
      [StatusIndicator.UNKNOWN]:     'Unknown'
    };
    return map[s] ?? 'Unknown';
  }

  private extractTransactionId(workflowId: string): string {
    const match = workflowId.match(/TXN-[A-Z]*-?\d+/i);
    return match ? match[0] : workflowId.split('-').slice(-1)[0];
  }

  private calcDuration(start: Date, end: Date): string {
    const ms = end.getTime() - start.getTime();
    if (ms < 1000) return `${ms}ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
    return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
  }
}
