import { Component, Input, Output, EventEmitter, signal, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkDragDrop, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';
import { WidgetWrapperComponent } from '../widget-wrapper/widget-wrapper.component';
import { WidgetLibraryDrawerComponent } from '../widget-library-drawer/widget-library-drawer.component';
import { LayoutManagerComponent } from '../layout-manager/layout-manager.component';
import { WorkspaceService, WidgetInstance, WorkspaceLayout } from '../../../../shared/services/workspace.service';

@Component({
  selector: 'app-workspace-shell',
  standalone: true,
  imports: [CommonModule, DragDropModule, WidgetWrapperComponent, WidgetLibraryDrawerComponent, LayoutManagerComponent],
  template: `
    <div class="workspace-shell">
      <div class="workspace-toolbar">
        <app-layout-manager
          [layouts]="workspaceService.savedLayouts()"
          [currentLayoutName]="workspaceService.currentLayoutName()"
          (saveLayout)="onSaveLayout($event)"
          (loadLayout)="onLoadLayout($event)"
          (resetLayout)="onResetLayout()"
          (toggleLibrary)="showLibrary.set(!showLibrary())">
        </app-layout-manager>
      </div>

      <div class="workspace-content">
        <div class="widget-grid" cdkDropList (cdkDropListDropped)="onDrop($event)">
          @for (widget of workspaceService.activeWidgets(); track widget.instanceId) {
            <app-widget-wrapper
              [widget]="widget"
              cdkDrag
              [cdkDragData]="widget"
              (remove)="onRemoveWidget(widget.instanceId)"
              (resize)="onResizeWidget(widget.instanceId, $event)">
            </app-widget-wrapper>
          }
          @if (workspaceService.activeWidgets().length === 0) {
            <div class="empty-workspace">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
              </svg>
              <p>No widgets configured</p>
              <button class="btn-add-widget" (click)="showLibrary.set(true)">Add Widgets</button>
            </div>
          }
        </div>

        @if (showLibrary()) {
          <app-widget-library-drawer
            (addWidget)="onAddWidget($event)"
            (close)="showLibrary.set(false)">
          </app-widget-library-drawer>
        }
      </div>
    </div>
  `,
  styles: [`
    .workspace-shell { display: flex; flex-direction: column; height: 100%; gap: 0.5rem; }
    .workspace-toolbar { display: flex; align-items: center; padding: 0.5rem 1rem; border-bottom: 1px solid var(--border); }
    .workspace-content { display: flex; flex: 1; overflow: hidden; position: relative; }
    .widget-grid {
      display: grid;
      grid-template-columns: repeat(12, 1fr);
      gap: 0.75rem;
      padding: 1rem;
      flex: 1;
      overflow-y: auto;
      align-content: start;
    }
    .empty-workspace {
      grid-column: 1 / -1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
      color: var(--text-2);
      gap: 1rem;
    }
    .btn-add-widget {
      padding: 0.5rem 1.25rem;
      background: var(--accent);
      color: #fff;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
    }
  `]
})
export class WorkspaceShellComponent implements OnInit {
  readonly workspaceService = inject(WorkspaceService);
  showLibrary = signal(false);

  ngOnInit(): void {
    this.workspaceService.loadUserLayout();
  }

  onDrop(event: CdkDragDrop<WidgetInstance[]>): void {
    const widgets = [...this.workspaceService.activeWidgets()];
    moveItemInArray(widgets, event.previousIndex, event.currentIndex);
    this.workspaceService.reorderWidgets(widgets);
  }

  onAddWidget(widgetId: string): void {
    this.workspaceService.addWidget(widgetId);
  }

  onRemoveWidget(instanceId: string): void {
    this.workspaceService.removeWidget(instanceId);
  }

  onResizeWidget(instanceId: string, size: { cols: number; rows: number }): void {
    this.workspaceService.resizeWidget(instanceId, size);
  }

  onSaveLayout(name: string): void {
    this.workspaceService.saveLayout(name);
  }

  onLoadLayout(name: string): void {
    this.workspaceService.loadLayout(name);
  }

  onResetLayout(): void {
    this.workspaceService.resetToDefault();
  }
}
