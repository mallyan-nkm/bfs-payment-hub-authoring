import { Component, Output, EventEmitter, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkspaceService, WidgetDefinition } from '../../../../shared/services/workspace.service';

@Component({
  selector: 'app-widget-library-drawer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="library-drawer">
      <div class="drawer-header">
        <h3>Widget Library</h3>
        <button class="btn-close" (click)="close.emit()" aria-label="Close">✕</button>
      </div>
      <div class="drawer-body">
        @for (category of categories; track category) {
          <div class="category-group">
            <h4 class="category-label">{{ category }}</h4>
            <div class="widget-list">
              @for (widget of getWidgetsByCategory(category); track widget.id) {
                <button class="widget-card" (click)="addWidget.emit(widget.id)" [title]="widget.description">
                  <span class="widget-name">{{ widget.name }}</span>
                  <span class="widget-size">{{ widget.defaultSize.cols }}×{{ widget.defaultSize.rows }}</span>
                </button>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .library-drawer {
      width: 280px;
      background: var(--bg-1);
      border-left: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      overflow-y: auto;
    }
    .drawer-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.75rem 1rem;
      border-bottom: 1px solid var(--border);
    }
    .drawer-header h3 { font-size: 0.875rem; font-weight: 600; color: var(--text-0); margin: 0; }
    .btn-close { background: none; border: none; color: var(--text-2); cursor: pointer; font-size: 1rem; }
    .drawer-body { padding: 0.75rem; }
    .category-group { margin-bottom: 1rem; }
    .category-label { font-size: 0.6875rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-3); margin: 0 0 0.5rem; }
    .widget-list { display: flex; flex-direction: column; gap: 0.375rem; }
    .widget-card {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem 0.75rem;
      background: var(--bg-2);
      border: 1px solid var(--border);
      border-radius: 6px;
      cursor: pointer;
      transition: border-color 0.15s;
    }
    .widget-card:hover { border-color: var(--accent); }
    .widget-name { font-size: 0.8125rem; color: var(--text-0); }
    .widget-size { font-size: 0.6875rem; color: var(--text-3); }
  `]
})
export class WidgetLibraryDrawerComponent {
  @Output() addWidget = new EventEmitter<string>();
  @Output() close = new EventEmitter<void>();

  private workspaceService = inject(WorkspaceService);

  get categories(): string[] {
    const cats = new Set(this.workspaceService.availableWidgets().map(w => w.category));
    return [...cats];
  }

  getWidgetsByCategory(category: string): WidgetDefinition[] {
    return this.workspaceService.availableWidgets().filter(w => w.category === category);
  }
}
