import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WidgetInstance } from '../../../../shared/services/workspace.service';

@Component({
  selector: 'app-widget-wrapper',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="widget-wrapper" [style.grid-column]="'span ' + widget.size.cols" [style.grid-row]="'span ' + widget.size.rows">
      <div class="widget-header">
        <span class="widget-title">{{ widget.title }}</span>
        <div class="widget-actions">
          <button class="widget-btn" title="Resize Small" (click)="resize.emit({ cols: 3, rows: 2 })">S</button>
          <button class="widget-btn" title="Resize Medium" (click)="resize.emit({ cols: 6, rows: 2 })">M</button>
          <button class="widget-btn" title="Resize Large" (click)="resize.emit({ cols: 12, rows: 3 })">L</button>
          <button class="widget-btn widget-btn--danger" title="Remove" (click)="remove.emit()">✕</button>
        </div>
      </div>
      <div class="widget-body">
        <ng-content></ng-content>
        <div class="widget-placeholder">
          <span>{{ widget.title }}</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .widget-wrapper {
      background: var(--bg-2);
      border: 1px solid var(--border);
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      min-height: 120px;
      overflow: hidden;
      transition: box-shadow 0.2s;
    }
    .widget-wrapper:hover { box-shadow: 0 2px 12px rgba(0,0,0,0.3); }
    .widget-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem 0.75rem;
      border-bottom: 1px solid var(--border);
      background: var(--bg-3);
      cursor: move;
    }
    .widget-title { font-size: 0.75rem; font-weight: 600; color: var(--text-1); text-transform: uppercase; letter-spacing: 0.03em; }
    .widget-actions { display: flex; gap: 0.25rem; }
    .widget-btn {
      width: 22px; height: 22px;
      display: flex; align-items: center; justify-content: center;
      border: 1px solid var(--border); border-radius: 4px;
      background: var(--bg-1); color: var(--text-2);
      font-size: 0.625rem; cursor: pointer;
    }
    .widget-btn:hover { background: var(--accent); color: #fff; border-color: var(--accent); }
    .widget-btn--danger:hover { background: var(--danger); border-color: var(--danger); }
    .widget-body { flex: 1; display: flex; align-items: center; justify-content: center; padding: 1rem; }
    .widget-placeholder { color: var(--text-3); font-size: 0.8125rem; }
  `]
})
export class WidgetWrapperComponent {
  @Input({ required: true }) widget!: WidgetInstance;
  @Output() remove = new EventEmitter<void>();
  @Output() resize = new EventEmitter<{ cols: number; rows: number }>();
}
