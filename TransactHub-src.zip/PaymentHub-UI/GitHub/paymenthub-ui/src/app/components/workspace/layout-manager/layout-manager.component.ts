import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkspaceLayout } from '../../../../shared/services/workspace.service';

@Component({
  selector: 'app-layout-manager',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="layout-manager">
      <div class="layout-info">
        <span class="layout-label">Layout:</span>
        <span class="layout-name">{{ currentLayoutName || 'Default' }}</span>
      </div>

      <div class="layout-actions">
        @if (layouts.length > 0) {
          <select class="layout-select" (change)="onLayoutSelect($event)">
            <option value="">Switch Layout...</option>
            @for (layout of layouts; track layout.name) {
              <option [value]="layout.name">{{ layout.name }}</option>
            }
          </select>
        }

        <button class="btn-toolbar" title="Save Layout" (click)="onSave()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
            <polyline points="17,21 17,13 7,13 7,21"/><polyline points="7,3 7,8 15,8"/>
          </svg>
        </button>

        <button class="btn-toolbar" title="Widget Library" (click)="toggleLibrary.emit()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
            <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
          </svg>
        </button>

        <button class="btn-toolbar" title="Reset to Default" (click)="resetLayout.emit()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="1,4 1,10 7,10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/>
          </svg>
        </button>
      </div>
    </div>
  `,
  styles: [`
    .layout-manager { display: flex; align-items: center; justify-content: space-between; width: 100%; }
    .layout-info { display: flex; align-items: center; gap: 0.5rem; }
    .layout-label { font-size: 0.75rem; color: var(--text-3); }
    .layout-name { font-size: 0.8125rem; font-weight: 600; color: var(--text-0); }
    .layout-actions { display: flex; align-items: center; gap: 0.5rem; }
    .layout-select {
      background: var(--bg-2); border: 1px solid var(--border); border-radius: 4px;
      color: var(--text-1); font-size: 0.75rem; padding: 0.25rem 0.5rem;
    }
    .btn-toolbar {
      display: flex; align-items: center; justify-content: center;
      width: 28px; height: 28px; border-radius: 4px;
      background: var(--bg-2); border: 1px solid var(--border);
      color: var(--text-2); cursor: pointer;
    }
    .btn-toolbar:hover { background: var(--accent); color: #fff; border-color: var(--accent); }
  `]
})
export class LayoutManagerComponent {
  @Input() layouts: WorkspaceLayout[] = [];
  @Input() currentLayoutName = '';
  @Output() saveLayout = new EventEmitter<string>();
  @Output() loadLayout = new EventEmitter<string>();
  @Output() resetLayout = new EventEmitter<void>();
  @Output() toggleLibrary = new EventEmitter<void>();

  onSave(): void {
    const name = prompt('Layout name:');
    if (name?.trim()) {
      this.saveLayout.emit(name.trim());
    }
  }

  onLayoutSelect(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    if (value) this.loadLayout.emit(value);
  }
}
