import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import {
  QueueFilter, QueueSort, QueuePage, QueueItem, QueueTypeTab, QuickFilter,
  BulkAction, BulkActionRequest, BulkActionResult, SavedFilterSet, QueueType,
  TransactionDetail, DetailActionEvent, BulkRefundCampaign, RefundReasonCode,
} from '../../../shared/types';
import { QueueService } from '../../../shared/services/queue.service';
import { TransactionApiService } from '../../../shared/services/transaction-api.service';
import { RefundService } from '../../../shared/services/refund.service';
import { ExportService } from '../../../shared/services/export.service';
import { ToastService } from '../../../shared/services/toast.service';
import { QuickFilterBarComponent } from '../quick-filter-bar/quick-filter-bar.component';
import { QueueFilterPanelComponent } from '../queue-filter-panel/queue-filter-panel.component';
import { QueueTableComponent, QueueTableActionEvent } from '../queue-table/queue-table.component';
import { BulkActionBarComponent } from '../bulk-action-bar/bulk-action-bar.component';
import { TransactionDetailComponent } from '../transaction-detail/transaction-detail.component';
import { RefundRequestModalComponent, RefundModalResult } from '../refund-request-modal/refund-request-modal.component';
import { DataFreshnessComponent } from '../../../shared/components/data-freshness/data-freshness.component';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';

const DEFAULT_FILTER: QueueFilter = {
  search: '',
  rails: [],
  statuses: [],
  priorities: [],
  types: [],
  paymentSubTypes: [],
  slaStatuses: [],
  dateFrom: null,
  dateTo: null,
  amountMin: null,
  amountMax: null,
  assignedTo: '',
  urgentOnly: false,
  queueType: QueueType.ALL,
  logic: 'AND',
};

@Component({
  selector: 'app-payment-queues-page',
  standalone: true,
  imports: [
    CommonModule,
    QuickFilterBarComponent,
    QueueFilterPanelComponent,
    QueueTableComponent,
    BulkActionBarComponent,
    TransactionDetailComponent,
    RefundRequestModalComponent,
    DataFreshnessComponent,
    EmptyStateComponent,
  ],
  templateUrl: './payment-queues-page.component.html',
  styleUrls: ['./payment-queues-page.component.scss']
})
export class PaymentQueuesPageComponent implements OnInit, OnDestroy {

  // ── State ─────────────────────────────────────────────────────────────────
  filter: QueueFilter = { ...DEFAULT_FILTER };
  sort: QueueSort = { column: 'submittedAt', direction: 'desc' };
  currentPage = 1;
  pageSize = 25;

  page: QueuePage = { items: [], totalCount: 0, filteredCount: 0, page: 1, pageSize: 25 };
  isLoading = false;
  filterPanelOpen = true;

  queueTypeTabs: QueueTypeTab[] = [];
  quickFilters: QuickFilter[] = [];
  activeQuickFilterId = 'all';
  bulkActions: BulkAction[] = [];
  savedFilters: SavedFilterSet[] = [];
  selectedIds: string[] = [];

  lastActionResult: BulkActionResult | null = null;
  selectedDetail: TransactionDetail | null = null;
  detailLoading = false;
  lastUpdated = new Date();

  // ── Refund modal state ────────────────────────────────────────────────────
  refundModalItem: QueueItem | null = null;
  lastBulkRefundCampaign: BulkRefundCampaign | null = null;

  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private refreshTimer: ReturnType<typeof setInterval> | null = null;
  private loadSub: Subscription | null = null;

  constructor(
    private svc: QueueService,
    private txnApi: TransactionApiService,
    private refundSvc: RefundService,
    private exportSvc: ExportService,
    private toastSvc: ToastService,
  ) {}

  ngOnInit(): void {
    this.bulkActions    = this.svc.getBulkActions();
    this.savedFilters   = this.svc.getSavedFilters();
    this.queueTypeTabs  = this.svc.getQueueTypeTabs();
    this.quickFilters   = this.svc.getQuickFilters(this.filter.queueType ?? QueueType.ALL);
    this.load();
    // Refresh every 30 s for live updates
    this.refreshTimer = setInterval(() => this.load(true), 30_000);
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    if (this.toastTimer)   clearTimeout(this.toastTimer);
    this.loadSub?.unsubscribe();
  }

  // ── Data ──────────────────────────────────────────────────────────────────

  load(silent = false): void {
    if (!silent) this.isLoading = true;
    this.loadSub?.unsubscribe();
    this.loadSub = this.txnApi.getTransactions(this.filter, this.sort, this.currentPage, this.pageSize)
      .subscribe(page => {
        this.page = page;
        this.isLoading = false;
        this.lastUpdated = new Date();
      });
  }

  exportCsv(): void {
    const rows = this.page.items.map(i => ({
      Reference: i.reference,
      Type: i.type,
      Payment_SubType: i.paymentSubType ?? '',
      Rail: i.rail,
      Status: i.status,
      Priority: i.priority,
      Originator: i.originatorName,
      Beneficiary: i.beneficiaryName,
      Amount: i.amount,
      Currency: i.currency,
      Submitted_At: i.submittedAt.toISOString(),
      SLA_Status: i.slaStatus,
    }));
    this.exportSvc.toCsv(rows, `queue-${new Date().toISOString().slice(0,10)}`);
    this.toastSvc.success('Export complete', `${rows.length} items exported`);
  }

  // ── Queue-type tabs ───────────────────────────────────────────────────────

  onQueueTypeChange(tab: QueueTypeTab): void {
    this.filter = { ...this.filter, queueType: tab.type };
    this.currentPage = 1;
    this.activeQuickFilterId = 'all';
    this.load();
  }

  // ── Quick filters ─────────────────────────────────────────────────────────

  onQuickFilterSelected(qf: QuickFilter): void {
    this.activeQuickFilterId = qf.id;
    this.filter = {
      ...DEFAULT_FILTER,
      queueType: this.filter.queueType,
      ...qf.filter,
    };
    this.currentPage = 1;
    this.load();
  }

  // ── Filter panel ──────────────────────────────────────────────────────────

  onFilterChange(f: QueueFilter): void {
    this.filter = f;
    this.currentPage = 1;
    this.activeQuickFilterId = 'all';
    this.load();
  }

  onFilterReset(): void {
    this.filter = { ...DEFAULT_FILTER, queueType: this.filter.queueType };
    this.currentPage = 1;
    this.activeQuickFilterId = 'all';
    this.load();
  }

  onFilterSave(name: string): void {
    this.svc.saveFilter(name, this.filter);
    this.savedFilters = this.svc.getSavedFilters();
  }

  toggleFilterPanel(): void { this.filterPanelOpen = !this.filterPanelOpen; }

  // ── Table events ──────────────────────────────────────────────────────────

  onSortChange(s: QueueSort): void { this.sort = s; this.currentPage = 1; this.load(); }
  onPageChange(p: number): void { this.currentPage = p; this.load(); }
  onPageSizeChange(ps: number): void { this.pageSize = ps; this.currentPage = 1; this.load(); }
  onSelectionChange(ids: string[]): void { this.selectedIds = ids; }

  onRowClick(item: QueueItem): void {
    this.detailLoading = true;
    this.selectedDetail = null;
    this.txnApi.getTransaction360(item.id).subscribe(dto => {
      if (dto) {
        this.selectedDetail = { ...item, ...this.svc.buildDetailFromApi(item, dto) } as any;
      } else {
        // 360 not available — show basic item data as detail
        this.selectedDetail = item as any;
      }
      this.detailLoading = false;
    });
  }

  closeDetail(): void {
    this.selectedDetail = null;
    this.detailLoading = false;
  }

  onDetailAction(evt: DetailActionEvent): void {
    if (evt.action === 'refund') {
      const item = this.page.items.find(i => i.id === evt.itemId)
        ?? (this.selectedDetail?.id === evt.itemId ? this.selectedDetail as QueueItem : null);
      if (item) {
        this.refundModalItem = item;
        return;
      }
    }
    // In production: call API, then reload the item
    this.closeDetail();
    this.load(true);
  }

  onRefundSubmitted(result: RefundModalResult): void {
    this.refundModalItem = null;
    this.toastSvc.success(
      'Refund Request Submitted',
      `${result.request.reference} · Pending approval at ${result.request.approvalStatus ?? 'L1'}`
    );
    this.closeDetail();
    this.load(true);
  }

  onRefundCancelled(): void {
    this.refundModalItem = null;
  }

  onRowAction(evt: QueueTableActionEvent): void {
    console.log('row action', evt.action, evt.item.reference);
  }

  // ── Bulk actions ──────────────────────────────────────────────────────────

  onBulkAction(req: BulkActionRequest): void {
    this.isLoading = true;
    setTimeout(() => {
      this.lastActionResult = this.svc.executeBulkAction(req);
      this.selectedIds = [];

      if (req.actionId === 'refund' && this.lastActionResult.bulkRefundCampaignId) {
        this.lastBulkRefundCampaign = this.refundSvc.getCampaign(
          this.lastActionResult.bulkRefundCampaignId
        ) ?? null;
      } else {
        this.lastBulkRefundCampaign = null;
      }

      this.load(true);
      this.showToast();
    }, 300);
  }

  onSelectAll(): void {
    this.selectedIds = this.page.items.map(i => i.id);
  }

  onClearSelection(): void { this.selectedIds = []; }

  private showToast(): void {
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => { this.lastActionResult = null; }, 4000);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  get activeQueueTab(): QueueTypeTab | undefined {
    return this.queueTypeTabs.find(t => t.type === this.filter.queueType);
  }

  get campaignSubmittedCount(): number {
    return (this.lastBulkRefundCampaign?.items ?? [])
      .filter(i => i.status !== 'CANCELLED').length;
  }

  get campaignIneligibleCount(): number {
    return (this.lastBulkRefundCampaign?.items ?? [])
      .filter(i => i.status === 'CANCELLED').length;
  }
}
