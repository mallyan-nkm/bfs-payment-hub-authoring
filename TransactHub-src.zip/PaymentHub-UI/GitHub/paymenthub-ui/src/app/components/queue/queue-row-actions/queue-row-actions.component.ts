import { Component, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QueueItem } from '../../../shared/types';

export type RowActionId = 'view' | 'assign' | 'comment' | 'urgent' | 'escalate' | 'tag' | 'hold';

export interface RowActionEvent {
  action: RowActionId;
  item: QueueItem;
}

@Component({
  selector: 'app-queue-row-actions',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './queue-row-actions.component.html',
  styleUrls: ['./queue-row-actions.component.scss']
})
export class QueueRowActionsComponent {
  @Input({ required: true }) item!: QueueItem;
  @Output() actionTriggered = new EventEmitter<RowActionEvent>();

  open = false;

  readonly actions: { id: RowActionId; label: string; icon: string; danger?: boolean }[] = [
    { id: 'view',     label: 'View Detail',  icon: '→' },
    { id: 'assign',   label: 'Assign',       icon: '👤' },
    { id: 'comment',  label: 'Add Comment',  icon: '💬' },
    { id: 'urgent',   label: 'Mark Urgent',  icon: '⚡' },
    { id: 'escalate', label: 'Escalate',     icon: '↑' },
    { id: 'tag',      label: 'Tag',          icon: '🏷' },
    { id: 'hold',     label: 'Hold',         icon: '⏸', danger: true },
  ];

  toggle(e: Event): void {
    e.stopPropagation();
    this.open = !this.open;
  }

  trigger(id: RowActionId, e: Event): void {
    e.stopPropagation();
    this.open = false;
    this.actionTriggered.emit({ action: id, item: this.item });
  }

  @HostListener('document:click')
  closeMenu(): void {
    this.open = false;
  }
}
