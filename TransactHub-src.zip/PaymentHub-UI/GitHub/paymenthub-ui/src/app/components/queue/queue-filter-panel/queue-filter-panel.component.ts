import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  QueueFilter, Rail, QueueItemStatus, QueueItemType, QueuePriority, SlaStatus, SavedFilterSet, PaymentType
} from '../../../shared/types';
import { QueueService } from '../../../shared/services/queue.service';

@Component({
  selector: 'app-queue-filter-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './queue-filter-panel.component.html',
  styleUrls: ['./queue-filter-panel.component.scss']
})
export class QueueFilterPanelComponent implements OnInit {
  @Input({ required: true }) filter!: QueueFilter;
  @Input() savedFilters: SavedFilterSet[] = [];
  @Output() filterChange = new EventEmitter<QueueFilter>();
  @Output() filterReset  = new EventEmitter<void>();
  @Output() filterSave   = new EventEmitter<string>();

  saveName = '';
  showSaveInput = false;

  readonly Rails = Object.values(Rail).filter(r => r !== Rail.ALL);
  readonly Statuses = Object.values(QueueItemStatus);
  readonly Priorities = Object.values(QueuePriority);
  readonly Types = Object.values(QueueItemType);
  readonly SlaOptions: { id: SlaStatus; label: string }[] = [
    { id: 'ok',      label: 'On Track'    },
    { id: 'warning', label: 'SLA Warning' },
    { id: 'breach',  label: 'SLA Breach'  },
  ];
  readonly Agents: string[] = [];

  readonly PaymentSubTypeOptions: { value: PaymentType; label: string }[] = [
    { value: 'cb103',       label: 'CB103'       }, { value: 'cb202',       label: 'CB202'       },
    { value: 'ufp',         label: 'UFP'         }, { value: 'uaefts-bulk', label: 'FTS Bulk'    },
    { value: 'ipi-instant', label: 'IPI Instant' }, { value: 'ipi-alias',   label: 'Aani Alias'  },
    { value: 'ipp-card',    label: 'IPP Card'    }, { value: 'wps-single',  label: 'WPS Single'  },
    { value: 'wps-batch',   label: 'WPS Batch'   }, { value: 'wps-pension', label: 'WPS Pension' },
    { value: 'mt103',       label: 'MT103'       }, { value: 'mt202',       label: 'MT202'       },
  ];

  constructor(private queueSvc: QueueService) {}

  ngOnInit(): void {
    (this.Agents as string[]).push(...this.queueSvc.getAgents());
  }

  get activeFilterCount(): number {
    let n = 0;
    if (this.filter.search?.trim()) n++;
    if (this.filter.rails?.length) n++;
    if (this.filter.statuses?.length) n++;
    if (this.filter.priorities?.length) n++;
    if (this.filter.types?.length) n++;
    if (this.filter.paymentSubTypes?.length) n++;
    if (this.filter.slaStatuses?.length) n++;
    if (this.filter.dateFrom) n++;
    if (this.filter.dateTo) n++;
    if (this.filter.amountMin !== null) n++;
    if (this.filter.amountMax !== null) n++;
    if (this.filter.urgentOnly) n++;
    if (this.filter.assignedTo?.trim()) n++;
    return n;
  }

  togglePaymentSubType(v: PaymentType): void {
    const arr = [...(this.filter.paymentSubTypes ?? [])];
    const idx = arr.indexOf(v);
    idx === -1 ? arr.push(v) : arr.splice(idx, 1);
    this.emit({ paymentSubTypes: arr });
  }

  isSubTypeActive(v: PaymentType): boolean {
    return this.filter.paymentSubTypes?.includes(v) ?? false;
  }

  toggleRail(r: Rail): void {
    const arr = [...(this.filter.rails ?? [])];
    const idx = arr.indexOf(r);
    idx === -1 ? arr.push(r) : arr.splice(idx, 1);
    this.emit({ rails: arr });
  }

  toggleStatus(s: QueueItemStatus): void {
    const arr = [...(this.filter.statuses ?? [])];
    const idx = arr.indexOf(s);
    idx === -1 ? arr.push(s) : arr.splice(idx, 1);
    this.emit({ statuses: arr });
  }

  togglePriority(p: QueuePriority): void {
    const arr = [...(this.filter.priorities ?? [])];
    const idx = arr.indexOf(p);
    idx === -1 ? arr.push(p) : arr.splice(idx, 1);
    this.emit({ priorities: arr });
  }

  toggleType(t: QueueItemType): void {
    const arr = [...(this.filter.types ?? [])];
    const idx = arr.indexOf(t);
    idx === -1 ? arr.push(t) : arr.splice(idx, 1);
    this.emit({ types: arr });
  }

  toggleSlaStatus(s: SlaStatus): void {
    const arr = [...(this.filter.slaStatuses ?? [])];
    const idx = arr.indexOf(s);
    idx === -1 ? arr.push(s) : arr.splice(idx, 1);
    this.emit({ slaStatuses: arr });
  }

  isRailActive(r: Rail): boolean { return this.filter.rails?.includes(r) ?? false; }
  isStatusActive(s: QueueItemStatus): boolean { return this.filter.statuses?.includes(s) ?? false; }
  isPriorityActive(p: QueuePriority): boolean { return this.filter.priorities?.includes(p) ?? false; }
  isTypeActive(t: QueueItemType): boolean { return this.filter.types?.includes(t) ?? false; }
  isSlaActive(s: SlaStatus): boolean { return this.filter.slaStatuses?.includes(s) ?? false; }

  onSearchChange(v: string): void { this.emit({ search: v }); }
  onLogicChange(l: 'AND' | 'OR'): void { this.emit({ logic: l }); }
  onUrgentToggle(): void { this.emit({ urgentOnly: !this.filter.urgentOnly }); }
  onAmountMinChange(v: string): void { this.emit({ amountMin: v ? +v : null }); }
  onAmountMaxChange(v: string): void { this.emit({ amountMax: v ? +v : null }); }
  onDateFromChange(v: string): void { this.emit({ dateFrom: v || null }); }
  onDateToChange(v: string): void { this.emit({ dateTo: v || null }); }
  onAssignedToChange(v: string): void { this.emit({ assignedTo: v }); }

  applySaved(sf: SavedFilterSet): void {
    this.filterChange.emit({ ...sf.filter });
  }

  onReset(): void { this.filterReset.emit(); }

  onSave(): void {
    if (this.saveName.trim()) {
      this.filterSave.emit(this.saveName.trim());
      this.saveName = '';
      this.showSaveInput = false;
    }
  }

  private emit(partial: Partial<QueueFilter>): void {
    this.filterChange.emit({ ...this.filter, ...partial });
  }
}
