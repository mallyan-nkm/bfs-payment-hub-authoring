import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  QueueItem, Rail, RefundReasonCode, REFUND_REASON_LABELS,
  RefundEligibility, RefundRequest, ApprovalTier,
} from '../../../shared/types';
import { RefundService } from '../../../shared/services/refund.service';

export interface RefundModalResult {
  request: RefundRequest;
  item: QueueItem;
}

@Component({
  selector: 'app-refund-request-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './refund-request-modal.component.html',
  styleUrls: ['./refund-request-modal.component.scss'],
})
export class RefundRequestModalComponent implements OnChanges {
  @Input() item: QueueItem | null = null;
  @Output() submitted = new EventEmitter<RefundModalResult>();
  @Output() cancelled = new EventEmitter<void>();

  readonly reasonCodes = Object.values(RefundReasonCode);
  readonly reasonLabels = REFUND_REASON_LABELS;

  selectedReasonCode: RefundReasonCode = RefundReasonCode.CUST;
  narrative = '';
  requestedAmount = 0;
  isPartialRefund = false;

  eligibility: RefundEligibility | null = null;
  isSubmitting = false;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['item'] && this.item) {
      this.requestedAmount = this.item.amount;
      this.isPartialRefund = false;
      this.narrative = '';
      this.selectedReasonCode = RefundReasonCode.CUST;
      this.eligibility = this.refundSvc.checkEligibility(this.item);
    }
  }

  constructor(private refundSvc: RefundService) {}

  get isNarrativeRequired(): boolean {
    return this.selectedReasonCode === RefundReasonCode.NARR;
  }

  get canSubmit(): boolean {
    if (!this.eligibility?.isEligible) return false;
    if (this.isNarrativeRequired && !this.narrative.trim()) return false;
    if (this.requestedAmount <= 0 || this.requestedAmount > (this.item?.amount ?? 0)) return false;
    return true;
  }

  get approvalTiers(): ApprovalTier[] {
    if (!this.eligibility) return [];
    return this.refundSvc.checkEligibility(this.item!, this.requestedAmount).approvalTiersRequired;
  }

  get isFraudReason(): boolean {
    return this.selectedReasonCode === RefundReasonCode.FRAD;
  }

  get isIpiItem(): boolean {
    return this.item?.rail === Rail.IPI;
  }

  get effectiveRailLabel(): string {
    if (!this.eligibility?.routedVia) return '';
    return this.refundSvc.railLabel(this.eligibility.routedVia);
  }

  onReasonChange(): void {
    if (this.item) {
      this.eligibility = this.refundSvc.checkEligibility(this.item, this.requestedAmount);
    }
  }

  onAmountChange(): void {
    if (this.item) {
      this.eligibility = this.refundSvc.checkEligibility(this.item, this.requestedAmount);
    }
  }

  onPartialToggle(): void {
    if (!this.isPartialRefund && this.item) {
      this.requestedAmount = this.item.amount;
    }
    this.onAmountChange();
  }

  submit(): void {
    if (!this.item || !this.canSubmit) return;
    this.isSubmitting = true;
    const request = this.refundSvc.submitRefundRequest(
      this.item,
      this.selectedReasonCode,
      this.narrative,
      this.requestedAmount,
    );
    this.isSubmitting = false;
    this.submitted.emit({ request, item: this.item });
  }

  formatAmount(amount: number, currency: string): string {
    return new Intl.NumberFormat('en-AE', { style: 'currency', currency, maximumFractionDigits: 2 }).format(amount);
  }

  windowExpiryClass(): string {
    if (!this.eligibility?.windowExpiry) return '';
    const hoursLeft = (this.eligibility.windowExpiry.getTime() - Date.now()) / 3_600_000;
    if (hoursLeft < 24) return 'rrm__window--critical';
    if (hoursLeft < 72) return 'rrm__window--warning';
    return 'rrm__window--ok';
  }
}
