import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  TransactionDetail, QueueItemStatus, QueuePriority, Rail,
  ComplianceSeverity, RoutingHop, AuditEvent, TransactionComment, DetailActionEvent,
  BatchLineItem, BatchSummary, RefundEligibility,
} from '../../../shared/types';
import { QueueService } from '../../../shared/services/queue.service';
import { RefundService } from '../../../shared/services/refund.service';
import { CountUpDirective } from '../../../shared/directives/count-up.directive';
import { CopyClipboardDirective } from '../../../shared/directives/copy-clipboard.directive';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';

export type DetailTab = 'overview' | 'audit' | 'comments' | 'batch';

interface ContextualAction {
  id: DetailActionEvent['action'];
  label: string;
  variant: 'primary' | 'success' | 'danger' | 'warning' | 'secondary';
  requiresReason: boolean;
  requiresConfirm: boolean;
}

@Component({
  selector: 'app-transaction-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, CountUpDirective, CopyClipboardDirective, EmptyStateComponent],
  templateUrl: './transaction-detail.component.html',
  styleUrls: ['./transaction-detail.component.scss']
})
export class TransactionDetailComponent implements OnChanges {
  @Input() detail: TransactionDetail | null = null;
  @Input() isLoading = false;
  @Output() closePanel  = new EventEmitter<void>();
  @Output() detailAction = new EventEmitter<DetailActionEvent>();

  activeTab: DetailTab = 'overview';
  newComment = '';
  pendingAction: ContextualAction | null = null;
  actionReason = '';
  batchSearchTerm = '';

  constructor(
    private queueSvc: QueueService,
    private refundSvc: RefundService,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['detail'] && this.detail) {
      this.activeTab = 'overview';
      this.pendingAction = null;
      this.actionReason = '';
      this.batchSearchTerm = '';
    }
  }

  // ── Rail / batch computed properties ──────────────────────────────────────

  get isBatchPayment(): boolean {
    const pst = this.detail?.paymentSubType;
    return pst === 'wps-batch' || pst === 'wps-pension' || pst === 'uaefts-bulk';
  }

  get isIpiRail(): boolean  { return this.detail?.rail === Rail.IPI; }
  get isWpsRail(): boolean  { return this.detail?.rail === Rail.WPS; }
  get isUaeftsRail(): boolean { return this.detail?.rail === Rail.UAEFTS; }

  get batchSummary(): BatchSummary | null {
    const items = this.detail?.batchLineItems;
    return items?.length ? this.queueSvc.getBatchSummary(items) : null;
  }

  get filteredBatchItems(): BatchLineItem[] {
    const items = this.detail?.batchLineItems ?? [];
    const q = this.batchSearchTerm.trim().toLowerCase();
    if (!q) return items;
    return items.filter(i =>
      i.employeeName.toLowerCase().includes(q) ||
      i.emiratesId.includes(q) ||
      i.iban.toLowerCase().includes(q)
    );
  }

  batchStatusClass(status: BatchLineItem['status']): string {
    return `batch-status--${status}`;
  }

  // ── Contextual actions ─────────────────────────────────────────────────────

  get availableActions(): ContextualAction[] {
    if (!this.detail) return [];
    const s = this.detail.status;
    const all: Partial<Record<QueueItemStatus, ContextualAction[]>> = {
      [QueueItemStatus.PENDING]: [
        { id: 'approve',  label: 'Approve',  variant: 'success',  requiresReason: false, requiresConfirm: false },
        { id: 'hold',     label: 'Hold',     variant: 'warning',  requiresReason: true,  requiresConfirm: false },
        { id: 'escalate', label: 'Escalate', variant: 'secondary',requiresReason: true,  requiresConfirm: false },
        { id: 'reject',   label: 'Reject',   variant: 'danger',   requiresReason: true,  requiresConfirm: true  },
      ],
      [QueueItemStatus.IN_REVIEW]: [
        { id: 'approve',  label: 'Approve',  variant: 'success',  requiresReason: false, requiresConfirm: false },
        { id: 'hold',     label: 'Hold',     variant: 'warning',  requiresReason: true,  requiresConfirm: false },
        { id: 'escalate', label: 'Escalate', variant: 'secondary',requiresReason: true,  requiresConfirm: false },
        { id: 'reject',   label: 'Reject',   variant: 'danger',   requiresReason: true,  requiresConfirm: true  },
      ],
      [QueueItemStatus.HELD]: [
        { id: 'release',  label: 'Release',  variant: 'primary',  requiresReason: false, requiresConfirm: false },
        { id: 'escalate', label: 'Escalate', variant: 'secondary',requiresReason: true,  requiresConfirm: false },
        { id: 'reject',   label: 'Reject',   variant: 'danger',   requiresReason: true,  requiresConfirm: true  },
      ],
      [QueueItemStatus.ESCALATED]: [
        { id: 'approve',  label: 'Approve',  variant: 'success',  requiresReason: false, requiresConfirm: false },
        { id: 'resolve',  label: 'Resolve',  variant: 'primary',  requiresReason: true,  requiresConfirm: false },
        { id: 'reject',   label: 'Reject',   variant: 'danger',   requiresReason: true,  requiresConfirm: true  },
      ],
    };
    return all[s] ?? [];
  }

  get isTerminal(): boolean {
    return this.detail?.status === QueueItemStatus.APPROVED
      || this.detail?.status === QueueItemStatus.REJECTED
      || this.detail?.status === QueueItemStatus.RESOLVED;
  }

  get isRefundRequest(): boolean {
    return this.detail?.status === QueueItemStatus.REFUND_REQUESTED
      || this.detail?.status === QueueItemStatus.REFUND_PENDING_RESPONSE
      || this.detail?.status === QueueItemStatus.REFUND_ACCEPTED
      || this.detail?.status === QueueItemStatus.REFUND_DECLINED
      || this.detail?.status === QueueItemStatus.REFUND_PARTIAL;
  }

  get refundEligibility(): RefundEligibility | null {
    if (!this.detail) return null;
    return this.refundSvc.checkEligibility(this.detail);
  }

  get canInitiateRefund(): boolean {
    if (!this.detail) return false;
    const refundableStatuses: QueueItemStatus[] = [QueueItemStatus.APPROVED, QueueItemStatus.RESOLVED];
    return refundableStatuses.includes(this.detail.status) && (this.refundEligibility?.isEligible ?? false);
  }

  onAction(action: ContextualAction): void {
    if (action.requiresReason || action.requiresConfirm) {
      this.pendingAction = action;
    } else {
      this.emit(action.id);
    }
  }

  confirmAction(): void {
    if (!this.pendingAction) return;
    this.emit(this.pendingAction.id, this.actionReason);
    this.pendingAction = null;
    this.actionReason = '';
  }

  cancelAction(): void { this.pendingAction = null; this.actionReason = ''; }

  emit(action: DetailActionEvent['action'], reason?: string): void {
    if (!this.detail) return;
    this.detailAction.emit({ action, itemId: this.detail.id, reason: reason || undefined });
  }

  // ── Comments ───────────────────────────────────────────────────────────────

  submitComment(): void {
    const body = this.newComment.trim();
    if (!body || !this.detail) return;
    this.detailAction.emit({ action: 'comment', itemId: this.detail.id, comment: body });
    // Optimistically add to local list
    this.detail.comments = [
      ...this.detail.comments,
      { id: `cmt-new-${Date.now()}`, timestamp: new Date(), author: 'You', body, isSystem: false }
    ];
    this.newComment = '';
  }

  // ── Rendering helpers ──────────────────────────────────────────────────────

  statusClass(status: QueueItemStatus): string {
    const m: Record<QueueItemStatus, string> = {
      [QueueItemStatus.PENDING]:                  'badge--pending',
      [QueueItemStatus.IN_REVIEW]:                'badge--review',
      [QueueItemStatus.HELD]:                     'badge--held',
      [QueueItemStatus.ESCALATED]:                'badge--escalated',
      [QueueItemStatus.APPROVED]:                 'badge--approved',
      [QueueItemStatus.REJECTED]:                 'badge--rejected',
      [QueueItemStatus.RESOLVED]:                 'badge--resolved',
      [QueueItemStatus.REFUND_REQUESTED]:         'badge--refund-requested',
      [QueueItemStatus.REFUND_PENDING_RESPONSE]:  'badge--refund-pending',
      [QueueItemStatus.REFUND_ACCEPTED]:          'badge--refund-accepted',
      [QueueItemStatus.REFUND_DECLINED]:          'badge--refund-declined',
      [QueueItemStatus.REFUND_PARTIAL]:           'badge--refund-partial',
    };
    return m[status] ?? '';
  }

  priorityClass(p: QueuePriority): string {
    return `pri--${p.toLowerCase()}`;
  }

  railClass(rail: Rail): string { return `rail--${rail.toLowerCase()}`; }

  severityClass(sev: ComplianceSeverity): string { return `sev--${sev}`; }

  hopClass(hop: RoutingHop): string { return `hop--${hop.status}`; }

  formatAmount(amount: number, currency: string): string {
    const cur = currency?.trim() || 'AED';
    try {
      return new Intl.NumberFormat('en-AE', { style: 'currency', currency: cur, maximumFractionDigits: 2 }).format(amount ?? 0);
    } catch {
      return `${(amount ?? 0).toLocaleString()} ${cur}`;
    }
  }

  formatTs(d: Date): string {
    return new Intl.DateTimeFormat('en-AE', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(d);
  }

  formatShortTs(d: Date): string {
    return new Intl.DateTimeFormat('en-AE', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(d);
  }

  slaClass(detail: TransactionDetail): string { return `sla--${detail.slaStatus}`; }

  fraudColor(score: number): string {
    if (score >= 70) return 'var(--danger, #ef4444)';
    if (score >= 40) return 'var(--warning, #f59e0b)';
    return 'var(--success, #22c55e)';
  }

  fraudLabel(score: number): string {
    if (score >= 70) return 'High Risk';
    if (score >= 40) return 'Medium';
    return 'Low Risk';
  }

  actorIcon(type: AuditEvent['actorType']): string {
    return type === 'user' ? '◎' : type === 'automated' ? '⬡' : '◈';
  }

  commentInitials(author: string): string {
    return author.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  }
}
