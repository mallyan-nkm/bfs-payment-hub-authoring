import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuickFilter } from '../../../shared/types';

@Component({
  selector: 'app-quick-filter-bar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './quick-filter-bar.component.html',
  styleUrls: ['./quick-filter-bar.component.scss']
})
export class QuickFilterBarComponent {
  @Input() filters: QuickFilter[] = [];
  @Input() activeFilterId: string = 'all';
  @Output() filterSelected = new EventEmitter<QuickFilter>();

  select(f: QuickFilter): void {
    this.activeFilterId = f.id;
    this.filterSelected.emit(f);
  }
}
