import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { QueueItem, QueueSort, QueueItemStatus, QueuePriority, Rail, QueueItemType, PaymentType } from '../../../shared/types';
import { QueueService } from '../../../shared/services/queue.service';
import { CopyClipboardDirective } from '../../../shared/directives/copy-clipboard.directive';
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';

export interface ColumnDef {
  key: keyof QueueItem;
  label: string;
  sortable: boolean;
  width?: string;
  sticky?: boolean;
}

export type QueueTableAction = 'view' | 'assign' | 'comment' | 'urgent' | 'escalate' | 'hold';

export interface QueueTableActionEvent { action: QueueTableAction; item: QueueItem; }

@Component({
  selector: 'app-queue-table',
  standalone: true,
  imports: [CommonModule, FormsModule, CopyClipboardDirective, EmptyStateComponent],
  templateUrl: './queue-table.component.html',
  styleUrls: ['./queue-table.component.scss']
})
export class QueueTableComponent implements OnChanges {
  @Input({ required: true }) items: QueueItem[] = [];
  @Input() totalCount = 0;
  @Input() filteredCount = 0;
  @Input() currentPage = 1;
  @Input() pageSize = 25;
  @Input() sort: QueueSort = { column: 'submittedAt', direction: 'desc' };
  @Input() isLoading = false;

  @Output() sortChange    = new EventEmitter<QueueSort>();
  @Output() pageChange    = new EventEmitter<number>();
  @Output() pageSizeChange = new EventEmitter<number>();
  @Output() selectionChange = new EventEmitter<string[]>();
  @Output() rowAction     = new EventEmitter<QueueTableActionEvent>();
  @Output() rowClick      = new EventEmitter<QueueItem>();

  selectedIds = new Set<string>();
  hoveredRowId: string | null = null;
  openMenuId: string | null = null;

  readonly pageSizeOptions = [10, 25, 50, 100];

  readonly columns: ColumnDef[] = [
    { key: 'id',             label: 'Txn ID',       sortable: true,  width: '160px' },
    { key: 'type',           label: 'Type',         sortable: true,  width: '110px' },
    { key: 'status',         label: 'Status',       sortable: true,  width: '110px' },
    { key: 'priority',       label: 'Priority',     sortable: true,  width: '90px'  },
    { key: 'rail',           label: 'Rail',         sortable: true,  width: '80px'  },
    { key: 'originatorName', label: 'From',         sortable: true,  width: '160px' },
    { key: 'beneficiaryName',label: 'To',           sortable: true,  width: '160px' },
    { key: 'amount',         label: 'Amount',       sortable: true,  width: '130px' },
    { key: 'submittedAt',    label: 'Submitted',    sortable: true,  width: '110px' },
    { key: 'slaStatus',      label: 'SLA',          sortable: true,  width: '110px' },
    { key: 'assignedTo',     label: 'Assigned',     sortable: true,  width: '130px' },
  ];

  readonly quickActions: { id: QueueTableAction; label: string }[] = [
    { id: 'view',     label: 'View'     },
    { id: 'assign',   label: 'Assign'   },
    { id: 'comment',  label: 'Comment'  },
    { id: 'urgent',   label: 'Urgent'   },
    { id: 'escalate', label: 'Escalate' },
    { id: 'hold',     label: 'Hold'     },
  ];

  constructor(private svc: QueueService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['items']) {
      // Remove deselected items that are no longer in the page
      const ids = new Set(this.items.map(i => i.id));
      this.selectedIds.forEach(id => { if (!ids.has(id)) this.selectedIds.delete(id); });
    }
  }

  // ─── Selection ────────────────────────────────────────────────────────────

  get allPageSelected(): boolean {
    return this.items.length > 0 && this.items.every(i => this.selectedIds.has(i.id));
  }

  get somePageSelected(): boolean {
    return this.items.some(i => this.selectedIds.has(i.id)) && !this.allPageSelected;
  }

  toggleAll(): void {
    if (this.allPageSelected) {
      this.items.forEach(i => this.selectedIds.delete(i.id));
    } else {
      this.items.forEach(i => this.selectedIds.add(i.id));
    }
    this.emitSelection();
  }

  toggleRow(id: string, event: Event): void {
    event.stopPropagation();
    this.selectedIds.has(id) ? this.selectedIds.delete(id) : this.selectedIds.add(id);
    this.emitSelection();
  }

  private emitSelection(): void {
    this.selectionChange.emit([...this.selectedIds]);
  }

  // ─── Sort ─────────────────────────────────────────────────────────────────

  onSort(col: ColumnDef): void {
    if (!col.sortable) return;
    const direction = this.sort.column === col.key && this.sort.direction === 'asc' ? 'desc' : 'asc';
    this.sortChange.emit({ column: col.key, direction });
  }

  sortIndicator(col: ColumnDef): string {
    if (this.sort.column !== col.key) return '';
    return this.sort.direction === 'asc' ? '↑' : '↓';
  }

  // ─── Pagination ───────────────────────────────────────────────────────────

  get totalPages(): number { return Math.ceil(this.filteredCount / this.pageSize); }

  get pageNumbers(): number[] {
    const total = this.totalPages;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    const pages: number[] = [1];
    if (this.currentPage > 3) pages.push(-1);
    for (let p = Math.max(2, this.currentPage - 1); p <= Math.min(total - 1, this.currentPage + 1); p++) pages.push(p);
    if (this.currentPage < total - 2) pages.push(-1);
    pages.push(total);
    return pages;
  }

  goToPage(p: number): void { if (p > 0 && p <= this.totalPages) this.pageChange.emit(p); }
  onPageSizeChange(v: string): void { this.pageSizeChange.emit(+v); }

  // ─── Row Actions ──────────────────────────────────────────────────────────

  onRowClick(item: QueueItem): void { this.rowClick.emit(item); }

  onQuickAction(action: QueueTableAction, item: QueueItem, event: Event): void {
    event.stopPropagation();
    this.openMenuId = null;
    this.rowAction.emit({ action, item });
  }

  toggleMenu(id: string, event: Event): void {
    event.stopPropagation();
    this.openMenuId = this.openMenuId === id ? null : id;
  }

  closeMenu(): void { this.openMenuId = null; }

  // ─── Cell rendering helpers ───────────────────────────────────────────────

  statusClass(status: QueueItemStatus): string {
    const m: Record<QueueItemStatus, string> = {
      [QueueItemStatus.PENDING]:                  'status--pending',
      [QueueItemStatus.IN_REVIEW]:                'status--review',
      [QueueItemStatus.HELD]:                     'status--held',
      [QueueItemStatus.ESCALATED]:                'status--escalated',
      [QueueItemStatus.APPROVED]:                 'status--approved',
      [QueueItemStatus.REJECTED]:                 'status--rejected',
      [QueueItemStatus.RESOLVED]:                 'status--resolved',
      [QueueItemStatus.REFUND_REQUESTED]:         'status--refund-req',
      [QueueItemStatus.REFUND_PENDING_RESPONSE]:  'status--refund-pending',
      [QueueItemStatus.REFUND_ACCEPTED]:          'status--refund-ok',
      [QueueItemStatus.REFUND_DECLINED]:          'status--refund-no',
      [QueueItemStatus.REFUND_PARTIAL]:           'status--refund-partial',
    };
    return m[status] ?? '';
  }

  priorityClass(priority: QueuePriority): string {
    const m: Record<QueuePriority, string> = {
      [QueuePriority.CRITICAL]: 'pri--critical',
      [QueuePriority.HIGH]:     'pri--high',
      [QueuePriority.NORMAL]:   'pri--normal',
      [QueuePriority.LOW]:      'pri--low',
    };
    return m[priority] ?? '';
  }

  railClass(rail: Rail): string { return `rail--${rail.toLowerCase()}`; }

  slaClass(item: QueueItem): string {
    return `sla--${item.slaStatus}`;
  }

  typeLabel(type: QueueItemType): string {
    const m: Record<QueueItemType, string> = {
      [QueueItemType.PAYMENT]:        'Pymt',
      [QueueItemType.RECALL]:         'Recall',
      [QueueItemType.RETURN]:         'Return',
      [QueueItemType.EXCEPTION]:      'Exc',
      [QueueItemType.APPROVAL]:       'Appr',
      [QueueItemType.ENQUIRY]:        'Enq',
      [QueueItemType.REFUND_REQUEST]: 'Refund',
    };
    return m[type] ?? type;
  }

  paymentSubTypeLabel(subType: PaymentType | undefined): string {
    if (!subType) return '';
    const labels: Record<PaymentType, string> = {
      'cb103':       'CB103',       'cb202':       'CB202',
      'ufp':         'UFP',         'uaefts-bulk': 'FTS Bulk',
      'ipi-instant': 'IPI Instant', 'ipi-alias':   'Aani Alias',
      'ipp-card':    'IPP Card',    'wps-single':  'WPS Single',
      'wps-batch':   'WPS Batch',   'wps-pension': 'WPS Pension',
      'mt103':       'MT103',       'mt202':       'MT202',
    };
    return labels[subType] ?? subType;
  }

  isBatchSubType(subType: PaymentType | undefined): boolean {
    return subType === 'wps-batch' || subType === 'wps-pension' || subType === 'uaefts-bulk';
  }

  formatAmount(amount: number, currency: string): string {
    return this.svc.formatAmount(amount, currency);
  }

  formatSla(item: QueueItem): string {
    return this.svc.formatSlaRemaining(item.slaMinutesRemaining);
  }

  get rangeStart(): number { return (this.currentPage - 1) * this.pageSize + 1; }
  get rangeEnd(): number { return Math.min(this.currentPage * this.pageSize, this.filteredCount); }

  trackById(_: number, item: QueueItem): string { return item.id; }
}
