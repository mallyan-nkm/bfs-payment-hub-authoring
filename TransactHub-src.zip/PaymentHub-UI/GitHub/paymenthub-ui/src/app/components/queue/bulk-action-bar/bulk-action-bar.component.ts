import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BulkAction, BulkActionRequest } from '../../../shared/types';

@Component({
  selector: 'app-bulk-action-bar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bulk-action-bar.component.html',
  styleUrls: ['./bulk-action-bar.component.scss']
})
export class BulkActionBarComponent {
  @Input() selectedIds: string[] = [];
  @Input() totalCount: number = 0;
  @Input() actions: BulkAction[] = [];
  @Output() actionExecute = new EventEmitter<BulkActionRequest>();
  @Output() clearSelection = new EventEmitter<void>();
  @Output() selectAll = new EventEmitter<void>();

  pendingAction: BulkAction | null = null;
  reason: string = '';
  showConfirm = false;

  get selectedCount(): number {
    return this.selectedIds.length;
  }

  /** True when some but not all items are selected. */
  get isPartialSelection(): boolean {
    return this.selectedCount > 0 && this.selectedCount < this.totalCount;
  }

  onAction(action: BulkAction): void {
    if (action.requiresConfirmation || action.requiresReason) {
      this.pendingAction = action;
      this.showConfirm = true;
    } else {
      this.actionExecute.emit({ actionId: action.id, itemIds: this.selectedIds });
    }
  }

  confirmAction(): void {
    if (!this.pendingAction) return;
    this.actionExecute.emit({
      actionId: this.pendingAction.id,
      itemIds: this.selectedIds,
      reason: this.reason || undefined
    });
    this.showConfirm = false;
    this.pendingAction = null;
    this.reason = '';
  }

  cancelConfirm(): void {
    this.showConfirm = false;
    this.pendingAction = null;
    this.reason = '';
  }
}
