import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { ClaudeChatService, ChatMessage } from "../services/claude-chat.service";

@Component({
  selector: "app-claude-chat",
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: "./claude-chat.component.html",
  styleUrls: ["./claude-chat.component.scss"],
})
export class ClaudeChatComponent implements OnInit {
  @ViewChild("chatContainer") chatContainer: ElementRef | null = null;

  messages: ChatMessage[] = [];
  userInput: string = "";
  isLoading: boolean = false;
  error: string | null = null;

  constructor(private claudeService: ClaudeChatService) {}

  ngOnInit(): void {
    // Initialize chat - optionally load history
  }

  async sendMessage(): Promise<void> {
    if (!this.userInput.trim()) {
      return;
    }

    const message = this.userInput.trim();
    this.userInput = "";
    this.isLoading = true;
    this.error = null;

    try {
      // Display user message immediately
      this.messages.push({
        role: "user",
        content: message,
      });

      // Get Claude's response
      const response = await this.claudeService.sendMessage(message);

      this.messages.push({
        role: "assistant",
        content: response,
      });

      this.scrollToBottom();
    } catch (err) {
      this.error =
        err instanceof Error ? err.message : "Failed to get response";
      console.error("Chat error:", err);
    } finally {
      this.isLoading = false;
    }
  }

  clearChat(): void {
    this.messages = [];
    this.claudeService.clearHistory();
    this.error = null;
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      if (this.chatContainer) {
        this.chatContainer.nativeElement.scrollTop =
          this.chatContainer.nativeElement.scrollHeight;
      }
    }, 0);
  }
}
