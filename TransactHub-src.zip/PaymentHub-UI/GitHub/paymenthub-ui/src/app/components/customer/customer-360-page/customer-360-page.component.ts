import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

interface CustomerProfile {
  customerId: string;
  cif: string;
  fullName: string;
  segment: string;
  riskRating: string;
  kycStatus: string;
  branch: string;
  email: string;
  phone: string;
  nationalId: string;
  createdAt: string;
  lastActivity: string;
}

interface CustomerTransaction {
  id: string;
  reference: string;
  type: string;
  rail: string;
  amount: number;
  currency: string;
  status: string;
  counterparty: string;
  date: string;
}

interface ComplianceCase {
  id: string;
  type: string;
  status: string;
  severity: string;
  createdAt: string;
  description: string;
}

type Tab = 'profile' | 'transactions' | 'compliance' | 'disputes' | 'beneficiaries';

@Component({
  selector: 'app-customer-360-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="customer-360">
      <div class="page-header">
        <a routerLink="/customers" class="back-link">← Back to Search</a>
        <h1>Customer 360°</h1>
      </div>

      @if (loading()) {
        <div class="loading-state">Loading customer data...</div>
      } @else if (customer()) {
        <div class="profile-card">
          <div class="profile-avatar">{{ customer()!.fullName.charAt(0) }}</div>
          <div class="profile-info">
            <h2>{{ customer()!.fullName }}</h2>
            <div class="profile-meta">
              <span class="badge badge--segment">{{ customer()!.segment }}</span>
              <span class="badge badge--risk" [class]="'badge--risk-' + customer()!.riskRating.toLowerCase()">{{ customer()!.riskRating }}</span>
              <span class="badge badge--kyc" [class]="'badge--kyc-' + customer()!.kycStatus.toLowerCase()">KYC: {{ customer()!.kycStatus }}</span>
            </div>
            <div class="profile-details">
              <span>CIF: {{ customer()!.cif }}</span>
              <span>Branch: {{ customer()!.branch }}</span>
              <span>Last Activity: {{ customer()!.lastActivity }}</span>
            </div>
          </div>
        </div>

        <div class="tab-bar">
          @for (tab of tabs; track tab.id) {
            <button class="tab-btn" [class.active]="activeTab() === tab.id" (click)="activeTab.set(tab.id)">
              {{ tab.label }}
              @if (tab.count) { <span class="tab-count">{{ tab.count }}</span> }
            </button>
          }
        </div>

        <div class="tab-content">
          @switch (activeTab()) {
            @case ('profile') {
              <div class="detail-grid">
                <div class="detail-item"><label>Full Name</label><span>{{ customer()!.fullName }}</span></div>
                <div class="detail-item"><label>CIF</label><span>{{ customer()!.cif }}</span></div>
                <div class="detail-item"><label>Segment</label><span>{{ customer()!.segment }}</span></div>
                <div class="detail-item"><label>Risk Rating</label><span>{{ customer()!.riskRating }}</span></div>
                <div class="detail-item"><label>KYC Status</label><span>{{ customer()!.kycStatus }}</span></div>
                <div class="detail-item"><label>Branch</label><span>{{ customer()!.branch }}</span></div>
                <div class="detail-item"><label>Email</label><span>{{ customer()!.email }}</span></div>
                <div class="detail-item"><label>Phone</label><span>{{ customer()!.phone }}</span></div>
                <div class="detail-item"><label>National ID</label><span>{{ customer()!.nationalId }}</span></div>
                <div class="detail-item"><label>Created</label><span>{{ customer()!.createdAt }}</span></div>
              </div>
            }
            @case ('transactions') {
              <div class="table-container">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Reference</th><th>Type</th><th>Rail</th><th>Amount</th><th>Status</th><th>Counterparty</th><th>Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    @for (txn of transactions(); track txn.id) {
                      <tr>
                        <td class="mono">{{ txn.reference }}</td>
                        <td>{{ txn.type }}</td>
                        <td><span class="rail-badge">{{ txn.rail }}</span></td>
                        <td class="amount">{{ txn.currency }} {{ txn.amount | number }}</td>
                        <td><span class="status-badge status--{{ txn.status.toLowerCase() }}">{{ txn.status }}</span></td>
                        <td>{{ txn.counterparty }}</td>
                        <td>{{ txn.date }}</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            }
            @case ('compliance') {
              <div class="table-container">
                <table class="data-table">
                  <thead><tr><th>Case ID</th><th>Type</th><th>Severity</th><th>Status</th><th>Created</th><th>Description</th></tr></thead>
                  <tbody>
                    @for (c of complianceCases(); track c.id) {
                      <tr>
                        <td class="mono">{{ c.id }}</td>
                        <td>{{ c.type }}</td>
                        <td><span class="severity-badge severity--{{ c.severity.toLowerCase() }}">{{ c.severity }}</span></td>
                        <td>{{ c.status }}</td>
                        <td>{{ c.createdAt }}</td>
                        <td>{{ c.description }}</td>
                      </tr>
                    }
                    @if (complianceCases().length === 0) { <tr><td colspan="6" class="empty-row">No compliance cases</td></tr> }
                  </tbody>
                </table>
              </div>
            }
            @case ('disputes') {
              <div class="empty-state">No disputes or complaints on record</div>
            }
            @case ('beneficiaries') {
              <div class="empty-state">Beneficiary list loaded from API</div>
            }
          }
        </div>
      } @else {
        <div class="error-state">Customer not found</div>
      }
    </div>
  `,
  styles: [`
    .customer-360 { padding: 1.5rem; max-width: 1200px; }
    .page-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
    .page-header h1 { font-size: 1.25rem; color: var(--text-0); margin: 0; }
    .back-link { color: var(--accent); text-decoration: none; font-size: 0.8125rem; }
    .loading-state, .error-state, .empty-state { padding: 3rem; text-align: center; color: var(--text-2); }
    .profile-card {
      display: flex; align-items: center; gap: 1.25rem; padding: 1.25rem;
      background: var(--bg-2); border: 1px solid var(--border); border-radius: 8px; margin-bottom: 1.5rem;
    }
    .profile-avatar {
      width: 56px; height: 56px; border-radius: 50%; background: var(--accent-dim);
      display: flex; align-items: center; justify-content: center;
      font-size: 1.5rem; font-weight: 700; color: var(--accent);
    }
    .profile-info h2 { font-size: 1.125rem; color: var(--text-0); margin: 0 0 0.375rem; }
    .profile-meta { display: flex; gap: 0.5rem; margin-bottom: 0.375rem; }
    .profile-details { display: flex; gap: 1.5rem; font-size: 0.75rem; color: var(--text-2); }
    .badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 600; }
    .badge--segment { background: var(--accent-dim); color: var(--accent); }
    .badge--risk-high { background: rgba(248,113,113,0.15); color: var(--danger); }
    .badge--risk-medium { background: rgba(251,191,36,0.15); color: var(--warning); }
    .badge--risk-low { background: rgba(74,222,128,0.15); color: var(--success); }
    .badge--kyc-verified { background: rgba(74,222,128,0.15); color: var(--success); }
    .badge--kyc-pending { background: rgba(251,191,36,0.15); color: var(--warning); }
    .tab-bar { display: flex; gap: 0; border-bottom: 1px solid var(--border); margin-bottom: 1rem; }
    .tab-btn {
      padding: 0.625rem 1rem; border: none; background: none; color: var(--text-2);
      font-size: 0.8125rem; cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.15s;
    }
    .tab-btn.active { color: var(--accent); border-bottom-color: var(--accent); }
    .tab-count { margin-left: 0.375rem; padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 8px; font-size: 0.6875rem; }
    .detail-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1rem; }
    .detail-item { display: flex; flex-direction: column; gap: 0.25rem; }
    .detail-item label { font-size: 0.6875rem; color: var(--text-3); text-transform: uppercase; letter-spacing: 0.03em; }
    .detail-item span { font-size: 0.875rem; color: var(--text-0); }
    .table-container { overflow-x: auto; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 0.8125rem; }
    .data-table th { text-align: left; padding: 0.5rem 0.75rem; color: var(--text-3); font-size: 0.6875rem; text-transform: uppercase; border-bottom: 1px solid var(--border); }
    .data-table td { padding: 0.5rem 0.75rem; border-bottom: 1px solid var(--border); color: var(--text-1); }
    .mono { font-family: 'JetBrains Mono', monospace; font-size: 0.75rem; }
    .amount { font-weight: 600; }
    .rail-badge { padding: 0.0625rem 0.375rem; background: var(--bg-3); border-radius: 3px; font-size: 0.6875rem; }
    .status-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .status--completed, .status--settled { background: rgba(74,222,128,0.15); color: var(--success); }
    .status--pending, .status--processing { background: rgba(251,191,36,0.15); color: var(--warning); }
    .status--failed, .status--rejected { background: rgba(248,113,113,0.15); color: var(--danger); }
    .severity-badge { padding: 0.125rem 0.5rem; border-radius: 4px; font-size: 0.6875rem; font-weight: 500; }
    .severity--critical { background: rgba(248,113,113,0.15); color: var(--danger); }
    .severity--high { background: rgba(251,191,36,0.15); color: var(--warning); }
    .severity--medium { background: rgba(76,158,255,0.15); color: var(--accent); }
    .empty-row { text-align: center; color: var(--text-3); }
  `]
})
export class Customer360PageComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private http = inject(HttpClient);

  loading = signal(true);
  customer = signal<CustomerProfile | null>(null);
  transactions = signal<CustomerTransaction[]>([]);
  complianceCases = signal<ComplianceCase[]>([]);
  activeTab = signal<Tab>('profile');

  tabs: { id: Tab; label: string; count?: number }[] = [
    { id: 'profile', label: 'Profile & KYC' },
    { id: 'transactions', label: 'Transactions' },
    { id: 'compliance', label: 'Compliance' },
    { id: 'disputes', label: 'Disputes' },
    { id: 'beneficiaries', label: 'Beneficiaries' },
  ];

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) this.loadCustomer(id);
  }

  private loadCustomer(id: string): void {
    this.http.get<CustomerProfile>(`${environment.apiBaseUrl}/customers/${id}`).subscribe({
      next: (data) => {
        this.customer.set(data);
        this.loading.set(false);
        this.loadTransactions(id);
        this.loadCompliance(id);
      },
      error: () => { this.loading.set(false); }
    });
  }

  private loadTransactions(customerId: string): void {
    this.http.get<CustomerTransaction[]>(`${environment.apiBaseUrl}/customers/${customerId}/transactions?limit=100`).subscribe({
      next: (data) => {
        this.transactions.set(data);
        this.tabs = this.tabs.map(t => t.id === 'transactions' ? { ...t, count: data.length } : t);
      },
      error: () => {}
    });
  }

  private loadCompliance(customerId: string): void {
    this.http.get<ComplianceCase[]>(`${environment.apiBaseUrl}/customers/${customerId}/compliance-cases`).subscribe({
      next: (data) => {
        this.complianceCases.set(data);
        this.tabs = this.tabs.map(t => t.id === 'compliance' ? { ...t, count: data.length } : t);
      },
      error: () => {}
    });
  }
}
