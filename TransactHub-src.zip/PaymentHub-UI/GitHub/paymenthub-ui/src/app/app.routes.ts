import { Routes } from '@angular/router';
import { authGuard } from './shared/guards/auth.guard';
import { permissionGuard } from './shared/guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./components/dashboard/live-ops-dashboard/live-ops-dashboard.component')
            .then(m => m.LiveOpsDashboardComponent)
      },
      {
        path: 'uaefts',
        loadComponent: () =>
          import('./components/dashboard/uaefts-dashboard/uaefts-dashboard.component')
            .then(m => m.UaeftsDashboardComponent)
      },
      {
        path: 'ipi',
        loadComponent: () =>
          import('./components/dashboard/ipi-dashboard/ipi-dashboard.component')
            .then(m => m.IpiDashboardComponent)
      },
      {
        path: 'ipp',
        loadComponent: () =>
          import('./components/dashboard/ipp-dashboard/ipp-dashboard.component')
            .then(m => m.IppDashboardComponent)
      },
      {
        path: 'wps',
        loadComponent: () =>
          import('./components/dashboard/wps-dashboard/wps-dashboard.component')
            .then(m => m.WpsDashboardComponent)
      },
      {
        path: 'swift',
        loadComponent: () =>
          import('./components/dashboard/swift-dashboard/swift-dashboard.component')
            .then(m => m.SwiftDashboardComponent)
      }
    ]
  },
  {
    path: 'operations',
    children: [
      {
        path: 'queues',
        loadComponent: () =>
          import('./components/queue/payment-queues-page/payment-queues-page.component')
            .then(m => m.PaymentQueuesPageComponent)
      },
      {
        path: 'approvals',
        loadComponent: () =>
          import('./components/approvals/approval-workflow-page/approval-workflow-page.component')
            .then(m => m.ApprovalWorkflowPageComponent)
      },
      {
        path: 'transactions',
        children: [
          {
            path: 'new',
            loadComponent: () =>
              import('./components/transactions/new-transaction/new-transaction.component')
                .then(m => m.NewTransactionComponent)
          }
        ]
      },
      { path: 'levers', loadComponent: () => import('./components/operations/operational-levers-page/operational-levers-page.component').then(m => m.OperationalLeversPageComponent) },
      { path: 'workflow-replay', loadComponent: () => import('./components/operations/workflow-replay-page/workflow-replay-page.component').then(m => m.WorkflowReplayPageComponent) },
      { path: 'shift-handover', loadComponent: () => import('./components/operations/shift-handover-page/shift-handover-page.component').then(m => m.ShiftHandoverPageComponent) },
      { path: 'documents', loadComponent: () => import('./components/operations/document-management-page/document-management-page.component').then(m => m.DocumentManagementPageComponent) },
      { path: 'collaboration', loadComponent: () => import('./components/operations/collaboration-page/collaboration-page.component').then(m => m.CollaborationPageComponent) },
    ]
  },
  {
    path: 'reporting',
    loadComponent: () =>
      import('./components/reporting/reporting-page/reporting-page.component')
        .then(m => m.ReportingPageComponent)
  },
  {
    path: 'exceptions',
    loadComponent: () =>
      import('./components/exceptions/exceptions-page/exceptions-page.component')
        .then(m => m.ExceptionsPageComponent)
  },
  {
    path: 'customers/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./components/customer/customer-360-page/customer-360-page.component')
        .then(m => m.Customer360PageComponent)
  },
  {
    path: 'counterparties/:id',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./components/counterparty/counterparty-360-page/counterparty-360-page.component')
        .then(m => m.Counterparty360PageComponent)
  },
  {
    path: 'audit',
    canActivate: [authGuard, permissionGuard('audit.read')],
    loadComponent: () =>
      import('./components/audit/audit-log-page/audit-log-page.component')
        .then(m => m.AuditLogPageComponent)
  },
  {
    path: 'compliance',
    canActivate: [authGuard],
    children: [
      { path: 'cases', loadComponent: () => import('./components/compliance/compliance-cases-page/compliance-cases-page.component').then(m => m.ComplianceCasesPageComponent) },
      { path: 'cases/:id', loadComponent: () => import('./components/compliance/compliance-case-detail/compliance-case-detail.component').then(m => m.ComplianceCaseDetailComponent) },
      { path: 'sanctions', loadComponent: () => import('./components/compliance/sanctions-page/sanctions-page.component').then(m => m.SanctionsPageComponent) },
      { path: 'sar', loadComponent: () => import('./components/compliance/sar-str-page/sar-str-page.component').then(m => m.SarStrPageComponent) },
    ]
  },
  {
    path: 'fraud',
    canActivate: [authGuard],
    children: [
      { path: 'cases', loadComponent: () => import('./components/fraud/fraud-cases-page/fraud-cases-page.component').then(m => m.FraudCasesPageComponent) },
      { path: 'cases/:id', loadComponent: () => import('./components/fraud/fraud-case-detail/fraud-case-detail.component').then(m => m.FraudCaseDetailComponent) },
      { path: 'alerts', loadComponent: () => import('./components/fraud/fraud-alerts-page/fraud-alerts-page.component').then(m => m.FraudAlertsPageComponent) },
    ]
  },
  {
    path: 'treasury',
    canActivate: [authGuard],
    children: [
      { path: 'nostro', loadComponent: () => import('./components/treasury/nostro-grid-page/nostro-grid-page.component').then(m => m.NostroGridPageComponent) },
      { path: 'liquidity', loadComponent: () => import('./components/treasury/liquidity-page/liquidity-page.component').then(m => m.LiquidityPageComponent) },
      { path: 'funding', loadComponent: () => import('./components/treasury/funding-page/funding-page.component').then(m => m.FundingPageComponent) },
      { path: 'fx', loadComponent: () => import('./components/treasury/fx-quotes-page/fx-quotes-page.component').then(m => m.FxQuotesPageComponent) },
    ]
  },
  {
    path: 'reconciliation',
    canActivate: [authGuard],
    children: [
      { path: '', loadComponent: () => import('./components/reconciliation/recon-workspace-page/recon-workspace-page.component').then(m => m.ReconWorkspacePageComponent) },
      { path: 'breaks', loadComponent: () => import('./components/reconciliation/recon-breaks-page/recon-breaks-page.component').then(m => m.ReconBreaksPageComponent) },
    ]
  },
  {
    path: 'incidents',
    canActivate: [authGuard],
    loadComponent: () => import('./components/incidents/incident-command-page/incident-command-page.component').then(m => m.IncidentCommandPageComponent)
  },
  {
    path: 'config',
    canActivate: [authGuard],
    children: [
      { path: 'reference-data', loadComponent: () => import('./components/config/reference-data-page/reference-data-page.component').then(m => m.ReferenceDataPageComponent) },
      { path: 'ufp', loadComponent: () => import('./components/config/ufp-register-page/ufp-register-page.component').then(m => m.UfpRegisterPageComponent) },
      { path: 'maintenance', loadComponent: () => import('./components/config/maintenance-page/maintenance-page.component').then(m => m.MaintenancePageComponent) },
      { path: 'webhooks', loadComponent: () => import('./components/config/webhook-page/webhook-page.component').then(m => m.WebhookPageComponent) },
      { path: 'sandbox', loadComponent: () => import('./components/config/sandbox-page/sandbox-page.component').then(m => m.SandboxPageComponent) },
      { path: 'history', loadComponent: () => import('./components/config/config-history-page/config-history-page.component').then(m => m.ConfigHistoryPageComponent) },
    ]
  },
  {
    path: '**',
    redirectTo: 'dashboard'
  }
];
