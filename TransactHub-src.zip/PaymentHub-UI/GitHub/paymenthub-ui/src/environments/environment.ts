export const environment = {
  production: false,
  apiBaseUrl: '/api',
  opsApiBaseUrl: '/api',
  sseBaseUrl: '/api/dashboard/events',
  auth: {
    authority: 'https://idp.bank.local/realms/paymenthub',
    clientId: 'paymenthub-bankingops',
    redirectUri: 'http://localhost:4300/auth/callback',
    postLogoutRedirectUri: 'http://localhost:4300',
    scope: 'openid profile email paymenthub.ops',
    silentRenewUrl: 'http://localhost:4300/silent-renew.html',
  },
  sessionTimeoutMinutes: 15,
  sessionWarningMinutes: 2,
  sseReconnectDelayMs: 3000,
  maxRetries: 3,
};
