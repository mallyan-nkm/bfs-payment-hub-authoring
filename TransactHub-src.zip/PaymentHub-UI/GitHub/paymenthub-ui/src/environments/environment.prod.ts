export const environment = {
  production: true,
  apiBaseUrl: '/api',
  opsApiBaseUrl: '/api/ops',
  sseBaseUrl: '/events',
  auth: {
    authority: 'https://idp.bank.local/realms/paymenthub',
    clientId: 'paymenthub-bankingops',
    redirectUri: '/auth/callback',
    postLogoutRedirectUri: '/',
    scope: 'openid profile email paymenthub.ops',
    silentRenewUrl: '/silent-renew.html',
  },
  sessionTimeoutMinutes: 15,
  sessionWarningMinutes: 2,
  sseReconnectDelayMs: 3000,
  maxRetries: 3,
};
