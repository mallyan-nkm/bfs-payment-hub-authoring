/// <reference lib="webworker" />

const CACHE_NAME = 'paymenthub-ops-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
];

self.addEventListener('install', (event: any) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS))
  );
});

self.addEventListener('activate', (event: any) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
});

self.addEventListener('fetch', (event: any) => {
  // Network-first for API calls
  if (event.request.url.includes('/api/') || event.request.url.includes('/events/')) {
    event.respondWith(
      fetch(event.request).catch(() => caches.match(event.request) as Promise<Response>)
    );
    return;
  }

  // Cache-first for static assets
  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request))
  );
});
