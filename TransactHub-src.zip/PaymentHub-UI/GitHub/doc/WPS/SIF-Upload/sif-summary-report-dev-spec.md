# SIF Summary Report — Development Spec (WPS Module)

Reusable across `wps/sif-summary`, `sif-detail`, `rtc`, `acknak`, `fts`, `ipp`, `ipi`, `swift`.

```
shared/
  components/
    data-table/
    status-badge/
    page-header/
    filter-toolbar/
    pagination-bar/
    action-buttons/
  directives/
    column-toggle.directive.ts
    export-csv.directive.ts
    sortable-column.directive.ts

wps/sif-summary/
  sif-summary.component.ts/html/scss
  sif-summary.model.ts
  sif-summary.mock.ts
  sif-summary.service.ts
```

---

## Phase 1 — Shared Components & Directives (build once, reuse everywhere) ✅ **COMPLETED**

**1. `shared/components/page-header`** ✅
Inputs: `breadcrumb: string[]`, `title`, `subtitle`. Content-projected slot (top-right) for action buttons (`Export CSV`, `Columns`).

**2. `shared/components/filter-toolbar`** ✅
Right-aligned `Clear` (outline) + `Search` (primary green) buttons. Emits `(clear)` and `(search)` events. Content-projectable for filter fields later.

**3. `shared/components/data-table`** ✅ (core reusable table)
Inputs:
- `columns: ColumnDef[]` → `{ key, label, sortable?, type?: 'text'|'number'|'currency'|'date'|'status', width? }`
- `rows: any[]`
- `rowActions: ActionDef[]` → `{ label, icon?, onClick }`

Features: per-column sort icon (via `sortable-column` directive), column show/hide (via `column-toggle` directive), renders `status-badge` when `type: 'status'`, renders `action-buttons` for the Actions column, empty/loading states.

**4. `shared/components/status-badge`** ✅
Input: `status: string`. Central color map (extend here, don't repeat per module):
```
ACK Received   -> green
NAK Received   -> red
Completed      -> green (solid)
Sent to CB     -> amber
Failed         -> red
Processing     -> blue
```

**5. `shared/components/action-buttons`** ✅
Input: `actions: {label, onClick}[]`. Renders outline buttons ("360 View", "Audit") — reused per row across all report modules.

**6. `shared/components/pagination-bar`** ✅
Inputs: `total`, `pageSize`, `currentPage`. Emits `pageChange`, `pageSizeChange`. Shows "Showing X–Y of N records", page-size select, Prev/Next, "page/totalPages".

**7. `shared/directives/export-csv`** ✅
`[appExportCsv]="{rows, columns, filename}"` on any button; generates CSV client-side. Reused by every future report's "Export CSV" button.

**8. `shared/directives/column-toggle`** ✅
`[appColumnToggle]="columns"` on the "Columns" button — checklist popover to show/hide `data-table` columns, emits updated `ColumnDef[]`.

**9. `shared/directives/sortable-column`** ✅
Attach to `data-table` header cells; toggles asc/desc and emits `sortChange`.

---

## Phase 2 — Data Model ✅ **COMPLETED**

`wps/sif-summary/sif-summary.model.ts` ✅

```ts
export type SifStatus =
  | 'ACK Received'
  | 'NAK Received'
  | 'Completed'
  | 'Sent to CB'
  | 'Failed'
  | 'Processing';

export interface SifSummaryRow {
  slNo: number;
  fileName: string;
  sifFileName: string;
  corporateName: string;
  accountNumber: string;
  molEstablishmentId: string;
  uploadDate: string;        // ISO string, format in table via pipe/formatter
  totalRecords: number;
  totalAmount: number;       // AED, format via currency pipe/formatter
  currentStatus: SifStatus;
  uploadedBy: string;
}
```

---

## Phase 3 — Mock Data ✅ **COMPLETED**

`wps/sif-summary/sif-summary.mock.ts` ✅

```ts
import { SifSummaryRow } from './sif-summary.model';

export const SIF_SUMMARY_MOCK: SifSummaryRow[] = [
  {
    slNo: 1,
    fileName: 'ORIG_WPS_20260522_001.SIF',
    sifFileName: 'WPS109928838.SIF',
    corporateName: 'Al Noor Trading LLC',
    accountNumber: 'AE070331234567890123456',
    molEstablishmentId: '10001234',
    uploadDate: '2026-05-22T19:40:00',
    totalRecords: 100,
    totalAmount: 850000.00,
    currentStatus: 'ACK Received',
    uploadedBy: 'Ali Hassan'
  },
  {
    slNo: 2,
    fileName: 'ORIG_WPS_20260520_003.SIF',
    sifFileName: 'WPS109928712.SIF',
    corporateName: 'Emirates Steel Arkan',
    accountNumber: 'AE070331234567890198765',
    molEstablishmentId: '10005678',
    uploadDate: '2026-05-20T14:15:00',
    totalRecords: 250,
    totalAmount: 2100000.00,
    currentStatus: 'NAK Received',
    uploadedBy: 'Sara Mohammed'
  },
  {
    slNo: 3,
    fileName: 'ORIG_WPS_20260519_002.SIF',
    sifFileName: 'WPS109928601.SIF',
    corporateName: 'Gulf Catering Company',
    accountNumber: 'AE070331234567890112233',
    molEstablishmentId: '10009901',
    uploadDate: '2026-05-19T09:30:00',
    totalRecords: 75,
    totalAmount: 615500.00,
    currentStatus: 'Completed',
    uploadedBy: 'Khalid Rashid'
  },
  {
    slNo: 4,
    fileName: 'ORIG_WPS_20260518_001.SIF',
    sifFileName: 'WPS109928490.SIF',
    corporateName: 'Mashreq Bank PJSC',
    accountNumber: 'AE070331234567890144556',
    molEstablishmentId: '10003344',
    uploadDate: '2026-05-18T11:05:00',
    totalRecords: 320,
    totalAmount: 4250000.00,
    currentStatus: 'Sent to CB',
    uploadedBy: 'Fatima Al Zaabi'
  },
  {
    slNo: 5,
    fileName: 'ORIG_WPS_20260515_004.SIF',
    sifFileName: 'WPS109928311.SIF',
    corporateName: 'Danube Properties LLC',
    accountNumber: 'AE070331234567890177889',
    molEstablishmentId: '10007722',
    uploadDate: '2026-05-15T16:50:00',
    totalRecords: 48,
    totalAmount: 390000.00,
    currentStatus: 'Failed',
    uploadedBy: 'Omar Yusuf'
  },
  {
    slNo: 6,
    fileName: 'ORIG_WPS_20260514_002.SIF',
    sifFileName: 'WPS109928200.SIF',
    corporateName: 'Emaar Properties PJSC',
    accountNumber: 'AE070331234567890199001',
    molEstablishmentId: '10002255',
    uploadDate: '2026-05-14T08:20:00',
    totalRecords: 185,
    totalAmount: 1575000.00,
    currentStatus: 'Processing',
    uploadedBy: 'Ali Hassan'
  },
  {
    slNo: 7,
    fileName: 'ORIG_WPS_20260512_001.SIF',
    sifFileName: 'WPS109928055.SIF',
    corporateName: 'Al Futtaim Group',
    accountNumber: 'AE070331234567890166778',
    molEstablishmentId: '10004411',
    uploadDate: '2026-05-12T10:12:00',
    totalRecords: 410,
    totalAmount: 5120000.00,
    currentStatus: 'Completed',
    uploadedBy: 'Sara Mohammed'
  },
  {
    slNo: 8,
    fileName: 'ORIG_WPS_20260510_003.SIF',
    sifFileName: 'WPS109927940.SIF',
    corporateName: 'Dubai Investments PJSC',
    accountNumber: 'AE070331234567890133445',
    molEstablishmentId: '10008833',
    uploadDate: '2026-05-10T13:45:00',
    totalRecords: 62,
    totalAmount: 480500.00,
    currentStatus: 'ACK Received',
    uploadedBy: 'Khalid Rashid'
  },
  {
    slNo: 9,
    fileName: 'ORIG_WPS_20260508_002.SIF',
    sifFileName: 'WPS109927815.SIF',
    corporateName: 'Union Coop',
    accountNumber: 'AE070331234567890155667',
    molEstablishmentId: '10006699',
    uploadDate: '2026-05-08T15:30:00',
    totalRecords: 130,
    totalAmount: 990000.00,
    currentStatus: 'Processing',
    uploadedBy: 'Fatima Al Zaabi'
  },
  {
    slNo: 10,
    fileName: 'ORIG_WPS_20260506_001.SIF',
    sifFileName: 'WPS109927690.SIF',
    corporateName: 'RAK Ceramics PJSC',
    accountNumber: 'AE070331234567890188990',
    molEstablishmentId: '10001122',
    uploadDate: '2026-05-06T09:05:00',
    totalRecords: 275,
    totalAmount: 3105000.00,
    currentStatus: 'NAK Received',
    uploadedBy: 'Omar Yusuf'
  },
  {
    slNo: 11,
    fileName: 'ORIG_WPS_20260504_002.SIF',
    sifFileName: 'WPS109927555.SIF',
    corporateName: 'Al Ain Farms LLC',
    accountNumber: 'AE070331234567890177001',
    molEstablishmentId: '10009988',
    uploadDate: '2026-05-04T12:20:00',
    totalRecords: 58,
    totalAmount: 425000.00,
    currentStatus: 'Sent to CB',
    uploadedBy: 'Ali Hassan'
  },
  {
    slNo: 12,
    fileName: 'ORIG_WPS_20260502_001.SIF',
    sifFileName: 'WPS109927420.SIF',
    corporateName: 'Etisalat Group',
    accountNumber: 'AE070331234567890144332',
    molEstablishmentId: '10003300',
    uploadDate: '2026-05-02T17:00:00',
    totalRecords: 520,
    totalAmount: 6250000.00,
    currentStatus: 'Failed',
    uploadedBy: 'Sara Mohammed'
  }
];
```

---

## Phase 4 — `wps/sif-summary` Module Wiring ✅ **COMPLETED**

`sif-summary.component.ts` ✅: define `columns: ColumnDef[]` for the 11 columns (SL NO, File Name, SIF File Name, Corporate Name, Account Number, MOL Establishment ID, Upload Date, Total Records, Total Amount [currency], Current Status [status], Uploaded By) + Actions column ("360 View", "Audit"). Wire `sif-summary.service.ts` ✅ (paginated GET, or `SIF_SUMMARY_MOCK` during dev) into `data-table` + `pagination-bar`.

**Deliverable:** ✅ `page-header` ("SIF Summary Report" / "WPS Salary Information File processing overview", breadcrumb Reports > WPS > SIF Summary Report) + `filter-toolbar` + `data-table` + `pagination-bar`, composed purely from Phase 1 shared components — no report-specific markup beyond `columns` + `rows` wiring.
