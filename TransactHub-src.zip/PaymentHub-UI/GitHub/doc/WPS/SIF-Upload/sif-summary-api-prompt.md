# Prompt: Build API for SIF Summary Report (replace hardcoded mock)

## Column → Table Mapping
| Grid Column | Source | Notes |
|---|---|---|
| SL No | — | row index, generate in API/UI, not a DB column |
| File Name | `wps.SifFileSubmissions.OriginalFileName` | direct |
| SIF File Name | `wps.SifFileSubmissions.SavedFileName` | direct |
| Corporate Name | `corporate.CorporateHeaders.CorporateName` | **JOIN** on `SifFileSubmissions.CorporateId = CorporateHeaders.CorporateId` (+ `TenantId`) |
| Account Number | `wps.SifFileSubmissions.AccountNumber` | direct |
| MOL Establishment ID | `wps.SifFileSubmissions.MolEstablishmentId` | direct |
| Upload Date | `wps.SifFileSubmissions.CreatedAt` | direct |
| Total Records | `wps.SifFileSubmissions.TotalRecordCount` | direct |
| Total Amount | `wps.SifFileSubmissions.TotalSalaryAmount` | direct |
| Current Status | `wps.cycle_states.CurrentStatus` | **GAP** — see below |
| Uploaded By | — | **GAP** — see below |

## Resolved decisions
1. **Current Status**: join key to `cycle_states` not yet confirmed — **hardcode as `"Processing"` for now**. Once `TransactionId ↔ FileId` mapping is confirmed, switch to real join and always take the **latest row by `LastUpdatedAt`**.
2. **Uploaded By**: use `SifFileSubmissions.ServiceUserId` as-is (no separate user-name resolution needed).
3. **TenantId**: required on every API call; pass as a param/header. Current value: `"DIB"`.

## API to build
`GET /api/reports/wps/sif-summaryReport`

**Query params:** `page`, `pageSize`, `sortBy`, `sortDir`, plus per-column filters: `fileName`, `sifFileName`, `corporateName`, `accountNumber`, `molEstablishmentId`, `uploadDateFrom`, `uploadDateTo`, `status`, `uploadedBy`.

**Sample Response:**
```json
{
  "totalRecords": 12,
  "page": 1,
  "pageSize": 6,
  "data": [
    {
      "slNo": 1,
      "fileName": "ORIG_WPS_20260522_001.SIF",
      "sifFileName": "WPS109928838.SIF",
      "corporateName": "Al Noor Trading LLC",
      "accountNumber": "AE070331234567890123456",
      "molEstablishmentId": "10001234",
      "uploadDate": "2026-05-22T19:40:00Z",
      "totalRecords": 100,
      "totalAmount": 850000.00,
      "currentStatus": "Processing",
      "uploadedBy": "WEB_SERVICE_USER"
    }
  ]
}
```

**Sample Query (v1 — status hardcoded until join key confirmed):**
```sql
SELECT
  sfs.OriginalFileName    AS FileName,
  sfs.SavedFileName       AS SifFileName,
  ch.CorporateName,
  sfs.AccountNumber,
  sfs.MolEstablishmentId,
  sfs.CreatedAt            AS UploadDate,
  sfs.TotalRecordCount     AS TotalRecords,
  sfs.TotalSalaryAmount    AS TotalAmount,
  'Processing'              AS CurrentStatus,   -- TODO: replace with cycle_states join once TransactionId↔FileId confirmed
  sfs.ServiceUserId        AS UploadedBy
FROM wps.SifFileSubmissions sfs
LEFT JOIN corporate.CorporateHeaders ch
  ON ch.CorporateId = sfs.CorporateId AND ch.TenantId = sfs.TenantId
WHERE sfs.TenantId = @TenantId   -- e.g. 'DIB'
ORDER BY sfs.CreatedAt DESC
```

**Sample Query (v2 — once join key confirmed), replace the hardcoded status line with:**
```sql
LEFT JOIN (
  SELECT cs1.*
  FROM wps.cycle_states cs1
  INNER JOIN (
    SELECT TransactionId, MAX(LastUpdatedAt) AS MaxUpdatedAt
    FROM wps.cycle_states
    WHERE TenantId = @TenantId
    GROUP BY TransactionId
  ) latest ON latest.TransactionId = cs1.TransactionId AND latest.MaxUpdatedAt = cs1.LastUpdatedAt
) cs ON cs.TransactionId = sfs.FileId AND cs.TenantId = sfs.TenantId
-- and select cs.CurrentStatus instead of the hardcoded literal
```

## Frontend
Replace the hardcoded array in `sif-summary.service.ts` with an HTTP call to the above endpoint, passing pagination/sort/filter state from `data-table` + `pagination-bar` + column-filter row as query params.