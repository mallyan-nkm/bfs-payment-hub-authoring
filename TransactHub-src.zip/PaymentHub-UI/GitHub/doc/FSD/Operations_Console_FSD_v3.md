Payment Hub Platform

Operations Console

Detailed Functional Specification

Version 2 — Comprehensive Coverage with Gap Closure

User Interface Deep Dive

This v2 closes functional gaps identified across all formal module specifications

including Reference Data Admin, Operational Control Levers, Compliance Case Management,

Liquidity Orchestration UI, WPS File Operations, GPI Detail, Reconciliation Workspace,

Incident Command, and 18 additional functional domains.

Audience: UX Designers • Frontend Engineers • Backend API Engineers

Operations Leadership • QA • Internal Audit • Vendor UI/UX Partners

Status: Final V2  |  Audit-Verified Coverage

# Document Metadata

# V2 Change Summary

Version 2 of this Functional Specification incorporates 26 new or substantially-expanded functional domains identified through systematic gap analysis against the platform's formal module specifications. The original Sections 1-30 remain valid and authoritative; V2 adds new Sections 31-56 covering the previously-missing functionality.

## Sections Added in V2

## Original V1 Sections Retained

All original Sections 1 through 30 from V1 remain authoritative and are reproduced in this V2. The V2 additions are layered on top, not replacing prior content. Where V2 extends original sections, cross-references are noted.

# Table of Contents

PART I — ORIGINAL V1 SECTIONS

1. Document Purpose and Scope

2. User Personas and Authority Tiers

3. Application Structure and Navigation

4. Authentication and Session Management

5. Workspace Composition Framework

6. Global Header and Navigation

7. Side Navigation and Module Discovery

8. Main Panel — Dashboard Functionality

9. Main Panel — Queue Functionality

10. Main Panel — Detail View Functionality

11. Main Panel — Reports and Analytics

12. Action Panel — Context-Sensitive Actions

13. Transaction Initiation Forms

14. Approval Workflow Surfaces

15. Exception Management Surfaces

16. Per-Rail Operations Surfaces

17. Cross-Cutting Capabilities

18. Notifications and Alerts

19. Search and Discovery

20. Personalization Features

21. Audit and Activity Tracking

22. Integration with Platform Backend

23. Mobile and Desktop Variants

24. Accessibility Requirements

25. Performance Requirements

26. Security and Privacy Requirements

27. Error Handling and Resilience

28. Help and Documentation

29. Internationalization

30. Appendices

PART II — V2 ADDITIONS (CLOSING IDENTIFIED GAPS)

31. Reference Data Administration UI

32. Operational Control Levers UI

33. Compliance Case Management UI

34. Fraud Case Management UI

35. Sanctions Hit Adjudication UI

36. SAR / STR Workflow UI

37. Reimbursement Assessment UI

38. Beneficiary Consent Workflow UI

39. Liquidity Orchestration UI

40. Funding Request Management UI

41. Counterparty Exposure Management UI

42. Stress Testing UI

43. WPS File Operations UI

44. GPI Tracker Detail UI

45. FX Quote and Treasury UI

46. Reconciliation Workspace UI

47. UFP Register and Cycle UI

48. Incident Command Center UI

49. Workflow Replay and Forensics UI

50. Shift Handover and Team Workload UI

51. Document and Evidence Management UI

52. Collaboration and Messaging UI

53. Maintenance Window and System Status UI

54. Webhook and Corporate Integration UI

55. Sandbox and Test Transaction UI

56. Configuration Change History UI

PART III — APPENDICES

A. Persona to Capability Mapping

B. Cross-References to Module Specifications

C. Functional Coverage Matrix (Updated)

D. UI Component Catalog

E. V2 Gap Closure Audit Trail

# Part I — Original V1 Sections

The following 30 sections were issued in Version 1 of this Functional Specification. They remain authoritative and are reproduced here for completeness. Part II (Sections 31-56) adds new functional domains identified through gap analysis.

# Section 1: Document Purpose and Scope

## 1.1 Purpose

This document specifies in functional detail every capability the Operations Console must deliver to users. It bridges the architectural Operations Console Design module (which describes the conceptual framework) and the actual implementation requirements (which engineering teams will build).

## 1.2 Scope

#### In Scope

All persona workspaces and their default behaviors

All operational queues, dashboards, and detail views

All action invocation surfaces (transaction initiation, approvals, exception resolution)

All reporting and analytics capabilities

All cross-cutting features (RBAC, audit, notifications, search, personalization)

Mobile and desktop variants

Accessibility, performance, security, and error handling

#### Out of Scope

Underlying platform module specifications (covered in module documentation)

Backend API specifications (covered separately)

Specific UI component library selection (engineering decision)

Visual design styling (covered in design system)

## 1.3 Document Conventions

MUST = mandatory functional requirement. SHOULD = strongly recommended; deviation requires explicit rationale. MAY = optional enhancement. Persona-specific = the requirement applies only to the specified persona. Rail-specific = the requirement applies only to flows on the specified rail.

# Section 2: User Personas and Authority Tiers

## 2.1 Persona Inventory

## 2.2 Authority Tiers

## 2.3 Persona Assignment Rules

Each user account MUST have exactly one primary persona

A user MAY have additional secondary persona assignments for cross-functional roles

Persona changes MUST require dual approval (HR + Operations Head) and MUST be audit-logged

Persona inheritance MUST follow organizational hierarchy where configured

# Section 3: Application Structure and Navigation

The console MUST present a consistent four-region layout: Header Bar (top, full width, fixed), Side Navigation (left, collapsible), Main Panel (center, primary work area, supports single-pane / split-pane / tabbed layouts), Action Panel (right or bottom, context-sensitive). Navigation MUST support: top-down hierarchical (Header > Side > Sub-section > Detail item); breadcrumb trail; back/forward navigation; deep linking via shareable URLs; bookmarks; recently visited history.

# Section 4: Authentication and Session Management

## 4.1 Authentication Flow

SSO integration with bank's identity provider

MFA for all users on initial login per session

Re-authentication for critical actions (see Section 12)

Session timeout: 15 minutes inactivity for operational personas; 5 minutes for executive personas

Concurrent session control with detection and warning

## 4.2 Session Management

Persist across browser tabs; invalidate when browser fully closed

Display session timer when within 2 minutes of timeout

Offer session extension via re-authentication

Graceful expiry with in-progress work saved

## 4.3 Privileged Access

JIT elevation for C-Suite, Manager, Executive personas

Time-bounded elevations (30-minute window)

Audit logging of all elevations with rationale

## 4.4 Persona Switching

Persona switching available from header for multi-persona users

Each switch audit-logged

Active persona visually distinct

Workspace refreshes on persona switch

# Section 5: Workspace Composition Framework

Each persona MUST have a default workspace loading on login, composed of: Primary dashboard for the persona's main domain, Active queues relevant to the persona, Pending action indicators, Quick-access actions.

## 5.1 Workspace Components

## 5.2 Workspace Customization

Drag-and-drop rearrangement

Resize components

Add/remove from component library

Save multiple custom layouts per user

Switch between saved layouts

Reset to default workspace

## 5.3 Workspace Sharing

Managers/Heads publish team templates

Templates versioned with effective dates

Adoption optional unless mandated

# Section 6: Global Header and Navigation

## 6.1 Header Components

## 6.2 Global Search

Free-text search across workflow IDs, payment references, customer IDs, BICs, employee IDs, invoice numbers, GIBANs, exception codes, queue names, dashboard names, report names

Structured queries (customer:123456, amount:>1M, status:held)

Recent searches persisted per user

Search filters: date range, rail, persona scope, status

Result categorization grouped by type

Result preview on hover or click

Direct navigation on click

Search permissions respect persona RBAC

## 6.3 Rail Switcher

Quick navigation to: All Rails (default cross-rail view), UAEFTS, IPI/Aani, IPP, WPS, SWIFT Rail Dashboards. Switching MUST refresh main panel, filter side navigation, preserve persona context, support keyboard shortcuts Alt+1 through Alt+6.

# Section 7: Side Navigation and Module Discovery

## 7.1 Side Navigation Structure

## 7.2 Side Navigation Behaviors

Icon-only collapsed mode and full-width expanded mode

Highlight current location

Collapse/expand sections on click

Persist user's collapse state per session

Badge counts on items requiring attention

Filterable via search box at top

Hide items user lacks permission to access

# Section 8: Main Panel — Dashboard Functionality

## 8.1 Live Operations Dashboard

#### Top-Level KPIs

Total in-flight payments across all rails (last 24h)

Total value processed (last 24h)

Exception count by severity

Approval pending count

SLA compliance percentage (last 24h, last hour)

System health indicator per rail

#### Per-Rail Health

Status: operational, degraded, outage

Throughput: current vs typical

Latency: P50, P95, P99 vs target

Error rate: last 1h, last 24h

Open exceptions count

## 8.2 Per-Rail Dashboards

### UAEFTS Rail

Live CB103, CB202, CB202COV, CB101 (UFP) volumes

Settlement window status with countdown

Daily cycle progress hourly breakdown

CB940/CB950 statement ingestion status

Treasury vs Customer segregation

KPIs: dispatch latency, settlement confirmation latency, exception rate, reconciliation break rate

### IPI / Aani Rail

Live instant payment volumes (per second, per minute)

Sub-second SLA compliance percentage

Aani alias resolution health

Confirmation of Payee health

KPIs: throughput, latency percentiles, instant-confirmation rate

### IPP Rail

Similar structure to IPI with IPP scheme-specific configurations.

### WPS Rail

Active SIF/PIF/DIF/RFA/RTC files with status

RFR/RRI/RRR/DCR/RSU refund flow status

MOHRE compliance status

Per-employer establishment views

KPIs: file completion rate, employee credit success rate

### SWIFT Rail

Inbound and outbound correspondent volumes

GPI tracker subscriptions and status updates

FX leg health

Multi-currency Nostro positions

Per-corridor, per-counterparty sub-queues

KPIs: GPI compliance rate, end-to-end latency, dispute rate

## 8.3 Specialized Dashboards

Counterparty Exposure (Treasury/Risk); Nostro Position (Treasury); Compliance Dashboard; Fraud Dashboard; Reconciliation Dashboard.

## 8.4 Dashboard Refresh

Manual refresh available. Pause refresh option available.

# Section 9: Main Panel — Queue Functionality

## 9.1 Queue List Display

## 9.2 Queue Filtering and Sorting

Multi-column filtering with AND/OR logic

Date range filtering

Saved filter sets per user

Quick filters (predefined)

Multi-column sorting with visual indicators

Persistent sort/filter state within session

## 9.3 Queue Actions

View detail

Take action (action panel)

Assign / Reassign (manager-tier+)

Comment

Mark as urgent

Tag

Bulk actions

## 9.4 Bulk Actions

Bulk approve, reject, reassign, comment, export, apply tag

Preview before execution showing impacted items

Require explicit confirmation

Audit-logged with bulk action correlation ID

Show progress during execution

Display per-item outcomes

## 9.5 Performance

Queue list loads within 2 seconds (100-500 items)

Server-side pagination for queues > 1000 items

Filter/sort updates within 500 ms

Bulk action up to 100 items within 30 seconds

# Section 10: Main Panel — Detail View Functionality

## 10.1 Header and Summary

Item identifier prominently displayed

Item type badge

Current status with visual indicator

Quick actions

Breadcrumb to parent context

Summary card with key fields, amount, currency, parties, important dates

## 10.2 Tabbed Detail Sections

## 10.3 Workflow Visualization

Visual flow diagram showing stages (current, completed, pending, skipped)

Stage timestamps with duration

Stage outcomes

Branch decisions highlighted

Linked sub-workflows navigation

Cross-workflow references

## 10.4 Linked Entity Navigation

Parent workflow (if child)

Child workflows (if parent)

Linked recalls/cancellations/returns

Linked SAR/STR cases

Linked reimbursement assessments

Linked reconciliation breaks

Original payment (if related to recall/return)

## 10.5 Performance

Detail view loads within 2 seconds

Tab switching instant (pre-loaded)

Workflow visualization renders within 1 second

Activity log supports virtual scrolling

# Section 11: Main Panel — Reports and Analytics

## 11.1 Report Categories

#### Operational Reports

Daily transaction volumes per rail

Daily exception summaries

Daily reconciliation cycle outcomes

Daily SLA compliance reports

Per-team productivity reports

Queue aging reports

#### Regulatory Reports

LCR reports

Intraday liquidity reporting (BCBS)

UFP cycle reports

MOHRE compliance reports per WPS cycle

SAR/STR submission reports

Sanctions monitoring reports

Counterparty exposure reports

AML transaction monitoring reports

#### Executive Dashboards

Daily executive summary, weekly trends, monthly business review, quarterly performance review, strategic KPI tracking

## 11.2 Report Builder (Custom Reports)

For senior personas (Manager, Executive, Senior Management):

#### Data Sources

Workflow registry

Audit log

Nostro register

Exception ledger

Reconciliation log

Customer transactions

Counterparty data

#### Dimensions

Time (year, quarter, month, week, day, hour)

Rail

Module / Flow type

Customer segment

Counterparty

Channel

Currency

Geographic dimension

#### Metrics

Count, Sum, Average, Percentiles (P50-P99), Min, Max, Standard deviation, Custom formula calculations

#### Visualizations

Table, Line, Bar, Pie/Donut, Area, Heatmap, Geographic map, Sankey

## 11.3 Report Scheduling

One-time generation with download

Scheduled generation (daily, weekly, monthly, custom cron)

Distribution lists

Output formats: CSV, Excel, PDF, JSON

Delivery: email attachment, secure download link, portal link

## 11.4 Performance

Standard reports generate within 30 seconds

Complex custom reports within 5 minutes

Long-running reports run async with notifications

Report data cacheable for repeated queries

# Section 12: Action Panel — Context-Sensitive Actions

The action panel MUST appear when an item is selected, display only authorized actions, group by category (primary, secondary, advanced), hide non-applicable actions, indicate disabled actions with tooltips.

## 12.1 Workflow/Payment Actions

View details, View workflow visualization, View audit trail

Cancel (if eligible), Recall (if eligible), Initiate enquiry

Add comment, Tag, Assign / Reassign, Escalate, Mark as urgent

## 12.2 Exception Actions

View detail, Resolve (with resolution code)

Escalate, Reject, Hold pending input, Re-route

Comment, Investigate further

## 12.3 Approval Actions

Approve, Reject (with reason), Escalate

Request more information, Delegate, Hold pending clarification

## 12.4 Confirmation Levels

Standard confirmation: routine actions

Detailed confirmation with rationale: impactful actions

Re-authentication: critical actions per Section 12.5

## 12.5 Critical Actions Requiring Re-authentication

Pause/resume rail processing

Override critical validation

Bypass compliance hold

Bulk actions affecting > 50 items

Treasury repositioning above configured value

UFP register modifications

Configuration changes (Reference Data)

User permission changes

Emergency funding above configured value

# Section 13: Transaction Initiation Forms

All forms MUST: display structured inputs with appropriate widget types; validate in real-time; show inline errors; support draft save; show applicable approval chain; display preview before submission; require explicit confirmation; provide submission tracking.

## 13.1 Form Inventory

## 13.2 Form Validation

Block submission if mandatory fields empty

Field-level errors with red border

Form-level errors at top

Highlight affected fields

Validate field dependencies

Verify user authority before submission

Save form state on navigation (recover on return)

## 13.3 Performance

Form rendering within 500 ms

Lookup auto-suggestions within 300 ms

Validation feedback instant

Submission acknowledge within 1 second

# Section 14: Approval Workflow Surfaces

## 14.1 My Approvals Queue

Approval ID, item type, workflow ID and reference, module/flow type

Amount and currency, originating user and timestamp

Time remaining until SLA breach, priority indicator

Prerequisites status, rationale provided by originator

## 14.2 Approval Item Detail View

Header: approval ID, type, current step, remaining steps, SLA countdown

Approval chain visualization with steps

Subject item context: payment detail, validation/screening/fraud outcomes

Comments thread from previous approvers

Similar historical cases for consistency

## 14.3 Approval Decision Actions

## 14.4 SLA Management

Approval SLA per flow type and amount tier

Time elapsed indicators

Visual SLA indicators (green/yellow/red/black)

Auto-escalation rules

SLA breach reporting

# Section 15: Exception Management Surfaces

## 15.1 Exception Central Queue

Consolidates exceptions from all platform modules, routed to appropriate sub-queues by exception code and severity.

#### Filters

Exception code, Severity, Module/flow type, Rail, Persona assignment, Age, Auto-resolution status

#### Sub-Queues per Persona

Payments Operations L1/L2, Compliance L1/L2, Fraud Operations

Reconciliation Operations, WPS Operations, Correspondent Operations

Investigation Queue (cross-cutting)

## 15.2 Exception Triage

Header: exception code, severity, rail/module, age, queue assignment

Subject context: full item detail with validation/screening/fraud history

Resolution path suggestions based on historical patterns

Action panel: resolve, escalate, reject, hold, re-route, comment, investigate

## 15.3 Bulk Exception Actions

Mass re-route, mass retry, mass escalate

Audit captures bulk action with rationale

Per-item outcomes tracked individually

## 15.4 Resolution Tracking and Trends

Per-resolution timing tracked

Resolution code distribution

Auto-resolution rate, escalation rate, rejection rate

Rising exception categories alerts

Chronic unresolved exceptions alerts

Per-rail exception trends

# Section 16: Per-Rail Operations Surfaces

Each rail has dedicated workspace. See V2 Sections 43-47 for deep dives on WPS File Operations, GPI Tracker Detail, UFP Register, and rail-specific capabilities.

## 16.1 UAEFTS Workspace

UAEFTS Rail Dashboard, per-message-type sub-queues (CB103 outbound/inbound, CB202/CB202COV, UFP, regulatory), settlement window timeline, CB940/CB950 ingestion status, per-counterparty bank views, Treasury vs Customer segregation.

## 16.2 IPI/Aani Workspace

IPI Rail Dashboard, in-flight outbound/inbound queues, Aani alias resolution monitoring, CoP monitoring, sub-second SLA breakdown, per-channel volume.

## 16.3 IPP Workspace

Similar structure to IPI with IPP-specific configurations.

## 16.4 WPS Workspace

See V2 Section 43 for WPS File Operations Deep Dive.

## 16.5 SWIFT Workspace

See V2 Section 44 for GPI Tracker Detail.

## 16.6 Cross-Rail Workspace

For Senior Management and Operations Heads: Cross-Rail Aggregated Dashboard, active incidents, trend analysis, rail health comparison, strategic KPI tracking.

# Section 17: Cross-Cutting Capabilities

## 17.1 Customer 360 View

Customer profile (relevant per persona)

Account list with balances

Recent transactions (last 100)

KYC status, Compliance flags

Customer notification preferences

Recent disputes/complaints, recalls/cancellations

Cross-rail activity summary

## 17.2 Counterparty 360 View

Counterparty BIC and details

Active relationships

Exposure utilization

Recent transaction history

Active disputes/issues

Vendor SLA compliance

## 17.3 Workflow Search and Tracking

Search workflows by ID, reference, customer, counterparty, amount, date range

Subscribe to workflow updates

Bookmark workflow for quick access

## 17.4 Investigation Linking

Create investigation case

Link multiple workflows, exceptions, customers, counterparties

Add documentation and evidence

Assign to investigator

Track investigation timeline

Resolution and closure workflow

## 17.5 Timeline View

For investigation cases or complex workflows: all linked events in chronological order, visual lifeline with milestones, branch points where decisions were made, linked workflows visualized.

# Section 18: Notifications and Alerts

## 18.1 Notification Types

Workspace badges on side navigation items

In-app notifications via bell icon

Toast notifications at top-right

Email per preference

SMS for critical events

Push notifications for mobile

## 18.2 Notification Categories

## 18.3 Notification Center

All notifications grouped by category

Show age, filter by category and read/unread

Mark as read/unread, archive

Click-through to related item

Persist 90 days minimum

## 18.4 User Preferences

Channel selection per category

Email digest frequency

Do Not Disturb windows

Critical alert override of DND

## 18.5 Broadcast Notifications

Operations Heads can send broadcasts to specific personas or all users with priority and channel specification; delivery and acknowledgement tracked.

# Section 19: Search and Discovery

Global search supports free-text, structured queries, filters, result categorization, permission-respecting results.

## 19.1 Shortcuts

## 19.2 Saved Searches

Save with custom names

Favorites

Share with team (RBAC-respecting)

Configure alerts on saved searches

## 19.3 Suggestions

Recent searches by user

Popular searches by persona

Related entities

Type-ahead for known entities

# Section 20: Personalization Features

## 20.1 User Preferences

Default workspace layout

Default rail on login

Theme: light, dark, high contrast

Language

Timezone display

Date and number format

Notification preferences

Dashboard refresh rates

Default filter sets per queue type

## 20.2 Custom Dashboards

Create from available components

Save multiple

Set as default

Share with team

Schedule snapshots for emails

## 20.3 Keyboard Shortcuts

## 20.4 Quick Actions Panel

Add frequently-used actions to personal panel, reorder, pin to header for one-click access.

# Section 21: Audit and Activity Tracking

## 21.1 Activity Logging

User identity and persona

Action type

Subject entity

Timestamp (UTC and local)

Session context

Network context

Action outcome

## 21.2 Visibility per Persona

## 21.3 Query Interface

User filter, Action type filter, Subject entity filter

Date range filter, Rail and module filter

Result export (CSV, Excel)

Saved queries

# Section 22: Integration with Platform Backend

## 22.1 API Integration

REST APIs over HTTPS

WebSocket for real-time updates

Server-Sent Events for notifications

## 22.2 Real-Time Data

Workflow state changes

New items in queues

New exceptions, new approvals

Position changes (Treasury)

Rail health status changes

Incident declarations

## 22.3 Offline Behavior

Display offline indicator

Queue actions for replay

Show last-known data with timestamp

Auto-reconnect

# Section 23: Mobile and Desktop Variants

## 23.1 Mobile App

All persona workspaces (simplified)

Real-time notifications

Approval queue with full action (re-authentication)

Critical incident alerts

Quick search

Persona-aware dashboards

Limited transaction initiation (pre-approved templates)

## 23.2 Mobile Behaviors

Touch targets minimum 44 pixels

Swipe gestures

Pull-to-refresh

Biometric re-authentication

Optimized data usage

Background sync

## 23.3 Desktop Power Tooling

Multi-monitor support with detachable panels

Desktop notifications

Hot keys

Customizable workflow automations

Advanced query capabilities

Bulk operation tooling

# Section 24: Accessibility Requirements

The console MUST conform to WCAG 2.1 Level AA:

Keyboard navigation for all interactive elements

Screen reader support with ARIA labels

Color contrast meets AA ratios

Visible focus indicators

Resizable text up to 200%

Skip-to-main-content link

Explicit form labels

Clear error identification

Extensible time limits

Reduced motion option

# Section 25: Performance Requirements

## 25.1 Concurrency

Up to 1000 concurrent users

Up to 10,000 active workflow items in queues

Up to 100,000 items in extended queue listings

# Section 26: Security and Privacy

## 26.1 Authentication

All sessions use TLS 1.3

Session tokens cryptographically secure

MFA enforced

## 26.2 Authorization

All actions authority-checked at request time

RBAC enforced at API and UI layers

Failed authorization audit-logged

## 26.3 Data Protection

Sensitive data encrypted at rest

API communication TLS 1.3

PII masked by default with explicit reveal (audit-logged)

Browser storage of sensitive data minimal and time-limited

## 26.4 Audit Logging

Every user action logged

Audit logs tamper-proof (append-only)

Queryable for 10 years minimum

# Section 27: Error Handling and Resilience

## 27.1 Error Categories

## 27.2 Recovery

Preserve user input on form errors for correction

Allow retry without losing state on action errors

Save in-progress work on session expiry; recover on re-login

## 27.3 Resilience

Handle backend degradation gracefully

Show partial data when some services unavailable

Clear 'service unavailable' indicators

Auto-retry transient failures

Manual retry for permanent failures

# Section 28: Help and Documentation

## 28.1 In-App Help

Help icon in header

Contextual help within forms and dialogs

Tooltip explanations

Keyboard shortcut overlay (?)

Walkthrough tours

First-time user onboarding

## 28.2 Documentation Integration

User guide knowledge base (searchable)

Video tutorials embedded

Glossary of terms

FAQ

Support contact

## 28.3 Persona Onboarding

Persona-specific orientation tour

Assigned learning path

Mentor/buddy assignment

Practice environment access (sandbox)

# Section 29: Internationalization

## 29.1 Language Support

English (primary)

Arabic (UAE-localized)

Right-to-left layout for Arabic

Mixed direction handling

Dynamic language switching without re-login

## 29.2 Localization

All UI strings

Date formats per locale

Number formats per locale

Currency formatting

Address formats

## 29.3 Maintenance

Translations maintained centrally

Missing translations fall back to English

Translation updates without code releases

# Section 30: V1 Appendices

## Appendix A: Component Library

Standardized buttons (primary, secondary, tertiary, destructive)

Standardized icons

Standardized forms and inputs

Standardized tables

Standardized notifications

Standardized modals and drawers

Standardized cards

Standardized data visualizations

## Appendix B: Browser Support

Chrome, Edge, Safari, Firefox (last 3 versions each)

Mobile Safari (iOS 14+)

Mobile Chrome (Android 10+)

# Part II — V2 Additions: Closing Identified Gaps

Sections 31 through 56 document functional requirements identified through systematic gap analysis against all formal module specifications. Each section addresses functionality that was either absent or insufficiently detailed in V1.

# Section 31: Reference Data Administration UI

## 31.1 Reference Data Domains

The console MUST provide administrative UIs for managing each reference data domain:

## 31.2 Reference Data Browser UI

For each domain, the console MUST provide:

Searchable browser with filter capabilities

Detail view of individual entries

Version history per entry (when entries change over time)

Effective date and expiry visibility

Last-refreshed timestamp

Source provenance (which feed, when imported)

Linked usage (which modules / workflows consume this entry)

Export to CSV/Excel for offline analysis

## 31.3 Reference Data Editing

For locally-editable reference data (approval authorities, persona definitions, notification templates, etc.):

Editing UI with form validation

Pre-publish preview showing impact on consuming modules

Dual approval workflow for changes (Operations Head + Compliance Head for high-impact)

Effective date scheduling (changes take effect at specified time)

Rollback capability with single-click revert to prior version

Change history with diff visualization

Audit logging of every change with rationale

## 31.4 Feed-Based Reference Data Monitoring

For feed-driven reference data (CBUAE participant directories, sanctions, PEP, etc.):

Feed health dashboard per source

Last successful refresh timestamp

Refresh failure alerts

Manual refresh trigger (emergency)

Delta view (what changed in the latest refresh)

Feed delay warnings (when feed lags behind expected refresh)

## 31.5 RBAC for Reference Data

# Section 32: Operational Control Levers UI

## 32.1 Levers Inventory

## 32.2 Lever Invocation UI

Each lever invocation MUST require:

Selection of the specific lever from a categorized menu

Rationale text (mandatory, free-text)

Linked incident reference (if applicable; references Incident Command Center)

Selection of all required co-approvers per lever's authority requirements

Co-approver acknowledgement workflow (parallel approval where dual/triple authority needed)

Re-authentication (MFA token) from invoker

Re-authentication from each co-approver

Final confirmation dialog showing scope and impact

## 32.3 Lever Effect Visualization

Before invocation, the UI MUST show:

Scope: which flows, customers, counterparties, or rails are affected

Estimated impacted volume (in-flight items, customer count)

Downstream consequences (which other flows depend on this)

Estimated revenue impact (where calculable)

Recovery procedure (how to resume)

Estimated duration based on similar past activations

## 32.4 Active Levers Dashboard

The console MUST provide a real-time dashboard of currently-active levers:

List of all active levers with: lever name, invocation timestamp, invoker, co-approvers, rationale, scope

Duration counter (how long this lever has been active)

Impact summary (volume held, customers affected)

Resume capability (one-click resume with re-authentication)

Lever expiry timer (auto-resume if configured)

## 32.5 Lever Audit and Reporting

Every lever invocation, modification, and resumption MUST be audit-logged

Lever activation history report (daily, monthly)

Lever activation frequency by type and rationale category

Lever activation impact reports (volume, value, duration)

Quarterly review report for regulatory audit

# Section 33: Compliance Case Management UI

## 33.1 Case Types

## 33.2 Case Creation UI

Automatic case creation from platform events (screening hits, fraud confirmations, regulator inquiries)

Manual case creation by Compliance Officer

Case ID auto-generated; case type selection

Subject parties (customers, counterparties, workflows)

Initial triage by Compliance Officer (L1)

Assignment to specific compliance investigator

## 33.3 Case Workspace

Each case MUST have a dedicated workspace with:

Case header: ID, type, status, priority, assigned investigator, age, SLA

Subject parties panel with full 360 view of each

Linked transactions and workflows with timeline

Evidence panel (uploaded documents, screening results, transaction history)

Investigation notes (chronological with author attribution)

Decision panel (Clear, Escalate, Block, SAR, STR, Dispute, Regulatory Submission)

Linked SAR/STR cases (see Section 36)

Related cases (history of similar cases for this customer or counterparty)

## 33.4 Case Workflow

## 33.5 Case Actions

Reassign to different investigator

Escalate to Compliance Manager or Head

Request documentation from customer/counterparty

Link additional transactions or workflows

Upload evidence (documents, communications)

Add investigation note

Draft decision

Submit for approval

Initiate SAR/STR (creates linked case per Section 36)

Initiate scheme dispute

Close case with resolution

## 33.6 Case Reporting

Active cases by type, priority, age

Case resolution time analytics (mean, median, P95)

Case outcomes distribution (cleared, blocked, SAR/STR)

Investigator productivity metrics

Trends by customer segment, corridor, or counterparty

Regulatory submission tracking

# Section 34: Fraud Case Management UI

## 34.1 Fraud Case Types

## 34.2 Fraud Case Workspace

Case header: ID, type, status, priority, assigned investigator

Subject customers and counterparties (Customer 360 + Counterparty 360 views)

Linked transactions with pattern visualization

Fraud model score breakdown (which features contributed)

Customer transaction history (last 100, with anomaly highlights)

Device and channel context (IP, device ID, channel)

Similar past fraud patterns (for context)

Customer communication log

Decision panel

## 34.3 Fraud Decision Actions

Clear (false positive; release any holds)

Block transaction (terminal reject)

Reverse transaction (if already completed)

Pattern B suspense (credit to suspense pending further review)

Trigger customer intervention (warning, callback, locking)

Lock customer account temporarily

Lock customer account permanently (with approval)

Initiate APP fraud reimbursement assessment (see Section 37)

Link to compliance case (if fraud is also AML-related)

Submit law enforcement report

## 34.4 Customer Intervention UI

For scam typology cases, the console MUST support customer intervention:

Compose scam warning message (template-based)

Send to customer via push, SMS, email

Trigger customer service callback

Lock customer's outbound capability temporarily

Restrict to verified beneficiaries only

Require enhanced authentication for next transactions

Track customer response and acknowledgement

## 34.5 Pattern Analysis UI

For Fraud Operations Managers and senior personas:

Pattern visualization across customers (sankey, network graph)

Time-series pattern detection

Geographic clustering

Counterparty bank clustering

Common channel or device patterns

Alert configuration for new patterns

Export pattern for regulatory submission

## 34.6 Mule Account Investigation

Mule indicators dashboard

Suspect mule accounts list

Transaction flow visualization (who funded, who received)

Investigation note capability

Decision: confirmed mule, suspected, cleared

Linked accounts (the mule's contacts)

Law enforcement coordination tracking

# Section 35: Sanctions Hit Adjudication UI

## 35.1 Adjudication Queue

Sanctions hits requiring adjudication appear in a dedicated queue:

Hit ID, hit timestamp

Subject party (originator, beneficiary, intermediary)

Sanctions list source (OFAC, UN, EU, UAE, etc.)

Match confidence score

Match details (which fields matched, how)

Linked transaction context

Priority (CONFIRMED > POTENTIAL > LOW_CONFIDENCE)

Age in queue, SLA status

Assigned compliance officer

## 35.2 Adjudication Workspace

When an adjudicator opens a hit:

Match detail: matched record on sanctions list with metadata

Subject party detail: full customer/counterparty 360

Match comparison view: side-by-side of matched fields with differences highlighted

Confidence factors: what contributed to the match (name, DOB, address, ID)

Past adjudication history: prior decisions on this subject

Linked workflow: the payment that triggered the hit

Funds status: held in compliance suspense, frozen, or released

## 35.3 Adjudication Actions

## 35.4 Adjudication Quality Control

Random sampling of cleared hits for QC review by Compliance Manager

QC outcomes tracked

False positive rate metrics per adjudicator

Review of cleared hits when sanctions list changes (was the cleared subject re-added?)

## 35.5 Reporting

Daily adjudication volumes

Cleared vs blocked distribution

Average adjudication time

Trending sanctions lists with most hits

Per-corridor sanctions hit trends

Regulatory submission count

# Section 36: SAR / STR Workflow UI

## 36.1 SAR/STR Case Lifecycle

## 36.2 SAR/STR Drafting UI

Template-based narrative composition per FIU format requirements

Auto-populated fields from linked transactions and parties

Suspicious activity description (free-text with template guidance)

Timeline of suspicious events

Linked accounts and customers

Linked counterparties

Supporting evidence attachments

Narrative validation (length, mandatory fields, regulatory format)

## 36.3 FIU Submission

Submission via FIU-prescribed channel (web portal, file upload, API)

Confirmation receipt capture

Submission reference assigned

Submission timestamp recorded for SLA tracking

## 36.4 Linked Workflow Visibility

Every SAR/STR MUST show all linked workflows that triggered or contributed

Customer 360 must indicate active SAR/STR (visibility restricted by RBAC)

Counterparty 360 must indicate active SAR/STR (similar restriction)

Investigation case linkage (Compliance Case Management — Section 33)

## 36.5 RBAC

# Section 37: Reimbursement Assessment UI

## 37.1 Reimbursement Trigger Sources

Customer raises APP fraud claim via channel

Failed recall on fraud-reason payment (the receiving bank declined)

Regulatory direction for specific case

Voluntary reimbursement decision by bank policy

## 37.2 Reimbursement Case Workspace

Case header: case ID, customer, claim amount, trigger source, status, age

Customer 360 with claim history

Original transaction detail

Customer's fraud claim narrative

Evidence panel (customer-provided, ops-gathered)

Liability assessment panel (who bears the loss)

Reimbursement decision (full, partial, declined)

Linked recall outcome (if recall was attempted)

Linked compliance case (if also AML-related)

## 37.3 Liability Assessment

The UI MUST guide the assessor through:

Was customer authorized? (vs unauthorized fraud)

Did the bank's controls fail? (potential bank liability)

Did customer follow security guidance? (impacts customer liability)

Was the receiving bank cooperative? (impacts split with receiving bank)

Are funds recoverable? (impacts net loss calculation)

Apply regulatory framework (per applicable consumer protection rules)

Decision: 100% bank, split, declined with reasons

## 37.4 Reimbursement Approval Chain

## 37.5 Reimbursement Execution

On approval, automatic credit to customer account

GL posting to fraud reimbursement reserve

Customer notification with reimbursement detail

Linked Internal Audit case for audit trail

Quarterly reimbursement reporting

# Section 38: Beneficiary Consent Workflow UI

## 38.1 Consent Trigger Sources

Inbound recall on error/fraud reason where beneficiary is at this bank

WPS RRI inbound where beneficiary is employee at Agent Bank

Other future flows requiring beneficiary consent

## 38.2 Consent Workflow UI for Operations

Branch and Ops staff use the console to manage consent collection:

Consent case queue showing pending consents

Case detail: original payment, recall reason, requested action

Customer/employee contact information

Consent collection channel options (in-branch, phone, secure messaging, app push)

Communication log per case

Consent decision capture (granted, declined, no response)

SLA tracking (typical 5-10 business days)

Auto-escalation if no response

## 38.3 Customer-Facing Consent UI (Mobile/Portal)

Customer/employee receives consent request via their banking channel:

Push notification with consent request preview

Secure in-app message with full detail

Clear explanation: original payment, requesting bank, reason, action requested

Decision buttons: Approve refund / Decline refund

Optional rationale field if declining

Confirmation upon submission

Audit log of customer's decision with timestamp and channel

## 38.4 Branch In-Person Consent Capture

If consent is collected in-branch:

Branch officer authenticates customer in person

Reviews consent request with customer

Captures customer's signature (electronic or paper-scan)

Captures decision in system with reference to in-person verification

Customer receives confirmation copy

## 38.5 Phone Consent Capture

Call center authenticates customer

Reviews consent request

Captures recorded verbal consent

Recording referenced in case

Customer receives written confirmation post-call

## 38.6 No-Response Handling

Configurable timeout (typically 5-10 business days)

Reminder notifications before expiry

Automatic decline on timeout (no consent = decline)

Case closure with no-response status

Downstream workflow notified of outcome

# Section 39: Liquidity Orchestration UI

## 39.1 Treasury Liquidity Workspace

Treasury Operations personas have a dedicated workspace with:

Real-time Nostro position grid (all Nostros, all currencies)

Projected position grid (with reservations and expected inflows)

Threshold status indicators per Nostro

Funding request queue (see Section 40)

Active inter-Nostro transfers in progress

Recent transfer history

Counterparty exposure summary (see Section 41)

Scheduled liquidity operations (planned transfers)

Stress test scenarios (see Section 42)

## 39.2 Inter-Nostro Transfer UI

Form-based initiation with mechanism-aware UI:

### 39.2.1 Mechanism Selection

### 39.2.2 Form Fields

Source Nostro (lookup; shows current position)

Target Nostro (lookup; shows current position)

Amount (number)

Currency (auto-populated)

Transfer mechanism (auto-determined from source/target/currency)

Urgency (URGENT, NORMAL)

Rationale (free-text mandatory)

Linked treasury operation (if part of larger plan)

### 39.2.3 Preview Panel

Source position before and after

Target position before and after

Threshold impact (will any threshold be breached?)

FX rate (if FX-mediated)

Estimated cost (fees, FX spread)

Estimated settlement time

Required approvers per amount tier

## 39.3 Drawdown and Sweep Configuration

Treasury Heads configure automatic drawdown and sweep rules:

### 39.3.1 Drawdown Configuration

Per Nostro: low balance threshold trigger

Source priorities (operational pool, investment pool, FX from AED, interbank borrowing)

Maximum auto-execute cap per event

Above cap: manual approval required

Activation hours (24x7 or business hours only)

### 39.3.2 Sweep Configuration

Per Nostro: high balance threshold trigger

End-of-day sweep schedule

Target priorities (interest-earning pool, treasury placement)

Maximum auto-execute cap per event

Activation conditions

## 39.4 Repositioning Workflow UI

For planned repositioning operations spanning multiple Nostros:

Multi-step plan composition (sequence of inter-Nostro transfers)

Pre-flight check showing all impact

Approval routing for the entire plan

Execution sequencing (with rollback option if intermediate step fails)

Progress tracking during execution

Outcome summary post-execution

# Section 40: Funding Request Management UI

## 40.1 Request Sources

Outbound payment workflow (when source Nostro short)

Scheduled funding plan (treasury pre-funding)

Threshold breach auto-trigger

Manual treasury operator request

## 40.2 Request Queue UI

Request ID, source, target

Currency and amount

Urgency (URGENT, HIGH, NORMAL)

Rationale

Originating workflow or user

Request timestamp

Time remaining until urgency-driven SLA breach

Auto-execute eligibility flag

Linked payment workflows that depend on this funding

## 40.3 Auto-Execution Configuration

Treasury Heads configure auto-execution rules:

Per-source enabled (e.g., AED CBUAE pool can auto-fund up to X)

Per-amount caps

Per-urgency caps (URGENT requests may auto-execute higher caps)

Time-of-day restrictions

Above auto-execute caps: manual review required

## 40.4 Manual Review UI

Request detail view with all context

Funding source recommendation from system

Operator can override source selection

Decision: approve, decline, defer

On approve: trigger inter-Nostro transfer workflow (see Section 39)

On decline: notify originating workflow

On defer: schedule for later review

## 40.5 Performance

Auto-execution funding request to transfer initiation: < 5 seconds

Manual urgent funding request to treasury response: < 15 minutes

Manual standard funding request to treasury response: < 60 minutes

# Section 41: Counterparty Exposure Management UI

## 41.1 Exposure Dashboard

Per-correspondent positions (Nostros at foreign banks)

Per-counterparty exposure aggregated across relationships

Per-country exposure

Per-currency exposure

Limit utilization as percentage with visual gauge

Approach to limit alerts (configurable thresholds)

Concentration analytics (top N counterparties)

Trend analysis (last 7, 30, 90 days)

## 41.2 Exposure Limit Management

Risk Heads and Treasury Heads configure limits:

Per-counterparty limit (depository, settlement, lending types)

Per-country limit

Per-currency limit

Per-concentration metric (% of total exposure)

Alert thresholds (warn at X%, hard alert at Y%)

Effective date scheduling

Audit trail of limit changes

Dual approval for limit changes (Risk Head + CRO)

## 41.3 Limit Breach Handling

Approach warning: notify Treasury and Risk; no automatic action

Near-breach: pause new exposure-increasing transactions to this counterparty

Hard breach: hard pause all new exposure; escalate to CRO

Override capability for CRO (with full audit)

## 41.4 Counterparty Detail View

Counterparty 360 (per Section 17.2)

Active relationships (which Nostros, lending, correspondence)

Current exposure breakdown

Limit utilization history

Recent transactions with this counterparty

Past disputes or incidents

Vendor SLA performance

Compliance status (any active investigations)

Documentation (counterparty agreement, KYC)

# Section 42: Stress Testing UI

## 42.1 Pre-Defined Scenarios

## 42.2 Stress Test Execution UI

Scenario selection from library

Parameter customization (severity, duration, scope)

Trigger execution (compute-intensive; runs async)

Progress tracking during execution

Result visualization upon completion

## 42.3 Stress Test Results

Per-Nostro projected positions under scenario

Liquidity gap visualization

Recovery options (which sources could cover the gap)

LCR impact projection

Regulatory reporting impact

Recommended pre-emptive actions

Export results for board/regulatory submission

## 42.4 Scheduled Stress Tests

Schedule periodic stress tests (monthly, quarterly)

Auto-execution and reporting

Trend analysis across periods

Regulatory submission integration

# Section 43: WPS File Operations UI

## 43.1 WPS File Inventory Browser

WPS Operations personas have a dedicated file browser:

All active SIF, PIF, DIF, RFA, RTC, RFR, RRI, RRR, RSU, DCR files

Filter by file type, date, employer, agent bank, status

Per-file detail: file ID, creation timestamp, record count, total value, status

Per-record drill-down within a file

Status indicators (in-flight, completed, failed, partially-failed)

Linked workflows for each file

## 43.2 SIF File Upload UI (Employer Bank Role)

Employer customers (or operations on their behalf) upload SIF files:

File upload widget with format validation

Pre-upload structural check

Pre-upload control total verification

Per-record validation preview

MOHRE compliance preview (potential flagged records)

Employer approval workflow (if customer-initiated)

Bank approval workflow (operations review)

Dispatch confirmation

## 43.3 PIF File Inbound Handling (Agent Bank Role)

Inbound PIF file queue

Per-file processing status

Per-record processing detail (PIFRecord workflow)

Successful credit confirmations

Failed records with reason

DIF generation for successful records

RFA generation for failed records

## 43.4 DIF Generation UI

Pending DIF queue (records ready for confirmation)

Batch DIF composition (multiple records into a single DIF file)

Pre-dispatch review

Dispatch authorization

Dispatch tracking

## 43.5 RFA Generation UI

Pending RFA queue (records returning)

Per-record reason code selection

Batch RFA composition

Pre-dispatch review with reason summaries

Dispatch authorization

## 43.6 Refund Sub-Flow UI

### 43.6.1 RFR Submission (Employer Bank)

Employer-initiated refund request via channel

Operations review and approval

RFR file composition

Dispatch to network

### 43.6.2 RRI Inbound (Agent Bank)

Inbound RRI queue

Critical status check UI: was the original record DISBURSED_VIA_DIF or RETURNED_VIA_RFA?

If RETURNED: auto-reject pathway with RRR Reject

If DISBURSED: consent workflow invoked (see Section 38)

On consent granted: DCR generation BEFORE RRR Accept

On consent declined: RRR Reject with reason

### 43.6.3 DCR Generation UI

DCR queue for records where consent granted and refund accepted

DCR composition with reference to original DIF

Pre-dispatch verification (DCR must precede RRR Accept)

Dispatch authorization

### 43.6.4 RRR Generation UI

RRR queue with accept/reject decisions

RRR composition

Dispatch authorization

### 43.6.5 RSU Inbound (Employer Bank)

Inbound RSU queue

Per-record refund status

Customer/employer notification

## 43.7 Per-Establishment View

Establishment ID and details

Active SIF files for this establishment

Historical SIF outcomes

Employee credit success rate

MOHRE compliance status

Active investigations or holds

## 43.8 MOHRE Compliance Enforcement UI

Compliance status per establishment

Per-record compliance flags

Override capability (with WPS Head + Compliance Head approval)

MOHRE reporting status

MOHRE dispute initiation if applicable

# Section 44: GPI Tracker Detail UI

## 44.1 Per-Payment GPI Timeline

For each correspondent payment with GPI subscription, the console MUST display:

Universal End-to-End Transaction Reference (UETR)

Initiating bank and timestamp

All intermediary banks in chronological order

Each bank's update: received, processing, FX applied, dispatched, credited

Time spent at each bank

Outstanding bank (if payment is currently with that bank)

Total elapsed time vs GPI SLA target

GPI compliance status (within SLA, at risk, breached)

Final credit confirmation with timestamp

## 44.2 GPI Tracker Filters and Search

Search by UETR

Filter by status (in-flight, credited, returned, disputed)

Filter by corridor (sender country → receiver country)

Filter by counterparty bank

Filter by currency

Filter by SLA status

Filter by time range

## 44.3 GPI Subscription Management

Correspondent Operations users can:

Subscribe to a specific payment for status updates

Subscribe to a specific corridor for all GPI events

Receive notifications when payment status changes

Receive alerts when SLA approaches breach

Push subscription to other personas (Treasury, Compliance)

## 44.4 GPI Dispute Initiation UI

Identify payment requiring dispute (delayed, missing, incorrect)

Select dispute type (delay, FX dispute, fee dispute, wrong beneficiary)

Compose dispute narrative

Attach evidence (customer complaint, internal investigation)

Dispatch dispute to upstream/downstream bank via GPI

Track dispute resolution

Update customer with dispute progress

## 44.5 GPI Inbound Status Updates

Inbound GPI events from other banks visible in real-time

Automatic correlation to local workflow

Customer notification triggered on key events (credited at next bank, fully credited)

Audit trail of all received GPI events

## 44.6 GPI Analytics

GPI compliance rate (% of corridor payments meeting SLA)

Average end-to-end latency per corridor

Per-correspondent bank GPI performance

Dispute rate and resolution time

Cost analysis (GPI fees vs benefit)

# Section 45: FX Quote and Treasury UI

## 45.1 FX Rate Board

Treasury FX desk has a live rate board:

Real-time rates for all supported currency pairs

Bid/ask spreads

Rate source (internal book, external providers)

Rate validity windows

Rate freshness indicator

Volatility indicators

Manual rate override capability (with audit)

## 45.2 FX Quote Request Queue

Inbound FX quote requests from payment workflows

Quote ID, requesting workflow, currency pair, amount

Customer or counterparty context

Quote validity required

Auto-quote eligibility (within configured limits)

Manual quote request (above limits) for Treasury Analyst review

## 45.3 Quote Acceptance UI

Quote detail view

Generated rate with margin breakdown

Validity window timer

Customer or counterparty acceptance status

Acceptance confirmation

On accept: trigger FX leg execution

On reject: notify originating workflow

## 45.4 FX Position Management

Real-time net position per currency

Position limits per currency

Approach to limit alerts

Hedging recommendation engine output

Manual hedging instruction (forward, swap, options)

P&L attribution to FX activity

## 45.5 FX Dispute Resolution

FX dispute queue (customer complaints about applied rate)

Investigation workspace with rate audit trail

Rate reconstruction (what rate was applied, what should have been)

Decision: refund difference, decline, partial

Customer communication

Audit trail of FX dispute decisions

## 45.6 FX Health Monitoring

Provider health status

Provider latency monitoring

Rate spread quality monitoring (vs market benchmark)

Failover capability when primary provider unavailable

Provider performance reports

# Section 46: Reconciliation Workspace UI

## 46.1 Break Investigation Workspace

Reconciliation Analysts use this workspace for breaks:

Break list per Nostro with severity ranking

Per-break detail view

Multi-source comparison view (internal ledger / external statement / workflow registry)

Side-by-side comparison with diff highlighting

Possible match suggestions from auto-resolution engine

Manual match capability

Investigation note capability

Linked workflows that may be the missing/mismatched entries

## 46.2 Auto-Resolution Rule Management

Reconciliation Managers configure auto-resolution patterns:

Pattern definition (e.g., split payments, reversal pairs, timing differences)

Activation conditions

Tolerance thresholds (amount rounding, value date variance)

Audit trail of rule activations

Effectiveness metrics (% of breaks auto-resolved)

Rule versioning

## 46.3 Cycle Close UI

Per-rail cycle status (UAEFTS daily, AEP cyclic, IPP, WPS file-cycle, SWIFT per-timezone)

Cycle close countdown

Open breaks count by severity

Breaks rolled over from prior cycles

Cycle close sign-off workflow (Reconciliation Manager → Treasury → Finance)

Sign-off requires all material breaks resolved or documented

Post-sign-off: cycle position frozen for regulatory reporting

## 46.4 Manual Match UI

Side-by-side display of unmatched entries from different sources

Drag-and-drop matching interface

Multi-entry matching (one ledger entry to many statement entries, etc.)

Mandatory rationale for manual matches

Match audit log

Reversal capability for incorrect matches

## 46.5 Break Aging and Escalation

## 46.6 Reconciliation Reporting

Daily break summary by Nostro

Average resolution time trends

Auto-resolution rate trends

Material break rate trends

Per-rail reconciliation cycle compliance

Regulatory reporting (where required)

# Section 47: UFP Register and Cycle UI

## 47.1 UFP Register Browser

Searchable register with indefinite retention

Search by original customer ID, account reference, CBUAE settlement reference, original name, EID, transfer date

Per-entry detail: original customer, original balance, UFP cycle, dispatch reference, status, reclaim history

Cross-cycle queries (entries from multiple UFP cycles)

Export for regulatory submission

RBAC: Branch Ops, Compliance, Internal Audit have read access

## 47.2 UFP Cycle Initiation UI

Annual or per-regulatory-cadence UFP cycle:

Cycle initiation by Operations Head + Compliance Head dual approval

Core Banking provides dormancy eligibility list

Pre-cycle review (list preview, total volume and value)

Approval workflow with Legal sign-off for high-value batches

Cycle execution tracking (per-record progress)

Cycle completion summary

Regulatory report generation

## 47.3 Per-Record Exclusion Management

Records excluded by validation (not dormant, balance mismatch)

Records excluded by sanctions hit (special handling)

Records excluded by manual decision

Each exclusion with rationale

Exclusion review by Compliance

## 47.4 UFP Reclaim Investigation

For complex reclaim cases (succession, dispute, regulatory direction):

Investigation workspace tied to UFP reclaim workflow

Document management for claim evidence (succession docs, court orders)

Multi-party verification (claimant identity, claim authority)

Legal review interface

CBUAE response tracking (long-running)

Outcome decision with rationale

## 47.5 CBUAE Response Tracking

Pending CB101 reclaim requests dispatched to CBUAE

Days elapsed since dispatch

Expected response window per CBUAE rules

Status enquiry trigger if response delayed

On response receipt: automatic workflow continuation

On rejection: investigation and possible re-submission

# Section 48: Incident Command Center UI

## 48.1 Incident Declaration UI

Incident declaration form (Operations Head, CRO, Payments Head can declare)

Incident type (rail outage, scheme issue, fraud incident, compliance issue, infrastructure issue)

Severity classification (P1, P2, P3, P4)

Affected scope (rails, modules, customers, counterparties)

Initial impact assessment

Incident Commander assignment

Bridge call link

## 48.2 Active Incident Command Workspace

Once declared, the Incident Commander has a dedicated workspace:

Incident header: ID, type, severity, declared timestamp, current status

Bridge call integration (one-click join)

Stakeholder roster (currently engaged personas)

Real-time impact metrics (volume affected, customers impacted, revenue at risk)

Active mitigation actions list

Decision log (chronological with attribution)

Communication timeline

Available operational levers (one-click invocation)

Linked workflows being investigated

## 48.3 Operational Lever Invocation from Incident

Within incident context, invoking levers is streamlined:

Pre-populated rationale with incident reference

Co-approvers pre-selected based on incident severity

Bulk action capability (pause multiple rails simultaneously)

Bulk operational cancellation pre-configured with incident scope

## 48.4 Communication Management

Internal broadcast composition and dispatch

Customer communication (proactive notifications)

Regulator communication tracking

Vendor/scheme communication tracking

Communication templates per incident type

Status page update for customers (if external status page enabled)

## 48.5 Incident Resolution

Resolution declaration

Post-incident review trigger

Lever resumption (revert pauses)

Customer recovery actions (re-trigger held payments, communications)

Lessons learned capture

RCA (Root Cause Analysis) report generation

## 48.6 Incident History and Reporting

All incidents archived

Incident frequency analytics

Incident duration analytics

MTTR (Mean Time To Resolve) trending

Per-rail incident rate

Regulatory submission (where required)

# Section 49: Workflow Replay and Forensics UI

## 49.1 Workflow Replay Capability

Internal Audit and senior Operations users can replay any workflow:

Step-through execution event by event

Show exact state at each event

Show configuration active at the time (reference data version, validation profile version)

Show user context at each manual interaction

Show external integration calls and responses

Highlight decision points and outcomes

Time-travel slider for navigating execution timeline

## 49.2 Forensic Query Builder

Build complex queries across audit log

Multi-dimensional filters (user, action, entity, timeframe, rail, module)

Cross-reference queries (find workflows where user X did action Y on entity Z)

Pattern detection (similar action sequences)

Export results for investigation reporting

## 49.3 Cross-Entity Investigation

For complex investigations spanning customers, counterparties, workflows, exceptions over long periods:

Investigation canvas (graph view linking entities)

Add entities to investigation by search

Auto-suggest related entities

Timeline view of all entity activity

Document attachment per investigation

Multi-investigator collaboration

Investigation case management (state, ownership, resolution)

## 49.4 Regulatory Audit Export

Export package for regulatory submissions

Includes: workflow lineage, audit trail, configurations active at the time, supporting documents

Formats: regulator-specific format, generic XBRL, PDF, structured ZIP

Tamper-evident packaging (digital signatures)

Submission tracking

# Section 50: Shift Handover and Team Workload UI

## 50.1 Shift Handover UI

End-of-shift handover form for each operational user

Auto-populated open items in the user's queue

Free-text handover notes (what to watch, ongoing investigations, customer commitments)

Mark items requiring attention from incoming shift

Submission triggers notification to incoming-shift counterpart

Incoming shift acknowledgement

Handover history per user/role

## 50.2 Team Workload Dashboard

For Managers and Heads:

Per-team workload distribution

Per-user workload (open items, average resolution time, recent activity)

Identify overloaded users

Identify underutilized users

Workload rebalancing capability (bulk reassign queue items)

Shift coverage planning

Staff availability calendar integration

## 50.3 Team Performance Metrics

Per-user productivity (items resolved, average time)

Per-user quality (error rate, escalation rate, customer feedback)

Per-team comparison

Trend analysis

Performance review data export

## 50.4 Workload Forecasting

Predicted incoming volume per rail and time-of-day

Staffing recommendations

Peak preparation alerts (e.g., end-of-month WPS processing)

Capacity planning data

# Section 51: Document and Evidence Management UI

## 51.1 Document Upload

Drag-and-drop or click-to-upload

Supported formats: PDF, DOCX, XLSX, images (PNG, JPG), audio, video

File size limits per type (configurable)

Virus scanning before storage

Auto-tagging by document type

Manual tagging capability

Linking to entities (workflow, case, customer, counterparty)

## 51.2 Document Browser

Search across all documents (full-text where extractable)

Filter by type, date, uploader, linked entity

Document preview without download

Download with audit logging

Version history per document

OCR for image-based documents

## 51.3 Evidence Chain of Custody

Cryptographic hash of each document at upload

Tamper-evident storage

Audit log of every access

Document access permissions per case/entity

Restricted distribution capability (some documents view-only, no download)

## 51.4 Document Retention

Retention policies per document type

Standard documents: 10 years

Regulatory documents (UFP, SAR/STR): indefinite

Fraud investigation documents: 10 years post-resolution

Auto-archival to cold storage after configured period

Legal hold capability (prevent deletion during litigation)

# Section 52: Collaboration and Messaging UI

## 52.1 In-Item Comments and Threads

Comment thread per workflow, exception, case

Markdown formatting support

User mentions with notification (@username)

Reply threading

Edit and delete (with audit log)

Comment search across all threads

## 52.2 Secure User-to-User Messaging

For sensitive communications between operations users:

Direct messaging between users (peer-to-peer)

Group conversations (case investigation team, incident response team)

Message encryption at rest

Audit logging of all messages

Compliance review capability (for SAR/STR-related discussions)

Message retention per policy

## 52.3 Case Workspace Collaboration

Multi-user case investigation

Real-time presence indicators (who's currently viewing)

Activity feed showing what others are doing

Lock specific entities while editing (prevent conflicts)

Conflict resolution UI for parallel edits

## 52.4 External Communication Tracking

For communications with external parties (customers, counterparties, regulators):

Communication log per case/customer/counterparty

Channel tracking (email, phone, in-person, regulatory portal)

Communication content reference

Outcome capture

Follow-up reminders

Compliance review of sensitive external communications

# Section 53: Maintenance Window and System Status UI

## 53.1 Maintenance Window Scheduling

Schedule planned maintenance with start/end times

Specify affected systems, rails, or services

Specify expected impact (no-impact, degradation, outage)

Approval workflow (Operations Head + Risk Head for impactful maintenance)

User notification (advance notice to relevant personas)

Customer notification trigger (for external-impacting maintenance)

Maintenance window calendar view

## 53.2 Internal System Status Page

Real-time status of all platform services

Per-rail adapter health

Per-integration health (CBWSI, GPI, FX, MOHRE, etc.)

Active incidents (links to Incident Command)

Active maintenance windows

Recent service events log

Historical uptime metrics

## 53.3 Customer Status Page

For external customers (corporate primarily):

Public status page with customer-relevant services

Active incidents affecting customer flows

Scheduled maintenance

Historical uptime

Subscribe to status updates (email, RSS)

## 53.4 Service Degradation Banners

Console-wide banners when services degraded

Banner with severity color coding

Click for incident detail

User dismissal capability (with reminder)

# Section 54: Webhook and Corporate Integration UI

## 54.1 Corporate Customer Webhook Configuration

Per-corporate-customer webhook endpoint registration

Authentication setup (HMAC signing keys, OAuth2 credentials)

Event subscription configuration (which events trigger webhooks)

Retry policy configuration

Test webhook delivery capability

Webhook health monitoring per customer

## 54.2 Webhook Delivery Queue

Pending webhook deliveries

Failed deliveries with retry status

Permanent failures requiring intervention

Customer endpoint health indicators

Manual retry capability

Delivery success rate per customer

## 54.3 Webhook Audit

Every webhook delivery attempt logged

Payload preservation (with sensitive data masked)

Customer endpoint response captured

Retention per regulatory requirement (7 years for payment-related)

# Section 55: Sandbox and Test Transaction UI

## 55.1 Sandbox Environment Access

Separate sandbox console (functionally identical to production)

Sandbox-only banner for clear identification

Sandbox data isolated from production

Sandbox accounts and counterparties pre-provisioned

Sandbox rail adapters connect to test scheme environments where available, or simulated otherwise

## 55.2 Test Transaction Submission

Test transaction form for each rail

Pre-populated valid test cases

Per-scenario test data (clear path, validation fail, sanctions hit, fraud fail, etc.)

Submission triggers actual platform flow execution

Visualization of flow through all stages

Verification capability (compare expected vs actual outcomes)

## 55.3 Corporate Customer Sandbox

Corporate customers can use sandbox for H2H API integration

Test credentials provided

Webhook test endpoints

Sandbox-specific notifications

Migration path from sandbox to production

## 55.4 API Explorer (Power User Tool)

Interactive API documentation

Try-it-now capability for each API endpoint

Authentication flow demonstration

Sample request/response payloads

Per-API version documentation

Postman/OpenAPI export

# Section 56: Configuration Change History UI

## 56.1 Change History Browser

All configuration changes across all reference data domains

Filter by domain, date, change author

Per-change detail (before/after diff)

Approval chain history

Effective dates

Linked workflows affected by the change

Outcome tracking (did the change cause incidents or improvements?)

## 56.2 Change Diff Visualization

Side-by-side diff for textual configurations

Visual diff for structured data (added/modified/removed)

Inline diff highlighting

Comments on diff (annotation by reviewers)

## 56.3 Rollback Capability

Single-click rollback to prior configuration version

Pre-rollback impact analysis

Approval workflow for rollback (matches original approval workflow)

Audit trail of rollback

Linked incident or rationale for rollback

## 56.4 Configuration Compliance

Periodic configuration review schedule

Stale configuration alerts (haven't been reviewed in X period)

Configuration vs documented standard comparison

Variance reporting for audit

# Part III — Appendices

## Appendix A: Persona to Capability Mapping

This matrix maps each persona to the V1+V2 capabilities they access. Highlight indicates primary capability for that persona.

## Appendix B: Cross-References to Module Specifications

Each V2 section corresponds to functional requirements from specific module specifications:

## Appendix C: Functional Coverage Matrix (Updated)

Maps every platform module to its corresponding UI capability section across V1 and V2:

## Appendix D: UI Component Catalog

Reusable components beyond V1's basic library:

## Appendix E: V2 Gap Closure Audit Trail

This appendix documents the gap analysis methodology and outcomes that drove V2.

### Methodology

Systematic review of every formal module specification

Cross-check each module's documented capabilities against V1 FSD coverage

Identify functionality referenced in modules but missing or insufficient in V1

Categorize gaps by domain and persona impact

Prioritize gap closure

Author V2 sections addressing each identified gap

### Gap Analysis Outcomes

### Total Sections

V1 specified 30 sections covering foundational console functionality. V2 adds 26 sections closing identified gaps. Total: 56 sections of functional specification.

# Document Conclusion

This V2 Functional Specification provides comprehensive coverage of every user-facing capability the Operations Console must deliver, with explicit gap closure addressing 26 functional domains identified through systematic cross-checking against the platform's formal module specifications.

The document is organized to enable both linear reading (V1 sections 1-30 cover foundational structure; V2 sections 31-56 add specialized depth) and reference lookup (Appendix B cross-references each section to its source modules; Appendix C provides functional coverage matrix; Appendix E documents the gap closure audit trail).

The Operations Console as specified in V2 delivers on the architectural promise: a unified operational interface across all rails, all personas, all flows, with comprehensive functional coverage built on the same 21 core platform modules through configuration overlays without introducing new core engines.

# Part IV — V3 Additions: Operational Practice Gaps

Sections 57 through 74 close functional gaps identified through a second-pass review, examining the platform from operational practice rather than module-by-module. These sections cover customer service, counterparty lifecycle, batch operations, governance, risk, settlement specifics, regulatory submissions, data quality, capacity, investigations, contracts, and configuration management.

# Section 57: Customer Onboarding to Payment Services UI

## 57.1 Beneficiary Management at Scale

For corporate customers with large beneficiary lists, the console MUST provide operations support:

Bulk beneficiary upload from corporate customer (CSV, Excel, structured file)

Beneficiary validation against participant directories

Confirmation of Payee verification batch run

Beneficiary template creation for recurring use

Beneficiary categorization (vendor, employee, related party, regulator)

Beneficiary risk scoring with operations review

Approval workflow for new high-risk beneficiaries

Beneficiary status tracking (active, pending verification, blocked)

Bulk beneficiary update and deactivation

## 57.2 Customer Channel Enablement

Per-customer channel activation (H2H API, portal, mobile, branch)

Channel-specific credentials provisioning

Channel testing UI before production cutover

Channel-specific rate limits and quotas configuration

Channel deactivation with run-off period

## 57.3 Mandate Setup for Direct Debits

For direct debit and recurring payment authorization (future-state):

Mandate creation form with payer details, payee details, amount, frequency, validity period

Mandate authentication (customer signature, digital signature, SCA)

Mandate registration with scheme (where applicable)

Mandate amendment workflow

Mandate cancellation workflow with customer notification

Mandate dispute resolution

## 57.4 Onboarding Audit Trail

Every onboarding step audit-logged

Documentary evidence linked

Approval chain captured

Effective dates tracked

Compliance review per regulatory requirements

# Section 58: Customer Service Desk Integration UI

## 58.1 Customer Service Workspace

For customer service representatives:

Customer authentication and identification

Customer 360 view with cross-rail activity

Recent payment summary (last 30 days, with status indicators)

Payment trace request (one-click investigation initiation)

Linked communication history

Active complaints and cases

Known issues affecting this customer

Action capability (cancel pending payment, raise complaint, initiate trace) within authority

## 58.2 Payment Trace Request

Customer enquiry capture (payment reference, amount, date)

Auto-correlation to payment workflow

Status retrieval with customer-friendly explanation

Detailed trace for cross-border (with GPI tracker integration)

Estimated time-to-resolution for in-flight payments

Manual investigation request if auto-trace insufficient

Customer notification of investigation outcome

## 58.3 Customer Complaint Lifecycle

Beyond fraud reimbursement (Section 37), general complaints lifecycle:

## 58.4 Complaint Categories

Payment delay or non-execution

Incorrect amount or currency

Wrong beneficiary

Fee or charge dispute

FX rate dispute

Service quality (call wait time, branch experience)

Channel issue (portal/app malfunction)

Privacy concern

Compliance / sanctions impact (legitimate transaction blocked)

Other regulatory concern

## 58.5 Customer Holds and Restrictions

Apply outbound restriction (block customer from initiating)

Apply inbound restriction (block credits to this customer)

Account freeze (full operational hold)

Channel-specific restrictions

Beneficiary-specific restrictions (whitelist mode)

Amount-specific restrictions (cap per transaction or daily)

Time-bound restrictions (auto-expire)

Restriction rationale (mandatory)

Approval chain per restriction type

Restriction lift workflow

# Section 59: Counterparty Lifecycle Management UI

## 59.1 New Counterparty Onboarding

Counterparty information capture (BIC, name, legal entity, country)

Counterparty KYC documentation upload

Compliance review workflow

Sanctions screening on counterparty and its UBOs

Counterparty risk assessment

Agreement template selection (correspondent, lending, depository)

Agreement negotiation tracking

Agreement execution (signed copies uploaded)

Operational setup: Nostro account opening, certificate exchange, RMA establishment

Test transaction execution

Go-live approval (Operations Head + Compliance Head + Risk Head)

## 59.2 Counterparty Agreement Management

Agreement document repository per counterparty

Version history with effective dates

Key terms summary (fees, SLAs, restrictions, governance)

Renewal alerts (90, 60, 30 days before expiry)

Amendment workflow with internal and counterparty approvals

Linked operational settings (the agreement drives certain configurations)

Per-agreement audit trail

## 59.3 Counterparty SLA Management

SLA definitions per counterparty (latency, availability, response time)

Real-time SLA monitoring

Breach detection and alerts

Breach documentation

Breach escalation per agreement terms

SLA performance reporting (monthly, quarterly)

SLA renegotiation tracking

## 59.4 Counterparty Offboarding

Offboarding initiation by Operations Head or Risk Head

Rationale documentation (regulatory, commercial, performance, risk)

Customer impact assessment

Run-off period planning (typical 30-90 days)

Customer migration support (alternative counterparties identified)

Outstanding transaction wind-down

Nostro closure procedures

Final reconciliation

Document retention compliance

Counterparty notification per agreement

## 59.5 Counterparty Performance Reporting

Per-counterparty volume and value

Per-counterparty exception rate

Per-counterparty SLA compliance

Per-counterparty dispute rate

Counterparty rankings

Trend analysis

# Section 60: Batch Job and Scheduled Operations UI

## 60.1 Scheduled Job Inventory

## 60.2 Job Status Dashboard

Real-time status of all scheduled jobs

Last successful run timestamp

Next scheduled run

Job duration trending

Failure history

Dependencies (which jobs depend on this job's completion)

Alerts for delayed or failed jobs

## 60.3 Job Manual Trigger

Manual trigger capability for authorized personas

Rationale required

Pre-flight check before execution

Approval workflow for impactful jobs

Execution monitoring

Audit log of manual triggers

## 60.4 Job Retry and Recovery

Failed job retry capability with retry count tracking

Partial-success recovery (continue from last successful checkpoint)

Manual intervention UI for complex failures

Escalation to engineering for systematic failures

Post-recovery validation

## 60.5 Job Schedule Configuration

Configurable schedules (cron-based or time-based)

Schedule change workflow (approval required)

Holiday calendar integration (skip on holidays)

Timezone configuration

Run-once vs recurring options

# Section 61: Workflow Priority and Stuck Workflow Recovery UI

## 61.1 Workflow Priority Management

Priority override capability (jump-the-queue for urgent items)

Authority-based (operational managers and above)

Rationale required for priority elevation

Audit logging of all priority changes

Impact analysis (what gets de-prioritized as a result)

Time-bounded priority (auto-revert after configured time)

## 61.2 Stuck Workflow Detection

The console MUST detect and surface workflows that appear stuck:

Workflows in same state longer than expected per workflow type

Workflows with no recent activity vs expected SLA

Workflows awaiting external response longer than expected

Workflows with cyclical state transitions

Workflows with repeated retry failures

## 61.3 Stuck Workflow Investigation Workspace

Stuck workflow detail with full state history

Most recent activity timestamp and what happened

External dependencies status

Reference data version at time of stuck event

Configuration overlay active

Similar past stuck workflows for pattern analysis

Suggested recovery actions

## 61.4 Recovery Actions

## 61.5 Workflow Cancellation

Distinct from payment cancellation (which acts on the payment); workflow cancellation acts on the workflow execution itself:

Used when workflow is buggy or cannot proceed

Compensating actions automatically triggered (reverse any postings, notify customer, etc.)

Authority: Operations Manager + Engineering Head

Rationale mandatory

Full audit logging

# Section 62: Operational Governance UI

## 62.1 Procedure Manual Integration

Every operational action has a linked procedure document

One-click access to procedure from action context

Procedure versioning with effective dates

Procedure search across the console

Procedure update notifications when actions involve recently-changed procedures

Procedure exception logging (when user deviates from procedure with rationale)

## 62.2 Policy Acknowledgement

New policy publication workflow (Compliance Head + Operations Head)

Mandatory user acknowledgement before continuing work

Acknowledgement tracking per user

Re-acknowledgement on material policy changes

Non-acknowledgement escalation

Audit trail of all acknowledgements

## 62.3 Training and Certification Tracking

Per-persona training curriculum

Training completion tracking

Certification expiry alerts

Mandatory re-certification cycles

Training records as part of audit

New persona training prerequisite verification

Refresher training scheduling

## 62.4 Privilege Review Cycles

Periodic re-attestation of user permissions per regulatory requirements:

Quarterly privilege review for high-stakes personas

Annual privilege review for all personas

Per-review: each manager re-attests their team's privileges

Privilege change recommendations

Privilege change workflow with HR + Operations Head approval

Review completion tracking

Regulatory submission of attestation reports

## 62.5 Vendor and Temporary Access Management

Vendor user provisioning workflow (Engineering + Vendor Manager + Security approval)

Time-bounded vendor access (auto-expire)

Scope-limited vendor access (only specific modules/data)

Vendor activity audit with elevated scrutiny

Vendor access termination workflow

Temporary access for incident response (with auto-expire)

## 62.6 Segregation of Duties Verification

Real-time SoD conflict detection (user about to perform conflicting roles)

Block on conflict with rationale capability for exceptional cases

Periodic SoD audit reports

Manager attestation of SoD compliance

Regulatory submission as required

# Section 63: Risk Operational Dashboards UI

## 63.1 Per-Channel Risk Dashboard

Per-channel fraud rate (mobile, portal, H2H, branch)

Per-channel exception rate

Per-channel customer dispute rate

Channel-specific anomalies

Channel security event correlation

Trend analysis per channel

## 63.2 Velocity Monitoring

Per-customer velocity (transaction count over time)

Per-counterparty velocity

Per-channel velocity

Per-corridor velocity (cross-border)

Anomaly thresholds per dimension

Velocity breach alerts

Investigation workspace for velocity anomalies

## 63.3 Operational Anomaly Detection Dashboard

Distinct from fraud — operational anomalies that may indicate technical or process issues:

Unusual processing latency

Unusual exception clustering

Unusual approval patterns (e.g., rapid sequential approvals by same user)

Unusual configuration changes

Unusual data quality issues

Pattern alerts with investigation workspace

## 63.4 Risk Appetite Tracking

Defined risk appetite metrics (per CRO governance)

Real-time tracking against appetite

Breach alerts with severity classification

Quarterly risk appetite review preparation

Risk appetite override approval workflow (CRO + Board)

Historical appetite vs actual reporting

## 63.5 Concentration Risk

Customer concentration (% of total volume from top customers)

Counterparty concentration

Geographic concentration

Currency concentration

Channel concentration

Trend analysis and alerts on rising concentrations

# Section 64: Settlement-Specific UI

## 64.1 Pre-Settlement Window Preparation

Before each scheme settlement window (UAEFTS cycles, AEP cycles, etc.):

Real-time projected net position for the upcoming settlement

Pending obligations summary

Liquidity assessment (will we settle without intervention)

Recommended pre-settlement actions

Treasury pre-funding triggers

Settlement readiness checklist

Stakeholder notifications

## 64.2 Real-Time Settlement Queue Monitoring

Items lined up for next settlement window

Per-rail count and value

Items at risk of missing the window

Auto-escalation for at-risk items

Manual intervention capability

Settlement window countdown clock

## 64.3 Post-Settlement Validation

After settlement window closes:

Settlement confirmation receipt from scheme

Reconciliation of expected vs actual settlement

Per-item settlement status verification

Failed settlement identification

Net settlement vs gross settlement reconciliation

Post-settlement reporting

## 64.4 Failed Settlement Recovery

Failed settlement queue

Per-failure root cause analysis

Recovery options per failure type

Customer impact assessment

Scheme dispute initiation if needed

Resubmission in next window with appropriate handling

## 64.5 Net Settlement Position Calculator

Real-time net position computation per rail

Net debit/credit projection

Required pre-funding computation

What-if scenario analysis (if I add this payment, what happens to net position)

End-of-cycle position lock for reporting

# Section 65: Regulatory Submission Calendar and Workflow UI

## 65.1 Regulatory Submission Calendar

All regulatory submissions due (with regulator, frequency, deadline)

Calendar view (monthly, quarterly, annually)

Per-submission preparation timeline

Status of each upcoming submission

Overdue submission alerts

Submission ownership per regulator and report type

## 65.2 Submission Inventory

## 65.3 Submission Preparation Workflow

Submission initiation per calendar trigger

Data gathering from platform (automated where possible)

Data quality verification

Draft report generation

Internal review workflow (per submission type)

Senior approval workflow

Regulator submission via prescribed channel (web portal, file upload, API)

Acknowledgement capture

Submission archive with full audit trail

## 65.4 Submission History

All past submissions queryable

Per-submission detail: content, approver, submission timestamp, regulator response

Regulator feedback tracking

Re-submission tracking for corrections

Long-term retention per regulatory requirement

## 65.5 Regulator Inquiry Response

For ad-hoc regulator inquiries:

Inquiry intake (from regulator email, letter, portal)

Inquiry assignment to responsible team

Response preparation workspace

Documentation gathering across platform

Forensic query support (per Section 49)

Response draft and internal review

Senior approval before dispatch

Response dispatch tracking

Follow-up response cycle support

## 65.6 Internal Management Committee Reports

Internal committee report preparation (ALCO, ORCO, executive committee)

Pre-defined templates per committee

Data aggregation from platform

Distribution to committee members

Committee response capture

Action item tracking

# Section 66: Data Quality Management UI

## 66.1 Data Quality Dashboard

Master data freshness indicators (when was each source last refreshed)

Master data completeness metrics (% of records with mandatory fields)

Master data consistency metrics (cross-source agreement)

Per-domain quality scores

Quality trend over time

Alert on quality degradation

## 66.2 Discrepancy Resolution

When master data sources disagree:

Discrepancy detection across sources

Discrepancy queue with severity classification

Comparison view of conflicting values

Investigation tools (which source is authoritative for this field)

Resolution decision (which value to use, or escalate to data steward)

Linked downstream impact (which workflows used the disputed data)

Audit log of resolutions

## 66.3 Customer Data Correction Workflow

Customer data correction request capture

Source of correction (customer request, ops observation, regulator)

Current vs proposed values display

Impact analysis (which workflows would be affected)

Compliance review (some changes need EDD)

Approval workflow

Effective date scheduling

Downstream propagation tracking

Customer notification of changes

## 66.4 Counterparty Data Correction Workflow

Similar workflow for counterparty data corrections with appropriate authority and audit.

## 66.5 Data Quality Reporting

Daily data quality summary

Per-domain quality trends

Per-source reliability metrics

Quality SLA tracking

Regulatory submission of data quality metrics where required

# Section 67: Capacity and Performance Operational UI

## 67.1 Backlog Management Dashboard

Queue depth across all queues

Backlog trending (last 1h, 24h, 7d)

Backlog projection (will queues clear at current processing rate?)

Per-queue SLA breach risk

Resource allocation suggestions

Auto-escalation when backlog crosses thresholds

## 67.2 Throughput Capacity Planning

Current throughput per rail and queue

Maximum sustained throughput (capacity)

Headroom analysis

Per-resource utilization (worker pools, API gateways, databases)

Scaling recommendations

Forecasted demand vs capacity

## 67.3 SLA Breach Root Cause Analysis

Per-breach detailed analysis

Contributing factors identification (queue wait, processing time, external delay)

Pattern detection across breaches

Systematic vs episodic classification

Remediation recommendation

Trend tracking of breaches

## 67.4 Queue Aging Analytics

Per-queue age distribution

Aging trends

Oldest items across all queues

Aging by item type

Aging by assignee (identify users with stale items)

Auto-escalation triggers based on aging

## 67.5 Predictive Operations

Volume forecasting per rail (next hour, next day)

Exception rate forecasting

Staffing requirements forecasting

Peak preparation recommendations

Anomaly forecasting (when conditions suggest upcoming issues)

# Section 68: Payment Trace and Investigation UI

## 68.1 Payment Trace Request Lifecycle

## 68.2 Investigation Workspace

Investigation ID, requester, subject payment

Customer 360 with payment context

Workflow trace (per Section 49 replay capability)

GPI tracker timeline (for cross-border, per Section 44)

External inquiry tracking (sent enquiries, received responses)

Document attachments (customer documentation, inter-bank correspondence)

Investigation notes

Multiple investigator coordination

Resolution decision panel

## 68.3 Inter-Bank Investigation Coordination

Outbound enquiry dispatch via appropriate rail (CB195, MT195, camt.027)

Inbound enquiry queue from other banks

Response tracking

Long-running investigation handling

Multi-bank investigation chains (for cross-border)

Investigation timeline visualization

## 68.4 Legal Hold Management

When transactions are placed on legal hold for litigation or regulatory proceedings:

Legal hold initiation by Legal Counsel

Hold scope specification (transactions, customers, time periods)

Document retention extension automatically applied

Hold visibility across the platform

Hold release workflow

Hold reporting for compliance

# Section 69: Service Catalog and Contract Management UI

## 69.1 Service Catalog

Master catalog of all payment services offered

Per-service capabilities and limitations

Per-service pricing (standard and tiered)

Per-service SLA

Service interdependencies

Service deprecation schedule

## 69.2 Customer Service Subscriptions

Per-customer service subscription matrix

Subscription effective dates

Customer-specific variations (negotiated terms)

Subscription change workflow

Subscription history

## 69.3 Customer Fee Schedule Management

Per-customer fee schedule (different from standard)

Fee schedule version control

Effective date scheduling

Approval workflow for fee changes

Fee calculation testing UI

Customer notification of fee changes

## 69.4 Per-Customer Contract Terms Reflection

Many customer-specific terms drive platform behavior:

Per-customer cutoff times

Per-customer transaction limits

Per-customer approval thresholds

Per-customer channel preferences

Per-customer notification preferences

Per-customer language preferences

Per-customer reporting cadence

## 69.5 Contract Renewal and Amendment

Renewal alerts (90, 60, 30 days)

Amendment proposal workflow

Customer acceptance tracking

Linked operational settings update

Amendment audit trail

# Section 70: Configuration Overlay Management UI

## 70.1 Configuration Overlay Browser

All configuration overlays per flow/module/rail

Currently active overlay per scope

Overlay layer visualization (base + overlays applied)

Effective resolution: for any given flow, show the effective configuration after all overlay merging

Overlay version history

Linked workflow templates and validation profiles

## 70.2 Overlay Impact Analysis

Pre-change impact analysis: if I modify this overlay, which flows are affected?

Visual flow-to-overlay dependency graph

Affected workflow count

Affected customer count

Affected transaction volume estimate

## 70.3 Per-Customer Configuration Variation

For multi-tenant or customer-specific configurations:

Per-customer overlay specification

Effective configuration view per customer

Variation rationale documentation

Approval workflow for customer-specific variations

Variation audit trail

## 70.4 Overlay Testing

Sandbox testing of overlay changes

Test transaction submission with new overlay

Before/after comparison

Validation profile testing

Pre-production verification before activation

## 70.5 Overlay Activation

Scheduled activation (effective date in future)

Pre-activation impact summary

Approval workflow

Activation execution with rollback capability

Post-activation monitoring

Auto-rollback triggers if anomalies detected

# Section 71: Broadcast and Communication Center UI

## 71.1 Communication Composition

Compose targeted broadcast (specific personas, customers, or all)

Multi-channel selection (in-app, email, SMS, push)

Template library for common communications

Localization support (English, Arabic, others)

Preview before dispatch

Approval workflow per communication type

## 71.2 Communication Tracking

Sent communications log

Delivery status per recipient (delivered, failed, opened, acknowledged)

Bounce rate tracking

Response tracking (for communications requiring acknowledgement)

Audit trail per communication

## 71.3 Targeted Customer Communications

Beyond transactional notifications:

Service announcements

Maintenance notifications

Policy changes

Regulatory communications

Marketing (subject to consent)

Compliance-driven communications (e.g., AML notice)

## 71.4 Communication Preferences

Per-customer preferences (channels, frequency, opt-outs)

Per-customer language

Per-customer DND windows

Compliance-driven mandatory communications (cannot be opted out)

Preference change audit

# Section 72: License and Entitlement Management UI

## 72.1 License Inventory

All vendor licenses (sanctions vendors, KYC providers, FX providers)

License expiry tracking

License utilization (current usage vs licensed capacity)

License cost tracking

License renewal alerts

License change workflow

## 72.2 Scheme Entitlements

UAEFTS participation status and capabilities

AEP IPI participation status and capabilities

IPP participation status

WPS participation status

SWIFT membership status

Per-scheme entitlement audit

## 72.3 Entitlement Audit

Periodic verification that platform usage matches entitlements

Excess usage alerts

Underutilization analysis

Cost optimization recommendations

# Section 73: Knowledge Management UI

## 73.1 Knowledge Base

Operational knowledge articles (how to handle X situation)

Exception code resolution guides

Customer scenario playbooks

Incident response playbooks

Regulator inquiry response templates

Search across knowledge base

## 73.2 Resolution Pattern Capture

Auto-suggest knowledge articles based on context

Capture novel resolution patterns from operators

Promote successful patterns to knowledge base after review

Pattern effectiveness tracking

Knowledge article versioning

## 73.3 FAQs and Customer Support Articles

Customer-facing FAQ management

Internal FAQ for operations

Translation management

FAQ effectiveness tracking

Update workflow

## 73.4 Onboarding Documentation

New persona onboarding materials

Procedure quick-reference cards

Walkthrough recordings

Mentor assignments

Onboarding checklist tracking

# Section 74: Business Continuity and DR Operational UI

## 74.1 BCP/DR Plan Repository

Active business continuity plans

Active disaster recovery plans

Per-scenario runbooks

RTO and RPO targets per scenario

Last test date and outcome

Plan version control

## 74.2 DR Test Execution UI

Scheduled DR test calendar

Test scenario selection

Test execution coordination workspace

Per-step test result capture

Issue identification during test

Post-test review and report

Regulatory submission of DR test results

## 74.3 Failover Initiation UI

Authority: CRO + CFO + CEO for full enterprise failover; lower thresholds for partial failover.

Failover scenario selection

Pre-failover checklist verification

Failover initiation with full re-authentication

Failover execution monitoring

Per-system failover status

Customer communication automation

Failback planning workspace

## 74.4 Site Health Monitoring

Primary site health indicators

Secondary site health indicators

Data replication lag monitoring

Failover readiness assessment

Drift detection between sites

## 74.5 Communication during BCP/DR

Internal cascade notifications

Customer notifications via all channels

Regulator notification per requirements

Vendor coordination

Media management workflow (PR)

# Document Conclusion

This V3 Functional Specification provides the most comprehensive coverage of the Operations Console available to date. Across 74 sections, it specifies:

Part I (Sections 1-30): foundational console structure — personas, navigation, dashboards, queues, detail views, reports, approvals, exceptions, per-rail surfaces, notifications, search, personalization, audit, mobile/desktop variants, accessibility, performance, security, errors, help, internationalization.

Part II (Sections 31-56): module-aligned operational UI — Reference Data Admin, Operational Levers, Compliance/Fraud/Sanctions/SAR Cases, Reimbursement, Beneficiary Consent, Liquidity Orchestration, Funding Requests, Counterparty Exposure, Stress Testing, WPS File Operations, GPI Tracker Detail, FX Treasury, Reconciliation Workspace, UFP Register, Incident Command, Workflow Forensics, Shift Handover, Documents, Collaboration, Maintenance, Webhooks, Sandbox, Configuration Change History.

Part III: V1+V2 Appendices.

Part IV (Sections 57-74): operational practice domains — Customer Onboarding, Customer Service Desk, Counterparty Lifecycle, Batch Jobs and Scheduled Operations, Workflow Priority and Stuck Workflow Recovery, Operational Governance (policies, training, privilege review, SoD), Risk Operational Dashboards, Settlement-Specific UI, Regulatory Submission Calendar, Data Quality Management, Capacity and Performance, Payment Trace and Investigation, Service Catalog and Contracts, Configuration Overlay Management, Broadcast Communication Center, License and Entitlement Management, Knowledge Management, Business Continuity and DR.

The document is organized to enable both linear reading and reference lookup. Cross-references throughout link to related sections and external module specifications.

The Operations Console as specified delivers the architectural promise comprehensively: a unified operational interface across all rails, all personas, all flows, with audit-verified functional completeness built on the same 21 core platform modules through configuration overlays — without introducing new core engines.

This is the operational heartbeat of the Payment Hub Platform.

| Document Title | Operations Console — Detailed Functional Specification (V2) |
| --- | --- |
| Version | 2.0 — Comprehensive coverage with gap closure |
| Type | Functional Specification — User Interface |
| Audience | UX Designers, Frontend Engineers, Backend API Engineers, Operations Leadership, QA, Internal Audit, Vendor UI/UX partners |
| Scope | All user-facing functionality of the unified Operations Console across web, mobile, and desktop. V2 adds previously-missing functional domains identified through systematic cross-checking against all formal module specifications. |
| Builds Upon | Operations Console Design module; Integration Catalog; all 22 formal module specifications; Cross-Module Alignment Audit (Refreshed) |
| Status | Final V2 — Audit-Verified Coverage |
| V2 Additions Summary | 26 new functional domains addressing gaps in Reference Data administration, Operational Control levers, Compliance and Fraud case management, Liquidity Orchestration, WPS file operations, GPI tracker detail, Reconciliation workspace, Incident command, and supporting capabilities. |

| New Section | Functional Domain | Resolves Gap From |
| --- | --- | --- |
| 31 | Reference Data Administration UI | Reference Data Management module |
| 32 | Operational Control Levers UI | Operational Control module |
| 33 | Compliance Case Management UI | Compliance module |
| 34 | Fraud Case Management UI | Fraud Detection module |
| 35 | Sanctions Hit Adjudication UI | Screening Orchestrator |
| 36 | SAR/STR Workflow UI | Compliance module |
| 37 | Reimbursement Assessment UI | Recalls / Fraud modules |
| 38 | Beneficiary Consent Workflow UI | Recalls / WPS Refund modules |
| 39 | Liquidity Orchestration UI | Nostro Management module |
| 40 | Funding Request Management UI | Nostro Management module |
| 41 | Counterparty Exposure Management UI | Nostro Management module |
| 42 | Stress Testing UI | Nostro Management module |
| 43 | WPS File Operations UI | WPS Employer Bank / Agent Bank modules |
| 44 | GPI Tracker Detail UI | Correspondent Banking modules |
| 45 | FX Quote and Treasury UI | FX Service integration |
| 46 | Reconciliation Workspace UI | Reconciliation Engine module |
| 47 | UFP Register and Cycle UI | UFP module |
| 48 | Incident Command Center UI | Operations Console / cross-cutting |
| 49 | Workflow Replay and Forensics UI | Audit & Monitoring module |
| 50 | Shift Handover and Team Workload UI | Operations Console / cross-cutting |
| 51 | Document and Evidence Management UI | Cross-cutting |
| 52 | Collaboration and Messaging UI | Cross-cutting |
| 53 | Maintenance Window and System Status UI | Operations Console / cross-cutting |
| 54 | Webhook and Corporate Integration UI | Notification / Integration Catalog |
| 55 | Sandbox and Test Transaction UI | Cross-cutting |
| 56 | Configuration Change History UI | Reference Data Management |

| Persona ID | Persona Name | Primary Domain | Authority Tier |
| --- | --- | --- | --- |
| PAY-OPS-L1 | Payments Operations Analyst (L1) | Payments Operations | Operational |
| PAY-OPS-L2 | Payments Operations Manager (L2) | Payments Operations | Manager |
| PAY-OPS-HEAD | Payments Operations Head | Payments Operations | Executive |
| TRE-OPS-AN | Treasury Operations Analyst | Treasury Operations | Operational |
| TRE-OPS-MG | Treasury Operations Manager | Treasury Operations | Manager |
| TRE-HEAD | Treasurer | Treasury Operations | Executive |
| CFO | Chief Financial Officer | Treasury / Finance | C-Suite |
| COMP-OFF | Compliance Officer | Compliance | Operational |
| COMP-MG | Compliance Manager | Compliance | Manager |
| COMP-HEAD | Compliance Head | Compliance | Executive |
| FRD-OPS-AN | Fraud Operations Analyst | Fraud Operations | Operational |
| FRD-OPS-MG | Fraud Operations Manager | Fraud Operations | Manager |
| REC-AN | Reconciliation Analyst | Reconciliation Operations | Operational |
| REC-MG | Reconciliation Manager | Reconciliation Operations | Manager |
| BR-OPS | Branch Operations Officer | Branch Operations | Operational |
| CORR-OPS | Correspondent Operations Officer | Correspondent Banking | Operational |
| WPS-OPS-AN | WPS Operations Analyst | WPS Operations | Operational |
| WPS-OPS-MG | WPS Operations Manager | WPS Operations | Manager |
| SR-MGT | Senior Management | Executive | C-Suite |
| INT-AUD | Internal Audit User | Internal Audit | Read-Only Audit |
| RISK-MG | Risk Management User | Risk Management | Manager |
| FIN-USR | Finance User | Finance | Operational |
| CRO | Chief Risk Officer | Risk Management | C-Suite |

| Tier | Description | Examples |
| --- | --- | --- |
| Operational | Day-to-day work; standard approvals within tier limits | Routine queue items, standard ops actions |
| Manager | Supervisory authority; mid-tier approvals; escalations | Approve mid-value transactions, override standard rules |
| Executive | Department-level authority; high-tier approvals; pause levers | Pause rail processing, approve high-value, incident command |
| C-Suite | Enterprise-level authority; emergency authority; board-level decisions | Emergency funding, regulatory submissions, strategic decisions |
| Read-Only Audit | View-only access; no actions; comprehensive query capabilities | Audit trail queries, report generation, no state changes |

| Component | Description |
| --- | --- |
| Card | Discrete content tile with header, body, optional footer; KPIs, summaries, alerts |
| Table | Tabular data with sorting, filtering, pagination, column customization, row selection, bulk actions |
| Chart | Visual data display: line, bar, pie, donut, area, scatter, gauge |
| Timeline | Event chronology display with zoom and filter |
| Tree | Hierarchical data display with expand/collapse |
| Form | Input form for data entry with validation |
| Wizard | Multi-step form for complex flows |
| Modal | Overlay dialog for focused interaction |
| Drawer | Side panel for additional context without leaving current view |
| Tabs | Multiple sub-views within a panel |
| Accordion | Collapsible sections within a panel |

| Element | Position | Behavior |
| --- | --- | --- |
| Bank logo | Left | Click returns to default workspace |
| Application name | Left of center | Static |
| Global search | Center | Always accessible; Ctrl+K |
| Rail switcher | Right of center | Quick switch between rail-specific views |
| Notifications icon | Right | Badge shows unread count |
| User profile | Far right | Photo, name, current persona |
| Persona switcher | Within profile dropdown | For multi-persona users |
| Help icon | Right (next to profile) | Opens help panel |
| Settings icon | Right (next to help) | Opens settings panel |

| Section | Sub-Items |
| --- | --- |
| HOME | My Workspace, My Approvals, My Tasks, Recent Activity |
| OPERATIONAL > Payment Flows | Outbound Customer, Inbound Customer, Bank-to-Bank, Cross-Border (SWIFT), Regulatory |
| OPERATIONAL > Non-Financial Transactions | Enquiries, Returns and Reversals, Recalls, Cancellations |
| OPERATIONAL > WPS Domain | Files Lifecycle, Records Lifecycle, Refund Sub-Flow, Compliance Status |
| OPERATIONAL > Special Authority | UFP, Pension Payments (GPSSA), Federal Tax Payments (FTA) |
| QUEUES | My Queue, Team Queues, Exception Queue, Approval Queue, Investigation Queue |
| DASHBOARDS | Live Operations, Per-Rail, Cross-Rail, Counterparty Exposure, Nostro Positions, Custom |
| REPORTS | Operational, Regulatory, Executive, Custom, Scheduled |
| ADMINISTRATION | User Management, Roles and Permissions, Reference Data, Notification Templates, Workflow Configuration, System Health |

| Real-time dashboards | 1 second |
| --- | --- |
| Operational dashboards | 5 seconds |
| Regulatory dashboards | 60 seconds |
| Executive dashboards | 5 minutes |

| Column | Description | Default Visibility |
| --- | --- | --- |
| Item ID / Reference | Unique identifier | Visible |
| Type | Item type | Visible |
| Subtype | More specific categorization | Visible |
| Amount / Value | Where applicable | Visible |
| Currency | Where applicable | Visible |
| Customer / Counterparty | Where applicable | Visible |
| Rail | UAEFTS, IPI, IPP, WPS, SWIFT | Visible |
| Status / State | Current lifecycle state | Visible |
| Priority | URGENT, HIGH, NORMAL, LOW | Visible |
| Age | Time since item entered queue | Visible |
| SLA Status | OK, AT RISK, BREACHED | Visible |
| Assigned To | User or team | Visible (manager view) |
| Originator | User who triggered | Hidden by default |
| Reason | Free-text rationale | Hidden by default |

| Tab | Content |
| --- | --- |
| Overview | Full payment/item context, all fields |
| Workflow | Visual workflow diagram with current state |
| Activity | Chronological event log |
| Validation | Validation outcomes |
| Screening | Sanctions, PEP, adverse media outcomes |
| Fraud | Fraud check outcomes, model scores |
| Approval | Approval chain history |
| Exceptions | Linked exceptions |
| Reconciliation | Reconciliation status and matches |
| Audit Trail | Complete immutable audit log |
| Documents | Linked documents and attachments |
| Comments | Comment thread |

| Form | Persona | Key Sections |
| --- | --- | --- |
| Treasury CB202 | Treasury Ops Analyst | Payment Detail, Treasury Context, Validation, Approval Routing |
| Operational Cancellation | Payments Ops Analyst | Subject Payment, Cancellation Reason, Routing Preview |
| UFP Reclaim | Branch Ops Officer | Original UFP Lookup, Claim Context, Internal Approval |
| Bulk Operational Cancellation | Incident Commander | Incident Context, Cancellation Criteria, Preview, Authorization |
| Inter-Nostro Transfer | Treasury Ops Analyst | Transfer Detail, Preview, Approval |
| Operational Recall | Payments Ops Analyst | Subject Payment, Recall Reason, Beneficiary Consent |
| Operational Return | Payments Ops Analyst | Subject Payment, Return Reason, Posting |
| Enquiry Outbound | Payments Ops Analyst | Subject Payment, Enquiry Detail, Recipient |

| Action | Behavior |
| --- | --- |
| Approve | Confirm dialog → record → propagate → update queue |
| Reject | Reason dialog (mandatory) → confirm → record → propagate |
| Escalate | Target selection → rationale → route to next level |
| Request More Info | Structured query → send to originator → park approval |
| Delegate | Peer selection (if authorized) → route to delegate |
| Hold Pending | Timeout selection → park approval |
| Comment Only | Add comment without decision |

| Category | Description | Default Channels |
| --- | --- | --- |
| Approval Required | New item awaiting decision | In-app, badge |
| Action Required | Item assigned to you | In-app, badge |
| Status Update | Item you're tracking | In-app |
| SLA Approaching | Approaching breach | In-app, email, badge |
| SLA Breached | Item has breached SLA | In-app, email, SMS for critical |
| System Alert | System health/operational | In-app, email for critical |
| Security Alert | Unusual login, permission changes | In-app, email, SMS |
| Workflow Update | Subscribed workflow updated | In-app |
| Comment Mentioned | You were mentioned | In-app, email |
| Incident Declared | Active incident | In-app broadcast, email |

| Shortcut | Behavior |
| --- | --- |
| #workflowID | Direct navigation to workflow |
| customer:ID | Customer detail view |
| bic:BIC | Counterparty bank detail |
| >Q1 2025 | Date range filter |
| amount:>1M | Amount filter |

| Shortcut | Action |
| --- | --- |
| Ctrl+K | Global search |
| Ctrl+/ | Help |
| Alt+1 to Alt+6 | Rail switcher |
| Ctrl+Shift+A | My Approvals |
| Ctrl+Shift+E | Exception Queue |
| Ctrl+Shift+T | My Tasks |
| Esc | Close modal/drawer |
| ? | Show shortcuts |

| Persona | Audit Log Access |
| --- | --- |
| Internal Audit | Full access; query by any dimension; 10-year retention |
| Compliance | Full access; query for compliance investigations |
| Operations Manager+ | Access to their team's logs |
| Standard Operational | Access to their own activity history |

| Metric | Target |
| --- | --- |
| Initial application load | < 3 seconds |
| Dashboard refresh (real-time) | 1 second |
| Dashboard refresh (operational) | 5 seconds |
| Queue list load (typical) | < 2 seconds |
| Queue filter/sort update | < 500 ms |
| Detail view load | < 2 seconds |
| Form rendering | < 500 ms |
| Form validation feedback | Instant |
| Action invocation acknowledge | < 1 second |
| Search auto-suggest | < 300 ms |
| Standard report generation | < 30 seconds |
| Complex custom report | < 5 minutes |
| Bulk action (up to 100 items) | < 30 seconds |
| Notification delivery | < 1 second |

| Error Type | Display Behavior |
| --- | --- |
| User input errors | Display inline with field |
| Validation errors | Display at form-level with affected fields |
| Authorization errors | Display 'Not authorized' with explanation |
| Backend errors | Display friendly message; log full error |
| Network errors | Display with retry option |
| System errors | Display generic message; log for ops review |

| NEW IN V2  Reference Data Management is referenced across every module as the authoritative source for participant directories, sanctions indices, message specifications, transaction codes, validation profiles, and configuration. V1 mentioned this only briefly under Administration. V2 specifies the full administrative UI. |
| --- |

| Domain | Description | Update Source |
| --- | --- | --- |
| CBUAE UAEFTS Participant Directory | Active UAE banks on UAEFTS with BICs and capabilities | CBUAE daily feed + event-driven |
| AEP IPI Participant Directory | Active IPI/Aani participants | AEP feed + event-driven |
| IPP Participant Directory | Active IPP participants | CBUAE IPP feed |
| MOHRE WPS Participant Directory | Active WPS Employer/Agent Banks | CBUAE/MOHRE feed |
| SWIFT BIC Directory | Global BIC reference | SWIFT BIC update feed |
| Sanctions Index | OFAC, UN, EU, UAE local sanctions lists | Multi-vendor continuous feed |
| PEP / Adverse Media Index | PEP and adverse media records | Specialized vendor feed |
| CBUAE Message Specifications | CB103, CB202, CB202COV, CB101, CB910, CB940/CB950, etc. | CBUAE rulebook updates |
| AEP IPI Specification | pacs.008 IPI profile, alias spec, CoP spec | AEP technical spec updates |
| IPP Specification | Per CBUAE IPP technical specification | CBUAE IPP updates |
| WPS File Specifications | SIF, PIF, DIF, RFA, RTC, RFR, RRI, RRR, RSU, DCR formats | CBUAE/MOHRE rulebook |
| Reason Codes per Rail | FTS-*, IPI-*, IPP-*, WPS-*, CORR-*, etc. | Per rail rulebook |
| Purpose Codes | CBUAE purpose code list | CBUAE rulebook |
| GIBAN Format and Authority Codes | GPSSA, FTA GIBAN parsing rules | CBUAE/GPSSA/FTA rulebook |
| Transaction Codes (UFP, regulatory, etc.) | Special transaction type codes | CBUAE rulebook |
| UFP Register | Long-term register of UFP transfers (indefinite retention) | Platform-internal |
| Counterparty Agreements | Correspondent banking, treasury counterparties | Treasury/Correspondent ops |
| Approval Authority Limits | Canonical authority matrix per persona and action | Operations/HR |
| Persona Definitions and RBAC | Persona inventory and permission matrix | HR/Operations |
| Validation Profiles | Per-flow validation rule sets | Engineering/Compliance |
| Transformation Maps | CPO to rail-format mappings | Engineering |
| Notification Templates | Per-event notification template library | Operations |
| Workflow Templates Inventory | All 30+ workflow templates with versioning | Engineering |
| Exception Code Registry | Complete exception taxonomy | Engineering/Operations |

| Domain | Read | Edit | Approve Edit |
| --- | --- | --- | --- |
| Participant directories | All ops personas | N/A (feed-driven) | N/A |
| Sanctions/PEP indices | Compliance, Internal Audit | N/A (feed-driven) | N/A |
| Message specifications | Engineering, Ops L2+ | Engineering Head | Compliance Head |
| Reason codes | All ops personas | Operations Head | Compliance Head |
| UFP register | Branch Ops, Compliance, Internal Audit | Platform-internal | N/A |
| Approval authority matrix | All ops personas (read) | HR + Operations Head | CRO |
| Persona definitions | All ops personas (read) | HR Admin | Operations Head |
| Validation profiles | Engineering, Ops L2+ | Engineering Head | Compliance Head + Ops Head |
| Notification templates | Ops Managers+ | Operations Manager | Operations Head |
| Workflow templates | Engineering, Ops L2+ | Engineering Head | Operations Head + Compliance Head |

| NEW IN V2  Every module has Operational Control configurations specifying pause/resume capabilities, override authorities, and emergency interventions. V1 mentioned this only at action panel level. V2 specifies the dedicated Operational Control Levers UI for emergency operations. |
| --- |

| Lever | Authority | Use Case |
| --- | --- | --- |
| Pause UAEFTS Outbound | Payments Head + CRO | Scheme outage, critical incident |
| Pause UAEFTS Inbound | Payments Head + CRO | Scheme outage with retention needed |
| Pause IPI Outbound | Payments Head + CRO | AEP issue or instant payment incident |
| Pause IPI Inbound | Payments Head + CRO | AEP issue |
| Pause IPP Outbound/Inbound | Payments Head + CRO | IPP scheme issue |
| Pause SWIFT Outbound/Inbound | Payments Head + CRO + Correspondent Ops Head | SWIFT scheme issue or correspondent issue |
| Pause WPS Outbound (SIF dispatch) | Payments Head + Compliance Head | MOHRE compliance issue or scheme issue |
| Pause WPS Refund Sub-Flow | WPS Ops Manager + Compliance | Refund flow issue |
| Pause UFP Outbound | Payments Head + Compliance Head + Legal | UFP cycle issue |
| Pause UFP Reclaim | Payments Head + Compliance Head + Legal | Reclaim flow issue (rare) |
| Pause Regulatory Payments | Payments Head + Compliance Head | CBWSI integration issue |
| Pause Per Counterparty Bank | Payments Head | Specific counterparty issue |
| Pause Per Customer Segment | Payments Head + Compliance | Targeted hold for investigation |
| Override Beneficiary Resolution | Payments Ops Manager | Case-by-case manual resolution |
| Force Reclaim Reprocess | Operations Head + Compliance Head | Resubmit after CBUAE rejection |
| Bypass Reconciliation Rule | Treasury Head + CFO + Internal Audit Oversight | Rare; with full audit trail |
| Override CBWSI Fallback Policy | Payments Head + Compliance Head | CBWSI integration management |
| Initiate Emergency Funding | Treasury Head + CFO | Liquidity emergency |
| Emergency Repositioning | Treasury Head + CFO | Critical Nostro shortage |
| Override Nostro Threshold | Treasury Head | Operational threshold override |
| Override Counterparty Exposure | Risk Head + CRO | Temporary exposure limit override |
| Initiate Scheme Dispute on Inbound | Compliance Head + Payments Head | Dispute confirmed sanctions inbound |
| Bulk Cancellation (Incident Mode) | Payments Head + Risk Head + Incident Commander | Mass intervention during incident |

| NEW IN V2  Compliance is referenced across all flows but V1 did not specify the dedicated Compliance Case Management UI. V2 specifies full case lifecycle from creation through closure. |
| --- |

| Case Type | Triggered By | Resolution Path |
| --- | --- | --- |
| Sanctions Hit Review | Screening confirmed/potential hit | Adjudication → Clear or SAR + Block |
| PEP Verification | PEP screening flag | Enhanced Due Diligence → Clear or Restrict |
| Adverse Media Review | Adverse media flag | Investigation → Clear or Escalate |
| EDD Investigation | High-risk corridor or pattern | Documentation review → Approve or Block |
| SAR/STR Investigation | Confirmed suspicious activity | Full investigation → FIU submission |
| Scheme Dispute Initiation | Inbound sanctions/fraud confirmed | Dispute filing → Resolution |
| Cross-Border Compliance Review | High-risk corridor flow | Documentation review → Approve or Block |
| Regulatory Inquiry Response | Regulator inquiry received | Investigation + Response |

| State | Description |
| --- | --- |
| NEW | Just created; awaiting initial triage |
| TRIAGED | Initial triage complete; assigned to investigator |
| INVESTIGATING | Active investigation in progress |
| AWAITING_INPUT | Awaiting documentation from customer/counterparty/regulator |
| AWAITING_APPROVAL | Decision drafted; awaiting senior approval |
| RESOLVED_CLEAR | Investigation complete; subject cleared |
| RESOLVED_RESTRICT | Subject restricted (specific limitations) |
| RESOLVED_BLOCK | Subject blocked; further action required |
| RESOLVED_SAR_SUBMITTED | SAR submitted to FIU |
| RESOLVED_STR_SUBMITTED | STR submitted to FIU |
| RESOLVED_DISPUTE_INITIATED | Scheme dispute initiated |
| CLOSED | Case closed with resolution recorded |

| NEW IN V2  Fraud Detection Engine is invoked in every flow but the dedicated Fraud Case Management UI was not specified in V1. |
| --- |

| Case Type | Triggered By | Primary Persona |
| --- | --- | --- |
| High-Risk Outbound Payment | Fraud model HIGH score on outbound | Fraud Ops Analyst |
| High-Risk Inbound Payment | Fraud model HIGH score on inbound (mule indicators) | Fraud Ops Analyst |
| APP Fraud Claim | Customer reports APP (Authorized Push Payment) fraud | Fraud Ops Analyst + Manager |
| Account Takeover Investigation | Unusual access pattern detected | Fraud Ops + Security |
| Mule Account Investigation | Mule account indicators | Fraud Ops Analyst |
| Pattern Anomaly | Cross-customer pattern detected | Fraud Ops Manager |
| Scam Typology Match | Scam pattern detected | Fraud Ops + Customer Service |
| Card-Adjacent Fraud | Cross-rail card-related fraud | Fraud Ops + Cards Team |

| NEW IN V2  Sanctions Screening Orchestrator is invoked in every flow. V1 mentioned sanctions outcomes in detail views but did not specify the dedicated adjudication UI. |
| --- |

| Action | Behavior |
| --- | --- |
| Clear (False Positive) | Subject is not the sanctioned party; release funds; document rationale |
| Clear (True Positive, Exempt) | Subject is the sanctioned party but transaction is permitted by license/exemption; document license |
| Block (Confirmed) | Confirmed hit; freeze funds; initiate SAR; legal direction; dispute inbound if applicable |
| Escalate to Compliance Manager | Adjudication beyond L1 authority |
| Request Documentation | Need customer documentation before deciding |
| Hold for Investigation | Park decision; investigate further |

| NEW IN V2  SAR/STR workflows are referenced across Recalls, Cancellations, Returns, Correspondent Banking, UFP, and Compliance modules as linked workflows. V1 mentioned this only as a linkage. V2 specifies the SAR/STR lifecycle UI. |
| --- |

| Stage | Description | Owner |
| --- | --- | --- |
| INITIATED | Case created from compliance/fraud investigation | Compliance Officer |
| EVIDENCE_GATHERING | Collecting transactions, parties, supporting evidence | Compliance Officer |
| DRAFT_PREPARED | SAR/STR narrative drafted | Compliance Officer |
| INTERNAL_REVIEW | Compliance Manager review | Compliance Manager |
| LEGAL_REVIEW | Legal review for high-stakes cases | Legal Counsel |
| AWAITING_APPROVAL | Compliance Head sign-off | Compliance Head |
| APPROVED_PENDING_FILING | Approved; ready to file with FIU | Compliance Officer |
| FILED_WITH_FIU | Filed with Financial Intelligence Unit | Compliance Officer |
| AWAITING_FIU_RESPONSE | Awaiting FIU acknowledgement or follow-up | Compliance Officer |
| FIU_FOLLOW_UP | FIU requested additional information | Compliance Officer |
| CLOSED | Investigation closed | Compliance Head |

| Action | Authorized Personas |
| --- | --- |
| View SAR/STR case | Compliance Officer, Compliance Manager, Compliance Head, Internal Audit, CRO |
| Create SAR/STR draft | Compliance Officer |
| Submit for review | Compliance Officer |
| Review and approve internal | Compliance Manager, Compliance Head |
| File with FIU | Compliance Officer (after approvals) |
| Close SAR/STR case | Compliance Head |

| NEW IN V2  Reimbursement Workflow is referenced in Recalls (declined fraud) and Cancellations (APP fraud) but V1 did not specify the assessment UI. V2 specifies the reimbursement decision workflow for APP fraud and consumer protection schemes. |
| --- |

| Amount Tier | Required Approvers |
| --- | --- |
| Up to AED 50,000 | Fraud Ops Manager |
| AED 50,000 - 500,000 | Fraud Ops Manager + Operations Manager |
| AED 500,000 - 5,000,000 | Operations Head + CRO |
| Above AED 5,000,000 | CFO + CRO + CEO |

| NEW IN V2  Beneficiary Consent Workflow is a reusable child workflow invoked by Inbound Recalls and WPS Refund Sub-Flow (RRI inbound). V1 did not specify how the consent is collected via the console. |
| --- |

| NEW IN V2  The Nostro Management Module specifies inter-Nostro transfer mechanisms but V1 covered only the basic form. V2 specifies the full Liquidity Orchestration UI for treasury operations. |
| --- |

| Mechanism | When Used | UI Specifics |
| --- | --- | --- |
| Internal Book Transfer | Same currency, internal ledgers | Simple form; instant |
| Scheme-Mediated (CB202) | Same currency, between rail Nostros | CB202 dispatch form; settlement window aware |
| FX-Mediated | Different currencies | FX quote integration (see Section 45) |
| Correspondent-to-Correspondent | Between two foreign Nostros | SWIFT outbound from source correspondent |

| NEW IN V2  The Nostro Management Module's Funding Request Queue was mentioned in V1 but not specified at UI depth. |
| --- |

| NEW IN V2  The Nostro Management Module specifies counterparty exposure tracking. V1 had a dashboard reference; V2 specifies management UI. |
| --- |

| NEW IN V2  Nostro Management specifies Position Stress Testing as a capability. V1 referenced it; V2 specifies the UI. |
| --- |

| Scenario | Description |
| --- | --- |
| Large Outflow | Sudden withdrawal of major correspondent deposits |
| Rate Shock | FX rate shocks affecting foreign currency Nostros |
| Scheme Outage | UAEFTS or correspondent rail unavailable for X hours |
| Counterparty Default | Major correspondent default; Nostro funds at risk |
| Operational Incident | Settlement processing delay of X hours |
| Concentrated Withdrawal | Top 5 customers withdrawing simultaneously |
| Multi-Scenario Combination | Two or more scenarios simultaneously |

| NEW IN V2  The WPS modules describe 13 workflow templates and 10 file types. V1's WPS dashboard was high-level. V2 specifies the file operations UI in depth. |
| --- |

| NEW IN V2  Correspondent Banking modules specify deep GPI Tracker integration. V1 mentioned the tracker only at dashboard level. V2 specifies the per-payment GPI tracker UI. |
| --- |

| NEW IN V2  FX Service is referenced across multiple modules but V1 did not specify the FX-specific operational UI. |
| --- |

| NEW IN V2  Reconciliation Engine is referenced in every module. V1 had a dashboard but no dedicated workspace for break investigation and resolution. |
| --- |

| Break Age | Action |
| --- | --- |
| < 1 hour | Reconciliation Analyst (L1) review |
| 1-4 hours | Active investigation; notify supervisor if value > threshold |
| 4-24 hours | Reconciliation Manager escalation |
| > 24 hours | Treasury Ops + Payments Head escalation |
| > 3 days | CRO escalation; mandatory daily reporting |

| NEW IN V2  The UFP Module specifies long-term register and cycle operations. V1 had a basic UFP reclaim form. V2 specifies the register browser and cycle management. |
| --- |

| NEW IN V2  Incident response is referenced across modules (bulk operational cancellation, pause levers, broadcast notifications) but V1 did not specify a dedicated Incident Command Center. |
| --- |

| NEW IN V2  Audit & Monitoring captures everything but V1 lacked the forensic investigation UI for stepping through historical workflows. |
| --- |

| NEW IN V2  Operations runs 24x7 with shift handovers. V1 did not specify the handover or workload distribution UI. |
| --- |

| NEW IN V2  Document attachments are referenced in multiple flows (UFP claim, compliance cases, fraud cases, disputes) but V1 lacked detailed document management specifications. |
| --- |

| NEW IN V2  Comment threads were mentioned in V1 but the broader collaboration capabilities were not specified. |
| --- |

| NEW IN V2  V1 lacked specifications for maintenance window management and system status communication. |
| --- |

| NEW IN V2  Corporate ERP webhooks are integration delivery endpoints but V1 did not specify the management UI. |
| --- |

| NEW IN V2  Engineers, QA, and corporate integration partners need sandbox capabilities. V1 did not specify this UI. |
| --- |

| NEW IN V2  Reference Data changes affect platform behavior but V1 lacked specifications for change history and rollback UI. |
| --- |

| Persona | Primary Capabilities | Secondary Capabilities |
| --- | --- | --- |
| PAY-OPS-L1 | Live Operations Dashboard, Queue work, Exception triage | Customer 360, Workflow detail |
| PAY-OPS-L2 | Manager queue oversight, Approvals, Bulk actions | Team workload, Reports |
| PAY-OPS-HEAD | Per-rail dashboards, Incident Command, Operational levers | Strategic dashboards, Capacity planning |
| TRE-OPS-AN | Nostro positions, Inter-Nostro transfers, Funding requests | FX quote acceptance |
| TRE-OPS-MG | Liquidity orchestration, CB202 approvals | Stress testing, Repositioning |
| TRE-HEAD | Strategic treasury, Emergency funding, Override authorities | Stress testing, Counterparty exposure |
| CFO | Executive dashboards, Strategic decisions | Audit log queries |
| COMP-OFF | Compliance cases, Sanctions adjudication, Screening reviews | Customer/counterparty 360 |
| COMP-MG | Compliance case oversight, SAR/STR drafting, QC | Trend analysis |
| COMP-HEAD | Strategic compliance, SAR/STR approvals, Scheme disputes | Regulatory submissions |
| FRD-OPS-AN | Fraud cases, Customer intervention | Pattern analysis, Mule investigation |
| FRD-OPS-MG | Fraud pattern analysis, Reimbursement decisions | Cross-flow investigation |
| REC-AN | Break investigation, Manual matching | Auto-resolution rule management |
| REC-MG | Cycle close sign-off, Material break escalation | Reconciliation reporting |
| BR-OPS | UFP reclaim initiation, Customer service queries | Document management |
| CORR-OPS | GPI tracker, Correspondent disputes, FX coordination | Multi-currency positions |
| WPS-OPS-AN | WPS file operations, Record-level investigation | MOHRE compliance |
| WPS-OPS-MG | WPS file authorization, Refund decisions | Per-establishment management |
| SR-MGT | Cross-rail dashboards, Executive reports | Strategic KPI tracking |
| INT-AUD | Audit log, Workflow replay, Forensic queries | All read-only access |
| RISK-MG | Counterparty exposure, Stress testing | Risk dashboards |
| FIN-USR | End-of-day positions, Settlement reports | Reconciliation cycle status |
| CRO | Strategic risk, Emergency authorities, Override approvals | Stress testing, Incident command |

| V2 Section | Source Module(s) |
| --- | --- |
| 31. Reference Data Admin | Reference Data Management module |
| 32. Operational Control Levers | Operational Control module (cross-module) |
| 33. Compliance Case Management | Compliance module, Screening Orchestrator |
| 34. Fraud Case Management | Fraud Detection Engine |
| 35. Sanctions Hit Adjudication | Screening Orchestrator |
| 36. SAR/STR Workflow | Compliance module (cross-cutting) |
| 37. Reimbursement Assessment | Recalls, Cancellations, Fraud modules |
| 38. Beneficiary Consent | Recalls, WPS Refund Sub-Flow |
| 39. Liquidity Orchestration | Nostro Management |
| 40. Funding Request Management | Nostro Management |
| 41. Counterparty Exposure | Nostro Management |
| 42. Stress Testing | Nostro Management |
| 43. WPS File Operations | WPS Employer Bank, Agent Bank, Refund Sub-Flow |
| 44. GPI Tracker Detail | Correspondent Banking Inbound/Outbound |
| 45. FX Quote and Treasury | FX Service integration |
| 46. Reconciliation Workspace | Reconciliation Engine |
| 47. UFP Register and Cycle | UFP module |
| 48. Incident Command Center | Operations Console Design (cross-cutting) |
| 49. Workflow Replay and Forensics | Audit & Monitoring |
| 50. Shift Handover | Operations Console (cross-cutting) |
| 51. Document Management | Cross-cutting (referenced in many modules) |
| 52. Collaboration and Messaging | Cross-cutting |
| 53. Maintenance and Status | Operational Control, HA |
| 54. Webhooks | Notification Service, Integration Catalog |
| 55. Sandbox | Cross-cutting |
| 56. Configuration Change History | Reference Data Management |

| Module | V1 Sections | V2 Sections |
| --- | --- | --- |
| Corporate FTS Outbound | 13, 14, 15, 16.1 | 32 (pause levers) |
| Corporate FTS Inbound | 10, 15, 16.1 | — |
| IPI Outbound/Inbound | 10, 13, 15, 16.2 | 32 (pause levers) |
| IPP Outbound/Inbound | 10, 13, 15, 16.3 | 32 (pause levers) |
| WPS Domain (all) | 13, 14, 15, 16.4 | 43 (complete file operations) |
| SWIFT Correspondent Banking | 10, 13, 16.5 | 44 (GPI detail), 45 (FX) |
| UFP | 13.4, 16 | 47 (register and cycle) |
| Regulatory Payments | 13, 16 | 32 (CBWSI controls) |
| Recalls | 13, 15 | 38 (consent), 37 (reimbursement) |
| Cancellations | 13, 15 | 32 (bulk ops), 48 (incident-driven) |
| Returns | 13, 15 | — |
| Enquiries | 13, 15 | — |
| Nostro Management | 8.3.2, 13.6 | 39 (orchestration), 40 (funding), 41 (exposure), 42 (stress) |
| Compliance / Screening | 10 (screening tab) | 33 (cases), 35 (adjudication), 36 (SAR/STR) |
| Fraud | 10 (fraud tab) | 34 (cases) |
| Reconciliation | 8.3.5 | 46 (workspace) |
| Audit & Monitoring | 21 | 49 (replay/forensics) |
| Notification Service | 18 | 54 (webhooks) |
| Reference Data | 7.1, 31 (V2) | 31 (admin), 56 (change history) |
| Operations Console Design | all V1 | 48 (incident command), 50 (handover/workload) |

| Component | Description | Used In |
| --- | --- | --- |
| Workflow Visualization | Visual flow diagram with state highlighting | Detail views, Replay |
| Approval Chain Visualization | Hierarchical approval chain display | Approval items |
| Multi-Source Diff | Side-by-side comparison with highlighting | Reconciliation, Config history |
| Timeline View | Chronological events with zoom and filter | Investigations, Activity logs |
| GPI Tracker Timeline | Per-payment GPI status progression | Correspondent banking |
| Network Graph | Entity relationships visualization | Fraud patterns, Investigations |
| Position Grid | Nostro positions matrix | Treasury workspace |
| Exposure Gauge | Limit utilization visualization | Counterparty exposure |
| Stress Test Results | Scenario impact visualization | Stress testing |
| Lever Activation Card | Active lever with status and resume option | Operational controls |
| Incident Header | Incident status with metrics | Incident command |
| Document Preview | In-line document viewing | Evidence management |
| Activity Feed | Real-time event stream | Dashboards, Cases |
| Persona Switcher | Multi-persona context switch | Header |
| Rail Switcher | Quick rail navigation | Header |

| Gap Category | V1 Coverage Level | V2 Resolution |
| --- | --- | --- |
| Reference Data Administration | Minimal (mentioned only) | Section 31 — full admin UI |
| Operational Control Levers | Partial (in action panel) | Section 32 — dedicated levers UI |
| Compliance Case Management | Minimal (screening outcomes only) | Section 33 — full case lifecycle |
| Fraud Case Management | Minimal (fraud outcomes only) | Section 34 — full case lifecycle |
| Sanctions Hit Adjudication | Minimal (mentioned) | Section 35 — dedicated adjudication UI |
| SAR/STR Workflow | Mentioned as linkage | Section 36 — full workflow UI |
| Reimbursement Assessment | Mentioned only | Section 37 — full assessment workflow |
| Beneficiary Consent UI | Mentioned only | Section 38 — full consent collection UI |
| Liquidity Orchestration | Basic form (V1 13.6) | Section 39 — full orchestration UI |
| Funding Request Management | Dashboard reference only | Section 40 — full management UI |
| Counterparty Exposure Management | Dashboard only | Section 41 — limit management UI |
| Stress Testing UI | Mentioned only | Section 42 — scenario and execution UI |
| WPS File Operations | Dashboard level (V1 16.4) | Section 43 — complete file operations |
| GPI Tracker Detail | Dashboard level (V1 16.5) | Section 44 — full timeline and dispute UI |
| FX Quote and Treasury | Not specified | Section 45 — complete FX desk UI |
| Reconciliation Workspace | Dashboard only (V1 8.3.5) | Section 46 — full investigation workspace |
| UFP Register Browser | Reclaim form only (V1 13.4) | Section 47 — register and cycle UI |
| Incident Command Center | Not specified | Section 48 — full incident lifecycle |
| Workflow Replay/Forensics | Audit log queries only (V1 21) | Section 49 — forensic investigation UI |
| Shift Handover and Workload | Not specified | Section 50 — handover and workload mgmt |
| Document Management | Mentioned only | Section 51 — full document lifecycle |
| Collaboration and Messaging | Comments only | Section 52 — secure messaging and collaboration |
| Maintenance and Status | Not specified | Section 53 — maintenance windows and status pages |
| Webhook Management | Mentioned only | Section 54 — full webhook lifecycle |
| Sandbox and Test Transaction | Not specified | Section 55 — sandbox environment UI |
| Configuration Change History | Mentioned only | Section 56 — full change history and rollback |

| NEW IN V2  V1 and V2 covered transaction handling and Customer 360 view, but the lifecycle of onboarding a customer to specific payment services was not specified. |
| --- |

| NEW IN V2  When customers call about a payment, customer service needs unified operational visibility. V1 referenced this only briefly. |
| --- |

| Stage | Description |
| --- | --- |
| INTAKE | Complaint logged from channel (call, branch, portal, regulator) |
| CATEGORIZED | Categorized by complaint type and severity |
| INVESTIGATING | Active investigation with assigned officer |
| AWAITING_INPUT | Awaiting customer documentation or response |
| AWAITING_RESOLUTION | Investigation complete; resolution decision drafted |
| AWAITING_APPROVAL | Resolution awaiting senior approval (high-value) |
| RESOLVED | Resolution communicated to customer; customer acceptance pending |
| CLOSED | Customer acknowledged resolution; case closed |
| ESCALATED_TO_OMBUDSMAN | Customer escalated to regulator/ombudsman |
| LITIGATION | Legal proceedings initiated |

| NEW IN V2  Counterparty 360 was specified but the full lifecycle (onboarding, agreement management, offboarding) was not. |
| --- |

| NEW IN V2  Daily cycles, scheduled file processing, periodic reports — none of this had a unified UI in V1 or V2. |
| --- |

| Job | Schedule | Owner |
| --- | --- | --- |
| UAEFTS End-of-Day Reconciliation | Daily at cycle close | Reconciliation Ops |
| AEP Settlement Cycle Reconciliation | Per AEP cycle | Reconciliation Ops |
| WPS File Cycle Processing | Per scheme schedule | WPS Ops |
| SWIFT Statement Ingestion (MT940/950, camt.053) | Per correspondent schedule | Correspondent Ops |
| Sanctions Index Refresh | Multiple times daily per vendor | Compliance/Integration |
| PEP/Adverse Media Refresh | Daily per vendor | Compliance/Integration |
| CBUAE Participant Directory Refresh | Daily | Integration Ops |
| Core Banking Dormancy List (UFP eligibility) | Annual per regulatory cadence | Branch Ops/Compliance |
| MOHRE Compliance Data Refresh | Per MOHRE feed schedule | WPS Ops/Compliance |
| Regulatory Report Generation | Per regulatory cadence | Finance/Compliance |
| LCR Computation | Daily | Treasury/Risk |
| Stress Test Periodic Execution | Monthly/Quarterly | Treasury/Risk |
| Audit Log Archival | Daily | Audit Operations |
| Document Cold Storage Archival | Daily | Document Operations |
| Workflow Cleanup (completed) | Daily | Platform Ops |

| NEW IN V2  Beyond standard queue management, operations needs the ability to prioritize urgent workflows and recover stuck workflows. |
| --- |

| Action | Authority | Effect |
| --- | --- | --- |
| Retry Last Step | Ops Analyst | Re-execute the most recent failed step |
| Skip Step | Ops Manager | Move workflow past stuck step (with rationale) |
| Reset to Prior State | Ops Manager + Engineering | Revert workflow to known good state |
| Manual Override Decision | Ops Manager | Provide decision the workflow was awaiting |
| Force Complete | Ops Head + CRO | Mark workflow as complete with manual posting (rare) |
| Force Reject | Ops Manager | Mark workflow as rejected; trigger compensating actions |
| Re-route to Different Workflow | Engineering Head | Move to different workflow template |

| NEW IN V2  Procedure manuals, policy updates, training, and privilege review were not specified in V1/V2 but are core operational governance requirements. |
| --- |

| NEW IN V2  Specialized risk dashboards beyond compliance and fraud were under-specified. |
| --- |

| NEW IN V2  Settlement is the financial culmination of every flow but V1/V2 lacked dedicated settlement operational UI. |
| --- |

| NEW IN V2  Regulatory reports were referenced in V1 Section 11 but the submission lifecycle was not specified. |
| --- |

| Submission | Regulator | Frequency |
| --- | --- | --- |
| LCR Report | CBUAE | Daily |
| Intraday Liquidity Monitoring | CBUAE/BCBS | Daily |
| WPS Compliance Report | MOHRE/CBUAE | Per WPS cycle |
| UFP Submission | CBUAE | Per cycle |
| SAR Submission | FIU | Per occurrence |
| STR Submission | FIU | Per occurrence |
| Sanctions Monitoring Report | CBUAE | Monthly |
| AML Transaction Monitoring | CBUAE | Monthly |
| Counterparty Exposure | CBUAE | Monthly/Quarterly |
| Pillar III Disclosures | CBUAE | Quarterly |
| Internal Capital Adequacy | CBUAE | Annually |
| Operational Risk Reporting | CBUAE | Quarterly |
| Outsourcing Notification | CBUAE | As required |
| Incident Reporting | CBUAE | Within prescribed window |
| Annual Compliance Certificate | CBUAE | Annually |

| NEW IN V2  Master data quality is foundational but V1/V2 did not specify the operational UI. |
| --- |

| NEW IN V2  Performance was specified in V1 Section 25 as targets but the operational view of capacity management was missing. |
| --- |

| NEW IN V2  Payment trace as a customer service capability was referenced in Section 58 but the full investigation lifecycle was not specified. |
| --- |

| Stage | Description |
| --- | --- |
| INITIATED | Trace request raised (customer, internal, regulator) |
| TRIAGED | Initial assessment by Investigation Officer |
| INVESTIGATING_INTERNAL | Internal platform investigation in progress |
| INVESTIGATING_EXTERNAL | Inter-bank or scheme inquiry dispatched |
| AWAITING_RESPONSE | Awaiting response from other bank/scheme |
| RESOLVED_FOUND | Payment located; status communicated to requester |
| RESOLVED_DELAY_EXPLAINED | Payment delayed; explanation provided |
| RESOLVED_LOST | Payment lost; recovery action initiated |
| RESOLVED_RECOVERED | Lost payment recovered |
| CLOSED | Investigation closed with resolution recorded |

| NEW IN V2  Corporate customer contracts and service variations were not specified. |
| --- |

| NEW IN V2  The platform's architectural promise is that configuration overlays absorb complexity. V1/V2 did not specify the operational view of these overlays. |
| --- |

| NEW IN V2  Beyond Section 18 notifications and Section 48 incident communications, a unified communication center was needed. |
| --- |

| NEW IN V2  Vendor licenses and scheme entitlements drive certain platform capabilities. V1/V2 did not specify management UI. |
| --- |

| NEW IN V2  Operational knowledge captured through resolutions is institutional value. V1/V2 did not specify knowledge management. |
| --- |

| NEW IN V2  Disaster recovery and business continuity are operational concerns that needed dedicated UI. |
| --- |
