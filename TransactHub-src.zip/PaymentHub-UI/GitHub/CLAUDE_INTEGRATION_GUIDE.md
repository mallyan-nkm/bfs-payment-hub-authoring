# Claude Chat Integration Guide

## Overview
This guide walks you through integrating Claude AI chat into your PaymentHub Operations Console.

## Prerequisites
- Claude Pro account (you have this ✓)
- Anthropic API key
- Node.js project with Angular

## Installation Steps

### Step 1: Get Your API Key
1. Visit [https://console.anthropic.com/account/keys](https://console.anthropic.com/account/keys)
2. Sign in with your Claude Pro account
3. Click **"Create Key"**
4. Copy the key and save it securely

### Step 2: Configure Environment Variables
Create a `.env` file in your project root:
```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx
```

⚠️ **Security Note**: Never commit `.env` to version control. Add it to `.gitignore`:
```
.env
.env.local
*.key
```

### Step 3: Verify Dependencies
Your `package.json` already includes the Anthropic SDK. If not, run:
```bash
npm install @anthropic-ai/sdk dotenv
```

### Step 4: Import Components in Your App

#### In your main app component or action panel:

```typescript
import { ClaudeChatComponent } from './components/claude-chat/claude-chat.component';

@Component({
  selector: 'app-action-panel',
  standalone: true,
  imports: [CommonModule, ClaudeChatComponent],
  template: `
    <div class="action-panel">
      <!-- Your existing content -->
      <app-claude-chat></app-claude-chat>
    </div>
  `
})
export class ActionPanelComponent { }
```

#### Or add to your action panel template:
```html
<div class="action-panel">
  <!-- Existing content -->
  <app-claude-chat></app-claude-chat>
</div>
```

### Step 5: Provide the Service

In your app bootstrap or root module, make sure the `ClaudeChatService` is provided:

```typescript
import { ClaudeChatService } from './app/shared/services/claude-chat.service';

bootstrapApplication(AppComponent, {
  providers: [
    ClaudeChatService,
    // ... other providers
  ]
});
```

## File Structure
```
src/
├── app/
│   ├── shared/
│   │   └── services/
│   │       └── claude-chat.service.ts      ← Claude API Service
│   └── components/
│       └── claude-chat/
│           ├── claude-chat.component.ts    ← Component Logic
│           ├── claude-chat.component.html  ← UI Template
│           └── claude-chat.component.scss  ← Styles
```

## Usage Examples

### Basic Chat
Users can type questions and receive Claude responses. The chat maintains conversation history automatically.

### Customizing System Prompt
To customize Claude's behavior for PaymentHub, edit the system message in `claude-chat.service.ts`:

```typescript
system: "You are Claude, an AI assistant for PaymentHub Operations Console. 
Help users with payment operations, transactions, and system management. 
Be concise and professional."
```

### Example Questions for PaymentHub
- "What are the current transaction statuses?"
- "How do I process a payment?"
- "Explain the IPI payment rail"
- "What's the status of recent transactions?"

## Advanced Configuration

### Change Model
To use a different Claude model, edit the service:
```typescript
private model: string = "claude-3-5-sonnet-20241022"; // or other models
```

Available models:
- `claude-3-5-sonnet-20241022` (Latest, recommended)
- `claude-3-opus-20250219`
- `claude-3-haiku-20250307`

### Adjust Response Length
```typescript
max_tokens: 2048, // Increase for longer responses
```

### Add Context from Your App
Enhance Claude's responses with PaymentHub data:

```typescript
async sendMessage(userMessage: string, context?: any): Promise<string> {
  const enrichedMessage = context 
    ? `${userMessage}\n\nContext: ${JSON.stringify(context)}`
    : userMessage;
  // ... rest of method
}
```

## Troubleshooting

### "API Key not found"
- Verify `.env` file exists in project root
- Check `ANTHROPIC_API_KEY` spelling (must be exact)
- Restart development server after adding `.env`

### "401 Unauthorized"
- API key may be invalid or expired
- Generate a new key from [console.anthropic.com](https://console.anthropic.com)

### CORS Issues (Browser)
If running as frontend-only, use a backend proxy:
```typescript
// Call your backend endpoint instead of directly calling Anthropic
this.httpClient.post('/api/chat', { message: userMessage });
```

### Slow Responses
- Claude responses typically take 1-3 seconds
- Consider showing a loading indicator (already implemented)
- Increase `timeout` if needed

## Security Best Practices

1. ✅ **Never expose API key in frontend code**
   - Use backend proxy for production
   - Keep API key in `.env` (server-side)

2. ✅ **Validate user input** before sending to Claude

3. ✅ **Rate limit** API calls to prevent abuse

4. ✅ **Monitor usage** at [console.anthropic.com/account/usage](https://console.anthropic.com/account/usage)

## Production Deployment

For production, implement a backend service:

```typescript
// Backend (Node.js)
app.post('/api/chat', async (req, res) => {
  const { message } = req.body;
  const response = await claudeService.sendMessage(message);
  res.json({ response });
});
```

Then call it from your component:
```typescript
async sendMessage(message: string): Promise<string> {
  const response = await this.http.post<{response: string}>
    ('/api/chat', { message }).toPromise();
  return response?.response || '';
}
```

## Support & Documentation

- **Anthropic API Docs**: https://docs.anthropic.com
- **Claude Models**: https://docs.anthropic.com/en/docs/about/models
- **Pricing**: https://www.anthropic.com/pricing

## Next Steps

1. ✓ Add API key to `.env`
2. ✓ Import `ClaudeChatComponent` in your layout
3. ✓ Test the chat interface
4. ✓ Customize the system prompt for PaymentHub
5. ✓ (Optional) Implement backend proxy for production
