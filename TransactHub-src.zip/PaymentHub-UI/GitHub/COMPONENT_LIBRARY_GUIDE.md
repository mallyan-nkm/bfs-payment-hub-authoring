# PaymentHub Operations Console - Angular Component Library

## Overview

This is the foundational Angular component library for the PaymentHub Operations Console, a comprehensive enterprise payment operations platform for UAE banks. The components implement a professional, dark-theme UI with a 4-region layout and full keyboard accessibility.

## Architecture

### Directory Structure

```
src/
├── app/
│   ├── app.component.ts          # Root component with main layout grid
│   ├── app.component.html        # Main template
│   ├── app.component.scss        # Global styles & theme variables
│   ├── shared/
│   │   └── types/
│   │       └── index.ts          # Shared TypeScript interfaces & enums
│   └── components/
│       └── layout/
│           ├── header/
│           │   ├── header.component.ts
│           │   ├── header.component.html
│           │   └── header.component.scss
│           ├── sidebar/
│           │   ├── sidebar.component.ts
│           │   ├── sidebar.component.html
│           │   └── sidebar.component.scss
│           ├── main-panel/
│           │   ├── main-panel.component.ts
│           │   ├── main-panel.component.html
│           │   └── main-panel.component.scss
│           ├── action-panel/
│           │   ├── action-panel.component.ts
│           │   ├── action-panel.component.html
│           │   └── action-panel.component.scss
│           └── footer/
│               ├── footer.component.ts
│               ├── footer.component.html
│               └── footer.component.scss
```

## Component Specifications

### 1. **AppComponent** (Root)

**Purpose:** Manages the main application layout with a 4-region grid structure.

**Layout:**
- Header: 48px fixed
- Main: 1fr flexible
  - Sidebar: 200px (collapsible to 60px)
  - Main Panel: 1fr flexible
  - Action Panel: 320px (collapsible to 40px)
- Footer: 28px fixed

**Features:**
- Grid-based responsive layout
- Layout state persistence (localStorage)
- Rail switching integration
- Sidebar/Action panel collapse state management

**Responsive Breakpoints:**
- Desktop (1200px+): Full layout
- Tablet (900-1200px): Sidebar collapses to 60px
- Mobile (≤768px): Sidebar/Action panel hidden, main panel full width

---

### 2. **HeaderComponent**

**Purpose:** Fixed header bar with navigation controls and user management.

**Dimensions:** 48px height, full width

**Features:**
- **Logo:** PaymentHub branding with accent glow effect
- **Rail Switcher:** Quick navigation between payment rails (UAEFTS, IPI, IPP, WPS, SWIFT, All Rails)
- **Global Search:** Full-text search with keyboard shortcut (Cmd+K)
- **Icon Buttons:**
  - Notifications (with badge count)
  - Settings
  - Help
- **User Chip:** Avatar, username, persona badge (OPERATOR, MANAGER, EXECUTIVE, etc.)
- **Session Timer:** Warning indicator when within 2 minutes of timeout

**Key Bindings:**
- Cmd+K / Ctrl+K: Focus search input
- Alt+1-6: Switch between rails

**Accessibility:**
- ARIA labels for all buttons
- Role="banner" for semantic HTML
- Focus indicators for keyboard navigation

---

### 3. **SidebarComponent**

**Purpose:** Left navigation panel with collapsible sections and badge indicators.

**Dimensions:** 200px (collapsed: 60px)

**Navigation Sections:**
1. **Dashboard** - Overview, KPI Metrics, System Health
2. **Operations** - Payment Queues, Transactions, Settlements, Rail Status
3. **Approvals** - Pending items, History, Delegations
4. **Exceptions** - Active Issues, Investigation, Resolution Queue
5. **Reporting** - Operational, Regulatory, Analytics
6. **Administration** - User Management, Settings, Audit Logs

**Features:**
- Collapsible sections (expand/collapse state persistence)
- Badge indicators with severity levels:
  - **URGENT** (red): Critical action items
  - **WARNING** (yellow): Items needing attention
  - **INFO** (blue): Informational badges
- Active navigation highlighting with left accent border
- Icon-only mode when collapsed
- Hover tooltips for collapsed state
- RouterLink integration for navigation

**Collapsed State:**
- Icon-only display
- 60px width
- Tooltips appear on hover
- Badge indicators shown as dots

---

### 4. **MainPanelComponent**

**Purpose:** Central content area with breadcrumb and page structure.

**Dimensions:** Flexible width, scrollable

**Features:**
- **Breadcrumb Navigation:** Full navigation trail with clickable links
- **Page Title Area:** Optional title and subtitle
- **Custom Header Slot:** Template for page-specific headers
- **Content Area:** Scrollable, supports all layout types
  - Single-pane layouts
  - Tabbed layouts
  - Split-pane layouts

**Accessibility:**
- Breadcrumb with role="navigation"
- Current page indicator in breadcrumb
- ARIA labels for all navigation elements

---

### 5. **ActionPanelComponent**

**Purpose:** Right-side context panel for action items and quick information.

**Dimensions:** 320px (collapsed: 40px)

**Features:**
- **Contextual Actions:** Dynamic action buttons based on current context
- **Action Types:**
  - Primary (blue): Main action
  - Secondary (gray): Alternative action
  - Danger (red): Destructive action
- **Quick Info:** Display context-specific information
- **Loading States:** Action buttons show loading spinner
- **Custom Content:** Support for template-based content
- **Collapsible:** Full collapse state persistence

**Collapsed State:**
- Vertical orientation
- Icon indicator only
- Expands on click

---

### 6. **FooterComponent**

**Purpose:** Status bar with system health and session information.

**Dimensions:** 28px height, full width

**Features:**
- **System Status Indicator:**
  - Operational (green)
  - Degraded (yellow)
  - Outage (red)
  - Unknown (gray)
- **Per-Rail Health Display:**
  - Status indicator (with animated dot)
  - Throughput (transactions/sec)
  - P95 Latency
  - Color-coded status
- **Session Info:** Duration display (e.g., "45m")
- **Keyboard Shortcuts:** Cmd+? hint for help
- **Real-time Updates:** Health data refreshes every 30 seconds

**Responsive:**
- Desktop: Full information display
- Tablet: Metrics hidden, status indicators only
- Mobile: Status only, no rail health

---

## Shared Types & Interfaces

### Enums

```typescript
export enum Rail {
  UAEFTS = 'UAEFTS',
  IPI = 'IPI',
  IPP = 'IPP',
  WPS = 'WPS',
  SWIFT = 'SWIFT',
  ALL = 'ALL'
}

export enum UserPersona {
  OPERATOR = 'OPERATOR',
  MANAGER = 'MANAGER',
  EXECUTIVE = 'EXECUTIVE',
  ADMINISTRATOR = 'ADMINISTRATOR',
  RISK_OFFICER = 'RISK_OFFICER',
  COMPLIANCE_OFFICER = 'COMPLIANCE_OFFICER'
}

export enum StatusIndicator {
  OPERATIONAL = 'operational',
  DEGRADED = 'degraded',
  OUTAGE = 'outage',
  UNKNOWN = 'unknown'
}

export enum BadgeSeverity {
  URGENT = 'urgent',
  WARNING = 'warning',
  INFO = 'info'
}
```

### Key Interfaces

- `NavigationItem`: Definition for sidebar navigation items
- `RailHealth`: Health status of a payment rail
- `UserSession`: Current user session information
- `ActionPanelContext`: Context for action panel actions
- `LayoutState`: Application layout state
- `Breadcrumb`: Breadcrumb navigation item

## CSS Variables & Theme

### Color Palette

```scss
// Dark theme backgrounds
--bg-0: #0a0e14;    // Darkest - body background
--bg-1: #0f141c;    // Dark - card, header background
--bg-2: #141a24;    // Medium dark - input, button background
--bg-3: #1b2230;    // Medium - hover states
--bg-4: #232b3b;    // Lighter - active states

// Borders
--border: #2a3447;         // Standard border
--border-light: #3a4561;   // Hover border

// Text colors
--text-0: #e8ecf3;  // Primary text
--text-1: #b4bdcc;  // Secondary text
--text-2: #7a8499;  // Tertiary text
--text-3: #525a6e;  // Muted text

// Semantic colors
--accent: #4c9eff;    // Primary action
--success: #4ade80;   // Success state
--warning: #fbbf24;   // Warning state
--danger: #f87171;    // Error state
--critical: #ef4444;  // Critical state
--info: #60a5fa;      // Information
--purple: #a78bfa;    // Accent 1
--teal: #2dd4bf;      // Accent 2
--pink: #f472b6;      // Accent 3
```

### Font Stack

```scss
// Primary UI Font
font-family: 'IBM Plex Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;

// Monospace (code, badges, metrics)
font-family: 'IBM Plex Mono', 'Courier New', monospace;
font-feature-settings: 'tnum'; // Tabular numbers
```

## Usage Examples

### Basic Setup

```typescript
// app.module.ts
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    AppComponent,
    RouterModule
  ]
})
export class AppModule { }
```

### Integrating Navigation

```typescript
// In a route/page component
import { MainPanelComponent } from './components/layout/main-panel/main-panel.component';
import { Breadcrumb } from './shared/types';

@Component({
  template: `
    <app-main-panel 
      [breadcrumbs]="breadcrumbs"
      [pageTitle]="'Payment Queues'"
      [pageSubtitle]="'Pending approvals'">
      <!-- Your content here -->
    </app-main-panel>
  `
})
export class PaymentQueuesPage {
  breadcrumbs: Breadcrumb[] = [
    { label: 'Dashboard', route: '/dashboard' },
    { label: 'Operations', route: '/operations' },
    { label: 'Queues', current: true }
  ];
}
```

### Using Action Panel

```typescript
import { ActionItem, ActionPanelComponent } from './shared/types';

@Component({
  template: `
    <app-action-panel 
      [title]="'Payment Actions'"
      [actions]="actions"
      (actionClicked)="handleAction($event)">
    </app-action-panel>
  `
})
export class PaymentDetailComponent {
  actions: ActionItem[] = [
    {
      id: 'approve',
      label: 'Approve Payment',
      type: 'primary',
      icon: 'check'
    },
    {
      id: 'reject',
      label: 'Reject',
      type: 'danger'
    }
  ];

  handleAction(action: ActionItem): void {
    console.log('Action:', action.id);
  }
}
```

## Accessibility Features

### WCAG 2.1 Compliance

- ✅ **Semantic HTML:** Proper use of roles, landmarks (header, nav, main, footer)
- ✅ **Keyboard Navigation:** Full keyboard support with Tab, Enter, Arrow keys
- ✅ **Focus Management:** Visible focus indicators for keyboard users
- ✅ **Color Contrast:** WCAG AA compliant color combinations
- ✅ **ARIA Labels:** Descriptive labels for interactive elements
- ✅ **Screen Reader Support:** Proper use of aria-label, aria-current, aria-live
- ✅ **Status Updates:** Real-time status updates with aria-live="polite"

### Keyboard Shortcuts

- `Cmd+K` / `Ctrl+K`: Focus search box
- `Tab`: Navigate through interactive elements
- `Enter` / `Space`: Activate buttons
- `Escape`: Close modals/panels (when implemented)
- `Arrow Keys`: Navigate menus, expand/collapse sections

## Performance Optimizations

- ✅ **Standalone Components:** Tree-shakable Angular 14+ architecture
- ✅ **OnPush Detection:** Change detection strategy for performance
- ✅ **Virtual Scrolling:** Ready for large lists in main panel
- ✅ **Lazy Loading:** Components support lazy loading
- ✅ **CSS Variables:** Efficient theme switching without rebuilds

## Responsive Design

### Mobile-First Approach

| Screen Size | Layout | Sidebar | Action Panel |
|-------------|--------|---------|-------------|
| Desktop (1200px+) | 3-column | 200px | 320px |
| Tablet (768-1200px) | 3-column | 60px (icon) | 40px (icon) |
| Mobile (≤768px) | 1-column | Hidden | Hidden |

## Next Steps (Phase 2)

- [ ] Implement routing with router configuration
- [ ] Connect to state management (NgRx/Signals)
- [ ] Implement authentication service integration
- [ ] Add API integration for data fetching
- [ ] Create page-specific components:
  - Dashboard component
  - Queue list component
  - Detail view component
  - Transaction forms
  - Approval workflows
- [ ] Implement modal/dialog system
- [ ] Add toast/notification system
- [ ] Implement search functionality
- [ ] Create data tables with sorting/filtering
- [ ] Add keyboard shortcuts help overlay
- [ ] Implement dark/light theme toggle
- [ ] Unit and E2E testing

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License

Internal use only - PaymentHub Operations Console

---

## Support & Documentation

For component API details, see individual component `.ts` files.
For styling reference, see component `.scss` files with inline comments.
For type definitions, see `shared/types/index.ts`.
