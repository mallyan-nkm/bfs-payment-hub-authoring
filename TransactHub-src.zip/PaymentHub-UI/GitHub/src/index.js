import Anthropic from "@anthropic-ai/sdk";
import dotenv from "dotenv";

dotenv.config();

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Default Claude Pro model
const DEFAULT_MODEL = "claude-3-5-sonnet-20241022";

async function chat(userMessage) {
  const message = await client.messages.create({
    model: DEFAULT_MODEL,
    max_tokens: 1024,
    messages: [
      {
        role: "user",
        content: userMessage,
      },
    ],
  });

  return message.content[0].text;
}

// Example usage
const response = await chat("Hello! What can you help me with?");
console.log("Claude:", response);
