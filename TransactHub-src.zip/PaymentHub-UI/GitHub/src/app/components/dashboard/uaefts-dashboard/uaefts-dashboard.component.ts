import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { KpiCardComponent } from '../kpi-card/kpi-card.component';
import { RailHealthCardComponent } from '../rail-health-card/rail-health-card.component';
import { RefreshBarComponent } from '../refresh-bar/refresh-bar.component';
import {
  UaeftsDashboardData,
  DashboardKPI,
  DashboardRefreshConfig
} from '../../../shared/types';
import { DashboardService } from '../../../shared/services/dashboard.service';

@Component({
  selector: 'app-uaefts-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, KpiCardComponent, RailHealthCardComponent, RefreshBarComponent],
  templateUrl: './uaefts-dashboard.component.html',
  styleUrls: ['./uaefts-dashboard.component.scss']
})
export class UaeftsDashboardComponent implements OnInit, OnDestroy {

  data!: UaeftsDashboardData;
  kpis: DashboardKPI[] = [];
  refreshConfig: DashboardRefreshConfig = {
    autoRefresh: true,
    intervalSeconds: 30,
    lastRefreshed: new Date(),
    isPaused: false
  };

  private refreshTimer: ReturnType<typeof setInterval> | null = null;

  constructor(readonly svc: DashboardService) {}

  ngOnInit(): void {
    this.loadData();
    this.scheduleAutoRefresh();
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  private loadData(): void {
    this.data = this.svc.getUaeftsDashboardData();
    this.kpis = this.buildKpis();
    this.refreshConfig = { ...this.refreshConfig, lastRefreshed: new Date() };
  }

  private buildKpis(): DashboardKPI[] {
    const d = this.data;
    return [
      {
        id: 'dispatch-latency',
        label: 'Dispatch Latency',
        value: this.svc.formatLatency(d.kpis.dispatchLatencyMs),
        color: d.kpis.dispatchLatencyMs > 800 ? 'danger' : d.kpis.dispatchLatencyMs > 500 ? 'warning' : 'success',
        subtitle: 'Avg end-to-end',
        trend: [320, 350, 290, 380, 360, d.kpis.dispatchLatencyMs]
      },
      {
        id: 'settlement-confirm-latency',
        label: 'Settlement Confirm',
        value: this.svc.formatLatency(d.kpis.settlementConfirmLatencyMs),
        color: d.kpis.settlementConfirmLatencyMs > 1500 ? 'danger' : d.kpis.settlementConfirmLatencyMs > 1000 ? 'warning' : 'success',
        subtitle: 'Confirm latency',
        trend: [750, 800, 790, 820, 810, d.kpis.settlementConfirmLatencyMs]
      },
      {
        id: 'exception-rate',
        label: 'Exception Rate',
        value: d.kpis.exceptionRate.toFixed(2),
        unit: '%',
        color: d.kpis.exceptionRate > 1 ? 'danger' : d.kpis.exceptionRate > 0.5 ? 'warning' : 'success',
        subtitle: 'Last 24h',
        trend: [0.18, 0.15, 0.14, 0.13, 0.11, d.kpis.exceptionRate]
      },
      {
        id: 'reco-break-rate',
        label: 'Recon Break Rate',
        value: d.kpis.recoBreakRate.toFixed(2),
        unit: '%',
        color: d.kpis.recoBreakRate > 0.5 ? 'danger' : d.kpis.recoBreakRate > 0.1 ? 'warning' : 'success',
        subtitle: 'Settlement recon',
        trend: [0.05, 0.04, 0.04, 0.03, 0.03, d.kpis.recoBreakRate]
      }
    ];
  }

  private scheduleAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (!this.refreshConfig.isPaused && this.refreshConfig.autoRefresh) {
        this.loadData();
      }
    }, this.refreshConfig.intervalSeconds * 1000);
  }

  onRefresh(): void {
    this.loadData();
  }

  onPauseToggle(): void {
    this.refreshConfig = { ...this.refreshConfig, isPaused: !this.refreshConfig.isPaused };
    this.svc.togglePause();
  }

  onIntervalChange(seconds: number): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    this.refreshConfig = { ...this.refreshConfig, intervalSeconds: seconds };
    this.scheduleAutoRefresh();
  }

  get settlementWindowPct(): number {
    const windowDurationSec = 4 * 3600;
    const elapsed = windowDurationSec - this.data.settlementWindowCountdownSec;
    return Math.min(Math.max(Math.round((elapsed / windowDurationSec) * 100), 0), 100);
  }

  get cycleBarMax(): number {
    if (!this.data?.cycleProgress?.length) return 1;
    return Math.max(...this.data.cycleProgress.map(h => h.count));
  }

  getBarHeightPct(count: number): number {
    const max = this.cycleBarMax;
    return max > 0 ? Math.round((count / max) * 100) : 0;
  }

  getIngestStatusClass(s: string): string {
    const map: Record<string, string> = {
      ok: 'status--ok',
      pending: 'status--pending',
      failed: 'status--failed'
    };
    return map[s] ?? 'status--unknown';
  }

  getWindowStatusClass(s: string): string {
    const map: Record<string, string> = {
      open: 'window-status--open',
      closed: 'window-status--closed',
      suspended: 'window-status--suspended'
    };
    return map[s] ?? '';
  }
}
