import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { KpiCardComponent } from '../kpi-card/kpi-card.component';
import { RailHealthCardComponent } from '../rail-health-card/rail-health-card.component';
import { RefreshBarComponent } from '../refresh-bar/refresh-bar.component';
import { SwiftDashboardData, DashboardKPI, DashboardRefreshConfig, NostroPosition } from '../../../shared/types';
import { DashboardService } from '../../../shared/services/dashboard.service';

@Component({
  selector: 'app-swift-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, KpiCardComponent, RailHealthCardComponent, RefreshBarComponent],
  templateUrl: './swift-dashboard.component.html',
  styleUrls: ['./swift-dashboard.component.scss']
})
export class SwiftDashboardComponent implements OnInit, OnDestroy {

  data!: SwiftDashboardData;
  kpis: DashboardKPI[] = [];
  refreshConfig: DashboardRefreshConfig = {
    autoRefresh: true, intervalSeconds: 30, lastRefreshed: new Date(), isPaused: false
  };
  private refreshTimer: ReturnType<typeof setInterval> | null = null;

  constructor(readonly svc: DashboardService) {}

  ngOnInit(): void { this.loadData(); this.scheduleAutoRefresh(); }
  ngOnDestroy(): void { if (this.refreshTimer) clearInterval(this.refreshTimer); }

  private loadData(): void {
    this.data = this.svc.getSwiftDashboardData();
    this.kpis = this.buildKpis();
    this.refreshConfig = { ...this.refreshConfig, lastRefreshed: new Date() };
  }

  private buildKpis(): DashboardKPI[] {
    const d = this.data;
    return [
      { id: 'gpi-compliance', label: 'GPI Compliance', value: d.kpis.gpiComplianceRatePct, unit: '%',
        color: d.kpis.gpiComplianceRatePct >= 99 ? 'success' : d.kpis.gpiComplianceRatePct >= 97 ? 'warning' : 'danger',
        trend: [98.2, 97.8, 98.1, 97.5, 97.8], subtitle: 'Target ≥ 99%' },
      { id: 'e2e-latency', label: 'E2E Latency', value: this.svc.formatLatency(d.kpis.endToEndLatencyMs), color: 'info' },
      { id: 'dispute-rate', label: 'Dispute Rate', value: d.kpis.disputeRatePct, unit: '%',
        color: d.kpis.disputeRatePct > 0.5 ? 'warning' : 'success', subtitle: 'Target < 0.5%' },
      { id: 'correspondents', label: 'Correspondents', value: d.kpis.correspondentCount, color: 'purple', subtitle: 'Active' },
      { id: 'gpi-pending', label: 'GPI Pending', value: d.gpiPending,
        color: d.gpiPending > 150 ? 'warning' : 'info', subtitle: `${d.gpiConfirmed} confirmed` },
      { id: 'volume', label: 'Net Volume', value: (d.outboundVolume + d.inboundVolume).toLocaleString(),
        unit: 'msgs', color: 'accent', subtitle: `↑${d.outboundVolume} ↓${d.inboundVolume}` }
    ];
  }

  private scheduleAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (!this.refreshConfig.isPaused) this.loadData();
    }, this.refreshConfig.intervalSeconds * 1000);
  }

  onRefresh(): void { this.loadData(); }
  onPauseToggle(): void { this.refreshConfig = { ...this.refreshConfig, isPaused: !this.refreshConfig.isPaused }; }
  onIntervalChange(s: number): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    this.refreshConfig = { ...this.refreshConfig, intervalSeconds: s };
    this.scheduleAutoRefresh();
  }

  getNostroStatusClass(pos: NostroPosition): string {
    return `nostro--${pos.status}`;
  }

  getNostroFillPct(pos: NostroPosition): number {
    return Math.min(Math.round((pos.balance / (pos.threshold * 5)) * 100), 100);
  }

  getGpiComplianceClass(): string {
    const pct = this.data?.kpis.gpiComplianceRatePct ?? 100;
    if (pct >= 99) return 'gpi--green';
    if (pct >= 97) return 'gpi--yellow';
    return 'gpi--red';
  }

  formatBalance(value: number): string {
    if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
    if (value >= 1_000) return `${(value / 1_000).toFixed(0)}K`;
    return value.toString();
  }
}
