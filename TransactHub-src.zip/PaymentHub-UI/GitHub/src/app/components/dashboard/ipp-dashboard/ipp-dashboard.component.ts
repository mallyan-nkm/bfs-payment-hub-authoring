import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { KpiCardComponent } from '../kpi-card/kpi-card.component';
import { RailHealthCardComponent } from '../rail-health-card/rail-health-card.component';
import { RefreshBarComponent } from '../refresh-bar/refresh-bar.component';
import { IppDashboardData, DashboardKPI, DashboardRefreshConfig } from '../../../shared/types';
import { DashboardService } from '../../../shared/services/dashboard.service';

@Component({
  selector: 'app-ipp-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, KpiCardComponent, RailHealthCardComponent, RefreshBarComponent],
  templateUrl: './ipp-dashboard.component.html',
  styleUrls: ['./ipp-dashboard.component.scss']
})
export class IppDashboardComponent implements OnInit, OnDestroy {

  data!: IppDashboardData;
  kpis: DashboardKPI[] = [];
  refreshConfig: DashboardRefreshConfig = {
    autoRefresh: true, intervalSeconds: 30, lastRefreshed: new Date(), isPaused: false
  };
  private refreshTimer: ReturnType<typeof setInterval> | null = null;

  constructor(readonly svc: DashboardService) {}

  ngOnInit(): void { this.loadData(); this.scheduleAutoRefresh(); }
  ngOnDestroy(): void { if (this.refreshTimer) clearInterval(this.refreshTimer); }

  private loadData(): void {
    this.data = this.svc.getIppDashboardData();
    this.kpis = this.buildKpis();
    this.refreshConfig = { ...this.refreshConfig, lastRefreshed: new Date() };
  }

  private buildKpis(): DashboardKPI[] {
    const d = this.data;
    return [
      { id: 'tps', label: 'Throughput/s', value: d.kpis.throughputPerSec, unit: 'tx/s', color: 'accent', trend: [2.8, 3.0, 2.9, 3.2, 3.1] },
      { id: 'p50', label: 'P50 Latency', value: this.svc.formatLatency(d.kpis.latencyP50Ms), color: 'info' },
      { id: 'p95', label: 'P95 Latency', value: this.svc.formatLatency(d.kpis.latencyP95Ms), color: d.kpis.latencyP95Ms > 1000 ? 'warning' : 'info' },
      { id: 'sla', label: 'SLA Compliance', value: d.kpis.successRatePct, unit: '%', color: d.kpis.successRatePct >= 99 ? 'success' : d.kpis.successRatePct >= 97 ? 'warning' : 'danger', trend: [98.8, 94.5, 95.2, 94.8, 94.2] },
      { id: 'pending', label: 'Pending', value: d.kpis.pendingCount, color: d.kpis.pendingCount > 50 ? 'warning' : 'info', subtitle: 'Awaiting processing' }
    ];
  }

  private scheduleAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (!this.refreshConfig.isPaused) this.loadData();
    }, this.refreshConfig.intervalSeconds * 1000);
  }

  onRefresh(): void { this.loadData(); }
  onPauseToggle(): void { this.refreshConfig = { ...this.refreshConfig, isPaused: !this.refreshConfig.isPaused }; }
  onIntervalChange(s: number): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    this.refreshConfig = { ...this.refreshConfig, intervalSeconds: s };
    this.scheduleAutoRefresh();
  }

  get slaColorClass(): string {
    const pct = this.data?.kpis.successRatePct ?? 100;
    if (pct >= 99) return 'sla--green';
    if (pct >= 97) return 'sla--yellow';
    return 'sla--red';
  }

  get cycleBarMax(): number {
    return Math.max(...(this.data?.hourlyVolume.map(h => h.count) ?? [1]));
  }

  getBarHeightPct(count: number): number {
    return Math.round((count / this.cycleBarMax) * 100);
  }
}
