import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { KpiCardComponent } from '../kpi-card/kpi-card.component';
import { RailHealthCardComponent } from '../rail-health-card/rail-health-card.component';
import { RefreshBarComponent } from '../refresh-bar/refresh-bar.component';
import {
  LiveOpsData, DashboardKPI, DashboardRefreshConfig, ExceptionCount
} from '../../../shared/types';
import { DashboardService } from '../../../shared/services/dashboard.service';

@Component({
  selector: 'app-live-ops-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, KpiCardComponent, RailHealthCardComponent, RefreshBarComponent],
  templateUrl: './live-ops-dashboard.component.html',
  styleUrls: ['./live-ops-dashboard.component.scss']
})
export class LiveOpsDashboardComponent implements OnInit, OnDestroy {

  data!: LiveOpsData;
  kpis: DashboardKPI[] = [];
  refreshConfig: DashboardRefreshConfig = {
    autoRefresh: true,
    intervalSeconds: 30,
    lastRefreshed: new Date(),
    isPaused: false
  };

  private refreshTimer: ReturnType<typeof setInterval> | null = null;

  constructor(private svc: DashboardService) {}

  ngOnInit(): void {
    this.loadData();
    this.scheduleAutoRefresh();
  }

  ngOnDestroy(): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  private loadData(): void {
    this.data = this.svc.getLiveOpsData();
    this.kpis = this.buildKpis(this.data);
    this.refreshConfig = { ...this.refreshConfig, lastRefreshed: new Date() };
  }

  private buildKpis(d: LiveOpsData): DashboardKPI[] {
    const totalExceptions = Object.values(d.exceptions).reduce((a, b) => a + b, 0);
    return [
      {
        id: 'in-flight-count',
        label: 'In-Flight Payments',
        value: d.inFlightCount.toLocaleString(),
        unit: 'txns',
        delta: 2.4,
        deltaType: 'up',
        trend: [12000, 13200, 12800, 14100, 13900, 14823],
        color: 'accent',
        subtitle: 'Last 24h',
        clickRoute: '/operations/transactions'
      },
      {
        id: 'in-flight-value',
        label: 'Total Value Processed',
        value: this.svc.formatCurrency(d.inFlightValue, d.inFlightCurrency),
        delta: 4.1,
        deltaType: 'up',
        trend: [2.1, 2.3, 2.6, 2.5, 2.7, 2.85],
        color: 'teal',
        subtitle: 'Last 24h'
      },
      {
        id: 'exceptions',
        label: 'Active Exceptions',
        value: totalExceptions,
        delta: -8.3,
        deltaType: 'down',
        trend: [210, 195, 188, 172, 201, 186],
        color: totalExceptions > 200 ? 'danger' : totalExceptions > 100 ? 'warning' : 'success',
        subtitle: `${d.exceptions.critical} critical`,
        clickRoute: '/exceptions/active'
      },
      {
        id: 'approvals',
        label: 'Pending Approvals',
        value: d.pendingApprovals,
        delta: 5.0,
        deltaType: 'up',
        color: d.pendingApprovals > 50 ? 'warning' : 'info',
        subtitle: 'Awaiting action',
        clickRoute: '/approval/pending'
      },
      {
        id: 'sla-24h',
        label: 'SLA Compliance',
        value: d.slaCompliance24h,
        unit: '%',
        delta: -0.3,
        deltaType: 'down',
        trend: [99.8, 99.5, 99.6, 99.4, 99.1, 99.3],
        color: d.slaCompliance24h >= 99 ? 'success' : d.slaCompliance24h >= 97 ? 'warning' : 'danger',
        subtitle: 'Last 24h'
      },
      {
        id: 'sla-1h',
        label: 'SLA — Last Hour',
        value: d.slaComplianceLastHour,
        unit: '%',
        color: d.slaComplianceLastHour >= 99 ? 'success' : d.slaComplianceLastHour >= 97 ? 'warning' : 'danger',
        subtitle: 'Rolling 60 min'
      }
    ];
  }

  private scheduleAutoRefresh(): void {
    this.refreshTimer = setInterval(() => {
      if (!this.refreshConfig.isPaused && this.refreshConfig.autoRefresh) {
        this.loadData();
      }
    }, this.refreshConfig.intervalSeconds * 1000);
  }

  onRefresh(): void {
    this.loadData();
  }

  onPauseToggle(): void {
    this.refreshConfig = { ...this.refreshConfig, isPaused: !this.refreshConfig.isPaused };
    this.svc.togglePause();
  }

  onIntervalChange(seconds: number): void {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
    this.refreshConfig = { ...this.refreshConfig, intervalSeconds: seconds };
    this.scheduleAutoRefresh();
  }

  get exceptionSummary(): Array<{ label: string; count: number; cls: string }> {
    if (!this.data) return [];
    const e: ExceptionCount = this.data.exceptions;
    return [
      { label: 'Critical', count: e.critical, cls: 'exc--critical' },
      { label: 'High',     count: e.high,     cls: 'exc--high'     },
      { label: 'Medium',   count: e.medium,   cls: 'exc--medium'   },
      { label: 'Low',      count: e.low,      cls: 'exc--low'      }
    ];
  }
}
