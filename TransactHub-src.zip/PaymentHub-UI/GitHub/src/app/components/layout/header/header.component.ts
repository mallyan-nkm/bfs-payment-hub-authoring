import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Rail, UserSession, UserPersona } from '../../../shared/types';

/**
 * HeaderComponent
 * 
 * Fixed header (48px) containing:
 * - Logo with glow effect
 * - Rail switcher (UAEFTS, IPI, IPP, WPS, SWIFT, ALL)
 * - Global search box with keyboard shortcut hint
 * - Icon buttons (notifications, settings, help)
 * - User chip with avatar and persona badge
 * - Session timer
 */
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @Input() activeRail: Rail = Rail.ALL;
  @Input() sessionTimeout: number = 900; // 15 minutes in seconds
  
  @Output() railChanged = new EventEmitter<Rail>();
  @Output() sidebarToggled = new EventEmitter<void>();
  @Output() search = new EventEmitter<string>();
  @Output() settingsClicked = new EventEmitter<void>();
  @Output() helpClicked = new EventEmitter<void>();
  @Output() notificationsClicked = new EventEmitter<void>();
  @Output() userClicked = new EventEmitter<void>();

  // Mock user session (would come from auth service)
  userSession: UserSession = {
    userId: 'USR-001',
    username: 'Ahmed Al Zaabi',
    email: 'ahmed.zaabi@bank.ae',
    persona: UserPersona.OPERATOR,
    persona_display: 'OPS',
    permissions: ['read:all', 'approve:payment'],
    session_start: new Date(),
    session_timeout: 900,
    last_activity: new Date(),
    mfa_verified: true
  };

  // Rail list
  railsList = [
    { id: Rail.ALL, label: 'All Rails' },
    { id: Rail.UAEFTS, label: 'UAEFTS' },
    { id: Rail.IPI, label: 'IPI' },
    { id: Rail.IPP, label: 'IPP' },
    { id: Rail.WPS, label: 'WPS' },
    { id: Rail.SWIFT, label: 'SWIFT' }
  ];

  searchQuery: string = '';
  notificationCount: number = 3;
  timeUntilTimeout: string = '';
  showSessionWarning: boolean = false;

  constructor() {
    this.updateSessionTimer();
    setInterval(() => this.updateSessionTimer(), 1000);
  }

  /**
   * Handle rail selection change
   */
  onRailChange(rail: Rail): void {
    if (this.activeRail !== rail) {
      this.activeRail = rail;
      this.railChanged.emit(rail);
    }
  }

  /**
   * Handle search input
   */
  onSearch(query: string): void {
    this.searchQuery = query;
    if (query.trim().length > 0) {
      this.search.emit(query);
    }
  }

  /**
   * Handle Cmd+K / Ctrl+K keyboard shortcut for search
   */
  onKeyboardShortcut(event: KeyboardEvent): void {
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
      event.preventDefault();
      const searchInput = document.querySelector('.search') as HTMLInputElement;
      if (searchInput) {
        searchInput.focus();
      }
    }
  }

  /**
   * Toggle sidebar visibility
   */
  toggleSidebar(): void {
    this.sidebarToggled.emit();
  }

  /**
   * Update session timeout display
   */
  private updateSessionTimer(): void {
    const remainingSeconds = this.sessionTimeout;
    
    if (remainingSeconds < 120) {
      this.showSessionWarning = true;
    }

    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    this.timeUntilTimeout = `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  /**
   * Handle settings button click
   */
  onSettingsClick(): void {
    this.settingsClicked.emit();
  }

  /**
   * Handle help button click
   */
  onHelpClick(): void {
    this.helpClicked.emit();
  }

  /**
   * Handle notifications button click
   */
  onNotificationsClick(): void {
    this.notificationsClicked.emit();
  }

  /**
   * Handle user chip click
   */
  onUserClick(): void {
    this.userClicked.emit();
  }

  /**
   * Get user avatar initials
   */
  getUserInitials(): string {
    const names = this.userSession.username.split(' ');
    return names.map(n => n.charAt(0).toUpperCase()).join('').substring(0, 2);
  }

  /**
   * Get user persona color/badge
   */
  getPersonaBadgeClass(): string {
    return `persona-${this.userSession.persona.toLowerCase()}`;
  }
}
