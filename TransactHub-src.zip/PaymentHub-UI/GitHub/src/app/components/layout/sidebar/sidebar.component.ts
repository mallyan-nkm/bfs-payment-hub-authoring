import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { Rail, NavigationItem, NavigationSection, BadgeSeverity } from '../../../shared/types';

/**
 * SidebarComponent
 * 
 * Left navigation panel (200px, collapsible to 60px)
 * - Navigation sections: Dashboard, Operations, Approval, Exceptions, Reporting, Admin
 * - Nav items with icons
 * - Hover/active states with left border accent
 * - Badge counts for urgent (red) and warning (yellow) items
 * - Collapse/expand state persistence
 */
@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  @Input() collapsed: boolean = false;
  @Input() activeRail: Rail = Rail.ALL;
  @Input() sidebarCollapsed: boolean = false;

  @Output() navigationClicked = new EventEmitter<NavigationItem>();
  @Output() collapsedChanged = new EventEmitter<boolean>();

  // Navigation structure
  navigationSections: Array<{
    section: NavigationSection;
    label: string;
    items: NavigationItem[];
    expanded: boolean;
  }> = [];

  currentSection: NavigationSection | null = null;

  ngOnInit(): void {
    this.initializeNavigation();
    this.loadCollapsedState();
  }

  /**
   * Initialize navigation structure
   */
  private initializeNavigation(): void {
    this.navigationSections = [
      {
        section: NavigationSection.DASHBOARD,
        label: 'Dashboard',
        expanded: true,
        items: [
          {
            id: 'dashboard-home',
            label: 'Overview',
            icon: 'home',
            route: '/dashboard',
            section: NavigationSection.DASHBOARD,
            permissions: ['read:dashboard']
          },
          {
            id: 'dashboard-kpi',
            label: 'KPI Metrics',
            icon: 'bar-chart-2',
            route: '/dashboard/kpi',
            section: NavigationSection.DASHBOARD,
            permissions: ['read:dashboard']
          },
          {
            id: 'dashboard-system-health',
            label: 'System Health',
            icon: 'activity',
            route: '/dashboard/health',
            section: NavigationSection.DASHBOARD,
            permissions: ['read:dashboard']
          }
        ]
      },
      {
        section: NavigationSection.OPERATIONS,
        label: 'Operations',
        expanded: true,
        items: [
          {
            id: 'ops-queues',
            label: 'Payment Queues',
            icon: 'list',
            route: '/operations/queues',
            section: NavigationSection.OPERATIONS,
            permissions: ['read:operations'],
            badge: { count: 12, severity: BadgeSeverity.WARNING }
          },
          {
            id: 'ops-transactions',
            label: 'Transactions',
            icon: 'send',
            route: '/operations/transactions',
            section: NavigationSection.OPERATIONS,
            permissions: ['read:operations']
          },
          {
            id: 'ops-settlements',
            label: 'Settlements',
            icon: 'check-circle',
            route: '/operations/settlements',
            section: NavigationSection.OPERATIONS,
            permissions: ['read:operations']
          },
          {
            id: 'ops-rail-health',
            label: 'Rail Status',
            icon: 'trending-up',
            route: '/operations/rail-health',
            section: NavigationSection.OPERATIONS,
            permissions: ['read:operations']
          }
        ]
      },
      {
        section: NavigationSection.APPROVAL,
        label: 'Approvals',
        expanded: true,
        items: [
          {
            id: 'approval-pending',
            label: 'Pending',
            icon: 'clock',
            route: '/approval/pending',
            section: NavigationSection.APPROVAL,
            permissions: ['read:approval'],
            badge: { count: 5, severity: BadgeSeverity.URGENT }
          },
          {
            id: 'approval-history',
            label: 'History',
            icon: 'history',
            route: '/approval/history',
            section: NavigationSection.APPROVAL,
            permissions: ['read:approval']
          },
          {
            id: 'approval-delegations',
            label: 'Delegations',
            icon: 'share-2',
            route: '/approval/delegations',
            section: NavigationSection.APPROVAL,
            permissions: ['read:approval']
          }
        ]
      },
      {
        section: NavigationSection.EXCEPTIONS,
        label: 'Exceptions',
        expanded: true,
        items: [
          {
            id: 'exc-active',
            label: 'Active Issues',
            icon: 'alert-circle',
            route: '/exceptions/active',
            section: NavigationSection.EXCEPTIONS,
            permissions: ['read:exceptions'],
            badge: { count: 8, severity: BadgeSeverity.URGENT }
          },
          {
            id: 'exc-investigation',
            label: 'Investigation',
            icon: 'search',
            route: '/exceptions/investigation',
            section: NavigationSection.EXCEPTIONS,
            permissions: ['read:exceptions']
          },
          {
            id: 'exc-resolution',
            label: 'Resolution Queue',
            icon: 'check',
            route: '/exceptions/resolution',
            section: NavigationSection.EXCEPTIONS,
            permissions: ['read:exceptions']
          }
        ]
      },
      {
        section: NavigationSection.REPORTING,
        label: 'Reporting',
        expanded: false,
        items: [
          {
            id: 'report-operational',
            label: 'Operational Reports',
            icon: 'file-text',
            route: '/reporting/operational',
            section: NavigationSection.REPORTING,
            permissions: ['read:reports']
          },
          {
            id: 'report-regulatory',
            label: 'Regulatory Reports',
            icon: 'shield',
            route: '/reporting/regulatory',
            section: NavigationSection.REPORTING,
            permissions: ['read:reports']
          },
          {
            id: 'report-analytics',
            label: 'Analytics',
            icon: 'pie-chart',
            route: '/reporting/analytics',
            section: NavigationSection.REPORTING,
            permissions: ['read:reports']
          }
        ]
      },
      {
        section: NavigationSection.ADMIN,
        label: 'Administration',
        expanded: false,
        items: [
          {
            id: 'admin-users',
            label: 'User Management',
            icon: 'users',
            route: '/admin/users',
            section: NavigationSection.ADMIN,
            permissions: ['admin:users']
          },
          {
            id: 'admin-settings',
            label: 'Settings',
            icon: 'settings',
            route: '/admin/settings',
            section: NavigationSection.ADMIN,
            permissions: ['admin:settings']
          },
          {
            id: 'admin-audit',
            label: 'Audit Logs',
            icon: 'log',
            route: '/admin/audit',
            section: NavigationSection.ADMIN,
            permissions: ['admin:audit']
          }
        ]
      }
    ];
  }

  /**
   * Toggle section expansion
   */
  toggleSection(section: NavigationSection): void {
    const sectionObj = this.navigationSections.find(s => s.section === section);
    if (sectionObj) {
      sectionObj.expanded = !sectionObj.expanded;
      this.saveSectionState();
    }
  }

  /**
   * Handle navigation item click
   */
  onNavigationClick(item: NavigationItem): void {
    this.currentSection = item.section;
    this.navigationClicked.emit(item);
  }

  /**
   * Check if section is expanded
   */
  isSectionExpanded(section: NavigationSection): boolean {
    return this.navigationSections.find(s => s.section === section)?.expanded ?? true;
  }

  /**
   * Toggle sidebar collapse state
   */
  toggleSidebar(): void {
    this.collapsed = !this.collapsed;
    this.collapsedChanged.emit(this.collapsed);
    this.saveCollapsedState();
  }

  /**
   * Save section expanded/collapsed state
   */
  private saveSectionState(): void {
    try {
      const state: Record<string, boolean> = {};
      this.navigationSections.forEach(section => {
        state[section.section] = section.expanded;
      });
      localStorage.setItem('sidebarSections', JSON.stringify(state));
    } catch (error) {
      console.warn('Failed to save section state:', error);
    }
  }

  /**
   * Load saved section state
   */
  private loadCollapsedState(): void {
    try {
      const saved = localStorage.getItem('sidebarSections');
      if (saved) {
        const state = JSON.parse(saved) as Record<string, boolean>;
        this.navigationSections.forEach(section => {
          if (section.section in state) {
            section.expanded = state[section.section];
          }
        });
      }
    } catch (error) {
      console.warn('Failed to load section state:', error);
    }
  }

  /**
   * Save collapsed state
   */
  private saveCollapsedState(): void {
    try {
      localStorage.setItem('sidebarCollapsed', JSON.stringify(this.collapsed));
    } catch (error) {
      console.warn('Failed to save collapsed state:', error);
    }
  }

  /**
   * Get badge color class
   */
  getBadgeClass(severity: BadgeSeverity): string {
    return `badge-${severity}`;
  }

  /**
   * Get icon SVG (placeholder - would use icon library)
   */
  getIconPath(icon: string): string {
    // Placeholder - in production use a real icon library
    return `/assets/icons/${icon}.svg`;
  }
}
