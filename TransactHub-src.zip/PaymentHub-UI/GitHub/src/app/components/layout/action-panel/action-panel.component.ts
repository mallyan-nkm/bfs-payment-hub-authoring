import { Component, Input, Output, EventEmitter, ContentChild, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActionPanelContext, ActionItem } from '../../../shared/types';

/**
 * ActionPanelComponent
 * 
 * Right-side context panel (320px, collapsible)
 * - Context-sensitive actions
 * - Quick actions
 * - Form actions
 * - Context information
 * - Collapsible state persistence
 */
@Component({
  selector: 'app-action-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './action-panel.component.html',
  styleUrls: ['./action-panel.component.scss']
})
export class ActionPanelComponent {
  @Input() collapsed: boolean = false;
  @Input() context: ActionPanelContext | null = null;
  @Input() actions: ActionItem[] = [];
  @Input() title: string = 'Actions';
  @Input() description: string = '';

  @Output() panelToggled = new EventEmitter<void>();
  @Output() actionClicked = new EventEmitter<ActionItem>();

  // Template for custom action content
  @ContentChild('actionContent') actionContent: TemplateRef<any> | null = null;

  /**
   * Toggle action panel collapse state
   */
  togglePanel(): void {
    this.collapsed = !this.collapsed;
    this.panelToggled.emit();
    this.saveCollapsedState();
  }

  /**
   * Handle action click
   */
  onActionClick(action: ActionItem): void {
    if (!action.disabled && !action.loading) {
      this.actionClicked.emit(action);
    }
  }

  /**
   * Get action button class
   */
  getActionButtonClass(action: ActionItem): string {
    return `action-btn action-btn-${action.type}`;
  }

  /**
   * Save collapsed state to localStorage
   */
  private saveCollapsedState(): void {
    try {
      localStorage.setItem('actionPanelCollapsed', JSON.stringify(this.collapsed));
    } catch (error) {
      console.warn('Failed to save action panel state:', error);
    }
  }

  /**
   * Load collapsed state from localStorage
   */
  loadCollapsedState(): void {
    try {
      const saved = localStorage.getItem('actionPanelCollapsed');
      if (saved) {
        this.collapsed = JSON.parse(saved);
      }
    } catch (error) {
      console.warn('Failed to load action panel state:', error);
    }
  }

  constructor() {
    this.loadCollapsedState();
  }
}
