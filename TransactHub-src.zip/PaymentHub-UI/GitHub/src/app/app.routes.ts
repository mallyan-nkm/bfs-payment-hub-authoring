import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./components/dashboard/live-ops-dashboard/live-ops-dashboard.component')
            .then(m => m.LiveOpsDashboardComponent)
      },
      {
        path: 'uaefts',
        loadComponent: () =>
          import('./components/dashboard/uaefts-dashboard/uaefts-dashboard.component')
            .then(m => m.UaeftsDashboardComponent)
      },
      {
        path: 'ipi',
        loadComponent: () =>
          import('./components/dashboard/ipi-dashboard/ipi-dashboard.component')
            .then(m => m.IpiDashboardComponent)
      },
      {
        path: 'ipp',
        loadComponent: () =>
          import('./components/dashboard/ipp-dashboard/ipp-dashboard.component')
            .then(m => m.IppDashboardComponent)
      },
      {
        path: 'wps',
        loadComponent: () =>
          import('./components/dashboard/wps-dashboard/wps-dashboard.component')
            .then(m => m.WpsDashboardComponent)
      },
      {
        path: 'swift',
        loadComponent: () =>
          import('./components/dashboard/swift-dashboard/swift-dashboard.component')
            .then(m => m.SwiftDashboardComponent)
      }
    ]
  },
  {
    path: 'operations',
    children: [
      { path: 'queues', loadComponent: () => import('./components/dashboard/live-ops-dashboard/live-ops-dashboard.component').then(m => m.LiveOpsDashboardComponent) },
      { path: 'transactions', loadComponent: () => import('./components/dashboard/live-ops-dashboard/live-ops-dashboard.component').then(m => m.LiveOpsDashboardComponent) }
    ]
  },
  {
    path: '**',
    redirectTo: 'dashboard'
  }
];
