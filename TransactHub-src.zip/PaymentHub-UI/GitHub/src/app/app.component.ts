import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, Router } from '@angular/router';
import { HeaderComponent } from './components/layout/header/header.component';
import { SidebarComponent } from './components/layout/sidebar/sidebar.component';
import { MainPanelComponent } from './components/layout/main-panel/main-panel.component';
import { ActionPanelComponent } from './components/layout/action-panel/action-panel.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { Rail, LayoutState, Breadcrumb } from './shared/types';

const RAIL_ROUTES: Partial<Record<Rail, string>> = {
  [Rail.ALL]:    '/dashboard',
  [Rail.UAEFTS]: '/dashboard/uaefts',
  [Rail.IPI]:    '/dashboard/ipi',
  [Rail.IPP]:    '/dashboard/ipp',
  [Rail.WPS]:    '/dashboard/wps',
  [Rail.SWIFT]:  '/dashboard/swift'
};

const RAIL_BREADCRUMBS: Partial<Record<Rail, Breadcrumb[]>> = {
  [Rail.ALL]:    [{ label: 'Dashboard', route: '/dashboard', current: true }],
  [Rail.UAEFTS]: [{ label: 'Dashboard', route: '/dashboard' }, { label: 'UAEFTS', current: true }],
  [Rail.IPI]:    [{ label: 'Dashboard', route: '/dashboard' }, { label: 'IPI / Aani', current: true }],
  [Rail.IPP]:    [{ label: 'Dashboard', route: '/dashboard' }, { label: 'IPP', current: true }],
  [Rail.WPS]:    [{ label: 'Dashboard', route: '/dashboard' }, { label: 'WPS', current: true }],
  [Rail.SWIFT]:  [{ label: 'Dashboard', route: '/dashboard' }, { label: 'SWIFT', current: true }]
};

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    HeaderComponent,
    SidebarComponent,
    MainPanelComponent,
    ActionPanelComponent,
    FooterComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'PaymentHub Operations Console';

  layoutState: LayoutState = {
    sidebarCollapsed: false,
    actionPanelCollapsed: false,
    activeRail: Rail.ALL,
    breadcrumbs: RAIL_BREADCRUMBS[Rail.ALL]
  };

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.loadLayoutState();
  }

  onRailChange(rail: Rail): void {
    this.layoutState.activeRail = rail;
    this.layoutState.breadcrumbs = RAIL_BREADCRUMBS[rail] ?? RAIL_BREADCRUMBS[Rail.ALL];
    this.saveLayoutState();
    const route = RAIL_ROUTES[rail] ?? '/dashboard';
    this.router.navigate([route]);
  }

  onToggleSidebar(): void {
    this.layoutState.sidebarCollapsed = !this.layoutState.sidebarCollapsed;
    this.saveLayoutState();
  }

  onToggleActionPanel(): void {
    this.layoutState.actionPanelCollapsed = !this.layoutState.actionPanelCollapsed;
    this.saveLayoutState();
  }

  private loadLayoutState(): void {
    try {
      const saved = localStorage.getItem('layoutState');
      if (saved) {
        this.layoutState = { ...this.layoutState, ...JSON.parse(saved) };
      }
    } catch {
      // Silently ignore — fall back to defaults
    }
  }

  private saveLayoutState(): void {
    try {
      localStorage.setItem('layoutState', JSON.stringify(this.layoutState));
    } catch {
      // LocalStorage unavailable — no-op
    }
  }
}
