import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  Rail, StatusIndicator,
  LiveOpsData, RailHealth,
  UaeftsDashboardData, IpiDashboardData, IppDashboardData,
  WpsDashboardData, SwiftDashboardData,
  DashboardRefreshConfig
} from '../types';

@Injectable({ providedIn: 'root' })
export class DashboardService {

  private refreshConfig$ = new BehaviorSubject<DashboardRefreshConfig>({
    autoRefresh: true,
    intervalSeconds: 30,
    lastRefreshed: new Date(),
    isPaused: false
  });

  getRefreshConfig(): Observable<DashboardRefreshConfig> {
    return this.refreshConfig$.asObservable();
  }

  togglePause(): void {
    const cfg = this.refreshConfig$.getValue();
    this.refreshConfig$.next({ ...cfg, isPaused: !cfg.isPaused });
  }

  markRefreshed(): void {
    const cfg = this.refreshConfig$.getValue();
    this.refreshConfig$.next({ ...cfg, lastRefreshed: new Date() });
  }

  setInterval(seconds: number): void {
    const cfg = this.refreshConfig$.getValue();
    this.refreshConfig$.next({ ...cfg, intervalSeconds: seconds });
  }

  // ─── Live Operations Dashboard (§8.1) ───────────────────────────────────

  getLiveOpsData(): LiveOpsData {
    return {
      inFlightCount: 14_823,
      inFlightValue: 2_847_500_000,
      inFlightCurrency: 'AED',
      exceptions: { critical: 3, high: 12, medium: 47, low: 124 },
      pendingApprovals: 28,
      slaCompliance24h: 99.3,
      slaComplianceLastHour: 98.7,
      railHealth: this.getAllRailHealth(),
      lastUpdated: new Date()
    };
  }

  getAllRailHealth(): RailHealth[] {
    return [
      {
        rail: Rail.UAEFTS,
        status: StatusIndicator.OPERATIONAL,
        throughput: 142,
        throughputTypical: 160,
        latency_p50: 380,
        latency_p95: 820,
        latency_p99: 1240,
        error_rate: 0.12,
        open_exceptions: 7,
        last_updated: new Date()
      },
      {
        rail: Rail.IPI,
        status: StatusIndicator.OPERATIONAL,
        throughput: 1847,
        throughputTypical: 2000,
        latency_p50: 180,
        latency_p95: 420,
        latency_p99: 680,
        error_rate: 0.05,
        open_exceptions: 3,
        last_updated: new Date()
      },
      {
        rail: Rail.IPP,
        status: StatusIndicator.DEGRADED,
        throughput: 312,
        throughputTypical: 500,
        latency_p50: 540,
        latency_p95: 1200,
        latency_p99: 2100,
        error_rate: 0.48,
        open_exceptions: 19,
        last_updated: new Date()
      },
      {
        rail: Rail.WPS,
        status: StatusIndicator.OPERATIONAL,
        throughput: 48,
        throughputTypical: 50,
        latency_p50: 1200,
        latency_p95: 3400,
        latency_p99: 5200,
        error_rate: 0.08,
        open_exceptions: 2,
        last_updated: new Date()
      },
      {
        rail: Rail.SWIFT,
        status: StatusIndicator.OPERATIONAL,
        throughput: 76,
        throughputTypical: 80,
        latency_p50: 4200,
        latency_p95: 12000,
        latency_p99: 28000,
        error_rate: 0.21,
        open_exceptions: 5,
        last_updated: new Date()
      }
    ];
  }

  // ─── UAEFTS Rail Dashboard (§8.2) ───────────────────────────────────────

  getUaeftsDashboardData(): UaeftsDashboardData {
    return {
      cb103OutboundCount: 3_284,
      cb103InboundCount: 2_917,
      cb202Count: 891,
      cb202CovCount: 124,
      cb101UfpCount: 47,
      settlementWindowStatus: 'open',
      settlementWindowCountdownSec: 4320,
      cycleProgress: this.generateHourlyVolume(14, 200, 400),
      cb940IngestStatus: 'ok',
      cb950IngestStatus: 'ok',
      treasuryVolume: 1_240_000_000,
      customerVolume: 987_000_000,
      kpis: {
        dispatchLatencyMs: 380,
        settlementConfirmLatencyMs: 820,
        exceptionRate: 0.12,
        recoBreakRate: 0.03
      },
      railHealth: this.getAllRailHealth().find(r => r.rail === Rail.UAEFTS)!,
      lastUpdated: new Date()
    };
  }

  // ─── IPI/Aani Rail Dashboard (§8.2) ─────────────────────────────────────

  getIpiDashboardData(): IpiDashboardData {
    return {
      volumePerSecond: 18.4,
      volumePerMinute: 1105,
      subSecondSlaCompliancePct: 99.72,
      aaniAliasResolutionHealth: StatusIndicator.OPERATIONAL,
      copHealth: StatusIndicator.OPERATIONAL,
      hourlyVolume: this.generateHourlyVolume(14, 800, 2200),
      kpis: {
        throughputPerSec: 18.4,
        latencyP50Ms: 180,
        latencyP95Ms: 420,
        latencyP99Ms: 680,
        instantConfirmRatePct: 99.72
      },
      railHealth: this.getAllRailHealth().find(r => r.rail === Rail.IPI)!,
      lastUpdated: new Date()
    };
  }

  // ─── IPP Rail Dashboard (§8.2) ──────────────────────────────────────────

  getIppDashboardData(): IppDashboardData {
    return {
      volumePerSecond: 3.1,
      volumePerMinute: 188,
      slaCompliancePct: 94.2,
      hourlyVolume: this.generateHourlyVolume(14, 150, 450),
      kpis: {
        throughputPerSec: 3.1,
        latencyP50Ms: 540,
        latencyP95Ms: 1200,
        successRatePct: 94.2,
        pendingCount: 38
      },
      railHealth: this.getAllRailHealth().find(r => r.rail === Rail.IPP)!,
      lastUpdated: new Date()
    };
  }

  // ─── WPS Rail Dashboard (§8.2) ──────────────────────────────────────────

  getWpsDashboardData(): WpsDashboardData {
    return {
      activeFiles: [
        { fileType: 'SIF', count: 142, status: 'processing' },
        { fileType: 'PIF', count: 87,  status: 'processing' },
        { fileType: 'DIF', count: 23,  status: 'completed' },
        { fileType: 'RFA', count: 11,  status: 'pending' },
        { fileType: 'RTC', count: 4,   status: 'processing' }
      ],
      refundFlows: [
        { flowType: 'RFR', count: 18, status: 'active' },
        { flowType: 'RRI', count: 7,  status: 'pending' },
        { flowType: 'RRR', count: 3,  status: 'active' },
        { flowType: 'DCR', count: 12, status: 'completed' },
        { flowType: 'RSU', count: 5,  status: 'active' }
      ],
      mohreComplianceStatus: 'compliant',
      employerEstablishments: 4_827,
      kpis: {
        fileCompletionRatePct: 96.8,
        employeeCreditSuccessRatePct: 99.1,
        activeCycles: 3,
        failedCredits: 42,
        totalEmployeesCredited: 48_293
      },
      railHealth: this.getAllRailHealth().find(r => r.rail === Rail.WPS)!,
      lastUpdated: new Date()
    };
  }

  // ─── SWIFT Rail Dashboard (§8.2) ────────────────────────────────────────

  getSwiftDashboardData(): SwiftDashboardData {
    return {
      outboundVolume: 1_284,
      inboundVolume: 943,
      gpiSubscriptions: 847,
      gpiPending: 124,
      gpiConfirmed: 723,
      fxLegHealth: StatusIndicator.OPERATIONAL,
      nostroCurrencies: [
        { currency: 'USD', balance: 48_200_000, threshold: 10_000_000, status: 'adequate' },
        { currency: 'EUR', balance: 31_400_000, threshold: 8_000_000,  status: 'adequate' },
        { currency: 'GBP', balance: 7_100_000,  threshold: 5_000_000,  status: 'low' },
        { currency: 'JPY', balance: 2_800_000,  threshold: 3_000_000,  status: 'critical' },
        { currency: 'CHF', balance: 12_300_000, threshold: 4_000_000,  status: 'adequate' }
      ],
      kpis: {
        gpiComplianceRatePct: 97.8,
        endToEndLatencyMs: 4200,
        disputeRatePct: 0.21,
        correspondentCount: 84
      },
      railHealth: this.getAllRailHealth().find(r => r.rail === Rail.SWIFT)!,
      lastUpdated: new Date()
    };
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────

  private generateHourlyVolume(currentHour: number, min: number, max: number) {
    return Array.from({ length: currentHour + 1 }, (_, i) => ({
      hour: i,
      count: Math.floor(Math.random() * (max - min) + min)
    }));
  }

  formatCurrency(value: number, currency = 'AED'): string {
    if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2)}B ${currency}`;
    if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M ${currency}`;
    if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K ${currency}`;
    return `${value} ${currency}`;
  }

  formatCountdown(seconds: number): string {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m ${s.toString().padStart(2, '0')}s`;
  }

  formatLatency(ms: number): string {
    if (ms >= 1000) return `${(ms / 1000).toFixed(1)}s`;
    return `${ms}ms`;
  }

  getThroughputPct(current: number, typical: number): number {
    return Math.min(Math.round((current / typical) * 100), 100);
  }
}
