/**
 * Shared Types and Interfaces for PaymentHub Operations Console
 */

// ─── Core Enums ─────────────────────────────────────────────────────────────

export enum Rail {
  UAEFTS = 'UAEFTS',
  IPI = 'IPI',
  IPP = 'IPP',
  WPS = 'WPS',
  SWIFT = 'SWIFT',
  ALL = 'ALL'
}

export enum UserPersona {
  OPERATOR = 'OPERATOR',
  MANAGER = 'MANAGER',
  EXECUTIVE = 'EXECUTIVE',
  ADMINISTRATOR = 'ADMINISTRATOR',
  RISK_OFFICER = 'RISK_OFFICER',
  COMPLIANCE_OFFICER = 'COMPLIANCE_OFFICER'
}

export enum NavigationSection {
  DASHBOARD = 'dashboard',
  OPERATIONS = 'operations',
  APPROVAL = 'approval',
  EXCEPTIONS = 'exceptions',
  REPORTING = 'reporting',
  ADMIN = 'admin'
}

export enum StatusIndicator {
  OPERATIONAL = 'operational',
  DEGRADED = 'degraded',
  OUTAGE = 'outage',
  UNKNOWN = 'unknown'
}

export enum BadgeSeverity {
  URGENT = 'urgent',
  WARNING = 'warning',
  INFO = 'info'
}

export enum ExceptionSeverity {
  CRITICAL = 'critical',
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low'
}

// ─── Phase 1 Interfaces ──────────────────────────────────────────────────────

export interface NavigationItem {
  id: string;
  label: string;
  icon: string;
  route: string;
  section: NavigationSection;
  badge?: NavigationBadge;
  children?: NavigationItem[];
  hidden?: boolean;
  permissions?: string[];
}

export interface NavigationBadge {
  count: number;
  severity: BadgeSeverity;
}

export interface UserSession {
  userId: string;
  username: string;
  email: string;
  avatar?: string;
  persona: UserPersona;
  persona_display: string;
  permissions: string[];
  session_start: Date;
  session_timeout: number;
  last_activity: Date;
  mfa_verified: boolean;
}

export interface RailHealth {
  rail: Rail;
  status: StatusIndicator;
  throughput: number;
  throughputTypical?: number;
  latency_p50?: number;
  latency_p95?: number;
  latency_p99?: number;
  error_rate?: number;
  open_exceptions?: number;
  last_updated: Date;
}

export interface KPIMetric {
  id: string;
  label: string;
  value: string | number;
  delta?: number;
  deltaType?: 'up' | 'down' | 'neutral';
  unit?: string;
  color?: 'accent' | 'success' | 'warning' | 'danger' | 'info' | 'purple' | 'teal';
}

export interface Breadcrumb {
  label: string;
  route?: string;
  current?: boolean;
}

export interface ActionPanelContext {
  title: string;
  description?: string;
  actions: ActionItem[];
  quickInfo?: Record<string, any>;
}

export interface ActionItem {
  id: string;
  label: string;
  icon?: string;
  type: 'primary' | 'secondary' | 'danger';
  disabled?: boolean;
  loading?: boolean;
}

export interface LayoutState {
  sidebarCollapsed: boolean;
  actionPanelCollapsed: boolean;
  activeRail: Rail;
  activeNavSection?: NavigationSection;
  breadcrumbs?: Breadcrumb[];
}

// ─── Phase 2 — Dashboard Data Models ────────────────────────────────────────

export interface DashboardKPI {
  id: string;
  label: string;
  value: number | string;
  unit?: string;
  delta?: number;
  deltaType?: 'up' | 'down' | 'neutral';
  trend?: number[];
  color?: 'accent' | 'success' | 'warning' | 'danger' | 'info' | 'purple' | 'teal';
  icon?: string;
  subtitle?: string;
  clickRoute?: string;
}

export interface ExceptionCount {
  critical: number;
  high: number;
  medium: number;
  low: number;
}

export interface LiveOpsData {
  inFlightCount: number;
  inFlightValue: number;
  inFlightCurrency: string;
  exceptions: ExceptionCount;
  pendingApprovals: number;
  slaCompliance24h: number;
  slaComplianceLastHour: number;
  railHealth: RailHealth[];
  lastUpdated: Date;
}

export interface HourlyVolume {
  hour: number;
  count: number;
}

export interface UaeftsDashboardData {
  cb103OutboundCount: number;
  cb103InboundCount: number;
  cb202Count: number;
  cb202CovCount: number;
  cb101UfpCount: number;
  settlementWindowStatus: 'open' | 'closed' | 'suspended';
  settlementWindowCountdownSec: number;
  cycleProgress: HourlyVolume[];
  cb940IngestStatus: 'ok' | 'pending' | 'failed';
  cb950IngestStatus: 'ok' | 'pending' | 'failed';
  treasuryVolume: number;
  customerVolume: number;
  kpis: {
    dispatchLatencyMs: number;
    settlementConfirmLatencyMs: number;
    exceptionRate: number;
    recoBreakRate: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface IpiDashboardData {
  volumePerSecond: number;
  volumePerMinute: number;
  subSecondSlaCompliancePct: number;
  aaniAliasResolutionHealth: StatusIndicator;
  copHealth: StatusIndicator;
  hourlyVolume: HourlyVolume[];
  kpis: {
    throughputPerSec: number;
    latencyP50Ms: number;
    latencyP95Ms: number;
    latencyP99Ms: number;
    instantConfirmRatePct: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface IppDashboardData {
  volumePerSecond: number;
  volumePerMinute: number;
  slaCompliancePct: number;
  hourlyVolume: HourlyVolume[];
  kpis: {
    throughputPerSec: number;
    latencyP50Ms: number;
    latencyP95Ms: number;
    successRatePct: number;
    pendingCount: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface WpsFile {
  fileType: 'SIF' | 'PIF' | 'DIF' | 'RFA' | 'RTC';
  count: number;
  status: 'processing' | 'completed' | 'failed' | 'pending';
}

export interface WpsRefundFlow {
  flowType: 'RFR' | 'RRI' | 'RRR' | 'DCR' | 'RSU';
  count: number;
  status: 'active' | 'pending' | 'completed';
}

export interface WpsDashboardData {
  activeFiles: WpsFile[];
  refundFlows: WpsRefundFlow[];
  mohreComplianceStatus: 'compliant' | 'non-compliant' | 'pending';
  employerEstablishments: number;
  kpis: {
    fileCompletionRatePct: number;
    employeeCreditSuccessRatePct: number;
    activeCycles: number;
    failedCredits: number;
    totalEmployeesCredited: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface NostroPosition {
  currency: string;
  balance: number;
  threshold: number;
  status: 'adequate' | 'low' | 'critical';
}

export interface SwiftDashboardData {
  outboundVolume: number;
  inboundVolume: number;
  gpiSubscriptions: number;
  gpiPending: number;
  gpiConfirmed: number;
  fxLegHealth: StatusIndicator;
  nostroCurrencies: NostroPosition[];
  kpis: {
    gpiComplianceRatePct: number;
    endToEndLatencyMs: number;
    disputeRatePct: number;
    correspondentCount: number;
  };
  railHealth: RailHealth;
  lastUpdated: Date;
}

export interface DashboardRefreshConfig {
  autoRefresh: boolean;
  intervalSeconds: number;
  lastRefreshed: Date;
  isPaused: boolean;
}
