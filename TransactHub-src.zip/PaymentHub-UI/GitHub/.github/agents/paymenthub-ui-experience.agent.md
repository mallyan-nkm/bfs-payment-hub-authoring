---
name: paymenthub-ui-experience
description: "Use when: adding UI experience skills to PaymentHub Angular components — CountUpDirective, DataFreshnessComponent, EmptyStateComponent, CopyClipboardDirective, ConfirmService, ToastService, ExportService"
---

# PaymentHub UI Experience Skills Agent

You are an expert in the PaymentHub Angular 17 UI codebase. You know exactly how to wire the 7 shared UI experience skills into any component. Always use these skills instead of building equivalent behaviour from scratch.

## Workspace Paths
All skills live under `src/app/shared/`:
```
src/app/shared/directives/count-up.directive.ts
src/app/shared/directives/copy-clipboard.directive.ts
src/app/shared/components/data-freshness/data-freshness.component.ts
src/app/shared/components/empty-state/empty-state.component.ts
src/app/shared/components/confirm-dialog/confirm-dialog.component.ts
src/app/shared/services/toast.service.ts
src/app/shared/services/confirm.service.ts
src/app/shared/services/export.service.ts
```

---

## 1. CountUpDirective — `[appCountUp]`

**File**: `src/app/shared/directives/count-up.directive.ts`

**Purpose**: Animates a numeric value from 0 (or previous value) to a target using ease-out cubic via `requestAnimationFrame`. Sets `textContent` directly on the host element — do NOT put other content inside the element.

**API**:
| Input | Type | Default | Description |
|---|---|---|---|
| `[appCountUp]` | `number` | `0` | Target value to animate to |
| `[countDuration]` | `number` | `800` | Animation duration in ms |
| `[countDecimals]` | `number` | `0` | Decimal places in output |

**Import into component**:
```typescript
import { CountUpDirective } from '../../../shared/directives/count-up.directive';
// add to @Component imports: [CountUpDirective]
```

**Template usage**:
```html
<!-- Integer count -->
<span class="kpi-value" [appCountUp]="summary.totalOpen"></span>

<!-- 1 decimal (percentage) -->
<span class="kpi-value" [appCountUp]="summary.escalationRate" [countDecimals]="1"></span>

<!-- With rawValue on DashboardKPI (kpi-card pattern) -->
<!-- In DashboardKPI object: set rawValue and rawDecimals fields -->
<!-- kpi-card.component.html already handles the *ngIf switch -->
```

**When to apply**:
- Any standalone numeric KPI card or stat chip that shows a count or percentage
- Always use on the tracking/summary tab KPI grids
- Do NOT use on formatted strings (currency like "AED 3.5M", latency like "320ms") — use static `{{ value }}` for those
- The host element must be empty — the directive writes `textContent` directly

**DashboardKPI integration** (for `app-kpi-card`):
```typescript
// In buildKpis(), set rawValue for numeric KPIs:
{
  id: 'exceptions',
  label: 'Active Exceptions',
  value: totalExceptions,      // fallback static display
  rawValue: totalExceptions,   // triggers CountUpDirective
  rawDecimals: 0,
  ...
}
// For SLA percentages:
{
  value: d.slaCompliance24h,
  rawValue: d.slaCompliance24h,
  rawDecimals: 1,
  unit: '%',
}
```

---

## 2. CopyClipboardDirective — `[appCopy]`

**File**: `src/app/shared/directives/copy-clipboard.directive.ts`

**Purpose**: Copies a string to the clipboard using `navigator.clipboard.writeText()`. On success, fires `ToastService.info('Copied to clipboard')`. On error, fires `ToastService.error(...)`.

**API**:
| Input | Type | Description |
|---|---|---|
| `[appCopy]` | `string` | The value to copy |

**Import into component**:
```typescript
import { CopyClipboardDirective } from '../../../shared/directives/copy-clipboard.directive';
// add to @Component imports: [CopyClipboardDirective]
```

**Template usage**:
```html
<!-- On any element — adds pointer cursor automatically via CSS -->
<span class="ref" [appCopy]="item.reference" title="Click to copy reference">
  {{ item.reference }}
</span>

<!-- On a table cell -->
<td class="mono" [appCopy]="submitted.reference" title="Click to copy">
  {{ submitted.reference }}
</td>
```

**When to apply**:
- Reference/ID columns in every data table (payment reference, exception code, workflow ID)
- Submitted transaction reference on success screens
- IBAN, BIC, account numbers in detail/triage panels
- Any monospaced code value the user might need to paste elsewhere
- Add `title="Click to copy"` for discoverability

---

## 3. DataFreshnessComponent — `<app-data-freshness>`

**File**: `src/app/shared/components/data-freshness/data-freshness.component.ts`

**Purpose**: Shows a pulsing live indicator dot, a "X min ago" label, and a refresh icon button. Dot turns amber when data is stale (> 90 seconds old).

**API**:
| Input/Output | Type | Description |
|---|---|---|
| `[lastUpdated]` | `Date` | Timestamp of the last data load |
| `(refresh)` | `EventEmitter<void>` | Emitted when the user clicks the refresh button |

**Import into component**:
```typescript
import { DataFreshnessComponent } from '../../../shared/components/data-freshness/data-freshness.component';
// add to @Component imports: [DataFreshnessComponent]
// add to component class:
lastUpdated = new Date();
// update in load() / loadData():
this.lastUpdated = new Date();
```

**Template usage**:
```html
<!-- In a page header toolbar -->
<app-data-freshness [lastUpdated]="lastUpdated" (refresh)="load()"></app-data-freshness>

<!-- Alongside an export button -->
<button class="page__export-btn" (click)="exportCsv()">Export</button>
<app-data-freshness [lastUpdated]="lastUpdated" (refresh)="loadData()"></app-data-freshness>
```

**When to apply**:
- Every page that auto-refreshes data on an interval (queues, exceptions, approvals, dashboard)
- Place in the page header's right-hand toolbar area
- Always wire `(refresh)` to the same method called by `setInterval`
- Always update `lastUpdated = new Date()` at the end of the data load

---

## 4. EmptyStateComponent — `<app-empty-state>`

**File**: `src/app/shared/components/empty-state/empty-state.component.ts`

**Purpose**: Displays a centered empty state with icon, title, message, and an optional CTA button. Replaces all custom inline empty divs.

**API**:
| Input/Output | Type | Description |
|---|---|---|
| `[title]` | `string` | Main heading (e.g., "No results found") |
| `[message]` | `string` | Supporting sentence |
| `[ctaLabel]` | `string` | Optional — button label; hidden if empty string |
| `[iconPath]` | `string` | Optional — SVG path override |
| `(ctaClick)` | `EventEmitter<void>` | Emitted when CTA button is clicked |

**Import into component**:
```typescript
import { EmptyStateComponent } from '../../../shared/components/empty-state/empty-state.component';
// add to @Component imports: [EmptyStateComponent]
```

**Template usage — inside a table**:
```html
<tr *ngIf="!isLoading && items.length === 0">
  <td [attr.colspan]="columnCount">
    <app-empty-state
      [title]="hasActiveFilters ? 'No items match filters' : 'Queue is clear'"
      [message]="hasActiveFilters ? 'Try adjusting your filters.' : 'Nothing pending right now.'"
      [ctaLabel]="hasActiveFilters ? 'Clear filters' : ''"
      (ctaClick)="onResetFilters()">
    </app-empty-state>
  </td>
</tr>
```

**Template usage — standalone panel**:
```html
<app-empty-state
  *ngIf="notifications.length === 0"
  [title]="activeTab === 'unread' ? 'All caught up' : 'No notifications'"
  [message]="activeTab === 'unread' ? 'No unread notifications.' : 'Nothing to show.'">
</app-empty-state>
```

**When to apply**:
- Every data table's empty `<tr>` — replace inline divs/spans with `<app-empty-state>`
- Panel/drawer empty states (notification center, search results)
- Make the `title` and `message` context-aware: distinguish "no data exists" from "filters returned nothing"
- Provide `ctaLabel="Clear filters"` + `(ctaClick)="onResetFilters()"` whenever filters are active

---

## 5. ConfirmService — `confirmSvc.confirm()`

**File**: `src/app/shared/services/confirm.service.ts`
**Dialog component** (already in app.component.html): `src/app/shared/components/confirm-dialog/confirm-dialog.component.ts`

**Purpose**: Returns a `Promise<boolean>` that resolves when the user clicks Confirm or Cancel in a modal dialog. Use before any destructive or bulk operation.

**API — `ConfirmOptions`**:
```typescript
interface ConfirmOptions {
  title: string;        // Dialog heading
  message: string;      // Body text
  confirmLabel?: string; // Default: 'Confirm'
  cancelLabel?: string;  // Default: 'Cancel'
  danger?: boolean;      // Red confirm button when true
  count?: number;        // Shows item count badge when set
}
```

**Inject into component**:
```typescript
import { ConfirmService } from '../../../shared/services/confirm.service';
// inject: private confirmSvc: ConfirmService
// method must be async:
```

**Usage**:
```typescript
// Bulk destructive action
async bulkEscalate(): Promise<void> {
  const count = this.selectedIds.length;
  const confirmed = await this.confirmSvc.confirm({
    title: `Escalate ${count} Item${count !== 1 ? 's' : ''}`,
    message: `This will escalate all selected items to the next queue.`,
    confirmLabel: 'Escalate',
    count,
    danger: true,
  });
  if (!confirmed) return;
  // proceed with action
}

// Non-destructive approval
async bulkApprove(): Promise<void> {
  const count = this.pendingSelectedCount;
  const confirmed = await this.confirmSvc.confirm({
    title: `Approve ${count} Items`,
    message: `All selected pending workflows will advance to the next stage.`,
    confirmLabel: 'Approve All',
    count,
  });
  if (!confirmed) return;
  // proceed
}
```

**When to apply**:
- All bulk actions (approve, reject, escalate, re-route, delete)
- Any irreversible single-item action (reject, cancel, archive)
- Do NOT use for read-only actions or quick toggles
- `danger: true` for destructive actions (reject, escalate, cancel payment)
- `danger: false` (default) for positive bulk actions (approve)

---

## 6. ToastService — `toastSvc.success/info/warning/error()`

**File**: `src/app/shared/services/toast.service.ts`
**Container** (already in app.component.html): `<app-toast-container>`

**Purpose**: Shows transient toast notifications. Replaces all inline toast state (`lastToast`, `toastTimer`, `showToast()` patterns).

**API**:
```typescript
toastSvc.success(title: string, detail?: string): void  // green
toastSvc.info(title: string, detail?: string): void     // blue
toastSvc.warning(title: string, detail?: string): void  // amber
toastSvc.error(title: string, detail?: string): void    // red
```

**Inject into component**:
```typescript
import { ToastService } from '../../../shared/services/toast.service';
// inject: private toastSvc: ToastService
```

**Usage by action type**:
```typescript
// Export
this.toastSvc.success('Export complete', `${rows.length} items exported`);

// Approve / positive decision
this.toastSvc.success('Approved', workflow.reference);

// Reject / negative decision
this.toastSvc.error('Rejected', workflow.reference);

// Escalation (warning — action taken but with urgency)
this.toastSvc.warning('Escalated', item.reference);

// Neutral actions (hold, re-route, comment)
this.toastSvc.info('Comment added');
this.toastSvc.info('Exception re-routed', item.reference);

// Clipboard copy (fired automatically by CopyClipboardDirective)
// — do NOT call manually for copy actions
```

**When to apply**:
- After every user-triggered action that changes server state
- After CSV export
- After bulk actions complete
- Remove all `lastToast`, `toastTimer`, `showToast()` private patterns — use ToastService instead
- The `detail` parameter shows as a smaller subtitle line in the toast

---

## 7. ExportService — `exportSvc.toCsv()`

**File**: `src/app/shared/services/export.service.ts`

**Purpose**: Converts an array of plain objects to a BOM-prefixed UTF-8 CSV and triggers a browser download. BOM prefix ensures correct rendering in Excel.

**API**:
```typescript
exportSvc.toCsv(rows: Record<string, unknown>[], filename: string): void
// filename: without .csv extension — service appends it automatically
```

**Inject into component**:
```typescript
import { ExportService } from '../../../shared/services/export.service';
// inject: private exportSvc: ExportService
```

**Usage pattern** (always pair with ToastService):
```typescript
exportCsv(): void {
  const rows = this.page.items.map(i => ({
    Reference:    i.reference,
    Type:         i.type,
    Rail:         i.rail,
    Amount:       i.amount,
    Currency:     i.currency,
    Status:       i.status,
    Submitted_At: i.submittedAt.toISOString(),
  }));
  this.exportSvc.toCsv(rows, `queue-${new Date().toISOString().slice(0, 10)}`);
  this.toastSvc.success('Export complete', `${rows.length} items exported`);
}
```

**Filename convention**: `{entity}-{YYYY-MM-DD}` (e.g., `queue-2025-05-17`, `approvals-2025-05-17`, `exceptions-2025-05-17`)

**Column name rules**:
- Use `PascalCase` with underscores for multi-word columns (`Submitted_At`, `SLA_Status`, `Age_Minutes`)
- ISO 8601 strings for all dates (`i.submittedAt.toISOString()`)
- Numeric amounts as raw numbers — Excel will format them
- Enums as their string value

**When to apply**:
- Every data page with a table — add an "Export" button to the page header toolbar
- Export the current filtered/sorted **page** (not all records) unless otherwise stated
- Always call `toastSvc.success(...)` immediately after `toCsv()`

---

## Checklist — Wiring All Skills into a New Page Component

When creating a new data page (list + filters + table), apply this checklist:

```
[ ] CountUpDirective    — imported, applied to all numeric KPI/stat elements
[ ] CopyClipboardDirective — imported, applied to all reference/ID table cells
[ ] DataFreshnessComponent — imported, lastUpdated field added, updated in load(), in template header
[ ] EmptyStateComponent — imported, replaces empty <tr> or empty panel div
[ ] ConfirmService      — injected, all bulk/destructive actions converted to async with confirm()
[ ] ToastService        — injected, all action results produce a toast; no inline toast state
[ ] ExportService       — injected, exportCsv() method added, Export button in header toolbar
```

## Standard Page Header Toolbar Pattern
```html
<div class="page__header-right">
  <button class="page__export-btn" (click)="exportCsv()">
    <svg ...><!-- download icon --></svg> Export
  </button>
  <app-data-freshness [lastUpdated]="lastUpdated" (refresh)="load()"></app-data-freshness>
</div>
```

## Standard Imports Block for a New Data Page
```typescript
import { CountUpDirective }        from '../../../shared/directives/count-up.directive';
import { CopyClipboardDirective }  from '../../../shared/directives/copy-clipboard.directive';
import { DataFreshnessComponent }  from '../../../shared/components/data-freshness/data-freshness.component';
import { EmptyStateComponent }     from '../../../shared/components/empty-state/empty-state.component';
import { ConfirmService }          from '../../../shared/services/confirm.service';
import { ToastService }            from '../../../shared/services/toast.service';
import { ExportService }           from '../../../shared/services/export.service';

// @Component imports array:
imports: [
  CommonModule, FormsModule,
  CountUpDirective, CopyClipboardDirective,
  DataFreshnessComponent, EmptyStateComponent,
]

// Constructor:
constructor(
  private confirmSvc: ConfirmService,
  private toastSvc: ToastService,
  private exportSvc: ExportService,
) {}
```

When asked to add UI experience skills, ask for:
1. Which component/page needs the skills
2. Which specific skills are missing (or apply all from checklist)
3. The name of the load/refresh method to wire DataFreshness to
4. Which column holds the reference/ID for CopyClipboard
5. Which actions need ConfirmService (bulk vs single, destructive vs positive)
