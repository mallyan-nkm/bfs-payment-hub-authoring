# CLAUDE.md

Claude Code's entry point for this repository.

**No architecture rule is written in this file.** The rules live in `.github/`, the single source of truth shared with GitHub Copilot. This file *imports* them, so both assistants work from the same rulebook, and adds the notes that only apply to Claude Code.

> About to add a rule here? Don't. Put it in `.github/copilot-instructions.md` (always on) or the matching `.github/instructions/*.instructions.md` (path-scoped), and it reaches both tools. A rule a script can check also goes in `tools/ci/check-code-guardrails.ps1`. See `.github/AI-GOVERNANCE.md`.

## The rulebook (imported — treat as if written here)

@.github/copilot-instructions.md

## Architecture (long form)

@.github/architecture-essentials.md

## Build / run / test

@.github/build-and-run.md

---

## How enforcement works in Claude Code

Prose is guidance; the model can miss it. Everything a script can check is enforced by the same `tools/ci/` scripts at every layer, so the in-session verdict and the PR verdict cannot disagree:

1. **Guidance.** The imports above (always on), plus `.claude/rules/*.md` — generated from `.github/instructions/*.instructions.md` with the same globs — which load the standards for the file you touch.
2. **Before an edit** (`PreToolUse`, `.claude/hooks/pre-edit-guard.ps1`): the text about to be added goes through `check-code-guardrails.ps1`. An edit that adds a violation is **blocked**. That covers runtime migrations, `dbo` mapping, package versions in a `.csproj`, removing a workflow patch marker (`Workflow.Patched` or `IsPatched`), secrets, a second UI library, bypassing the `@paymenthub/ui` barrel, hardcoded colours, and SQL `UPDATE` on transaction tables or new foreign keys. Only new text can fire, so existing debt never blocks an edit. A block is final: rewrite the change.
3. **After an edit** (`PostToolUse`): whole-file rules on the result. When a `.csproj` changed, `check-architecture.ps1` also runs. Append-only advisories come back as context.
4. **Before the turn ends** (`Stop`): the PR gates on the uncommitted work. These are code guardrails, DB/versioning, success+failure tests, layering, and AI-asset drift. Fix what they report. If something can't be fixed (for example, it predates your change), tell the user plainly. Set `PAYMENTHUB_STOP_GATE=off` or `full` to change this.
5. **Commit and PR**: `.githooks/pre-commit` and the `Conformance` job in `azure-pipelines.yml` run the same scripts for every author and tool.

When a hook reports a violation, fix the code. Never weaken a rule, add a `$knownExceptions` entry, or edit a hook to get past it. A waiver needs Engineering + Architecture lead approval (Engineering Principles §9.4), so ask the user.

`.claude/settings.json` is committed and wires the hooks. Machine-local overrides go in `.claude/settings.local.json`, which is not committed.

## Agents, skills and commands

`.claude/agents/`, `.claude/skills/` and `.claude/commands/` hold **generated pointers** to the canonical `.github/agents/`, `.github/skills/` and `.github/prompts/` files. Their `description` lets Claude auto-delegate. A structural change (new service/worker/schema/table/migration/route/adaptor, or anything under `services/shared/`) goes through **`ipayhub-architect`** for a PASS / CHANGES-REQUIRED verdict before the PR. A schema change goes to **`ef-migration`**.

Never edit a generated file; edit the `.github/` original and re-run:

```powershell
pwsh tools/ai-assets/sync-claude-assets.ps1     # agents / skills / commands   (-Check to verify)
pwsh tools/ai-assets/sync-claude-rules.ps1      # .claude/rules from .github/instructions
```

The hand-written agents `ef-migration`, `encryption`, `rbac` and `spec-driven-design-pipeline`, and the `speckit-*` skills, are not generated. The generator leaves them alone.

## One-time setup per clone

```powershell
pwsh tools/ai-assets/install-git-hooks.ps1      # pre-commit runs the same gates as the PR pipeline
```

## graphify

This project has a knowledge graph at graphify-out/ with god nodes, community structure, and cross-file relationships.

Rules:
- For codebase questions, first run `graphify query "<question>"` when graphify-out/graph.json exists. Use `graphify path "<A>" "<B>"` for relationships and `graphify explain "<concept>"` for focused concepts. These return a scoped subgraph, usually much smaller than GRAPH_REPORT.md or raw grep output.
- If graphify-out/wiki/index.md exists, use it for broad navigation instead of raw source browsing.
- Read graphify-out/GRAPH_REPORT.md only for broad architecture review or when query/path/explain do not surface enough context.
- After modifying code, run `graphify update .` to keep the graph current (AST-only, no API cost).
