# Save as compact-docker.ps1 and schedule weekly
wsl --shutdown
Start-Sleep -Seconds 5
$vhdx = "$env:LOCALAPPDATA\Docker\wsl\disk\docker_data.vhdx"
$script = @"
select vdisk file="$vhdx"
attach vdisk readonly
compact vdisk
detach vdisk
exit
"@
$script | diskpart