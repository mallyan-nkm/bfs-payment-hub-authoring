import { useState } from 'react';
import { Tabs, TabsList, TabsTrigger } from '@paymenthub/ui';
import type { SlaBucket, SlaStatus, SlaSummary } from '../types';

const STATUS_COLOR: Record<SlaStatus, string> = {
  Green: 'var(--accent-green)',
  Amber: 'var(--accent-amber)',
  Red: 'var(--accent-red)',
};

function Sparkline({ points, color }: { points: number[]; color: string }) {
  if (points.length === 0) return null;
  // Fixed internal coordinate system; the SVG scales to its container width via
  // viewBox + preserveAspectRatio, so it never bleeds out of a narrow card.
  const w = 220;
  const h = 36;
  const max = 100;
  const step = w / Math.max(1, points.length - 1);
  const d = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${(i * step).toFixed(1)} ${(h - (p / max) * h).toFixed(1)}`)
    .join(' ');
  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      preserveAspectRatio="none"
      className="h-9 w-full"
      role="img"
      aria-label="24-hour SLA trend"
    >
      <path d={d} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function ComplianceBlock({ label, bucket }: { label: string; bucket: SlaBucket }) {
  const color = STATUS_COLOR[bucket.status] ?? 'var(--text-muted)';
  const spark = (bucket.sparkline ?? []).map((s) => s.pct);
  return (
    <div className="min-w-0 rounded-lg border border-[var(--border)] bg-[var(--bg-secondary)] p-4">
      <div className="truncate text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
        {label}
      </div>
      <div className="mt-1 flex flex-wrap items-baseline gap-x-2">
        <span className="text-3xl font-semibold tabular-nums" style={{ color }}>
          {bucket.compliancePct.toFixed(1)}%
        </span>
        <span
          className="rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase"
          style={{ color, backgroundColor: `${color}1a` }}
        >
          {bucket.status}
        </span>
      </div>
      <div className="mt-2">{spark.length > 0 && <Sparkline points={spark} color={color} />}</div>
      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-[var(--text-muted)]">
        <span className="flex items-center gap-1">
          <span className="size-2 rounded-full bg-[var(--accent-green)]" /> {bucket.withinSla} compliant
        </span>
        <span className="flex items-center gap-1">
          <span className="size-2 rounded-full bg-[var(--accent-red)]" /> {bucket.breachedSla} breached
        </span>
        <span>{bucket.totalCompleted} completed</span>
      </div>
    </div>
  );
}

/**
 * SLA widget driven by the real `/ops/dashboard/sla-summary` payload (overall + per-rail,
 * with sparklines). Used by the TAT & SLA page. Distinct from `SlaComplianceWidget`, which is
 * the four-view port of the Angular ops dashboard widget.
 */
export function SlaSummaryWidget({ sla }: { sla: SlaSummary }) {
  const [tab, setTab] = useState<'overall' | 'by-rail'>('overall');
  const overallColor = STATUS_COLOR[sla.overall.status] ?? 'var(--text-muted)';

  return (
    <div className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-[var(--text-primary)]">SLA Compliance</h2>
        <Tabs value={tab} onValueChange={(v) => setTab(v as 'overall' | 'by-rail')}>
          <TabsList>
            <TabsTrigger value="overall">Overall</TabsTrigger>
            <TabsTrigger value="by-rail">By Rail</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {tab === 'overall' ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
          <div className="min-w-0 rounded-lg border border-[var(--border)] bg-[var(--bg-secondary)] p-4">
            <div className="truncate text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Overall Compliance
            </div>
            <div className="mt-1 text-4xl font-semibold tabular-nums" style={{ color: overallColor }}>
              {sla.overall.todayCompliancePct.toFixed(1)}%
            </div>
            <div className="mt-1 text-xs text-[var(--text-muted)]">
              Target {sla.overall.targetPct}% · breach &lt; {sla.overall.breachThresholdPct}%
            </div>
            <div className="mt-1 text-xs text-[var(--text-muted)]">
              Last hour: {sla.overall.lastHourCompliancePct.toFixed(1)}%
            </div>
          </div>
          <ComplianceBlock label="Outward — Today" bucket={sla.outward.today} />
          <ComplianceBlock label="Inbound — Today" bucket={sla.inbound.today} />
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[var(--border)]">
          <table className="w-full min-w-max text-sm">
            <thead>
              <tr className="border-b border-[var(--border)] bg-[var(--bg-secondary)] text-left text-xs font-medium uppercase tracking-wider text-[var(--text-muted)]">
                <th className="px-3 py-2">Rail</th>
                <th className="px-3 py-2">SLA Target</th>
                <th className="px-3 py-2 text-right">Outward</th>
                <th className="px-3 py-2 text-right">Inbound</th>
                <th className="px-3 py-2 text-right">Within / Breached</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-light)]">
              {sla.byRail.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-3 py-6 text-center text-[var(--text-muted)]">
                    No per-rail SLA data yet.
                  </td>
                </tr>
              ) : (
                sla.byRail.map((r) => (
                  <tr key={r.rail} className="odd:bg-[var(--bg-secondary)]">
                    <td className="px-3 py-2 font-medium text-[var(--text-primary)]">{r.rail}</td>
                    <td className="px-3 py-2 text-[var(--text-muted)]">{r.slaTargetLabel}</td>
                    <td
                      className="px-3 py-2 text-right font-medium tabular-nums"
                      style={{ color: STATUS_COLOR[r.outward.status] }}
                    >
                      {r.outward.compliancePct.toFixed(1)}%
                    </td>
                    <td
                      className="px-3 py-2 text-right font-medium tabular-nums"
                      style={{ color: STATUS_COLOR[r.inbound.status] }}
                    >
                      {r.inbound.compliancePct.toFixed(1)}%
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums text-[var(--text-secondary)]">
                      <span className="text-[var(--accent-green)]">{r.outward.withinSla}</span> /{' '}
                      <span className="text-[var(--accent-red)]">{r.outward.breachedSla}</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
