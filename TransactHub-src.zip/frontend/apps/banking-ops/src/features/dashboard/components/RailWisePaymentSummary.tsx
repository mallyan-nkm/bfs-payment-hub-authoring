import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronUp, RefreshCw } from 'lucide-react';
import { cn, usePermissions } from '@paymenthub/ui';
import { PERM } from '../../../shared/auth/permissionKeys';
import { opsDashboardApi } from '../api';
import type { WpsMessageTypeSummary } from '../types';

type ViewMode = 'file' | 'rec';
type RailKey = 'ipi' | 'wps' | 'fts';

/** Row shape shared by all three rail boxes — the WPS message-summary DTO. */
type MessageRow = WpsMessageTypeSummary;

const zeroRow = (messageType: string): MessageRow => ({
  messageType,
  msgCount: 0,
  sendToCb: 0,
  cbPending: 0,
  ackReceived: 0,
  nakCount: 0,
  exceptionCount: 0,
  rejectedCount: 0,
  totalRecordCount: 0,
  amountAed: 0,
  recSendToCb: 0,
  recCbPending: 0,
  recAckReceived: 0,
  recNakCount: 0,
});

/**
 * IPI and FTS have no message-type breakdown endpoint yet — they are static zero rows so the
 * widget keeps the mockup's three-column shape (same as the Angular widget) rather than
 * pretending the data exists. WPS is the one rail backed by real data.
 *
 * Because they are placeholders rather than data, they are gated on their rail gates all the
 * same: the day a real IPI or FTS endpoint lands behind these boxes, the gate is already in
 * place rather than being remembered at that point.
 */
const IPI_ROWS: MessageRow[] = [zeroRow('FFTS0001')];
const FTS_ROWS: MessageRow[] = [zeroRow('CB 102 / 103'), zeroRow('CB 202 / 203')];

const num = (n: number | null | undefined) => (n ?? 0).toLocaleString();

/** Compact AED with a K step — matches the Angular widget's `formatAed`. */
function formatAed(value: number | null | undefined): string {
  const v = value ?? 0;
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(1)}K`;
  return v.toLocaleString();
}

const RAIL_ACCENT: Record<RailKey, string> = { ipi: '#10B981', wps: '#00B4D8', fts: '#6366F1' };

/** Rail gate each box is shown behind — the same key the backing endpoint requires. */
const RAIL_GATE: Record<RailKey, string> = {
  ipi: PERM.railIpi,
  wps: PERM.railWps,
  fts: PERM.railFts,
};

interface Props {
  refreshTick: number;
}

/**
 * Rail-wise Payment Summary — port of the Angular `widget-rail-wise-payment-summary`.
 * Three per-rail boxes, each toggling between a message-level ("Message Count") and a
 * record-level ("Record Count") view of the same message types.
 */
export function RailWisePaymentSummary({ refreshTick }: Props) {
  const [expanded, setExpanded] = useState(true);
  const [viewMode, setViewMode] = useState<Record<RailKey, ViewMode>>({ ipi: 'file', wps: 'file', fts: 'file' });

  // Not <Can>, because this gate has to reach the query as well as the markup: hiding the box
  // while still fetching would leave a caller denied the rail earning a 403 on every refresh
  // tick for data they never see. isResolved keeps the fail-closed direction honest — while
  // the snapshot loads every key reads as denied, and firing the query on that would defeat it.
  const { can, isResolved } = usePermissions();
  const railVisible = (rail: RailKey) => isResolved && can(RAIL_GATE[rail]);

  const wpsQ = useQuery({
    queryKey: ['wps-message-summary'],
    queryFn: () => opsDashboardApi.wpsMessageSummary(),
    enabled: railVisible('wps'),
  });

  useEffect(() => {
    if (refreshTick > 0 && railVisible('wps')) void wpsQ.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshTick]);

  // RFR is appended as a static zero row: no activity writes wps.message_payloads for it yet.
  const wpsRows: MessageRow[] = wpsQ.data ? [...wpsQ.data.messageTypes, zeroRow('RFR')] : [];

  const setRailView = (rail: RailKey, mode: ViewMode) => setViewMode((prev) => ({ ...prev, [rail]: mode }));

  // A caller holding no rail at all gets no widget, rather than a titled box with nothing in it —
  // an empty "Rail-wise Payment Summary" reads as a system with no traffic, which is a different
  // and more alarming statement than "not yours to see".
  if (!(['ipi', 'wps', 'fts'] as const).some(railVisible)) {
    return null;
  }

  return (
    <section className="flex flex-col w-full self-stretch overflow-hidden rounded-[var(--brdr-radius-big)] border border-[var(--border)] bg-[var(--plain-bg)] ">
      <button
        onClick={() => setExpanded((e) => !e)}
        className="flex w-full items-center gap-2 p-[var(--default-padding)] text-left"
      >
        {/* <LayoutGrid size={14} className="text-[var(--text-muted)]" /> */}
        <h3 >Rail-wise Payment Summary</h3>
        {/* <span className="flex items-center gap-1.5 text-[11px] text-[var(--text-muted)]">
          <span className="size-2 shrink-0 animate-pulse rounded-full bg-[var(--accent-green)]" />
          Live
        </span> */}
        <span className='icon-btn ml-auto'>
          <ChevronUp
            size={16}
            className={cn('transition-transform', !expanded && '-rotate-180')}
          />
        </span>
      </button>

      {expanded && (
        <div className="grid w-full grid-flow-row gap-4 sm:grid-flow-col rail-card-wrapper p-4">
          {railVisible('ipi') && (
            <RailBox
              railKey="ipi"
              label="IPI"
              mode={viewMode.ipi}
              onModeChange={(m) => setRailView('ipi', m)}
              rows={IPI_ROWS}
              amountLabel="Txn Amount (AED)"
            />
          )}
          {railVisible('wps') && (
            <RailBox
              railKey="wps"
              label="WPS"
              mode={viewMode.wps}
              onModeChange={(m) => setRailView('wps', m)}
              rows={wpsRows}
              amountLabel="Salary Amount (AED)"
              loading={wpsQ.isLoading}
              emptyMessage="No WPS SIF messages today"
              onRefresh={() => void wpsQ.refetch()}
            />
          )}
          {railVisible('fts') && (
            <RailBox
              railKey="fts"
              label="FTS"
              mode={viewMode.fts}
              onModeChange={(m) => setRailView('fts', m)}
              rows={FTS_ROWS}
              amountLabel="Txn Amount (AED)"
            />
          )}
        </div>
      )}
    </section>
  );
}

interface RailBoxProps {
  railKey: RailKey;
  label: string;
  mode: ViewMode;
  onModeChange: (mode: ViewMode) => void;
  rows: MessageRow[];
  amountLabel: string;
  loading?: boolean;
  emptyMessage?: string;
  onRefresh?: () => void;
}

function RailBox({ railKey, label, mode, onModeChange, rows, amountLabel, loading, emptyMessage, onRefresh }: RailBoxProps) {
  const [spinning, setSpinning] = useState(false);
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const accent = RAIL_ACCENT[railKey];

  const toggleRow = (index: number) => setOpenIndex((prev) => (prev === index ? null : index));

  const handleRefresh = () => {
    onRefresh?.();
    setSpinning(true);
    window.setTimeout(() => setSpinning(false), 650);
  };

  return (
    <div className="overflow-hidden rounded-[var(--brdr-radius-mdm)] border border-[var(--border)] p-4">
      <div className="flex flex-wrap items-center gap-2">
        <h4 className='flex gap-2 items-center'>
          <span className=""
            style={{ background: accent }}></span>
          {label}
        </h4>

        
        <div className='ml-auto flex gap-2 items-center'>
          <button
          onClick={handleRefresh}
          title="Refresh"
          className=" plain-btn"
        >
          <RefreshCw size={14} className={cn(spinning && 'animate-spin')} />
        </button>
         <div className="pill-holder ">
          {([
            { key: 'file', label: 'Message' },
            { key: 'rec', label: 'Record' },
          ] as const).map((t) => {
            const isActive = mode === t.key;
            return (
              <button
                key={t.key}
                onClick={() => onModeChange(t.key)}
                style={isActive ? { background: accent } : undefined}
                className={cn(
                  'tab-pill-btn transition-colors',
                  isActive && 'active-pill'
                )}
              >
                {t.label}
              </button>
            );
          })}
        </div>
        </div>
       

      </div>

      {loading ? (
        <p className="px-3 py-6 text-center text-xs text-[var(--text-muted)]">Loading…</p>
      ) : rows.length === 0 ? (
        <p className="px-3 py-6 text-center text-xs text-[var(--text-muted)]">{emptyMessage ?? 'No data'}</p>
      ) : (
        rows.map((row, index) => {
          const isOpen = openIndex === index;
          return (
            <div key={row.messageType} className="border border-[var(--border)] rounded-[var(--brdr-radius-mdm)] p-[12px] mt-[12px]">
              <button
                type="button"
                onClick={() => toggleRow(index)}
                className="mb-1.5 flex w-full items-center justify-between gap-2 "
              >
                <span className="text-[12px] font-bold uppercase tracking-wide text-[var(--text-primary)]">
                  {row.messageType}
                </span>
                <ChevronUp
                  size={14}
                  className={cn('shrink-0 text-[var(--text-muted)] transition-transform', !isOpen && '-rotate-180')}
                />
              </button>
              {isOpen && (
                <dl className="flex flex-col gap-1 border-t border-[var(--border)] py-2.5">
                  {mode === 'file' ? (
                    <>
                      <StatLine label="Msg Count" value={num(row.msgCount)} />
                      <StatLine label="Exception Count" value={num(row.exceptionCount)} tone="nak" />
                      <StatLine label="Rejected Count" value={num(row.rejectedCount)} tone="nak" />
                      <StatLine label="Send to CB" value={num(row.sendToCb)} />
                      <StatLine label="CB Pending" value={num(row.cbPending)} tone="pending" />
                      <StatLine label="ACK Msg Received" value={num(row.ackReceived)} tone="ack" />
                      <StatLine label="NAK Msg Count" value={num(row.nakCount)} tone="nak" />
                    </>
                  ) : (
                    <>
                      <StatLine label="Total Record Count" value={num(row.totalRecordCount)} />
                      <StatLine label={amountLabel} value={formatAed(row.amountAed)} />
                      <StatLine label="Send to CB" value={num(row.recSendToCb)} />
                      <StatLine label="CB Pending" value={num(row.recCbPending)} tone="pending" />
                      <StatLine label="ACK Received Count" value={num(row.recAckReceived)} tone="ack" />
                      <StatLine label="NAK Received Count" value={num(row.recNakCount)} tone="nak" />
                    </>
                  )}
                </dl>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}

const TONE_CLASS = {
  pending: 'text-[var(--accent-amber)]',
  ack: 'text-[var(--accent-green)]',
  nak: 'text-[var(--accent-red)]',
} as const;

function StatLine({ label, value, tone }: { label: string; value: string; tone?: keyof typeof TONE_CLASS }) {
  return (
    <div className="flex items-baseline justify-between gap-2 text-[12px]">
      <dt className="text-[var(--text-secondary)]">{label}</dt>
      <dd className={cn('font-semibold tabular-nums', tone ? TONE_CLASS[tone] : 'text-[var(--text-primary)]')}>{value}</dd>
    </div>
  );
}
