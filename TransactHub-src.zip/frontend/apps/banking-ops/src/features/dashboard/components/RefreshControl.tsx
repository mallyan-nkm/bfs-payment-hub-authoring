import { Pause, Play, RefreshCw } from 'lucide-react';
import { cn } from '@paymenthub/ui';

export interface RefreshControlProps {
  /** Active interval in ms, or 0 when paused. */
  intervalMs: number;
  onIntervalChange: (ms: number) => void;
  paused: boolean;
  onTogglePause: () => void;
  onManualRefresh: () => void;
  isFetching?: boolean;
  updatedAgoLabel?: string;
}

const OPTIONS: Array<{ label: string; ms: number }> = [
  { label: '10s', ms: 10_000 },
  { label: '30s', ms: 30_000 },
  { label: '1m', ms: 60_000 },
  { label: '2m', ms: 120_000 },
];

/** Auto-refresh interval + pause + manual-refresh control (Angular ops refresh panel). */
export function RefreshControl({
  intervalMs,
  onIntervalChange,
  paused,
  onTogglePause,
  onManualRefresh,
  isFetching,
  updatedAgoLabel,
}: RefreshControlProps) {
  return (
    <div className="flex items-center gap-2">
      {updatedAgoLabel && (
        <span className="flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
          <span className={cn('size-2 rounded-full', paused ? 'bg-[var(--text-muted)]' : 'bg-[var(--accent-green)]')} />
          {updatedAgoLabel}
        </span>
      )}
      <div className="flex items-center overflow-hidden rounded-md border border-[var(--border)]">
        {OPTIONS.map((o) => (
          <button
            key={o.ms}
            type="button"
            onClick={() => onIntervalChange(o.ms)}
            className={cn(
              'px-2.5 py-1 text-xs font-medium transition-colors',
              !paused && intervalMs === o.ms
                ? 'bg-[var(--accent)] text-white'
                : 'text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
            )}
          >
            {o.label}
          </button>
        ))}
        <button
          type="button"
          onClick={onTogglePause}
          title={paused ? 'Resume auto-refresh' : 'Pause auto-refresh'}
          className="border-l border-[var(--border)] px-2 py-1 text-[var(--text-secondary)] transition-colors hover:bg-[var(--bg-card-hover)]"
        >
          {paused ? <Play size={13} /> : <Pause size={13} />}
        </button>
        <button
          type="button"
          onClick={onManualRefresh}
          title="Refresh now"
          className="border-l border-[var(--border)] px-2 py-1 text-[var(--text-secondary)] transition-colors hover:bg-[var(--bg-card-hover)]"
        >
          <RefreshCw size={13} className={cn(isFetching && 'animate-spin')} />
        </button>
      </div>
    </div>
  );
}
