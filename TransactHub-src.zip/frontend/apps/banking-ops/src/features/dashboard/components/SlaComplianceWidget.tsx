import { useMemo, useState } from 'react';
import { cn } from '@paymenthub/ui';
import { ChevronUp, TriangleAlert } from 'lucide-react';


export type SlaView = 'overall' | 'by-rail' | 'by-status' | 'by-message';

interface RailMetric { rail: string; pct: number; met: number; breached: number; barColor: string }
interface StatusMetric {
  rail: string;
  cbComplianceBreached: number;
  fraudComplianceFailed: number;
  amlComplianceFailed: number;
  sanctionBreached: number;
  screeningBreached: number;
  slaPct: number;
}
interface MessageMetric {
  messageType: string;
  totalMessages: number;
  withinSla: number;
  cbBreached: number;
  fraudFailed: number;
  amlFailed: number;
  slaPct: number;
}
interface SlaMetrics {
  overallPct: number;
  compliantCount: number;
  warningCount: number;
  breachedCount: number;
  railMetrics: RailMetric[];
  statusMetrics: StatusMetric[];
  messageMetrics: Record<string, MessageMetric[]>;
}

/**
 * Reference dataset carried over verbatim from the Angular `widget-sla-compliance`, which
 * renders these fixed figures rather than calling an endpoint — the per-status and
 * per-message-type SLA breakdowns it shows have no backing API yet. The real
 * `/ops/dashboard/sla-summary` endpoint only covers the overall + per-rail compliance
 * percentages, so wiring it here would leave two of the four views empty.
 */
const SLA_METRICS: SlaMetrics = {
  overallPct: 99.1,
  compliantCount: 14823,
  warningCount: 81,
  breachedCount: 133,
  railMetrics: [
    { rail: 'IPI', pct: 99.2, met: 4485, breached: 36, barColor: 'rgb(16, 185, 129)' },
    { rail: 'UAEFTS', pct: 98.9, met: 2816, breached: 31, barColor: 'rgb(99, 102, 241)' },
    { rail: 'WPS', pct: 99.8, met: 890, breached: 2, barColor: 'rgb(0, 180, 216)' },
    { rail: 'IPP', pct: 99.5, met: 651, breached: 3, barColor: 'rgb(107, 44, 216)' },
    { rail: 'SWIFT', pct: 97.4, met: 323, breached: 9, barColor: 'rgb(217, 119, 6)' },
  ],
  statusMetrics: [
    { rail: 'IPI', cbComplianceBreached: 12, fraudComplianceFailed: 8, amlComplianceFailed: 6, sanctionBreached: 5, screeningBreached: 5, slaPct: 99.2 },
    { rail: 'UAEFTS', cbComplianceBreached: 14, fraudComplianceFailed: 7, amlComplianceFailed: 5, sanctionBreached: 3, screeningBreached: 2, slaPct: 98.9 },
    { rail: 'WPS', cbComplianceBreached: 1, fraudComplianceFailed: 0, amlComplianceFailed: 1, sanctionBreached: 0, screeningBreached: 0, slaPct: 99.8 },
    { rail: 'IPP', cbComplianceBreached: 1, fraudComplianceFailed: 1, amlComplianceFailed: 1, sanctionBreached: 0, screeningBreached: 0, slaPct: 99.5 },
    { rail: 'SWIFT', cbComplianceBreached: 4, fraudComplianceFailed: 2, amlComplianceFailed: 1, sanctionBreached: 1, screeningBreached: 1, slaPct: 97.4 },
  ],
  messageMetrics: {
    IPI: [{ messageType: 'FFTS0001', totalMessages: 6040, withinSla: 5977, cbBreached: 22, fraudFailed: 14, amlFailed: 12, slaPct: 99.2 }],
    UAEFTS: [
      { messageType: '102 Customer Transfer', totalMessages: 450, withinSla: 435, cbBreached: 6, fraudFailed: 3, amlFailed: 2, slaPct: 96.7 },
      { messageType: '103 Single Credit', totalMessages: 380, withinSla: 368, cbBreached: 5, fraudFailed: 3, amlFailed: 2, slaPct: 96.8 },
      { messageType: '202 Financial Institution', totalMessages: 45, withinSla: 43, cbBreached: 1, fraudFailed: 0, amlFailed: 0, slaPct: 95.6 },
      { messageType: '203 Multiple Credit', totalMessages: 22, withinSla: 22, cbBreached: 0, fraudFailed: 0, amlFailed: 0, slaPct: 100 },
      { messageType: '2C2 / 003', totalMessages: 20, withinSla: 20, cbBreached: 0, fraudFailed: 0, amlFailed: 0, slaPct: 100 },
    ],
    WPS: [
      { messageType: 'SIF Salary Info File', totalMessages: 24500, withinSla: 24498, cbBreached: 1, fraudFailed: 0, amlFailed: 0, slaPct: 99.9 },
      { messageType: 'PRC / DIF / DCR', totalMessages: 5843, withinSla: 5843, cbBreached: 0, fraudFailed: 0, amlFailed: 0, slaPct: 100 },
    ],
    IPP: [
      { messageType: 'Direct Credit', totalMessages: 548, withinSla: 545, cbBreached: 1, fraudFailed: 1, amlFailed: 1, slaPct: 99.5 },
      { messageType: 'Bulk File', totalMessages: 1200, withinSla: 1200, cbBreached: 0, fraudFailed: 0, amlFailed: 0, slaPct: 100 },
    ],
    SWIFT: [
      { messageType: 'MT103 Single Credit', totalMessages: 185, withinSla: 179, cbBreached: 2, fraudFailed: 1, amlFailed: 1, slaPct: 96.8 },
      { messageType: 'MT202 Financial Institution', totalMessages: 42, withinSla: 40, cbBreached: 1, fraudFailed: 0, amlFailed: 0, slaPct: 95.2 },
      { messageType: 'MT202COV Cover Payment', totalMessages: 18, withinSla: 17, cbBreached: 1, fraudFailed: 0, amlFailed: 0, slaPct: 94.4 },
    ],
  },
};

const RAILS = ['IPI', 'UAEFTS', 'WPS', 'IPP', 'SWIFT'] as const;
const RAIL_DOT: Record<string, string> = { IPI: '#10B981', UAEFTS: '#6366F1', WPS: '#00B4D8', IPP: '#6b2cd8', SWIFT: '#d97706' };

const VIEWS: ReadonlyArray<{ key: SlaView; label: string }> = [
  { key: 'overall', label: 'Overall' },
  { key: 'by-rail', label: 'By Rail' },
  { key: 'by-status', label: 'By Status' },
  { key: 'by-message', label: 'By Message' },
];

const num = (n: number) => n.toLocaleString();
const pct1 = (n: number) => n.toFixed(1);

/** Compliance-percentage colour thresholds, per the Angular widget. */
function pctTone(pct: number, green = 99, amber = 97): string {
  if (pct >= green) return 'var(--accent-green)';
  if (pct >= amber) return 'var(--accent-amber)';
  return 'var(--accent-red)';
}

const TH = '';
const TD = 'tabular-nums';

/**
 * SLA Compliance widget — port of the Angular `widget-sla-compliance`, with all four views
 * (Overall / By Rail / By Status / By Message).
 */
export function SlaComplianceWidget() {
  const [expanded, setExpanded] = useState(true);
  const [activeView, setActiveView] = useState<SlaView>('overall');
  const [selectedMessageRail, setSelectedMessageRail] = useState<string>('IPI');
  const metrics = SLA_METRICS;

  const statusTotal = useMemo(
    () => ({
      cb: metrics.statusMetrics.reduce((s, r) => s + r.cbComplianceBreached, 0),
      fraud: metrics.statusMetrics.reduce((s, r) => s + r.fraudComplianceFailed, 0),
      aml: metrics.statusMetrics.reduce((s, r) => s + r.amlComplianceFailed, 0),
      sanction: metrics.statusMetrics.reduce((s, r) => s + r.sanctionBreached, 0),
      screening: metrics.statusMetrics.reduce((s, r) => s + r.screeningBreached, 0),
    }),
    [metrics.statusMetrics],
  );

  const messageRows = metrics.messageMetrics[selectedMessageRail] ?? [];

  return (
    <section
      className="flex flex-col w-full self-stretch overflow-hidden rounded-[var(--brdr-radius-big)] bg-[var(--plain-bg)] border border-[var(--border)]"
      role="region"
      aria-label="SLA Compliance metrics"
    >
      <button
        onClick={() => setExpanded((e) => !e)}
        className="flex w-full items-center gap-2 p-[var(--default-padding)] text-left"
      >
        {/* <LayoutGrid size={14} className="text-[var(--text-muted)]" /> */}
        <h3 >SLA Compliance</h3>
        {/* <span className="flex items-center gap-1.5 text-[11px] text-[var(--text-muted)]">
                <span className="size-2 shrink-0 animate-pulse rounded-full bg-[var(--accent-green)]" />
                Live
              </span> */}
        <span className='icon-btn ml-auto'>
          <ChevronUp
            size={16}
            className={cn('transition-transform', !expanded && '-rotate-180')}
          />
        </span>
      </button>
      {expanded && (

        <div className="flex flex-col w-full p-4">
          <div className="flex flex-wrap items-center justify-between gap-3 ">
            <div className="flex shrink-0 tab-main sub-tab mb-[24px] w-full" role="tablist" aria-label="SLA view">
              {VIEWS.map((v) => (
                <button
                  key={v.key}
                  role="tab"
                  aria-selected={activeView === v.key}
                  onClick={() => setActiveView(v.key)}
                  className={cn(
                    'tab-pills',
                    activeView === v.key ? 'active-tab' : '',
                  )}
                >
                  {v.label}
                </button>
              ))}
            </div>
          </div>

          <div >
            {activeView === 'overall' && (
              <div className="flex gap-4 w-full">
                <div className='w-[50%]'>
                  <h4 className='mb-2'>Overall Compliance</h4>
                  <p className="mt-1 text-4xl font-bold tabular-nums mb-3" style={{ color: pctTone(metrics.overallPct, 98, 96) }}>
                    {pct1(metrics.overallPct)}%
                  </p>
                  <div className="mt-3 h-2 mb-4 overflow-hidden rounded-full bg-[var(--bg-secondary)]">
                    <div className="h-full rounded-full" style={{ width: `${metrics.overallPct}%`, background: 'var(--accent-green)' }} />
                  </div>
                  <p className="badge-warning flex gap-3 w-full">
                    <span><TriangleAlert size={14} /></span>
                    SWIFT 97.4% at risk
                  </p>
                </div>

                <div className="w-[50%]">
                  <div className="badge-success flex gap-3 mb-2 w-full">
                    <Dot color="var(--green-dot)" text={`${num(metrics.compliantCount)} compliant`} />
                  </div>
                  <div className="badge-warning flex gap-3 mb-2 w-full">
                    <Dot color="var(--yellow-dot)" text={`${num(metrics.warningCount)} warning`} /></div>
                  <div className="badge-alert flex gap-3 w-full">
                    <Dot color="var(--red-dot)" text={`${num(metrics.breachedCount)} breached`} /></div>
                </div>

              </div>
            )}

            {activeView === 'by-rail' && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
                {metrics.railMetrics.map((rail) => (
                  <div key={rail.rail} className="rounded-lg border border-[var(--border)] p-3">
                    <p className=" tabular-nums" style={{ color: pctTone(rail.pct) }}>
                      {pct1(rail.pct)}%
                    </p>
                    <p className="mt-1">
                      <span
                        className="common-badge text-[10px] font-bold uppercase text-white"
                        style={{ background: RAIL_DOT[rail.rail] ?? 'var(--accent)' }}
                      >
                        {rail.rail}
                      </span>
                    </p>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[var(--bg-secondary)]">
                      <div className="h-full rounded-full" style={{ width: `${rail.pct}%`, background: rail.barColor }} />
                    </div>
                    <p className="mt-2 text-[11px] text-[var(--text-muted)]">
                      <span className="text-[var(--accent-green)]">{num(rail.met)} met</span>{' '}
                      <span className="text-[var(--accent-red)]">{num(rail.breached)} breached</span>
                    </p>
                  </div>
                ))}
              </div>
            )}

            {activeView === 'by-status' && (
              <div className="overflow-x-auto rounded-lg border border-[var(--border)] table-holder">
                <table>
                  <thead>
                    <tr>
                      <th className="tracking-wide">Rail</th>
                      <th className={TH}>CB Compliance Breached</th>
                      <th className={TH}>Fraud Compliance Failed</th>
                      <th className={TH}>AML Compliance Failed</th>
                      <th className={TH}>Sanction Breached</th>
                      <th className={TH}>Screening Breached</th>
                      <th className={TH}>SLA %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {metrics.statusMetrics.map((row) => (
                      <tr key={row.rail}>
                        <td className="px-3 py-2">
                          <span
                            className="common-badge text-[10px] font-bold uppercase text-white"
                            style={{ background: RAIL_DOT[row.rail] ?? 'var(--accent)' }}
                          >
                            {row.rail}
                          </span>
                        </td>
                        <td className={TD}>{row.cbComplianceBreached}</td>
                        <td className={TD}>{row.fraudComplianceFailed}</td>
                        <td className={TD}>{row.amlComplianceFailed}</td>
                        <td className={TD}>{row.sanctionBreached}</td>
                        <td className={TD}>{row.screeningBreached}</td>
                        <td className={TD}>
                          <SlaBadge pct={row.slaPct} />
                        </td>
                      </tr>
                    ))}
                    <tr>
                      <td className="">Total</td>
                      <td className={TD}>{statusTotal.cb}</td>
                      <td className={TD}>{statusTotal.fraud}</td>
                      <td className={TD}>{statusTotal.aml}</td>
                      <td className={TD}>{statusTotal.sanction}</td>
                      <td className={TD}>{statusTotal.screening}</td>
                      <td className={TD}>
                        <SlaBadge pct={metrics.overallPct} />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {activeView === 'by-message' && (
              <div className="flex flex-col gap-3">
                <p className="text-xs text-[var(--text-muted)]">
                  ℹ SLA compliance broken down by message type per rail. Select a rail to view compliance counts per message type.
                </p>
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="mr-1 text-[10px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">Select rail:</span>
                  {RAILS.map((r) => (
                    <button
                      key={r}
                      onClick={() => setSelectedMessageRail(r)}
                      className={cn(
                        'gap-1.5 common-pill transition-colors',
                        selectedMessageRail === r
                          ? 'active-pill'
                          : '',
                      )}
                    >
                      <span className="rail-dot size-2 shrink-0 rounded-full" style={{ background: RAIL_DOT[r] }} />
                      {r}
                    </button>
                  ))}
                </div>
                <div className="overflow-x-auto table-holder">
                  <table>
                    <thead>
                      <tr>
                        <th >Type</th>
                        <th className={TH}>Total Txns</th>
                        <th className={cn(TH, 'text-[var(--accent-green)]')}>SLA Met</th>
                        <th className={cn(TH, 'text-[var(--accent-red)]')}>CB Compliance Breached</th>
                        <th className={cn(TH, 'text-[var(--accent-red)]')}>Fraud Compliance Failed</th>
                        <th className={cn(TH, 'text-[var(--accent-red)]')}>AML Compliance Failed</th>
                        <th className={TH}>SLA %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {messageRows.map((row) => (
                        <tr key={row.messageType}>
                          <td className="">{row.messageType}</td>
                          <td className={TD}>{num(row.totalMessages)}</td>
                          <td className={cn(TD, 'text-[var(--accent-green)]')}>{num(row.withinSla)}</td>
                          <td className={cn(TD, 'text-[var(--accent-red)]')}>{row.cbBreached}</td>
                          <td className={cn(TD, 'text-[var(--accent-red)]')}>{row.fraudFailed}</td>
                          <td className={cn(TD, 'text-[var(--accent-red)]')}>{row.amlFailed}</td>
                          <td className={TD}>
                            <SlaBadge pct={row.slaPct} amber={96} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {selectedMessageRail === 'SWIFT' && (
                  <p className="rounded-md border border-[var(--accent-amber)]/40 bg-[var(--accent-amber)]/10 px-3 py-2 text-xs text-[var(--accent-amber)]">
                    ⚠ SWIFT overall SLA at 97.4% — below CBUAE threshold. MT202COV at 94.4% — immediate review advised.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}


    </section>
  );
}

function Dot({ color, text }: { color: string; text: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="size-2 shrink-0 rounded-full" style={{ background: color }} />
      {text}
    </span>
  );
}

function SlaBadge({ pct, amber = 97 }: { pct: number; amber?: number }) {
  const color = pctTone(pct, 99, amber);
  return (
    <span className="rounded-full px-2 py-0.5 text-[11px] font-bold" style={{ color, background: `${color}1a` }}>
      {pct1(pct)}%
    </span>
  );
}
