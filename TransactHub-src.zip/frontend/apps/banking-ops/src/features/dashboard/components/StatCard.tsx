import type { ReactNode } from 'react';
import { cn } from '@paymenthub/ui';

export type StatTone = 'blue' | 'green' | 'red' | 'amber' | 'purple' | 'yellow';

const TONE: Record<StatTone, { bg: string; fg: string }> = {
  blue: { bg: 'var(--kpi-blue-bg)', fg: 'var(--kpi-blue-fg)' },
  green: { bg: 'var(--kpi-green-bg)', fg: 'var(--kpi-green-fg)' },
  red: { bg: 'var(--kpi-red-bg)', fg: 'var(--kpi-red-fg)' },
  amber: { bg: 'var(--kpi-amber-bg)', fg: 'var(--kpi-amber-fg)' },
  purple: { bg: 'var(--kpi-purple-bg)', fg: 'var(--kpi-purple-fg)' },
  yellow: { bg: 'var(--kpi-yellow-bg)', fg: 'var(--kpi-yellow-fg)' },
};

interface Props {
  label: string;
  value: ReactNode;
  tone: StatTone;
  /** Small pill under the value (e.g. "+12% vs prev", "Attention needed"). */
  footer?: ReactNode;
  footerTone?: 'default' | 'success' | 'warning' | 'danger';
  onClick?: () => void;
  className?: string;
}

const FOOTER_TONE = {
  default: 'text-[var(--text-secondary)]',
  success: 'text-[var(--accent-green)]',
  warning: 'text-[var(--accent-amber)]',
  danger: 'text-[var(--accent-red)]',
};

/** Pastel-gradient KPI tile — NeST TransactHub dashboard. */
export function StatCard({ label, value, tone, footer, footerTone = 'default', onClick, className }: Props) {
  const t = TONE[tone];
  const Comp = onClick ? 'button' : 'div';
  return (
    <Comp
      onClick={onClick}
      className={cn(
        'flex min-w-0 flex-col justify-center gap-0.5 rounded-lg px-3 py-2 text-left transition-transform',
        onClick && 'hover:-translate-y-0.5 hover:shadow-sm',
        className,
      )}
      style={{ background: t.bg }}
    >
      <span className="truncate text-[10px] font-semibold uppercase tracking-wide" style={{ color: t.fg, opacity: 0.8 }}>
        {label}
      </span>
      <div className="flex min-w-0 items-baseline gap-1.5">
        <span className="truncate text-lg font-bold leading-none" style={{ color: t.fg }}>
          {value}
        </span>
        {footer && <span className={cn('truncate text-[10px] font-medium', FOOTER_TONE[footerTone])}>{footer}</span>}
      </div>
    </Comp>
  );
}
