export interface GrowthPoint {
  label: string;
  value: number;
}

/** Lightweight responsive area+line chart for the "Transaction Growth" card. */
export function GrowthChart({ points }: { points: GrowthPoint[] }) {
  const W = 640;
  const H = 240;
  const padX = 36;
  const padY = 24;
  const max = Math.max(1, ...points.map((p) => p.value));
  const stepX = points.length > 1 ? (W - padX * 2) / (points.length - 1) : 0;
  const x = (i: number) => padX + i * stepX;
  const y = (v: number) => H - padY - (v / max) * (H - padY * 2);

  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${x(i).toFixed(1)} ${y(p.value).toFixed(1)}`).join(' ');
  const area = `${line} L ${x(points.length - 1).toFixed(1)} ${H - padY} L ${x(0).toFixed(1)} ${H - padY} Z`;

  // 4 horizontal gridlines
  const grid = [0, 0.25, 0.5, 0.75, 1].map((f) => ({ v: Math.round(max * f), yy: y(max * f) }));

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="h-full min-h-[140px] w-full" role="img" aria-label="Transaction growth this week">
      <defs>
        <linearGradient id="growthFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.28" />
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
        </linearGradient>
      </defs>
      {grid.map((g, i) => (
        <g key={i}>
          <line x1={padX} y1={g.yy} x2={W - padX} y2={g.yy} stroke="var(--border)" strokeWidth={1} strokeDasharray="3 4" />
          <text x={padX - 8} y={g.yy + 3} textAnchor="end" fontSize="10" fill="var(--text-muted)">
            {g.v}
          </text>
        </g>
      ))}
      {points.length > 0 && (
        <>
          <path d={area} fill="url(#growthFill)" />
          <path d={line} fill="none" stroke="var(--accent)" strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />
          {points.map((p, i) => (
            <g key={p.label}>
              <circle cx={x(i)} cy={y(p.value)} r={3} fill="var(--bg-card)" stroke="var(--accent)" strokeWidth={2} />
              <text x={x(i)} y={H - 6} textAnchor="middle" fontSize="10" fill="var(--text-muted)">
                {p.label}
              </text>
            </g>
          ))}
        </>
      )}
    </svg>
  );
}
