import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { LoadingSpinner, cn } from '@paymenthub/ui';
import { opsDashboardApi } from '../api';
import { TransactionSummaryModal } from './TransactionSummaryModal';
import { ArrowUp, ArrowRight, BarChart2 } from 'lucide-react';
export type FlowDirection = 'outward' | 'inbound';

interface Props {
  direction: FlowDirection;
  /** Bumped by the dashboard's single refresh clock; the card owns no timer of its own. */
  refreshTick: number;
  rail?: string;
}

const num = (n: number | null | undefined) => (n ?? 0).toLocaleString();

/** Compact AED — mirrors the Angular card's `formatAed` (B / M / raw, no K step). */
function formatAed(value: number | null | undefined): string {
  const v = value ?? 0;
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
  return v.toLocaleString();
}

// const TILE = 'flex flex-col items-start gap-0.5 px-4 py-3 text-left transition-colors hover:bg-[var(--bg-card-hover)]';
// const TILE_LABEL = 'text-[10px] font-semibold uppercase tracking-wider text-[var(--text-muted)]';
const TILE_VALUE = 'text-2xl font-bold leading-tight tabular-nums text-[var(--text-primary)]';
const TILE_UNIT = 'ml-1 text-[11px] font-normal text-[var(--text-muted)]';
// const TILE_SUB = 'text-[11px] text-[var(--text-muted)]';

/**
 * Outward / Inbound directional flow card — port of the Angular `widget-directional-flow-card`.
 * Header carries clickable Exceptions / Pending badges plus a Live indicator; the body is a 2×2
 * grid of drill-down tiles (Total Transactions, In-Flight, Transaction Summary, Active
 * Exceptions). The third tile opens the Transaction Summary modal.
 */
export function DirectionalFlowCard({ direction, refreshTick, rail }: Props) {
  const navigate = useNavigate();
  const [modalOpen, setModalOpen] = useState(false);

  const outward = direction === 'outward';
  // const label = outward ? 'Outward Payments' : 'Inbound Payments';

  const flowQ = useQuery({
    queryKey: ['flow-summary', rail ?? 'all'],
    queryFn: () => opsDashboardApi.flowSummary(rail),
  });

  // A refresh tick refetches in the background; the last good numbers stay on screen rather
  // than flickering back to a spinner every cycle.
  useEffect(() => {
    if (refreshTick > 0) void flowQ.refetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshTick]);

  // Default to zero metrics if API fails - cards should always show with data
  const defaultMetrics = {
    totalTransactions: 0,
    totalValue: 0,
    inFlightCount: 0,
    inFlightValue: 0,
    valueProcessed: 0,
    processedCount: 0,
    exceptionCount: 0,
    criticalExceptions: 0,
    newExceptionsLastHour: 0,
    pendingCount: 0,
    deltaPct: 0,
  };

  const metrics = flowQ.data ? (outward ? flowQ.data.outward : flowQ.data.inbound) : defaultMetrics;
  const deltaPct = metrics?.deltaPct ?? 0;
  // Settled share of today's transactions — the same buckets the Successful tile counts.
  const successRate = metrics.totalTransactions > 0
    ? (metrics.processedCount / metrics.totalTransactions) * 100
    : 0;
  const newExceptions = metrics.newExceptionsLastHour ?? 0;

  // const headerAccent = outward ? '#3b82f6' : '#22c55e';
  // const headerBg = outward
  //   ? 'linear-gradient(135deg, rgba(59,130,246,0.12), rgba(30,64,175,0.18))'
  //   : 'linear-gradient(135deg, rgba(22,163,74,0.12), rgba(15,118,110,0.18))';

  return (
    <section className='flex flex-col w-full self-stretch'>


    

      {flowQ.isLoading && !flowQ.data ? (
        <div className="flex flex-col items-center gap-3 px-5 py-14" role="status" aria-live="polite">
          <LoadingSpinner />
          <p className="text-xs text-[var(--text-muted)]">Loading {direction} metrics…</p>
        </div>
      ) : (
        <div className="grid w-full grid-flow-row gap-4  mb-6 antialiased sm:grid-flow-col sm:auto-cols-fr status-card-wrapper">

          {/* 1. Total Transactions */}
          <button className="common-card"
            onClick={() => navigate(`/total-transactions?direction=${direction}`)}
            title="Click to view transaction summary">
            <div className="absolute top-0 bottom-0 left-0 w-1 bg-[var(--primary-blue)] " />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[16px] bg-gradient-to-t from-[rgba(0,180,216,0.02)] to-[rgba(0,180,216,0.15)]" />

            <div className="flex items-start justify-between">
              <div className='text-left'>
                <span className=" tracking-wider tt-trns">
                  Total Transactions
                </span>
                <div className=" tt-qnty">
                  {num(metrics.totalTransactions)}
                </div>
                <div className="tt-amount">
                  AED {formatAed(metrics.totalValue)}
                </div>
              </div>

              {/* <div className="h-12 w-20 shrink-0 sm:w-24">
        <svg viewBox="0 0 100 45" className="h-full w-full overflow-visible">
          <path
            d="M0 35 Q 15 15, 30 30 T 60 20 T 85 10 T 100 5"
            fill="none"
            stroke="#0ea5e9"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div> */}
            </div>

            <div className="relative mt-4 flex items-center">
              <span className={cn('text-[11px] font-semibold', deltaPct >= 0 ? 'text-[var(--accent-green)]' : 'text-[var(--accent-red)]')}>
                {deltaPct >= 0 ? '▲' : '▼'} {Math.abs(deltaPct).toFixed(1)}% vs yesterday
              </span>
            </div>
          </button>


          {/* 2. Successful */}
          <button className="common-card" onClick={() => setModalOpen(true)}
            title="Click to view transaction summary">

            <div className="absolute top-0 bottom-0 left-0 w-1 bg-[var(--greenish)]" />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[16px] bg-gradient-to-t from-[rgba(16,185,129,0.02)] to-[rgba(16,185,129,0.15)]" />

            <div className="flex items-start justify-between">
              <div className='text-left'>
                <span className="tracking-wider tt-trns">
                  Successful
                </span>
                <div className="tt-qnty">
                  AED {formatAed(metrics.valueProcessed)}
                </div>
                <div className="tt-amount">
                  {outward ? 'Outward settled value' : 'Inbound posted value'}
                </div>
                <div className="tt-amount !font-extrabold !text-[var(--text-primary)]">
                  {num(metrics.processedCount)} txns processed
                </div>
              </div>

              {/* <div className="h-12 w-20 shrink-0 sm:w-24">
        <svg viewBox="0 0 100 45" className="h-full w-full overflow-visible">
          <path
            d="M0 38 Q 15 20, 30 32 T 60 18 T 85 12 T 100 4"
            fill="none"
            stroke="#10b981"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div> */}
            </div>

            <div className="relative mt-4 flex items-center">
              <span className="inline-flex items-center rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-600">
                {successRate.toFixed(1)}% success rate
              </span>
            </div>
          </button>


            {/* 3. In-Flight */}
        <button className="common-card" onClick={() => navigate(`/in-flight?direction=${direction}`)}
            title="Click to drill down by rail">
          <div className="absolute top-0 bottom-0 left-0 w-1 bg-[var(--orangish)]" />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[16px] bg-gradient-to-t from-[rgba(245,158,11,0.02)] to-[rgba(245,158,11,0.15)]" />

          <div className="flex items-start justify-between">
            <div className='text-left'>
              <span className="tt-trns">
                In-Flight
              </span>
              <div className="tt-qnty">
               {num(metrics.inFlightCount)}
              </div>
              <div className="tt-amount">
                AED {formatAed(metrics.inFlightValue)}
              </div>
            </div>

            {/* <div className="h-12 w-20 shrink-0 sm:w-24">
        <svg viewBox="0 0 100 45" className="h-full w-full overflow-visible">
          <path
            d="M0 5 Q 15 15, 30 8 T 60 22 T 85 30 T 100 38"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div> */}
          </div>

          <div className="relative mt-4 flex items-center">
            <span className="inline-flex items-center rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-semibold text-amber-600">
              Processing now
            </span>
          </div>
        </button>


               {/* 4. Active Exceptions */}
        <button className="common-card"  onClick={() => navigate(`/active-exceptions?direction=${direction}`)}
            title="Click to drill down exceptions">
          <div className="absolute top-0 bottom-0 left-0 w-1 bg-[var(--redish)]" />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[16px] bg-gradient-to-t from-[rgba(239,68,68,0.02)] to-[rgba(239,68,68,0.15)]" />

          <div className="flex items-start justify-between">
            <div className='text-left'>
              <div className="flex items-center gap-2">
                <span className="tt-trns">
                  Active Exceptions
                </span>
                <span className="antn-badge">
                  Attention
                </span>
              </div>
              <div 
                className={cn('tt-qnty', TILE_VALUE, metrics.exceptionCount > 0 && 'text-[var(--accent-red)]')}>
              {num(metrics.exceptionCount)}<span className={TILE_UNIT}>txns</span>
              </div>
              <div className="tt-amount !font-extrabold !text-[var(--text-primary)]">
               {num(metrics.criticalExceptions)} Critical Exceptions
              </div>
            </div>

            {/* <div className="h-12 w-20 shrink-0 sm:w-24">
        <svg viewBox="0 0 100 45" className="h-full w-full overflow-visible">
          <path
            d="M0 40 Q 15 28, 30 35 T 60 22 T 85 14 T 100 8"
            fill="none"
            stroke="#f43f5e"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div> */}
          </div>

          <div className="relative mt-4 flex items-center">
            <span className="inline-flex items-center gap-0.5 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-semibold text-amber-700">
              {newExceptions > 0 && <ArrowUp className="h-3 w-3 stroke-[2.5]" />} {num(newExceptions)} new in last hour
            </span>
          </div>
        </button>


         

          {/* 5. Summary Action Button */}
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            title="Click to view transaction summary"
            className="group relative flex flex-col items-center justify-center gap-2 rounded-2xl bg-[#1d5b79] p-5 text-white transition-all duration-200 hover:bg-[#164860] hover:shadow-md"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white transition-transform group-hover:scale-110">
              <BarChart2 className="h-5 w-5" />
            </div>
            <div className="text-center font-bold tracking-tight text-white">
              View Full Summary
            </div>
            <div className="inline-flex items-center gap-1 text-xs font-medium text-sky-100/80 transition-colors group-hover:text-white">
              All metrics <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
            </div>
          </button>

        </div>
      )}
      

      {modalOpen && <TransactionSummaryModal direction={direction} onClose={() => setModalOpen(false)} />}
    </section>
  );
}
