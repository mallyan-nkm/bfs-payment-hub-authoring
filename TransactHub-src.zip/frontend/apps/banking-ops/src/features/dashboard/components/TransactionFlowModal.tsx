import { useQuery } from '@tanstack/react-query';
import { X } from 'lucide-react';
import { LoadingSpinner, cn } from '@paymenthub/ui';
import { bankingApi } from '../../../shared/api/bankingApi';

interface FlowStep {
  stepNumber: string;
  name: string;
  status: string;
  startTime: string | null;
  endTime: string | null;
  durationMs: number | null;
  actor: string | null;
  contentData?: {
    remarks?: string | null;
    channel?: string | null;
    messageType?: string | null;
    note?: string | null;
    approverRemarks?: string | null;
    rejectionReason?: string | null;
    approverName?: string | null;
  } | null;
  connectorColor?: string | null;
}

interface FlowResp {
  txnReference: string;
  messageType: string | null;
  paymentType: string | null;
  currency: string | null;
  amount: number | null;
  status: string | null;
  durationSeconds: number | null;
  steps: FlowStep[];
  error?: string | null;
}

/** Dark navy modal chrome, matching the Angular flow modal header. */
const HEADER_BG = '#1e3a5f';

type StepState = 'completed' | 'in-progress' | 'failed' | 'not-reached';

function stepState(status: string): StepState {
  const s = status?.toLowerCase().replace(/\s+/g, '-');
  if (s === 'completed' || s === 'success' || s === 'done' || s === 'settled') return 'completed';
  if (s === 'failed' || s === 'error' || s === 'rejected') return 'failed';
  if (s === 'in-progress' || s === 'inprogress' || s === 'processing' || s === 'running') return 'in-progress';
  return 'not-reached';
}

const STEP_ICON: Record<StepState, { glyph: string; className: string }> = {
  completed: { glyph: '✓', className: 'bg-[var(--accent-green)] text-white' },
  'in-progress': { glyph: '⏳', className: 'bg-[var(--accent-blue)] text-white' },
  failed: { glyph: '✗', className: 'bg-[var(--accent-red)] text-white' },
  'not-reached': { glyph: '○', className: 'border border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-muted)]' },
};

const STATUS_BADGE: Record<StepState, string> = {
  completed: 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]',
  'in-progress': 'bg-[var(--accent-blue)]/15 text-[var(--accent-blue)]',
  failed: 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]',
  'not-reached': 'bg-white/15 text-white',
};

/**
 * Transaction Flow — the step timeline opened from the drill-down modal's Txn Flow button.
 * Port of the Angular `app-transaction-flow-modal`: navy header carrying the reference and a
 * message-type / rail / amount / status / duration strip, then a vertical stepper with each
 * step's raw start and end timestamps.
 */
export function TransactionFlowModal({ txnId, onClose }: { txnId: string; onClose: () => void }) {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['txn-flow', txnId],
    queryFn: () => bankingApi.get<FlowResp>(`/reports/transactions/${encodeURIComponent(txnId)}/flow`).then((r) => r.data),
  });

  const headerStatus = stepState(data?.status ?? '');
  const amountLabel =
    data?.amount != null
      ? `${data.currency ?? 'AED'} ${data.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
      : null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto bg-black/60 p-4 sm:p-8"
      role="dialog"
      aria-modal="true"
      aria-label="Transaction flow"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-[var(--shadow-lg)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3 px-5 py-3" style={{ background: HEADER_BG }}>
          <div className="min-w-0 text-white">
            <h2 className="truncate text-base font-semibold">Transaction Flow — {data?.txnReference ?? txnId}</h2>
            <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-white/85">
              {[data?.messageType, data?.paymentType, amountLabel].filter(Boolean).map((part, i) => (
                <span key={i}>
                  {part}
                  <span className="ml-2 text-white/50">·</span>
                </span>
              ))}
              {data?.status && (
                <span className={cn('rounded px-1.5 py-0.5 text-[11px] font-bold uppercase', STATUS_BADGE[headerStatus])}>
                  {data.status}
                </span>
              )}
              {data?.durationSeconds != null && (
                <span>
                  <span className="mr-2 text-white/50">·</span>Duration: {data.durationSeconds}s
                </span>
              )}
            </p>
          </div>
          <button onClick={onClose} className="rounded-md p-1 text-white/90 hover:bg-white/15" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="max-h-[70vh] overflow-y-auto px-5 py-4">
          {isLoading ? (
            <div className="flex h-40 items-center justify-center"><LoadingSpinner /></div>
          ) : isError || !data ? (
            <p className="py-8 text-center text-sm text-[var(--text-muted)]">Unable to load the transaction flow.</p>
          ) : data.steps.length === 0 ? (
            <p className="py-8 text-center text-sm text-[var(--text-muted)]">No workflow steps recorded for this transaction.</p>
          ) : (
            <ol className="flex flex-col">
              {data.steps.map((step, i) => {
                const state = stepState(step.status);
                const icon = STEP_ICON[state];
                const last = i === data.steps.length - 1;
                const note = step.contentData?.note || step.contentData?.approverRemarks;
                return (
                  <li key={`${step.stepNumber}-${i}`} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <span className={cn('grid size-6 shrink-0 place-items-center rounded-full text-xs font-bold', icon.className)}>
                        {icon.glyph}
                      </span>
                      {!last && (
                        <span
                          className="w-0.5 flex-1 bg-[var(--accent-green)]"
                          style={step.connectorColor ? { background: step.connectorColor } : undefined}
                        />
                      )}
                    </div>
                    <div className={cn('min-w-0 flex-1', last ? 'pb-1' : 'pb-5')}>
                      <p className="text-sm font-semibold text-[var(--text-primary)]">
                        STEP {step.stepNumber} · {step.name}
                      </p>
                      {(step.startTime || step.endTime) && (
                        <p className="mt-0.5 text-xs text-[var(--text-muted)]">
                          {step.startTime && <>Start: {step.startTime} IST</>}
                          {step.endTime && <> · End: {step.endTime} IST</>}
                        </p>
                      )}
                      {note && <p className="mt-1 text-xs text-[var(--text-secondary)]">{note}</p>}
                      {step.contentData?.rejectionReason && (
                        <p className="mt-1 text-xs text-[var(--accent-red)]">
                          <strong>Rejected by {step.contentData.approverName ?? 'approver'}:</strong>{' '}
                          {step.contentData.rejectionReason}
                        </p>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </div>
      </div>
    </div>
  );
}
