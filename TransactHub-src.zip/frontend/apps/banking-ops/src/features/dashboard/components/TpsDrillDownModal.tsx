import { useEffect, useMemo, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronDown, ChevronLeft, ChevronRight, Download, Search, Settings, X } from 'lucide-react';
import { Can, LoadingSpinner, cn, useSessionDateTime } from '@paymenthub/ui';
import { PERM } from '../../../shared/auth/permissionKeys';
import { useRailAccess } from '../../../shared/auth/rails';
import { totalTransactionsApi } from '../api';
import type { DashboardDateFilter, TpsTransactionRow } from '../types';
import { TransactionFlowModal } from './TransactionFlowModal';

/** Dark navy modal chrome, matching the Angular drill-down header. */
const HEADER_BG = '#1e3a5f';

type FilterType = 'text' | 'select' | 'none';

interface TransactionColumn {
  key: string;
  label: string;
  visible: boolean;
  sortable: boolean;
  filterable: boolean;
  filterType: FilterType;
  filterOptions?: string[];
  type: 'string' | 'number' | 'date' | 'badge';
  width?: string;
}

/** Flattened row the table renders — mirrors the Angular modal's `Transaction` shape. */
interface Txn {
  id: string;
  txnReference: string;
  referenceNumber: string;
  senderReference: string;
  messageType: string;
  orderingName: string;
  orderingAccount: string;
  orderingAddress?: string;
  beneficiaryName: string;
  beneficiaryAccount: string;
  beneficiaryAddress?: string;
  cbTransactionReference: string;
  beneficiaryRefCB?: string;
  currency: string;
  purposeOfPayment?: string;
  remittanceInfo?: string;
  amount: number;
  status: string;
  transactionDate: string;
  duration: number;
  corporateName?: string;
  fileName?: string;
  recordCount?: number;
  [key: string]: unknown;
}

/**
 * Default layout — applies to every rail except WPS. A WPS transaction is one SIF file
 * covering many employees, not a single debtor/creditor pair, so it gets its own column set
 * below rather than a visibility toggle on this one.
 */
const DEFAULT_COLUMNS: readonly TransactionColumn[] = [
  { key: 'messageType', label: 'Message Type', visible: true, sortable: true, filterable: true, filterType: 'select', filterOptions: ['All'], type: 'badge', width: '100px' },
  { key: 'txnReference', label: 'Txn Reference', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '140px' },
  { key: 'referenceNumber', label: 'End-to-End Reference', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'senderReference', label: 'Sender Reference', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '140px' },
  { key: 'view', label: 'Txn Flow', visible: true, sortable: false, filterable: false, filterType: 'none', type: 'string', width: '90px' },
  { key: 'orderingName', label: 'Ordering Name', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'orderingAccount', label: 'Ordering Account', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'orderingAddress', label: 'Ordering Address', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '200px' },
  { key: 'beneficiaryName', label: 'Beneficiary Name', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'beneficiaryAccount', label: 'Beneficiary Account', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'beneficiaryAddress', label: 'Beneficiary Address', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '200px' },
  { key: 'cbTransactionReference', label: 'CB Transaction Ref', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'beneficiaryRefCB', label: 'Beneficiary Ref(CB)', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'amount', label: 'Amount (AED)', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'number', width: '120px' },
  { key: 'currency', label: 'Currency', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '90px' },
  { key: 'purposeOfPayment', label: 'Purpose of Payment', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '150px' },
  { key: 'remittanceInfo', label: 'Remittance Info', visible: false, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '200px' },
  { key: 'status', label: 'Status', visible: true, sortable: true, filterable: true, filterType: 'select', filterOptions: ['All'], type: 'badge', width: '120px' },
  { key: 'transactionDate', label: 'Transaction Date', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'date', width: '120px' },
  { key: 'duration', label: 'Time (sec)', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'number', width: '90px' },
];

/** WPS layout: employer / file identity and record count replace the sender-beneficiary pair. */
const WPS_COLUMNS: readonly TransactionColumn[] = [
  { key: 'messageType', label: 'Message Type', visible: true, sortable: true, filterable: true, filterType: 'select', filterOptions: ['All', 'SIF', 'RFR'], type: 'badge', width: '110px' },
  { key: 'referenceNumber', label: 'Transaction ID', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '190px' },
  { key: 'corporateName', label: 'Corporate Name', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'string', width: '160px' },
  { key: 'fileName', label: 'File Name', visible: true, sortable: false, filterable: true, filterType: 'text', type: 'string', width: '220px' },
  { key: 'recordCount', label: 'Record Count', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'number', width: '110px' },
  { key: 'amount', label: 'Amount (AED)', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'number', width: '130px' },
  { key: 'status', label: 'Status', visible: true, sortable: true, filterable: true, filterType: 'select', filterOptions: ['All'], type: 'badge', width: '110px' },
  { key: 'transactionDate', label: 'Transaction Date', visible: true, sortable: true, filterable: true, filterType: 'text', type: 'date', width: '130px' },
  { key: 'view', label: 'Txn Flow', visible: true, sortable: false, filterable: false, filterType: 'none', type: 'string', width: '90px' },
];

const columnsForRail = (rail: string): TransactionColumn[] =>
  (rail?.toUpperCase() === 'WPS' ? WPS_COLUMNS : DEFAULT_COLUMNS).map((c) => ({ ...c }));

const STATUS_TONE: Record<string, string> = {
  processed: 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]',
  settled: 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]',
  'in progress': 'bg-[var(--accent-blue)]/15 text-[var(--accent-blue)]',
  'action pending': 'bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]',
  'pending approval': 'bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]',
  initiated: 'bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]',
  hold: 'bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]',
  failed: 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]',
  rejected: 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]',
  'system rejected': 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]',
};
const statusTone = (status: string) => STATUS_TONE[status?.toLowerCase()] ?? 'bg-[var(--bg-secondary)] text-[var(--text-secondary)]';

/** Duration colouring — over 30 min warns, over an hour is critical. */
function durationTone(seconds: number): string {
  if (seconds > 3600) return 'text-[var(--accent-red)]';
  if (seconds > 1800) return 'text-[var(--accent-amber)]';
  return 'text-[var(--text-primary)]';
}

const num = (v: unknown) => (typeof v === 'number' ? v.toLocaleString() : '');
const PAGE_SIZES = [5, 10, 20, 30, 40];

interface Props {
  rail: string;
  messageType: string;
  messageCount: number;
  transactionCount: number;
  direction: string;
  filter: DashboardDateFilter;
  onClose: () => void;
}

/**
 * TPS drill-down modal — opened by clicking any transaction count on the Total Transactions
 * page. Port of the Angular `ops-tps-drill-down-modal`: three metric blocks, per-column sort
 * and filter icons, a column-settings panel (toggle + drag reorder + save), server-side
 * pagination, CSV export, and a Txn Flow button per row that opens the flow timeline.
 */
export function TpsDrillDownModal({ rail, messageType, messageCount, transactionCount, direction, filter, onClose }: Props) {
  const { allows: allowsRail } = useRailAccess();
  const { formatInstant } = useSessionDateTime();
  const [columns, setColumns] = useState<TransactionColumn[]>(() => columnsForRail(rail));
  const [showColumnPanel, setShowColumnPanel] = useState(false);
  const [pageSize, setPageSize] = useState(10);
  const [pageNumber, setPageNumber] = useState(1);
  const [sortColumn, setSortColumn] = useState('duration');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [flowTxnId, setFlowTxnId] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);

  // Applied filters drive the table; pending filters are what the header inputs are editing.
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [pendingFilters, setPendingFilters] = useState<Record<string, string>>({});
  const [activeFilterColumns, setActiveFilterColumns] = useState<Set<string>>(new Set());

  const railChanged = useRef(rail);
  useEffect(() => {
    if (railChanged.current !== rail) {
      railChanged.current = rail;
      setColumns(columnsForRail(rail));
    }
  }, [rail]);

  // Restore any saved layout for this rail.
  useEffect(() => {
    const saved = localStorage.getItem(`tps-modal-columns-${rail}`);
    if (!saved) return;
    try {
      const layout = JSON.parse(saved) as Array<{ key: string; visible: boolean }>;
      const base = columnsForRail(rail);
      const ordered = layout
        .map(({ key, visible }) => {
          const col = base.find((c) => c.key === key);
          return col ? { ...col, visible } : null;
        })
        .filter((c): c is TransactionColumn => c !== null);
      // Any column added since the layout was saved keeps its default position at the end.
      const missing = base.filter((c) => !ordered.some((o) => o.key === c.key));
      setColumns([...ordered, ...missing]);
    } catch {
      // A corrupt saved layout is not worth failing the modal over — fall back to defaults.
    }
  }, [rail]);

  // `duration` and `transactionDate` are the only two the backend can sort on; everything else
  // is sorted client-side over the fetched page.
  const serverSortColumn = sortColumn === 'duration' ? 'DurationSeconds' : 'CreatedAt';

  const txnQ = useQuery({
    queryKey: ['tps-transactions', direction, rail, filter, pageSize, pageNumber, serverSortColumn, sortDirection],
    // The endpoint refuses a rail the caller does not hold, and its CSV export with it. Every call
    // site guards before opening this modal; the query is gated too so a rail that arrives another
    // way — a bookmarked link, a stale render before the snapshot lands — cannot fire the request.
    enabled: allowsRail(rail),
    queryFn: () =>
      totalTransactionsApi.tpsTransactions({
        direction,
        rail,
        filter,
        pageSize,
        pageNumber,
        sortColumn: serverSortColumn,
        sortDirection: sortDirection === 'desc' ? 'DESC' : 'ASC',
      }),
  });

  const rows: Txn[] = useMemo(
    () =>
      (txnQ.data?.transactions ?? []).map((row: TpsTransactionRow) => ({
        id: row.endToEndReference,
        txnReference: row.senderReferenceNumber,
        referenceNumber: row.endToEndReference,
        senderReference: row.senderReferenceNumber,
        messageType: row.messageType || rail,
        orderingName: row.orderingName,
        orderingAccount: row.orderingAccount,
        orderingAddress: row.orderingAccountAddress,
        beneficiaryName: row.beneficiaryName,
        beneficiaryAccount: row.beneficiaryAccount,
        beneficiaryAddress: row.beneficiaryAddress,
        cbTransactionReference: row.cbTransactionReference,
        beneficiaryRefCB: row.beneficiaryRefCB ?? '',
        currency: row.currency,
        purposeOfPayment: row.purposeOfPayment,
        remittanceInfo: row.remittanceInfo,
        amount: row.amount,
        status: row.status,
        // The day the instant falls on in the session zone, dd-MM-yyyy.
        transactionDate: row.createdAt ? formatInstant(row.createdAt, 'date') : '',
        duration: row.durationSeconds,
        corporateName: row.corporateName,
        fileName: row.fileName,
        recordCount: row.recordCount,
      })),
    [txnQ.data, rail, formatInstant],
  );

  // Select filters offer the values actually present, so you can never pick an empty result.
  const columnsWithOptions = useMemo(
    () =>
      columns.map((col) => {
        if (col.filterType !== 'select') return col;
        const values = [...new Set(rows.map((r) => String(r[col.key] ?? '')).filter(Boolean))].sort();
        return { ...col, filterOptions: ['All', ...values] };
      }),
    [columns, rows],
  );

  const filteredRows = useMemo(() => {
    const entries = Object.entries(columnFilters);
    const matched = entries.length === 0
      ? rows
      : rows.filter((txn) =>
          entries.every(([key, value]) => String(txn[key] ?? '').toLowerCase().includes(value.toLowerCase())),
        );
    const col = columns.find((c) => c.key === sortColumn);
    if (!col) return matched;
    return [...matched].sort((a, b) => {
      const av = a[sortColumn];
      const bv = b[sortColumn];
      if (typeof av === 'number' && typeof bv === 'number') return sortDirection === 'desc' ? bv - av : av - bv;
      const cmp = String(av ?? '').localeCompare(String(bv ?? ''));
      return sortDirection === 'desc' ? -cmp : cmp;
    });
  }, [rows, columnFilters, columns, sortColumn, sortDirection]);

  const visibleColumns = columnsWithOptions.filter((c) => c.visible);
  const activeFilterCount = Object.keys(columnFilters).length;
  const isWps = rail?.toUpperCase() === 'WPS';

  // Server total when unfiltered; the client-side filtered count once a filter is applied,
  // since filtering only ever narrows the page already fetched.
  const totalCount = activeFilterCount > 0 ? filteredRows.length : txnQ.data?.totalCount ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const pageStart = totalCount === 0 ? 0 : (pageNumber - 1) * pageSize + 1;
  const pageEnd = Math.min(pageNumber * pageSize, totalCount);

  /** WPS counts employee records inside the loaded SIF files; other rails count rows. */
  const recordsLoaded = isWps ? filteredRows.reduce((sum, t) => sum + (t.recordCount ?? 0), 0) : filteredRows.length;
  const recordsLoadedLabel = isWps ? 'Total Record Count' : 'Records Loaded';

  const sortBy = (key: string) => {
    if (sortColumn === key) {
      setSortDirection((d) => (d === 'desc' ? 'asc' : 'desc'));
    } else {
      setSortColumn(key);
      setSortDirection('desc');
    }
  };
  const sortIndicator = (key: string) => (sortColumn !== key ? '↕' : sortDirection === 'desc' ? '▼' : '▲');

  const activateFilter = (key: string) => {
    setPendingFilters((p) => ({ ...p, [key]: columnFilters[key] ?? '' }));
    setActiveFilterColumns((s) => new Set(s).add(key));
  };
  const deactivateFilter = (key: string) =>
    setActiveFilterColumns((s) => {
      const next = new Set(s);
      next.delete(key);
      return next;
    });

  const applyFilters = () => {
    const next: Record<string, string> = { ...columnFilters };
    for (const [key, value] of Object.entries(pendingFilters)) {
      if (value && value !== 'All') next[key] = value;
      else delete next[key];
    }
    setColumnFilters(next);
    setActiveFilterColumns(new Set());
    setPageNumber(1);
  };

  const clearColumnFilter = (key: string) => {
    setColumnFilters(({ [key]: _drop, ...rest }) => rest);
    setPendingFilters(({ [key]: _drop2, ...rest }) => rest);
    deactivateFilter(key);
  };

  const clearAllFilters = () => {
    setColumnFilters({});
    setPendingFilters({});
    setActiveFilterColumns(new Set());
    setPageNumber(1);
  };

  const toggleColumn = (key: string) =>
    setColumns((cols) => cols.map((c) => (c.key === key ? { ...c, visible: !c.visible } : c)));

  const resetColumnLayout = () => setColumns(columnsForRail(rail));

  const saveColumnLayout = () => {
    localStorage.setItem(`tps-modal-columns-${rail}`, JSON.stringify(columns.map((c) => ({ key: c.key, visible: c.visible }))));
    setShowColumnPanel(false);
  };

  // Drag-reorder in the column-settings list.
  const dragIndex = useRef<number | null>(null);
  const onDropAt = (target: number) => {
    const from = dragIndex.current;
    dragIndex.current = null;
    if (from === null || from === target) return;
    setColumns((cols) => {
      const next = [...cols];
      const [moved] = next.splice(from, 1);
      next.splice(target, 0, moved);
      return next;
    });
  };

  // Fetched with the session's token and saved from a blob, rather than opened as a URL: the
  // export endpoint requires an authenticated caller, and a new window would send no bearer token.
  const exportCsv = async () => {
    setExporting(true);
    try {
      const csv = await totalTransactionsApi.tpsExportCsv({
        direction,
        rail,
        filter,
        sortColumn: serverSortColumn,
        sortDirection: sortDirection.toUpperCase(),
      });
      const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
      const a = document.createElement('a');
      a.href = url;
      // date-format-ok: file-name stamp, not a displayed date
      a.download = `tps_${rail}_${direction}_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setExporting(false);
    }
  };

  const todayLabel = formatInstant(Date.now(), 'date');

  const renderCell = (txn: Txn, col: TransactionColumn) => {
    switch (col.key) {
      case 'messageType':
        return (
          <span className="rounded-md bg-[var(--accent-amber)]/15 px-1.5 py-0.5 text-[10px] font-bold uppercase text-[var(--accent-amber)]">
            {txn.messageType}
          </span>
        );
      case 'status':
        return <span className={cn('rounded px-2 py-0.5 text-[11px] font-semibold', statusTone(txn.status))}>{txn.status}</span>;
      case 'referenceNumber':
        return <span className="break-all font-mono text-[11px] text-[var(--accent)]">{txn.referenceNumber}</span>;
      case 'view':
        return (
          <button
            onClick={() => setFlowTxnId(txn.id)}
            className="inline-flex items-center gap-1 rounded-md border border-[var(--border)] bg-[var(--bg-secondary)] px-2 py-1 text-[11px] text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]"
          >
            <Search size={11} /> View
          </button>
        );
      case 'duration':
        return <span className={durationTone(txn.duration)}>{num(txn.duration)}</span>;
      case 'amount':
        return <>{txn.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} AED</>;
      default:
        return col.type === 'number' ? <>{num(txn[col.key])}</> : <>{String(txn[col.key] ?? '')}</>;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/60 p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={`${rail} ${messageType} transactions`}
      onClick={onClose}
    >
      <div
        className="w-full max-w-[1400px] overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-[var(--shadow-lg)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-3 px-5 py-3" style={{ background: HEADER_BG }}>
          <div className="min-w-0 text-white">
            <h2 className="truncate text-base font-semibold">{rail} — {messageType}</h2>
            <p className="mt-0.5 text-xs text-white/80">
              {messageCount.toLocaleString()} messages · {(activeFilterCount > 0 ? totalCount : transactionCount).toLocaleString()} transactions · {todayLabel}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <button
              onClick={() => setShowColumnPanel((v) => !v)}
              title="Column Settings"
              className="grid size-8 place-items-center rounded-md bg-white/10 text-white hover:bg-white/20"
            >
              <Settings size={15} />
            </button>
            {/* The TPS export route is on the ops:report:export group; the button mirrors it. */}
            <Can permission={PERM.opsReportExport}>
              <button
                onClick={exportCsv}
                disabled={exporting}
                className="inline-flex items-center gap-1.5 rounded-md bg-white/10 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-white/20 disabled:opacity-60"
              >
                <Download size={13} /> {exporting ? 'Exporting…' : 'Export CSV'}
              </button>
            </Can>
            <button onClick={onClose} aria-label="Close" className="grid size-8 place-items-center rounded-md bg-white/10 text-white hover:bg-white/20">
              <X size={15} />
            </button>
          </div>
        </div>

        {/* Metric blocks */}
        <div className="grid grid-cols-1 gap-px border-b border-[var(--border)] bg-[var(--border)] sm:grid-cols-3">
          {[
            { label: 'Total Messages', value: messageCount },
            { label: 'Total Transactions', value: activeFilterCount > 0 ? totalCount : transactionCount },
            { label: recordsLoadedLabel, value: recordsLoaded },
          ].map((m) => (
            <div key={m.label} className="bg-[var(--bg-secondary)] px-5 py-3">
              <p className="text-[10px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">{m.label}</p>
              <p className="mt-1 text-2xl font-bold tabular-nums text-[var(--text-primary)]">{m.value.toLocaleString()}</p>
            </div>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] px-5 py-2.5">
          {activeFilterCount > 0 && (
            <span className="text-xs text-[var(--text-muted)]">
              {activeFilterCount} filter{activeFilterCount !== 1 ? 's' : ''} active
            </span>
          )}
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={applyFilters}
              className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold text-white"
              style={{ background: HEADER_BG }}
            >
              <Search size={12} /> Search
            </button>
            <button
              onClick={clearAllFilters}
              disabled={activeFilterCount === 0}
              className="inline-flex items-center gap-1.5 rounded-md border border-[var(--border)] px-3 py-1.5 text-xs text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)] disabled:cursor-not-allowed disabled:opacity-45"
            >
              <X size={12} /> Clear Filters
            </button>
          </div>
        </div>

        <div className="flex">
          {/* Table */}
          <div className="min-w-0 flex-1 overflow-x-auto">
            {txnQ.isLoading ? (
              <div className="flex h-48 items-center justify-center"><LoadingSpinner /></div>
            ) : (
              <table className="w-full min-w-max text-xs">
                <thead>
                  <tr className="border-b border-[var(--border)] bg-[var(--bg-secondary)] text-left">
                    {visibleColumns.map((col) => {
                      const filterActive = activeFilterColumns.has(col.key);
                      const applied = !!columnFilters[col.key];
                      return (
                        <th key={col.key} className="px-3 py-2 align-bottom" style={{ minWidth: col.width }}>
                          {filterActive ? (
                            <div className="flex flex-col gap-1">
                              <span className="text-[9px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">{col.label}</span>
                              <div className="flex items-center gap-1">
                                {col.filterType === 'select' ? (
                                  <select
                                    autoFocus
                                    value={pendingFilters[col.key] ?? 'All'}
                                    onChange={(e) => {
                                      setPendingFilters((p) => ({ ...p, [col.key]: e.target.value }));
                                      applyFilters();
                                    }}
                                    onBlur={() => deactivateFilter(col.key)}
                                    className="h-7 w-full rounded border border-[var(--border)] bg-[var(--bg-input)] px-1 text-[11px] text-[var(--text-primary)]"
                                  >
                                    {(col.filterOptions ?? ['All']).map((opt) => (
                                      <option key={opt} value={opt}>{opt}</option>
                                    ))}
                                  </select>
                                ) : (
                                  <input
                                    autoFocus
                                    value={pendingFilters[col.key] ?? ''}
                                    onChange={(e) => setPendingFilters((p) => ({ ...p, [col.key]: e.target.value }))}
                                    onKeyDown={(e) => { if (e.key === 'Enter') applyFilters(); }}
                                    onBlur={() => deactivateFilter(col.key)}
                                    placeholder="Search…"
                                    className="h-7 w-full rounded border border-[var(--border)] bg-[var(--bg-input)] px-1.5 text-[11px] text-[var(--text-primary)] outline-none focus:border-[var(--accent)]"
                                  />
                                )}
                                <button onClick={() => clearColumnFilter(col.key)} className="text-[var(--text-muted)] hover:text-[var(--accent-red)]" aria-label="Clear filter">×</button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5">
                              <span className={cn('text-[10px] font-semibold uppercase tracking-wide', col.type === 'number' ? 'text-right' : '', 'text-[var(--text-muted)]')}>
                                {col.label}
                              </span>
                              {col.sortable && (
                                <button
                                  onClick={() => sortBy(col.key)}
                                  aria-label={`Sort by ${col.label}`}
                                  className={cn('text-[10px]', sortColumn === col.key ? 'text-[var(--accent)]' : 'text-[var(--text-muted)] hover:text-[var(--text-secondary)]')}
                                >
                                  {sortIndicator(col.key)}
                                </button>
                              )}
                              {col.filterable && (
                                <button
                                  onClick={() => activateFilter(col.key)}
                                  title={applied ? `Filtering: ${columnFilters[col.key]} — click to edit` : 'Filter this column'}
                                  aria-label={`Filter ${col.label}`}
                                  className={cn('text-[10px]', applied ? 'text-[var(--accent)]' : 'text-[var(--text-muted)] hover:text-[var(--text-secondary)]')}
                                >
                                  ⏷
                                </button>
                              )}
                              {applied && (
                                <button onClick={() => clearColumnFilter(col.key)} title="Remove filter" className="text-[10px] text-[var(--accent-red)]">×</button>
                              )}
                            </div>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border-light)]">
                  {filteredRows.length === 0 ? (
                    <tr>
                      <td colSpan={visibleColumns.length} className="px-3 py-10 text-center text-[var(--text-muted)]">
                        No transactions match the current filters.
                      </td>
                    </tr>
                  ) : (
                    filteredRows.map((txn, i) => (
                      <tr key={`${txn.id}-${i}`} className="odd:bg-[var(--bg-secondary)] hover:bg-[var(--bg-card-hover)]">
                        {visibleColumns.map((col) => (
                          <td
                            key={col.key}
                            className={cn('px-3 py-2 align-middle', col.type === 'number' && 'text-right tabular-nums')}
                          >
                            {renderCell(txn, col)}
                          </td>
                        ))}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            )}
          </div>

          {/* Column settings panel */}
          {showColumnPanel && (
            <aside className="w-64 shrink-0 border-l border-[var(--border)] bg-[var(--bg-secondary)]">
              <div className="flex items-center justify-between border-b border-[var(--border)] px-3 py-2">
                <span className="text-xs font-semibold text-[var(--text-primary)]">Column Settings</span>
                <button onClick={() => setShowColumnPanel(false)} aria-label="Close column settings" className="text-[var(--text-muted)] hover:text-[var(--text-primary)]">
                  <X size={13} />
                </button>
              </div>
              <ul className="max-h-72 overflow-y-auto px-2 py-2">
                {columns.map((col, i) => (
                  <li
                    key={col.key}
                    draggable
                    onDragStart={() => { dragIndex.current = i; }}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={() => onDropAt(i)}
                    className="flex cursor-grab items-center gap-2 rounded px-1.5 py-1 text-xs text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]"
                  >
                    <span aria-hidden="true" className="text-[var(--text-muted)]">⋮⋮</span>
                    <input
                      type="checkbox"
                      checked={col.visible}
                      onChange={() => toggleColumn(col.key)}
                      id={`col-${col.key}`}
                      className="accent-[var(--accent)]"
                    />
                    <label htmlFor={`col-${col.key}`} className="min-w-0 flex-1 truncate">{col.label}</label>
                  </li>
                ))}
              </ul>
              <div className="flex gap-2 border-t border-[var(--border)] px-3 py-2">
                <button onClick={resetColumnLayout} className="flex-1 rounded-md border border-[var(--border)] px-2 py-1 text-[11px] text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]">
                  Reset Default
                </button>
                <button onClick={saveColumnLayout} className="flex-1 rounded-md px-2 py-1 text-[11px] font-semibold text-white" style={{ background: HEADER_BG }}>
                  Save
                </button>
              </div>
            </aside>
          )}
        </div>

        {/* Footer / pagination */}
        <div className="pq-pagination">
          <span>
            Showing <strong>{pageStart}–{pageEnd}</strong> of <strong>{totalCount.toLocaleString()}</strong> transactions
          </span>
          <div className="pq-pagination-controls">
            <div className="pq-pagesize">
              <span>Rows per page:</span>
              <div className="pq-pagesize-select">
                <select
                  value={pageSize}
                  onChange={(e) => { setPageSize(Number(e.target.value)); setPageNumber(1); }}
                >
                  {PAGE_SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
                <ChevronDown size={13} className="pq-pagesize-caret" />
              </div>
            </div>
            <button type="button" onClick={() => setPageNumber((p) => Math.max(1, p - 1))} disabled={pageNumber <= 1} className="btn-tertiary">
              <ChevronLeft size={14} /> Previous
            </button>
            <span className="pq-page-badge">{pageNumber}</span>
            <button type="button" onClick={() => setPageNumber((p) => Math.min(totalPages, p + 1))} disabled={pageNumber >= totalPages} className="btn-tertiary">
              Next <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>

      {flowTxnId && <TransactionFlowModal txnId={flowTxnId} onClose={() => setFlowTxnId(null)} />}
    </div>
  );
}
