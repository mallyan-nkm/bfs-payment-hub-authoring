import { useEffect, useState } from 'react';
import { cn } from '@paymenthub/ui';
import {RefreshCcw, SlidersVertical} from 'lucide-react';

export interface RefreshControlPanelProps {
  paused: boolean;
  /** Epoch ms of the last completed refresh — drives the "Updated Xs ago" label. */
  lastRefreshAt: number;
  intervalMs: number;
  onIntervalChange: (ms: number) => void;
  onPauseToggle: (paused: boolean) => void;
  onManualRefresh: () => void;
}

const INTERVAL_OPTIONS: ReadonlyArray<{ label: string; value: number }> = [
  { label: '10s', value: 10_000 },
  { label: '30s', value: 30_000 },
  { label: '1m', value: 60_000 },
  { label: '2m', value: 120_000 },
];

const BTN =
  'transition-colors';
const BTN_ACTIVE = 'border-[var(--accent)]';

/**
 * Live indicator + auto-refresh controls for the Live Operations Dashboard — port of the
 * Angular `widget-refresh-control-panel`. It owns no timer of its own: the parent dashboard
 * holds the single refresh clock and this panel only reports intent (interval / pause /
 * refresh-now) and renders how stale the data is.
 */
export function RefreshControlPanel({
  paused,
  lastRefreshAt,
  intervalMs,
  onIntervalChange,
  onPauseToggle,
  onManualRefresh,
}: RefreshControlPanelProps) {
  // Re-render once a second purely so the "Xs ago" text stays truthful between refreshes.
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setTick((n) => n + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  const [spinning, setSpinning] = useState(false);
  const handleManualRefresh = () => {
    onManualRefresh();
    setSpinning(true);
    window.setTimeout(() => setSpinning(false), 650);
  };

  const seconds = Math.max(0, Math.floor((Date.now() - lastRefreshAt) / 1000));
  const ago = seconds < 60 ? `${seconds}s ago` : `${Math.floor(seconds / 60)}m ago`;

  return (
    <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--text-primary)]">
      <span
        className={cn(
          'size-2 shrink-0 rounded-full',
          paused ? 'bg-[var(--accent-amber)]' : 'animate-pulse bg-[var(--accent-green)]',
        )}
      />
      {paused ? 'Paused' : `Updated ${ago}`}
      <div className="ml-2 flex flex-wrap gap-1">
        {/* {INTERVAL_OPTIONS.map((opt) => (
          <button
            key={opt.value}
            type="button"
            onClick={() => onIntervalChange(opt.value)}
            className={cn(BTN, intervalMs === opt.value && !paused ? BTN_ACTIVE : 'hover:bg-[var(--bg-card-hover)]')}
          >
            {opt.label}
          </button>
        ))} */}
        <div className='select-holder flex align-items-center'>
          <label>Auto Refresh : </label>
        <select
          value={paused ? '' : intervalMs}
          onChange={(e) => onIntervalChange(Number(e.target.value))}
          className="h-8 rounded-lg border border-[var(--border-subtle)] bg-[var(--bg-card)] px-2 text-xs font-medium text-[var(--text-primary)] outline-none transition-colors hover:bg-[var(--bg-card-hover)] focus:border-[var(--brand-primary)]"
        >
          {INTERVAL_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value} className="bg-[var(--bg-card)] text-[var(--text-primary)]">
              {opt.label}
            </option>
          ))}
        </select>
        </div>
        <button
          type="button"
          onClick={() => onPauseToggle(!paused)}
          title={paused ? 'Resume auto-refresh' : 'Pause auto-refresh'}
          className={cn(BTN, paused ? BTN_ACTIVE : 'hover:bg-[var(--bg-card-hover)], icon-btn')}
        >
          {paused ? '▶' : '⏸'}
        </button>
        <button
          type="button"
          onClick={handleManualRefresh}
          title="Manual refresh"
          className={cn(BTN, 'hover:bg-[var(--bg-card-hover)], icon-btn')}
        >
          <RefreshCcw size={16} className={cn(BTN, spinning && 'animate-spin')}/>
        </button>
         <button
          type="button"
          title="Configure Widgets"
          className={cn(BTN, 'hover:bg-[var(--bg-card-hover)], icon-btn')}
        >
          <SlidersVertical size={16}/>
        </button>
      </div>
    </div>
  );
}
