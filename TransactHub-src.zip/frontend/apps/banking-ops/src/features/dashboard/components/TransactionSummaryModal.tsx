import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, X } from 'lucide-react';
import { LoadingSpinner, cn, useSessionDateTime } from '@paymenthub/ui';
import { useRailAccess } from '../../../shared/auth/rails';
import { opsDashboardApi } from '../api';
import type { MessagePipeline, PipelineStage, PipelineStageWithResponse } from '../types';
import { StatusMixDonut, STATUS_MIX_COLORS } from './StatusMixDonut';
import { HourlyVolumeBars } from './HourlyVolumeBars';

type FlowDirection = 'outward' | 'inbound';

interface Props {
  direction: FlowDirection;
  onClose: () => void;
}

const RAIL_CHIPS: ReadonlyArray<{ id: string; label: string }> = [
  { id: 'ALL', label: 'All Rails' },
  { id: 'IPI', label: 'IPI' },
  { id: 'FTS', label: 'UAEFTS' },
  { id: 'WPS', label: 'WPS' },
  { id: 'IPP', label: 'IPP' },
  { id: 'SWIFT', label: 'SWIFT' },
];

const RAIL_FULL_NAME: Record<string, string> = {
  IPI: 'Immediate Payment',
  FTS: 'UAE Funds Transfer',
  WPS: 'Wage Protection',
  IPP: 'Instant Payment',
  SWIFT: 'SWIFT Payments',
};

const num = (n: number | null | undefined) => (n ?? 0).toLocaleString();
const pct1 = (n: number | null | undefined) => (n ?? 0).toFixed(1);

function formatAed(value: number | null | undefined): string {
  const v = value ?? 0;
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
  return v.toLocaleString();
}

function formatChartTotalValue(value: number): string {
  if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2)}B`;
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return value.toLocaleString();
}

function formatAvgTime(sec: number | null | undefined): string {
  const s = sec ?? 0;
  if (s <= 0) return '—';
  if (s < 60) return `${s.toFixed(0)}s`;
  const m = Math.floor(s / 60);
  const rem = Math.round(s % 60);
  return rem > 0 ? `${m}m ${rem}s` : `${m}m`;
}

const KPI_TILES = [
  { key: 'totalTxns', label: 'Total', color: 'var(--text-primary)' },
  { key: 'success', label: 'Processed', color: 'var(--accent-green)' },
  { key: 'inProgress', label: 'System Processing', color: 'var(--accent-blue)' },
  { key: 'pending', label: 'Pending', color: 'var(--accent-amber)' },
  { key: 'failed', label: 'Failed', color: 'var(--accent-red)' },
] as const;

const TH = 'px-3.5 py-3 text-right text-[14px] font-semibold uppercase tracking-wide text-[#4B5563] whitespace-nowrap';
const TD = 'px-3.5 py-3 text-right tabular-nums text-[14px] text-[var(--text-secondary)] whitespace-nowrap';
const SECTION = 'input-label text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]';

export function TransactionSummaryModal({ direction, onClose }: Props) {
  const navigate = useNavigate();
  const { allows: allowsRail } = useRailAccess();
  const { formatInstant } = useSessionDateTime();
  const [activeTab, setActiveTab] = useState<'summary' | 'recon'>('summary');
  const [selectedRail, setSelectedRail] = useState('ALL');
  const [reconRail, setReconRail] = useState('IPI');
  const [wpsMsgType, setWpsMsgType] = useState<'SIF' | 'RFR'>('SIF');

  // 'ALL' is not a rail and stays for everyone — it is the cross-rail view, which the server
  // answers with only the rails the session holds. The rest of the chips are what this session
  // may actually open.
  const railChips = RAIL_CHIPS.filter((chip) => chip.id === 'ALL' || allowsRail(chip.id));
  const heldRailIds = railChips.filter((chip) => chip.id !== 'ALL').map((chip) => chip.id);
  const heldRailKey = heldRailIds.join(',');

  // Neither picked rail can stay on its literal default: 'IPI' is wrong for anyone not entitled to
  // IPI, and both endpoints now refuse a rail the caller does not hold. Corrected in effects rather
  // than initialisers because the permission snapshot resolves after first paint — until it lands
  // every key reads as denied, so heldRailIds starts empty for everyone.
  useEffect(() => {
    if (heldRailIds.length > 0 && !heldRailIds.includes(reconRail)) setReconRail(heldRailIds[0]);
    // heldRailKey stands in for the array, which is rebuilt on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [heldRailKey, reconRail]);

  useEffect(() => {
    if (selectedRail !== 'ALL' && !allowsRail(selectedRail)) setSelectedRail('ALL');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [heldRailKey, selectedRail]);

  const dirLabel = direction === 'outward' ? 'Outward' : 'Inbound';
  const todayLabel = formatInstant(Date.now(), 'date');

  const summaryQ = useQuery({
    queryKey: ['flow-txn-summary', direction],
    queryFn: () => opsDashboardApi.transactionSummaryByRail(direction),
  });

  const chartsQ = useQuery({
    queryKey: ['flow-txn-charts', selectedRail],
    enabled: selectedRail !== 'ALL',
    queryFn: () => opsDashboardApi.transactionSummaryCharts(selectedRail),
  });

  const reconQ = useQuery({
    queryKey: ['flow-recon', reconRail],
    // Also gated on access: message-reconciliation now refuses a rail the caller does not hold,
    // so the render between first paint and the snapshot resolving must not fire with the default.
    enabled: activeTab === 'recon' && allowsRail(reconRail),
    queryFn: () => opsDashboardApi.messageReconciliation(reconRail),
  });

  const summary = summaryQ.data;
  // Presentation filter over rows the server has already confined; `totals` below comes from the
  // same response and is summed there, so the table and its total row cannot disagree.
  const visibleRails = (summary?.rails ?? []).filter((r) => allowsRail(r.rail));
  const rows = selectedRail === 'ALL' ? visibleRails : visibleRails.filter((r) => r.rail?.toUpperCase() === selectedRail);
  const kpiSource = selectedRail === 'ALL' ? summary?.totals : rows[0];
  const charts = chartsQ.data;
  const recon = reconQ.data;

  const openRail = (rail: string) => {
    // The rows this is reachable from are filtered above; this is the backstop, because the target
    // page would open on a rail the caller cannot read and every query on it would be refused.
    if (!allowsRail(rail)) return;
    onClose();
    navigate(`/total-transactions?direction=${direction}&rail=${encodeURIComponent(rail)}`);
  };

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={`${dirLabel} transaction summary`}
      onClick={onClose}
    >
      <div
        className="flex h-full w-full max-w-4xl sm:max-w-5xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div className="min-w-0">
            <h2 className="text-xl font-bold text-[var(--text-primary)]">
              {dirLabel} Transaction Summary
            </h2>
            <p className="mt-1 text-xs text-[var(--text-muted)]">
              Today — {todayLabel} · All Payment Rails Overview
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 border-b border-[var(--border)] bg-[var(--bg-secondary)]/30 px-6 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('summary')}
            className={cn(
              'border-b-2 px-4 py-2.5 text-sm font-bold transition-colors whitespace-nowrap inline-flex items-center gap-1.5',
              activeTab === 'summary'
                ? 'border-[var(--primary-blue)] text-[var(--primary-blue)] bg-[var(--bg-card)] rounded-t-md'
                : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]',
            )}
          >
             Transaction Summary
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('recon')}
            className={cn(
              'border-b-2 px-4 py-2.5 text-sm font-bold transition-colors whitespace-nowrap inline-flex items-center gap-1.5',
              activeTab === 'recon'
                ? 'border-[var(--primary-blue)] text-[var(--primary-blue)] bg-[var(--bg-card)] rounded-t-md'
                : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]',
            )}
          >
            Message Reconciliation
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'summary' && (
            <div className="flex flex-col gap-6">
              {summaryQ.isLoading ? (
                <div className="flex h-48 items-center justify-center">
                  <LoadingSpinner />
                </div>
              ) : (
                <>
                  {/* Rail Filter Pill Tabs */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="mr-1 text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                      View by rail:
                    </span>
                    {railChips.map((chip) => (
                      <button
                        key={chip.id}
                        type="button"
                        onClick={() => setSelectedRail(chip.id)}
                        className={cn(
                          'common-pill',
                          selectedRail === chip.id
                            ? 'active-pill'
                            : '',
                        )}
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>

                  {/* 5 KPI Metric Cards */}
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                    {KPI_TILES.map((tile) => (
                      <div
                        key={tile.key}
                        className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 text-center shadow-xs transition-shadow hover:shadow-sm"
                        style={{ borderTop: `3px solid ${tile.color}` }}
                      >
                        <p className="text-2xl font-bold tabular-nums" style={{ color: tile.color }}>
                          {num(kpiSource?.[tile.key])}
                        </p>
                        <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                          {tile.label}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Single-Rail Analytics Section */}
                  {selectedRail !== 'ALL' && (
                    <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
                      <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 shadow-xs">
                        <p className={SECTION}>Status Mix — {selectedRail}</p>
                        {chartsQ.isLoading ? (
                          <div className="flex h-56 items-center justify-center">
                            <LoadingSpinner />
                          </div>
                        ) : (
                          <>
                            <div className="relative mx-auto mt-4 grid w-[200px] place-items-center">
                              <StatusMixDonut
                                mix={
                                  charts?.statusMix ?? {
                                    total: 0,
                                    processed: 0,
                                    systemProcessing: 0,
                                    pending: 0,
                                    failed: 0,
                                  }
                                }
                              />
                              <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                                <div>
                                  <p className="text-2xl font-bold tabular-nums text-[var(--text-primary)]">
                                    {num(charts?.statusMix?.total)}
                                  </p>
                                  <p className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                                    Total
                                  </p>
                                </div>
                              </div>
                            </div>
                            <ul className="mt-4 flex flex-col gap-1.5 text-xs text-[var(--text-secondary)] border-t border-[var(--border)] pt-3">
                              <LegendRow
                                color={STATUS_MIX_COLORS.processed}
                                label="Processed"
                                value={charts?.statusMix?.processed}
                              />
                              <LegendRow
                                color={STATUS_MIX_COLORS.systemProcessing}
                                label="System Processing"
                                value={charts?.statusMix?.systemProcessing}
                              />
                              <LegendRow
                                color={STATUS_MIX_COLORS.pending}
                                label="Pending"
                                value={charts?.statusMix?.pending}
                              />
                              <LegendRow
                                color={STATUS_MIX_COLORS.failed}
                                label="Failed"
                                value={charts?.statusMix?.failed}
                              />
                            </ul>
                          </>
                        )}
                      </div>

                      <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 shadow-xs">
                        <div className="flex items-center justify-between gap-2 border-b border-[var(--border)] pb-3">
                          <p className={SECTION}>24-Hour Volume — {selectedRail}</p>
                          <span className="rounded-full border border-[var(--border)] bg-[var(--bg-secondary)] px-2.5 py-0.5 text-[11px] font-semibold text-[var(--text-secondary)]">
                            Avg: {formatAvgTime(charts?.avgProcessingTimeSeconds)}
                          </span>
                        </div>
                        {chartsQ.isLoading ? (
                          <div className="flex h-56 items-center justify-center">
                            <LoadingSpinner />
                          </div>
                        ) : (
                          <>
                            <div className="mt-3">
                              <HourlyVolumeBars hours={charts?.hourlyVolume ?? []} />
                            </div>
                            <div className="mt-3 flex flex-wrap gap-4 text-xs text-[var(--text-secondary)]">
                              <InlineLegend color={STATUS_MIX_COLORS.processed} label="Processed" />
                              <InlineLegend color={STATUS_MIX_COLORS.pending} label="Pending" />
                              <InlineLegend color={STATUS_MIX_COLORS.failed} label="Failed" />
                            </div>
                            <div className="mt-4 rounded-lg bg-[var(--bg-secondary)]/50 p-3 text-xs text-[var(--text-secondary)] border border-[var(--border)]">
                              Total Value:{' '}
                              <strong className="text-[var(--text-primary)] font-bold font-mono ml-1">
                                {formatChartTotalValue(charts?.totalValue ?? 0)} AED
                              </strong>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  {/* All Rails Summary Table */}
                  {selectedRail === 'ALL' && (
                    <div className="overflow-x-auto rounded-lg border border-[var(--border)] table-holder">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border) px-[12px] py-[8px]">
                        <span className="text-[13px] font-semibold text-[var(--text-primary)]">
                          All Rails Breakdown
                        </span>
                      </div>
                      <div className="overflow-x-auto">
                        <table >
                          <thead>
                            <tr >
                              <th >
                                Rail
                              </th>
                              <th className={TH}>Total</th>
                              <th className={cn(TH, 'text-green-700')}>Processed</th>
                              <th className={cn(TH, 'text-blue-700')}>In Progress</th>
                              <th className={cn(TH, 'text-amber-700')}>Pending</th>
                              <th className={cn(TH, 'text-red-700')}>Failed</th>
                              <th className={TH}>Value (AED)</th>
                              <th className={TH}>Avg Time</th>
                              <th className="w-10"></th>
                            </tr>
                          </thead>
                          <tbody >
                            {rows.length === 0 ? (
                              <tr>
                                <td colSpan={9} className="px-4 py-8 text-center text-xs text-[var(--text-muted)]">
                                  No transactions recorded today.
                                </td>
                              </tr>
                            ) : (
                              rows.map((row) => (
                                <tr
                                  key={row.rail}
                                  onClick={() => openRail(row.rail)}
                                  className="group cursor-pointer odd:bg-[var(--bg-secondary)]/20 hover:bg-[var(--bg-card-hover)] transition-colors"
                                >
                                  <td className="px-3.5 py-3">
                                    <span className="inline-flex rounded-md border border-[var(--border)] bg-white px-2 py-0.5 text-xs font-bold uppercase text-[var(--primary-blue)] shadow-2xs">
                                      {row.rail}
                                    </span>
                                  </td>
                                  <td className={cn(TD, 'font-bold text-[var(--text-primary)]')}>
                                    {num(row.totalTxns)}
                                  </td>
                                  <td className={cn(TD, 'font-semibold text-green-700')}>
                                    {num(row.success)}
                                  </td>
                                  <td className={cn(TD, 'font-semibold text-blue-700')}>
                                    {num(row.inProgress)}
                                  </td>
                                  <td className={cn(TD, 'font-semibold text-amber-700')}>
                                    {num(row.pending)}
                                  </td>
                                  <td className={cn(TD, 'font-semibold text-red-700')}>
                                    {num(row.failed)}
                                  </td>
                                  <td className={cn(TD, 'font-mono')}>{formatAed(row.totalAed)}</td>
                                  <td className={cn(TD, 'text-[var(--text-muted)]')}>—</td>
                                  <td className="px-2 text-center text-[var(--text-muted)] group-hover:text-[var(--primary-blue)] transition-colors">
                                    <ChevronRight size={16} />
                                  </td>
                                </tr>
                              ))
                            )}
                            <tr className="border-t-2 border-[var(--border)] bg-[var(--bg-secondary)]/40 font-bold text-[var(--text-primary)]">
                              <td className="px-3.5 py-3 font-extrabold uppercase text-xs text-[var(--text-primary)]">
                                Total Summary
                              </td>
                              <td className={TD}>{num(summary?.totals?.totalTxns)}</td>
                              <td className={cn(TD, 'text-green-700')}>{num(summary?.totals?.success)}</td>
                              <td className={cn(TD, 'text-blue-700')}>{num(summary?.totals?.inProgress)}</td>
                              <td className={cn(TD, 'text-amber-700')}>{num(summary?.totals?.pending)}</td>
                              <td className={cn(TD, 'text-red-700')}>{num(summary?.totals?.failed)}</td>
                              <td className={cn(TD, 'font-mono')}>{formatAed(summary?.totals?.totalAed)}</td>
                              <td className={TD}>{formatAvgTime(summary?.avgProcessingTimeSec)}</td>
                              <td></td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {activeTab === 'recon' && (
            <div className="flex flex-col gap-6">
              {reconQ.isLoading ? (
                <div className="flex h-48 items-center justify-center">
                  <LoadingSpinner />
                </div>
              ) : !recon ? (
                <div className="rounded-xl border border-[var(--border)] p-12 text-center text-xs italic text-[var(--text-muted)]">
                  Reconciliation data is currently unavailable.
                </div>
              ) : (
                <>
                  <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-xs">
                    <label className="input-label">Select Payment Rail</label>
                    <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                      {/* Presentation filter over cards the server has already confined: a rail
                          this session does not hold has no card to click, so reconRail can never
                          be set to one the endpoint would refuse. */}
                      {recon.railSummaries.filter((card) => allowsRail(card.rail)).map((card) => {
                        const isSelected = card.rail === reconRail;
                        return (
                          <button
                            key={card.rail}
                            type="button"
                            onClick={() => {
                              if (card.rail === reconRail) return;
                              setReconRail(card.rail);
                              setWpsMsgType('SIF');
                            }}
                            className={cn(
                              'rail-card',
                              isSelected
                                ? 'rail-card-selected'
                                : '',
                            )}
                          >
                            <span
                              className={cn(
                                'common-badge',
                              )}
                            >
                              {card.railLabel}
                            </span>
                            <p className="mt-2 text-xs font-semibold text-[var(--text-primary)]">
                              {RAIL_FULL_NAME[card.rail] ?? card.rail}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex flex-col w-full self-stretch overflow-hidden rounded-[var(--brdr-radius-big)] border border-[var(--border)] bg-[var(--plain-bg)] ">
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] p-[var(--default-padding)]">
                      <div className="flex items-center gap-2">
                        <span className="badge-selected">
                          {recon.pipeline.railLabel}
                        </span>
                        <h4 >
                          {recon.pipeline.railDescription}
                        </h4>
                      </div>
                      {reconRail === 'WPS' && (
                        <div className="flex items-center gap-1.5">
                          {(['SIF', 'RFR'] as const).map((t) => (
                            <button
                              key={t}
                              type="button"
                              onClick={() => setWpsMsgType(t)}
                              className={cn(
                                'common-pill',
                                wpsMsgType === t
                                  ? 'active-pill'
                                  : '',
                              )}
                            >
                              {t}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {reconRail !== 'WPS' || wpsMsgType === 'SIF' ? (
                      <PipelineRows pipeline={recon.pipeline} />
                    ) : (
                      <div className="mt-4">
                        <PipelineRows pipeline={EMPTY_RFR_PIPELINE} showRouted={false} />
                        <p className="mt-4 text-center text-xs italic text-[var(--text-muted)]">
                          No RFR reconciliation data recorded yet.
                        </p>
                      </div>
                    )}
                  </div>

                  {recon.pendingAlerts.hasAlerts && (
                    <div className="flex items-center gap-2.5 rounded-xl border border-amber-300 bg-amber-50 p-4 text-xs font-semibold text-amber-900 shadow-xs">
                      <span className="text-amber-600 font-bold">⚠</span>
                      <span>{recon.pendingAlerts.alertMessage}</span>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <span className="text-xs text-[var(--text-muted)] font-medium">
            Directional operational summary for banking reconciliation
          </span>
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary large-btn !w-32 justify-center"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

function LegendRow({ color, label, value }: { color: string; label: string; value: number | undefined }) {
  return (
    <li className="flex items-center justify-between">
      <span className="flex items-center gap-2">
        <span className="size-2 shrink-0 rounded-full" style={{ background: color }} />
        <span>{label}</span>
      </span>
      <strong className="font-mono text-[var(--text-primary)]">{num(value)}</strong>
    </li>
  );
}

function InlineLegend({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="size-2 shrink-0 rounded-full" style={{ background: color }} />
      <span>{label}</span>
    </span>
  );
}

const BAR_TRACK = 'progress-bar-base';

function PipelineRows({ pipeline, showRouted = true }: { pipeline: MessagePipeline; showRouted?: boolean }) {
  const initiatedPct = pipeline.initiated.count > 0 ? 100 : 0;
  return (
    <div className="p-[var(--default-padding)] flex flex-col gap-2">
      <StageRow stage={pipeline.initiated} percentage={initiatedPct} color="#3b82f6" baseLabel="" />
      <StageRow
        stage={pipeline.ffts0001}
        percentage={pipeline.ffts0001.percentage}
        color="#6366f1"
        baseLabel="of initiated"
      />
      <ResponseStageRow stage={pipeline.ffts0002} color="#22c55e" />
      <ResponseStageRow stage={pipeline.ffts0006} color="#f59e0b" />
      {showRouted && (
        <StageRow
          stage={pipeline.routedToOtherChannel}
          percentage={pipeline.routedToOtherChannel.percentage}
          color="#fb923c"
          baseLabel="of initiated"
          warn
        />
      )}
    </div>
  );
}

function StageRow({
  stage,
  percentage,
  color,
  baseLabel,
  warn,
}: {
  stage: PipelineStage;
  percentage: number;
  color: string;
  baseLabel: string;
  warn?: boolean;
}) {
  return (
    <div className="flex flex-wrap items-center gap-3 sm:flex-nowrap">
      <div className={cn('w-44 shrink-0 text-xs', warn ? 'text-amber-700 font-bold' : 'text-[var(--text-secondary)]')}>
        <strong className={warn ? undefined : 'text-[var(--text-primary)]'}>{stage.label}</strong>
        {stage.sublabel && <span className="ml-1 text-[var(--text-muted)]">{stage.sublabel}</span>}
      </div>
      <div className={BAR_TRACK}>
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{ width: `${Math.min(100, Math.max(0, percentage))}%`, background: color }}
        />
      </div>
      <div className="w-44 shrink-0 text-right text-xs">
        <span className={cn('font-bold tabular-nums', warn ? 'text-amber-700' : 'text-[var(--text-primary)]')}>
          {num(stage.count)}
        </span>
        <span className="ml-2 font-mono text-[var(--text-muted)]">{pct1(percentage)}%</span>
        {baseLabel && <span className="ml-1 text-[var(--text-muted)]">{baseLabel}</span>}
      </div>
    </div>
  );
}

function ResponseStageRow({ stage, color }: { stage: PipelineStageWithResponse; color: string }) {
  const combinedPct = stage.acceptedPct + stage.rejectedPct;
  return (
    <div className="flex flex-wrap items-center gap-3 sm:flex-nowrap">
      <div className="w-44 shrink-0 text-xs text-[var(--text-secondary)]">
        <strong className="text-[var(--text-primary)]">{stage.label}</strong>
        {stage.sublabel && <span className="ml-1 text-[var(--text-muted)]">{stage.sublabel}</span>}
      </div>
      <div className={BAR_TRACK}>
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{ width: `${Math.min(100, Math.max(0, combinedPct))}%`, background: color }}
        />
      </div>
      <div className="w-44 shrink-0 text-right text-xs">
        <span className="font-bold tabular-nums text-[var(--text-primary)]">{num(stage.totalCount)}</span>
        <span className="ml-2 font-mono text-[var(--text-muted)]">{pct1(combinedPct)}%</span>
        <span className="ml-1 text-[var(--text-muted)]">of {num(stage.baseCount)} sent</span>
        <div className="mt-1 flex justify-end gap-3 text-[11px] font-semibold">
          <span className="text-green-700">Accepted: {num(stage.acceptedCount)}</span>
          <span className="text-red-600">Rejected: {num(stage.rejectedCount)}</span>
        </div>
      </div>
    </div>
  );
}

const zeroStage = (label: string, sublabel = ''): PipelineStage => ({ label, sublabel, count: 0, percentage: 0 });
const zeroResponseStage = (label: string, sublabel = ''): PipelineStageWithResponse => ({
  label,
  sublabel,
  totalCount: 0,
  acceptedCount: 0,
  rejectedCount: 0,
  acceptedPct: 0,
  rejectedPct: 0,
  baseCount: 0,
});

const EMPTY_RFR_PIPELINE: MessagePipeline = {
  railLabel: 'WPS',
  railDescription: 'Wage Protection System',
  initiated: zeroStage('Initiated'),
  ffts0001: zeroStage('RFR', '(Sent to CB)'),
  ffts0002: zeroResponseStage('CB Response', '(ACK / NAK)'),
  ffts0006: zeroResponseStage('Settlement', '(Channel Notified)'),
  routedToOtherChannel: zeroStage('Routed to Other Channel'),
};