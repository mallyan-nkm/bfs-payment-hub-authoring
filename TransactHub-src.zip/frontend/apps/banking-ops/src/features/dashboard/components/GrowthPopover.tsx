import { useEffect, useRef, useState } from 'react';
import { LineChart, X } from 'lucide-react';
import { GrowthChart, type GrowthPoint } from './GrowthChart';

/** Compact trigger that expands the Transaction Growth chart into a popover on hover or click — keeps the dashboard dense. */
export function GrowthPopover({ points }: { points: GrowthPoint[] }) {
  const [pinned, setPinned] = useState(false);
  const [hovering, setHovering] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const open = pinned || hovering;

  useEffect(() => {
    if (!pinned) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setPinned(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setPinned(false);
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [pinned]);

  return (
    <div className="relative" ref={ref} onMouseEnter={() => setHovering(true)} onMouseLeave={() => setHovering(false)}>
      <button
        type="button"
        onClick={() => setPinned((p) => !p)}
        className="inline-flex items-center gap-1.5 rounded-full border border-[var(--border)] bg-[var(--bg-card)] px-3 py-1.5 text-sm font-medium text-[var(--text-secondary)] transition-colors hover:bg-[var(--bg-card-hover)]"
        aria-expanded={open}
        title="Transaction growth"
      >
        <LineChart size={15} className="text-[var(--accent)]" /> Growth
      </button>

      {open && (
        <div className="absolute right-0 top-full z-30 mt-2 w-[min(420px,85vw)] rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-lg)]">
          <div className="mb-1 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-[var(--text-primary)]">Transaction Growth</h3>
              <p className="text-xs text-[var(--text-muted)]">This Week</p>
            </div>
            <button onClick={() => { setPinned(false); setHovering(false); }} className="rounded-md p-1 text-[var(--text-muted)] hover:bg-[var(--bg-card-hover)] hover:text-[var(--text-secondary)]" aria-label="Close">
              <X size={15} />
            </button>
          </div>
          <div className="h-44">
            <GrowthChart points={points} />
          </div>
        </div>
      )}
    </div>
  );
}
