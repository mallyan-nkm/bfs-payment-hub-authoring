import type { HourlyVolumeData } from '../types';
import { STATUS_MIX_COLORS } from './StatusMixDonut';

const W = 560;
const H = 200;
const PAD_L = 30;
const PAD_R = 6;
const PAD_T = 8;
const PAD_B = 20;

/** Round a max up to a readable gridline value so the y-axis labels aren't noise. */
function niceMax(value: number): number {
  if (value <= 4) return 4;
  const magnitude = 10 ** Math.floor(Math.log10(value));
  return Math.ceil(value / magnitude) * magnitude;
}

/**
 * 24-hour stacked volume bars (Processed / Pending / Failed) for the Transaction Summary
 * modal — the inline-SVG equivalent of the Angular stacked chart.js bar chart.
 */
export function HourlyVolumeBars({ hours }: { hours: HourlyVolumeData[] }) {
  const rows = hours.length > 0 ? hours : Array.from({ length: 24 }, (_, hour) => ({ hour, processed: 0, pending: 0, failed: 0 }));
  const max = niceMax(Math.max(...rows.map((h) => h.processed + h.pending + h.failed), 0));

  const plotW = W - PAD_L - PAD_R;
  const plotH = H - PAD_T - PAD_B;
  const slot = plotW / rows.length;
  const barW = Math.max(2, slot * 0.62);
  const hOf = (v: number) => (v / max) * plotH;

  const gridlines = [0, 0.25, 0.5, 0.75, 1];

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-[200px] w-full" role="img" aria-label="24-hour transaction volume">
      {gridlines.map((f) => {
        const y = PAD_T + plotH - f * plotH;
        return (
          <g key={f}>
            <line x1={PAD_L} y1={y} x2={W - PAD_R} y2={y} stroke="var(--border)" strokeWidth={1} />
            <text x={PAD_L - 5} y={y + 3} textAnchor="end" fontSize={9} fill="var(--text-muted)">
              {Math.round(max * f).toLocaleString()}
            </text>
          </g>
        );
      })}
      {rows.map((h, i) => {
        const x = PAD_L + i * slot + (slot - barW) / 2;
        // Stack bottom-up: processed, then pending, then failed.
        const processedH = hOf(h.processed);
        const pendingH = hOf(h.pending);
        const failedH = hOf(h.failed);
        const baseY = PAD_T + plotH;
        return (
          <g key={h.hour}>
            <rect x={x} y={baseY - processedH} width={barW} height={processedH} fill={STATUS_MIX_COLORS.processed} />
            <rect x={x} y={baseY - processedH - pendingH} width={barW} height={pendingH} fill={STATUS_MIX_COLORS.pending} />
            <rect x={x} y={baseY - processedH - pendingH - failedH} width={barW} height={failedH} fill={STATUS_MIX_COLORS.failed} />
            {i % 3 === 0 && (
              <text x={x + barW / 2} y={H - 6} textAnchor="middle" fontSize={9} fill="var(--text-muted)">
                {String(h.hour).padStart(2, '0')}
              </text>
            )}
          </g>
        );
      })}
      <line x1={PAD_L} y1={PAD_T + plotH} x2={W - PAD_R} y2={PAD_T + plotH} stroke="var(--border)" strokeWidth={1} />
    </svg>
  );
}
