import type { StatusMixData } from '../types';

/** Segment colours are the Angular chart.js palette, kept identical for continuity. */
export const STATUS_MIX_COLORS = {
  processed: '#22c55e',
  systemProcessing: '#3b82f6',
  pending: '#facc15',
  failed: '#f87171',
} as const;

const R = 85;
const STROKE = 30;
const CIRCUMFERENCE = 2 * Math.PI * R;

/**
 * Status-mix doughnut (70% cutout) for the Transaction Summary modal. Drawn as inline SVG
 * rather than pulling in a charting dependency — this app ships no chart library.
 */
export function StatusMixDonut({ mix }: { mix: StatusMixData }) {
  const segments = [
    { value: mix.processed, color: STATUS_MIX_COLORS.processed },
    { value: mix.systemProcessing, color: STATUS_MIX_COLORS.systemProcessing },
    { value: mix.pending, color: STATUS_MIX_COLORS.pending },
    { value: mix.failed, color: STATUS_MIX_COLORS.failed },
  ].filter((s) => s.value > 0);

  const total = segments.reduce((sum, s) => sum + s.value, 0);
  let offset = 0;

  return (
    <svg viewBox="0 0 200 200" className="size-[200px] max-w-full" role="img" aria-label="Status mix">
      {total === 0 ? (
        <circle cx={100} cy={100} r={R} fill="none" stroke="var(--border)" strokeWidth={STROKE} />
      ) : (
        segments.map((seg, i) => {
          const length = (seg.value / total) * CIRCUMFERENCE;
          const dash = `${length} ${CIRCUMFERENCE - length}`;
          const dashOffset = -offset;
          offset += length;
          return (
            <circle
              key={i}
              cx={100}
              cy={100}
              r={R}
              fill="none"
              stroke={seg.color}
              strokeWidth={STROKE}
              strokeDasharray={dash}
              strokeDashoffset={dashOffset}
              transform="rotate(-90 100 100)"
            />
          );
        })
      )}
    </svg>
  );
}
