import type { PaymentRail } from '@paymenthub/ui';

export interface DashboardKpi {
  totalVolume: number;
  totalVolumeDelta: number;
  successRate: number;
  successRateDelta: number;
  pendingApprovals: number;
  pendingApprovalsDelta: number;
  avgProcessingTimeSeconds: number;
  avgProcessingTimeDelta: number;
}

export interface RailHealth {
  rail: PaymentRail;
  status: 'healthy' | 'degraded' | 'down';
  throughputPerMin: number;
  successRate: number;
  pendingCount: number;
  failedToday: number;
}

/** One side (outward | inbound) of the directional flow-summary endpoint. */
export interface DirectionalFlow {
  totalTransactions: number;
  totalValue: number;
  deltaPct: number;
  inFlightCount: number;
  inFlightValue: number;
  valueProcessed: number;
  processedCount: number;
  exceptionCount: number;
  criticalExceptions: number;
  pendingCount: number;
}

export interface FlowSummary {
  outward: DirectionalFlow;
  inbound: DirectionalFlow;
}

export type SlaStatus = 'Green' | 'Amber' | 'Red';

export interface SlaSparklinePoint {
  hour: number;
  pct: number;
  completed: number;
}

export interface SlaBucket {
  compliancePct: number;
  withinSla: number;
  breachedSla: number;
  totalCompleted: number;
  status: SlaStatus;
  sparkline?: SlaSparklinePoint[];
}

export interface SlaByRail {
  rail: string;
  slaTargetLabel: string;
  outward: SlaBucket;
  inbound: SlaBucket;
}

export interface SlaSummary {
  overall: {
    todayCompliancePct: number;
    lastHourCompliancePct: number;
    targetPct: number;
    breachThresholdPct: number;
    status: SlaStatus;
  };
  outward: { today: SlaBucket; lastHour: SlaBucket };
  inbound: { today: SlaBucket; lastHour: SlaBucket };
  byRail: SlaByRail[];
}

export interface DashboardActivityEvent {
  id: string;
  timestamp: string;
  rail: PaymentRail;
  message: string;
  severity: 'info' | 'warning' | 'critical';
}

export interface DashboardSnapshot {
  kpi: DashboardKpi;
  rails: RailHealth[];
  flow: FlowSummary | null;
  sla: SlaSummary | null;
  recentActivity: DashboardActivityEvent[];
}

// ─────────────────────────────────────────────────────────────────────────────
// Live Operations Dashboard (ports the Angular `ops/dashboard-v2` widgets).
// Each interface mirrors the DTO returned by /api/ops/dashboard/*.
// ─────────────────────────────────────────────────────────────────────────────

/** One side of /ops/dashboard/flow-summary. */
export interface DirectionalFlowMetrics {
  totalTransactions: number;
  totalValue: number;
  deltaPct: number;
  inFlightCount: number;
  inFlightValue: number;
  valueProcessed: number;
  processedCount: number;
  hourlyTrend: number;
  exceptionCount: number;
  criticalExceptions: number;
  /** Subset of exceptionCount first raised within the last hour. */
  newExceptionsLastHour: number;
  pendingCount: number;
}

export interface FlowSummaryResponse {
  outward: DirectionalFlowMetrics;
  inbound: DirectionalFlowMetrics;
}

export interface RailSummaryRow {
  rail: string;
  totalTxns: number;
  success: number;
  failed: number;
  inProgress: number;
  pending: number;
  exceptions: number;
  totalAed: number;
}

export interface TransactionSummaryByRailResponse {
  asOf: string;
  direction: string;
  rails: RailSummaryRow[];
  totals: RailSummaryRow;
  avgProcessingTimeSec: number;
}

export interface StatusMixData {
  total: number;
  processed: number;
  systemProcessing: number;
  pending: number;
  failed: number;
}

export interface HourlyVolumeData {
  hour: number;
  processed: number;
  pending: number;
  failed: number;
}

export interface TransactionSummaryChartsResponse {
  asOf: string;
  rail: string;
  statusMix: StatusMixData;
  hourlyVolume: HourlyVolumeData[];
  avgProcessingTimeSeconds: number;
  totalValue: number;
}

export interface WpsMessageTypeSummary {
  messageType: string;
  msgCount: number;
  sendToCb: number;
  cbPending: number;
  ackReceived: number;
  nakCount: number;
  /** Files carrying an unresolved exception. */
  exceptionCount: number;
  /** Files whose outcome reached the terminal "Rejected" state. */
  rejectedCount: number;
  totalRecordCount: number;
  amountAed: number;
  recSendToCb: number;
  recCbPending: number;
  recAckReceived: number;
  recNakCount: number;
}

export interface WpsMessageSummaryResponse {
  asOf: string;
  messageTypes: WpsMessageTypeSummary[];
}

/**
 * One channel row inside a rail group (`by-channel`). `value` arrives pre-formatted and
 * abbreviated from the backend (e.g. "587.75 K AED"), not as a number.
 */
export interface ChannelRow {
  name: string;
  totalTxns: number;
  inProgress: number;
  pending: number;
  pendingWarn: boolean;
  success: number;
  failed: number;
  exceptions: number;
  exceptionsWarn: boolean;
  value: string;
}

/** `channelBreakdown[]` element. */
export interface RailChannelGroup {
  rail: string;
  description: string;
  colorClass: string;
  channels: ChannelRow[];
}

/** `messageBreakdown[rail][]` element. */
export interface MessageBreakdownRow {
  type: string;
  totalMsg: number;
  totalTxn: number;
  pending: number;
  inProgress: number;
  systemRejected: number;
  sentToCb: number;
  cbAccepted: number;
  cbRejected: number;
  paymentConfirmed: number;
  paymentRejected: number;
  exceptions: number;
  value: string;
}

/** /ops/dashboard/transaction-summary — the six KPI cards on the Total Transactions page. */
export interface TransactionSummaryDto {
  totalTxns: number;
  success: number;
  failed: number;
  inProgress: number;
  pending: number;
  exceptions: number;
  totalAed: number;
  successAed: number;
  failedAed: number;
  inProgressAed: number;
  pendingAed: number;
  exceptionsAed: number;
}

/** One row of /ops/dashboard/tps-transactions — the drill-down table. */
export interface TpsTransactionRow {
  endToEndReference: string;
  senderReferenceNumber: string;
  cbTransactionReference: string;
  /** CB-assigned beneficiary reference (Angular "Beneficiary Ref(CB)" — hidden column by default). */
  beneficiaryRefCB?: string;
  messageType: string;
  channel: string;
  purposeOfPayment?: string;
  status: string;
  currency: string;
  amount: number;
  valueDate: string;
  orderingAccount: string;
  orderingAccountAddress?: string;
  orderingName: string;
  beneficiaryAccount: string;
  beneficiaryAddress?: string;
  beneficiaryName: string;
  remittanceInfo?: string;
  durationSeconds: number;
  createdAt: string;
  /** WPS-only: employer/corporate that submitted the SIF file. */
  corporateName?: string;
  /** WPS-only: original SIF file name as uploaded. */
  fileName?: string;
  /** WPS-only: employee salary records inside this transaction's SIF file. */
  recordCount?: number;
}

export interface TpsTransactionResponse {
  transactions: TpsTransactionRow[];
  totalCount: number;
  recordsLoaded: number;
  pageSize: number;
  pageNumber: number;
  totalPages: number;
  resultsLabel: string;
}

/** Query shape shared by the page's filter bar and the drill-down modal. */
export interface DashboardDateFilter {
  dateType: 'transactionDate' | 'valueDate';
  dateRange: 'today' | 'yesterday' | 'customRange';
  dateFrom: string;
  dateTo: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// In-Flight Transactions drill-down (ports the Angular `ops-in-flight-transactions`
// page). These endpoints are OUTWARD-only server-side — the `direction` query param
// only drives the page's labels, never the request. `dateRange` is required and must
// be one of tillToday | today | yesterday | custom; `from`/`to` are sent only for custom.
// ─────────────────────────────────────────────────────────────────────────────

export type InFlightDateRange = 'tillToday' | 'today' | 'yesterday' | 'custom';

/** Filter state shared by the in-flight filter bar. */
export interface InFlightDateFilter {
  dateRange: InFlightDateRange;
  from: string;
  to: string;
}

/** /ops/dashboard/outward-inflight-summary — the four KPI cards. */
export interface OutwardInFlightSummary {
  asOf: string;
  totalInProgress: number;
  actionPending: number;
  systemProcessing: number;
  exceptions: number;
  processingAmountAed: number;
  dateRange: string;
}

/** Per-rail row (`outward-inflight-by-rail`). `value` is a raw AED number. */
export interface RailInFlightRow {
  rail: string;
  totalInProgress: number;
  systemProcessing: number;
  actionPending: number;
  exceptions: number;
  value: number;
}

export interface OutwardInFlightByRailResponse {
  asOf: string;
  rails: RailInFlightRow[];
  totals: RailInFlightRow;
  dateRange: string;
}

/** Per-channel row inside a rail group (`outward-inflight-by-channel`). */
export interface ChannelInFlightRow {
  channel: string;
  totalInProgress: number;
  systemProcessing: number;
  actionPending: number;
  exceptions: number;
  value: number;
}

export interface RailChannelInFlightGroup {
  rail: string;
  channels: ChannelInFlightRow[];
  railSubtotal: ChannelInFlightRow;
}

export interface OutwardInFlightByChannelResponse {
  asOf: string;
  railGroups: RailChannelInFlightGroup[];
  grandTotal: ChannelInFlightRow;
  dateRange: string;
}

/** Per-message-type row (`outward-inflight-by-message`). */
export interface MessageInFlightRow {
  type: string;
  totalInProgress: number;
  systemProcessing: number;
  actionPending: number;
  exceptions: number;
  value: number;
}

export interface OutwardInFlightByMessageResponse {
  asOf: string;
  rail: string;
  messages: MessageInFlightRow[];
  totals: MessageInFlightRow;
  dateRange: string;
}

export interface RailReconciliationCard {
  rail: string;
  railLabel: string;
  totalTxns: number;
}

export interface PipelineStage {
  label: string;
  sublabel: string;
  count: number;
  percentage: number;
}

export interface PipelineStageWithResponse {
  label: string;
  sublabel: string;
  totalCount: number;
  acceptedCount: number;
  rejectedCount: number;
  acceptedPct: number;
  rejectedPct: number;
  baseCount: number;
}

export interface MessagePipeline {
  railLabel: string;
  railDescription: string;
  initiated: PipelineStage;
  ffts0001: PipelineStage;
  ffts0002: PipelineStageWithResponse;
  ffts0006: PipelineStageWithResponse;
  routedToOtherChannel: PipelineStage;
}

export interface PendingMessageAlerts {
  pendingFfts0002: number;
  pendingFfts0006: number;
  enquiryTimeout: number;
  hasAlerts: boolean;
  alertMessage: string;
}

export interface MessageReconciliationResponse {
  asOf: string;
  direction: string;
  selectedRail: string;
  railSummaries: RailReconciliationCard[];
  pipeline: MessagePipeline;
  pendingAlerts: PendingMessageAlerts;
}
