import { bankingApi } from '../../shared/api/bankingApi';
import { toUtcRangeParams } from '@paymenthub/ui';
import type { PaymentRail } from '@paymenthub/ui';
import type {
  DashboardDateFilter,
  DashboardSnapshot,
  DirectionalFlow,
  FlowSummary,
  FlowSummaryResponse,
  InFlightDateFilter,
  MessageBreakdownRow,
  MessageReconciliationResponse,
  OutwardInFlightByChannelResponse,
  OutwardInFlightByRailResponse,
  OutwardInFlightByMessageResponse,
  OutwardInFlightSummary,
  RailChannelGroup,
  RailHealth,
  RailSummaryRow,
  SlaSummary,
  TpsTransactionResponse,
  TransactionSummaryByRailResponse,
  TransactionSummaryChartsResponse,
  TransactionSummaryDto,
  WpsMessageSummaryResponse,
} from './types';

/**
 * Backend DTOs (Operations API — /api/ops/dashboard/*).
 * The BankOps dashboard aggregates three real endpoints into one snapshot:
 *   - transaction-summary-by-rail  → per-rail health + KPI totals
 *   - flow-summary                 → directional (outward/inbound) flow cards
 *   - sla-summary                  → SLA compliance widget (overall + by-rail)
 */
const RAIL_ALIASES: Record<string, PaymentRail> = {
  IPI: 'IPI',
  IPP: 'IPP',
  WPS: 'WPS',
  SWIFT: 'SWIFT',
  UAEFTS: 'UAEFTS',
  FTS: 'UAEFTS',
};

function normalizeRail(rail: string): PaymentRail | null {
  return RAIL_ALIASES[rail?.toUpperCase()] ?? null;
}

function deriveStatus(row: RailSummaryRow): RailHealth['status'] {
  if (row.totalTxns === 0) return 'healthy';
  const failRate = (row.failed + row.exceptions) / row.totalTxns;
  if (failRate > 0.2) return 'down';
  if (failRate > 0.05) return 'degraded';
  return 'healthy';
}

function toRailHealth(row: RailSummaryRow): RailHealth | null {
  const rail = normalizeRail(row.rail);
  if (!rail) return null;
  return {
    rail,
    status: deriveStatus(row),
    // Per-minute throughput needs time-series data the summary endpoint doesn't
    // expose; surface in-progress count as the closest live proxy for now.
    throughputPerMin: row.inProgress,
    successRate: row.totalTxns > 0 ? (row.success / row.totalTxns) * 100 : 0,
    pendingCount: row.pending,
    failedToday: row.failed,
  };
}

const EMPTY_FLOW: DirectionalFlow = {
  totalTransactions: 0,
  totalValue: 0,
  deltaPct: 0,
  inFlightCount: 0,
  inFlightValue: 0,
  valueProcessed: 0,
  processedCount: 0,
  exceptionCount: 0,
  criticalExceptions: 0,
  pendingCount: 0,
};

function buildSnapshot(
  summary: TransactionSummaryByRailResponse,
  flow: FlowSummary | null,
  sla: SlaSummary | null,
  rail?: string,
): DashboardSnapshot {
  // transaction-summary-by-rail has no server-side rail filter, so when a scheme is
  // selected the KPI totals must come from that rail's row rather than the grand total.
  const railRow = rail
    ? summary.rails.find((r) => r.rail?.toUpperCase() === rail.toUpperCase())
    : undefined;
  const totals = rail ? (railRow ?? { ...summary.totals, totalTxns: 0, success: 0, pending: 0 }) : summary.totals;
  const successRate = totals.totalTxns > 0 ? (totals.success / totals.totalTxns) * 100 : 0;

  return {
    kpi: {
      totalVolume: totals.totalTxns,
      totalVolumeDelta: flow?.outward.deltaPct ?? 0,
      successRate,
      // No historical success-rate delta available from these endpoints yet.
      successRateDelta: 0,
      pendingApprovals: totals.pending,
      pendingApprovalsDelta: 0,
      avgProcessingTimeSeconds: summary.avgProcessingTimeSec,
      avgProcessingTimeDelta: 0,
    },
    rails: summary.rails.map(toRailHealth).filter((r): r is RailHealth => r !== null),
    flow: flow ? { outward: flow.outward ?? EMPTY_FLOW, inbound: flow.inbound ?? EMPTY_FLOW } : null,
    sla,
    // Live activity is delivered via the 'dashboard' realtime channel (SSE); there is
    // no historical recent-activity endpoint, so the seed list is empty.
    recentActivity: [],
  };
}

/** UI rail name → the scheme value the backend stores in `platform.PaymentScheme`. */
const RAIL_TO_SCHEME: Record<string, string> = { UAEFTS: 'FTS' };

export const dashboardApi = {
  getSnapshot: async (scheme?: string) => {
    const rail = scheme ? (RAIL_TO_SCHEME[scheme] ?? scheme) : undefined;

    // No `rail` param here — this endpoint always returns every rail; it is filtered below.
    const summaryReq = bankingApi.get<TransactionSummaryByRailResponse>(
      '/ops/dashboard/transaction-summary-by-rail',
      { params: { direction: 'Outward', dateRange: 'today' } },
    );
    // flow-summary + sla-summary are best-effort enrichers — the dashboard still
    // renders (KPIs + rail cards) if either is unavailable.
    const flowReq = bankingApi
      .get<FlowSummary>('/ops/dashboard/flow-summary', { params: rail ? { rail } : {} })
      .then((r) => r.data)
      .catch(() => null);
    const slaReq = bankingApi
      .get<SlaSummary>('/ops/dashboard/sla-summary', { params: rail ? { rail } : {} })
      .then((r) => r.data)
      .catch(() => null);

    const [summaryRes, flow, sla] = await Promise.all([summaryReq, flowReq, slaReq]);
    return { ...summaryRes, data: buildSnapshot(summaryRes.data, flow, sla, rail) };
  },
};

/**
 * Endpoints backing the Live Operations Dashboard widgets — the same five the Angular
 * `ops-api.service` calls from `ops/dashboard-v2`. Errors are deliberately NOT swallowed
 * here: each widget surfaces its own error/retry state rather than rendering fabricated
 * zeros that look identical to genuinely-zero activity.
 */
export const opsDashboardApi = {
  flowSummary: (rail?: string) =>
    bankingApi
      .get<FlowSummaryResponse>('/ops/dashboard/flow-summary', { params: rail ? { rail } : {} })
      .then((r) => r.data),

  transactionSummaryByRail: (direction: 'outward' | 'inbound') =>
    bankingApi
      .get<TransactionSummaryByRailResponse>('/ops/dashboard/transaction-summary-by-rail', { params: { direction } })
      .then((r) => r.data),

  transactionSummaryCharts: (rail?: string) =>
    bankingApi
      .get<TransactionSummaryChartsResponse>('/ops/dashboard/transaction-summary-charts', {
        params: rail && rail !== 'ALL' ? { rail } : {},
      })
      .then((r) => r.data),

  wpsMessageSummary: () =>
    bankingApi.get<WpsMessageSummaryResponse>('/ops/dashboard/wps-message-summary').then((r) => r.data),

  messageReconciliation: (rail?: string) =>
    bankingApi
      .get<MessageReconciliationResponse>('/ops/dashboard/message-reconciliation', { params: rail ? { rail } : {} })
      .then((r) => r.data),
};

/** Turns the page's date filter into the query params every dashboard endpoint accepts. */
export function dateFilterParams(filter: DashboardDateFilter): Record<string, string> {
  const params: Record<string, string> = {
    dateType: filter.dateType,
    dateRange: filter.dateRange,
  };
  if (filter.dateRange === 'customRange') {
    // Session-zone days as UTC [from, to) (UTC date-time T-22); the named ranges are resolved by the server in
    // the session zone.
    const { from, to } = toUtcRangeParams(filter.dateFrom, filter.dateTo);
    if (from) params.from = from;
    if (to) params.to = to;
  }
  return params;
}

/**
 * Turns the in-flight filter into query params. `dateRange` is always sent (the backend
 * rejects a missing one); `from`/`to` are sent only for a custom range.
 */
/**
 * In-flight date params translated for the **export** endpoint, which spells one value differently.
 *
 * The in-flight routes accept `dateRange=custom` with `from`/`to` — `DashboardEndpoints`
 * validates against `["tilltoday", "today", "yesterday", "custom"]`. The export path does not go
 * through that validator: `BaseExportService` tests `DateRange == "customRange"`, the spelling the
 * *transaction* dashboard uses. Sent unchanged, a custom in-flight range would reach the exporter
 * as an unrecognised value, its `from`/`to` would be ignored, and the caller would get a file for
 * a different period with nothing raised anywhere.
 *
 * Translated here rather than in the page so the two spellings are reconciled in one place. The
 * real fix is one vocabulary across both paths; this is the honest patch until then.
 */
export function inFlightExportParams(filter: InFlightDateFilter): Record<string, string> {
  const params = inFlightParams(filter);
  if (params.dateRange === 'custom') params.dateRange = 'customRange';
  return params;
}

export function inFlightParams(filter: InFlightDateFilter): Record<string, string> {
  const params: Record<string, string> = { dateRange: filter.dateRange };
  if (filter.dateRange === 'custom') {
    const { from, to } = toUtcRangeParams(filter.from, filter.to);
    if (from) params.from = from;
    if (to) params.to = to;
  }
  return params;
}

/**
 * Endpoints behind the In-Flight Transactions drill-down page. All four are OUTWARD-only
 * server-side; the page's `direction` only relabels the UI, so it is never forwarded.
 */
/**
 * The dashboard's server-side CSV extract — `GET /api/ops/dashboard/export`.
 *
 * **Why this replaced two browser-built CSVs.** In-Flight and Total Transactions used to assemble
 * their CSV in the page from rows the grid already held. That made the Export button a control
 * nothing could refuse: `ops:report:export` gates this endpoint, and a CSV built in the browser
 * never touches it, so re-enabling the button in devtools produced the file anyway. A key that
 * only hides something in the browser is not a control.
 *
 * It is also narrower than what the browser could produce. The endpoint sets `ScopedTenantId` and
 * `AllowedRails` from the caller's own token **after** every bound parameter, so an extract cannot
 * be widened past what the caller may read — where the browser version exported whatever had
 * already been fetched into the grid.
 *
 * The body is JSON carrying the CSV as `csv`, not a file download; turning it into a file is the
 * caller's job. Fetched through `bankingApi` rather than `window.open` for the reason
 * {@link totalTransactionsApi.tpsExportCsv} gives: a navigation carries cookies but not the
 * Authorization header, so it would download a 401 body as a .csv.
 */
export const dashboardExportApi = {
  csv: (args: {
    /** `rail`, `channel` or `message` — the grouping the page is showing. */
    viewType: string;
    direction: string;
    /**
     * The date params already built by the caller's own helper.
     *
     * Taken built rather than as a filter object, because the two dashboard filters are not the
     * same shape — `DashboardDateFilter` says `customRange` with `dateFrom`/`dateTo` and carries a
     * `dateType`, while `InFlightDateFilter` says `custom` with `from`/`to` and has none. A union
     * narrowed by a cast would send `dateRange=custom` with no bounds and no `dateType`, which the
     * endpoint reads as a different extract rather than refusing.
     */
    dateParams: Record<string, string>;
    /** Only meaningful for the message view, which is scoped to one rail. */
    rail?: string;
    channel?: string;
    /** `transactions` or `exceptions`. */
    resourceType?: string;
  }) =>
    bankingApi
      .get<{ csv: string }>('/ops/dashboard/export', {
        params: {
          viewType: args.viewType,
          direction: args.direction,
          rail: args.rail,
          channel: args.channel,
          resourceType: args.resourceType ?? 'transactions',
          ...args.dateParams,
        },
      })
      .then((r) => r.data.csv),
};

export const inFlightApi = {
  summary: (filter: InFlightDateFilter) =>
    bankingApi
      .get<OutwardInFlightSummary>('/ops/dashboard/outward-inflight-summary', { params: inFlightParams(filter) })
      .then((r) => r.data),

  byRail: (filter: InFlightDateFilter) =>
    bankingApi
      .get<OutwardInFlightByRailResponse>('/ops/dashboard/outward-inflight-by-rail', { params: inFlightParams(filter) })
      .then((r) => r.data),

  byChannel: (filter: InFlightDateFilter) =>
    bankingApi
      .get<OutwardInFlightByChannelResponse>('/ops/dashboard/outward-inflight-by-channel', { params: inFlightParams(filter) })
      .then((r) => r.data),

  byMessage: (rail: string, filter: InFlightDateFilter) =>
    bankingApi
      .get<OutwardInFlightByMessageResponse>('/ops/dashboard/outward-inflight-by-message', {
        params: { rail, ...inFlightParams(filter) },
      })
      .then((r) => r.data),
};

/** Endpoints behind the Total Transactions page and its drill-down modal. */
export const totalTransactionsApi = {
  /** Lightweight KPI-card query — six figures, no rail breakdown. */
  summary: (direction: string, filter: DashboardDateFilter) =>
    bankingApi
      .get<TransactionSummaryDto>('/ops/dashboard/transaction-summary', {
        params: { direction: direction.toLowerCase(), ...dateFilterParams(filter) },
      })
      .then((r) => r.data),

  byRail: (direction: string, filter: DashboardDateFilter) =>
    bankingApi
      .get<TransactionSummaryByRailResponse>('/ops/dashboard/transaction-summary-by-rail', {
        params: { direction: direction.toLowerCase(), ...dateFilterParams(filter) },
      })
      .then((r) => r.data),

  byChannel: (direction: string, filter: DashboardDateFilter) =>
    bankingApi
      .get<{ channelBreakdown: RailChannelGroup[] }>('/ops/dashboard/by-channel', {
        params: { direction, ...dateFilterParams(filter) },
      })
      .then((r) => r.data?.channelBreakdown ?? []),

  byMessage: (direction: string, filter: DashboardDateFilter) =>
    bankingApi
      .get<{ messageBreakdown: Record<string, MessageBreakdownRow[]> }>('/ops/dashboard/by-message', {
        params: { direction, ...dateFilterParams(filter) },
      })
      .then((r) => r.data?.messageBreakdown ?? {}),

  /** Paginated, server-sorted transaction rows for the drill-down modal. */
  tpsTransactions: (args: {
    direction: string;
    rail: string;
    filter: DashboardDateFilter;
    pageSize: number;
    pageNumber: number;
    sortColumn: string;
    sortDirection: 'ASC' | 'DESC';
  }) =>
    bankingApi
      .get<TpsTransactionResponse>('/ops/dashboard/tps-transactions', {
        params: {
          direction: args.direction,
          rail: args.rail,
          pageSize: args.pageSize,
          pageNumber: args.pageNumber,
          sortColumn: args.sortColumn,
          sortDirection: args.sortDirection,
          ...dateFilterParams(args.filter),
        },
      })
      .then((r) => r.data),

  /**
   * Server-side CSV of the whole filtered set (not just the current page).
   *
   * Fetched through `bankingApi` rather than handed to the browser as a URL. The endpoint now
   * requires an authenticated caller (RBAC phase 1), and a `window.open` navigation carries
   * cookies but NOT the Authorization header — so the previous `tpsExportUrl` approach would
   * download a 401 body as a .csv. Same shape as `activeExceptionsApi.exportCsv`.
   */
  tpsExportCsv: (args: { direction: string; rail: string; filter: DashboardDateFilter; sortColumn: string; sortDirection: string }) =>
    bankingApi
      .get<string>('/ops/dashboard/tps-transactions/export', {
        params: {
          rail: args.rail,
          direction: args.direction,
          sortColumn: args.sortColumn,
          sortDirection: args.sortDirection,
          ...dateFilterParams(args.filter),
        },
        // text, not the default json: axios only skips JSON.parse when responseType is set, so
        // without this a CSV body that happens to parse as JSON would arrive as an object.
        responseType: 'text',
      })
      .then((r) => r.data),
};
