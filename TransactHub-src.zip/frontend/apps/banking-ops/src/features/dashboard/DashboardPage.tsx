import { useCallback, useEffect, useState } from 'react';
import { cn, PageBody, PageHeader, PageShell, useLocalStorage } from '@paymenthub/ui';
import { RefreshControlPanel } from './components/RefreshControlPanel';
import { OutwardPanel } from './OutwardPanel';
import { InboundPanel } from './InboundPanel';
const DEFAULT_INTERVAL_MS = 30_000;
// Must stay in sync with RefreshControlPanel's INTERVAL_OPTIONS values — used only to reject a
// corrupted/out-of-range persisted value, not to change what options are offered.
const VALID_INTERVAL_MS_VALUES = [10_000, 30_000, 60_000, 120_000];
const AUTO_REFRESH_INTERVAL_STORAGE_KEY = 'dashboard.autoRefreshIntervalMs';

/**
 * Live Operations Dashboard — port of the Angular `ops/dashboard-v2`.
 *
 * The page owns the single refresh clock: `refreshTick` is the one source of truth for "a
 * refresh should happen now", and every widget keys off it instead of running its own timer.
 * That is what makes manual refresh, pause, and interval switching actually take effect
 * across all widgets at once.
 */
type TopTab = 'outward' | 'inbound';

const TOP_TABS: Array<{ key: TopTab; label: string; title: string; disabled?: boolean }> = [
  { key: 'outward', label: 'Outward Payments', title: 'Outward Payments' },
  { key: 'inbound', label: 'Inbound Payments', title: 'Inbound Payments', disabled: true },
];

export function DashboardPage() {
  const [tab, setTab] = useState<TopTab>('outward');
  // Persisted across navigation/remounts (see the useLocalStorage hook) — otherwise this page
  // is unmounted whenever the user leaves the /dashboard route, and a fresh instance always
  // re-initializes to the 30s default, silently discarding the user's selection.
  const [storedIntervalMs, setIntervalMs] = useLocalStorage<number>(
    AUTO_REFRESH_INTERVAL_STORAGE_KEY,
    DEFAULT_INTERVAL_MS,
  );
  const intervalMs = VALID_INTERVAL_MS_VALUES.includes(storedIntervalMs)
    ? storedIntervalMs
    : DEFAULT_INTERVAL_MS;
  const [paused, setPaused] = useState(false);
  const [refreshTick, setRefreshTick] = useState(0);
  const [lastRefreshAt, setLastRefreshAt] = useState(() => Date.now());
  // Bumped to restart the countdown from zero (after a manual refresh) without changing the
  // interval itself — a ref would not re-run the effect below.
  const [timerNonce, setTimerNonce] = useState(0);

  const triggerRefresh = useCallback(() => {
    setRefreshTick((t) => t + 1);
    setLastRefreshAt(Date.now());
  }, []);

  // Auto-refresh timer, re-created whenever the interval changes, pause toggles, or a manual
  // refresh happens — so the next auto-tick is always a full interval after the last refresh.
  useEffect(() => {
    if (paused) return undefined;
    const id = window.setInterval(triggerRefresh, intervalMs);
    return () => window.clearInterval(id);
  }, [paused, intervalMs, triggerRefresh, timerNonce]);

  const onManualRefresh = () => {
    triggerRefresh();
    setTimerNonce((n) => n + 1);
  };

  return (
    <PageShell>
      <PageHeader
        title="Live Operations Dashboard"
        subtitle="Real-time cross-rail payment health"
        actions={
          <RefreshControlPanel
            paused={paused}
            lastRefreshAt={lastRefreshAt}
            intervalMs={intervalMs}
            onIntervalChange={setIntervalMs}
            onPauseToggle={setPaused}
            onManualRefresh={onManualRefresh}
          />
        }
      />
      <PageBody className='pt-[12px]'>
        <div className="flex shrink-0 tab-main mb-[24px] pr-2">
          {TOP_TABS.map((t) => {
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                type="button"
                title={t.title}
                disabled={t.disabled}
                onClick={() => setTab(t.key)}
                className={cn(
                  'tab-pills',
                  active
                    ? 'active-tab'
                    : '',
                  t.disabled ? 'opacity-50 cursor-not-allowed' : '',
                )}
              >
                {t.label}
              </button>
            );
          })}
        </div>

        {tab === 'outward' && <OutwardPanel refreshTick={refreshTick} />}
        {tab === 'inbound' && <InboundPanel refreshTick={refreshTick} />}


      </PageBody>
    </PageShell>
  );
}
