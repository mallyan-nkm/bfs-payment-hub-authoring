import { } from 'react';
import { OfflineBanner } from '../../shared/components/OfflineBanner';
import { DirectionalFlowCard } from './components/DirectionalFlowCard';
import { RailWisePaymentSummary } from './components/RailWisePaymentSummary';
import { SlaComplianceWidget } from './components/SlaComplianceWidget';

interface OutwardPanelProps {
  refreshTick: number;
}

export function OutwardPanel({ refreshTick }: OutwardPanelProps) {
  return (
    <div className="mx-auto flex w-full max-w-[1600px] flex-col gap-4 pr-2">
      <OfflineBanner />

      {/* Two directional panels side by side */}
      <div className="gap-3 flex">
        <DirectionalFlowCard direction="outward" refreshTick={refreshTick} />
      </div>

      <RailWisePaymentSummary refreshTick={refreshTick} />
      <SlaComplianceWidget />
    </div>
  );
}