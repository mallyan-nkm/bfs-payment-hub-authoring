import { Fragment, useEffect, useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ChevronDown, ChevronRight, Download, Search, Calendar } from 'lucide-react';
import { Can, LoadingSpinner, PageBody, PageShell, SortIcon, cn, sessionToday, shiftDay, useSessionDateTime } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { useRailAccess } from '../../shared/auth/rails';
import { dashboardExportApi, dateFilterParams, totalTransactionsApi } from './api';
import { resolveUploadDateRange } from '../reports/wps/sifDrillDown';
import type { ChannelRow, DashboardDateFilter, MessageBreakdownRow, RailSummaryRow } from './types';

type ViewMode = 'rail' | 'channel' | 'message';

interface RailRow {
  rail: string;
  totalTxns: number;
  inProgress: number;
  pending: number;
  pendingWarn: boolean;
  success: number;
  failed: number;
  exceptions: number;
  exceptionsWarn: boolean;
  value: string;
  /** Numeric twin of `value`, so the footer can add the rows up instead of asking a second endpoint. */
  valueAed: number;
  [key: string]: string | number | boolean;
}

const RAIL_COLOR: Record<string, string> = {
  IPI: '#7c3aed',
  UAEFTS: '#0891b2',
  FTS: '#0891b2',
  WPS: '#16a34a',
  IPP: '#d97706',
  SWIFT: '#2563eb',
  CBFT: '#0891b2',
  NPSS: '#a855f7',
  EDDA: '#0d9488',
};
const railColor = (rail: string) => RAIL_COLOR[rail?.toUpperCase()] ?? 'var(--primary-blue)';

const MESSAGE_RAILS = ['IPI', 'UAEFTS', 'WPS', 'IPP', 'SWIFT'] as const;
const MESSAGE_RAIL_ALIASES: Record<string, string[]> = {
  IPI: ['IPI'],
  UAEFTS: ['UAEFTS', 'FTS'],
  WPS: ['WPS'],
  IPP: ['IPP'],
  SWIFT: ['SWIFT'],
};

const RAIL_DETAIL_REPORT: Record<string, string> = { WPS: '/reports/wps/sif-detail' };
const RAIL_SUMMARY_REPORT: Record<string, string> = { WPS: '/reports/sif-summary' };
const detailReportFor = (rail: string) => RAIL_DETAIL_REPORT[rail?.toUpperCase()] ?? null;
const summaryReportFor = (rail: string) => RAIL_SUMMARY_REPORT[rail?.toUpperCase()] ?? null;

const CB_ACCEPTED_LABEL: Record<string, string> = { UAEFTS: 'CBUAE', FTS: 'CBUAE', WPS: 'MOHRE', SWIFT: 'NETWORK' };
const cbAcceptedLabel = (rail: string) => CB_ACCEPTED_LABEL[rail?.toUpperCase()] ?? 'CB ACCEPTED';

const num = (n: number | null | undefined) => (n ?? 0).toLocaleString();
const aed = (n: number | null | undefined) => `${(n ?? 0).toLocaleString()} AED`;

const AED_MAGNITUDE: Record<string, number> = { K: 1_000, M: 1_000_000, B: 1_000_000_000 };

function parseAed(value: string | null | undefined): number {
  if (!value) return 0;
  const match = value.match(/([\d,.]+)\s*([KMB])?\s*AED/i);
  if (!match) return 0;
  const parsed = Number.parseFloat(match[1].replace(/,/g, ''));
  if (Number.isNaN(parsed)) return 0;
  return parsed * (AED_MAGNITUDE[match[2]?.toUpperCase() ?? ''] ?? 1);
}

function formatAed(amount: number): string {
  const scales: ReadonlyArray<readonly [string, number]> = [['B', 1_000_000_000], ['M', 1_000_000], ['K', 1_000]];
  for (const [suffix, factor] of scales) {
    if (amount >= factor) return `${(amount / factor).toFixed(2).replace(/\.?0+$/, '')}${suffix} AED`;
  }
  return `${amount.toLocaleString('en-US', { maximumFractionDigits: 2 })} AED`;
}

const sumBy = <T,>(rows: readonly T[], pick: (row: T) => number) => rows.reduce((acc, row) => acc + (pick(row) || 0), 0);

interface ChannelTotals {
  totalTxns: number;
  inProgress: number;
  pending: number;
  success: number;
  failed: number;
  exceptions: number;
  valueAed: number;
}
const EMPTY_CHANNEL_TOTALS: ChannelTotals = { totalTxns: 0, inProgress: 0, pending: 0, success: 0, failed: 0, exceptions: 0, valueAed: 0 };

const sumChannels = (channels: readonly ChannelRow[]): ChannelTotals => ({
  totalTxns: sumBy(channels, (c) => c.totalTxns),
  inProgress: sumBy(channels, (c) => c.inProgress),
  pending: sumBy(channels, (c) => c.pending),
  success: sumBy(channels, (c) => c.success),
  failed: sumBy(channels, (c) => c.failed),
  exceptions: sumBy(channels, (c) => c.exceptions),
  valueAed: sumBy(channels, (c) => parseAed(c.value)),
});

const addChannelTotals = (a: ChannelTotals, b: ChannelTotals): ChannelTotals => ({
  totalTxns: a.totalTxns + b.totalTxns,
  inProgress: a.inProgress + b.inProgress,
  pending: a.pending + b.pending,
  success: a.success + b.success,
  failed: a.failed + b.failed,
  exceptions: a.exceptions + b.exceptions,
  valueAed: a.valueAed + b.valueAed,
});

const messageTotalRow = (rows: readonly MessageBreakdownRow[]): MessageBreakdownRow => ({
  type: 'TOTAL',
  totalMsg: sumBy(rows, (r) => r.totalMsg),
  totalTxn: sumBy(rows, (r) => r.totalTxn),
  pending: sumBy(rows, (r) => r.pending),
  inProgress: sumBy(rows, (r) => r.inProgress),
  systemRejected: sumBy(rows, (r) => r.systemRejected),
  sentToCb: sumBy(rows, (r) => r.sentToCb),
  cbAccepted: sumBy(rows, (r) => r.cbAccepted),
  cbRejected: sumBy(rows, (r) => r.cbRejected),
  paymentConfirmed: sumBy(rows, (r) => r.paymentConfirmed),
  paymentRejected: sumBy(rows, (r) => r.paymentRejected),
  exceptions: sumBy(rows, (r) => r.exceptions),
  value: formatAed(sumBy(rows, (r) => parseAed(r.value))),
});

const DATE_TYPE_LABEL: Record<string, string> = { transactionDate: 'Transaction Date', valueDate: 'Value Date' };
const MAX_CUSTOM_RANGE_DAYS = 7;
const earlierOf = (a: string, b: string) => (a < b ? a : b);

const TODAY_FILTER: DashboardDateFilter = { dateType: 'transactionDate', dateRange: 'today', dateFrom: '', dateTo: '' };

const TH = 'tracking-wide whitespace-nowrap';
const TH_NUM = 'tracking-wide whitespace-nowrap';
const TD = 'whitespace-nowrap';
const TD_NUM = 'tabular-nums whitespace-nowrap';
const CLICK_NUM = 'cursor-pointer font-bold text-[var(--primary-blue)] hover:underline decoration-dotted underline-offset-2';

export function TotalTransactionsPage() {
  const navigate = useNavigate();
  const { formatInstant } = useSessionDateTime();
  const { allows: allowsRail, allowed: heldRails } = useRailAccess();
  /** Stable dependency for the memos below — `allows` is a fresh closure on every render. */
  const heldRailKey = heldRails.join(',');
  const [params] = useSearchParams();
  const direction: 'outward' | 'inbound' = params.get('direction') === 'inbound' ? 'inbound' : 'outward';
  const dirLabel = direction === 'outward' ? 'Outward' : 'Inbound';
  const apiDirection = dirLabel;

  const [view, setView] = useState<ViewMode>('rail');

  const [draft, setDraft] = useState<DashboardDateFilter>(TODAY_FILTER);
  const [applied, setApplied] = useState<DashboardDateFilter>(TODAY_FILTER);

  const [railSortColumn, setRailSortColumn] = useState<keyof RailRow>('totalTxns');
  const [railSortDirection, setRailSortDirection] = useState<'asc' | 'desc'>('desc');
  const [collapsedRails, setCollapsedRails] = useState<Record<string, boolean>>({});
  const [pickedMessageRail, setPickedMessageRail] = useState<string>('IPI');

  const summaryQ = useQuery({
    queryKey: ['tt-summary', apiDirection, applied],
    queryFn: () => totalTransactionsApi.summary(apiDirection, applied),
  });
  const railQ = useQuery({
    queryKey: ['tt-by-rail', apiDirection, applied],
    queryFn: () => totalTransactionsApi.byRail(apiDirection, applied),
  });
  const channelQ = useQuery({
    queryKey: ['tt-by-channel', apiDirection, applied],
    enabled: view === 'channel',
    queryFn: () => totalTransactionsApi.byChannel(apiDirection, applied),
  });
  const messageQ = useQuery({
    queryKey: ['tt-by-message', apiDirection, applied],
    enabled: view === 'message',
    queryFn: () => totalTransactionsApi.byMessage(apiDirection, applied),
  });

  const summary = summaryQ.data;

  // ── Rail access ────────────────────────────────────────────────────────────
  // The server already confines every query on this page to the rails the session holds, so the
  // filtering below is presentation: it stops the page drawing a chip, a row or a tab whose data
  // will never arrive. Without it a denied rail reads as "no traffic today" rather than "not
  // yours", which is the misreading the whole gate exists to prevent.
  const messageRails = MESSAGE_RAILS.filter(allowsRail);
  const messageRailKey = messageRails.join(',');

  // The picked rail cannot stay on a literal 'IPI'. That default is wrong for anyone not entitled
  // to IPI, and now that the endpoint refuses a rail the caller does not hold it would earn a 403
  // the moment the tab opens. Corrected in an effect rather than in the initialiser because the
  // permission snapshot resolves after first paint — every key reads as denied until it lands.
  useEffect(() => {
    if (messageRails.length > 0 && !(messageRails as readonly string[]).includes(pickedMessageRail)) {
      setPickedMessageRail(messageRails[0]);
    }
    // messageRailKey stands in for the array, which is rebuilt on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messageRailKey, pickedMessageRail]);

  // If the snapshot resolves while By Message is open and the session holds none of its rails,
  // fall back to a view that still has something to show rather than an empty selector.
  useEffect(() => {
    if (view === 'message' && messageRails.length === 0) setView('rail');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messageRailKey, view]);

  // ── By Rail ────────────────────────────────────────────────────────────────
  const railRows: RailRow[] = useMemo(() => {
    const rows: RailRow[] = (railQ.data?.rails ?? []).filter((r: RailSummaryRow) => allowsRail(r.rail)).map((r: RailSummaryRow) => ({
      rail: r.rail,
      totalTxns: r.totalTxns,
      inProgress: r.inProgress,
      pending: r.pending,
      pendingWarn: r.pending > 100,
      success: r.success,
      failed: r.failed,
      exceptions: r.exceptions,
      exceptionsWarn: r.exceptions > 10,
      value: r.totalAed.toLocaleString(),
      valueAed: r.totalAed,
    }));
    return [...rows].sort((a, b) => {
      const av = a[railSortColumn];
      const bv = b[railSortColumn];
      if (typeof av === 'number' && typeof bv === 'number') return railSortDirection === 'asc' ? av - bv : bv - av;
      const cmp = String(av ?? '').localeCompare(String(bv ?? ''));
      return railSortDirection === 'asc' ? cmp : -cmp;
    });
  }, [railQ.data, railSortColumn, railSortDirection, heldRailKey]);

  // The footer is the sum of the rows above it. It used to come from /transaction-summary, which counts every status
  // and every rail (the rows are settled value and only the rails this session may see), so the Total row did not
  // equal the column it sat under.
  const totalTxns = sumBy(railRows, (r) => r.totalTxns);
  const totalInProgress = sumBy(railRows, (r) => r.inProgress);
  const totalPending = sumBy(railRows, (r) => r.pending);
  const totalSuccess = sumBy(railRows, (r) => r.success);
  const totalFailed = sumBy(railRows, (r) => r.failed);
  const totalExceptions = sumBy(railRows, (r) => r.exceptions);
  const totalValueAed = sumBy(railRows, (r) => r.valueAed);

  const sortRailBy = (column: keyof RailRow) => {
    if (railSortColumn === column) setRailSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
    else {
      setRailSortColumn(column);
      setRailSortDirection('desc');
    }
  };
  const railSortDirectionFor = (column: keyof RailRow) => (railSortColumn === column ? railSortDirection : null);

  // ── By Channel ─────────────────────────────────────────────────────────────
  const channelGroups = useMemo(() => (channelQ.data ?? []).filter((g) => allowsRail(g.rail)), [channelQ.data, heldRailKey]);
  const channelSubtotals = useMemo(() => channelGroups.map((g) => sumChannels(g.channels ?? [])), [channelGroups]);
  const channelGrandTotal = useMemo(() => channelSubtotals.reduce(addChannelTotals, EMPTY_CHANNEL_TOTALS), [channelSubtotals]);

  const messageRows = useMemo(() => {
    const dict = messageQ.data ?? {};
    const key = (MESSAGE_RAIL_ALIASES[pickedMessageRail] ?? [pickedMessageRail]).find((k) => dict[k]?.length);
    const rows = key ? dict[key] : [];
    return rows.length > 0 ? [...rows, messageTotalRow(rows)] : [];
  }, [messageQ.data, pickedMessageRail]);

  /**
   * Whether a count may link to a report: the rail has one AND the applied filter is something the
   * report can honour. The SIF reports filter on upload date only and have no value-date predicate,
   * so under a Value Date filter a link would open the unfiltered report and imply the filter had
   * been kept. The count stays plain text instead, as it does for a rail with no report.
   */
  const canOpenReport = (path: string | null): path is string =>
    path !== null && applied.dateType === 'transactionDate';

  const openReport = (path: string, rail: string) => {
    // The report routes carry their own guards and their endpoints refuse a rail the caller does
    // not hold, so navigating a denied rail would land on /unauthorized where a row simply should
    // not have been clickable. The rows this is reached from are filtered above; this is the
    // backstop for the ones reached from a rail label or the message tab.
    if (!allowsRail(rail) || !canOpenReport(path)) return;

    // Hand the applied (searched) filter over as the report's own upload-date window. The report
    // resolves nothing itself: relative ranges become concrete local days here, so the destination
    // can seed its first request straight from the URL.
    //
    // Known limits, both deliberate: only the DATE is carried. A By Channel count therefore opens
    // the report for every channel in the window, not the clicked one (the SIF endpoints have no
    // channel filter). And By Rail / By Channel counts are files while SIF Detail lists employee
    // records, so those two counts will not reconcile row-for-row with the report they open.
    const range = resolveUploadDateRange(applied);
    if (!range) return;
    navigate(`${path}?${new URLSearchParams(range).toString()}`);
  };

  const openDetailReport = (rail: string) => {
    const path = detailReportFor(rail);
    if (path) openReport(path, rail);
  };
  const openSummaryReport = (rail: string) => {
    const path = summaryReportFor(rail);
    if (path) openReport(path, rail);
  };

  const onRangeChange = (dateRange: DashboardDateFilter['dateRange']) => {
    setDraft((d) => {
      if (dateRange !== 'customRange') return { ...d, dateRange };
      // "Today" is the session zone's date, not the UTC one (UTC date-time T-22, AC-UT-K01).
      const today = sessionToday();
      return { ...d, dateRange, dateTo: today, dateFrom: shiftDay(today, -(MAX_CUSTOM_RANGE_DAYS - 1)) };
    });
  };

  const [rangeError, setRangeError] = useState<string | null>(null);

  const doSearch = () => {
    if (draft.dateRange === 'customRange') {
      const today = sessionToday();
      if (!draft.dateFrom || !draft.dateTo) return setRangeError('Select both a From and a To date.');
      if (draft.dateFrom > today || draft.dateTo > today) return setRangeError('Dates cannot be in the future.');
      if (draft.dateFrom > draft.dateTo) return setRangeError('From date must be on or before the To date.');
      const spanDays = (Date.parse(draft.dateTo) - Date.parse(draft.dateFrom)) / 86_400_000;
      if (spanDays > MAX_CUSTOM_RANGE_DAYS) return setRangeError(`Range cannot exceed ${MAX_CUSTOM_RANGE_DAYS} days.`);
    }
    setRangeError(null);
    setApplied(draft);
  };

  const dateRangeLabel =
    applied.dateRange === 'customRange'
      ? `${applied.dateFrom} to ${applied.dateTo}`
      : applied.dateRange === 'yesterday'
        ? 'Yesterday'
        : 'Today';

  const todayLabel = formatInstant(Date.now(), 'date');

  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  /**
   * The rows come from the server; only the report preamble is still built here.
   *
   * This function used to assemble the whole CSV from `railRows` / `channelGroups` / `messageRows`,
   * which made Export a button nothing could refuse — `ops:report:export` gates
   * `/api/ops/dashboard/export`, and a CSV built in the browser never reaches it. The server
   * extract is also correctly scoped: it applies the caller's own tenant and rail filters after
   * every bound parameter, where this built from whatever had already been fetched.
   *
   * **The preamble stays client-side, and the subtotal rows are gone.** The four header lines
   * describe the request rather than the data, so the page is the right place for them. The
   * per-rail SUBTOTAL and grand-total rows are not in the server extract; they were presentation
   * computed over one page of results, and a subtotal that only sums the rows the browser happened
   * to hold is worse than no subtotal in a file someone reconciles against.
   */
  const exportCsv = async () => {
    setExporting(true);
    setExportError(null);
    try {
      const csv = await dashboardExportApi.csv({
        viewType: view,
        direction,
        dateParams: dateFilterParams(applied),
        rail: view === 'message' ? pickedMessageRail : undefined,
      });

      const meta = [
        `Transaction Export Report — By ${view === 'rail' ? 'Rail' : view === 'channel' ? 'Channel' : 'Message'}`,
        `Generated: ${new Date().toISOString()}`,
        `Filter: ${DATE_TYPE_LABEL[applied.dateType]} = ${dateRangeLabel}`,
        `Direction: ${dirLabel}`,
        '',
      ];

      const blob = new Blob([[...meta, csv].join('\n')], { type: 'text/csv' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `TransactionExport_By${view}_${sessionToday()}_${applied.dateRange}.csv`;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (err) {
      setExportError(
        (err as { response?: { status?: number } })?.response?.status === 403
          ? 'You do not hold the export permission (ops:report:export) for this extract.'
          : 'The export could not be generated. Nothing was downloaded.',
      );
    } finally {
      setExporting(false);
    }
  };

  const kpis = [
    { label: `Total ${dirLabel}`, value: summary?.totalTxns ?? 0, sub: aed(summary?.totalAed), tail: 'Transactions', color: 'var(--primary-blue)' },
    { label: 'Pending', value: summary?.pending ?? 0, sub: null, tail: 'Awaiting processing', color: '#d97706' },
    { label: 'System Processing', value: summary?.inProgress ?? 0, sub: aed(summary?.inProgressAed), tail: 'Being processed', color: '#2563eb' },
    { label: 'Success', value: summary?.success ?? 0, sub: aed(summary?.successAed), tail: 'Settled', color: '#16a34a' },
    { label: 'Failed', value: summary?.failed ?? 0, sub: aed(summary?.failedAed), tail: 'Rejected / Error', color: '#dc2626' },
    { label: 'Exceptions', value: totalExceptions, sub: aed(summary?.exceptionsAed), tail: 'Flagged for review', color: '#ea580c' },
  ];

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / '}
              <span className="text-[var(--text-secondary)]">{dirLabel} Total Transactions</span>
            </p>
          </div>

          {/* Title Header */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                {dirLabel} Total Transactions — All Rails
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Consolidated real-time transaction processing view across rails and channels
              </p>
            </div>
          </div>

          {/* KPI Metric Cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {kpis.map((k) => (
              <div
                key={k.label}
                className="trand-card rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]"
                style={{ borderTop: `3px solid ${k.color}` }}
              >
                <p className="input-label tracking-wider">
                  {k.label}
                </p>
                <p className="mt-1 text-2xl sm:text-3xl font-bold leading-none tabular-nums" style={{ color: k.color }}>
                  {summaryQ.isLoading ? '—' : num(k.value)}
                </p>
                <p className="mt-2 truncate text-[11px] text-[var(--text-muted)]">
                  {k.sub && <strong className="text-[var(--text-secondary)]">{k.sub}</strong>}
                  {k.sub ? ' · ' : ''}
                  {k.tail}
                </p>
              </div>
            ))}
          </div>

          {/* Filter Bar Card */}
          <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]">
            <p className="input-label mb-2 text-[11px] font-bold tracking-wider text-[var(--text-muted)]">
              {dirLabel} transactions created filter
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative h-full">
                <select
                  aria-label="Date type"
                  value={draft.dateType}
                  onChange={(e) => setDraft((d) => ({ ...d, dateType: e.target.value as DashboardDateFilter['dateType'] }))}
                  className="input-cls h-32px min-w-[220px] appearance-none pr-7 "
                >
                  <option value="transactionDate">Transaction Date</option>
                  <option value="valueDate">Value Date</option>
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-2.5 size-3 text-[var(--text-muted)]" />
              </div>

              <div className="relative h-full">
                <select
                  aria-label="Date range"
                  value={draft.dateRange}
                  onChange={(e) => onRangeChange(e.target.value as DashboardDateFilter['dateRange'])}
                  className="input-cls h-32px appearance-none pr-7  "
                >
                  <option value="today">Today</option>
                  <option value="yesterday">Yesterday</option>
                  <option value="customRange">Custom Range</option>
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-2.5 size-3 text-[var(--text-muted)]" />
              </div>

              <button
                type="button"
                onClick={doSearch}
                className="btn-primary !py-1.5 !px-3.5 text-xs inline-flex items-center gap-1"
              >
                <Search size={13} />
                Search
              </button>

              {/* GET /api/ops/dashboard/export enforces ops:report:export; the button mirrors it. */}
              <Can permission={PERM.opsReportExport}>
                <button
                  type="button"
                  onClick={exportCsv}
                  disabled={exporting}
                  className="btn-secondary !py-1.5 !px-3 text-xs inline-flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Download size={13} />
                  {exporting ? 'Exporting…' : 'Export CSV'}
                </button>
              </Can>
            </div>

            {exportError && (
              <p className="mt-2 w-full text-xs text-[var(--accent-red)]" role="alert">
                {exportError}
              </p>
            )}

            {draft.dateRange === 'customRange' && (
              <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-[var(--border)] pt-3">
                <div className='w-[125px]'>
                <label htmlFor="tt-from" className="input-label">
                  From:
                </label>
                <input
                  id="tt-from"
                  type="date"
                  min={draft.dateTo ? shiftDay(draft.dateTo, -MAX_CUSTOM_RANGE_DAYS) : undefined}
                  max={draft.dateTo || sessionToday()}
                  value={draft.dateFrom}
                  onChange={(e) => setDraft((d) => ({ ...d, dateFrom: e.target.value }))}
                  className="input-cls h-7 text-xs"
                />
                </div>
                <div className='w-[125px]'>
                <label htmlFor="tt-to" className=" input-label">
                  To:
                </label>
                <input
                  id="tt-to"
                  type="date"
                  min={draft.dateFrom || undefined}
                  max={
                    draft.dateFrom
                      ? earlierOf(sessionToday(), shiftDay(draft.dateFrom, MAX_CUSTOM_RANGE_DAYS))
                      : sessionToday()
                  }
                  value={draft.dateTo}
                  onChange={(e) => setDraft((d) => ({ ...d, dateTo: e.target.value }))}
                  className="input-cls h-7 text-xs"
                />
                </div>
              </div>
            )}

            {rangeError && (
              <p
                role="alert"
                aria-live="assertive"
                className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700"
              >
                {rangeError}
              </p>
            )}
            <p className="mt-2 text-[11px] text-[var(--text-muted)]">
              ℹ Counts reflect transactions created in the selected period only — historical carryover excluded.
            </p>
          </div>

          <div className="overflow-x-auto rounded-lg border border-[var(--border)] table-holder">
          {/* View Selection Mode Pills */}

          <div className="flex flex-wrap items-center justify-between gap-3 border border-[var(--border)] px-[12px] py-[8px]"> 
            <div className="flex flex-wrap items-center justify-between gap-3 w-full">
            <div className="flex items-center gap-2">
              {(
                [
                  { key: 'rail' as ViewMode, label: 'By Rail', loading: railQ.isLoading, shown: true },
                  { key: 'channel' as ViewMode, label: 'By Channel', loading: view === 'channel' && channelQ.isLoading, shown: true },
                  // By Rail and By Channel stay: they are cross-rail views that simply show fewer
                  // rows. By Message is different — its whole content is one rail picked from the
                  // chip row, so with no chip to pick it is an empty selector over an empty table.
                  { key: 'message' as ViewMode, label: 'By Message', loading: view === 'message' && messageQ.isLoading, shown: messageRails.length > 0 },
                ] as const
              ).filter((t) => t.shown).map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setView(t.key)}
                  className={cn(
                    'common-pill',
                    view === t.key
                      ? 'active-pill'
                      : '',
                  )}
                >
                  {t.label} {t.loading ? '⟳' : ''}
                </button>
              ))}
            </div>

            <span className="text-xs text-[var(--text-muted)] font-medium flex gap-1 ml-auto">
              <Calendar size={14} />
              {DATE_TYPE_LABEL[applied.dateType]}: <strong className="text-[var(--text-secondary)]">{dateRangeLabel}</strong>
            </span>
          </div>
          </div>
          {/* ═══ By Rail Table ═══ */}
          {view === 'rail' && (
            <div >

              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px]">
                <h4 className="mb-2">Transactions By Rail</h4>
                <span className="text-xs text-[var(--text-muted)]">({railRows.length} rails)</span>
              </div>
              {railQ.isLoading ? (
                <div className="flex h-40 items-center justify-center">
                  <LoadingSpinner />
                </div>
              ) : (
                <div className="overflow-x-auto ">
                  <table >
                    <thead>
                      <tr >
                        <th >Rail</th>
                        {([
                          ['totalTxns', 'Total Transactions'],
                          ['inProgress', 'System Processing'],
                          ['pending', 'Pending'],
                          ['success', 'Success'],
                          ['failed', 'Failed'],
                          ['exceptions', 'Exceptions'],
                          ['value', 'Value (AED)'],
                        ] as Array<[keyof RailRow, string]>).map(([key, label]) => (
                          <th key={String(key)} className={TH_NUM}>
                            <button
                              type="button"
                              onClick={() => sortRailBy(key)}
                              className="inline-flex items-center gap-1 "
                            >
                              <span>{label}</span>
                              <SortIcon direction={railSortDirectionFor(key)} />
                            </button>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border)]">
                      {railRows.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="p-[12px]">
                            No transactions for the selected period.
                          </td>
                        </tr>
                      ) : (
                        railRows.map((row) => (
                          <tr
                            key={row.rail}
                            className={cn(
                              '',
                              row.pending > 500 && 'bg-amber-50/40',
                            )}
                          >
                            <td >
                              <span
                                className="common-badge text-[10px] font-bold uppercase text-white"
                                style={{ background: railColor(row.rail) }}
                              >
                                {row.rail}
                              </span>
                            </td>
                            <td className={TD_NUM}>
                              {canOpenReport(detailReportFor(row.rail)) ? (
                                <button
                                  type="button"
                                  className={CLICK_NUM}
                                  onClick={() => openDetailReport(row.rail)}
                                >
                                  {num(row.totalTxns)}
                                </button>
                              ) : (
                                <span className="font-semibold text-[var(--text-primary)]">{num(row.totalTxns)}</span>
                              )}
                            </td>
                            <td className={cn(TD_NUM, 'text-blue-700 font-semibold')}>{num(row.inProgress)}</td>
                            <td
                              className={cn(
                                TD_NUM,
                                (row.pendingWarn || row.pending > 500) && 'font-bold text-amber-700',
                              )}
                            >
                              {num(row.pending)}
                              {row.pendingWarn || row.pending > 500 ? ' ⚠' : ''}
                            </td>
                            <td className={cn(TD_NUM, 'font-semibold text-green-700')}>{num(row.success)}</td>
                            <td className={cn(TD_NUM, 'font-semibold text-red-700')}>{num(row.failed)}</td>
                            <td className={TD_NUM}>
                              <button
                                type="button"
                                onClick={() => navigate(`/exceptions?rail=${encodeURIComponent(row.rail)}`)}
                                className={cn(
                                  'hover:underline',
                                  row.exceptionsWarn
                                    ? 'font-bold text-amber-700'
                                    : 'font-semibold text-[var(--primary-blue)]',
                                )}
                              >
                                {num(row.exceptions)}
                                {row.exceptionsWarn ? ' ⚠' : ''}
                              </button>
                            </td>
                            <td className={cn(TD_NUM, 'font-mono')}>{row.value}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                    <tfoot>
                      <tr >
                        <td className="px-3 py-3 text-xs font-black uppercase text-[var(--text-primary)]">Total</td>
                        <td className={cn(TD_NUM, 'font-bold text-[var(--text-primary)]')}>{num(totalTxns)}</td>
                        <td className={cn(TD_NUM, 'text-blue-700')}>{num(totalInProgress)}</td>
                        <td className={cn(TD_NUM, 'text-amber-700')}>{num(totalPending)}</td>
                        <td className={cn(TD_NUM, 'text-green-700')}>{num(totalSuccess)}</td>
                        <td className={cn(TD_NUM, 'text-red-700')}>{num(totalFailed)}</td>
                        <td className={cn(TD_NUM, 'text-amber-700')}>{num(totalExceptions)}</td>
                        <td className={cn(TD_NUM, 'font-mono text-[var(--text-primary)]')}>{aed(totalValueAed)}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          )}
          </div>

          {/* ═══ By Channel Table ═══ */}
          {view === 'channel' && (
            <div className="overflow-hidden rounded-xl border border-[var(--border)] table-holder">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px]">
                <h4 className="mb-2">Transactions By Channel</h4>
                <span className="text-xs text-[var(--text-muted)]">({channelGroups.length} schemes)</span>
              </div>

              {channelQ.isLoading ? (
                <div className="flex h-40 items-center justify-center">
                  <LoadingSpinner />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table >
                    <thead>
                      <tr >
                        <th >Rail</th>
                        <th>Channel</th>
                        {['Total Transactions', 'System Processing', 'Pending', 'Success', 'Failed', 'Exceptions', 'Value (AED)'].map(
                          (c) => (
                            <th key={c} className={TH_NUM}>
                              {c}
                            </th>
                          ),
                        )}
                      </tr>
                    </thead>
                    <tbody >
                      {channelGroups.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="px-4 py-10 text-center text-xs text-[var(--text-muted)]">
                            No channel breakdown for the selected period.
                          </td>
                        </tr>
                      ) : (
                        <>
                          {channelGroups.map((group, i) => {
                            const subtotal = channelSubtotals[i];
                            const collapsed = collapsedRails[group.rail] ?? false;
                            return (
                              <Fragment key={group.rail}>
                                <tr
                                  onClick={() => setCollapsedRails((p) => ({ ...p, [group.rail]: !p[group.rail] }))}
                                  className=""
                                >
                                  <td
                                    colSpan={9}
                                    className="tracking-wider"
                                    style={{ color: railColor(group.rail) }}
                                  >
                                    <span className="inline-flex items-center gap-1.5">
                                      {collapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                                      {group.rail} — {group.description}
                                    </span>
                                  </td>
                                </tr>
                                {!collapsed &&
                                  (group.channels ?? []).map((ch) => (
                                    <tr
                                      key={`${group.rail}-${ch.name}`}
                                      className=""
                                    >
                                      <td >
                                        <span
                                          className="inline-flex common-badge text-white shadow-2xs"
                                          style={{ background: railColor(group.rail) }}
                                        >
                                          {group.rail}
                                        </span>
                                      </td>
                                      <td >{ch.name}</td>
                                      <td className={TD_NUM}>
                                        {canOpenReport(detailReportFor(group.rail)) ? (
                                          <button
                                            type="button"
                                            className={CLICK_NUM}
                                            onClick={() => openDetailReport(group.rail)}
                                          >
                                            {num(ch.totalTxns)}
                                          </button>
                                        ) : (
                                          <span className="font-semibold text-[var(--text-primary)]">{num(ch.totalTxns)}</span>
                                        )}
                                      </td>
                                      <td className={cn(TD_NUM, 'text-blue-700')}>{num(ch.inProgress)}</td>
                                      <td
                                        className={cn(
                                          TD_NUM,
                                          ch.pendingWarn && 'font-bold text-amber-700',
                                        )}
                                      >
                                        {num(ch.pending)}
                                        {ch.pendingWarn ? ' ⚠' : ''}
                                      </td>
                                      <td className={cn(TD_NUM, 'font-semibold text-green-700')}>{num(ch.success)}</td>
                                      <td className={cn(TD_NUM, 'font-semibold text-red-700')}>{num(ch.failed)}</td>
                                      <td
                                        className={cn(
                                          TD_NUM,
                                          ch.exceptionsWarn && 'font-bold text-amber-700',
                                        )}
                                      >
                                        {num(ch.exceptions)}
                                        {ch.exceptionsWarn ? ' ⚠' : ''}
                                      </td>
                                      <td className={cn(TD_NUM, 'font-mono')}>{ch.value}</td>
                                    </tr>
                                  ))}
                                <tr className="bg-[var(--bg-secondary)]/30 font-semibold text-[var(--text-primary)]">
                                  <td colSpan={2} className="px-3 py-2 text-xs font-bold uppercase text-[var(--text-muted)]">
                                    {group.rail} Sub-Total
                                  </td>
                                  <td className={cn(TD_NUM, 'font-bold text-[var(--text-primary)]')}>{num(subtotal.totalTxns)}</td>
                                  <td className={cn(TD_NUM, 'text-blue-700')}>{num(subtotal.inProgress)}</td>
                                  <td className={cn(TD_NUM, 'text-amber-700')}>{num(subtotal.pending)}</td>
                                  <td className={cn(TD_NUM, 'text-green-700')}>{num(subtotal.success)}</td>
                                  <td className={cn(TD_NUM, 'text-red-700')}>{num(subtotal.failed)}</td>
                                  <td className={cn(TD_NUM, 'text-amber-700')}>{num(subtotal.exceptions)}</td>
                                  <td className={cn(TD_NUM, 'font-mono')}>{formatAed(subtotal.valueAed)}</td>
                                </tr>
                              </Fragment>
                            );
                          })}
                          <tr className="border-t-2 border-[var(--border)] bg-[var(--bg-secondary)]/60 font-bold text-[var(--text-primary)]">
                            <td colSpan={2} className="px-3 py-3 text-xs font-black uppercase text-[var(--text-primary)]">
                              Grand Total — All Rails
                            </td>
                            <td className={cn(TD_NUM, 'font-bold text-[var(--text-primary)]')}>{num(channelGrandTotal.totalTxns)}</td>
                            <td className={cn(TD_NUM, 'text-blue-700')}>{num(channelGrandTotal.inProgress)}</td>
                            <td className={cn(TD_NUM, 'text-amber-700')}>{num(channelGrandTotal.pending)}</td>
                            <td className={cn(TD_NUM, 'text-green-700')}>{num(channelGrandTotal.success)}</td>
                            <td className={cn(TD_NUM, 'text-red-700')}>{num(channelGrandTotal.failed)}</td>
                            <td className={cn(TD_NUM, 'text-amber-700')}>{num(channelGrandTotal.exceptions)}</td>
                            <td className={cn(TD_NUM, 'font-mono text-[var(--text-primary)]')}>{formatAed(channelGrandTotal.valueAed)}</td>
                          </tr>
                        </>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ═══ By Message Table ═══ */}
          {view === 'message' && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2.5 rounded-xl border border-[var(--border)] bg-[#eff6ff] px-4 py-3 text-xs text-[#1e40af]">
                <span className="font-bold">ℹ</span>
                <span>
                  Transaction Processing Status — full message lifecycle by rail. Select a rail below to view processing stages, counts, and outcomes for today.
                </span>
              </div>
              <div className="overflow-hidden rounded-xl border border-[var(--border)] table-holder">
                {/* Message Rail Filter Pills */}
                <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] px-[12px] py-[12px]">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                    Select rail:
                  </span>
                  {messageRails.map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setPickedMessageRail(r)}
                      className={cn(
                        'inline-flex items-center gap-1.5 common-pill',
                        pickedMessageRail === r
                          ? 'active-pill'
                          : '',
                      )}
                    >
                      <span className="rail-dot" style={{ background: railColor(r) }} />
                      {r}
                    </button>
                  ))}
                </div>

                <div>
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px]">
                    <div className='flex mb-2 items-center'>
                      <h4>
                        {dirLabel} — {pickedMessageRail}
                      </h4>
                      <span className="ml-2 text-xs text-[var(--text-muted)]">
                        Summary of messages for today ({todayLabel})
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setView('rail')}
                      className="btn-secondary !py-1 !px-2.5 text-xs"
                    >
                      ← Back to Rail View
                    </button>
                  </div>

                  {messageQ.isLoading ? (
                    <div className="flex h-40 items-center justify-center">
                      <LoadingSpinner />
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table >
                        <thead>
                          <tr >
                            <th className={TH}>Type</th>
                            {[
                              ['Total Msg', ''],
                              ['Total Txn', ''],
                              ['Pending', 'text-amber-700'],
                              ['System Processing', 'text-blue-700'],
                              ['System Rejected', 'text-red-700'],
                              ['Sent to CB', 'text-blue-700'],
                              [cbAcceptedLabel(pickedMessageRail), 'text-green-700'],
                              ['CB Rejected', 'text-amber-700'],
                              ['Payment Confirmed', ''],
                              ['Payment Rejected', 'text-red-700'],
                              ['Exceptions', ''],
                              ['Value (AED)', ''],
                            ].map(([label, tone]) => (
                              <th key={label} className={cn(TH_NUM, tone)}>
                                {label}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody >
                          {messageRows.length === 0 ? (
                            <tr>
                              <td colSpan={13} className="text-center text-xs text-[var(--text-muted)]">
                                No message breakdown for the selected period.
                              </td>
                            </tr>
                          ) : (
                            messageRows.map((r) => {
                              const isTotal = r.type === 'TOTAL';
                              return (
                                <tr
                                  key={r.type}
                                  className={cn(
                                    isTotal
                                      ? 'font-bold'
                                      : '',
                                  )}
                                >
                                  <td className={cn(TD,)}>{r.type}</td>
                                  <td className={TD_NUM}>
                                    {!isTotal && canOpenReport(summaryReportFor(pickedMessageRail)) ? (
                                      <button
                                        type="button"
                                        className={CLICK_NUM}
                                        onClick={() => openSummaryReport(pickedMessageRail)}
                                      >
                                        {num(r.totalMsg)}
                                      </button>
                                    ) : (
                                      <span className={isTotal ? 'font-bold text-[var(--text-primary)]' : undefined}>
                                        {num(r.totalMsg)}
                                      </span>
                                    )}
                                  </td>
                                  <td className={TD_NUM}>
                                    {!isTotal && canOpenReport(detailReportFor(pickedMessageRail)) ? (
                                      <button
                                        type="button"
                                        className={CLICK_NUM}
                                        onClick={() => openDetailReport(pickedMessageRail)}
                                      >
                                        {num(r.totalTxn)}
                                      </button>
                                    ) : (
                                      <span className={isTotal ? 'font-bold text-[var(--text-primary)]' : undefined}>
                                        {num(r.totalTxn)}
                                      </span>
                                    )}
                                  </td>
                                  <td className={cn(TD_NUM, !isTotal && 'text-amber-700 font-medium')}>{num(r.pending)}</td>
                                  <td className={cn(TD_NUM, !isTotal && 'text-blue-700 font-medium')}>{num(r.inProgress)}</td>
                                  <td className={cn(TD_NUM, !isTotal && 'text-red-700 font-medium')}>{num(r.systemRejected)}</td>
                                  <td className={cn(TD_NUM, !isTotal && 'text-blue-700 font-medium')}>{num(r.sentToCb)}</td>
                                  <td className={cn(TD_NUM, !isTotal && 'text-green-700 font-semibold')}>{num(r.cbAccepted)}</td>
                                  <td className={cn(TD_NUM, !isTotal && 'text-amber-700 font-medium')}>{num(r.cbRejected)}</td>
                                  <td className={TD_NUM}>{num(r.paymentConfirmed)}</td>
                                  <td className={cn(TD_NUM, !isTotal && 'text-red-700 font-medium')}>{num(r.paymentRejected)}</td>
                                  <td className={TD_NUM}>{num(r.exceptions)}</td>
                                  <td className={cn(TD_NUM, 'font-mono')}>{r.value}</td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                      <p className="px-3 py-2 text-xs text-[var(--text-muted)]">
                        Total Msg counts files; Total Txn counts the employee records inside them. Pending through
                        Exceptions count files, each in exactly one column, so they add up to Total Msg.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </PageBody>
    </PageShell>
  );
}