import { Fragment, useEffect, useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ChevronDown, ChevronRight, Download, Search } from 'lucide-react';
import { Can, LoadingSpinner, PageBody, PageShell, cn, sessionToday, shiftDay, useSessionDateTime } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { useRailAccess } from '../../shared/auth/rails';
import { dashboardExportApi, inFlightApi, inFlightExportParams } from './api';
import type {
  ChannelInFlightRow,
  InFlightDateFilter,
  MessageInFlightRow,
  RailInFlightRow,
} from './types';

type ViewMode = 'rail' | 'channel' | 'message';

const RAIL_COLOR: Record<string, string> = {
  IPI: '#3b82f6',
  UAEFTS: '#8b5cf6',
  FTS: '#8b5cf6',
  WPS: '#22c55e',
  IPP: '#f59e0b',
  SWIFT: '#eab308',
};
const railColor = (rail: string) => RAIL_COLOR[rail?.toUpperCase()] ?? 'var(--primary-blue)';

const RAIL_DESCRIPTION: Record<string, string> = {
  IPI: 'Instant Payment Infrastructure',
  FTS: 'UAE Funds Transfer System',
  UAEFTS: 'UAE Funds Transfer System',
  WPS: 'Wage Protection System',
  IPP: 'Image Payment Protocol',
  SWIFT: 'International Transfers',
};
const railDescription = (rail: string) => RAIL_DESCRIPTION[rail?.toUpperCase()] ?? rail;

const MESSAGE_RAILS = ['IPI', 'UAEFTS', 'WPS'] as const;

const num = (n: number | null | undefined) => (n ?? 0).toLocaleString();

function formatValue(value: number | null | undefined): string {
  const v = value ?? 0;
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(1)}K`;
  return v.toFixed(0);
}

const sumBy = <T,>(rows: readonly T[], pick: (row: T) => number) => rows.reduce((acc, row) => acc + (pick(row) || 0), 0);

const DEFAULT_FILTER: InFlightDateFilter = { dateRange: 'tillToday', from: '', to: '' };

// const TH = 'px-3.5 py-3 text-left text-[14px] font-semibold uppercase tracking-wide text-[#4B5563] whitespace-nowrap';
// const TH_NUM = 'px-3.5 py-3 text-right text-[14px] font-semibold uppercase tracking-wide text-[#4B5563] whitespace-nowrap';
// const TD = 'px-3.5 py-3 text-[14px] text-[var(--text-secondary)] whitespace-nowrap';
// const TD_NUM = 'px-3.5 py-3 text-right text-[14px] tabular-nums text-[var(--text-secondary)] whitespace-nowrap';

function downloadCsv(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

export function InFlightPage() {
  const navigate = useNavigate();
  const { formatInstant } = useSessionDateTime();
  const { allows: allowsRail, allowed: heldRails } = useRailAccess();
  /** Stable dependency for the memos below — `allows` is a fresh closure on every render. */
  const heldRailKey = heldRails.join(',');
  const [params] = useSearchParams();
  const direction: 'outward' | 'inbound' = params.get('direction') === 'inbound' ? 'inbound' : 'outward';
  const dirLabel = direction === 'outward' ? 'Outward' : 'Inbound';

  const [view, setView] = useState<ViewMode>('rail');

  const [draft, setDraft] = useState<InFlightDateFilter>(DEFAULT_FILTER);
  const [applied, setApplied] = useState<InFlightDateFilter>(DEFAULT_FILTER);
  const [rangeError, setRangeError] = useState<string | null>(null);

  const [collapsedRails, setCollapsedRails] = useState<Record<string, boolean>>({});
  const [pickedMessageRail, setPickedMessageRail] = useState<string>('IPI');

  // Rails the By Message chip row may offer. The literal 'IPI' default above is wrong for anyone
  // not entitled to IPI, and the by-message endpoint now refuses a rail the caller does not hold —
  // so it is corrected here rather than left to 403 on tab open. An effect rather than a lazy
  // initialiser because the permission snapshot resolves after first paint: until it lands every
  // key reads as denied, so this list starts empty for everyone.
  const messageRails = MESSAGE_RAILS.filter(allowsRail);
  const messageRailKey = messageRails.join(',');

  useEffect(() => {
    if (messageRails.length > 0 && !(messageRails as readonly string[]).includes(pickedMessageRail)) {
      setPickedMessageRail(messageRails[0]);
    }
    // messageRailKey stands in for the array, which is rebuilt on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messageRailKey, pickedMessageRail]);

  // If the snapshot resolves while By Message is open and none of its rails are held, fall back to
  // a view that still has something to show rather than an empty selector over an empty table.
  useEffect(() => {
    if (view === 'message' && messageRails.length === 0) setView('rail');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messageRailKey, view]);

  const summaryQ = useQuery({
    queryKey: ['if-summary', applied],
    queryFn: () => inFlightApi.summary(applied),
  });
  const railQ = useQuery({
    queryKey: ['if-by-rail', applied],
    queryFn: () => inFlightApi.byRail(applied),
  });
  const channelQ = useQuery({
    queryKey: ['if-by-channel', applied],
    enabled: view === 'channel',
    queryFn: () => inFlightApi.byChannel(applied),
  });
  const messageQ = useQuery({
    queryKey: ['if-by-message', pickedMessageRail, applied],
    // Also gated on access so the one render between first paint and the snapshot resolving
    // cannot fire the request with the stale default rail and earn a 403.
    enabled: view === 'message' && allowsRail(pickedMessageRail),
    queryFn: () => inFlightApi.byMessage(pickedMessageRail, applied),
  });

  const summary = summaryQ.data;

  // ── By Rail ────────────────────────────────────────────────────────────────
  // Filtered for presentation only — the server already confines this query to the rails the
  // session holds. Without it a denied rail would read as "no traffic today" rather than "not
  // yours", and it would ride along into the CSV built from these same rows below.
  const railRows: RailInFlightRow[] = useMemo(
    () => (railQ.data?.rails ?? []).filter((r) => allowsRail(r.rail)),
    [railQ.data, heldRailKey],
  );
  const railTotals = railQ.data?.totals;
  const totalSystemProcessing = sumBy(railRows, (r) => r.systemProcessing);
  const totalExceptions = sumBy(railRows, (r) => r.exceptions);

  // ── By Channel ─────────────────────────────────────────────────────────────
  const channelGroups = useMemo(
    () => (channelQ.data?.railGroups ?? []).filter((g) => allowsRail(g.rail)),
    [channelQ.data, heldRailKey],
  );
  const channelGrandTotal = channelQ.data?.grandTotal;

  const messageRows: MessageInFlightRow[] = useMemo(() => {
    const data = messageQ.data;
    if (!data) return [];
    return [...data.messages, { ...data.totals, type: 'TOTAL' }];
  }, [messageQ.data]);

  const kpis = [
    {
      label: 'Total In Progress',
      value: `${num(summary?.totalInProgress)} txns`,
      sub: 'System Processing + Action Pending + Exceptions',
      color: '#1a56db',
    },
    {
      label: 'Action Pending',
      value: num(summary?.actionPending),
      sub: 'Awaiting processing',
      color: '#d97706',
    },
    {
      label: 'System Processing',
      value: num(summary?.systemProcessing),
      sub: `${formatValue(summary?.processingAmountAed)} AED · Being processed`,
      color: '#2563eb',
    },
    {
      label: 'Exceptions (Action Pending)',
      value: num((summary?.actionPending ?? 0) + (summary?.exceptions ?? 0)),
      sub: `${num(summary?.actionPending)} action pending · ${num(summary?.exceptions)} exceptions`,
      color: '#ea580c',
    },
  ];

  const onRangeChange = (dateRange: InFlightDateFilter['dateRange']) => {
    setDraft((d) => {
      if (dateRange !== 'custom') return { ...d, dateRange };
      // "Today" is the session zone's date, not the UTC one (UTC date-time T-22, AC-UT-K02).
      const today = sessionToday();
      return { ...d, dateRange, to: today, from: shiftDay(today, -7) };
    });
  };

  const doSearch = () => {
    if (draft.dateRange === 'custom') {
      if (!draft.from || !draft.to) return setRangeError('Please select both From and To dates.');
      if (draft.from > draft.to) return setRangeError('From date must be on or before the To date.');
    }
    setRangeError(null);
    setApplied(draft);
  };

  const todayLabel = formatInstant(Date.now(), 'date');

  /**
   * The CSV is built by the server, not here.
   *
   * It used to be assembled in this function from `railRows` / `channelGroups` / `messageRows` —
   * rows the grid already held — which made Export a button nothing could refuse. `ops:report:export`
   * gates `/api/ops/dashboard/export`, and a CSV built in the browser never reaches it.
   *
   * The server extract is also the narrower one: it scopes to the caller's own tenant and rails
   * after every bound parameter, where this function exported whatever had already been fetched.
   */
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  const exportCsv = async () => {
    setExporting(true);
    setExportError(null);
    try {
      const csv = await dashboardExportApi.csv({
        viewType: view,
        direction,
        dateParams: inFlightExportParams(applied),
        // The message view is scoped to one rail; the other two span every rail the caller holds.
        rail: view === 'message' ? pickedMessageRail : undefined,
      });

      const stamp = sessionToday();
      const scope = view === 'message' ? `Message_${pickedMessageRail}` : view === 'channel' ? 'Channel' : 'Rail';
      downloadCsv(csv, `InFlight_${scope}_${applied.dateRange}_${stamp}.csv`);
    } catch (err) {
      // Said on the page rather than swallowed: a 403 here means the caller holds the screen and
      // not the export key, which is a different thing from the export being broken.
      setExportError(
        (err as { response?: { status?: number } })?.response?.status === 403
          ? 'You do not hold the export permission (ops:report:export) for this extract.'
          : 'The export could not be generated. Nothing was downloaded.',
      );
    } finally {
      setExporting(false);
    }
  };

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / '}
              <span className="text-[var(--text-secondary)]">{dirLabel} In-Flight</span>
            </p>
          </div>

          {/* Title Header & Live Metric Pill */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] sm:text-[22px] lg:text-[24px] font-black text-[var(--text-primary)]">
                {dirLabel} In-Flight Payments — All Rails
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Live view of transactions still moving through the rails — system processing, action pending and exceptions
              </p>
            </div>
            <div className="inline-flex shrink-0 items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg-card)] px-3.5 py-2 text-xs font-semibold text-[var(--text-secondary)] shadow-sm">
              <span className="size-2 animate-pulse rounded-full bg-emerald-500" />
              Live&nbsp;
              <strong className="text-[var(--primary-blue)]">{num(summary?.totalInProgress)}</strong> txns
              <span className="text-[var(--border)]">|</span>
              <strong className="font-mono text-[var(--text-primary)]">{formatValue(summary?.processingAmountAed)} AED</strong>
            </div>
          </div>

          {/* KPI Metric Cards */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {kpis.map((k) => (
              <div
                key={k.label}
                className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]"
                style={{ borderTop: `3px solid ${k.color}` }}
              >
                <p className="input-label text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                  {k.label}
                </p>
                <p className="mt-1 text-2xl sm:text-3xl font-bold leading-none tabular-nums" style={{ color: k.color }}>
                  {summaryQ.isLoading ? '—' : k.value}
                </p>
                <p className="mt-2 text-[11px] text-[var(--text-muted)]">{k.sub}</p>
              </div>
            ))}
          </div>

          {/* Filter Bar Card */}
          <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]">
            <p className="input-label mb-2 text-[11px] font-bold tracking-wider text-[var(--text-muted)]">
              {dirLabel} in-flight transactions created filter
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <select
                  aria-label="Date range"
                  value={draft.dateRange}
                  onChange={(e) => onRangeChange(e.target.value as InFlightDateFilter['dateRange'])}
                  className="input-cls h-32px min-w-[220px] appearance-none pr-7"
                >
                  <option value="tillToday">Till Today (All Pending)</option>
                  <option value="today">Today</option>
                  <option value="yesterday">Yesterday</option>
                  <option value="custom">Custom Range</option>
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-2.5 size-3 text-[var(--text-muted)]" />
              </div>

              <button
                type="button"
                onClick={doSearch}
                className="btn-primary !py-1.5 !px-3.5 text-xs inline-flex items-center gap-1"
              >
                <Search size={13} />
                Search
              </button>

              {/* GET /api/ops/dashboard/export enforces ops:report:export; the button mirrors it. */}
              <Can permission={PERM.opsReportExport}>
                <button
                  type="button"
                  onClick={exportCsv}
                  disabled={exporting}
                  className="btn-secondary !py-1.5 !px-3 text-xs inline-flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Download size={13} />
                  {exporting ? 'Exporting…' : 'Export CSV'}
                </button>
              </Can>
            </div>

            {exportError && (
              <p className="mt-2 w-full text-xs text-[var(--accent-red)]" role="alert">
                {exportError}
              </p>
            )}

            {draft.dateRange === 'custom' && (
              <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-[var(--border)] pt-3 w-full">
                  <div className='w-[125px]'>
                <label htmlFor="if-from" className="input-label">
                  From:
                </label>
                <input
                  id="if-from"
                  type="date"
                  max={draft.to || sessionToday()}
                  value={draft.from}
                  onChange={(e) => setDraft((d) => ({ ...d, from: e.target.value }))}
                  className="input-cls h-7 text-xs"
                />
                </div>
                  <div className='w-[125px]'>
                <label htmlFor="if-to" className="input-label">
                  To:
                </label>
                <input
                  id="if-to"
                  type="date"
                  min={draft.from}
                  max={sessionToday()}
                  value={draft.to}
                  onChange={(e) => setDraft((d) => ({ ...d, to: e.target.value }))}
                  className="input-cls h-7 text-xs"
                />
                </div>
              </div>
            )}

            {rangeError && (
              <p
                role="alert"
                aria-live="assertive"
                className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700"
              >
                {rangeError}
              </p>
            )}
          </div>

          {/* View Selection Mode Pills */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {(
                [
                  { key: 'rail' as ViewMode, label: 'By Rail', loading: railQ.isLoading, shown: true },
                  { key: 'channel' as ViewMode, label: 'By Channel', loading: view === 'channel' && channelQ.isLoading, shown: true },
                  // By Rail and By Channel stay: they are cross-rail views that simply show fewer rows.
                  // By Message is different — its whole content is one rail picked from the chip row,
                  // so with no chip to pick it is an empty selector over an empty table.
                  { key: 'message' as ViewMode, label: 'By Message', loading: view === 'message' && messageQ.isLoading, shown: messageRails.length > 0 },
                ] as const
              ).filter((t) => t.shown).map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setView(t.key)}
                  className={cn(
                    'common-pill',
                    view === t.key
                      ? 'active-pill'
                      : '',
                  )}
                >
                  {t.label} {t.loading ? '⟳' : ''}
                </button>
              ))}
            </div>

            <span className="text-xs text-[var(--text-muted)] font-medium">
              Period: <strong className="text-[var(--text-secondary)]">{applied.dateRange}</strong>
            </span>
          </div>

          {/* ═══ By Rail Table ═══ */}
          {view === 'rail' && (
            <div className="overflow-x-auto rounded-lg border border-[var(--border)] table-holder">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border) px-[12px] py-[8px]">
                  <h4 className="mb-2">In-Flight Transactions By Rail</h4>
                <span className="text-xs text-[var(--text-muted)]">({railRows.length} rails)</span>
              </div>
              {railQ.isLoading ? (
                <div className="flex h-40 items-center justify-center">
                  <LoadingSpinner />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table >
                    <thead>
                      <tr >
                        <th >Rail</th>
                        {['Total Transactions', 'System Processing', 'Action Pending', 'Exceptions', 'Value (AED)'].map((c) => (
                          <th key={c} >
                            {c}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border-light)]">
                      {railRows.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-4 py-10 text-center text-xs text-[var(--text-muted)]">
                            No in-flight transactions for the selected period.
                          </td>
                        </tr>
                      ) : (
                        railRows.map((row) => {
                          const pendingWarn = row.actionPending > 50;
                          const exceptionsWarn = row.exceptions > 10;
                          return (
                            <tr key={row.rail} >
                              <td >
                                <span
                                  className="inline-flex rounded px-2 py-0.5 text-[10px] font-bold uppercase text-white shadow-xs"
                                  style={{ background: railColor(row.rail) }}
                                >
                                  {row.rail}
                                </span>
                              </td>
                              <td>
                                {num(row.totalInProgress)}
                              </td>
                              <td >
                                {num(row.systemProcessing)}
                              </td>
                              <td >
                                {num(row.actionPending)}{pendingWarn ? ' ⚠' : ''}
                              </td>
                              <td >
                                {num(row.exceptions)}{exceptionsWarn ? ' ⚠' : ''}
                              </td>
                              <td >{formatValue(row.value)}</td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                    <tfoot>
                      <tr >
                        <td className="px-3.5 py-3 text-xs font-black uppercase text-[var(--text-primary)]">Total</td>
                        <td className={cn('font-bold text-[var(--text-primary)]')}>{num(railTotals?.totalInProgress)}</td>
                        <td className={cn('text-blue-700')}>{num(totalSystemProcessing)}</td>
                        <td className={cn('text-amber-700')}>{num(railTotals?.actionPending)}</td>
                        <td className={cn('text-amber-700')}>{num(totalExceptions)}</td>
                        <td className={cn('font-mono text-[var(--text-primary)]')}>{formatValue(railTotals?.value)}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ═══ By Channel Table ═══ */}
          {view === 'channel' && (
            <div className="overflow-hidden rounded-xl border border-[var(--border)] table-holder">
              <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] px-[12px] py-[12px] items-center mb-2">
                <h4 >In-Flight Transactions By Channel</h4>
                <span className="ml-auto text-xs text-[var(--text-muted)]">({channelGroups.length} schemes)</span>
              </div>
              {channelQ.isLoading ? (
                <div className="flex h-40 items-center justify-center">
                  <LoadingSpinner />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table>
                    <thead>
                      <tr >
                        <th >Rail</th>
                        <th>Channel</th>
                        {['Total In Progress', 'System Processing', 'Action Pending', 'Exceptions', 'Value (AED)'].map((c) => (
                          <th key={c} >
                            {c}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody >
                      {channelGroups.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-4 py-10 text-center text-xs text-[var(--text-muted)]">
                            No channel breakdown for the selected period.
                          </td>
                        </tr>
                      ) : (
                        <>
                          {channelGroups.map((group) => {
                            const collapsed = collapsedRails[group.rail] ?? false;
                            const sub: ChannelInFlightRow = group.railSubtotal;
                            return (
                              <Fragment key={group.rail}>
                                <tr
                                  onClick={() => setCollapsedRails((p) => ({ ...p, [group.rail]: !p[group.rail] }))}
                                 
                                >
                                  <td
                                    colSpan={7}
                                   
                                    style={{ color: railColor(group.rail) }}
                                  >
                                    <span className="inline-flex items-center gap-1.5">
                                      {collapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                                      {group.rail} — {railDescription(group.rail)}
                                    </span>
                                  </td>
                                </tr>
                                {!collapsed &&
                                  group.channels.map((ch) => {
                                    const pendingWarn = ch.actionPending > 50;
                                    const exceptionsWarn = ch.exceptions > 10;
                                    return (
                                      <tr
                                        key={`${group.rail}-${ch.channel}`}
                                        
                                      >
                                        <td >
                                          <span
                                            className="common-badge text-[10px] font-bold uppercase text-white"
                                            style={{ background: railColor(group.rail) }}
                                          >
                                            {group.rail}
                                          </span>
                                        </td>
                                        <td >{ch.channel}</td>
                                        <td >
                                          {num(ch.totalInProgress)}
                                        </td>
                                        <td >{num(ch.systemProcessing)}</td>
                                        <td className={cn( pendingWarn ? 'font-bold text-amber-700' : 'text-[var(--text-secondary)]')}>
                                          {num(ch.actionPending)}{pendingWarn ? ' ⚠' : ''}
                                        </td>
                                        <td className={cn( exceptionsWarn ? 'font-bold text-amber-700' : 'text-[var(--text-secondary)]')}>
                                          {num(ch.exceptions)}{exceptionsWarn ? ' ⚠' : ''}
                                        </td>
                                        <td >{formatValue(ch.value)}</td>
                                      </tr>
                                    );
                                  })}
                                <tr >
                                  <td colSpan={2} className="font-bold uppercase text-[var(--text-muted)]">
                                    {group.rail} Sub-Total
                                  </td>
                                  <td className={cn('font-bold text-[var(--text-primary)]')}>{num(sub.totalInProgress)}</td>
                                  <td className={cn(  'text-blue-700')}>{num(sub.systemProcessing)}</td>
                                  <td className={cn(  'text-amber-700')}>{num(sub.actionPending)}</td>
                                  <td className={cn(  'text-amber-700')}>{num(sub.exceptions)}</td>
                                  <td className={cn(  'font-mono')}>{formatValue(sub.value)}</td>
                                </tr>
                              </Fragment>
                            );
                          })}
                          <tr className="border-t-2 border-[var(--border)] bg-[var(--bg-secondary)]/60 font-bold text-[var(--text-primary)]">
                            <td colSpan={2} className="px-3.5 py-3 text-xs font-black uppercase text-[var(--text-primary)]">
                              Grand Total — All Channels
                            </td>
                            <td className={cn(  'font-bold text-[var(--text-primary)]')}>{num(channelGrandTotal?.totalInProgress)}</td>
                            <td className={cn(  'text-blue-700')}>{num(channelGrandTotal?.systemProcessing)}</td>
                            <td className={cn(  'text-amber-700')}>{num(channelGrandTotal?.actionPending)}</td>
                            <td className={cn(  'text-amber-700')}>{num(channelGrandTotal?.exceptions)}</td>
                            <td className={cn(  'font-mono text-[var(--text-primary)]')}>{formatValue(channelGrandTotal?.value)}</td>
                          </tr>
                        </>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ═══ By Message Table ═══ */}
          {view === 'message' && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2.5 rounded-xl border border-[var(--border)] bg-[#eff6ff] px-4 py-3 text-xs text-[#1e40af]">
                <span className="font-bold">ℹ</span>
                <span>
                  Transaction Processing Status — full message lifecycle by rail. Select a rail below to view processing stages, counts, and outcomes.
                </span>
              </div>
              <div className='overflow-hidden rounded-xl border border-[var(--border)] table-holder'>
              {/* Message Rail Filter Pills */}
              <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] px-[12px] py-[12px]">
                <span className="input-label">
                  Select rail:
                </span>
                {messageRails.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setPickedMessageRail(r)}
                    className={cn(
                      'iinline-flex items-center gap-1.5 common-pill',
                      pickedMessageRail === r
                        ? 'active-pill'
                        : '',
                    )}
                  >
                    <span className="rail-dot" style={{ background: railColor(r) }} />
                    {r}
                  </button>
                ))}
              </div>

              <div >
             <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px]">
                  <div className='flex mb-2 items-center'>
                    <h4 >
                      {dirLabel} — {pickedMessageRail}
                    </h4>
                    <span className="ml-2 text-xs text-[var(--text-muted)]">
                      Summary of messages for {applied.dateRange === 'today' || applied.dateRange === 'tillToday' ? 'today' : 'selected period'} ({todayLabel})
                    </span>
                    
                  </div>
                   <button
                    type="button"
                    onClick={() => setView('rail')}
                    className="btn-secondary !py-1 !px-2.5 text-xs"
                  >
                    ← Back to Rail View
                  </button>
                </div>
                {messageQ.isLoading ? (
                  <div className="flex h-40 items-center justify-center">
                    <LoadingSpinner />
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table >
                      <thead>
                        <tr >
                          <th >Message Type</th>
                          {[
                            ['Total In Progress', ''],
                            ['System Processing', 'text-blue-700'],
                            ['Action Pending', 'text-amber-700'],
                            ['Exceptions', 'text-red-700'],
                            ['Value (AED)', ''],
                          ].map(([label, tone]) => (
                            <th key={label} className={cn( tone)}>
                              {label}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody >
                        {messageRows.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="px-4 py-10 text-center text-xs text-[var(--text-muted)]">
                              No message breakdown for the selected period.
                            </td>
                          </tr>
                        ) : (
                          messageRows.map((r) => {
                            const isTotal = r.type === 'TOTAL';
                            return (
                              <tr
                                key={r.type}
                               
                              >
                                <td >{r.type}</td>
                                <td >
                                  {num(r.totalInProgress)}
                                </td>
                                <td className={cn(  !isTotal && 'text-blue-700 font-medium')}>{num(r.systemProcessing)}</td>
                                <td className={cn(  !isTotal && 'text-amber-700 font-medium')}>{num(r.actionPending)}</td>
                                <td className={cn(  !isTotal && 'text-red-700 font-medium')}>{num(r.exceptions)}</td>
                                <td className={cn(  'font-mono')}>{formatValue(r.value)}</td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
            </div>
          )}
        </div>
      </PageBody>
    </PageShell>
  );
}