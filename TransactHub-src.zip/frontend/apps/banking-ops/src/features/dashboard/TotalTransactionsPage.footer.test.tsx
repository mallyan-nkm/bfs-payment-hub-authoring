/**
 * Total Transactions → By Rail footer.
 *
 * The Total row must be the sum of the rows above it. It used to read /transaction-summary, which values every status
 * (383,535 AED in the reported case) while the rows value settled payments only (76,707 AED), so the footer disagreed
 * with the column it sat under.
 */
import { render, screen, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { TotalTransactionsPage } from './TotalTransactionsPage';

const api = vi.hoisted(() => ({
  summary: vi.fn(),
  byRail: vi.fn(),
  byChannel: vi.fn(),
  byMessage: vi.fn(),
}));

vi.mock('./api', () => ({ totalTransactionsApi: api }));

vi.mock('../../shared/auth/rails', () => ({
  useRailAccess: () => ({ allows: () => true, allowed: ['IPI', 'WPS'] }),
}));

const railRow = (rail: string, v: Partial<Record<string, number>>) => ({
  rail,
  totalTxns: 0,
  success: 0,
  failed: 0,
  inProgress: 0,
  pending: 0,
  exceptions: 0,
  totalAed: 0,
  ...v,
});

function renderPage() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={['/total-transactions']}>
        <TotalTransactionsPage />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

describe('Total Transactions → By Rail footer', () => {
  beforeEach(() => {
    // Every status and every rail: deliberately different from what the rows add up to.
    api.summary.mockResolvedValue({
      totalTxns: 999,
      pending: 998,
      success: 997,
      failed: 996,
      inProgress: 995,
      exceptions: 994,
      totalAed: 383535,
    });
    api.byRail.mockResolvedValue({
      rails: [
        railRow('WPS', { totalTxns: 50, inProgress: 3, pending: 18, success: 9, failed: 5, exceptions: 15, totalAed: 76707 }),
        railRow('IPI', { totalTxns: 10, inProgress: 1, pending: 2, success: 3, failed: 1, exceptions: 3, totalAed: 1293 }),
      ],
    });
    api.byChannel.mockResolvedValue([]);
    api.byMessage.mockResolvedValue({});
  });

  it('adds the rows up, in every column including Value', async () => {
    renderPage();

    const total = (await screen.findByText('Total', { selector: 'td' })).closest('tr') as HTMLElement;
    const cells = within(total)
      .getAllByRole('cell')
      .map((c) => c.textContent?.trim());

    // Total Transactions, System Processing, Pending, Success, Failed, Exceptions, Value
    expect(cells.slice(1)).toEqual(['60', '4', '20', '12', '6', '18', '78,000 AED']);
    expect(cells.join('|')).not.toContain('383,535');
  });
});
