/**
 * Total Transactions → SIF report drill-down.
 *
 * The applied Transaction Date filter must reach the report as `uploadDateFrom` / `uploadDateTo`
 * (concrete local days), through every WPS count link, with each link keeping its existing
 * destination. Under a Value Date filter the SIF reports cannot honour the filter, so those counts
 * must not be links at all.
 *
 * Rendered in jsdom against a mocked dashboard API; only the Date is faked, so timers and
 * react-query behave normally.
 */
import { fireEvent, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, useLocation } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { TotalTransactionsPage } from './TotalTransactionsPage';

const api = vi.hoisted(() => ({
  summary: vi.fn(),
  byRail: vi.fn(),
  byChannel: vi.fn(),
  byMessage: vi.fn(),
}));

vi.mock('./api', () => ({ totalTransactionsApi: api }));

vi.mock('../../shared/auth/rails', () => ({
  useRailAccess: () => ({ allows: () => true, allowed: ['IPI', 'WPS'] }),
}));

// Distinct, recognisable counts so each link can be found by its number.
const RAIL_WPS = 111;
const RAIL_IPI = 555;
const CHANNEL_WPS = 222;
const MSG_TOTAL_MSG = 333;
const MSG_TOTAL_TXN = 444;

const DETAIL = '/reports/wps/sif-detail';
const SUMMARY = '/reports/sif-summary';

const railRow = (rail: string, totalTxns: number) => ({
  rail,
  totalTxns,
  success: 0,
  failed: 0,
  inProgress: 0,
  pending: 0,
  exceptions: 0,
  totalAed: 0,
});

const messageRow = (totalMsg: number, totalTxn: number) => ({
  type: 'SIF',
  totalMsg,
  totalTxn,
  pending: 0,
  inProgress: 0,
  systemRejected: 0,
  sentToCb: 0,
  cbAccepted: 0,
  cbRejected: 0,
  paymentConfirmed: 0,
  paymentRejected: 0,
  exceptions: 0,
  value: '0 AED',
});

function LocationProbe() {
  const { pathname, search } = useLocation();
  return <div data-testid="location">{`${pathname}${search}`}</div>;
}

const location = () => screen.getByTestId('location').textContent;

function renderPage() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={['/total-transactions']}>
        <LocationProbe />
        <TotalTransactionsPage />
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

const user = () => userEvent.setup();

async function applyFilter(u: ReturnType<typeof userEvent.setup>, opts: { dateType?: string; dateRange?: string }) {
  if (opts.dateType) await u.selectOptions(screen.getByLabelText('Date type'), opts.dateType);
  if (opts.dateRange) await u.selectOptions(screen.getByLabelText('Date range'), opts.dateRange);
  await u.click(screen.getByRole('button', { name: /^Search$/ }));
}

const pickView = (u: ReturnType<typeof userEvent.setup>, name: RegExp) => u.click(screen.getByRole('button', { name }));

/** The user's own view of "is this count a link": a button named by its number. */
const countLink = (n: number) => screen.queryByRole('button', { name: String(n) });

beforeEach(() => {
  // Midday so the UTC-based date validation in the filter bar agrees with the local day.
  vi.useFakeTimers({ toFake: ['Date'] });
  vi.setSystemTime(new Date(2026, 8, 15, 12, 0, 0));

  api.summary.mockResolvedValue({});
  api.byRail.mockResolvedValue({ rails: [railRow('WPS', RAIL_WPS), railRow('IPI', RAIL_IPI)] });
  api.byChannel.mockResolvedValue([
    {
      rail: 'WPS',
      description: 'Wage Protection System',
      colorClass: 'group-wps',
      channels: [
        {
          name: 'IB',
          totalTxns: CHANNEL_WPS,
          inProgress: 0,
          pending: 0,
          pendingWarn: false,
          success: 0,
          failed: 0,
          exceptions: 0,
          exceptionsWarn: false,
          value: '0 AED',
        },
      ],
    },
  ]);
  api.byMessage.mockResolvedValue({ WPS: [messageRow(MSG_TOTAL_MSG, MSG_TOTAL_TXN)] });
});

afterEach(() => {
  vi.useRealTimers();
  vi.clearAllMocks();
});

describe('Total Transactions → SIF drill-down: Transaction Date filter is carried over', () => {
  it('Today: By Rail count opens SIF Detail with today as both bounds', async () => {
    const u = user();
    renderPage();

    await u.click(await screen.findByRole('button', { name: String(RAIL_WPS) }));

    expect(location()).toBe(`${DETAIL}?uploadDateFrom=2026-09-15&uploadDateTo=2026-09-15`);
  });

  it('Yesterday: uses yesterday as both bounds', async () => {
    const u = user();
    renderPage();
    await applyFilter(u, { dateRange: 'yesterday' });

    await u.click(await screen.findByRole('button', { name: String(RAIL_WPS) }));

    expect(location()).toBe(`${DETAIL}?uploadDateFrom=2026-09-14&uploadDateTo=2026-09-14`);
  });

  it('Custom Range: uses the applied From / To', async () => {
    const u = user();
    renderPage();
    await u.selectOptions(screen.getByLabelText('Date range'), 'customRange');
    fireEvent.change(screen.getByLabelText('From:'), { target: { value: '2026-09-10' } });
    fireEvent.change(screen.getByLabelText('To:'), { target: { value: '2026-09-14' } });
    await u.click(screen.getByRole('button', { name: /^Search$/ }));

    await u.click(await screen.findByRole('button', { name: String(RAIL_WPS) }));

    expect(location()).toBe(`${DETAIL}?uploadDateFrom=2026-09-10&uploadDateTo=2026-09-14`);
  });

  it('carries the APPLIED filter, not edits that have not been searched yet', async () => {
    const u = user();
    renderPage();
    await screen.findByRole('button', { name: String(RAIL_WPS) });

    // Draft says Yesterday, but Search was never pressed: applied is still Today.
    await u.selectOptions(screen.getByLabelText('Date range'), 'yesterday');
    await u.click(screen.getByRole('button', { name: String(RAIL_WPS) }));

    expect(location()).toBe(`${DETAIL}?uploadDateFrom=2026-09-15&uploadDateTo=2026-09-15`);
  });

  it('sends only the report\'s own upload-date params', async () => {
    const u = user();
    renderPage();

    await u.click(await screen.findByRole('button', { name: String(RAIL_WPS) }));

    const params = new URLSearchParams(location()!.split('?')[1]);
    expect([...params.keys()].sort()).toEqual(['uploadDateFrom', 'uploadDateTo']);
  });
});

describe('Total Transactions → SIF drill-down: destinations are unchanged', () => {
  const DATES = '?uploadDateFrom=2026-09-15&uploadDateTo=2026-09-15';

  it('By Rail → SIF Detail', async () => {
    const u = user();
    renderPage();
    await u.click(await screen.findByRole('button', { name: String(RAIL_WPS) }));
    expect(location()).toBe(`${DETAIL}${DATES}`);
  });

  it('By Channel → SIF Detail', async () => {
    const u = user();
    renderPage();
    await pickView(u, /^By Channel/);
    await u.click(await screen.findByRole('button', { name: String(CHANNEL_WPS) }));
    expect(location()).toBe(`${DETAIL}${DATES}`);
  });

  it('By Message "Total Msg" → SIF Summary', async () => {
    const u = user();
    renderPage();
    await pickView(u, /^By Message/);
    await u.click(await screen.findByRole('button', { name: 'WPS' }));
    await u.click(await screen.findByRole('button', { name: String(MSG_TOTAL_MSG) }));
    expect(location()).toBe(`${SUMMARY}${DATES}`);
  });

  it('By Message "Total Txn" → SIF Detail', async () => {
    const u = user();
    renderPage();
    await pickView(u, /^By Message/);
    await u.click(await screen.findByRole('button', { name: 'WPS' }));
    await u.click(await screen.findByRole('button', { name: String(MSG_TOTAL_TXN) }));
    expect(location()).toBe(`${DETAIL}${DATES}`);
  });

  it('a rail with no report is still plain text', async () => {
    renderPage();
    await screen.findByRole('button', { name: String(RAIL_WPS) });
    expect(countLink(RAIL_IPI)).toBeNull();
    expect(screen.getByText(String(RAIL_IPI))).toBeInTheDocument();
  });
});

describe('Total Transactions → SIF drill-down: Value Date is not drillable', () => {
  it('renders every WPS count as plain text in all three views, and never navigates', async () => {
    const u = user();
    renderPage();
    await screen.findByRole('button', { name: String(RAIL_WPS) });

    await applyFilter(u, { dateType: 'valueDate' });

    // By Rail
    expect(await screen.findByText(String(RAIL_WPS))).toBeInTheDocument();
    expect(countLink(RAIL_WPS)).toBeNull();

    // By Channel
    await pickView(u, /^By Channel/);
    // The number also appears in the rail's sub-total and the grand total, hence "all".
    expect((await screen.findAllByText(String(CHANNEL_WPS))).length).toBeGreaterThan(0);
    expect(countLink(CHANNEL_WPS)).toBeNull();

    // By Message (Total Msg and Total Txn)
    await pickView(u, /^By Message/);
    await u.click(await screen.findByRole('button', { name: 'WPS' }));
    const table = (await screen.findByText('SIF')).closest('table')!;
    expect(within(table).getAllByText(String(MSG_TOTAL_MSG)).length).toBeGreaterThan(0);
    expect(countLink(MSG_TOTAL_MSG)).toBeNull();
    expect(within(table).getAllByText(String(MSG_TOTAL_TXN)).length).toBeGreaterThan(0);
    expect(countLink(MSG_TOTAL_TXN)).toBeNull();

    expect(location()).toBe('/total-transactions');
  });

  it('restores the links when the filter goes back to Transaction Date', async () => {
    const u = user();
    renderPage();
    await applyFilter(u, { dateType: 'valueDate' });
    await screen.findByText(String(RAIL_WPS));
    expect(countLink(RAIL_WPS)).toBeNull();

    await applyFilter(u, { dateType: 'transactionDate' });

    expect(await screen.findByRole('button', { name: String(RAIL_WPS) })).toBeInTheDocument();
  });
});
