import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Plus, RotateCcw, Search, Workflow } from 'lucide-react';
import { Badge, Can, StatusBadge, LoadingSpinner, cn, useSessionDateTime, shiftDay } from '@paymenthub/ui';
import type { Payment } from '@paymenthub/ui';
import { bankingApi } from '../../shared/api/bankingApi';
import { useRailAccess } from '../../shared/auth/rails';
import { transactionsApi } from '../operations/transactions/api';
import { StatCard } from './components/StatCard';
import { GrowthPopover } from './components/GrowthPopover';
import { TransactionFlowModal } from './components/TransactionFlowModal';
import type { GrowthPoint } from './components/GrowthChart';

/** Short weekday of a calendar day (`yyyy-MM-dd`): zone-free arithmetic on the date itself. */
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;
function weekdayOf(day: string): string {
  const [y, m, d] = day.split('-').map(Number);
  return WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
}

interface RailRow {
  rail: string;
  totalTxns: number;
  success: number;
  failed: number;
  inProgress: number;
  pending: number;
  exceptions: number;
  totalAed: number;
}
interface SummaryResp {
  rails: RailRow[];
  totals: RailRow;
  avgProcessingTimeSec: number;
}

const RAIL_LABEL: Record<string, string> = { FTS: 'FTS', UAEFTS: 'FTS', IPI: 'IPI', WPS: 'WPS', EDDA: 'eDDA', NPSS: 'NPSS', XBDR: 'XBDR', IPP: 'IPP', SWIFT: 'SWIFT' };

const STATUS_TABS: { key: string; label: string; match: (s: string) => boolean }[] = [
  { key: 'ALL', label: 'All Transactions', match: () => true },
  { key: 'COMPLETED', label: 'Completed', match: (s) => s === 'COMPLETED' },
  { key: 'PROCESSING', label: 'Processing', match: (s) => s === 'PROCESSING' || s === 'APPROVED' },
  { key: 'FAILED', label: 'Failed', match: (s) => s === 'FAILED' },
  { key: 'ATTENTION', label: 'Need Attention', match: (s) => s === 'REVERSED' || s === 'CANCELLED' },
  { key: 'PENDING', label: 'Pending', match: (s) => s === 'PENDING_APPROVAL' || s === 'DRAFT' },
  { key: 'REJECTED', label: 'Rejected', match: (s) => s === 'REJECTED' },
];

function fmtSecs(s: number): string {
  if (!s) return '< 1';
  if (s < 60) return s.toFixed(1);
  return `${Math.floor(s / 60)}m`;
}

export function OverallDashboard() {
  const navigate = useNavigate();
  const { formatInstant, todayInZone } = useSessionDateTime();
  const { allows: allowsRail } = useRailAccess();
  const [rail, setRail] = useState('ALL');
  const [statusTab, setStatusTab] = useState('ALL');
  const [search, setSearch] = useState('');
  const [minAmt, setMinAmt] = useState('');
  const [maxAmt, setMaxAmt] = useState('');
  const [flowTxn, setFlowTxn] = useState<string | null>(null);

  const summaryQ = useQuery({
    queryKey: ['overall-summary'],
    queryFn: () =>
      bankingApi
        .get<SummaryResp>('/ops/dashboard/transaction-summary-by-rail', {
          params: { direction: 'Outward', dateRange: 'today' },
        })
        .then((r) => r.data),
    refetchInterval: 30_000,
  });

  const txnQ = useQuery({
    queryKey: ['overall-transactions'],
    queryFn: () => transactionsApi.search({ page: 1, pageSize: 100 }).then((r) => r.data.items),
  });

  const summary = summaryQ.data;
  const totals = summary?.totals;
  const txns = useMemo(() => txnQ.data ?? [], [txnQ.data]);

  // ── Rail chips ──
  // Filtered by rail access: the dashboard is a shared screen, so denying a rail must remove that
  // rail's slice of it rather than the whole page. Rows for rails the session cannot reach are
  // dropped before the chips are built, so the counts a user sees are counts they may see.
  const railChips = useMemo(() => {
    const rows = (summary?.rails ?? []).filter((r) => allowsRail(r.rail));
    const all = { rail: 'ALL', label: 'All', count: totals?.totalTxns ?? 0 };
    return [all, ...rows.map((r) => ({ rail: r.rail, label: RAIL_LABEL[r.rail?.toUpperCase()] ?? r.rail, count: r.totalTxns }))];
  }, [summary, totals, allowsRail]);

  // ── KPI values ──
  const kpis = totals
    ? {
        total: totals.totalTxns,
        successRate: totals.totalTxns > 0 ? (totals.success / totals.totalTxns) * 100 : 0,
        failed: totals.failed + totals.exceptions,
        pending: totals.pending + totals.inProgress,
        avg: fmtSecs(summary?.avgProcessingTimeSec ?? 0),
        awaiting: totals.pending,
      }
    : null;

  // ── Growth chart: real transactions aggregated over the last 7 days ──
  const growth: GrowthPoint[] = useMemo(() => {
    // Days in the session zone, not UTC or the browser's.
    const days: GrowthPoint[] = [];
    const counts = new Map<string, number>();
    for (const t of txns) {
      const epoch = new Date(t.submittedAt).getTime();
      if (Number.isNaN(epoch)) continue;
      const key = todayInZone(epoch);
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    const today = todayInZone();
    for (let i = 6; i >= 0; i--) {
      const key = shiftDay(today, -i);
      days.push({ label: weekdayOf(key), value: counts.get(key) ?? 0 });
    }
    return days;
  }, [txns, todayInZone]);

  // ── Filtered table ──
  const railFiltered = useMemo(() => {
    if (rail === 'ALL') return txns;
    return txns.filter((t) => (RAIL_LABEL[t.rail?.toUpperCase()] ?? t.rail)?.toUpperCase() === (RAIL_LABEL[rail] ?? rail).toUpperCase());
  }, [txns, rail]);

  const statusCounts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const tab of STATUS_TABS) c[tab.key] = railFiltered.filter((t) => tab.match(t.status)).length;
    return c;
  }, [railFiltered]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const min = minAmt ? parseFloat(minAmt) : null;
    const max = maxAmt ? parseFloat(maxAmt) : null;
    const tab = STATUS_TABS.find((t) => t.key === statusTab) ?? STATUS_TABS[0];
    return railFiltered.filter((t) => {
      if (!tab.match(t.status)) return false;
      if (min != null && t.amount < min) return false;
      if (max != null && t.amount > max) return false;
      if (q && !`${t.referenceNumber} ${t.debtorAccount} ${t.creditorAccount}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [railFiltered, statusTab, search, minAmt, maxAmt]);

  const clearAll = () => {
    setSearch('');
    setMinAmt('');
    setMaxAmt('');
    setStatusTab('ALL');
  };

  if (summaryQ.isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Rail chips + New Payment */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap items-center gap-2">
          {railChips.map((c) => {
            const active = rail === c.rail;
            return (
              <button
                key={c.rail}
                onClick={() => setRail(c.rail)}
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors',
                  active
                    ? 'border-transparent text-white'
                    : 'border-[var(--border)] bg-[var(--bg-card)] text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
                )}
                style={active ? { background: 'var(--brand-gradient)' } : undefined}
              >
                {c.label}
                <span className={cn('text-xs', active ? 'text-white/90' : 'text-[var(--text-muted)]')}>{c.count}</span>
              </button>
            );
          })}
        </div>
        <div className="ml-auto flex items-center gap-2">
          <GrowthPopover points={growth} />
          {/* Labelled "New Payment" but it goes straight to /wps/initiate, so it is a WPS
              control and follows the WPS rail. Hidden rather than disabled: the route guard
              would bounce the click anyway, and a button that always fails is worse than none. */}
          <Can permission="rail:WPS:access" mode="hide">
            <button
              onClick={() => navigate('/wps/initiate')}
              className="inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold text-white shadow-sm"
              style={{ background: 'var(--brand-gradient)' }}
            >
              <Plus size={15} /> New Payment
            </button>
          </Can>
        </div>
      </div>

      {/* KPI strip — single compact row */}
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
        <StatCard tone="blue" label="Total Transactions" value={kpis?.total ?? 0} footer="breakdown" onClick={() => navigate('/total-transactions?direction=all')} />
        <StatCard tone="green" label="Success Rate" value={`${(kpis?.successRate ?? 0).toFixed(1)}%`} footer={(kpis?.successRate ?? 0) >= 90 ? 'healthy' : 'attention'} footerTone={(kpis?.successRate ?? 0) >= 90 ? 'success' : 'warning'} />
        <StatCard tone="red" label="Failed" value={kpis?.failed ?? 0} footer={(kpis?.failed ?? 0) > 0 ? 'review' : 'none'} footerTone={(kpis?.failed ?? 0) > 0 ? 'danger' : 'success'} onClick={() => navigate('/exceptions')} />
        <StatCard tone="amber" label="Pending / Proc." value={kpis?.pending ?? 0} footer={`${totals?.pending ?? 0}p · ${totals?.inProgress ?? 0}pr`} />
        <StatCard tone="purple" label="Avg Time" value={kpis?.avg ?? '—'} footer="sec" />
        <StatCard tone="yellow" label="Awaiting Appr." value={kpis?.awaiting ?? 0} footer={(kpis?.awaiting ?? 0) > 0 ? 'review' : 'clear'} footerTone={(kpis?.awaiting ?? 0) > 0 ? 'warning' : 'success'} onClick={() => navigate('/operations/approvals')} />
      </div>

      {/* Table card: compact filters + status tabs + table */}
      <div className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--bg-card)] shadow-[var(--shadow-sm)]">
        {/* Compact filter bar */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] px-3 py-2">
          <span className="relative min-w-0 flex-1 sm:max-w-xs">
            <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Txn ID, sender, receiver…" className="h-9 w-full rounded-lg border border-[var(--border)] bg-[var(--bg-input)] pl-9 pr-3 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent)]" />
          </span>
          <input value={minAmt} onChange={(e) => setMinAmt(e.target.value)} type="number" placeholder="Min AED" className="h-9 w-28 rounded-lg border border-[var(--border)] bg-[var(--bg-input)] px-3 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent)]" />
          <input value={maxAmt} onChange={(e) => setMaxAmt(e.target.value)} type="number" placeholder="Max AED" className="h-9 w-28 rounded-lg border border-[var(--border)] bg-[var(--bg-input)] px-3 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent)]" />
          <button onClick={clearAll} className="ml-auto inline-flex h-9 items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--bg-secondary)] px-3 text-sm text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]">
            <RotateCcw size={14} /> Clear
          </button>
        </div>
        {/* Status tabs */}
        <div className="flex flex-wrap gap-1.5 border-b border-[var(--border)] px-3 py-2">
          {STATUS_TABS.map((t) => {
            const active = statusTab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setStatusTab(t.key)}
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium transition-colors',
                  active ? 'text-white' : 'text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
                )}
                style={active ? { background: 'var(--brand-gradient)' } : undefined}
              >
                {t.label}
                <span className={cn('rounded-full px-1.5 text-xs', active ? 'bg-white/20' : 'bg-[var(--bg-secondary)] text-[var(--text-muted)]')}>
                  {statusCounts[t.key] ?? 0}
                </span>
              </button>
            );
          })}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-max text-sm">
            <thead>
              <tr className="border-b border-[var(--border)] bg-[var(--bg-secondary)] text-left text-xs font-semibold uppercase tracking-wide text-[var(--text-muted)]">
                <th className="px-4 py-3">Transaction ID</th>
                <th className="px-4 py-3">Date / Time</th>
                <th className="px-4 py-3">Application</th>
                <th className="px-4 py-3">Sender</th>
                <th className="px-4 py-3">Receiver</th>
                <th className="px-4 py-3 text-right">Amount</th>
                <th className="px-4 py-3">Currency</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-center">Flow</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-light)]">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-10 text-center text-[var(--text-muted)]">
                    No transactions match the current filters.
                  </td>
                </tr>
              ) : (
                filtered.slice(0, 25).map((t: Payment) => (
                  <tr
                    key={t.id}
                    onClick={() => navigate(`/operations/transactions/${encodeURIComponent(t.id)}/360`)}
                    className="cursor-pointer odd:bg-[var(--bg-secondary)] hover:bg-[var(--bg-card-hover)]"
                  >
                    <td className="px-4 py-2.5 font-mono text-xs text-[var(--accent)]">{t.referenceNumber}</td>
                    <td className="px-4 py-2.5 text-[var(--text-secondary)]">{formatInstant(t.submittedAt)}</td>
                    <td className="px-4 py-2.5"><Badge variant="outline">{RAIL_LABEL[t.rail?.toUpperCase()] ?? t.rail}</Badge></td>
                    <td className="px-4 py-2.5 text-[var(--text-secondary)]">{t.debtorAccount || '—'}</td>
                    <td className="px-4 py-2.5 text-[var(--text-secondary)]">{t.creditorAccount || '—'}</td>
                    <td className="px-4 py-2.5 text-right font-medium text-[var(--text-primary)] tabular-nums">{t.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                    <td className="px-4 py-2.5 text-[var(--text-muted)]">{t.currency}</td>
                    <td className="px-4 py-2.5"><StatusBadge status={t.status} /></td>
                    <td className="px-4 py-2.5 text-center">
                      <button
                        onClick={(e) => { e.stopPropagation(); setFlowTxn(t.id); }}
                        title="View transaction flow"
                        aria-label="View transaction flow"
                        className="inline-grid size-7 place-items-center rounded-md text-[var(--text-muted)] transition-colors hover:bg-[var(--bg-card-hover)] hover:text-[var(--accent)]"
                      >
                        <Workflow size={15} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {flowTxn && <TransactionFlowModal txnId={flowTxn} onClose={() => setFlowTxn(null)} />}
    </div>
  );
}
