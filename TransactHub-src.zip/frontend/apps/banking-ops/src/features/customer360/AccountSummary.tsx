import { useQuery } from '@tanstack/react-query';
import { Badge, EmptyState, LoadingSpinner } from '@paymenthub/ui';
import { customer360Api } from './api';
import type { CustomerAccount } from './types';

const STATUS_VARIANT: Record<CustomerAccount['status'], 'green' | 'amber' | 'red' | 'default'> = {
  ACTIVE: 'green',
  DORMANT: 'amber',
  FROZEN: 'red',
  CLOSED: 'default',
};

interface AccountSummaryProps {
  customerId: string;
}

export function AccountSummary({ customerId }: AccountSummaryProps) {
  const { data: accounts = [], isLoading, error } = useQuery({
    queryKey: ['customer360-accounts', customerId],
    queryFn: () => customer360Api.getAccounts(customerId).then((r) => r.data),
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return <p className="text-sm text-[var(--accent-red)]">Failed to load accounts.</p>;
  }

  if (accounts.length === 0) {
    return <EmptyState title="No accounts" message="This customer has no linked accounts." />;
  }

  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="border-b border-[var(--border)] bg-[var(--bg-secondary)]">
          {['Account', 'Type', 'Currency', 'Balance', 'Status'].map((h) => (
            <th
              key={h}
              className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-[var(--text-muted)]"
            >
              {h}
            </th>
          ))}
        </tr>
      </thead>
      <tbody className="divide-y divide-[var(--border-light)]">
        {accounts.map((acct) => (
          <tr key={acct.id} className="hover:bg-[var(--bg-card-hover)]">
            <td className="px-4 py-3 font-mono text-xs font-medium text-[var(--text-primary)]">
              {acct.accountNumber}
            </td>
            <td className="px-4 py-3 text-[var(--text-secondary)]">{acct.accountType}</td>
            <td className="px-4 py-3">
              <Badge variant="outline">{acct.currency}</Badge>
            </td>
            <td className="px-4 py-3 font-medium text-[var(--text-primary)]">
              {acct.balance.toLocaleString()}
            </td>
            <td className="px-4 py-3">
              <Badge variant={STATUS_VARIANT[acct.status]}>{acct.status}</Badge>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
