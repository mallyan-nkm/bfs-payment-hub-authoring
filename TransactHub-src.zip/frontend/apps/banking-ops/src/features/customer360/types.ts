export type CustomerTier = 'STANDARD' | 'PRIORITY' | 'PRIVATE' | 'CORPORATE';
export type CustomerStatus = 'ACTIVE' | 'DORMANT' | 'SUSPENDED' | 'CLOSED';
export type KycReviewStatus = 'VERIFIED' | 'PENDING_REVIEW' | 'EXPIRED' | 'REJECTED';
export type RiskBand = 'LOW' | 'MEDIUM' | 'HIGH';

export interface CustomerProfile {
  id: string;
  customerId: string;
  fullName: string;
  tier: CustomerTier;
  status: CustomerStatus;
  segment?: string;
  onboardedAt: string;
  tenantId: string;
  email?: string;
  phone?: string;
}

export interface KycDocumentCheck {
  id: string;
  documentType: string;
  status: 'VERIFIED' | 'MISSING' | 'EXPIRED' | 'PENDING';
  verifiedAt?: string;
}

export interface KycStatus {
  customerId: string;
  status: KycReviewStatus;
  lastReviewedAt?: string;
  nextReviewDue?: string;
  documents: KycDocumentCheck[];
}

export interface RiskScoreData {
  customerId: string;
  score: number;
  band: RiskBand;
  lastAssessedAt: string;
  factors?: string[];
}

export interface CustomerAccount {
  id: string;
  accountNumber: string;
  accountType: string;
  currency: string;
  balance: number;
  status: 'ACTIVE' | 'DORMANT' | 'FROZEN' | 'CLOSED';
}

export interface CustomerTransactionEvent {
  id: string;
  timestamp: string;
  description: string;
  amount: number;
  currency: string;
  status: string;
}
