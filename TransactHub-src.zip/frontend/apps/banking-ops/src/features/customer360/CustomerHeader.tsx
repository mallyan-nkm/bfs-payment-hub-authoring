import { Badge } from '@paymenthub/ui';
import type { CustomerProfile } from './types';

const TIER_VARIANT: Record<CustomerProfile['tier'], 'default' | 'purple' | 'blue' | 'cyan'> = {
  STANDARD: 'default',
  PRIORITY: 'blue',
  PRIVATE: 'purple',
  CORPORATE: 'cyan',
};

const STATUS_VARIANT: Record<CustomerProfile['status'], 'green' | 'amber' | 'red' | 'default'> = {
  ACTIVE: 'green',
  DORMANT: 'amber',
  SUSPENDED: 'red',
  CLOSED: 'default',
};

interface CustomerHeaderProps {
  customer: CustomerProfile;
}

export function CustomerHeader({ customer }: CustomerHeaderProps) {
  return (
    <div className="flex items-center justify-between border-b border-[var(--border)] pb-4">
      <div>
        <h1 className="text-lg font-semibold text-[var(--text-primary)]">{customer.fullName}</h1>
        <p className="text-sm text-[var(--text-muted)]">
          Customer ID {customer.customerId}
          {customer.segment ? ` · ${customer.segment}` : ''}
        </p>
      </div>
      <div className="flex items-center gap-2">
        <Badge variant={TIER_VARIANT[customer.tier]}>{customer.tier}</Badge>
        <Badge variant={STATUS_VARIANT[customer.status]}>{customer.status}</Badge>
      </div>
    </div>
  );
}
