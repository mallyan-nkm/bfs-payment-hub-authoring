import { bankingApi } from '../../shared/api/bankingApi';
import type {
  CustomerAccount,
  CustomerProfile,
  CustomerTransactionEvent,
  KycStatus,
  RiskScoreData,
} from './types';

export const customer360Api = {
  get: (id: string) => bankingApi.get<CustomerProfile>(`/customers/${id}`),

  getTransactionHistory: (id: string) =>
    bankingApi.get<CustomerTransactionEvent[]>(`/customers/${id}/transactions`),

  getKyc: (id: string) => bankingApi.get<KycStatus>(`/customers/${id}/kyc`),

  getRiskScore: (id: string) => bankingApi.get<RiskScoreData>(`/customers/${id}/risk-score`),

  getAccounts: (id: string) => bankingApi.get<CustomerAccount[]>(`/customers/${id}/accounts`),
};
