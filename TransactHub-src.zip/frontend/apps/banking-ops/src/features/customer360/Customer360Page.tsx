import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { EmptyState, LoadingSpinner, PageBody, PageHeader, PageShell, Tabs, TabsContent, TabsList, TabsTrigger } from '@paymenthub/ui';
import { customer360Api } from './api';
import { CustomerHeader } from './CustomerHeader';
import { AccountSummary } from './AccountSummary';
import { TransactionHistory } from './TransactionHistory';
import { KycWidget } from './KycWidget';
import { RiskScore } from './RiskScore';

export function Customer360Page() {
  const { id } = useParams<{ id: string }>();

  const { data: customer, isLoading, error } = useQuery({
    queryKey: ['customer360', id],
    queryFn: () => customer360Api.get(id!).then((r) => r.data),
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error || !customer) {
    return <EmptyState title="Customer not found" message="This customer profile could not be loaded." />;
  }

  return (
    <PageShell>
      <PageHeader title="Customer 360" />

      <PageBody className="flex flex-col gap-6">
      <CustomerHeader customer={customer} />

      <Tabs defaultValue="overview">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="kyc">KYC</TabsTrigger>
          <TabsTrigger value="risk">Risk</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <AccountSummary customerId={customer.id} />
        </TabsContent>

        <TabsContent value="transactions">
          <TransactionHistory customerId={customer.id} />
        </TabsContent>

        <TabsContent value="kyc">
          <KycWidget customerId={customer.id} />
        </TabsContent>

        <TabsContent value="risk">
          <RiskScore customerId={customer.id} />
        </TabsContent>
      </Tabs>
      </PageBody>
    </PageShell>
  );
}
