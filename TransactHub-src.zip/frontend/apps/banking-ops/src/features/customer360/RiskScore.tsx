import { useQuery } from '@tanstack/react-query';
import { Badge, LoadingSpinner, cn, useSessionDateTime } from '@paymenthub/ui';
import { customer360Api } from './api';
import type { RiskBand } from './types';

const BAND_VARIANT: Record<RiskBand, 'green' | 'amber' | 'red'> = {
  LOW: 'green',
  MEDIUM: 'amber',
  HIGH: 'red',
};

const BAND_BAR_COLOR: Record<RiskBand, string> = {
  LOW: 'bg-[var(--accent-green)]',
  MEDIUM: 'bg-[var(--accent-amber)]',
  HIGH: 'bg-[var(--accent-red)]',
};

interface RiskScoreProps {
  customerId: string;
}

export function RiskScore({ customerId }: RiskScoreProps) {
  const { formatInstant } = useSessionDateTime();
  const { data: risk, isLoading, error } = useQuery({
    queryKey: ['customer360-risk', customerId],
    queryFn: () => customer360Api.getRiskScore(customerId).then((r) => r.data),
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  if (error || !risk) {
    return <p className="text-sm text-[var(--accent-red)]">Failed to load risk score.</p>;
  }

  const pct = Math.max(0, Math.min(100, risk.score));

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-[var(--text-muted)]">Risk score</p>
          <p className="text-2xl font-semibold text-[var(--text-primary)]">{risk.score}</p>
        </div>
        <Badge variant={BAND_VARIANT[risk.band]}>{risk.band} RISK</Badge>
      </div>

      <div className="h-2 w-full overflow-hidden rounded-full bg-[var(--bg-secondary)]">
        <div
          className={cn('h-full rounded-full transition-all', BAND_BAR_COLOR[risk.band])}
          style={{ width: `${pct}%` }}
        />
      </div>

      <p className="text-xs text-[var(--text-muted)]">
        Last assessed {formatInstant(risk.lastAssessedAt)}
      </p>

      {risk.factors && risk.factors.length > 0 && (
        <div>
          <p className="mb-1.5 text-sm font-medium text-[var(--text-primary)]">Contributing factors</p>
          <ul className="flex flex-wrap gap-1.5">
            {risk.factors.map((factor) => (
              <li key={factor}>
                <Badge variant="outline">{factor}</Badge>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
