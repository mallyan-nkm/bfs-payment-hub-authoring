import { useQuery } from '@tanstack/react-query';
import { LoadingSpinner, Timeline } from '@paymenthub/ui';
import type { TimelineEvent } from '@paymenthub/ui';
import { customer360Api } from './api';

interface TransactionHistoryProps {
  customerId: string;
}

export function TransactionHistory({ customerId }: TransactionHistoryProps) {
  const { data: events = [], isLoading, error } = useQuery({
    queryKey: ['customer360-transactions', customerId],
    queryFn: () => customer360Api.getTransactionHistory(customerId).then((r) => r.data),
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return <p className="text-sm text-[var(--accent-red)]">Failed to load transaction history.</p>;
  }

  const timelineEvents: TimelineEvent[] = events.map((e) => ({
    id: e.id,
    timestamp: e.timestamp,
    title: e.description,
    description: `${e.amount.toLocaleString()} ${e.currency}`,
    variant: e.status === 'FAILED' ? 'danger' : e.status === 'COMPLETED' ? 'success' : 'default',
  }));

  return <Timeline events={timelineEvents} emptyMessage="No recent transactions for this customer." />;
}
