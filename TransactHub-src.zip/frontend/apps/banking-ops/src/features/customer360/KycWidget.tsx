import { useQuery } from '@tanstack/react-query';
import { Badge, EmptyState, LoadingSpinner, useSessionDateTime } from '@paymenthub/ui';
import { customer360Api } from './api';
import type { KycDocumentCheck } from './types';

const DOC_STATUS_VARIANT: Record<KycDocumentCheck['status'], 'green' | 'amber' | 'red' | 'default'> = {
  VERIFIED: 'green',
  PENDING: 'amber',
  EXPIRED: 'red',
  MISSING: 'red',
};

const KYC_STATUS_VARIANT: Record<string, 'green' | 'amber' | 'red' | 'default'> = {
  VERIFIED: 'green',
  PENDING_REVIEW: 'amber',
  EXPIRED: 'red',
  REJECTED: 'red',
};

interface KycWidgetProps {
  customerId: string;
}

export function KycWidget({ customerId }: KycWidgetProps) {
  const { formatCalendarDate } = useSessionDateTime();
  const { data: kyc, isLoading, error } = useQuery({
    queryKey: ['customer360-kyc', customerId],
    queryFn: () => customer360Api.getKyc(customerId).then((r) => r.data),
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  if (error || !kyc) {
    return <p className="text-sm text-[var(--accent-red)]">Failed to load KYC status.</p>;
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-[var(--text-muted)]">KYC Status</p>
          <Badge variant={KYC_STATUS_VARIANT[kyc.status] ?? 'default'}>{kyc.status}</Badge>
        </div>
        <div>
          <p className="text-xs text-[var(--text-muted)]">Last reviewed</p>
          <p className="text-sm text-[var(--text-secondary)]">
            {formatCalendarDate(kyc.lastReviewedAt)}
          </p>
        </div>
        <div>
          <p className="text-xs text-[var(--text-muted)]">Next review due</p>
          <p className="text-sm text-[var(--text-secondary)]">
            {formatCalendarDate(kyc.nextReviewDue)}
          </p>
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-[var(--text-primary)]">Document checklist</p>
        {kyc.documents.length === 0 ? (
          <EmptyState title="No documents" message="No KYC documents on file." />
        ) : (
          <ul className="flex flex-col gap-2">
            {kyc.documents.map((doc) => (
              <li
                key={doc.id}
                className="flex items-center justify-between rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2 text-sm"
              >
                <span className="text-[var(--text-secondary)]">{doc.documentType}</span>
                <div className="flex items-center gap-2">
                  {doc.verifiedAt && (
                    <span className="text-xs text-[var(--text-muted)]">
                      {formatCalendarDate(doc.verifiedAt)}
                    </span>
                  )}
                  <Badge variant={DOC_STATUS_VARIANT[doc.status]}>{doc.status}</Badge>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
