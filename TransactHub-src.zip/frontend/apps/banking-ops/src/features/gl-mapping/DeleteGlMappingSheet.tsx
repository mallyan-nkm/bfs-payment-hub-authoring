import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Can } from '@paymenthub/ui';
import { SideSheet } from '../../shared/components/SideSheet';
import { PERM } from '../../shared/auth/permissionKeys';
import { useDeleteGlMapping, useGlMappingDetail, useGlMappingWorkflow } from './api';
import { glErrorMessage, glFieldErrors } from './errors';
import type { GlFieldMap } from './errors';
import {
  AppliesImmediately,
  PANEL_WIDTH,
  PanelError,
  PanelFooter,
  RemarksField,
  SERVER_ERROR,
  fieldErrorText,
} from './formParts';
import { useGlMappingTranslation } from './i18n';
import { deleteGlMappingSchema } from './schemas';
import type { DeleteGlMappingForm } from './schemas';
import { GL_RULE_CODES } from './types';
import type { GlMappingRow } from './types';

const SERVER_FIELDS: GlFieldMap<keyof DeleteGlMappingForm> = {
  properties: { remarks: 'remarks' },
  rules: { [GL_RULE_CODES.remarksMandatory]: 'remarks' },
};

/**
 * Delete confirmation (FSD §5.5, design §7): a narrow right slide-in with the FSD's sentence and mandatory Remarks.
 * There is no active-transactions warning: nothing enforces one in v1.0 (BR-GL-003, GQ-5). The optimistic-concurrency
 * base comes from the mapping's detail, so Delete waits for it.
 */
export function DeleteGlMappingSheet({
  row,
  onClose,
  onDeleted,
}: {
  row: GlMappingRow;
  onClose: () => void;
  onDeleted: (message: string) => void;
}) {
  const { t } = useGlMappingTranslation();
  const [panelError, setPanelError] = useState<string | null>(null);
  const detail = useGlMappingDetail(row.mappingId);
  const workflow = useGlMappingWorkflow();
  const remove = useDeleteGlMapping();

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm<DeleteGlMappingForm>({
    resolver: zodResolver(deleteGlMappingSchema),
    defaultValues: { remarks: '' },
    shouldFocusError: true,
  });

  const confirm = handleSubmit(
    async ({ remarks }) => {
      if (!detail.data) return;
      setPanelError(null);
      try {
        await remove.mutateAsync({ mappingId: row.mappingId, baseTimelineId: detail.data.baseTimelineId, remarks });
        onDeleted(t('TOAST.DELETED', { rail: row.railCode, type: row.accountTypeName, currency: row.currency }));
      } catch (error) {
        const [first] = glFieldErrors(error, SERVER_FIELDS);
        if (first) setError(first.field, { type: SERVER_ERROR, message: first.message }, { shouldFocus: true });
        else setPanelError(glErrorMessage(error, t('ERROR.REQUEST_FAILED')));
      }
    },
    () => setPanelError(null),
  );

  return (
    <SideSheet
      eyebrow={t('DELETE.EYEBROW')}
      title={`${row.railCode} — ${row.accountTypeName} · ${row.accountNumber}`}
      subtitle={t('DELETE.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={
        <PanelFooter onCancel={onClose}>
          <Can permission={PERM.glMappingWrite}>
            <Button
              type="button"
              variant="danger"
              disabled={!detail.data || remove.isPending}
              onClick={() => void confirm()}
            >
              {remove.isPending ? t('DELETE.DELETING') : t('DELETE.DELETE')}
            </Button>
          </Can>
        </PanelFooter>
      }
    >
      <PanelError message={panelError ?? (detail.isError ? glErrorMessage(detail.error, t('ERROR.REQUEST_FAILED')) : null)} />
      <AppliesImmediately show={Boolean(workflow.data?.makerOnlyActions.includes('DeleteGlMapping'))} />
      <p className="mb-4 text-sm text-[var(--text-primary)]">{t('DELETE.CONFIRM')}</p>
      <RemarksField
        id="gl-delete-remarks"
        label={t('FORM.REMARKS')}
        accent="red"
        placeholder={t('DELETE.REMARKS_PLACEHOLDER')}
        hint={t('DELETE.AUDIT_HINT')}
        error={fieldErrorText(t, errors.remarks)}
        {...register('remarks')}
      />
    </SideSheet>
  );
}
