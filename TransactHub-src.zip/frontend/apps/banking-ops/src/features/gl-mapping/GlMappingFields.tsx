import { Controller, useWatch } from 'react-hook-form';
import type { Control, FieldErrors, UseFormRegister, UseFormSetValue } from 'react-hook-form';
import { Input, Select } from '@paymenthub/ui';
import { FormRow, fieldErrorText } from './formParts';
import { useGlMappingTranslation } from './i18n';
import { MAX_ACCOUNT_NUMBER } from './schemas';
import type { NewGlMappingForm } from './schemas';
import { PLATFORM_RAIL_CODE } from './types';
import type { GlMappingOptions } from './types';

/** The fields, top to bottom: the order focus goes to the first one in error (AC-GL-074). */
export const FIELD_ORDER = ['railCode', 'accountTypeCode', 'accountNumber', 'currency', 'remarks'] as const;

/** DOM ids by field, so a custom Select (which has no ref) can still take focus. */
export const FIELD_ID = {
  railCode: 'gl-rail',
  accountTypeCode: 'gl-account-type',
  accountNumber: 'gl-account-number',
  description: 'gl-description',
  currency: 'gl-currency',
  remarks: 'gl-remarks',
} as const;

/** Moves focus to the first field in error, in the order the panel shows them. */
export function focusFirstError(errors: FieldErrors<NewGlMappingForm>) {
  const first = FIELD_ORDER.find((f) => errors[f]);
  if (first) document.getElementById(FIELD_ID[first])?.focus();
}

/**
 * Rail, Account Name, Account Number, Description and Currency, shared by New and View & Modify (FSD §5.1.1, §5.3).
 * Currency lists only the chosen rail's currencies (Platform: the union) and is cleared when the Rail changes
 * (BR-GL-008). A Disabled rail is shown but cannot be chosen (GQ-9).
 */
export function GlMappingFields<T extends NewGlMappingForm>({
  control,
  register,
  setValue,
  errors,
  options,
  editable = true,
  fallbackAccountType,
}: {
  control: Control<T>;
  register: UseFormRegister<T>;
  setValue: UseFormSetValue<T>;
  errors: FieldErrors<NewGlMappingForm>;
  options: GlMappingOptions | undefined;
  editable?: boolean;
  /** The mapping's own account type, when it is no longer in the current list. */
  fallbackAccountType?: { code: string; name: string };
}) {
  const { t } = useGlMappingTranslation();
  // Typed against the New form: Modify's form is that plus Status.
  const c = control as unknown as Control<NewGlMappingForm>;
  const reg = register as unknown as UseFormRegister<NewGlMappingForm>;
  const set = setValue as unknown as UseFormSetValue<NewGlMappingForm>;
  const railCode = useWatch({ control: c, name: 'railCode' });

  const rails = options?.rails ?? [];
  const selected = rails.find((r) => r.railCode === railCode);
  const accountTypes = [...(options?.accountTypes ?? [])];
  if (fallbackAccountType && !accountTypes.some((a) => a.code === fallbackAccountType.code)) {
    accountTypes.push(fallbackAccountType);
  }

  return (
    <>
      <FormRow label={t('FORM.RAIL')} htmlFor={FIELD_ID.railCode} required>
        <Controller
          control={c}
          name="railCode"
          render={({ field }) => (
            <Select
              id={FIELD_ID.railCode}
              value={field.value || undefined}
              disabled={!editable}
              placeholder={t('FORM.RAIL_PLACEHOLDER')}
              onValueChange={(v) => {
                field.onChange(v);
                // The new rail may not support the chosen currency.
                set('currency', '');
              }}
              options={rails.map((r) => ({
                value: r.railCode,
                label: r.railCode === PLATFORM_RAIL_CODE ? r.railName : `${r.railCode} — ${r.railName}`,
                // Shown, not selectable, while the rail is not Active (GQ-9).
                disabled: r.status !== 'Active',
              }))}
              error={fieldErrorText(t, errors.railCode)}
              className="h-10 w-full text-xs"
            />
          )}
        />
      </FormRow>

      <FormRow label={t('FORM.ACCOUNT_NAME')} htmlFor={FIELD_ID.accountTypeCode} required>
        <Controller
          control={c}
          name="accountTypeCode"
          render={({ field }) => (
            <Select
              id={FIELD_ID.accountTypeCode}
              value={field.value || undefined}
              disabled={!editable}
              placeholder={t('FORM.ACCOUNT_NAME_PLACEHOLDER')}
              onValueChange={field.onChange}
              options={accountTypes.map((a) => ({ value: a.code, label: a.name }))}
              error={fieldErrorText(t, errors.accountTypeCode)}
              className="h-10 w-full text-xs"
            />
          )}
        />
      </FormRow>

      <FormRow label={t('FORM.ACCOUNT_NUMBER')} htmlFor={FIELD_ID.accountNumber} required>
        <Input
          id={FIELD_ID.accountNumber}
          placeholder={t('FORM.ACCOUNT_NUMBER_PLACEHOLDER')}
          maxLength={MAX_ACCOUNT_NUMBER}
          inputMode="numeric"
          autoComplete="off"
          readOnly={!editable}
          aria-required="true"
          error={fieldErrorText(t, errors.accountNumber)}
          className="h-10 w-full font-mono text-xs"
          {...reg('accountNumber')}
        />
      </FormRow>

      <FormRow label={t('FORM.DESCRIPTION')} htmlFor={FIELD_ID.description}>
        <Input
          id={FIELD_ID.description}
          placeholder={t('FORM.DESCRIPTION_PLACEHOLDER')}
          maxLength={500}
          autoComplete="off"
          readOnly={!editable}
          error={fieldErrorText(t, errors.description)}
          className="h-10 w-full text-xs"
          {...reg('description')}
        />
      </FormRow>

      <FormRow label={t('FORM.CURRENCY')} htmlFor={FIELD_ID.currency} required>
        <Controller
          control={c}
          name="currency"
          render={({ field }) => (
            <Select
              key={selected?.railCode ?? 'no-rail'}
              id={FIELD_ID.currency}
              value={field.value || undefined}
              disabled={!editable || !selected}
              placeholder={t('FORM.CURRENCY_PLACEHOLDER')}
              onValueChange={field.onChange}
              options={(selected?.currencies ?? []).map((cur) => ({ value: cur, label: cur }))}
              error={fieldErrorText(t, errors.currency)}
              className="h-10 w-full text-xs"
            />
          )}
        />
      </FormRow>
    </>
  );
}
