import { forwardRef } from 'react';
import type { ComponentPropsWithoutRef, ReactNode } from 'react';
import type { FieldError as RhfFieldError } from 'react-hook-form';
import { Button, Input, Textarea, cn } from '@paymenthub/ui';
import { Info } from 'lucide-react';
import { MAX_REMARKS } from './schemas';
import { useGlMappingTranslation } from './i18n';
import type { GlMappingT } from './i18n';

export { formatGridDateTime } from './format';

/** The panels' width, from the mockup's CSS: `.right-panel.open` is 360px, `.right-panel-xl.open` 640px. */
export const PANEL_WIDTH = 360;
export const PANEL_WIDTH_XL = 640;

/** The `type` a server refusal is set under, so its text is shown as sent rather than looked up as a key. */
export const SERVER_ERROR = 'server';

/** The text of a form field's error: a schema error carries a `GL_MAPPING` key; a server refusal its own message. */
export function fieldErrorText(t: GlMappingT, error: RhfFieldError | undefined): string | undefined {
  if (!error?.message) return undefined;
  return error.type === SERVER_ERROR ? error.message : t(error.message);
}

function RequiredMark() {
  return (
    <span className="text-[var(--accent-red)]" aria-hidden="true">
      *
    </span>
  );
}

/** A label above its control. */
export function FormRow({
  label,
  htmlFor,
  required,
  children,
}: {
  label: string;
  htmlFor: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={htmlFor} className="input-label text-sm font-semibold">
        {label} {required && <RequiredMark />}
      </label>
      <div className="min-w-0">{children}</div>
    </div>
  );
}

export function ReadOnlyInput({ id, value, mono }: { id: string; value: string; mono?: boolean }) {
  return (
    <Input
      id={id}
      value={value}
      readOnly
      className={cn(
        'h-10 w-full cursor-not-allowed bg-[var(--bg-secondary)] text-xs text-[var(--text-2)]',
        mono && 'font-mono',
      )}
    />
  );
}

type RemarksFieldProps = Omit<ComponentPropsWithoutRef<'textarea'>, 'id' | 'children'> & {
  id: string;
  label: string;
  accent: 'amber' | 'red';
  error?: string;
  hint?: string;
};

/** The panels' mandatory remarks box. The textarea's props are react-hook-form's `register(...)`. */
export const RemarksField = forwardRef<HTMLTextAreaElement, RemarksFieldProps>(function RemarksField(
  { id, label, accent, error, hint, ...textarea },
  ref,
) {
  const { t } = useGlMappingTranslation();
  return (
    <div>
      <label htmlFor={id} className="mb-2 flex items-center gap-2">
        <span
          className={cn('h-3.5 w-[3px] rounded', accent === 'red' ? 'bg-[var(--accent-red)]' : 'bg-[var(--accent-amber)]')}
          aria-hidden="true"
        />
        <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-primary)]">
          {label} <RequiredMark />
        </span>
      </label>
      <Textarea
        ref={ref}
        id={id}
        rows={4}
        maxLength={MAX_REMARKS}
        aria-required="true"
        error={error}
        className="input-cls w-full resize-y text-xs"
        {...textarea}
      />
      <p className="mt-1.5 flex items-center gap-1 text-[11px] text-[var(--text-muted)]">
        <Info size={12} aria-hidden="true" />
        {hint ?? t('FORM.AUDIT_HINT')}
      </p>
    </div>
  );
});

/** A server refusal that belongs to no single field, shown at the top of the panel. */
export function PanelError({ message }: { message: string | null }) {
  return message ? (
    <div
      role="alert"
      className="mb-4 rounded-lg border border-[var(--accent-red)]/40 bg-[var(--accent-red)]/10 px-3 py-2 text-xs text-[var(--accent-red)]"
    >
      {message}
    </div>
  ) : null;
}

/** The note a panel shows when its action applies at once (`makerOnlyActions`, AC-GL-079). */
export function AppliesImmediately({ show }: { show: boolean }) {
  const { t } = useGlMappingTranslation();
  return show ? (
    <p role="note" className="mb-4 flex gap-2 rounded-lg bg-[var(--bg-secondary)] px-3 py-2 text-xs text-[var(--text-2)]">
      <Info size={14} className="mt-0.5 shrink-0" aria-hidden="true" />
      {t('FORM.APPLIES_IMMEDIATELY')}
    </p>
  ) : null;
}

/** `Cancel` on the start side and the panel's actions on the end side (FSD §5.3 footer). */
export function PanelFooter({ onCancel, children }: { onCancel: () => void; children: ReactNode }) {
  const { t } = useGlMappingTranslation();
  return (
    <div className="flex w-full flex-wrap justify-between gap-3">
      <Button type="button" variant="secondary" onClick={onCancel}>
        {t('FORM.CANCEL')}
      </Button>
      <div className="flex flex-wrap justify-end gap-3">{children}</div>
    </div>
  );
}
