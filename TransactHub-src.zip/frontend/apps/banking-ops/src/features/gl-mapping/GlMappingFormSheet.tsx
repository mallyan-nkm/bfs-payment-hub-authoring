import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Can } from '@paymenthub/ui';
import { SideSheet } from '../../shared/components/SideSheet';
import { PERM } from '../../shared/auth/permissionKeys';
import { useCreateGlMapping, useGlMappingOptions, useGlMappingWorkflow } from './api';
import { glErrorMessage, glFieldErrors } from './errors';
import type { GlFieldMap } from './errors';
import { FIELD_ID, GlMappingFields, focusFirstError } from './GlMappingFields';
import {
  AppliesImmediately,
  PANEL_WIDTH,
  PanelError,
  PanelFooter,
  RemarksField,
  SERVER_ERROR,
  fieldErrorText,
} from './formParts';
import { useGlMappingTranslation } from './i18n';
import { newGlMappingSchema } from './schemas';
import type { NewGlMappingForm } from './schemas';
import { GL_RULE_CODES } from './types';

/**
 * Which field a server refusal is about (design §6.1): by the ValidationProblemDetails `errors` map, or by rule code
 * for a refusal the service raises. A taken Rail + Account Name + Currency is BR-GL-001.
 */
export const NEW_SERVER_FIELDS: GlFieldMap<keyof NewGlMappingForm> = {
  properties: {
    railCode: 'railCode',
    accountTypeCode: 'accountTypeCode',
    accountNumber: 'accountNumber',
    description: 'description',
    currency: 'currency',
    remarks: 'remarks',
  },
  rules: {
    [GL_RULE_CODES.duplicateKey]: 'accountTypeCode',
    [GL_RULE_CODES.railNotActive]: 'railCode',
    [GL_RULE_CODES.currencyNotSupported]: 'currency',
    [GL_RULE_CODES.accountNumberFormat]: 'accountNumber',
    [GL_RULE_CODES.remarksMandatory]: 'remarks',
  },
};

/**
 * New GL mapping (FSD §5.1, design §7): Rail, Account Name, Account Number, Description, Currency and Remarks; no
 * Status, a New is Active once applied. Uniqueness and the rail's currencies are the server's to judge.
 */
export function GlMappingFormSheet({ onClose, onSaved }: { onClose: () => void; onSaved: (message: string) => void }) {
  const { t } = useGlMappingTranslation();
  const [panelError, setPanelError] = useState<string | null>(null);
  const options = useGlMappingOptions();
  const workflow = useGlMappingWorkflow();
  const create = useCreateGlMapping();

  const {
    register,
    control,
    handleSubmit,
    setError,
    setValue,
    formState: { errors },
  } = useForm<NewGlMappingForm>({
    resolver: zodResolver(newGlMappingSchema),
    defaultValues: { railCode: '', accountTypeCode: '', accountNumber: '', description: '', currency: '', remarks: '' },
    shouldFocusError: false,
  });

  const submit = handleSubmit(
    async (values) => {
      setPanelError(null);
      try {
        await create.mutateAsync({ baseTimelineId: null, ...values });
        const type = options.data?.accountTypes.find((a) => a.code === values.accountTypeCode)?.name ?? values.accountTypeCode;
        onSaved(t('TOAST.CREATED', { rail: values.railCode, type, currency: values.currency }));
      } catch (error) {
        const fieldErrors = glFieldErrors(error, NEW_SERVER_FIELDS);
        if (fieldErrors.length === 0) {
          setPanelError(glErrorMessage(error, t('ERROR.REQUEST_FAILED')));
          return;
        }
        fieldErrors.forEach(({ field, message }, i) =>
          setError(field, { type: SERVER_ERROR, message }, { shouldFocus: i === 0 }),
        );
        document.getElementById(FIELD_ID[fieldErrors[0].field])?.focus();
      }
    },
    (invalid) => {
      setPanelError(null);
      focusFirstError(invalid);
    },
  );

  return (
    <SideSheet
      eyebrow={t('NEW.EYEBROW')}
      title={t('NEW.TITLE')}
      subtitle={t('NEW.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={
        <PanelFooter onCancel={onClose}>
          <Can permission={PERM.glMappingWrite}>
            <Button type="button" variant="primary" disabled={create.isPending} onClick={() => void submit()}>
              {create.isPending ? t('FORM.SAVING') : t('FORM.SAVE')}
            </Button>
          </Can>
        </PanelFooter>
      }
    >
      <form noValidate onSubmit={(e) => void submit(e)} className="flex flex-col gap-4">
        <PanelError message={panelError ?? (options.isError ? glErrorMessage(options.error, t('ERROR.OPTIONS_FAILED')) : null)} />
        <AppliesImmediately show={Boolean(workflow.data?.makerOnlyActions.includes('CreateGlMapping'))} />

        <GlMappingFields
          control={control}
          register={register}
          setValue={setValue}
          errors={errors}
          options={options.data}
        />

        <RemarksField
          id={FIELD_ID.remarks}
          label={t('FORM.REMARKS')}
          accent="amber"
          placeholder={t('NEW.REMARKS_PLACEHOLDER')}
          error={fieldErrorText(t, errors.remarks)}
          {...register('remarks')}
        />
        {/* Enter in a text field submits, as in any form. */}
        <Button type="submit" hidden aria-hidden="true" tabIndex={-1} unstyled />
      </form>
    </SideSheet>
  );
}
