import { Badge, cn } from '@paymenthub/ui';
import { lastActionLabel, statusLabel, useGlMappingTranslation } from './i18n';
import type { GlMappingLastAction, GlMappingStatus } from './types';

/** Modifier on the shared `.status-badge` (sass/_typography.scss); Disabled is grey (design §7), which it has none for. */
const STATUS_MODIFIER: Record<GlMappingStatus, string> = {
  Active: 'success',
  Disabled: '!bg-[var(--bg-3)] !text-[var(--text-2)]',
  Pending: 'warn',
  '-': '',
};

/** A mapping's status: Active green, Disabled grey, Pending amber, and a plain "-" for a rejected New (GQ-14). */
export function GlStatusBadge({ status }: { status: GlMappingStatus }) {
  const { t } = useGlMappingTranslation();
  if (status === '-') return <span className="text-[var(--text-muted)]">{statusLabel(t, status)}</span>;
  return <span className={cn('status-badge', STATUS_MODIFIER[status])}>{statusLabel(t, status)}</span>;
}

/** The rail code as the grid's monospace identifier, as the RAIL screen shows it. */
export function RailBadge({ code }: { code: string }) {
  return <span className="pq-refno-cell font-mono font-bold">{code}</span>;
}

/** Accepted reads green; Pending and Rejected both still need someone's attention, so amber. "—" for none. */
export function LastActionBadge({ lastAction }: { lastAction: GlMappingLastAction | null }) {
  const { t } = useGlMappingTranslation();
  const label = lastActionLabel(t, lastAction);
  if (!label) return <span className="text-[var(--text-muted)]">—</span>;
  return (
    <Badge variant={lastAction?.outcome === 'Accepted' ? 'green' : 'amber'} className="whitespace-nowrap">
      {label}
    </Badge>
  );
}
