import type { GlMappingAuditEntry } from './types';

/** The snapshot fields an audit card can show, in display order (`GlMappingSnapshot`). */
export type AuditField =
  | 'railCode'
  | 'accountTypeCode'
  | 'currency'
  | 'accountNumber'
  | 'description'
  | 'status'
  | 'isDeleted';

/** A snapshot value: text, a yes/no flag, or null for "none" (shown as "—"). */
export type AuditValue = string | boolean | null;

/** One "Field · Before → After" line on an audit card. */
export interface AuditFieldChange {
  field: AuditField;
  before: AuditValue;
  after: AuditValue;
}

const FIELDS: AuditField[] = [
  'railCode',
  'accountTypeCode',
  'currency',
  'accountNumber',
  'description',
  'status',
  'isDeleted',
];

/** Parses a snapshot, reading its keys case-insensitively (the writer uses PascalCase). */
function parse(json: string | null): Record<string, unknown> | null {
  if (!json) return null;
  try {
    const value: unknown = JSON.parse(json);
    if (!value || typeof value !== 'object') return null;
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([k, v]) => [k.toLowerCase(), v]));
  } catch {
    return null;
  }
}

function value(v: unknown): AuditValue {
  if (typeof v === 'boolean') return v;
  return v === null || v === undefined || v === '' ? null : String(v);
}

/**
 * The field changes a card shows, from `OldData` / `NewData`. A Created row has no before-snapshot, so every field
 * reads "none" → value; otherwise only the fields that differ are listed. A decision card has no snapshot change.
 */
export function auditFieldChanges(entry: GlMappingAuditEntry): AuditFieldChange[] {
  const before = parse(entry.oldData);
  const after = parse(entry.newData);
  if (!after) return [];

  if (!before) {
    return FIELDS.filter((f) => f !== 'isDeleted' && f.toLowerCase() in after).map((field) => ({
      field,
      before: null,
      after: value(after[field.toLowerCase()]),
    }));
  }

  return FIELDS.flatMap((field) => {
    const b = value(before[field.toLowerCase()]);
    const a = value(after[field.toLowerCase()]);
    return b === a ? [] : [{ field, before: b, after: a }];
  });
}

/** Which approval level a decision card records, and how many there are (AC-APQ-114). */
export interface AuditLevel {
  level: number;
  totalLevels: number;
}

const levelNumber = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

/** "Level k of N" for an Approval card whose `NewData` carries both numbers, or null (a card written before multi-level approval). */
export function auditLevel(entry: GlMappingAuditEntry): AuditLevel | null {
  if (entry.section !== 'Approval') return null;
  const data = parse(entry.newData);
  const level = levelNumber(data?.level);
  const totalLevels = levelNumber(data?.totallevels);
  return level !== null && totalLevels !== null ? { level, totalLevels } : null;
}
