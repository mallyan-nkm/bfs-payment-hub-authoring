import { GL_RULE_CODES } from './types';
import type { GlMappingProblemDetails } from './types';

/**
 * Reading a GL mapping refusal (design §6.1). A refusal is put on the field it is about by its `errors` map or its
 * rule code, never by matching its English text. The server's `detail` is shown as sent.
 */

/** The ProblemDetails body of a failed call, or null when the failure carried none (a network error, a 5xx page). */
export function glProblem(error: unknown): GlMappingProblemDetails | null {
  const data = (error as { response?: { data?: unknown } } | null)?.response?.data;
  if (!data || typeof data !== 'object') return null;
  return 'errorCode' in data || 'detail' in data || 'errors' in data ? (data as GlMappingProblemDetails) : null;
}

/** The rule a refusal enforces: `ruleCode`, else `errorCode` when that already is a rule code. */
export function glRuleCode(problem: GlMappingProblemDetails | null): string | null {
  if (!problem) return null;
  if (problem.ruleCode) return problem.ruleCode;
  const known: readonly string[] = Object.values(GL_RULE_CODES);
  return problem.errorCode && known.includes(problem.errorCode) ? problem.errorCode : null;
}

/** The message to show for a failed call: the server's `detail`, else the caller's (translated) fallback. */
export function glErrorMessage(error: unknown, fallback: string): string {
  return glProblem(error)?.detail || fallback;
}

export interface GlFieldMap<F extends string> {
  /** Server property name → form field (case-insensitive, last segment of a dotted path). */
  properties: Partial<Record<string, F>>;
  /** Rule code → form field, for a refusal with no `errors` map. */
  rules?: Partial<Record<string, F>>;
}

/** The field errors a refusal carries; empty when it is about no field of this form (show it at the panel top). */
export function glFieldErrors<F extends string>(error: unknown, map: GlFieldMap<F>): { field: F; message: string }[] {
  const problem = glProblem(error);
  if (!problem) return [];

  const properties = Object.fromEntries(
    Object.entries(map.properties).map(([name, field]) => [name.toLowerCase(), field]),
  ) as Partial<Record<string, F>>;

  const found: { field: F; message: string }[] = [];
  for (const [property, messages] of Object.entries(problem.errors ?? {})) {
    const field = properties[property.split('.').pop()?.toLowerCase() ?? ''];
    const message = Array.isArray(messages) ? messages.find((m) => Boolean(m)) : undefined;
    if (field && message && !found.some((f) => f.field === field)) found.push({ field, message });
  }
  if (found.length > 0) return found;

  const rule = glRuleCode(problem);
  const field = rule ? map.rules?.[rule] : undefined;
  return field && problem.detail ? [{ field, message: problem.detail }] : [];
}
