import { useTranslation } from 'react-i18next';
import type { GlMappingLastAction, GlMappingStatus } from './types';

/**
 * The GL mapping screen's copy: the `GL_MAPPING` block of the shared `@paymenthub/ui` translations (`i18n/en.json`,
 * `ar.json`), the same pattern as `DEPARTMENT.*` and `RAIL.*`. Keys below are relative to that block.
 */
export function useGlMappingTranslation() {
  return useTranslation('translation', { keyPrefix: 'GL_MAPPING' });
}

/** The prefixed `t`, for helpers that build copy outside a component. */
export type GlMappingT = ReturnType<typeof useGlMappingTranslation>['t'];

export const STATUS_KEY: Record<GlMappingStatus, string> = {
  Active: 'STATUS.ACTIVE',
  Disabled: 'STATUS.DISABLED',
  Pending: 'STATUS.PENDING',
  '-': 'STATUS.NONE',
};

/** The server's Last Action labels (`GlMappingReadService.LastAction`) and their copy. */
const ACTION_KEY: Record<string, string> = {
  'GL Mapping Created': 'LAST_ACTION.CREATED',
  'Modify GL Mapping': 'LAST_ACTION.MODIFY',
  'Delete GL Mapping': 'LAST_ACTION.DELETE',
  'GL Mapping Closed': 'LAST_ACTION.CLOSED',
};

const OUTCOME_KEY: Record<string, string> = {
  Accepted: 'LAST_ACTION.ACCEPTED',
  Rejected: 'LAST_ACTION.REJECTED',
};

/** The grid's Last Action filter: the server's full labels, which is what `LastActions` matches (design §5.1). */
export const LAST_ACTION_FILTER_VALUES = [
  'GL Mapping Created',
  'GL Mapping Created - Accepted',
  'GL Mapping Created - Rejected',
  'Modify GL Mapping',
  'Modify GL Mapping - Accepted',
  'Modify GL Mapping - Rejected',
  'Delete GL Mapping',
  'Delete GL Mapping - Rejected',
] as const;

/** The grid's Last Action filter value for a row's action, matching `LAST_ACTION_FILTER_VALUES`. */
function splitFilterValue(value: string): GlMappingLastAction {
  const [action, outcome = ''] = value.split(' - ');
  return { action, outcome: outcome as GlMappingLastAction['outcome'] };
}

/** A status in the reader's language. */
export function statusLabel(t: GlMappingT, status: GlMappingStatus): string {
  return t(STATUS_KEY[status]);
}

/** "<Action> - <Accepted|Rejected>", the action alone while Pending (GQ-18); null when there is no request. */
export function lastActionLabel(t: GlMappingT, lastAction: GlMappingLastAction | null): string | null {
  if (!lastAction) return null;
  const action = ACTION_KEY[lastAction.action] ? t(ACTION_KEY[lastAction.action]) : lastAction.action;
  const outcomeKey = OUTCOME_KEY[lastAction.outcome];
  return outcomeKey ? t('LAST_ACTION.LABEL', { action, outcome: t(outcomeKey) }) : action;
}

/** The copy of one Last Action filter value. */
export function lastActionFilterLabel(t: GlMappingT, value: string): string {
  return lastActionLabel(t, splitFilterValue(value)) ?? value;
}

/** The Audit Trail's Section labels; the value sent to the server stays the stored `AdminAudit.Section`. */
export const SECTION_KEY: Record<string, string> = {
  'Account Update': 'AUDIT.SECTIONS.ACCOUNT_UPDATE',
  'Status Change': 'AUDIT.SECTIONS.STATUS_CHANGE',
  'GL Created': 'AUDIT.SECTIONS.GL_CREATED',
  Approval: 'AUDIT.SECTIONS.APPROVAL',
};
