import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Can, PageBody, PageShell, SmartGrid, parseMultiFilter, usePermissions } from '@paymenthub/ui';
import type { SmartGridQueryChange } from '@paymenthub/ui';
import { Plus } from 'lucide-react';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { PERM } from '../../shared/auth/permissionKeys';
import { glMappingApi, useGlMappingList, useGlMappingOptions } from './api';
import { GL_FILTER, buildColumns } from './columns';
import type { GlMappingGridView } from './columns';
import { DeleteGlMappingSheet } from './DeleteGlMappingSheet';
import { GlMappingAuditTrailModal } from './GlMappingAuditTrailModal';
import { GlMappingFormSheet } from './GlMappingFormSheet';
import { GlMappingModifySheet } from './GlMappingModifySheet';
import { useGlMappingTranslation } from './i18n';
import type { GlMappingExportFormat, GlMappingListParams, GlMappingRow, GlMappingSortBy } from './types';

const DEFAULT_PAGE_SIZE = 20;

type Sheet =
  | { kind: 'create' }
  | { kind: 'modify'; row: GlMappingRow }
  | { kind: 'audit'; row: GlMappingRow }
  | { kind: 'delete'; row: GlMappingRow };

interface GridQuery {
  page: number;
  pageSize: number;
  sortBy: string | null;
  sortDir: 'asc' | 'desc';
  filters: Record<string, string>;
}

const EMPTY_QUERY: GridQuery = { page: 1, pageSize: DEFAULT_PAGE_SIZE, sortBy: null, sortDir: 'asc', filters: {} };

/** The grid's flat filter record as the list endpoint's parameters: multi-selects become repeated keys. */
function filtersToParams(f: Record<string, string>): Partial<GlMappingListParams> {
  const text = (key: string) => f[key]?.trim() || undefined;
  const many = (key: string) => {
    const values = parseMultiFilter(f[key]);
    return values.length ? values : undefined;
  };
  return {
    railCodes: many(GL_FILTER.Rail),
    accountTypeCodes: many(GL_FILTER.AccountType),
    currencies: many(GL_FILTER.Currency),
    statuses: many(GL_FILTER.Status),
    lastActions: many(GL_FILTER.LastAction),
    accountNumber: text(GL_FILTER.AccountNumber),
    description: text(GL_FILTER.Description),
    createdBy: text(GL_FILTER.CreatedBy),
    lastModifiedBy: text(GL_FILTER.LastModifiedBy),
    createdFrom: text(`${GL_FILTER.Created}From`),
    createdTo: text(`${GL_FILTER.Created}To`),
    lastModifiedFrom: text(`${GL_FILTER.LastModified}From`),
    lastModifiedTo: text(`${GL_FILTER.LastModified}To`),
  };
}

/**
 * GL Account Mapping (Administration → Platform): map GL accounts to payment rails (GL Account design §7).
 *
 * The grid runs in server mode: column filters, sort and paging all go to `glMappingList`, and export asks the server
 * for the whole filtered set. The tenant and the acting user come from the session.
 */
export function GlMappingPage() {
  const navigate = useNavigate();
  const { t, i18n } = useGlMappingTranslation();
  const { can } = usePermissions();
  // The export routes need `ops:report:export` on top of the page key (design §8.2).
  const canExport = can(PERM.opsReportExport);

  const [query, setQuery] = useState<GridQuery>(EMPTY_QUERY);
  const [sheet, setSheet] = useState<Sheet | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);

  const listParams: GlMappingListParams = useMemo(
    () => ({
      ...filtersToParams(query.filters),
      sortBy: (query.sortBy as GlMappingSortBy | null) ?? undefined,
      sortDirection: query.sortBy ? query.sortDir : undefined,
      pageSize: query.pageSize,
      pageNumber: query.page,
    }),
    [query],
  );

  const listQuery = useGlMappingList(listParams);
  const options = useGlMappingOptions().data;
  const rows = listQuery.data?.items ?? [];
  const totalRecords = listQuery.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalRecords / query.pageSize));

  // A delete or a narrower filter can leave the operator past the last page; server mode trusts the caller to clamp.
  useEffect(() => {
    if (query.page > totalPages) setQuery((q) => ({ ...q, page: totalPages }));
  }, [query.page, totalPages]);

  const gridView = useRef<GlMappingGridView>({
    rows,
    page: query.page,
    pageSize: query.pageSize,
    onViewModify: (row) => setSheet({ kind: 'modify', row }),
    onAuditTrail: (row) => setSheet({ kind: 'audit', row }),
    onDelete: (row) => setSheet({ kind: 'delete', row }),
  });
  gridView.current.rows = rows;
  gridView.current.page = query.page;
  gridView.current.pageSize = query.pageSize;

  // SmartGrid never re-reads column definitions, so they are rebuilt, and the grid remounted, when the language or the
  // filter options change; the closures read rows and handlers through the ref.
  const columns = useMemo(() => buildColumns(gridView, t, options), [t, options]);

  // Stable, so SideSheet's focus/Escape effect doesn't re-run on every page render.
  const closeSheet = useCallback(() => setSheet(null), []);

  function handleQueryChange(change: SmartGridQueryChange) {
    setQuery((prev) => ({
      ...prev,
      page: change.page ?? prev.page,
      pageSize: change.pageSize ?? prev.pageSize,
      sortBy: change.sortBy !== undefined ? change.sortBy : prev.sortBy,
      sortDir: change.sortDir ?? prev.sortDir,
      filters: change.filters ?? prev.filters,
    }));
  }

  /** The server renders the whole filtered set, with only the columns the operator has visible. */
  const handleExport = (format: GlMappingExportFormat, visibleColumnKeys: string[]) =>
    glMappingApi.export(
      format,
      listParams,
      visibleColumnKeys.filter((k) => k !== 'slNo' && k !== 'actions'),
    );

  function completed(message: string) {
    setToast({ tone: 'success', message });
    closeSheet();
  }

  return (
    <PageShell>
      <PageBody>
        <div className="pq-page pe-2">
          {/* Breadcrumb: Payment Hub Operations Console › Administration › GL Account */}
          <nav aria-label={t('PAGE.BREADCRUMB_LABEL')}>
            <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
              <Button type="button" unstyled onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">
                {t('PAGE.BREADCRUMB_ROOT')}
              </Button>
              {' › '}
              <span>{t('PAGE.BREADCRUMB_PARENT')}</span>
              {' › '}
              <span aria-current="page">{t('PAGE.BREADCRUMB')}</span>
            </p>
          </nav>

          <div className="pq-header">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                {t('PAGE.TITLE')}
              </h1>
              <p className="pq-header-subtitle">{t('PAGE.SUBTITLE')}</p>
            </div>
            <div className="pq-header-meta">
              {/* What a denial looks like is the render policy's to decide, not this screen's (RBAC §13). */}
              <Can permission={PERM.glMappingWrite}>
                <Button
                  type="button"
                  variant="primary"
                  onClick={() => setSheet({ kind: 'create' })}
                  icon={<Plus size={14} aria-hidden="true" />}
                >
                  {t('PAGE.NEW')}
                </Button>
              </Can>
            </div>
          </div>

          {listQuery.isError ? (
            <div role="alert" className="flex flex-col items-center gap-3 p-10 text-center text-sm text-[var(--text-2)]">
              <p>{t('PAGE.LOAD_FAILED')}</p>
              <Button type="button" variant="outline" size="sm" onClick={() => void listQuery.refetch()}>
                {t('PAGE.RETRY')}
              </Button>
            </div>
          ) : (
            <SmartGrid<GlMappingRow>
              key={`${i18n.language}-${options ? 'ready' : 'loading'}`}
              columns={columns}
              rows={rows}
              getRowId={(r) => String(r.mappingId)}
              storageKey="gl-mapping-columns-v1"
              loading={listQuery.isFetching}
              emptyTitle={t('PAGE.EMPTY_TITLE')}
              emptyMessage={t('PAGE.EMPTY_MESSAGE')}
              exportFilename="gl-mappings"
              onExport={canExport ? handleExport : undefined}
              exportFormats={canExport ? ['csv', 'excel', 'pdf'] : []}
              server={{
                page: query.page,
                pageSize: query.pageSize,
                total: totalRecords,
                sortBy: query.sortBy,
                sortDir: query.sortDir,
                onQueryChange: handleQueryChange,
              }}
            />
          )}
        </div>
      </PageBody>

      {sheet?.kind === 'create' && <GlMappingFormSheet onClose={closeSheet} onSaved={completed} />}
      {sheet?.kind === 'modify' && (
        <GlMappingModifySheet mappingId={sheet.row.mappingId} onClose={closeSheet} onCompleted={completed} />
      )}
      {sheet?.kind === 'audit' && <GlMappingAuditTrailModal row={sheet.row} onClose={closeSheet} />}
      {sheet?.kind === 'delete' && <DeleteGlMappingSheet row={sheet.row} onClose={closeSheet} onDeleted={completed} />}

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}
