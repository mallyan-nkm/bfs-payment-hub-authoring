/**
 * GL mapping screen dates (design §7, X-6; UTC date-time design §6.7, task T-23). The API sends UTC instants; they
 * are shown in the **session zone**, `dd-MM-yyyy HH:mm:ss`, through the `@paymenthub/ui` date-time module. Thin
 * delegates kept for their callers; a component formats through `useSessionDateTime()` instead.
 */
import { sessionInstant } from '@paymenthub/ui';

/** `2026-09-28T14:15:30Z` → `28-09-2026 18:15:30` in Dubai; "—" when absent or unreadable. */
export function formatGridDateTime(iso: string | null | undefined): string {
  return sessionInstant(iso);
}

/** The Audit Trail's date and time: the same session-zone `dd-MM-yyyy HH:mm:ss`. */
export function formatAuditDateTime(iso: string | null | undefined): string {
  return sessionInstant(iso);
}
