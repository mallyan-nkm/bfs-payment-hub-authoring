import type { RefObject } from 'react';
import { Button, Can } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { GlStatusBadge, LastActionBadge, RailBadge } from './badges';
import { LAST_ACTION_FILTER_VALUES, lastActionFilterLabel, lastActionLabel, statusLabel } from './i18n';
import type { GlMappingT } from './i18n';
import type { GlMappingOptions, GlMappingRow, GlMappingStatus } from './types';

/**
 * Handlers, the live page and the filter options, behind a ref. SmartGrid snapshots column definitions on first mount
 * and never re-reads them, so the render closures must read through a ref.
 */
export interface GlMappingGridView {
  rows: GlMappingRow[];
  page: number;
  pageSize: number;
  onViewModify: (row: GlMappingRow) => void;
  onAuditTrail: (row: GlMappingRow) => void;
  onDelete: (row: GlMappingRow) => void;
}

/** Grid filter keys. The date ranges' `…From` / `…To` pair is what the list endpoint binds. */
export const GL_FILTER = {
  Rail: 'rail',
  AccountType: 'accountType',
  AccountNumber: 'accountNumber',
  Description: 'description',
  Currency: 'currency',
  Status: 'status',
  Created: 'created',
  CreatedBy: 'createdBy',
  LastModified: 'lastModified',
  LastModifiedBy: 'lastModifiedBy',
  LastAction: 'lastAction',
} as const;

const STATUS_FILTERS: GlMappingStatus[] = ['Active', 'Disabled', 'Pending', '-'];

/** What the options endpoint gives the filters; empty until it loads (a filter then offers nothing, not wrong values). */
export function filterChoices(options: GlMappingOptions | undefined) {
  return {
    rails: options?.rails.map((r) => ({ value: r.railCode, label: r.railCode })) ?? [],
    accountTypes: options?.accountTypes.map((a) => ({ value: a.code, label: a.name })) ?? [],
    currencies: [...new Set(options?.rails.flatMap((r) => r.currencies) ?? [])].sort().map((c) => ({ value: c, label: c })),
  };
}

/**
 * The 13 columns in the FSD's order (GQ-20), with Actions last as in the mockup: Sl, Rail, Account Name, Account Number,
 * Description, Currency, Status, Created Date, Created By, Last Modified, Last Modified By, Last Action, Actions. Column keys double as the export's
 * column keys (`GlMappingExportMapper`); `sortKey` is the backend's sort whitelist (`GlMappingListSort`).
 */
export function buildColumns(
  view: RefObject<GlMappingGridView>,
  t: GlMappingT,
  options: GlMappingOptions | undefined,
): SmartGridColumn<GlMappingRow>[] {
  const choices = filterChoices(options);
  return [
    {
      key: 'slNo',
      label: t('COLUMNS.SL'),
      locked: true,
      numeric: true,
      render: (r) => {
        const { rows, page, pageSize } = view.current;
        const index = rows.indexOf(r);
        return index < 0 ? '—' : (page - 1) * pageSize + index + 1;
      },
    },
    {
      key: 'rail',
      label: t('COLUMNS.RAIL'),
      filterKey: GL_FILTER.Rail,
      filterType: 'multiSelect',
      filterOptions: choices.rails,
      sortKey: 'Rail',
      getValue: (r) => r.railCode,
      render: (r) => <RailBadge code={r.railCode} />,
    },
    {
      key: 'accountType',
      label: t('COLUMNS.ACCOUNT_NAME'),
      filterKey: GL_FILTER.AccountType,
      filterType: 'multiSelect',
      filterOptions: choices.accountTypes,
      sortKey: 'AccountType',
      getValue: (r) => r.accountTypeName,
      // FSD §5.2.2 row 3: the mapping's Description shows under the account name as a sub-label.
      render: (r) => (
        <div>
          <div>{r.accountTypeName}</div>
          {r.description ? <div className="text-xs text-[var(--text-muted)]">{r.description}</div> : null}
        </div>
      ),
    },
    {
      key: 'accountNumber',
      label: t('COLUMNS.ACCOUNT_NUMBER'),
      filterKey: GL_FILTER.AccountNumber,
      sortKey: 'AccountNumber',
      getValue: (r) => r.accountNumber,
      render: (r) => <span className="pq-refno-cell font-mono font-bold">{r.accountNumber}</span>,
    },
    {
      key: 'description',
      label: t('COLUMNS.DESCRIPTION'),
      filterKey: GL_FILTER.Description,
      sortKey: 'Description',
      wrap: true,
      maxWidth: 260,
      getValue: (r) => r.description || '—',
    },
    {
      key: 'currency',
      label: t('COLUMNS.CURRENCY'),
      filterKey: GL_FILTER.Currency,
      filterType: 'multiSelect',
      filterOptions: choices.currencies,
      sortKey: 'Currency',
      getValue: (r) => r.currency,
    },
    {
      key: 'status',
      label: t('COLUMNS.STATUS'),
      filterKey: GL_FILTER.Status,
      filterType: 'multiSelect',
      filterOptions: STATUS_FILTERS.map((s) => ({ value: s, label: statusLabel(t, s) })),
      sortKey: 'Status',
      getValue: (r) => statusLabel(t, r.status),
      render: (r) => <GlStatusBadge status={r.status} />,
    },
    {
      key: 'createdAt',
      label: t('COLUMNS.CREATED'),
      filterKey: GL_FILTER.Created,
      filterType: 'dateRange',
      sortKey: 'CreatedAt',
      kind: 'instant',
    },
    {
      key: 'createdBy',
      label: t('COLUMNS.CREATED_BY'),
      filterKey: GL_FILTER.CreatedBy,
      sortKey: 'CreatedBy',
      getValue: (r) => r.createdBy,
    },
    {
      key: 'lastModifiedAt',
      label: t('COLUMNS.LAST_MODIFIED'),
      filterKey: GL_FILTER.LastModified,
      filterType: 'dateRange',
      sortKey: 'LastModifiedAt',
      kind: 'instant',
    },
    {
      key: 'lastModifiedBy',
      label: t('COLUMNS.LAST_MODIFIED_BY'),
      filterKey: GL_FILTER.LastModifiedBy,
      sortKey: 'LastModifiedBy',
      getValue: (r) => r.lastModifiedBy ?? '—',
    },
    {
      key: 'lastAction',
      label: t('COLUMNS.LAST_ACTION'),
      filterKey: GL_FILTER.LastAction,
      filterType: 'multiSelect',
      filterOptions: LAST_ACTION_FILTER_VALUES.map((v) => ({ value: v, label: lastActionFilterLabel(t, v) })),
      sortKey: 'LastAction',
      getValue: (r) => lastActionLabel(t, r.lastAction) ?? '—',
      render: (r) => <LastActionBadge lastAction={r.lastAction} />,
    },
    {
      key: 'actions',
      label: t('COLUMNS.ACTIONS'),
      locked: true,
      render: (r) => (
        <div className="pq-row-actions">
          {/* A pending request locks the mapping (BR-GL-009): View & Modify and Delete wait, Audit never does. */}
          <Button
            type="button"
            variant="secondary"
            size="sm"
            disabled={!r.canModify && !r.canResubmit && !r.canClose}
            title={r.isPending ? t('BLOCKED.PENDING') : undefined}
            onClick={(e) => {
              e.stopPropagation();
              view.current.onViewModify(r);
            }}
            aria-label={t('ROW.VIEW_MODIFY_LABEL', { name: `${r.railCode} ${r.accountNumber}` })}
          >
            {t('ROW.VIEW_MODIFY')}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              view.current.onAuditTrail(r);
            }}
            aria-label={t('ROW.AUDIT_LABEL', { name: `${r.railCode} ${r.accountNumber}` })}
          >
            {t('ROW.AUDIT')}
          </Button>
          {/* What a denial looks like is the render policy's to decide, not this screen's (RBAC §13). */}
          <Can permission={PERM.glMappingWrite}>
            <Button
              type="button"
              variant="danger"
              size="sm"
              disabled={!r.canDelete}
              title={r.isPending ? t('BLOCKED.PENDING') : !r.canDelete ? t('BLOCKED.REJECTED_NEW') : undefined}
              onClick={(e) => {
                e.stopPropagation();
                view.current.onDelete(r);
              }}
              aria-label={t('ROW.DELETE_LABEL', { name: `${r.railCode} ${r.accountNumber}` })}
            >
              {t('ROW.DELETE')}
            </Button>
          </Can>
        </div>
      ),
    },
  ];
}
