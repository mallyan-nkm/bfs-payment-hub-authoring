/**
 * GL Account mapping contracts, mirroring `GlMappingDtos.cs` and `GlMappingHistoryDtos.cs` (GL Account design §5).
 * Dates are UTC ISO strings; the UI formats them.
 */

/** The stored statuses; `-` is a New that was rejected and never applied, so it has none (design §4.1). */
export type GlMappingStatus = 'Active' | 'Disabled' | 'Pending' | '-';

/** The statuses a Maker can choose on View & Modify. */
export const EDITABLE_STATUSES = ['Active', 'Disabled'] as const;

/** The platform-wide pseudo rail (Currency lists the union of every rail's). */
export const PLATFORM_RAIL_CODE = 'PLATFORM';

export type GlMappingRequestAction = 'CreateGlMapping' | 'ModifyGlMapping' | 'DeleteGlMapping' | 'CloseGlMapping';
export type GlMappingRequestStatus = 'Pending' | 'Applied' | 'Rejected';

/** The Last Action as the server labels it: `action` is one of `LAST_ACTIONS`, `outcome` is empty for Pending. */
export interface GlMappingLastAction {
  action: string;
  outcome: 'Pending' | 'Accepted' | 'Rejected' | '';
}

export interface GlMappingRow {
  sl: number;
  mappingId: number;
  railCode: string;
  railName: string;
  accountTypeCode: string;
  accountTypeName: string;
  accountNumber: string;
  description: string | null;
  currency: string;
  status: GlMappingStatus;
  isPending: boolean;
  createdAt: string;
  createdBy: string;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  lastAction: GlMappingLastAction | null;
  canModify: boolean;
  canDelete: boolean;
  canResubmit: boolean;
  canClose: boolean;
}

export interface GlMappingListResponse {
  items: GlMappingRow[];
  pageNumber: number;
  pageSize: number;
  totalRecords: number;
  totalPages?: number;
}

export type GlMappingSortBy =
  | 'Rail'
  | 'AccountType'
  | 'Currency'
  | 'AccountNumber'
  | 'Description'
  | 'Status'
  | 'CreatedAt'
  | 'CreatedBy'
  | 'LastModifiedAt'
  | 'LastModifiedBy'
  | 'LastAction';

/** The grid's filters and sort; arrays go as repeated keys. */
export interface GlMappingListParams {
  railCodes?: string[];
  accountTypeCodes?: string[];
  currencies?: string[];
  statuses?: string[];
  lastActions?: string[];
  accountNumber?: string;
  description?: string;
  createdBy?: string;
  lastModifiedBy?: string;
  createdFrom?: string;
  createdTo?: string;
  lastModifiedFrom?: string;
  lastModifiedTo?: string;
  sortBy?: GlMappingSortBy;
  sortDirection?: 'asc' | 'desc';
  pageSize: number;
  pageNumber: number;
}

export interface GlMappingRequestSummary {
  requestId: number;
  action: GlMappingRequestAction;
  status: GlMappingRequestStatus;
  makerBy: string;
  makerAt: string;
  makerRemarks: string;
  checkerBy: string | null;
  checkerAt: string | null;
  checkerRemarks: string | null;
}

export interface GlMappingDetail {
  mappingId: number;
  baseTimelineId: number | null;
  railCode: string;
  railName: string;
  accountTypeCode: string;
  accountTypeName: string;
  currency: string;
  accountNumber: string;
  description: string | null;
  status: GlMappingStatus;
  isPending: boolean;
  createdAt: string;
  createdBy: string;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  latestRequest: GlMappingRequestSummary | null;
  canModify: boolean;
  canDelete: boolean;
  canResubmit: boolean;
  canClose: boolean;
  /** The signed-in user is the Maker of the latest request (Admin Approval Queue §10.5). */
  callerIsMaker: boolean;
  /** The Maker is no longer eligible and the caller may Close the rejected New in their place (R-3). */
  canFallbackClose: boolean;
}

export interface GlMappingRailOption {
  railCode: string;
  railName: string;
  /** Stored state: only an Active rail can be chosen (GQ-9). */
  status: 'Active' | 'Disabled';
  currencies: string[];
}

export interface GlMappingAccountTypeOption {
  code: string;
  name: string;
}

export interface GlMappingOptions {
  rails: GlMappingRailOption[];
  accountTypes: GlMappingAccountTypeOption[];
}

export interface GlMappingWorkflow {
  makerOnlyActions: string[];
  checkerPermission: string;
}

/** Body of `glMappingSave` (New), `glMappingSave/{id}` (Modify) and `glMappingResubmit/{id}`. */
export interface SaveGlMappingRequest {
  baseTimelineId: number | null;
  railCode: string;
  accountTypeCode: string;
  currency: string;
  accountNumber: string;
  description: string;
  /** Modify only; a New is always Active on apply. */
  status?: 'Active' | 'Disabled';
  remarks: string;
  /** Resubmit only: the rejected request being repaired; the server refuses a stale one. */
  resubmissionOf?: number;
}

export interface GlMappingSavedResponse {
  mappingId: number;
  requestId: number;
  auditId: number;
  applied: boolean;
  createdAt: string;
}

/** The workflow action a panel performs, as named in `makerOnlyActions` (`GlMapping:MakerOnlyActions`). */
export type GlMappingWorkflowAction = Exclude<GlMappingRequestAction, 'CloseGlMapping'>;

export const AUDIT_SECTIONS = ['Account Update', 'Status Change', 'GL Created'] as const;
export type GlAuditSection = (typeof AUDIT_SECTIONS)[number] | 'Approval';

export interface GlMappingAuditParams {
  section?: string;
  fromDate?: string;
  toDate?: string;
  pageSize: number;
  pageNumber: number;
}

export interface GlMappingAuditEntry {
  sequenceNo: number;
  auditId: number;
  requestId: number | null;
  action: string;
  section: GlAuditSection | (string & {});
  userId: string;
  userName: string | null;
  userRole: string;
  remarks: string;
  changedFields: string | null;
  oldData: string | null;
  newData: string;
  actionDate: string;
}

export interface GlMappingAuditResponse {
  mappingId: number;
  items: GlMappingAuditEntry[];
  pageNumber: number;
  pageSize: number;
  totalRecords: number;
}

export type GlMappingExportFormat = 'csv' | 'excel' | 'pdf';

/** `ruleCode` of a refusal (`GlMappingRuleCodes`). */
export const GL_RULE_CODES = {
  duplicateKey: 'BR-GL-001',
  remarksMandatory: 'BR-GL-004',
  currencyNotSupported: 'BR-GL-008',
  onePendingRequest: 'BR-GL-009',
  railNotActive: 'GQ-9',
  accountNumberFormat: 'GQ-11',
  rejectedNewOnly: 'GQ-8',
  changedConcurrently: 'GL-CONCURRENCY',
  accountTypesUnavailable: 'E-16',
} as const;

/** RFC 7807 body of every refusal (design §5): `detail` is user-facing; `errors` is set by FluentValidation. */
export interface GlMappingProblemDetails {
  type?: string;
  title?: string;
  status?: number;
  detail?: string;
  errorCode?: string;
  ruleCode?: string;
  traceId?: string;
  requestId?: number | null;
  action?: string | null;
  makerBy?: string | null;
  errors?: Record<string, string[]>;
}
