import { screen } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiOk, grant, renderWithProviders } from '../../../test/renderWithProviders';
import { GlMappingModifySheet } from './GlMappingModifySheet';
import type { GlMappingDetail } from './types';

// The route guard's session check reads storage; a signed-in session is all this case needs.
vi.mock('@paymenthub/ui', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@paymenthub/ui')>()),
  getCurrentUserFromStorage: () => ({ id: 'u1' }),
}));
vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

/** A rejected New the signed-in user made: the panel offers Resubmit and Close (Admin Approval Queue §10.2, §10.5). */
const REJECTED_NEW: GlMappingDetail = {
  mappingId: 8,
  baseTimelineId: null,
  railCode: 'IPI',
  railName: 'Instant Payments',
  accountTypeCode: '1001',
  accountTypeName: 'Nostro',
  currency: 'AED',
  accountNumber: '555',
  description: null,
  status: '-',
  isPending: false,
  createdAt: '2026-09-28T14:15:30Z',
  createdBy: 'maker1',
  lastModifiedAt: null,
  lastModifiedBy: null,
  latestRequest: {
    requestId: 3,
    action: 'CreateGlMapping',
    status: 'Rejected',
    makerBy: 'maker1',
    makerAt: '2026-10-01T00:00:00Z',
    makerRemarks: 'New account',
    checkerBy: 'checker1',
    checkerAt: '2026-10-02T10:00:00Z',
    checkerRemarks: 'Wrong account',
  },
  canModify: false,
  canDelete: false,
  canResubmit: true,
  canClose: true,
  callerIsMaker: true,
  canFallbackClose: false,
};

beforeEach(() => {
  get.mockReset();
  get.mockImplementation(async (url) => {
    if (String(url).startsWith('/ops/glMappingDetail')) return apiOk(REJECTED_NEW);
    if (String(url).startsWith('/ops/glMappingOptions')) return apiOk({ rails: [], accountTypes: [] });
    if (String(url).startsWith('/ops/glMappingWorkflow')) {
      return apiOk({ makerOnlyActions: [], checkerPermission: PERM.glMappingApprove });
    }
    throw new Error(`unexpected GET ${String(url)}`);
  });
});

describe('GL mapping View & Modify panel, rejected New', () => {
  it("AC-APQ-143 labels the resubmit button 'Resubmit', not 'Save'", async () => {
    grant(PERM.glMappingPage, PERM.glMappingWrite);
    renderWithProviders(<GlMappingModifySheet mappingId={8} onClose={vi.fn()} onCompleted={vi.fn()} />);

    expect(await screen.findByRole('button', { name: 'Resubmit' })).toBeEnabled();
    expect(screen.queryByRole('button', { name: 'Save' })).not.toBeInTheDocument();
  });
});
