import { act, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import type { ReactNode } from 'react';
import type { RouteObject } from 'react-router-dom';
import { getI18n } from 'react-i18next';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { changeLanguage } from '@paymenthub/ui';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { DesktopSidebar } from '../../shared/layouts/DesktopSidebar';
import { routes } from '../../router';
import {
  apiError,
  apiOk,
  chooseOption,
  expectNotActionable,
  grant,
  optionsOf,
  renderWithProviders,
} from '../../../test/renderWithProviders';
import { DeleteGlMappingSheet } from './DeleteGlMappingSheet';
import { GlMappingAuditTrailModal } from './GlMappingAuditTrailModal';
import { GlMappingFormSheet } from './GlMappingFormSheet';
import { GlMappingModifySheet } from './GlMappingModifySheet';
import { GlMappingPage } from './GlMappingPage';
import type { GlMappingDetail, GlMappingOptions, GlMappingRow } from './types';

// Opening a shared Radix Select takes 60-110 s under jsdom on the dev machine (the Department tests are slow the same
// way, on Node 22 and 24), so the three tests that open several of them get a longer limit than the 20 s default.
const SLOW_SELECT_MS = 240_000;

// The route guard's session check reads storage; a signed-in session is all these cases need.
vi.mock('@paymenthub/ui', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@paymenthub/ui')>()),
  getCurrentUserFromStorage: () => ({ id: 'u1' }),
}));
vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

const ROW: GlMappingRow = {
  sl: 1,
  mappingId: 7,
  railCode: 'IPI',
  railName: 'Instant Payments',
  accountTypeCode: '1001',
  accountTypeName: 'Nostro',
  accountNumber: '10200100',
  description: 'Settlement account',
  currency: 'AED',
  status: 'Active',
  isPending: false,
  createdAt: '2026-09-28T14:15:30Z',
  createdBy: 'maker1',
  lastModifiedAt: '2026-10-01T09:05:07Z',
  lastModifiedBy: 'maker2',
  lastAction: { action: 'Modify GL Mapping', outcome: 'Accepted' },
  canModify: true,
  canDelete: true,
  canResubmit: false,
  canClose: false,
};

const REJECTED_NEW_ROW: GlMappingRow = {
  ...ROW,
  mappingId: 8,
  accountNumber: '555',
  status: '-',
  lastAction: { action: 'GL Mapping Created', outcome: 'Rejected' },
  lastModifiedAt: null,
  lastModifiedBy: null,
  canModify: false,
  canDelete: false,
  canResubmit: true,
  canClose: true,
};

const DETAIL: GlMappingDetail = {
  mappingId: 7,
  baseTimelineId: 42,
  railCode: 'IPI',
  railName: 'Instant Payments',
  accountTypeCode: '1001',
  accountTypeName: 'Nostro',
  currency: 'AED',
  accountNumber: '10200100',
  description: 'Settlement account',
  status: 'Active',
  isPending: false,
  createdAt: '2026-09-28T14:15:30Z',
  createdBy: 'maker1',
  lastModifiedAt: null,
  lastModifiedBy: null,
  latestRequest: null,
  canModify: true,
  canDelete: true,
  canResubmit: false,
  canClose: false,
  callerIsMaker: false,
  canFallbackClose: false,
};

const REJECTED_REQUEST = {
  requestId: 3,
  action: 'ModifyGlMapping' as const,
  status: 'Rejected' as const,
  makerBy: 'maker1',
  makerAt: '2026-10-01T00:00:00Z',
  makerRemarks: 'Change',
  checkerBy: 'checker1',
  checkerAt: '2026-10-02T10:00:00Z',
  checkerRemarks: 'Wrong account',
};

const OPTIONS: GlMappingOptions = {
  rails: [
    { railCode: 'IPI', railName: 'Instant Payments', status: 'Active', currencies: ['AED', 'USD'] },
    { railCode: 'FTS', railName: 'Fund Transfer', status: 'Active', currencies: ['AED'] },
    { railCode: 'WPS', railName: 'Wage Protection', status: 'Disabled', currencies: ['AED'] },
  ],
  accountTypes: [
    { code: '1001', name: 'Nostro' },
    { code: '1002', name: 'Suspense A/C' },
  ],
};

const NOT_MAKER_ONLY = { makerOnlyActions: [], checkerPermission: PERM.glMappingApprove };

function listOf(items: GlMappingRow[]) {
  return { items, pageNumber: 1, pageSize: 20, totalRecords: items.length };
}

/** Answers each GET by its route, like the Operations API; `over` replaces a route's reply. */
function serve(over: Record<string, unknown> = {}) {
  const table: Record<string, unknown> = {
    '/ops/glMappingList': listOf([ROW]),
    '/ops/glMappingOptions': OPTIONS,
    '/ops/glMappingWorkflow': NOT_MAKER_ONLY,
    '/ops/glMappingDetail': DETAIL,
    ...over,
  };
  get.mockImplementation(async (url) => {
    const key = Object.keys(table).find((k) => String(url).startsWith(k));
    if (!key) throw new Error(`unexpected GET ${String(url)}`);
    return apiOk(table[key]);
  });
}

beforeEach(() => {
  get.mockReset();
  post.mockReset();
  serve();
});

function findRoute(list: RouteObject[], path: string): RouteObject | undefined {
  for (const r of list) {
    if (r.path === path) return r;
    const nested = r.children ? findRoute(r.children, path) : undefined;
    if (nested) return nested;
  }
  return undefined;
}

function inClient(ui: ReactNode, entry: string) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[entry]}>{ui}</MemoryRouter>
    </QueryClientProvider>,
  );
}

// ── Route and chrome (AC-GL-072) ────────────────────────────────────────────────

describe('GL mapping route and chrome', () => {
  const route = findRoute(routes, 'platform/gl-mapping');

  function mountRoute() {
    const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    return render(
      <QueryClientProvider client={client}>
        <MemoryRouter initialEntries={['/platform/gl-mapping']}>
          <Routes>
            <Route path="/platform/gl-mapping" element={route?.element} />
            <Route path="/unauthorized" element={<p>Unauthorized</p>} />
          </Routes>
        </MemoryRouter>
      </QueryClientProvider>,
    );
  }

  it('refuses a session without the page key: the route is no longer ungated', async () => {
    grant(PERM.railPage);
    mountRoute();
    expect(await screen.findByText('Unauthorized')).toBeInTheDocument();
  });

  it('opens for a holder with the title and the full breadcrumb', async () => {
    grant(PERM.glMappingPage);
    mountRoute();
    expect(await screen.findByRole('heading', { name: 'GL Account Mapping' })).toBeInTheDocument();
    expect(screen.getByRole('navigation', { name: 'Breadcrumb' })).toHaveTextContent(
      'Payment Hub Operations Console › Administration › GL Account',
    );
  });

  it('lists the sidebar entry for a holder only', () => {
    grant(PERM.glMappingPage);
    const { unmount } = inClient(<DesktopSidebar />, '/platform/gl-mapping');
    expect(screen.getAllByRole('link', { name: 'GL Mapping' })[0]).toHaveAttribute('href', '/platform/gl-mapping');
    unmount();

    grant(PERM.railPage);
    inClient(<DesktopSidebar />, '/platform/gl-mapping');
    expect(screen.queryByRole('link', { name: 'GL Mapping' })).not.toBeInTheDocument();
  });
});

// ── Grid (AC-GL-073, 075) ───────────────────────────────────────────────────────

describe('GL mapping grid', () => {
  it('shows the 13 FSD columns in order, the status colours, DD-MM-YYYY HH:MM:SS dates and the record count', async () => {
    grant(PERM.glMappingPage, PERM.glMappingWrite);
    serve({ '/ops/glMappingList': listOf([ROW, REJECTED_NEW_ROW]) });
    renderWithProviders(<GlMappingPage />);

    await screen.findByText('10200100');
    const headers = within(screen.getAllByRole('row')[0])
      .getAllByRole('columnheader')
      .map((h) => h.textContent?.trim() ?? '');
    const expected: ((h: string) => boolean)[] = [
      (h) => h.startsWith('Sl'),
      (h) => h.startsWith('Rail'),
      (h) => h.startsWith('Account Name'),
      (h) => h.startsWith('Account Number'),
      (h) => h.startsWith('Description'),
      (h) => h.startsWith('Currency'),
      (h) => h.startsWith('Status'),
      (h) => h.startsWith('Created Date'),
      (h) => h.startsWith('Created By'),
      (h) => h.startsWith('Last Modified') && !h.startsWith('Last Modified By'),
      (h) => h.startsWith('Last Modified By'),
      (h) => h.startsWith('Last Action'),
      (h) => h.startsWith('Actions'),
    ];
    const positions = expected.map((match) => headers.findIndex(match));
    expect(positions.every((p) => p >= 0)).toBe(true);
    expect([...positions].sort((a, b) => a - b)).toEqual(positions);

    // The mapping's Description also shows as a sub-label under the account name (FSD §5.2.2 row 3).
    // Two rows, each shown in the Description column and again under the account name.
    expect(screen.getAllByText('Settlement account')).toHaveLength(4);

    expect(screen.getByText('Active')).toHaveClass('success');
    expect(screen.getByText('-', { selector: 'span' })).toBeInTheDocument();
    expect(screen.getAllByText('28-09-2026 18:15:30')).toHaveLength(2); // session zone (Dubai), was UTC
    expect(screen.getByText('Modify GL Mapping - Accepted')).toBeInTheDocument();
    expect(screen.getByText('GL Mapping Created - Rejected')).toBeInTheDocument();
    expect(document.body).toHaveTextContent('Showing 1–2 of 2 records');
    expect(get).toHaveBeenCalledWith(
      '/ops/glMappingList',
      expect.objectContaining({ params: expect.objectContaining({ PageSize: 20, PageNumber: 1 }) }),
    );
  });

  it('disables View & Modify and Delete on a pending mapping, keeps Audit enabled', async () => {
    grant(PERM.glMappingPage, PERM.glMappingWrite);
    serve({
      '/ops/glMappingList': listOf([
        {
          ...ROW,
          status: 'Pending',
          isPending: true,
          lastAction: { action: 'Modify GL Mapping', outcome: 'Pending' },
          canModify: false,
          canDelete: false,
        },
      ]),
    });
    renderWithProviders(<GlMappingPage />);
    await screen.findByText('10200100');

    expect(screen.getByText('Pending', { selector: '.status-badge' })).toHaveClass('warn');
    expect(screen.getByRole('button', { name: 'View and modify IPI 10200100' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Delete IPI 10200100' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'View audit history for IPI 10200100' })).toBeEnabled();
  });
});

// ── New panel (AC-GL-074, 079) ──────────────────────────────────────────────────

describe('New GL mapping panel', () => {
  async function openNew() {
    grant(PERM.glMappingPage, PERM.glMappingWrite);
    renderWithProviders(<GlMappingFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);
    const rail = await screen.findByRole('combobox', { name: 'Rail' });
    // The trigger is there before the options reply lands; open it only once the rails are loaded.
    await act(async () => {
      await Promise.all(get.mock.results.map((r) => r.value));
    });
    return rail;
  }

  it('has no Status, lists the rail\'s currencies, clears Currency on a Rail change and shows a Disabled rail unselectable', { timeout: SLOW_SELECT_MS }, async () => {
    const rail = await openNew();

    expect(screen.queryByRole('combobox', { name: 'Status' })).not.toBeInTheDocument();
    for (const label of ['Account Name', 'Account Number', 'Description', 'Currency', 'Remarks']) {
      expect(screen.getAllByText(label, { exact: false }).length).toBeGreaterThan(0);
    }

    // Each Select open is slow under jsdom here, so every open both checks and picks.
    await userEvent.click(rail);
    expect(await screen.findByRole('option', { name: /WPS/ })).toHaveAttribute('aria-disabled', 'true');
    await userEvent.click(await screen.findByRole('option', { name: 'IPI — Instant Payments' }));

    const currency = screen.getByRole('combobox', { name: 'Currency' });
    await userEvent.click(currency);
    const labels = within(await screen.findByRole('listbox'))
      .getAllByRole('option')
      .map((o) => o.textContent?.trim() ?? '');
    expect(labels).toEqual(['AED', 'USD']);
    await userEvent.click(await screen.findByRole('option', { name: 'USD' }));
    expect(currency).toHaveTextContent('USD');

    await chooseOption(rail, 'FTS — Fund Transfer');
    await waitFor(() => expect(screen.getByRole('combobox', { name: 'Currency' })).toHaveTextContent('Select Currency'));
    expect(await optionsOf(screen.getByRole('combobox', { name: 'Currency' }))).toEqual(['AED']);
  });

  it('focuses the first empty required field and shows a server refusal inline', { timeout: SLOW_SELECT_MS }, async () => {
    const rail = await openNew();

    await userEvent.click(screen.getByRole('button', { name: 'Save' }));
    expect(await screen.findByText('Please select a Rail.')).toBeInTheDocument();
    expect(screen.getByText('Please select an Account Type.')).toBeInTheDocument();
    expect(screen.getByText('Account Number is required.')).toBeInTheDocument();
    expect(screen.getByText('Currency is required, please select.')).toBeInTheDocument();
    expect(screen.getByText('Remarks required.')).toBeInTheDocument();
    await waitFor(() => expect(rail).toHaveFocus());
    expect(post).not.toHaveBeenCalled();

    const taken = 'This GL mapping already exists for the selected Rail, Currency and Account Type.';
    post.mockRejectedValue(apiError(409, taken, 'Conflict', { ruleCode: 'BR-GL-001' }));
    await chooseOption(rail, 'IPI — Instant Payments');
    await chooseOption(screen.getByRole('combobox', { name: 'Account Name' }), 'Nostro');
    await userEvent.type(screen.getByLabelText(/Account Number/), '10200100');
    await chooseOption(screen.getByRole('combobox', { name: 'Currency' }), 'AED');
    await userEvent.type(screen.getByLabelText(/Remarks/), 'New account');
    await userEvent.click(screen.getByRole('button', { name: 'Save' }));

    expect(await screen.findByText(taken)).toBeInTheDocument();
    expect(post).toHaveBeenCalledWith(
      '/ops/glMappingSave',
      expect.objectContaining({ railCode: 'IPI', accountTypeCode: '1001', currency: 'AED', accountNumber: '10200100' }),
    );
  });

  it('says the change applies immediately only when the action is in makerOnlyActions (AC-GL-079)', async () => {
    const note = 'This change applies immediately; no approval is needed.';
    serve({ '/ops/glMappingWorkflow': { ...NOT_MAKER_ONLY, makerOnlyActions: ['CreateGlMapping'] } });
    const { unmount } = renderWithProviders(<GlMappingFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);
    expect(await screen.findByText(note)).toBeInTheDocument();
    unmount();

    serve();
    renderWithProviders(<GlMappingFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);
    await waitFor(() => expect(get).toHaveBeenCalledWith('/ops/glMappingWorkflow'));
    await screen.findByRole('combobox', { name: 'Rail' });
    expect(screen.queryByText(note)).not.toBeInTheDocument();
  });
});

// ── View & Modify panel (AC-GL-075, 078) ────────────────────────────────────────

describe('View & Modify panel', () => {
  it('lets an applied mapping change every field including Rail and Status, with the Approver Remarks read-only after a rejection', { timeout: SLOW_SELECT_MS }, async () => {
    grant(PERM.glMappingPage, PERM.glMappingWrite);
    serve({ '/ops/glMappingDetail': { ...DETAIL, latestRequest: REJECTED_REQUEST } });
    renderWithProviders(<GlMappingModifySheet mappingId={7} onClose={vi.fn()} onCompleted={vi.fn()} />);

    const rail = await screen.findByRole('combobox', { name: 'Rail' });
    expect(rail).toBeEnabled();
    expect(screen.getByRole('combobox', { name: 'Account Name' })).toBeEnabled();
    expect(screen.getByLabelText(/Account Number/)).not.toHaveAttribute('readonly');
    expect(await optionsOf(screen.getByRole('combobox', { name: 'Status' }))).toEqual(['Active', 'Disabled']);

    const approver = screen.getByLabelText('Approver Remarks');
    expect(approver).toHaveAttribute('readonly');
    expect(approver).toHaveValue('Wrong account');
    expect(screen.getByRole('button', { name: 'Save Changes' })).toBeEnabled();
  });

  it('offers the Maker of a rejected New only Resubmit, Close and Cancel', async () => {
    grant(PERM.glMappingPage, PERM.glMappingWrite);
    serve({
      '/ops/glMappingDetail': {
        ...DETAIL,
        mappingId: 8,
        baseTimelineId: null,
        status: '-',
        canModify: false,
        canDelete: false,
        canResubmit: true,
        canClose: true,
        callerIsMaker: true,
        latestRequest: { ...REJECTED_REQUEST, action: 'CreateGlMapping' },
      },
    });
    renderWithProviders(<GlMappingModifySheet mappingId={8} onClose={vi.fn()} onCompleted={vi.fn()} />);

    expect(await screen.findByRole('button', { name: 'Resubmit' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Close GL mapping IPI — Nostro' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Cancel' })).toBeEnabled();
    expect(screen.queryByRole('button', { name: 'Save Changes' })).not.toBeInTheDocument();
  });

  it('gates Resubmit and Close on the write key (AC-GL-078)', async () => {
    grant(PERM.glMappingPage);
    serve({
      '/ops/glMappingDetail': { ...DETAIL, canModify: false, canResubmit: true, canClose: true, callerIsMaker: true },
    });
    renderWithProviders(<GlMappingModifySheet mappingId={7} onClose={vi.fn()} onCompleted={vi.fn()} />);

    await screen.findByRole('combobox', { name: 'Rail' });
    expectNotActionable(screen.queryByRole('button', { name: 'Resubmit' }));
    expectNotActionable(screen.queryByRole('button', { name: 'Save Changes' }));
    expectNotActionable(screen.queryByRole('button', { name: /^Close GL mapping/ }));
  });
});

// ── Delete panel (AC-GL-076) ────────────────────────────────────────────────────

describe('Delete GL mapping panel', () => {
  it('asks the FSD question, requires Remarks and shows no active-transactions warning', async () => {
    grant(PERM.glMappingPage, PERM.glMappingWrite);
    renderWithProviders(<DeleteGlMappingSheet row={ROW} onClose={vi.fn()} onDeleted={vi.fn()} />);

    expect(screen.getByText('Delete this GL mapping? This cannot be undone.')).toBeInTheDocument();
    expect(screen.queryByText(/transaction/i)).not.toBeInTheDocument();

    const remove = screen.getByRole('button', { name: 'Delete Mapping' });
    await waitFor(() => expect(remove).toBeEnabled());
    await userEvent.click(remove);
    expect(await screen.findByText('Remarks required.')).toBeInTheDocument();
    expect(post).not.toHaveBeenCalled();
  });
});

// ── Audit modal (AC-GL-077) ─────────────────────────────────────────────────────

describe('GL mapping audit modal', () => {
  it('is titled Audit History, offers no Approval section, keeps To after From, dates the cards and pages by 10', { timeout: SLOW_SELECT_MS }, async () => {
    grant(PERM.glMappingPage);
    serve({
      '/ops/glMappingAudit': {
        mappingId: 7,
        pageNumber: 1,
        pageSize: 10,
        totalRecords: 12,
        items: [
          {
            sequenceNo: 1,
            auditId: 100,
            requestId: 1,
            action: 'GlMappingCreated',
            section: 'GL Created',
            userId: 'maker1',
            userName: 'Maker One',
            userRole: 'Maker',
            remarks: 'New account',
            changedFields: null,
            oldData: null,
            newData: '{"RailCode":"IPI","Currency":"AED","Status":"Active"}',
            actionDate: '2026-09-28T14:15:00Z',
          },
        ],
      },
    });
    renderWithProviders(<GlMappingAuditTrailModal row={ROW} onClose={vi.fn()} />);

    expect(await screen.findByText('28-09-2026 18:15:00')).toBeInTheDocument(); // session zone (Dubai), 24-hour
    expect(screen.getByText('Audit History')).toBeInTheDocument();
    expect(await optionsOf(screen.getByRole('combobox', { name: 'Section' }))).toEqual([
      'All Sections',
      'Account Update',
      'Status Change',
      'GL Created',
    ]);
    expect(get).toHaveBeenCalledWith(
      '/ops/glMappingAudit/7',
      expect.objectContaining({ params: expect.objectContaining({ PageSize: 10, PageNumber: 1 }) }),
    );
    expect(screen.getByText('1–1 of 12')).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText('From'), { target: { value: '2026-10-05' } });
    fireEvent.change(screen.getByLabelText('To'), { target: { value: '2026-10-01' } });
    expect(await screen.findByText("To Date can't be earlier than From Date.")).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Search' })).toBeDisabled();
  });
});

// ── Controls follow the keys (AC-GL-078) ────────────────────────────────────────

describe('GL mapping grid controls', () => {
  it('shows New and Delete only with the write key and Export only with the export key; Audit needs the page key', async () => {
    grant(PERM.glMappingPage);
    const { unmount } = renderWithProviders(<GlMappingPage />);
    await screen.findByText('10200100');

    expectNotActionable(screen.queryByRole('button', { name: /New GL Mapping/ }));
    expectNotActionable(screen.queryByRole('button', { name: 'Delete IPI 10200100' }));
    expect(screen.getByRole('button', { name: 'View audit history for IPI 10200100' })).toBeEnabled();
    expect(screen.queryByRole('button', { name: /Export/ })).not.toBeInTheDocument();
    unmount();

    grant(PERM.glMappingPage, PERM.glMappingWrite, PERM.opsReportExport);
    renderWithProviders(<GlMappingPage />);
    await screen.findByText('10200100');

    expect(screen.getByRole('button', { name: /New GL Mapping/ })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Delete IPI 10200100' })).toBeEnabled();
    expect(screen.getByRole('button', { name: /Export/ })).toBeInTheDocument();
  });
});

// ── Languages (AC-GL-080) ───────────────────────────────────────────────────────

describe('GL mapping languages', () => {
  afterEach(async () => {
    await changeLanguage('en');
  });

  /** Every leaf of a translation block, as `A.B.C`. */
  function leaves(node: unknown, path = ''): string[] {
    if (typeof node === 'string') return [path];
    return Object.entries(node as Record<string, unknown>).flatMap(([k, v]) => leaves(v, path ? `${path}.${k}` : k));
  }

  it('has an Arabic entry for every English one and renders right-to-left in Arabic', async () => {
    await changeLanguage('ar');
    const i18n = getI18n();
    const en = (i18n.getResourceBundle('en', 'translation') as Record<string, unknown>).GL_MAPPING;
    const ar = (i18n.getResourceBundle('ar', 'translation') as Record<string, unknown>).GL_MAPPING;

    expect(en).toBeDefined();
    expect(leaves(ar).sort()).toEqual(leaves(en).sort());
    leaves(ar).forEach((key) => {
      const value = key.split('.').reduce<unknown>((o, k) => (o as Record<string, unknown>)[k], ar);
      expect(value).not.toBe('');
    });

    grant(PERM.glMappingPage);
    renderWithProviders(<GlMappingPage />);
    expect(await screen.findByRole('heading', { name: 'ربط حسابات الأستاذ العام' })).toBeInTheDocument();
    expect(document.documentElement.dir).toBe('rtl');
  });
});
