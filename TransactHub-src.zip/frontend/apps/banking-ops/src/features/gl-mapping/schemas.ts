import { z } from 'zod';

/**
 * The panels' forms: one zod schema each, mirroring the server's FluentValidation rules (design §6, §6.1); the server
 * stays authoritative. A message is a key in the `GL_MAPPING` translation block, so a schema needs no language.
 */
export const VALIDATION = {
  railRequired: 'VALIDATION.RAIL_REQUIRED',
  accountTypeRequired: 'VALIDATION.ACCOUNT_TYPE_REQUIRED',
  accountNumberRequired: 'VALIDATION.ACCOUNT_NUMBER_REQUIRED',
  accountNumberFormat: 'VALIDATION.ACCOUNT_NUMBER_FORMAT',
  currencyRequired: 'VALIDATION.CURRENCY_REQUIRED',
  remarksRequired: 'VALIDATION.REMARKS_REQUIRED',
} as const;

export const MAX_ACCOUNT_NUMBER = 34;
export const MAX_DESCRIPTION = 500;
export const MAX_REMARKS = 1000;

/** ASCII digits, 1-34 (GQ-11). `\d` is not used: it matches other scripts' digits. */
const ACCOUNT_NUMBER = /^[0-9]{1,34}$/;

const required = (message: string) => z.string().trim().min(1, message);

/** New (FSD §5.1): no Status. */
export const newGlMappingSchema = z.object({
  railCode: required(VALIDATION.railRequired),
  accountTypeCode: required(VALIDATION.accountTypeRequired),
  accountNumber: required(VALIDATION.accountNumberRequired).regex(ACCOUNT_NUMBER, VALIDATION.accountNumberFormat),
  description: z.string().trim().max(MAX_DESCRIPTION),
  currency: required(VALIDATION.currencyRequired),
  remarks: required(VALIDATION.remarksRequired).max(MAX_REMARKS),
});

export type NewGlMappingForm = z.infer<typeof newGlMappingSchema>;

/** View & Modify (FSD §5.3) and Resubmit: the same fields plus the Status a Maker can pick. */
export const modifyGlMappingSchema = newGlMappingSchema.extend({
  status: z.enum(['Active', 'Disabled', 'Pending', '-']),
});

export type ModifyGlMappingForm = z.infer<typeof modifyGlMappingSchema>;

/** Delete (FSD §5.5): the mandatory reason. */
export const deleteGlMappingSchema = z.object({ remarks: required(VALIDATION.remarksRequired).max(MAX_REMARKS) });

export type DeleteGlMappingForm = z.infer<typeof deleteGlMappingSchema>;
