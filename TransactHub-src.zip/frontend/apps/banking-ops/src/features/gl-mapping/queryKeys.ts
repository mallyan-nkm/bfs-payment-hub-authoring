import type { GlMappingAuditParams, GlMappingListParams } from './types';

/** GL mapping query keys. Every command invalidates `all`. */
export const glMappingKeys = {
  all: ['gl-mappings'] as const,
  list: (params: GlMappingListParams) => ['gl-mappings', 'list', params] as const,
  detail: (mappingId: number) => ['gl-mappings', 'detail', mappingId] as const,
  options: ['gl-mappings', 'options'] as const,
  workflow: ['gl-mappings', 'workflow'] as const,
  audit: (mappingId: number, params: GlMappingAuditParams) => ['gl-mappings', 'audit', mappingId, params] as const,
};
