import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { bankingApi } from '../../shared/api/bankingApi';
import { glMappingKeys } from './queryKeys';
import type {
  GlMappingAuditParams,
  GlMappingAuditResponse,
  GlMappingDetail,
  GlMappingExportFormat,
  GlMappingListParams,
  GlMappingListResponse,
  GlMappingOptions,
  GlMappingSavedResponse,
  GlMappingWorkflow,
  SaveGlMappingRequest,
} from './types';

/**
 * GL Account mapping over the Operations API (GL Account design §5). The tenant and the acting user come from the
 * session server-side, so no request here names either.
 */
const BASE = '/ops';

/** Repeated keys for arrays (`RailCodes=A&RailCodes=B`), as the server's binder reads them. */
const REPEAT_KEYS = { indexes: null } as const;

const some = (v?: string[]) => (v?.length ? v : undefined);

function listQuery(p: GlMappingListParams) {
  return {
    RailCodes: some(p.railCodes),
    AccountTypeCodes: some(p.accountTypeCodes),
    Currencies: some(p.currencies),
    Statuses: some(p.statuses),
    LastActions: some(p.lastActions),
    AccountNumber: p.accountNumber || undefined,
    Description: p.description || undefined,
    CreatedBy: p.createdBy || undefined,
    LastModifiedBy: p.lastModifiedBy || undefined,
    // Days stay `yyyy-MM-dd`: these endpoints bind DateOnly days and read them in the session zone (UTC date-time T-22).
    CreatedFrom: p.createdFrom || undefined,
    CreatedTo: p.createdTo || undefined,
    LastModifiedFrom: p.lastModifiedFrom || undefined,
    LastModifiedTo: p.lastModifiedTo || undefined,
    SortBy: p.sortBy,
    SortDirection: p.sortBy ? p.sortDirection : undefined,
  };
}

export const glMappingApi = {
  list: (p: GlMappingListParams) =>
    bankingApi
      .get<GlMappingListResponse>(`${BASE}/glMappingList`, {
        params: { ...listQuery(p), PageSize: p.pageSize, PageNumber: p.pageNumber },
        paramsSerializer: REPEAT_KEYS,
      })
      .then((r) => r.data),

  detail: (mappingId: number) =>
    bankingApi.get<GlMappingDetail>(`${BASE}/glMappingDetail/${mappingId}`).then((r) => r.data),

  options: () => bankingApi.get<GlMappingOptions>(`${BASE}/glMappingOptions`).then((r) => r.data),

  workflow: () => bankingApi.get<GlMappingWorkflow>(`${BASE}/glMappingWorkflow`).then((r) => r.data),

  audit: (mappingId: number, p: GlMappingAuditParams) =>
    bankingApi
      .get<GlMappingAuditResponse>(`${BASE}/glMappingAudit/${mappingId}`, {
        params: {
          Section: p.section || undefined,
          // Days stay `yyyy-MM-dd`: these endpoints bind DateOnly days and read them in the session zone (UTC date-time T-22).
          FromDate: p.fromDate || undefined,
          ToDate: p.toDate || undefined,
          PageSize: p.pageSize,
          PageNumber: p.pageNumber,
        },
      })
      .then((r) => r.data),

  create: (body: SaveGlMappingRequest) =>
    bankingApi.post<GlMappingSavedResponse>(`${BASE}/glMappingSave`, body).then((r) => r.data),

  modify: (mappingId: number, body: SaveGlMappingRequest) =>
    bankingApi.post<GlMappingSavedResponse>(`${BASE}/glMappingSave/${mappingId}`, body).then((r) => r.data),

  resubmit: (mappingId: number, body: SaveGlMappingRequest) =>
    bankingApi.post<GlMappingSavedResponse>(`${BASE}/glMappingResubmit/${mappingId}`, body).then((r) => r.data),

  remove: (mappingId: number, baseTimelineId: number | null, remarks: string) =>
    bankingApi
      .post<GlMappingSavedResponse>(`${BASE}/glMappingDelete/${mappingId}`, { baseTimelineId, remarks })
      .then((r) => r.data),

  /** `closesRequestId` is the rejected request being closed: the server refuses a stale one. */
  close: (mappingId: number, remarks: string, closesRequestId: number) =>
    bankingApi
      .post<GlMappingSavedResponse>(`${BASE}/glMappingClose/${mappingId}`, { remarks, closesRequestId })
      .then((r) => r.data),

  /** The whole filtered set, server-rendered; `columns` are the visible column keys in display order. */
  export: (format: GlMappingExportFormat, p: GlMappingListParams, columns: string[]) =>
    bankingApi
      .get<Blob>(`${BASE}/glMappingExport/${format}`, {
        params: { ...listQuery(p), Columns: columns.join(',') },
        paramsSerializer: REPEAT_KEYS,
        responseType: 'blob',
      })
      .then((r) => r.data),
};

export function useGlMappingList(params: GlMappingListParams) {
  return useQuery({
    queryKey: glMappingKeys.list(params),
    queryFn: () => glMappingApi.list(params),
    placeholderData: keepPreviousData,
  });
}

export function useGlMappingDetail(mappingId: number) {
  return useQuery({ queryKey: glMappingKeys.detail(mappingId), queryFn: () => glMappingApi.detail(mappingId) });
}

export function useGlMappingOptions() {
  return useQuery({ queryKey: glMappingKeys.options, queryFn: glMappingApi.options });
}

/** Which actions apply immediately; until it loads, nothing is claimed to (the safe wording). */
export function useGlMappingWorkflow() {
  return useQuery({ queryKey: glMappingKeys.workflow, queryFn: glMappingApi.workflow });
}

export function useGlMappingAudit(mappingId: number, params: GlMappingAuditParams) {
  return useQuery({
    queryKey: glMappingKeys.audit(mappingId, params),
    queryFn: () => glMappingApi.audit(mappingId, params),
    placeholderData: keepPreviousData,
  });
}

/** Every command refreshes the grid and the mapping's detail and audit feed. */
function useGlMappingCommand<TArgs>(run: (args: TArgs) => Promise<GlMappingSavedResponse>) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: run,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: glMappingKeys.all }),
  });
}

export const useCreateGlMapping = () => useGlMappingCommand((body: SaveGlMappingRequest) => glMappingApi.create(body));

export const useModifyGlMapping = () =>
  useGlMappingCommand(({ mappingId, body }: { mappingId: number; body: SaveGlMappingRequest }) =>
    glMappingApi.modify(mappingId, body),
  );

export const useResubmitGlMapping = () =>
  useGlMappingCommand(({ mappingId, body }: { mappingId: number; body: SaveGlMappingRequest }) =>
    glMappingApi.resubmit(mappingId, body),
  );

export const useDeleteGlMapping = () =>
  useGlMappingCommand(
    ({ mappingId, baseTimelineId, remarks }: { mappingId: number; baseTimelineId: number | null; remarks: string }) =>
      glMappingApi.remove(mappingId, baseTimelineId, remarks),
  );

export const useCloseGlMapping = () =>
  useGlMappingCommand(
    ({ mappingId, remarks, closesRequestId }: { mappingId: number; remarks: string; closesRequestId: number }) =>
      glMappingApi.close(mappingId, remarks, closesRequestId),
  );
