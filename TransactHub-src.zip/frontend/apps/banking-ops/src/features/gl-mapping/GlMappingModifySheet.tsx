import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Can, Select, Textarea, usePermissions, useSessionDateTime } from '@paymenthub/ui';
import { Info } from 'lucide-react';
import { SideSheet } from '../../shared/components/SideSheet';
import { PERM } from '../../shared/auth/permissionKeys';
import {
  useCloseGlMapping,
  useGlMappingDetail,
  useGlMappingOptions,
  useGlMappingWorkflow,
  useModifyGlMapping,
  useResubmitGlMapping,
} from './api';
import { glErrorMessage, glFieldErrors } from './errors';
import { FIELD_ID, GlMappingFields, focusFirstError } from './GlMappingFields';
import { NEW_SERVER_FIELDS } from './GlMappingFormSheet';
import {
  AppliesImmediately,
  FormRow,
  PANEL_WIDTH,
  PanelError,
  PanelFooter,
  ReadOnlyInput,
  RemarksField,
  SERVER_ERROR,
  fieldErrorText,
} from './formParts';
import { statusLabel, useGlMappingTranslation } from './i18n';
import { modifyGlMappingSchema } from './schemas';
import type { ModifyGlMappingForm } from './schemas';
import { EDITABLE_STATUSES } from './types';
import type { GlMappingDetail, GlMappingStatus } from './types';

const isEditable = (s: GlMappingStatus) => (EDITABLE_STATUSES as readonly string[]).includes(s);

/**
 * View & Modify (FSD §5.3, design §7). The panel reads `glMappingDetail`, not the grid row, because the buttons depend
 * on the newest request:
 * - a pending request locks the mapping: nothing can be changed until the Checker decides (BR-GL-009);
 * - a rejected request shows the Approver's remarks read-only, so the Maker can see why;
 * - a rejected New can only be resubmitted with corrected values or closed (GQ-8).
 */
export function GlMappingModifySheet({
  mappingId,
  onClose,
  onCompleted,
}: {
  mappingId: number;
  onClose: () => void;
  onCompleted: (message: string) => void;
}) {
  const { t } = useGlMappingTranslation();
  const detailQuery = useGlMappingDetail(mappingId);
  const detail = detailQuery.data;

  if (detail) {
    return (
      <ModifyForm
        // Remount on a refetch after a command, so the form starts from the mapping's new state.
        key={`${detail.mappingId}-${detail.baseTimelineId ?? 0}-${detail.latestRequest?.requestId ?? 0}-${detail.latestRequest?.status ?? ''}`}
        detail={detail}
        onClose={onClose}
        onCompleted={onCompleted}
      />
    );
  }

  return (
    <SideSheet
      eyebrow={t('MODIFY.EYEBROW')}
      title={t('MODIFY.LOADING_TITLE')}
      subtitle={t('MODIFY.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={
        <Button type="button" variant="secondary" onClick={onClose}>
          {t('FORM.CANCEL')}
        </Button>
      }
    >
      {detailQuery.isError ? (
        <div className="flex flex-col items-center gap-3">
          <PanelError message={glErrorMessage(detailQuery.error, t('ERROR.REQUEST_FAILED'))} />
          <Button type="button" variant="outline" size="sm" onClick={() => void detailQuery.refetch()}>
            {t('MODIFY.RETRY')}
          </Button>
        </div>
      ) : (
        <p role="status" className="p-6 text-center text-sm text-[var(--text-2)]">
          {t('MODIFY.LOADING')}
        </p>
      )}
    </SideSheet>
  );
}

function ModifyForm({
  detail,
  onClose,
  onCompleted,
}: {
  detail: GlMappingDetail;
  onClose: () => void;
  onCompleted: (message: string) => void;
}) {
  const { t } = useGlMappingTranslation();
  const { formatInstant } = useSessionDateTime();
  const { can } = usePermissions();
  const canWrite = can(PERM.glMappingWrite);
  const [panelError, setPanelError] = useState<string | null>(null);
  const options = useGlMappingOptions();
  const workflow = useGlMappingWorkflow();

  const modify = useModifyGlMapping();
  const resubmit = useResubmitGlMapping();
  const close = useCloseGlMapping();
  const busy = modify.isPending || resubmit.isPending || close.isPending;

  const {
    register,
    control,
    handleSubmit,
    setError,
    setValue,
    getValues,
    trigger,
    watch,
    formState: { errors },
  } = useForm<ModifyGlMappingForm>({
    resolver: zodResolver(modifyGlMappingSchema),
    defaultValues: {
      railCode: detail.railCode,
      accountTypeCode: detail.accountTypeCode,
      accountNumber: detail.accountNumber,
      description: detail.description ?? '',
      currency: detail.currency,
      status: detail.status,
      remarks: '',
    },
    shouldFocusError: false,
  });

  // A refusal is about what was submitted; editing anything clears it.
  useEffect(() => {
    const subscription = watch(() => setPanelError(null));
    return () => subscription.unsubscribe();
  }, [watch]);

  const request = detail.latestRequest;
  const pending = detail.isPending;
  // Resubmit/Close are for a rejected New (GQ-8); Modify only while nothing is pending. Only the Maker resubmits or
  // closes; another user may only do the fallback Close, once IAM says the Maker can no longer act (§10.3, §10.5).
  const rejectedNew = detail.canResubmit || detail.canClose;
  const makerActs = rejectedNew && detail.callerIsMaker;
  const fallbackClose = rejectedNew && !detail.callerIsMaker && detail.canFallbackClose;
  const canModify = canWrite && detail.canModify;
  const editable = canModify || (canWrite && detail.canResubmit && makerActs);
  const statusOptions: GlMappingStatus[] = isEditable(detail.status)
    ? [...EDITABLE_STATUSES]
    : [detail.status, ...EDITABLE_STATUSES];
  const immediate = Boolean(
    workflow.data?.makerOnlyActions.includes(rejectedNew ? 'CreateGlMapping' : 'ModifyGlMapping'),
  );

  function fail(error: unknown) {
    const fieldErrors = glFieldErrors(error, NEW_SERVER_FIELDS);
    if (fieldErrors.length === 0) {
      setPanelError(glErrorMessage(error, t('ERROR.REQUEST_FAILED')));
      return;
    }
    fieldErrors.forEach(({ field, message }, i) =>
      setError(field, { type: SERVER_ERROR, message }, { shouldFocus: i === 0 }),
    );
    document.getElementById(FIELD_ID[fieldErrors[0].field])?.focus();
  }

  const name = `${detail.railCode} — ${detail.accountTypeName}`;

  const saveChanges = handleSubmit(
    async (values) => {
      const unchanged =
        values.railCode === detail.railCode &&
        values.accountTypeCode === detail.accountTypeCode &&
        values.accountNumber === detail.accountNumber &&
        values.description === (detail.description ?? '') &&
        values.currency === detail.currency &&
        values.status === detail.status;
      if (unchanged) {
        setPanelError(t('MODIFY.NO_CHANGES'));
        return;
      }
      try {
        await modify.mutateAsync({
          mappingId: detail.mappingId,
          body: {
            baseTimelineId: detail.baseTimelineId,
            railCode: values.railCode,
            accountTypeCode: values.accountTypeCode,
            currency: values.currency,
            accountNumber: values.accountNumber,
            description: values.description,
            status: isEditable(values.status) ? (values.status as 'Active' | 'Disabled') : undefined,
            remarks: values.remarks,
          },
        });
        onCompleted(t('TOAST.UPDATED', { name }));
      } catch (error) {
        fail(error);
      }
    },
    (invalid) => focusFirstError(invalid),
  );

  const resubmitNew = handleSubmit(
    async (values) => {
      if (!request) return;
      try {
        await resubmit.mutateAsync({
          mappingId: detail.mappingId,
          body: {
            baseTimelineId: null,
            railCode: values.railCode,
            accountTypeCode: values.accountTypeCode,
            currency: values.currency,
            accountNumber: values.accountNumber,
            description: values.description,
            remarks: values.remarks,
            resubmissionOf: request.requestId,
          },
        });
        onCompleted(t('TOAST.RESUBMITTED', { name }));
      } catch (error) {
        fail(error);
      }
    },
    (invalid) => focusFirstError(invalid),
  );

  /** Closing keeps the values as they are: only the remarks are checked, and only for a fallback close (Maker: optional). */
  async function closeNew() {
    if (!request) return;
    if (fallbackClose && !(await trigger('remarks', { shouldFocus: true }))) return;
    try {
      await close.mutateAsync({
        mappingId: detail.mappingId,
        remarks: getValues('remarks').trim(),
        closesRequestId: request.requestId,
      });
      onCompleted(t('TOAST.CLOSED'));
    } catch (error) {
      fail(error);
    }
  }

  // Each control is gated on its own: <Can> applies a denial to its one child, and a fragment can't carry one.
  const footer = (
    <PanelFooter onCancel={onClose}>
      {rejectedNew ? (
        <>
          {(makerActs || fallbackClose) && (
            <Can permission={PERM.glMappingWrite}>
              <Button
                type="button"
                variant="secondary"
                disabled={busy || !detail.canClose}
                onClick={() => void closeNew()}
                // The header's ✕ is also named "Close"; this one closes the rejected mapping, not the panel.
                aria-label={t('MODIFY.CLOSE_LABEL', { name })}
              >
                {t('MODIFY.CLOSE')}
              </Button>
            </Can>
          )}
          {makerActs && (
            <Can permission={PERM.glMappingWrite}>
              <Button type="button" variant="primary" disabled={busy || !detail.canResubmit} onClick={() => void resubmitNew()}>
                {t('MODIFY.RESUBMIT')}
              </Button>
            </Can>
          )}
        </>
      ) : (
        <Can permission={PERM.glMappingWrite}>
          <Button
            type="button"
            variant="primary"
            disabled={!canModify || busy}
            title={canModify ? undefined : pending ? t('BLOCKED.PENDING') : undefined}
            onClick={() => void saveChanges()}
          >
            {modify.isPending ? t('FORM.SAVING') : t('MODIFY.SAVE_CHANGES')}
          </Button>
        </Can>
      )}
    </PanelFooter>
  );

  return (
    <SideSheet
      eyebrow={t('MODIFY.EYEBROW')}
      title={name}
      subtitle={t('MODIFY.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={footer}
    >
      <div>
        <PanelError message={panelError} />

        {pending && request && (
          <div
            role="status"
            className="mb-4 flex gap-2 rounded-lg border border-[var(--accent-amber)]/40 bg-[var(--accent-amber)]/10 px-3 py-2 text-xs text-[var(--text-primary)]"
          >
            <Info size={14} className="mt-0.5 shrink-0 text-[var(--accent-amber)]" aria-hidden="true" />
            <span>
              {t('MODIFY.PENDING_NOTICE', {
                requestId: request.requestId,
                makerBy: request.makerBy,
              })}
            </span>
          </div>
        )}

        {fallbackClose && request && (
          <div
            role="note"
            className="mb-4 flex gap-2 rounded-lg border border-[var(--accent-amber)]/40 bg-[var(--accent-amber)]/10 px-3 py-2 text-xs text-[var(--text-primary)]"
          >
            <Info size={14} className="mt-0.5 shrink-0 text-[var(--accent-amber)]" aria-hidden="true" />
            <span>{t('MODIFY.MAKER_INELIGIBLE', { makerBy: request.makerBy })}</span>
          </div>
        )}

        {editable && <AppliesImmediately show={immediate} />}

        {request?.status === 'Rejected' && (
          <section
            aria-labelledby="gl-approver-remarks-heading"
            className="mb-4 rounded-lg border border-[var(--accent-red)]/40 bg-[var(--accent-red)]/5 px-3 py-2"
          >
            <h3 id="gl-approver-remarks-heading" className="text-xs font-bold uppercase tracking-wider text-[var(--accent-red)]">
              {t('MODIFY.REJECTED')}
            </h3>
            <p className="mt-1 text-[11px] text-[var(--text-muted)]">
              {t('MODIFY.APPROVER', {
                approver: request.checkerBy ?? '—',
                at: formatInstant(request.checkerAt),
              })}
            </p>
            <label htmlFor="gl-approver-remarks" className="mt-2 block text-xs font-semibold text-[var(--text-primary)]">
              {t('MODIFY.APPROVER_REMARKS')}
            </label>
            <Textarea
              id="gl-approver-remarks"
              value={request.checkerRemarks ?? ''}
              readOnly
              rows={3}
              className="input-cls mt-1 w-full cursor-default resize-none bg-[var(--bg-secondary)] text-xs text-[var(--text-2)]"
            />
          </section>
        )}

        <div className="flex flex-col gap-3">
          <GlMappingFields
            control={control}
            register={register}
            setValue={setValue}
            errors={errors}
            options={options.data}
            editable={editable}
            fallbackAccountType={{ code: detail.accountTypeCode, name: detail.accountTypeName }}
          />
          <FormRow label={t('FORM.STATUS')} htmlFor="gl-status">
            <Controller
              control={control}
              name="status"
              render={({ field }) => (
                <Select
                  id="gl-status"
                  value={field.value}
                  onValueChange={(v) => field.onChange(v as GlMappingStatus)}
                  disabled={!canModify}
                  options={statusOptions.map((s) => ({ value: s, label: statusLabel(t, s), disabled: !isEditable(s) }))}
                  className="h-10 w-full text-xs"
                />
              )}
            />
          </FormRow>
          <FormRow label={t('MODIFY.CREATED_ON')} htmlFor="gl-created-on">
            <ReadOnlyInput id="gl-created-on" value={formatInstant(detail.createdAt)} />
          </FormRow>
          <FormRow label={t('MODIFY.CREATED_BY')} htmlFor="gl-created-by">
            <ReadOnlyInput id="gl-created-by" value={detail.createdBy} />
          </FormRow>
          <FormRow label={t('MODIFY.LAST_MODIFIED')} htmlFor="gl-last-modified">
            <ReadOnlyInput id="gl-last-modified" value={formatInstant(detail.lastModifiedAt)} />
          </FormRow>
          <FormRow label={t('MODIFY.LAST_MODIFIED_BY')} htmlFor="gl-last-modified-by">
            <ReadOnlyInput id="gl-last-modified-by" value={detail.lastModifiedBy ?? '—'} />
          </FormRow>
        </div>

        {(editable || (canWrite && fallbackClose)) && (
          <div className="mt-5">
            <RemarksField
              id={FIELD_ID.remarks}
              label={t('FORM.REMARKS')}
              accent="amber"
              placeholder={t('MODIFY.REMARKS_PLACEHOLDER')}
              error={fieldErrorText(t, errors.remarks)}
              {...register('remarks')}
            />
          </div>
        )}
      </div>
    </SideSheet>
  );
}
