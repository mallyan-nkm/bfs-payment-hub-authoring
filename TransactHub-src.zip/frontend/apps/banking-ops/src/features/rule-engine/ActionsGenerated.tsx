import type { ApprovalMatrix, RuleActionDto } from './types';

/**
 * "Actions Generated" (FSD Section 19.2) for the Test Rule tab and the Test /
 * Evaluate consoles. Plain Field = Value entries are listed as returned; entries
 * that carry a `group` (a WorkflowApproval File Type and its levels) are listed
 * under that group, ordered by `sequence`. A returned approval matrix is summarised first.
 */
export function ActionsGenerated({ actions, approvalMatrix }: { actions: RuleActionDto[]; approvalMatrix?: ApprovalMatrix | null }) {
  if (actions.length === 0) return null;

  const ungrouped = actions.filter((a) => !a.group);
  const groups = [...new Set(actions.filter((a) => a.group).map((a) => a.group!))].map((group) => ({
    group,
    entries: actions
      .filter((a) => a.group === group)
      .sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0)),
  }));

  return (
    <div className="mb-3 flex flex-col gap-1 rounded-md bg-[var(--bg-secondary)] p-3" data-testid="actions-generated">
      <label className="text-[10px] uppercase tracking-wide text-[var(--text-muted)]">Actions Generated</label>
      {approvalMatrix && (
        <div className="mb-1 text-xs font-semibold text-[var(--text-primary)]">
          {[approvalMatrix.mode, approvalMatrix.isStp ? 'STP (Straight Through Processing)' : approvalMatrix.type, `TotalApprovalLevels: ${approvalMatrix.totalApprovalLevels ?? 0}`].filter(Boolean).join(' · ')}
          {!approvalMatrix.isStp && approvalMatrix.fileTypes.map((f) => (
            <div key={f.fileType ?? 'levels'} className="font-mono font-normal">
              {f.fileType ? `${f.fileType}: ` : ''}{f.levels.map((l) => `L${l.level} ${l.role}`).join(' → ') || '—'}
            </div>
          ))}
        </div>
      )}
      {ungrouped.map((a, i) => (
        <ActionLine key={`u-${i}`} action={a} />
      ))}
      {groups.map(({ group, entries }) => (
        <div key={group} className="mt-1 flex flex-col gap-1 border-l-2 border-[var(--accent)]/40 pl-2">
          <span className="font-mono text-[11px] font-bold text-[var(--text-secondary)]">{group}</span>
          {entries.map((a, i) => (
            <ActionLine key={`${group}-${i}`} action={a} />
          ))}
        </div>
      ))}
    </div>
  );
}

function ActionLine({ action }: { action: RuleActionDto }) {
  return (
    <div className="flex items-center gap-2 font-mono text-xs">
      {action.sequence != null && <span className="text-[var(--text-muted)]">L{action.sequence}</span>}
      <span className="rounded bg-[var(--accent)]/10 px-1.5 py-0.5 font-semibold text-[var(--accent)]">{action.field}</span>
      <span className="text-[var(--text-muted)]">=</span>
      <span className="text-[var(--text-primary)]">{action.value}</span>
    </div>
  );
}
