import { createContext, useContext, useMemo } from 'react';
import { Braces, Plus, X } from 'lucide-react';
import { Button, Input, RichSelect, Select, cn } from '@paymenthub/ui';
import {
  EMPTY_CONDITION_CATALOG,
  getConditionFieldDef,
  getOperatorArity,
  getValueLabel,
  selectableOptions,
  type ConditionCatalog,
  type ConditionControlType,
  type ConditionNode,
  type LookupOption,
} from './types';

/**
 * Recursive AND/OR condition-group builder — port of the Angular Rule Editor's
 * `rowsTpl`/`conditionItemTpl` templates (new-rule.component.ts). A bracket
 * (GroupConditionRow) contains an ordered list of rows, each either a single
 * condition or another group — brackets nest to arbitrary depth, e.g.
 * (A AND B) OR (C AND D). The same recursive component renders every level.
 *
 * Its three dropdowns (parameter, operator, value) come from the configuration
 * catalog supplied through {@link ConditionCatalogContext}; nothing is hardcoded.
 */

/** The condition catalog the builder renders from — provided by the page that hosts it. */
export const ConditionCatalogContext = createContext<ConditionCatalog>(EMPTY_CONDITION_CATALOG);

let idCounter = 0;
function newId(prefix: string): string {
  idCounter += 1;
  return `${prefix}-${idCounter}`;
}

export interface ConditionItem {
  id: string;
  field: string;
  operator: string;
  value: string;
  /** Second bound, used only when operator is Between. */
  valueTo?: string;
}

export interface SingleConditionRow {
  kind: 'single';
  id: string;
  condition: ConditionItem;
}

export interface GroupConditionRow {
  kind: 'group';
  id: string;
  groupOperator: 'AND' | 'OR';
  items: ConditionRow[];
}

export type ConditionRow = SingleConditionRow | GroupConditionRow;

export function newConditionItem(): ConditionItem {
  return { id: newId('cond'), field: '', operator: '', value: '' };
}

export function newSingleRow(): SingleConditionRow {
  return { kind: 'single', id: newId('row'), condition: newConditionItem() };
}

export function newGroupRow(): GroupConditionRow {
  return { kind: 'group', id: newId('row'), groupOperator: 'AND', items: [newSingleRow()] };
}

/** Total leaf conditions across every row/group, at any nesting depth. */
export function countConditionRows(rows: ConditionRow[]): number {
  return rows.reduce((sum, row) => sum + (row.kind === 'single' ? 1 : countConditionRows(row.items)), 0);
}

function formatConditionValue(c: ConditionItem, catalog: ConditionCatalog): string | null {
  const arity = getOperatorArity(catalog, c.operator, c.field);
  if (arity === 'NONE') return null;
  if (!c.value) return '?';
  if (arity === 'RANGE' && c.valueTo) return `${c.value} - ${c.valueTo}`;
  if (arity === 'MULTI') return `(${c.value})`;
  const def = getConditionFieldDef(catalog, c.field);
  return def?.controlType === 'boolean' ? getValueLabel(def, c.value) : c.value;
}

function formatConditionItem(c: ConditionItem, catalog: ConditionCatalog): string {
  const value = formatConditionValue(c, catalog);
  return `${c.field || '?'} ${c.operator || '?'}${value === null ? '' : ` ${value}`}`;
}

function formatRow(row: ConditionRow, catalog: ConditionCatalog): string {
  if (row.kind === 'single') return formatConditionItem(row.condition, catalog);
  const inner = formatRows(row.items, row.groupOperator, catalog);
  return row.items.length > 1 ? `(${inner})` : inner;
}

function formatRows(rows: ConditionRow[], operator: 'AND' | 'OR', catalog: ConditionCatalog): string {
  return rows.map((row) => formatRow(row, catalog)).join(` ${operator} `);
}

/** Live text preview of the whole condition set — port of getConditionPreview(). */
export function formatConditionPreview(rows: ConditionRow[], rootOperator: 'AND' | 'OR', catalog: ConditionCatalog = EMPTY_CONDITION_CATALOG): string {
  if (rows.length === 0) return 'No conditions';
  return formatRows(rows, rootOperator, catalog);
}

/** Every distinct condition field used anywhere in the rows — e.g. to find conditions a newly chosen Rule Type no longer offers. */
export function collectConditionFields(rows: ConditionRow[]): string[] {
  const fields = rows.flatMap((row) => (row.kind === 'single' ? [row.condition.field] : collectConditionFields(row.items)));
  return [...new Set(fields.filter(Boolean))];
}

/** The rows without any condition on the given fields; a group left empty is dropped with them. */
export function removeConditionFields(rows: ConditionRow[], fields: ReadonlySet<string>): ConditionRow[] {
  return rows.flatMap((row): ConditionRow[] => {
    if (row.kind === 'single') return fields.has(row.condition.field) ? [] : [row];
    const items = removeConditionFields(row.items, fields);
    return items.length === 0 ? [] : [{ ...row, items }];
  });
}

function itemToNode(item: ConditionItem): ConditionNode | null {
  if (!item.field || !item.operator) return null;
  const hasValue = item.value !== '' && item.value != null;
  const hasValueTo = item.valueTo !== '' && item.valueTo != null;
  return {
    type: 'condition',
    field: item.field,
    operator: item.operator,
    value: hasValue ? String(item.value) : '',
    valueTo: hasValueTo ? String(item.valueTo) : undefined,
  };
}

function rowToNode(row: ConditionRow): ConditionNode | null {
  if (row.kind === 'single') return itemToNode(row.condition);
  const children = row.items.map(rowToNode).filter((n): n is ConditionNode => n !== null);
  if (children.length === 0) return null;
  if (children.length === 1) return children[0]; // a group left with only one valid member collapses to that member
  return { type: 'group', operator: row.groupOperator, children };
}

/** Builds the API's recursive ConditionNode tree from the row/group model — port of buildConditionTree(). */
export function conditionRowsToTree(rows: ConditionRow[], rootOperator: 'AND' | 'OR'): ConditionNode | null {
  const nodes = rows.map(rowToNode).filter((n): n is ConditionNode => n !== null);
  if (nodes.length === 0) return null;
  if (nodes.length === 1) return nodes[0]; // no redundant wrapping group for a single row
  return { type: 'group', operator: rootOperator, children: nodes };
}

function mapLeafToItem(leaf: Extract<ConditionNode, { type: 'condition' }>): ConditionItem {
  return { id: newId('cond'), field: leaf.field, operator: leaf.operator, value: leaf.value, valueTo: leaf.valueTo ?? undefined };
}

function mapNodeToRow(node: ConditionNode): ConditionRow {
  if (node.type === 'condition') {
    return { kind: 'single', id: newId('row'), condition: mapLeafToItem(node) };
  }
  return {
    kind: 'group',
    id: newId('row'),
    groupOperator: node.operator === 'OR' ? 'OR' : 'AND',
    items: node.children.map(mapNodeToRow),
  };
}

/**
 * Converts a saved condition tree back into the row/group model — port of
 * mapConditionTreeToRows(). A rule saved by this builder always has a root
 * group whose children are either bare leaves or one-level groups; a tree
 * with deeper nesting (not producible by this UI, but not precluded by the
 * data model) still round-trips via the same recursive mapNodeToRow.
 */
export function conditionTreeToRows(tree: ConditionNode | null): { rows: ConditionRow[]; rootOperator: 'AND' | 'OR' } {
  if (!tree) return { rows: [], rootOperator: 'AND' };
  if (tree.type === 'condition') {
    return { rows: [{ kind: 'single', id: newId('row'), condition: mapLeafToItem(tree) }], rootOperator: 'AND' };
  }
  return { rows: tree.children.map(mapNodeToRow), rootOperator: tree.operator === 'OR' ? 'OR' : 'AND' };
}

function splitMultiValue(value: string): string[] {
  return value ? value.split(',').map((v) => v.trim()).filter(Boolean) : [];
}

/** Field + Operator + dynamic Value control for one condition item. */
function ConditionItemFields({ item, onChange }: { item: ConditionItem; onChange: (item: ConditionItem) => void }) {
  const catalog = useContext(ConditionCatalogContext);
  const def = getConditionFieldDef(catalog, item.field);
  const controlType: ConditionControlType = def?.controlType ?? 'text';
  const operatorDefs = def?.operators ?? [];
  const arity = getOperatorArity(catalog, item.operator, item.field);
  const isMulti = arity === 'MULTI';
  const values: LookupOption[] = def?.values ?? [];

  // Active parameters, grouped — plus the stored one, labelled (inactive), if it has been retired.
  const fieldOptions = useMemo(() => {
    const options = catalog.groups.flatMap((g) =>
      g.fields.filter((f) => f.isActive).map((f) => ({ label: f.label, value: f.field, group: g.label })),
    );
    if (item.field && !options.some((o) => o.value === item.field)) {
      options.push({ label: `${def?.label ?? item.field} (inactive)`, value: item.field, group: def?.group ?? '' });
    }
    return options;
  }, [catalog, item.field, def]);

  function onFieldChange(field: string) {
    const next = getConditionFieldDef(catalog, field);
    onChange({ ...item, field, operator: next?.operators.find((o) => o.isActive)?.code ?? '', value: '', valueTo: undefined });
  }

  function onOperatorChange(operator: string) {
    const nextArity = getOperatorArity(catalog, operator, item.field);
    const multiChanged = (arity === 'MULTI') !== (nextArity === 'MULTI');
    onChange({
      ...item,
      operator,
      value: nextArity === 'NONE' || multiChanged ? '' : item.value,
      valueTo: nextArity === 'RANGE' ? item.valueTo : undefined,
    });
  }

  const inputType = controlType === 'number' ? 'number' : controlType === 'time' ? 'time' : 'text';

  return (
    // Fixed column template: Field | Operator | Value. Every row gets the same widths whatever it holds,
    // so a newly added (empty) row lines up with the filled ones above it.
    <div className="grid min-w-0 flex-1 grid-cols-[minmax(150px,1.2fr)_minmax(120px,0.8fr)_minmax(150px,1.6fr)] items-start gap-1.5">
      <div className="min-w-0">
        <Select placeholder="Field…" value={item.field} onValueChange={onFieldChange} options={fieldOptions} />
      </div>
      <div className="min-w-0">
        <Select
          placeholder="Op…"
          value={item.operator}
          onValueChange={onOperatorChange}
          options={selectableOptions(
            operatorDefs.map((o) => ({ code: o.code, label: o.label, isActive: o.isActive })),
            item.operator,
          )}
          disabled={!item.field}
        />
      </div>

      {/* Dynamic third control: the parameter's control type and the operator's arity decide it. No value for IS EMPTY / IS NOT EMPTY (the column stays, empty). */}
      <div className="flex min-w-0 items-start gap-1.5">
        {arity !== 'NONE' && (controlType === 'select' || controlType === 'boolean') && isMulti && (
          <div className="min-w-0 flex-1">
            <RichSelect
              placeholder="Select values…"
              options={selectableOptions(values, splitMultiValue(item.value))}
              value={splitMultiValue(item.value)}
              onChange={(selected) => onChange({ ...item, value: selected.join(', ') })}
            />
          </div>
        )}
        {arity !== 'NONE' && (controlType === 'select' || controlType === 'boolean') && !isMulti && (
          <div className="min-w-0 flex-1">
            <Select
              placeholder="Select…"
              value={item.value}
              onValueChange={(value) => onChange({ ...item, value })}
              options={selectableOptions(values, item.value)}
            />
          </div>
        )}
        {arity !== 'NONE' && (controlType === 'number' || controlType === 'time' || controlType === 'text') && (
          <>
            {/* Input renders its own wrapper div, so the column width is set on this container. */}
            <div className="min-w-0 flex-1">
              <Input
                type={inputType}
                className="w-full"
                placeholder={controlType === 'time' ? undefined : 'Value…'}
                value={item.value}
                onChange={(e) => onChange({ ...item, value: e.target.value })}
              />
            </div>
            {arity === 'RANGE' && (
              <>
                <span className="self-center text-sm text-[var(--text-muted)]">–</span>
                <div className="min-w-0 flex-1">
                  <Input
                    type={inputType}
                    className="w-full"
                    placeholder={controlType === 'time' ? undefined : 'To…'}
                    value={item.valueTo ?? ''}
                    onChange={(e) => onChange({ ...item, valueTo: e.target.value })}
                  />
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export interface ConditionGroupBuilderProps {
  rows: ConditionRow[];
  onChange: (rows: ConditionRow[]) => void;
}

/** The recursive row-list renderer — a group's own `items` are rendered by the
 *  same component, so brackets nest to arbitrary depth. */
export function ConditionGroupBuilder({ rows, onChange }: ConditionGroupBuilderProps) {
  function updateRow(index: number, row: ConditionRow) {
    onChange(rows.map((r, i) => (i === index ? row : r)));
  }
  function removeRow(index: number) {
    onChange(rows.filter((_, i) => i !== index));
  }

  return (
    <div className="flex flex-col gap-2">
      {rows.map((row, index) => (
        <div key={row.id}>
          {row.kind === 'single' ? (
            <div className="flex items-start gap-1.5">
              <ConditionItemFields item={row.condition} onChange={(condition) => updateRow(index, { ...row, condition })} />
              <Button className='btn-tertiary h-38px'  onClick={() => removeRow(index)} title="Remove condition">
                <X size={14} />
              </Button>
            </div>
          ) : (
            <div className="flex flex-col gap-1.5 rounded-md border border-dashed border-[var(--accent)] p-2.5">
              <div className="flex items-center gap-1.5 text-xs text-[var(--text-muted)]">
                <Braces size={13} className="text-[var(--accent)]" />
                <span>Group — match</span>
                <select
                  className="input-cls"
                  value={row.groupOperator}
                  onChange={(e) => updateRow(index, { ...row, groupOperator: e.target.value as 'AND' | 'OR' })}
                >
                  <option value="AND">ALL (AND)</option>
                  <option value="OR">ANY (OR)</option>
                </select>
                <span>of:</span>
                <Button className="ml-auto btn-tertiary h-38px" onClick={() => removeRow(index)} title="Remove group">
                  <X size={14} />
                </Button>
              </div>
              {row.items.length === 0 && (
                <span className="text-[10px] italic text-[var(--text-muted)]">No conditions in this group yet</span>
              )}
              <ConditionGroupBuilder rows={row.items} onChange={(items) => updateRow(index, { ...row, items })} />
              <div className="flex gap-1.5">
                <Button className='btn-tertiary-filled' size="sm" onClick={() => updateRow(index, { ...row, items: [...row.items, newSingleRow()] })}>
                  <Plus size={12} /> Condition
                </Button>
                <Button className='btn-tertiary-filled' size="sm" onClick={() => updateRow(index, { ...row, items: [...row.items, newGroupRow()] })}>
                  <Braces size={12} /> Sub-group
                </Button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

/** Header row exposing "+ Condition"/"+ Group" for the top-level rows array,
 *  plus the "combine all rows with AND/OR" selector shown when there is more
 *  than one top-level row (Angular's root-operator-row). */
export function ConditionBuilderToolbar({
  rows,
  onChange,
  rootOperator,
  onRootOperatorChange,
}: {
  rows: ConditionRow[];
  onChange: (rows: ConditionRow[]) => void;
  rootOperator: 'AND' | 'OR';
  onRootOperatorChange: (operator: 'AND' | 'OR') => void;
}) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-1.5">
        <Button className='btn-tertiary-filled' size="sm" onClick={() => onChange([...rows, newSingleRow()])}>
          <Plus size={12} /> Condition
        </Button>
        <Button className='btn-tertiary-filled' size="sm" onClick={() => onChange([...rows, newGroupRow()])}>
          <Braces size={12} /> Group
        </Button>
      </div>
      {rows.length > 1 && (
        <div className="flex items-center gap-2 text-xs text-[var(--text-muted)]">
          <span>Combine all rows with:</span>
          <select
            className={cn('input-cls')}
            value={rootOperator}
            onChange={(e) => onRootOperatorChange(e.target.value as 'AND' | 'OR')}
          >
            <option value="AND">AND</option>
            <option value="OR">OR</option>
          </select>
        </div>
      )}
    </div>
  );
}

/** Placeholder empty state, matching the Angular "no conditions" hint. */
export function ConditionBuilderEmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="flex flex-col items-center gap-2 py-6 text-center text-[var(--text-muted)]">
      <p className="text-sm font-medium">No conditions defined</p>
      <span className="text-xs">Rule will apply to all transactions</span>
      <Button className='btn-secondary' size="sm" onClick={onAdd}>
        Add Condition
      </Button>
    </div>
  );
}
