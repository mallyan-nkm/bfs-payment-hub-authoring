import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { ConditionCatalogContext, ConditionGroupBuilder, formatConditionPreview, type ConditionRow } from '../ConditionGroupBuilder';
import { toConditionCatalog } from '../types';
import { CONDITION_CATALOG } from './fixtures';

const catalog = toConditionCatalog(CONDITION_CATALOG);

const row = (field: string, operator: string, value: string, valueTo?: string): ConditionRow => ({
  kind: 'single',
  id: `row-${field}`,
  condition: { id: `cond-${field}`, field, operator, value, valueTo },
});

function renderRows(rows: ConditionRow[]) {
  return render(
    <ConditionCatalogContext.Provider value={catalog}>
      <ConditionGroupBuilder rows={rows} onChange={() => undefined} />
    </ConditionCatalogContext.Provider>,
  );
}

describe('ConditionGroupBuilder', () => {
  it('renders the parameter, operator and value labels from the catalog', () => {
    renderRows([row('IsHoliday', 'Equals', 'true')]);

    expect(screen.getByText('Is Holiday')).toBeInTheDocument();
    expect(screen.getByText('= (Equals)')).toBeInTheDocument();
    expect(screen.getByText('Yes')).toBeInTheDocument();
  });

  it('keeps a value retired since the rule was saved, labelled (inactive)', () => {
    renderRows([row('Currency', 'Equals', 'JPY')]);
    expect(screen.getByText('JPY (inactive)')).toBeInTheDocument();
  });

  it('shows no value input for IS EMPTY and a second input for BETWEEN', () => {
    const { unmount } = renderRows([row('Amount', 'IsNull', '')]);
    expect(screen.queryByPlaceholderText('Value…')).toBeNull();
    unmount();

    renderRows([row('Amount', 'Between', '10', '20')]);
    expect(screen.getByPlaceholderText('Value…')).toHaveValue(10);
    expect(screen.getByPlaceholderText('To…')).toHaveValue(20);
  });

  it('previews by arity: ranges, lists, booleans and value-less operators', () => {
    expect(formatConditionPreview([row('Amount', 'Between', '10', '20'), row('Currency', 'In', 'AED, USD')], 'AND', catalog))
      .toBe('Amount Between 10 - 20 AND Currency In (AED, USD)');
    expect(formatConditionPreview([row('IsHoliday', 'Equals', 'false'), row('Amount', 'IsNotNull', '')], 'OR', catalog))
      .toBe('IsHoliday Equals No OR Amount IsNotNull');
  });
});
