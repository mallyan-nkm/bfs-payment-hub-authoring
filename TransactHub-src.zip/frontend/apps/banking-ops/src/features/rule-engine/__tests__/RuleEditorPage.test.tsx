/**
 * RuleEditorPage — every option list comes from the metadata API (plan Phase 3). The API
 * modules are mocked with the seeded catalog's responses; the page is driven like a user.
 */
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { RuleEditorPage } from '../RuleEditorPage';
import { CONDITION_CATALOG, RULE_TYPES, actionCatalogDto } from './fixtures';

const api = vi.hoisted(() => ({
  rules: { getById: vi.fn(), create: vi.fn(), update: vi.fn(), testDraft: vi.fn() },
  metadata: { ruleTypes: vi.fn(), conditionCatalog: vi.fn(), actionCatalog: vi.fn(), lookup: vi.fn() },
  messageTypes: vi.fn(),
}));

vi.mock('../api', () => ({ ruleEngineApi: api.rules, ruleMetadataApi: api.metadata }));
vi.mock('../../charges/api', () => ({ chargeConfigApi: { getMessageTypes: api.messageTypes } }));
// Rail gating (rail:<CODE>:access) is not what these tests exercise: the test user may use every rail.
vi.mock('../../../shared/auth/rails', () => ({
  useRailAccess: () => ({ allows: () => true, allowed: ['IPI', 'FTS', 'WPS', 'NPSS', 'EDDA', 'CBFT'] }),
}));
vi.mock('../../../stores/authStore', () => ({
  useAuthStore: (select: (s: unknown) => unknown) => select({ activeTenantId: 'ADIB', user: { username: 'tester' } }),
}));

function renderEditor(path = '/rule-engine/new') {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/rule-engine/new" element={<RuleEditorPage />} />
          <Route path="/rule-engine/edit/:id" element={<RuleEditorPage />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

const ruleTypeSelect = () => screen.getByLabelText('Rule Type *') as HTMLSelectElement;
const openTab = (user: ReturnType<typeof userEvent.setup>, name: RegExp) => user.click(screen.getByRole('tab', { name }));

beforeEach(() => {
  api.metadata.ruleTypes.mockResolvedValue({ data: RULE_TYPES });
  api.metadata.conditionCatalog.mockResolvedValue({ data: CONDITION_CATALOG });
  api.metadata.actionCatalog.mockImplementation((_tenant: string, ruleType: string) => Promise.resolve({ data: actionCatalogDto(ruleType) }));
  api.messageTypes.mockResolvedValue({ data: [] });
});

afterEach(() => {
  vi.clearAllMocks();
  vi.restoreAllMocks();
});

describe('RuleEditorPage — Rule Information', () => {
  it('lists the configured Rule Types, starts on the default one and previews its code prefix', async () => {
    renderEditor();

    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));
    expect(within(ruleTypeSelect()).getAllByRole('option').map((o) => o.textContent)).toEqual(
      ['Routing', 'Charge', 'Workflow', 'Validation', 'Limit', 'Decision', 'WorkflowApproval'],
    );
    expect(screen.getByLabelText('Rule Code')).toHaveValue('Generated on save — CHG-?-NNN');

    const user = userEvent.setup();
    await user.selectOptions(ruleTypeSelect(), 'WorkflowApproval');
    await user.selectOptions(screen.getByLabelText('Domain / Rail *'), 'WPS');
    expect(screen.getByLabelText('Rule Code')).toHaveValue('Generated on save — WFA-WPS-NNN');
  });

  it('shows an error banner and blocks saving when the configuration cannot be loaded', async () => {
    api.metadata.ruleTypes.mockRejectedValue(new Error('down'));
    renderEditor();

    expect(await screen.findByRole('alert')).toHaveTextContent('could not be loaded');
    expect(screen.getByRole('button', { name: /Save Draft/ })).toBeDisabled();
    expect(screen.getByRole('button', { name: /Submit for Approval/ })).toBeDisabled();
  });
});

describe('RuleEditorPage — Actions', () => {
  it.each(['Routing', 'Charge', 'Workflow', 'Validation', 'Limit', 'Decision'])(
    'shows no WorkflowApproval controls for %s',
    async (ruleType) => {
      const user = userEvent.setup();
      renderEditor();
      await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));

      await user.selectOptions(ruleTypeSelect(), ruleType);
      await openTab(user, /Actions/);

      await waitFor(() => expect(screen.queryByText(/Loading available action fields/)).toBeNull());
      expect(screen.queryByLabelText('Workflow Type')).toBeNull();
      expect(screen.queryByLabelText('Level 1 Approver Role')).toBeNull();
    },
  );

  it('renders a generic type’s Dropdown 1 / Dropdown 2 from its action catalog', async () => {
    const user = userEvent.setup();
    renderEditor();
    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));
    await user.selectOptions(ruleTypeSelect(), 'Routing');
    await openTab(user, /Actions/);

    const value = await screen.findByLabelText('Action 1 value');
    expect(screen.getByLabelText('Action 1 field')).toHaveValue('Route.Adapter');
    expect(within(value).getAllByRole('option').map((o) => o.textContent)).toEqual(['BANK_A_IPI_ADAPTER', 'FTS_CORE_ADAPTER']);

    await user.selectOptions(screen.getByLabelText('Action 1 field'), 'Route.Rail');
    expect(within(screen.getByLabelText('Action 1 value')).getAllByRole('option').map((o) => o.textContent)).toEqual(['IPP', 'IPI', 'Swift']);
  });

  it('toggles the Charge dependent fields by Charge Action Type and Result Type', async () => {
    const user = userEvent.setup();
    renderEditor();
    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));
    await openTab(user, /Actions/);

    const chargeType = await screen.findByLabelText('Charge Action Type *');
    expect(within(chargeType).queryByRole('option', { name: /Fetch Preferential/ })).toBeNull(); // seeded inactive (Q4)

    await user.selectOptions(chargeType, 'Discount');
    expect(screen.getByRole('button', { name: /Fixed Amount/ })).toHaveAttribute('aria-pressed', 'true');
    expect(screen.getByLabelText('Currency')).toHaveValue('AED');
    expect(screen.getByLabelText('Minimum Charge')).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: /Percentage/ }));
    expect(screen.queryByLabelText('Currency')).toBeNull();
    expect(screen.getByLabelText('Percentage *')).toBeInTheDocument();

    await user.selectOptions(chargeType, 'Waiver');
    expect(screen.queryByLabelText('Minimum Charge')).toBeNull();

    await user.selectOptions(chargeType, 'Override');
    expect(screen.getByText('Fixed Charges (AED)')).toBeInTheDocument();
    expect(screen.getByText('Variable Charges (%)')).toBeInTheDocument();
    expect(screen.getByLabelText('VAT Percent')).toBeInTheDocument();
  });

  it('submits E1 as the rev-6 action list: Workflow Type and the levels only', async () => {
    const user = userEvent.setup();
    api.rules.create.mockResolvedValue({ data: { ruleName: 'E1', ruleCode: 'WFA-WPS-001', versionNo: 1 } });
    renderEditor();
    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));

    await user.type(screen.getByLabelText('Rule Name *'), 'E1');
    await user.selectOptions(ruleTypeSelect(), 'WorkflowApproval');
    await user.selectOptions(screen.getByLabelText('Domain / Rail *'), 'WPS');
    await openTab(user, /Actions/);

    expect(screen.queryByLabelText('Workflow Mode')).toBeNull();
    expect(screen.queryByLabelText('File Type')).toBeNull();
    await user.selectOptions(await screen.findByLabelText('Workflow Type'), 'Parallel');
    await user.selectOptions(screen.getByLabelText('Level 1 Approver Role'), 'Maker');
    await user.click(screen.getByRole('button', { name: 'Add Level' }));
    await user.selectOptions(screen.getByLabelText('Level 2 Approver Role'), 'Checker');
    await user.click(screen.getByRole('button', { name: 'Add Level' }));
    await user.selectOptions(screen.getByLabelText('Level 3 Approver Role'), 'SuperAdmin');

    await user.click(screen.getByRole('button', { name: /Submit for Approval/ }));

    await waitFor(() => expect(api.rules.create).toHaveBeenCalledTimes(1));
    const request = api.rules.create.mock.calls[0][0];
    expect(request).toMatchObject({ ruleType: 'WorkflowApproval', rail: 'WPS', ruleStatus: 'Active', chargeActionType: undefined });
    expect(request.actions).toEqual([
      { field: 'WorkflowApproval.ProcessingMode', value: 'APPROVAL_LEVELS' },
      { field: 'WorkflowApproval.Type', value: 'Parallel' },
      { field: 'WorkflowApproval.ApproverRole', value: 'Maker', sequence: 1 },
      { field: 'WorkflowApproval.ApproverRole', value: 'Checker', sequence: 2 },
      { field: 'WorkflowApproval.ApproverRole', value: 'SuperAdmin', sequence: 3 },
    ]);
  });

  it('shows only the Rule Information, Conditions and Actions tabs — Summary and Test Rule are hidden', async () => {
    renderEditor();
    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));

    const tabs = within(screen.getByRole('tablist', { name: 'Rule editor tabs' })).getAllByRole('tab').map((t) => t.textContent);
    expect(tabs).toEqual(['1. Rule Information', '2. Conditions', '3. Actions']);
  });

  it('opens a new WorkflowApproval rule as Levels of Approval, and submits an STP rule with no type or levels', async () => {
    const user = userEvent.setup();
    api.rules.create.mockResolvedValue({ data: { ruleName: 'STP', ruleCode: 'WFA-WPS-009', versionNo: 1 } });
    renderEditor();
    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));

    await user.type(screen.getByLabelText('Rule Name *'), 'STP');
    await user.selectOptions(ruleTypeSelect(), 'WorkflowApproval');
    await user.selectOptions(screen.getByLabelText('Domain / Rail *'), 'WPS');
    await openTab(user, /Actions/);

    expect(await screen.findByRole('radio', { name: 'Levels of Approval' })).toBeChecked();
    await user.selectOptions(screen.getByLabelText('Level 1 Approver Role'), 'Maker');

    await user.click(screen.getByRole('radio', { name: 'STP (Straight Through Processing)' }));
    expect(screen.queryByLabelText('Workflow Type')).toBeNull();
    expect(screen.queryByLabelText('Level 1 Approver Role')).toBeNull();
    expect(screen.getByTestId('stp-notice')).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: /Submit for Approval/ }));

    await waitFor(() => expect(api.rules.create).toHaveBeenCalledTimes(1));
    expect(api.rules.create.mock.calls[0][0].actions).toEqual([{ field: 'WorkflowApproval.ProcessingMode', value: 'STP' }]);
  });

  it('moves a legacy rule’s Mode / File Type actions into its conditions, and saves the rev-6 shape', async () => {
    api.rules.getById.mockResolvedValue({
      data: {
        ruleId: 7, ruleName: 'WPS payment approvals', ruleType: 'WorkflowApproval', rail: 'WPS', priority: 1, ruleStatus: 'Active',
        effectiveFrom: '2026-01-01T00:00:00Z',
        conditionTree: { type: 'condition', field: 'Amount', operator: 'GreaterThan', value: '25000' },
        actions: [
          { field: 'WorkflowApproval.Mode', value: 'Outward' },
          { field: 'WorkflowApproval.Type', value: 'Sequential' },
          { field: 'WorkflowApproval.FileType', value: 'PAYMENT_WORKFLOW', group: 'PAYMENT_WORKFLOW' },
          { field: 'WorkflowApproval.ApproverRole', value: 'Maker', group: 'PAYMENT_WORKFLOW', sequence: 1 },
          { field: 'WorkflowApproval.ApproverRole', value: 'Checker', group: 'PAYMENT_WORKFLOW', sequence: 2 },
          { field: 'WorkflowApproval.TotalApprovalLevels', value: '2' },
        ],
      },
    });
    api.rules.update.mockResolvedValue({ data: { ruleName: 'WPS payment approvals', ruleCode: 'WFA-WPS-001', versionNo: 2 } });
    const user = userEvent.setup();
    renderEditor('/rule-engine/edit/7');

    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('WorkflowApproval'));
    await openTab(user, /Actions/);
    expect(await screen.findByLabelText('Workflow Type')).toHaveValue('Sequential');
    expect(screen.getByTestId('workflow-approval-preview')).toHaveTextContent('Payment Workflow · Outward · Sequential');

    await user.click(screen.getByRole('button', { name: /Update Rule/ }));

    await waitFor(() => expect(api.rules.update).toHaveBeenCalledTimes(1));
    const request = api.rules.update.mock.calls[0][1];
    expect(request.conditionTree).toEqual({
      type: 'group',
      operator: 'AND',
      children: [
        { type: 'condition', field: 'FileType', operator: 'Equals', value: 'PAYMENT_WORKFLOW' },
        { type: 'condition', field: 'Direction', operator: 'Equals', value: 'Outward' },
        { type: 'condition', field: 'Amount', operator: 'GreaterThan', value: '25000' },
      ],
    });
    expect(request.actions).toEqual([
      { field: 'WorkflowApproval.ProcessingMode', value: 'APPROVAL_LEVELS' },
      { field: 'WorkflowApproval.Type', value: 'Sequential' },
      { field: 'WorkflowApproval.ApproverRole', value: 'Maker', sequence: 1 },
      { field: 'WorkflowApproval.ApproverRole', value: 'Checker', sequence: 2 },
    ]);
  });

  it('asks before switching away from WorkflowApproval, and clears the matrix when confirmed', async () => {
    const user = userEvent.setup();
    const confirm = vi.spyOn(window, 'confirm');
    renderEditor();
    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Charge'));
    await user.selectOptions(ruleTypeSelect(), 'WorkflowApproval');
    await openTab(user, /Actions/);
    await user.selectOptions(await screen.findByLabelText('Workflow Type'), 'Parallel');
    await openTab(user, /Rule Information/);

    confirm.mockReturnValueOnce(false);
    await user.selectOptions(ruleTypeSelect(), 'Routing');
    expect(confirm).toHaveBeenCalledTimes(1);
    expect(ruleTypeSelect()).toHaveValue('WorkflowApproval');

    confirm.mockReturnValueOnce(true);
    await user.selectOptions(ruleTypeSelect(), 'Routing');
    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Routing'));

    await user.selectOptions(ruleTypeSelect(), 'WorkflowApproval');
    await openTab(user, /Actions/);
    expect(await screen.findByLabelText('Workflow Type')).toHaveValue('');
  });

  it('keeps a retired value of an existing rule, labelled (inactive)', async () => {
    api.rules.getById.mockResolvedValue({
      data: {
        ruleId: 5, ruleName: 'Old routing', ruleType: 'Routing', rail: 'IPI', priority: 3, ruleStatus: 'Active',
        effectiveFrom: '2026-01-01T00:00:00Z', conditionTree: null, actions: [{ field: 'Route.Adapter', value: 'OLD_ADAPTER' }],
      },
    });
    const user = userEvent.setup();
    renderEditor('/rule-engine/edit/5');

    await waitFor(() => expect(ruleTypeSelect()).toHaveValue('Routing'));
    await openTab(user, /Actions/);

    const value = await screen.findByLabelText('Action 1 value');
    expect(value).toHaveValue('OLD_ADAPTER');
    expect(within(value).getByRole('option', { name: 'OLD_ADAPTER (inactive)' })).toBeInTheDocument();
  });
});
