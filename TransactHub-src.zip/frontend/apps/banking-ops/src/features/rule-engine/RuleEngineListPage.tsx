import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Copy, Eye, Pause, Pencil, Play, Plus, RefreshCw, Trash2 } from 'lucide-react';
import { Badge, Button, Can, Dialog, PageBody, PageHeader, PageShell, SmartGrid, usePermissions, useSessionDateTime } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import type { SmartGridColumn } from '@paymenthub/ui';
import { useAuthStore } from '../../stores/authStore';
import { ruleEngineApi } from './api';
import { useRuleTypes } from './useRuleMetadata';
import { actionsToApprovalMatrix } from './workflowApproval';
import { formatConditionTree, summarizeOverrideBreakdown } from './types';
import type { ApprovalMatrix, ChargeRuleDetail, ChargeRuleListItem } from './types';
import { useRailAccess } from '../../shared/auth/rails';

/**
 * Rules List — port of the Angular admin-portal's RulesListComponent
 * (frontend/admin-portal/src/app/views/ops-console/rules/rules-list.component.ts).
 * "Rule Engine POC": manage charge-calculation rules (condition-based pricing,
 * rule evaluation engine).
 *
 * Grid built on SmartGrid — this app's Common Grid Standard (the same primitive
 * behind the SIF Summary 360 record list) — for column-level filters, sorting,
 * show/hide + drag-to-reorder columns, and pagination, instead of a bespoke table.
 */

const RAIL_OPTIONS = [
  { label: 'All Rails', value: '' },
  { label: 'IPI', value: 'IPI' },
  { label: 'FTS', value: 'FTS' },
  { label: 'WPS', value: 'WPS' },
  { label: 'NPSS', value: 'NPSS' },
  { label: 'SWIFT', value: 'SWIFT' },
  { label: 'ALL', value: 'ALL' },
];

const STATUS_OPTIONS = [
  { label: 'All Status', value: '' },
  { label: 'Active', value: 'Active' },
  { label: 'Inactive', value: 'Inactive' },
  { label: 'Draft', value: 'Draft' },
  { label: 'Pending', value: 'Pending' },
  { label: 'Rejected', value: 'Rejected' },
];

const STATUS_BADGE_VARIANT: Record<string, 'green' | 'default' | 'amber' | 'blue' | 'red'> = {
  Active: 'green',
  Inactive: 'default',
  Draft: 'amber',
  Pending: 'blue',
  Rejected: 'red',
};

function formatResultAction(r: ChargeRuleListItem): string {
  const matrix = actionsToApprovalMatrix(r.actions);
  if (matrix) {
    if (matrix.isStp) return [matrix.mode, 'STP (Straight Through Processing)'].filter(Boolean).join(' · ');
    const levels = matrix.fileTypes.map((f) => [f.fileType, f.levels.map((l) => `L${l.level} ${l.role}`).join(' → ')].filter(Boolean).join(': '));
    return [[matrix.mode, matrix.type].filter(Boolean).join(' · '), ...levels].filter(Boolean).join(' · ');
  }
  if (r.ruleType !== 'Charge' || !r.chargeActionType) {
    // The 5 non-Charge Rule Types carry their action list generically (FSD Section 14.1).
    if (r.actions.length > 0) return r.actions.map((a) => `${a.field} = ${a.value}`).join(', ');
    return `— (${r.ruleType} rule)`;
  }
  if (r.chargeActionType === 'FetchPreferentialCharge') return 'Fetch Preferential Charge';
  const value = r.overrideCharge != null
    ? `${r.overrideCharge.toFixed(2)} AED`
    : r.percentageCharge != null
      ? `${r.percentageCharge}%`
      : (r.chargeActionType === 'Override' ? summarizeOverrideBreakdown(r.actions) : '') || '—';
  switch (r.chargeActionType) {
    case 'Override': return `Charge = ${value}`;
    case 'Discount': return `Discount = ${value}`;
    case 'Surcharge': return `Surcharge = ${value}`;
    case 'Waiver': return `Waive = ${value}`;
    default: return value;
  }
}

function priorityTone(priority: number): 'red' | 'amber' | 'blue' {
  if (priority <= 2) return 'red';
  if (priority <= 5) return 'amber';
  return 'blue';
}

export function RuleEngineListPage() {
  // Effective dates are calendar dates (sent as yyyy-MM-dd, never converted); created / modified are instants.
  const { formatInstant, formatCalendarDate } = useSessionDateTime();
  const { allows: allowsRail } = useRailAccess();
  const navigate = useNavigate();
  const tenantId = useAuthStore((s) => s.activeTenantId);
  const currentUser = useAuthStore((s) => s.user);
  const queryClient = useQueryClient();
  const { can } = usePermissions();
  const canExport = can(PERM.opsReportExport);

  const [viewRule, setViewRule] = useState<ChargeRuleListItem | null>(null);
  const [viewDetail, setViewDetail] = useState<ChargeRuleDetail | null>(null);

  // Every configured Rule Type, retired ones included, so a rule of a since-deactivated type stays filterable.
  const ruleTypes = useRuleTypes(tenantId);
  const ruleTypeFilterOptions = ruleTypes.map((t) => ({ label: t.ruleTypeName, value: t.ruleTypeCode }));
  const ruleTypeName = (code: string) => ruleTypes.find((t) => t.ruleTypeCode === code)?.ruleTypeName ?? code;

  const rulesQuery = useQuery({
    queryKey: ['rule-engine', 'rules', tenantId],
    queryFn: () => ruleEngineApi.list(tenantId!).then((r) => r.data),
    enabled: Boolean(tenantId),
  });

  const rules = useMemo(
    () => (rulesQuery.data ?? []).filter((r) => r.isCurrentVersion),
    [rulesQuery.data],
  );

  // Default row order — priority ascending. SmartGrid keeps this order until the
  // operator activates a column sort; its own filters/sort/pagination take it from here.
  const sortedRules = useMemo(() => [...rules].sort((a, b) => a.priority - b.priority), [rules]);

  const toggleStatus = useMutation({
    mutationFn: (rule: ChargeRuleListItem) => {
      const newStatus = rule.ruleStatus === 'Active' ? 'Inactive' : 'Active';
      const modifiedBy = currentUser?.username || 'system';
      return ruleEngineApi.updateStatus(rule.ruleId, newStatus, modifiedBy);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['rule-engine', 'rules', tenantId] }),
  });

  const deleteRule = useMutation({
    mutationFn: (rule: ChargeRuleListItem) => ruleEngineApi.remove(rule.ruleId, currentUser?.username || 'system'),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['rule-engine', 'rules', tenantId] }),
  });

  function openView(rule: ChargeRuleListItem) {
    // Show the row-level summary immediately; enrich with the real condition
    // tree once the detail fetch resolves, avoiding a blank dialog while loading.
    setViewRule(rule);
    setViewDetail(null);
    ruleEngineApi.getById(rule.ruleId).then((res) => setViewDetail(res.data)).catch(() => undefined);
  }

  const columns: SmartGridColumn<ChargeRuleListItem>[] = [
    {
      key: 'ruleName',
      label: 'Rule Name',
      filterKey: 'ruleName',
      filterType: 'text',
      sortKey: 'ruleName',
      wrap: true,
      maxWidth: 220,
      getValue: (row) => `${row.ruleName} ${row.ruleCode}`,
      getSortValue: (row) => row.ruleName,
      render: (row) => (
        <div className="flex flex-col">
          <button className="text-left font-medium text-[var(--accent)] hover:underline" onClick={() => openView(row)}>
            {row.ruleName}
          </button>
          <span className="font-mono text-[10px] text-[var(--text-muted)]">{row.ruleCode}</span>
        </div>
      ),
    },
    {
      key: 'rail',
      label: 'Rail',
      filterKey: 'rail',
      filterType: 'select',
      filterOptions: RAIL_OPTIONS.filter((o) => o.value && allowsRail(o.value)),
      sortKey: 'rail',
      render: (row) => <Badge variant="outline">{row.rail}</Badge>,
    },
    {
      key: 'ruleType',
      label: 'Rule Type',
      filterKey: 'ruleType',
      filterType: 'select',
      filterOptions: ruleTypeFilterOptions,
      sortKey: 'ruleType',
      getValue: (row) => row.ruleType,
      render: (row) => <Badge variant="blue">{ruleTypeName(row.ruleType)}</Badge>,
    },
    {
      key: 'conditionCount',
      label: 'Conditions',
      sortKey: 'conditionCount',
      numeric: true,
      getSortValue: (row) => row.conditionCount,
      render: (row) => <span className="text-xs text-[var(--text-muted)]">{row.conditionCount === 0 ? 'No conditions' : `${row.conditionCount} condition(s)`}</span>,
    },
    {
      key: 'priority',
      label: 'Priority',
      sortKey: 'priority',
      numeric: true,
      getSortValue: (row) => row.priority,
      render: (row) => <Badge variant={priorityTone(row.priority)}>{row.priority}</Badge>,
    },
    {
      key: 'resultAction',
      label: 'Action',
      wrap: true,
      maxWidth: 260,
      getValue: (row) => formatResultAction(row),
      render: (row) => <span className="font-mono text-xs">{formatResultAction(row)}</span>,
    },
    {
      key: 'ruleStatus',
      label: 'Status',
      filterKey: 'ruleStatus',
      filterType: 'select',
      filterOptions: STATUS_OPTIONS.filter((o) => o.value),
      sortKey: 'ruleStatus',
      render: (row) => <Badge variant={STATUS_BADGE_VARIANT[row.ruleStatus] ?? 'default'}>{row.ruleStatus}</Badge>,
    },
    {
      key: 'versionNo',
      label: 'Ver',
      sortKey: 'versionNo',
      numeric: true,
      getSortValue: (row) => row.versionNo,
      render: (row) => `v${row.versionNo}`,
    },
    {
      key: 'effectiveFrom',
      label: 'Effective Period',
      filterKey: 'effectiveFrom',
      filterType: 'dateRange',
      sortKey: 'effectiveFrom',
      getValue: (row) => row.effectiveFrom,
      getSortValue: (row) => row.effectiveFrom,
      render: (row) => (
        <span className="whitespace-nowrap text-xs">
          {formatCalendarDate(row.effectiveFrom)}
          {row.effectiveTo ? <> → {formatCalendarDate(row.effectiveTo)}</> : <span className="ml-1 text-[var(--text-muted)]">∞</span>}
        </span>
      ),
    },
    {
      key: 'actions',
      label: '',
      locked: true,
      align: 'right',
      render: (row) => (
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="sm" onClick={() => openView(row)} title="View rule details"><Eye size={14} /></Button>
          {/* Edit, Clone, Activate/Deactivate and Delete end in the Rule Engine write group. */}
          <Can permission={PERM.configRuleWrite} mode="disable">
          <Button variant="ghost" size="sm" onClick={() => navigate(`/rule-engine/edit/${row.ruleId}`)} title="Edit rule"><Pencil size={14} /></Button>
          <Button variant="ghost" size="sm" onClick={() => navigate(`/rule-engine/new?clone=${row.ruleId}`)} title="Clone rule"><Copy size={14} /></Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleStatus.mutate(row)}
            title={row.ruleStatus === 'Active' ? 'Deactivate' : 'Activate'}
          >
            {row.ruleStatus === 'Active' ? <Pause size={14} /> : <Play size={14} />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              if (window.confirm(`Are you sure you want to delete rule "${row.ruleName}"?`)) deleteRule.mutate(row);
            }}
            title="Delete rule"
          >
            <Trash2 size={14} className="text-[var(--accent-red)]" />
          </Button>
          </Can>
        </div>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Rules Management"
        subtitle="Manage charge calculation rules · Condition-based pricing · Rule evaluation engine"
        actions={
          <>
            <Can permission={PERM.configRuleWrite} mode="disable">
              <Button variant="primary" size="sm" onClick={() => navigate('/rule-engine/new')}>
                <Plus size={14} /> New Rule
              </Button>
            </Can>
          </>
        }
      />

      <PageBody>
        {!tenantId && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            No tenant context found for the current user — please sign in again.
          </div>
        )}
        {rulesQuery.isError && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            Failed to load rules. Please try again.
          </div>
        )}

        <SmartGrid
          columns={columns}
          rows={sortedRules}
          getRowId={(row) => String(row.ruleId)}
          // v2: the Charge Type column became Rule Type (key ruleType); v1 layouts would append it last.
          storageKey="rule-engine-list-columns-v2"
          loading={rulesQuery.isFetching}
          emptyTitle="No rules found"
          emptyMessage="No rules found matching your criteria."
          // The common export key. Browser-built CSV over rows the grid holds, so presentation only here.
          exportFormats={canExport ? ['csv'] : []}
          exportFilename="rule-engine-rules"
          toolbarExtra={
            <Button unstyled className='btn-tertiary h-38px' onClick={() => rulesQuery.refetch()} title="Refresh rules list">
              <RefreshCw size={14} />
            </Button>
          }
        />
      </PageBody>

      {viewRule && (
        <Dialog open={!!viewRule} onOpenChange={(open) => !open && setViewRule(null)} title={viewRule.ruleName} maxWidth="sm:max-w-2xl"
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setViewRule(null)}>Close</Button>
              <Can permission={PERM.configRuleWrite} mode="disable">
                <Button variant="primary" size="sm" onClick={() => { navigate(`/rule-engine/edit/${viewRule.ruleId}`); setViewRule(null); }}>Edit Rule</Button>
              </Can>
            </>
          }
        >
          <div className="grid grid-cols-2 gap-4 text-sm">
            <DetailItem label="Rule Code"><span className="font-mono">{viewRule.ruleCode}</span></DetailItem>
            <DetailItem label="Rail"><Badge variant="outline">{viewRule.rail}</Badge></DetailItem>
            <DetailItem label="Rule Type">
              <Badge variant="blue">{ruleTypeName(viewRule.ruleType)}</Badge>
            </DetailItem>
            <DetailItem label="Priority"><Badge variant={priorityTone(viewRule.priority)}>{viewRule.priority}</Badge></DetailItem>
            <DetailItem label="Conditions" full>
              <pre className="whitespace-pre-wrap rounded-md bg-[var(--bg-secondary)] p-3 font-mono text-xs">
                {viewDetail ? formatConditionTree(viewDetail.conditionTree) : (viewRule.conditionCount === 0 ? 'No conditions — applies to all transactions' : 'Loading…')}
              </pre>
            </DetailItem>
            <DetailItem label="Result Action" full><span className="font-mono">{formatResultAction(viewRule)}</span></DetailItem>
            {actionsToApprovalMatrix(viewRule.actions) && (
              <DetailItem label="Approval Matrix" full>
                <ApprovalMatrixView matrix={actionsToApprovalMatrix(viewRule.actions, viewDetail?.conditionTree)!} />
              </DetailItem>
            )}
            <DetailItem label="Status"><Badge variant={STATUS_BADGE_VARIANT[viewRule.ruleStatus] ?? 'default'}>{viewRule.ruleStatus}</Badge></DetailItem>
            <DetailItem label="Version">v{viewRule.versionNo}</DetailItem>
            <DetailItem label="Effective From">{formatCalendarDate(viewRule.effectiveFrom)}</DetailItem>
            <DetailItem label="Effective To">{viewRule.effectiveTo ? formatCalendarDate(viewRule.effectiveTo) : 'No end date'}</DetailItem>
            <DetailItem label="Created By">{viewRule.createdBy}</DetailItem>
            <DetailItem label="Created At">{formatInstant(viewRule.createdDate)}</DetailItem>
            <DetailItem label="Last Modified" full>{formatInstant(viewRule.modifiedDate ?? viewRule.createdDate)}</DetailItem>
          </div>
        </Dialog>
      )}
    </PageShell>
  );
}

/** A WorkflowApproval rule's file type, mode (from its conditions), type and level-wise approvers (plan §2A, WA-09). */
function ApprovalMatrixView({ matrix }: { matrix: ApprovalMatrix }) {
  return (
    <div className="flex flex-col gap-1.5 rounded-md bg-[var(--bg-secondary)] p-3 text-xs" data-testid="approval-matrix">
      <div className="font-semibold">{[matrix.mode, matrix.isStp ? 'STP (Straight Through Processing)' : matrix.type].filter(Boolean).join(' · ') || '—'}</div>
      <div>TotalApprovalLevels: {matrix.totalApprovalLevels}</div>
      {matrix.fileTypes.map((f) => (
        <div key={f.fileType ?? 'levels'} className="flex flex-col gap-0.5">
          {f.fileType && <span className="font-mono font-semibold">{f.fileType}</span>}
          {f.levels.map((l) => (
            <span key={l.level} className="pl-3">Level {l.level}: {l.role}</span>
          ))}
        </div>
      ))}
    </div>
  );
}

function DetailItem({ label, full, children }: { label: string; full?: boolean; children: React.ReactNode }) {
  return (
    <div className={full ? 'col-span-2 flex flex-col gap-1' : 'flex flex-col gap-1'}>
      <label className="text-[10px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">{label}</label>
      <div className="text-[var(--text-primary)]">{children}</div>
    </div>
  );
}
