import { ArrowDown, ArrowUp, Info, Plus, Trash2 } from 'lucide-react';
import { selectableOptions, type RuleActionCatalog, type RuleActionFieldDef } from './types';
import {
  WORKFLOW_APPROVAL_FIELDS,
  findField,
  formatApprovalLevels,
  isStp,
  levelLimits,
  optionLabel,
  type WorkflowApprovalForm,
} from './workflowApproval';

/**
 * Actions tab of a WorkflowApproval rule (plan §2A.2, rev 6): the Processing Mode — Levels
 * of Approval (the Workflow Type and the ordered approver levels) or STP (neither; the
 * transaction goes straight through). A rule is one or the other, never both, so the levels
 * are hidden while STP is chosen. File Type and Workflow Mode select the rule, so they
 * are conditions (FileType, Direction) on the Conditions tab. Every option, label,
 * section heading and the level limit come from the action catalog; roles come from
 * platform.Roles. Levels are numbered by position, so adding, removing or reordering
 * always leaves them contiguous (1..N).
 */
export interface WorkflowApprovalActionsEditorProps {
  catalog: RuleActionCatalog;
  value: WorkflowApprovalForm;
  onChange: (value: WorkflowApprovalForm) => void;
  /** The rule's File Type / Mode conditions, for the preview line. */
  selectedBy?: WorkflowApprovalSelection;
  /** Show required-field errors (after a submit attempt). */
  submitted?: boolean;
}

/** Display labels of the conditions a WorkflowApproval rule is selected by. */
export interface WorkflowApprovalSelection {
  fileType?: string;
  mode?: string;
}

const SECTION_HEADING = 'text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]';

export function WorkflowApprovalActionsEditor({ catalog, value, onChange, selectedBy, submitted = false }: WorkflowApprovalActionsEditorProps) {
  const processingModeField = findField(catalog, WORKFLOW_APPROVAL_FIELDS.processingMode);
  const typeField = findField(catalog, WORKFLOW_APPROVAL_FIELDS.type);
  const roleField = findField(catalog, WORKFLOW_APPROVAL_FIELDS.approverRole);
  const { max } = levelLimits(catalog);
  const repeatLabel = roleField?.repeatLabel || 'Level';
  const atMax = value.levels.length >= max;
  const roleLabel = roleField?.label ?? 'Approver Role';

  function setLevels(levels: string[]) {
    onChange({ ...value, levels });
  }

  function moveLevel(index: number, delta: -1 | 1) {
    const target = index + delta;
    if (target < 0 || target >= value.levels.length) return;
    const levels = [...value.levels];
    [levels[index], levels[target]] = [levels[target], levels[index]];
    setLevels(levels);
  }

  const stp = isStp(value);

  return (
    <div className="flex flex-col gap-3">
      <p className="flex items-center gap-2 rounded-md border border-[var(--accent)]/25 bg-[var(--accent)]/5 px-3 py-1.5 text-xs text-[var(--text-secondary)]">
        <Info size={13} className="shrink-0 text-[var(--accent)]" />
        <span>File Type and Workflow Mode (Direction: Outward / Inward) are set on the Conditions tab.</span>
      </p>

      {processingModeField && (
        <ProcessingModeChoice
          field={processingModeField}
          value={value.processingMode}
          submitted={submitted}
          onChange={(processingMode) => onChange({ ...value, processingMode })}
        />
      )}

      {stp ? (
        <div className="grid grid-cols-1 items-start gap-3 lg:grid-cols-[minmax(240px,320px)_minmax(0,1fr)]">
          <Card title="Result Preview">
            <WorkflowApprovalPreview catalog={catalog} value={value} selectedBy={selectedBy} />
          </Card>
          <p className="rounded-md border border-[var(--border)] px-3 py-2 text-xs text-[var(--text-secondary)]" data-testid="stp-notice">
            Transactions matching this rule are processed straight through, with no approval levels. Choose Levels of
            Approval instead to configure approvers.
          </p>
        </div>
      ) : (
      /* Settings + preview on the left, the level list fills the rest — no dead space on wide screens. */
      <div className="grid grid-cols-1 items-start gap-3 lg:grid-cols-[minmax(240px,320px)_minmax(0,1fr)]">
        <div className="flex flex-col gap-3">
          <Card title={typeField?.section ?? 'Workflow Settings'}>
            <ChoiceField field={typeField} label="Workflow Type" value={value.type} submitted={submitted} onChange={(type) => onChange({ ...value, type })} />
          </Card>

          <Card title="Result Preview">
            <WorkflowApprovalPreview catalog={catalog} value={value} selectedBy={selectedBy} />
          </Card>
        </div>

        <Card
          title={`Approval Levels — ${roleLabel} *`}
          aside={max !== Number.MAX_SAFE_INTEGER ? `(${value.levels.length} of max ${max})` : undefined}
        >
          <div className="flex flex-col gap-2">
            {value.levels.map((role, index) => {
              // Every active role is offered at every level: the same role may approve several levels
              // (L2 and L3 both Checker), each assigned to a different user by the approval engine.
              const options = selectableOptions(roleField?.options ?? [], role);
              const levelName = `${repeatLabel} ${index + 1}`;
              return (
                <div key={index} className="grid grid-cols-[64px_minmax(0,1fr)_auto] items-center gap-2" data-testid="approval-level">
                  <span className="inline-flex h-7 items-center justify-center rounded-md bg-[var(--bg-secondary)] text-xs font-semibold text-[var(--text-secondary)]">
                    {levelName}
                  </span>
                  <select
                    className="input-cls"
                    aria-label={`${levelName} ${roleLabel}`}
                    value={role}
                    onChange={(e) => setLevels(value.levels.map((r, i) => (i === index ? e.target.value : r)))}
                  >
                    <option value="" disabled>{roleField?.placeholder ?? 'Select Role'}</option>
                    {options.map((o) => (
                      <option key={o.value} value={o.value}>{o.label}</option>
                    ))}
                  </select>
                  <div className="flex items-center gap-1">
                    <IconButton label={`Move ${levelName} up`} disabled={index === 0} onClick={() => moveLevel(index, -1)}><ArrowUp size={13} /></IconButton>
                    <IconButton label={`Move ${levelName} down`} disabled={index === value.levels.length - 1} onClick={() => moveLevel(index, 1)}><ArrowDown size={13} /></IconButton>
                    <IconButton
                      label={`Remove ${levelName}`}
                      disabled={value.levels.length <= 1}
                      danger
                      onClick={() => setLevels(value.levels.filter((_, i) => i !== index))}
                    >
                      <Trash2 size={13} />
                    </IconButton>
                  </div>
                </div>
              );
            })}
            {submitted && value.levels.some((r) => !r) && (
              <span className="text-xs text-[var(--accent-red)]">Choose an approver role for every level.</span>
            )}
            <button
              type="button"
              onClick={() => setLevels([...value.levels, ''])}
              disabled={atMax}
              className="mt-1 flex w-fit items-center gap-1.5 rounded-md border border-dashed border-[var(--accent)]/50 px-2.5 py-1 text-xs font-semibold text-[var(--accent)] hover:bg-[var(--accent)]/5 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Plus size={13} /> Add {repeatLabel}
            </button>
          </div>
        </Card>
      </div>
      )}
    </div>
  );
}

/**
 * Levels of Approval or STP — a radio pair, so a rule can only ever be one of the two.
 * Options and labels come from the WORKFLOW_PROCESSING_MODE lookup in the action catalog.
 */
function ProcessingModeChoice({
  field,
  value,
  submitted,
  onChange,
}: {
  field: RuleActionFieldDef;
  value: string;
  submitted: boolean;
  onChange: (value: string) => void;
}) {
  return (
    <Card title={field.section ?? 'Processing Mode'}>
      <div role="radiogroup" aria-label={field.label} className="flex flex-wrap items-center gap-x-6 gap-y-2">
        {selectableOptions(field.options ?? [], value).map((o) => (
          <label key={o.value} className="flex cursor-pointer items-center gap-2 text-sm text-[var(--text-primary)]">
            <input
              type="radio"
              name="workflow-approval-processing-mode"
              value={o.value}
              checked={value === o.value}
              onChange={() => onChange(o.value)}
            />
            {o.label}
          </label>
        ))}
      </div>
      {submitted && !value && <span className="mt-1 block text-xs text-[var(--accent-red)]">Choose Levels of Approval or STP.</span>}
    </Card>
  );
}

/** A bordered panel with a compact header bar — keeps the sections visually grouped without extra spacing. */
function Card({ title, aside, children }: { title: string; aside?: string; children: React.ReactNode }) {
  return (
    <section className="overflow-hidden rounded-md border border-[var(--border)]">
      <header className="flex items-center justify-between gap-2 border-b border-[var(--border)] bg-[var(--bg-secondary)] px-3 py-2">
        <h4 className={SECTION_HEADING}>{title}</h4>
        {aside && <span className="text-[11px] text-[var(--text-muted)]">{aside}</span>}
      </header>
      <div className="p-3">{children}</div>
    </section>
  );
}

/** "Payment Workflow · Outward · Sequential", "L1 Maker → L2 Checker", "TotalApprovalLevels: 2" — reused by the Summary tab. */
export function WorkflowApprovalPreview({
  catalog,
  value,
  selectedBy,
}: {
  catalog: RuleActionCatalog | undefined;
  value: WorkflowApprovalForm;
  selectedBy?: WorkflowApprovalSelection;
}) {
  if (isStp(value)) {
    const stpLabel = optionLabel(findField(catalog, WORKFLOW_APPROVAL_FIELDS.processingMode), value.processingMode);
    return (
      <div className="flex flex-col gap-1 font-mono text-sm font-semibold text-[var(--accent-green)]" data-testid="workflow-approval-preview">
        <span>{[selectedBy?.fileType, selectedBy?.mode, stpLabel].filter(Boolean).join(' · ')}</span>
        <span>no approval levels</span>
        <span>TotalApprovalLevels: 0</span>
      </div>
    );
  }

  const typeLabel = value.type ? optionLabel(findField(catalog, WORKFLOW_APPROVAL_FIELDS.type), value.type) : 'Workflow Type not selected';
  const heading = [selectedBy?.fileType, selectedBy?.mode, typeLabel].filter(Boolean).join(' · ');
  const levels = formatApprovalLevels(value.levels);
  const totalLevels = value.levels.filter(Boolean).length;
  return (
    <div className="flex flex-col gap-1 font-mono text-sm font-semibold text-[var(--accent-green)]" data-testid="workflow-approval-preview">
      <span>{heading}</span>
      <span>{levels || 'no approval levels yet'}</span>
      <span>TotalApprovalLevels: {totalLevels}</span>
    </div>
  );
}

function ChoiceField({
  field,
  label,
  value,
  submitted,
  onChange,
}: {
  field: RuleActionFieldDef | undefined;
  label: string;
  value: string;
  submitted: boolean;
  onChange: (value: string) => void;
}) {
  const text = field?.label ?? label;
  return (
    <div className="flex flex-col gap-1.5">
      <label className="input-label">{text}{field?.isRequired !== false ? ' *' : ''}</label>
      <select className="input-cls" aria-label={text} value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="" disabled>{field?.placeholder ?? `Select ${text}`}</option>
        {selectableOptions(field?.options ?? [], value).map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
      {submitted && !value && <span className="text-xs text-[var(--accent-red)]">Required</span>}
    </div>
  );
}

function IconButton({
  label,
  disabled,
  danger,
  onClick,
  children,
}: {
  label: string;
  disabled?: boolean;
  danger?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className={`flex h-7 w-7 items-center justify-center rounded-md border border-[var(--border)] text-[var(--text-muted)] disabled:cursor-not-allowed disabled:opacity-40 ${
        danger ? 'hover:bg-[var(--accent-red)]/10 hover:text-[var(--accent-red)]' : 'hover:bg-[var(--bg-secondary)]'
      }`}
    >
      {children}
    </button>
  );
}
