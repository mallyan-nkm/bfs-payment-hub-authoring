import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Check, ListOrdered, Loader2, Play, RefreshCw, X, Zap } from 'lucide-react';
import { Button, Can, PageBody, PageHeader, PageShell, Select } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { useAuthStore } from '../../stores/authStore';
import { ruleEngineApi } from './api';
import { ActionsGenerated } from './ActionsGenerated';
import { useConditionCatalog, useRuleTypes } from './useRuleMetadata';
import type { EvaluateGenericResponse } from './types';
import { useRailAccess } from '../../shared/auth/rails';

/**
 * Evaluate Rules — a small console around the generic, type-agnostic Evaluate
 * Rule API (FSD Section 15 / 36.10, `POST /rules/evaluate`). Unlike the Rule
 * Test Console (which tests one rule's own conditions in isolation), this
 * screen shows the actual cross-rule priority arbitration: every Active,
 * currently-effective rule of the chosen Rule Type (+ optional Domain/Rail),
 * ordered by Priority ascending (lower number wins) then Rule Code, evaluated
 * in that order until the first match — that rule's action list is what
 * comes back. Nothing else in the UI surfaces this endpoint.
 */

// Rails stay hardcoded in this release (plan Q1); Rule Types and the context fields come from the configuration catalog.
const RAIL_OPTIONS = [
  { label: 'Any Rail', value: '' },
  { label: 'IPI (Instant Payment)', value: 'IPI' },
  { label: 'FTS (Fund Transfer)', value: 'FTS' },
  { label: 'WPS (Wage Protection)', value: 'WPS' },
  { label: 'NPSS', value: 'NPSS' },
  { label: 'SWIFT', value: 'SWIFT' },
  { label: 'ALL Rails (rules scoped to every rail)', value: 'ALL' },
];

function extractErrorMessage(err: unknown): string {
  const httpError = err as { response?: { data?: { title?: string; error?: string } }; message?: string };
  return httpError?.response?.data?.title || httpError?.response?.data?.error || httpError?.message || 'Evaluation failed. Please try again.';
}

export function RuleEvaluateConsolePage() {
  const { allows: allowsRail } = useRailAccess();
  const navigate = useNavigate();
  const tenantId = useAuthStore((s) => s.activeTenantId);
  const { catalog } = useConditionCatalog(tenantId);
  const fieldGroups = useMemo(
    () => catalog.groups.map((g) => ({ group: g.label, fields: g.fields.filter((f) => f.isActive) })).filter((g) => g.fields.length > 0),
    [catalog],
  );
  const ruleTypes = useRuleTypes(tenantId);
  const ruleTypeOptions = ruleTypes.filter((t) => t.isActive).map((t) => ({ label: t.ruleTypeName, value: t.ruleTypeCode }));

  const [ruleType, setRuleType] = useState('');
  // Start on the configured default Rule Type once the types have loaded.
  useEffect(() => {
    if (!ruleType && ruleTypes.length > 0) setRuleType((ruleTypes.find((t) => t.isDefault && t.isActive) ?? ruleTypes.find((t) => t.isActive))?.ruleTypeCode ?? '');
  }, [ruleType, ruleTypes]);
  const [domain, setDomain] = useState('');
  const [context, setContext] = useState<Record<string, string>>({});

  const [evaluating, setEvaluating] = useState(false);
  const [result, setResult] = useState<EvaluateGenericResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  function reset() {
    setContext({});
    setResult(null);
    setError(null);
  }

  function runEvaluate() {
    if (!tenantId) return;
    setEvaluating(true);
    setResult(null);
    setError(null);

    const cleanContext: Record<string, string> = {};
    for (const [key, value] of Object.entries(context)) {
      if (value !== '' && value != null) cleanContext[key] = String(value);
    }

    ruleEngineApi
      .evaluate({ tenantId, ruleType, domain: domain || undefined, context: cleanContext })
      .then((res) => setResult(res.data))
      .catch((err) => setError(extractErrorMessage(err)))
      .finally(() => setEvaluating(false));
  }

  return (
    <PageShell>
      <PageHeader
        title={
          <span className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate('/rule-engine')} title="Back to rules list"><ArrowLeft size={16} /></Button>
            Evaluate Rules
          </span>
        }
        subtitle="Runs the priority-based arbitration API across every Active rule of a Rule Type — first matching rule, in Priority order (lower number wins), returns its action"
      />

      <PageBody>
        {!tenantId && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            No tenant context found for the current user — please sign in again.
          </div>
        )}
        {error && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* Left: Evaluate request — Rule Type + Domain + Payment Context */}
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <header className="border-b border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-3 text-sm font-semibold text-[var(--text-primary)]">Evaluate Request</header>
            <div className="flex flex-col gap-4 p-4">
              <div className="grid grid-cols-2 gap-3">
                <Select
                  label="Rule Type *"
                  options={ruleTypeOptions}
                  value={ruleType}
                  onValueChange={setRuleType}
                  helperText="Only Active, effective rules of this type compete"
                  className='input-cls'
                />
                <Select
                  label="Domain / Rail"
                  options={RAIL_OPTIONS.filter((o) => o.value === '' || allowsRail(o.value))}
                  value={domain}
                  onValueChange={setDomain}
                  helperText="Matches rules scoped to this rail, or to ALL"
                  className='input-cls'

                />
              </div>
              <div className='rounded-xl border border-blue-200 bg-[#eff6ff] p-3 text-xs text-[#1e40af]'>
                <h4 className="mb-1">Sample Payment Context</h4>
              <p className="-mt-2 text-xs text-[var(--text-muted)]">
                Fill in whatever fields your competing rules&apos; conditions check — leave the rest blank.
              </p>
              </div>
              
              <div className="flex flex-col gap-4">
                {fieldGroups.map(({ group, fields }) => (
                  <div key={group} className="flex flex-col gap-2.5">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{group}</div>
                    {fields.map((f) => (
                      <div key={f.field} className="flex flex-col gap-1">
                        <label className="input-label">{f.label}</label>
                        {f.controlType === 'number' && (
                          <input
                            type="number"
                            className='input-cls'

                            placeholder="Enter value"
                            value={context[f.field] ?? ''}
                            onChange={(e) => setContext({ ...context, [f.field]: e.target.value })}
                          />
                        )}
                        {f.controlType === 'time' && (
                          <input
                            type="time"
                            className="input-cls"
                            value={context[f.field] ?? ''}
                            onChange={(e) => setContext({ ...context, [f.field]: e.target.value })}
                          />
                        )}
                        {f.controlType === 'boolean' && (
                          <Select
                            placeholder="Select…"
                            options={f.values.filter((v) => v.isActive).map((v) => ({ label: v.label, value: v.code }))}
                            value={context[f.field] ?? ''}
                            onValueChange={(v) => setContext({ ...context, [f.field]: v })}
                            className='input-cls'
                          />
                        )}
                        {f.controlType === 'select' && (
                          <Select
                            placeholder="Select…"
                            options={f.values.filter((v) => v.isActive).map((v) => ({ label: v.label, value: v.code }))}
                            value={context[f.field] ?? ''}
                            onValueChange={(v) => setContext({ ...context, [f.field]: v })}
                            className='input-cls'
                          />
                        )}
                        {f.controlType === 'text' && (
                          <input
                            type="text"
                            className="input-cls"
                            placeholder="Enter value"
                            value={context[f.field] ?? ''}
                            onChange={(e) => setContext({ ...context, [f.field]: e.target.value })}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                ))}
              </div>

              <div className="flex justify-end gap-2 border-t border-[var(--border)] pt-4">
                <Button className="btn-tertiary" size="sm" onClick={reset}><RefreshCw size={14} /> Reset</Button>
                <Can permission={PERM.configRuleEvaluate} mode="disable">
                <Button className='btn-secondary' size="sm" onClick={runEvaluate} disabled={!tenantId || !ruleType || evaluating}>
                  {evaluating ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />} {evaluating ? 'Evaluating…' : 'Evaluate'}
                </Button>
                </Can>
              </div>
            </div>
          </section>

          {/* Right: Result */}
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <header className="flex items-center gap-2 border-b border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-3 text-sm font-semibold text-[var(--text-primary)]">
              <Zap size={16} className="text-[var(--accent)]" /> Evaluate Result
              {result && <span className="ml-auto font-mono text-xs text-[var(--text-muted)]">{result.executionDurationMs}ms</span>}
            </header>
            <div className="p-4">
              {!result ? (
                <div className="flex flex-col items-center gap-1 py-12 text-center text-[var(--text-muted)]">
                  <ListOrdered size={40} className="opacity-40" />
                  <p className="font-semibold text-[var(--text-primary)]">No evaluation run yet</p>
                  <span className="text-xs">Pick a Rule Type and Domain, fill in the context, and click &quot;Evaluate&quot;</span>
                </div>
              ) : (
                <>
                  <div className={`mb-3 flex items-center gap-3 rounded-md border p-3 ${result.matched ? 'border-[var(--accent-green)] bg-[var(--accent-green)]/10' : 'border-[var(--text-muted)] bg-[var(--bg-secondary)]'}`}>
                    {result.matched ? <Check size={20} className="text-[var(--accent-green)]" /> : <X size={20} className="text-[var(--text-muted)]" />}
                    <div>
                      <div className={`font-bold text-sm ${result.matched ? 'text-[var(--accent-green)]' : 'text-[var(--text-secondary)]'}`}>
                        {result.matched ? 'MATCHED' : 'NO RULE MATCHED'}
                      </div>
                      {result.matched && (
                        <div className="font-mono text-xs text-[var(--text-muted)]">{result.ruleCode} · v{result.version}</div>
                      )}
                    </div>
                  </div>

                  <div className="mb-3 rounded-md bg-[var(--bg-secondary)] p-3 text-xs text-[var(--text-muted)]">
                    <span className="font-semibold text-[var(--text-primary)]">{result.rulesEvaluated}</span>{' '}
                    Active, effective rule{result.rulesEvaluated === 1 ? '' : 's'} of type <span className="font-semibold text-[var(--text-primary)]">{ruleType}</span>
                    {domain && <> scoped to <span className="font-semibold text-[var(--text-primary)]">{domain}</span></>} competed, ordered by Priority (lowest number first).
                    {result.matched ? ' The first one whose conditions matched won.' : ' None of their conditions matched this context.'}
                  </div>

                  {result.matched && <ActionsGenerated actions={result.actions} approvalMatrix={result.approvalMatrix} />}
                </>
              )}
            </div>
          </section>
        </div>
      </PageBody>
    </PageShell>
  );
}
