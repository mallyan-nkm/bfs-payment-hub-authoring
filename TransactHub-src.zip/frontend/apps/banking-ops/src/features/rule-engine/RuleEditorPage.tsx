import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { Banknote, Beaker, Check, Code, Loader2, Percent, Play, Plus, RefreshCw, Save, Trash2, X } from 'lucide-react';
import { Can, PageBody, PageHeader, PageShell } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { useAuthStore } from '../../stores/authStore';
import { ruleEngineApi } from './api';
import { ActionsGenerated } from './ActionsGenerated';
import {
  ConditionBuilderEmptyState,
  ConditionBuilderToolbar,
  ConditionCatalogContext,
  ConditionGroupBuilder,
  collectConditionFields,
  conditionRowsToTree,
  countConditionRows,
  formatConditionPreview,
  newSingleRow,
  removeConditionFields,
} from './ConditionGroupBuilder';
import {
  PERCENTAGE_RESULT_TYPE,
  applyChargeDefaults,
  buildCreateRuleRequest,
  chargeSelectorField,
  defaultActions,
  detailToForm,
  emptyForm,
  getChargeFieldValue,
  getResultPreview,
  isFormValid,
  newActionFor,
  selectableActionFields,
  setChargeFieldValue,
  visibleChargeFields,
  type ActionContext,
  type RuleForm,
} from './ruleForm';
import {
  collectConditionLeaves,
  getConditionFieldDef,
  getOperatorLabel,
  getValueLabel,
  selectableOptions,
  withRailMessageTypes,
  type ActionEditorMode,
  type ConditionCatalog,
  type ConditionTestNode,
  type RuleActionFieldDef,
  type TestRuleResponse,
} from './types';
import { conditionCatalogQuery, useRailMessageTypes, useRuleMetadata } from './useRuleMetadata';
import { WorkflowApprovalActionsEditor, WorkflowApprovalPreview } from './WorkflowApprovalActionsEditor';
import {
  WORKFLOW_APPROVAL_CONDITIONS,
  conditionEqualsValue,
  emptyWorkflowApproval,
  hasWorkflowApprovalContent,
  isWorkflowApprovalComplete,
} from './workflowApproval';
import { useRailAccess } from '../../shared/auth/rails';

/**
 * Create / Edit / Clone Rule — the FSD's 5-tab Rule Builder (Section 10.2):
 * 1. Rule Information, 2. Conditions, 3. Actions, 4. Summary, 5. Test Rule,
 * all against a single in-memory draft. Summary and Test Rule are currently hidden
 * from the tab bar (see TABS). Port of the Angular admin-portal's
 * NewRuleComponent, extended with the generic Action Builder (Section 14).
 *
 * Every option list comes from the Rule Engine's configuration catalog
 * (useRuleMetadata): Rule Types and their Rule Code prefixes, condition
 * parameters / operators / values, and each type's action fields. The Rule
 * Type's ActionEditorMode picks the Actions editor — GENERIC (Dropdown 1 →
 * Dropdown 2), CHARGE (Charge Action Type and its dependent fields) or
 * WORKFLOW_APPROVAL (mode, type and approval matrix). Only the Rail list stays
 * hardcoded in this release (plan Q1).
 */

type EditorTab = 'info' | 'conditions' | 'actions' | 'summary' | 'test';

function extractErrorMessage(err: unknown): string {
  const httpError = err as { response?: { data?: { errors?: Record<string, string[]>; title?: string; error?: string } }; message?: string };
  const validationErrors = httpError?.response?.data?.errors;
  if (validationErrors) {
    const messages = Object.values(validationErrors).flat();
    if (messages.length > 0) return messages.join(' ');
  }
  return httpError?.response?.data?.title || httpError?.response?.data?.error || httpError?.message || 'Failed to save rule. Please try again.';
}

// Rails stay hardcoded in this release (plan Q1–Q3): no rails API exists to read them from.
const RAIL_OPTIONS = [
  { label: 'IPI (Instant Payment)', value: 'IPI' },
  { label: 'FTS (Fund Transfer)', value: 'FTS' },
  { label: 'WPS (Wage Protection)', value: 'WPS' },
  { label: 'NPSS', value: 'NPSS' },
  { label: 'SWIFT', value: 'SWIFT' },
  { label: 'All Rails', value: 'ALL' },
];

const TABS: { key: EditorTab; label: string }[] = [
  { key: 'info', label: '1. Rule Information' },
  { key: 'conditions', label: '2. Conditions' },
  { key: 'actions', label: '3. Actions' },
  // 4. Summary and 5. Test Rule are hidden from the tab bar (review decision, 16-Oct-2026). Their panels
  // below are kept, so restoring a tab is adding its entry back:
  //   { key: 'summary', label: '4. Summary' },
  //   { key: 'test', label: '5. Test Rule' },
];

export function RuleEditorPage() {
  const { allows: allowsRail } = useRailAccess();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const cloneId = searchParams.get('clone');
  const tenantId = useAuthStore((s) => s.activeTenantId);
  const currentUser = useAuthStore((s) => s.user);

  const isEditMode = Boolean(id);
  const [editingRuleId, setEditingRuleId] = useState<number | null>(null);
  const [form, setForm] = useState<RuleForm>(emptyForm());
  const [tab, setTab] = useState<EditorTab>('info');
  const [submitted, setSubmitted] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingRule, setIsLoadingRule] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [showJson, setShowJson] = useState(false);

  const [testParams, setTestParams] = useState<Record<string, string>>({});
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<TestRuleResponse | null>(null);

  const metadata = useRuleMetadata(tenantId, form.ruleType || undefined);
  const { ruleTypes, selectedType, actionCatalog } = metadata;
  const editorMode: ActionEditorMode = selectedType?.actionEditorMode ?? 'GENERIC';
  const actionCtx: ActionContext = { mode: editorMode, catalog: actionCatalog };
  const metadataReady = !metadata.isLoading && !metadata.isError && Boolean(actionCatalog);

  // Message Type values follow the selected rail (Q7); "All Rails" or no data keeps the seeded fallback list.
  const railMessageTypes = useRailMessageTypes(form.railType || undefined);
  const conditionCatalog: ConditionCatalog = useMemo(
    () => withRailMessageTypes(metadata.conditionCatalog, railMessageTypes),
    [metadata.conditionCatalog, railMessageTypes],
  );

  // A new rule starts on the configured default Rule Type.
  const defaultType = ruleTypes.find((t) => t.isDefault && t.isActive) ?? ruleTypes.find((t) => t.isActive);
  useEffect(() => {
    if (!id && !cloneId && defaultType) {
      setForm((f) => (f.ruleType ? f : { ...f, ruleType: defaultType.ruleTypeCode }));
    }
  }, [id, cloneId, defaultType, form.ruleType]);

  // A generic type always carries at least one action row — seeded once its catalog has loaded.
  useEffect(() => {
    if (editorMode === 'GENERIC' && actionCatalog?.ruleTypeCode === form.ruleType && form.actions.length === 0) {
      setForm((f) => (f.actions.length > 0 ? f : { ...f, actions: defaultActions(actionCatalog) }));
    }
  }, [editorMode, actionCatalog, form.ruleType, form.actions.length]);

  useEffect(() => {
    const loadId = id ?? cloneId;
    if (!loadId) return;
    const ruleId = Number(loadId);
    if (!ruleId) {
      setSaveError(`Invalid rule id: ${loadId}`);
      return;
    }
    setIsLoadingRule(true);
    setSaveError(null);
    ruleEngineApi
      .getById(ruleId)
      .then((res) => {
        setIsLoadingRule(false);
        const loaded = detailToForm(res.data);
        if (cloneId && !id) {
          // A clone is a brand-new rule: blank name, back to Draft, no
          // editingRuleId so Save creates rather than versions the source.
          loaded.ruleName = '';
          loaded.status = 'Draft';
        } else {
          setEditingRuleId(ruleId);
        }
        setForm(loaded);
      })
      .catch((err) => {
        setIsLoadingRule(false);
        setSaveError(extractErrorMessage(err));
      });
    // Only ever runs once per mount of this route (id/cloneId are fixed by the URL).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const genericFields = useMemo(() => selectableActionFields(actionCatalog), [actionCatalog]);
  const chargeSelector = chargeSelectorField(editorMode === 'CHARGE' ? actionCatalog : undefined);
  const chargeFields = useMemo(
    () => (editorMode === 'CHARGE' ? visibleChargeFields(actionCatalog, form) : []),
    [editorMode, actionCatalog, form],
  );

  async function onRuleTypeChange(ruleType: string) {
    const nextMode = ruleTypes.find((t) => t.ruleTypeCode === ruleType)?.actionEditorMode ?? 'GENERIC';

    if (editorMode === 'WORKFLOW_APPROVAL' && nextMode !== 'WORKFLOW_APPROVAL' && hasWorkflowApprovalContent(form.workflowApproval)
      && !window.confirm('Changing the Rule Type clears the Workflow Mode, Workflow Type and Approval Matrix. Continue?')) {
      return;
    }

    // Conditions on a parameter the new type does not offer are flagged and, once confirmed, dropped.
    let conditionRows = form.conditionRows;
    const usedFields = collectConditionFields(conditionRows);
    if (usedFields.length > 0 && tenantId) {
      try {
        const nextCatalog = await queryClient.fetchQuery(conditionCatalogQuery(tenantId, ruleType));
        const unavailable = usedFields.filter((f) => !nextCatalog.byField.get(f)?.isActive);
        if (unavailable.length > 0) {
          if (!window.confirm(`${ruleType} rules do not offer these condition parameters: ${unavailable.join(', ')}. Their conditions will be removed. Continue?`)) return;
          conditionRows = removeConditionFields(conditionRows, new Set(unavailable));
        }
      } catch {
        // Catalog unreachable: keep the conditions — the server validates them on save.
      }
    }

    // Action fields are type-specific (FSD Section 10.2.1 / 14.2): the previous type's actions no longer apply.
    setForm((f) => ({
      ...f,
      ruleType,
      conditionRows,
      actions: [],
      workflowApproval: emptyWorkflowApproval(),
      ...(nextMode === 'CHARGE' ? {} : { chargeType: '', resultValue: '', minimumCharge: '', maximumCharge: '', overrideBreakdown: {} }),
    }));
  }

  function addActionRow() {
    const used = new Set(form.actions.map((a) => a.field));
    const next = genericFields.find((f) => f.isActive && !used.has(f.field)) ?? genericFields.find((f) => f.isActive);
    if (!next) return;
    setForm({ ...form, actions: [...form.actions, newActionFor(next)] });
  }

  function updateActionField(index: number, field: string) {
    const meta = genericFields.find((f) => f.field === field);
    setForm({
      ...form,
      actions: form.actions.map((a, i) => (i === index ? (meta ? newActionFor(meta) : { field, value: '' }) : a)),
    });
  }

  function updateActionValue(index: number, value: string) {
    setForm({ ...form, actions: form.actions.map((a, i) => (i === index ? { ...a, value } : a)) });
  }

  function removeActionRow(index: number) {
    if (form.actions.length <= 1) return; // A rule must always retain at least one action (FSD Section 14.2).
    setForm({ ...form, actions: form.actions.filter((_, i) => i !== index) });
  }

  function onChargeTypeChange(chargeType: string) {
    setForm((f) => applyChargeDefaults({ ...f, chargeType }, actionCatalog));
  }

  function onChargeFieldChange(field: string, value: string) {
    setForm((f) => applyChargeDefaults(setChargeFieldValue(f, field, value), actionCatalog));
  }

  function saveRule(status: string) {
    if (!tenantId) {
      setSaveError('No tenant context found for the current user. Please sign in again.');
      return;
    }
    const submitForm = { ...form, status };
    setForm(submitForm);
    setIsSaving(true);
    setSaveError(null);
    setSaveSuccess(null);

    const request = buildCreateRuleRequest(submitForm, tenantId, currentUser?.username || 'system', actionCtx);
    const wasActivating = status === 'Active';
    const isUpdating = isEditMode && editingRuleId != null;

    const save = isUpdating ? ruleEngineApi.update(editingRuleId!, request) : ruleEngineApi.create(request);

    save
      .then((res) => {
        setIsSaving(false);
        setSubmitted(false);
        const saved = res.data;
        if (isUpdating) {
          // PUT creates a new append-only version with its own RuleId — stay in
          // edit mode, now pointing at that new version, form repopulated from
          // what was actually persisted.
          setEditingRuleId(saved.ruleId);
          setForm(detailToForm(saved));
          setSaveSuccess(`Rule "${saved.ruleName}" (${saved.ruleCode}) updated successfully (v${saved.versionNo}).`);
        } else {
          setForm(emptyForm());
          setSaveSuccess(`Rule "${saved.ruleName}" (${saved.ruleCode}) ${wasActivating ? 'created and activated' : 'saved as draft'} successfully.`);
        }
      })
      .catch((err) => {
        setIsSaving(false);
        setSaveError(extractErrorMessage(err));
      });
  }

  function saveDraft() {
    saveRule('Draft');
  }

  function saveAndActivate() {
    setSubmitted(true);
    if (!isFormValid(form, actionCtx)) return;
    saveRule('Active');
  }

  function runDraftTest() {
    if (!tenantId) return;
    setTesting(true);
    setTestResult(null);
    const draft = buildCreateRuleRequest(form, tenantId, currentUser?.username || 'system', actionCtx);
    const parameters: Record<string, string> = {};
    for (const [key, value] of Object.entries(testParams)) {
      if (value !== '' && value != null) parameters[key] = String(value);
    }
    ruleEngineApi
      .testDraft({ draft, parameters })
      .then((res) => setTestResult(res.data))
      .catch((err) => setSaveError(extractErrorMessage(err)))
      .finally(() => setTesting(false));
  }

  const formValid = metadataReady && isFormValid(form, actionCtx);
  const conditionCount = countConditionRows(form.conditionRows);
  const preview = formatConditionPreview(form.conditionRows, form.rootOperator, conditionCatalog);
  const resultPreview = getResultPreview(form, actionCtx);
  const ruleTypeOptions = selectableOptions(
    ruleTypes.map((t) => ({ code: t.ruleTypeCode, label: t.ruleTypeName, isActive: t.isActive })),
    form.ruleType,
  );
  // Full categorized Payment Context, same schema as the standalone Test
  // Console (FSD Section 10.2.5 / 10.4) — not just the fields this draft's
  // own conditions reference, so any transaction detail can be set.
  const testFieldGroups = useMemo(
    () => conditionCatalog.groups.map((g) => ({ group: g.label, fields: g.fields.filter((f) => f.isActive) })).filter((g) => g.fields.length > 0),
    [conditionCatalog],
  );
  const draftConditionHints = useMemo(() => {
    const tree = conditionRowsToTree(form.conditionRows, form.rootOperator);
    const byField = new Map<string, { operator: string; value: string }[]>();
    for (const leaf of collectConditionLeaves(tree)) {
      const list = byField.get(leaf.field) ?? [];
      list.push({ operator: leaf.operator, value: leaf.value });
      byField.set(leaf.field, list);
    }
    const hints = new Map<string, string>();
    for (const [field, leaves] of byField) {
      hints.set(field, leaves.map((l) => `${getOperatorLabel(conditionCatalog, l.operator, field)} ${l.value}`).join(' / '));
    }
    return hints;
  }, [form.conditionRows, form.rootOperator, conditionCatalog]);

  // WorkflowApproval: the File Type / Mode the rule is selected by, for the Actions preview and Summary.
  const workflowApprovalSelection = useMemo(() => {
    const tree = conditionRowsToTree(form.conditionRows, form.rootOperator);
    const label = (field: string) => {
      const value = conditionEqualsValue(tree, field);
      return value ? getValueLabel(getConditionFieldDef(conditionCatalog, field), value) : undefined;
    };
    return { fileType: label(WORKFLOW_APPROVAL_CONDITIONS.fileType), mode: label(WORKFLOW_APPROVAL_CONDITIONS.mode) };
  }, [form.conditionRows, form.rootOperator, conditionCatalog]);

  const actionsChecklist =
    editorMode === 'WORKFLOW_APPROVAL'
      ? { ok: isWorkflowApprovalComplete(form.workflowApproval, actionCatalog), label: 'Approval matrix complete' }
      : { ok: editorMode === 'CHARGE' ? Boolean(form.chargeType) : form.actions.length > 0, label: 'At least one action' };

  return (
    <PageShell>
      <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
        <button onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">Dashboard</button>
        {' / '}
        <button onClick={() => navigate('/rule-engine')} className="pq-breadcrumb-link">Rule Engine</button>
        {' / '}
        <span>{isEditMode ? 'Edit Rule' : 'Create Rule'}</span>
      </p>
      <PageHeader
        title={isEditMode ? 'Edit Rule' : 'Create Rule'}
        subtitle={isEditMode ? 'Modify rule configuration' : 'Define conditions and actions using dropdowns — no code required'}
        actions={
          <>
            <button type="button" className="btn-secondary h-38px gap-2" onClick={() => navigate('/rule-engine')}>Cancel</button>
            {/* Save Draft and Submit/Update both POST or PUT /api/rules — config:rule:write. */}
            <Can permission={PERM.configRuleWrite} mode="disable">
            <button
              type="button"
              className="btn-secondary h-38px gap-2 disabled:pointer-events-none disabled:opacity-50"
              onClick={saveDraft}
              disabled={!form.ruleName || isSaving || isLoadingRule || !tenantId || !metadataReady}
            >
              {isSaving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Save Draft
            </button>
            <button
              type="button"
              className="btn-primary h-38px gap-2 disabled:pointer-events-none disabled:opacity-50"
              onClick={saveAndActivate}
              disabled={!formValid || isSaving || isLoadingRule || !tenantId}
            >
              {isSaving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
              {isSaving ? 'Saving...' : isEditMode ? 'Update Rule' : 'Submit for Approval'}
            </button>
            </Can>
          </>
        }
      />

      <PageBody>
        {isLoadingRule && (
          <div className="mb-4 flex items-center gap-2 rounded-md border border-[var(--accent)] bg-[var(--accent)]/10 px-3.5 py-2.5 text-sm text-[var(--accent)]">
            <Loader2 size={14} className="animate-spin" /> Loading rule…
          </div>
        )}
        {metadata.isLoading && tenantId && (
          <div className="mb-4 flex items-center gap-2 rounded-md border border-[var(--accent)] bg-[var(--accent)]/10 px-3.5 py-2.5 text-sm text-[var(--accent)]" role="status">
            <Loader2 size={14} className="animate-spin" /> Loading rule configuration…
          </div>
        )}
        {metadata.isError && (
          <div className="mb-4 flex items-center gap-2 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]" role="alert">
            <span className="flex-1">The rule configuration (rule types, conditions and actions) could not be loaded, so the rule cannot be saved.</span>
            <button type="button" className="flex items-center gap-1 font-semibold underline" onClick={() => metadata.refetch()}>
              <RefreshCw size={13} /> Retry
            </button>
          </div>
        )}
        {saveSuccess && (
          <div className="mb-4 flex items-center gap-2 rounded-md border border-[var(--accent-green)] bg-[var(--accent-green)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-green)]">
            <span className="flex-1">{saveSuccess}</span>
            <button onClick={() => setSaveSuccess(null)} aria-label="Dismiss"><X size={14} /></button>
          </div>
        )}
        {!tenantId && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            No tenant context found for the current user — please sign in again before creating a rule.
          </div>
        )}
        {saveError && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            {saveError}
          </div>
        )}

        {/* Tab bar (FSD Section 10.2) — styled like PaymentQueuePage's queue-scope tabs */}
        <div className="pq-tabs mb-4" role="tablist" aria-label="Rule editor tabs">
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={tab === t.key}
              onClick={() => setTab(t.key)}
              className={tab === t.key ? 'pq-tab pq-tab-active' : 'pq-tab'}
            >
              <span className="pq-tab-label">{t.label}</span>
            </button>
          ))}
        </div>

        {/* ── Tab 1: Rule Information ── */}
        {tab === 'info' && (
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <div className="grid grid-cols-1 gap-4 p-4 md:grid-cols-2">
              <div className="flex flex-col gap-1.5 md:col-span-2">
                <label className="input-label" htmlFor="rule-name">Rule Name *</label>
                <input
                  id="rule-name"
                  className="input-cls"
                  placeholder="e.g. IPI Bank A Routing"
                  value={form.ruleName}
                  onChange={(e) => setForm({ ...form, ruleName: e.target.value })}
                />
                {submitted && !form.ruleName ? (
                  <span className="text-xs text-[var(--accent-red)]">Rule name is required.</span>
                ) : (
                  <span className="text-xs text-[var(--text-muted)]">Business-friendly name shown throughout the UI</span>
                )}
              </div>
              <div className="flex flex-col gap-1.5 md:col-span-2">
                <label className="input-label">Description</label>
                <textarea
                  className="input-cls"
                  rows={2}
                  style={{ height: 'auto', minHeight: 64, alignItems: 'flex-start', paddingTop: 8 }}
                  placeholder="Describe when this rule applies and its purpose"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>
              </div>
               <div className="grid grid-cols-1 gap-4 p-4 md:grid-cols-3">
              <div className="flex flex-col gap-1.5">
                <label className="input-label" htmlFor="rule-type">Rule Type *</label>
                <select id="rule-type" className="input-cls" value={form.ruleType} onChange={(e) => void onRuleTypeChange(e.target.value)} disabled={ruleTypes.length === 0}>
                  {!form.ruleType && <option value="" disabled>{metadata.isLoading ? 'Loading…' : 'Select Rule Type'}</option>}
                  {ruleTypeOptions.map((o) => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
                <span className="text-xs text-[var(--text-muted)]">{selectedType?.description || 'Determines which action fields are available on the Actions tab'}</span>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="input-label" htmlFor="rule-rail">Domain / Rail *</label>
                <select id="rule-rail" className="input-cls" value={form.railType} onChange={(e) => setForm({ ...form, railType: e.target.value })}>
                  <option value="" disabled>Select Rail</option>
                  {RAIL_OPTIONS.filter((o) => allowsRail(o.value)).map((o) => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
                {submitted && !form.railType && <span className="text-xs text-[var(--accent-red)]">Required</span>}
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="input-label">Priority</label>
                <input
                  className="input-cls"
                  type="number"
                  min={1}
                  max={100}
                  value={form.priority}
                  onChange={(e) => setForm({ ...form, priority: Number(e.target.value) })}
                />
                <span className="text-xs text-[var(--text-muted)]">Lower number = evaluated first</span>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="input-label">Status</label>
                <input disabled value={form.status} className="input-cls" />
                <span className="text-[11px] text-[var(--text-muted)]">System-managed — set via Save Draft / Submit for Approval below</span>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="input-label">Effective From *</label>
                <input
                  className="input-cls d-block"
                  type="date"
                  value={form.effectiveFrom}
                  onChange={(e) => setForm({ ...form, effectiveFrom: e.target.value })}
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="input-label">Effective To</label>
                <input
                  className="input-cls d-block"
                  type="date"
                  value={form.effectiveTo}
                  onChange={(e) => setForm({ ...form, effectiveTo: e.target.value })}
                />
                <span className="text-xs text-[var(--text-muted)]">Leave empty for no end date</span>
              </div>
              <div className="md:col-span-2">
                <label className="input-label mb-1.5 block" htmlFor="rule-code">Rule Code</label>
                <input
                  id="rule-code"
                  disabled
                  value={isEditMode ? '(unchanged across versions)' : `Generated on save — ${selectedType?.ruleCodePrefix ?? 'GEN'}-${form.railType || '?'}-NNN`}
                  className="input-cls w-full"
                />
              </div>
            </div>
          </section>
        )}

        {/* ── Tab 2: Conditions ── */}
        {tab === 'conditions' && (
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <ConditionCatalogContext.Provider value={conditionCatalog}>
              <div className="flex flex-col gap-3 p-4">
                {form.conditionRows.length === 0 ? (
                  <ConditionBuilderEmptyState onAdd={() => setForm({ ...form, conditionRows: [newSingleRow()] })} />
                ) : (
                  <>
                    <ConditionBuilderToolbar
                      rows={form.conditionRows}
                      onChange={(conditionRows) => setForm({ ...form, conditionRows })}
                      rootOperator={form.rootOperator}
                      onRootOperatorChange={(rootOperator) => setForm({ ...form, rootOperator })}
                    />
                    <ConditionGroupBuilder rows={form.conditionRows} onChange={(conditionRows) => setForm({ ...form, conditionRows })} />
                  </>
                )}
                {form.conditionRows.length > 0 && (
                  <div className="mt-2 rounded-md bg-[var(--bg-secondary)] p-3">
                    <label className="mb-1.5 block text-[10px] uppercase tracking-wide text-[var(--text-muted)]">Live Preview:</label>
                    <code className="break-all text-xs text-[var(--text-primary)]">{preview}</code>
                  </div>
                )}
              </div>
            </ConditionCatalogContext.Provider>
          </section>
        )}

        {/* ── Tab 3: Actions (FSD Section 14) ── */}
        {tab === 'actions' && (
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <div className="flex flex-col gap-4 p-4">
              {!actionCatalog ? (
                <InfoNote>{metadata.isError ? 'Action fields could not be loaded.' : `Loading available action fields for ${form.ruleType || 'the rule type'}…`}</InfoNote>
              ) : editorMode === 'WORKFLOW_APPROVAL' ? (
                <WorkflowApprovalActionsEditor
                  catalog={actionCatalog}
                  value={form.workflowApproval}
                  selectedBy={workflowApprovalSelection}
                  onChange={(workflowApproval) => setForm((f) => ({ ...f, workflowApproval }))}
                  submitted={submitted}
                />
              ) : editorMode === 'CHARGE' ? (
                <>
                  <div className="flex flex-col gap-1.5">
                    <label className="input-label" htmlFor="charge-action-type">{chargeSelector?.label ?? 'Charge Action Type'} *</label>
                    <select
                      id="charge-action-type"
                      className="input-cls"
                      value={form.chargeType}
                      onChange={(e) => onChargeTypeChange(e.target.value)}
                    >
                      <option value="" disabled>{chargeSelector?.placeholder ?? 'Select Type'}</option>
                      {selectableOptions(chargeSelector?.options ?? [], form.chargeType).map((o) => (
                        <option key={o.value} value={o.value}>{o.label}</option>
                      ))}
                    </select>
                    {submitted && !form.chargeType && <span className="text-xs text-[var(--accent-red)]">Required</span>}
                  </div>

                  {!form.chargeType ? (
                    <InfoNote>Select a {chargeSelector?.label ?? 'Charge Action Type'} above to configure its value.</InfoNote>
                  ) : chargeFields.length === 0 ? (
                    <InfoNote>{resultPreview}. No value is entered here — it is applied automatically when the rule&apos;s conditions match.</InfoNote>
                  ) : (
                    <ChargeFieldsEditor fields={chargeFields} form={form} submitted={submitted} onChange={onChargeFieldChange} />
                  )}

                  <div className="mt-2 rounded-md bg-[var(--bg-secondary)] p-3">
                    <label className="mb-1.5 block text-[10px] uppercase tracking-wide text-[var(--text-muted)]">Result Preview:</label>
                    <div className="font-mono text-sm font-semibold text-[var(--accent-green)]">{resultPreview}</div>
                  </div>
                </>
              ) : (
                <div className="flex flex-col gap-2">
                  {form.actions.map((action, i) => {
                    const meta = genericFields.find((f) => f.field === action.field);
                    const fieldOptions = selectableOptions(
                      genericFields.map((f) => ({ code: f.field, label: f.label, isActive: f.isActive })),
                      action.field,
                    );
                    return (
                      <div key={i} className="grid grid-cols-[0.9fr_1.3fr_28px] items-center gap-2" data-testid="generic-action-row">
                        <select
                          className="input-cls"
                          aria-label={`Action ${i + 1} field`}
                          value={action.field}
                          onChange={(e) => updateActionField(i, e.target.value)}
                        >
                          {fieldOptions.map((o) => (
                            <option key={o.value} value={o.value}>{o.label}</option>
                          ))}
                        </select>
                        {meta?.valueType === 'enum' ? (
                          <select
                            className="input-cls"
                            aria-label={`Action ${i + 1} value`}
                            value={action.value}
                            onChange={(e) => updateActionValue(i, e.target.value)}
                          >
                            {!action.value && <option value="" disabled>Select…</option>}
                            {selectableOptions(meta.options, action.value).map((o) => (
                              <option key={o.value} value={o.value}>{o.label}</option>
                            ))}
                          </select>
                        ) : (
                          <input
                            type={meta?.valueType === 'number' ? 'number' : 'text'}
                            aria-label={`Action ${i + 1} value`}
                            placeholder={meta?.placeholder ?? 'Value'}
                            value={action.value}
                            onChange={(e) => updateActionValue(i, e.target.value)}
                            className="input-cls"
                          />
                        )}
                        <button
                          type="button"
                          onClick={() => removeActionRow(i)}
                          disabled={form.actions.length <= 1}
                          className="flex h-7 w-7 items-center justify-center rounded-md border border-[var(--border)] text-[var(--text-muted)] hover:bg-[var(--accent-red)]/10 hover:text-[var(--accent-red)] disabled:cursor-not-allowed disabled:opacity-40"
                          title={form.actions.length <= 1 ? 'A rule must have at least one action' : 'Remove action'}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    );
                  })}
                  {submitted && !isFormValid(form, actionCtx) && (
                    <span className="text-xs font-medium text-[var(--accent-red)]">At least one complete action is required.</span>
                  )}
                  <button
                    onClick={addActionRow}
                    disabled={form.actions.length >= genericFields.filter((f) => f.isActive).length}
                    className="mt-1 flex w-fit items-center gap-1.5 text-xs font-semibold text-[var(--accent)] hover:underline disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <Plus size={13} /> Add Action
                  </button>
                </div>
              )}
            </div>
          </section>
        )}

        {/* ── Tab 4: Summary (FSD Section 10.2.4) ── */}
        {tab === 'summary' && (
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <div className="flex flex-col gap-4 p-4">
              <div className="rounded-lg border-l-4 border-[var(--accent)] bg-[var(--bg-secondary)] p-4">
                <div className="mb-2 font-mono text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">IF</div>
                <code className="block break-all text-sm text-[var(--text-primary)]">{conditionCount === 0 ? 'always (no conditions)' : preview}</code>
                <div className="mt-4 mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">
                  <span>→</span> THEN
                </div>
                {editorMode === 'WORKFLOW_APPROVAL' ? (
                  <WorkflowApprovalPreview catalog={actionCatalog} value={form.workflowApproval} selectedBy={workflowApprovalSelection} />
                ) : editorMode === 'CHARGE' ? (
                  <div className="inline-flex items-center gap-2 rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-bold text-white">
                    <span className="uppercase opacity-80">{form.chargeType || 'Charge'}</span>
                    <span className="font-mono">{resultPreview}</span>
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {form.actions.map((a, i) => (
                      <div key={i} className="inline-flex items-center gap-2 rounded-md bg-[var(--accent)] px-3 py-1.5 text-xs font-bold text-white">
                        <span className="uppercase opacity-80">{a.field}</span>
                        <span className="font-mono">{a.value || '—'}</span>
                      </div>
                    ))}
                    {form.actions.length === 0 && <span className="text-xs text-[var(--text-muted)]">No actions configured yet.</span>}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 rounded-md bg-[var(--bg-secondary)] p-3 text-sm md:grid-cols-4">
                <ChecklistItem ok={Boolean(form.ruleName)} label="Rule Name" />
                <ChecklistItem ok={conditionCount > 0} label={`${conditionCount} condition(s)`} />
                <ChecklistItem ok={actionsChecklist.ok} label={actionsChecklist.label} />
                <ChecklistItem ok={Boolean(form.railType)} label="Domain / Rail set" />
              </div>

              <div>
                <button onClick={() => setShowJson((v) => !v)} className="flex items-center gap-1.5 text-xs font-semibold text-[var(--text-muted)] hover:text-[var(--text-primary)]">
                  <Code size={13} /> {showJson ? 'Hide JSON' : 'View JSON'}
                </button>
                {showJson && tenantId && (
                  <pre className="mt-2 overflow-x-auto rounded-md bg-[var(--ink,#0F1B2D)] p-4 text-[11px] leading-relaxed text-[#D9EEE6]">
                    {JSON.stringify(buildCreateRuleRequest(form, tenantId, currentUser?.username || 'system', actionCtx), null, 2)}
                  </pre>
                )}
              </div>
            </div>
          </section>
        )}

        {/* ── Tab 5: Test Rule (FSD Section 19 / 10.2.5) ── */}
        {tab === 'test' && (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
              <header className="border-b border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-3 text-sm font-semibold text-[var(--text-primary)]">Sample Payment Context</header>
              <div className="flex flex-col gap-4 p-4">
                {draftConditionHints.size === 0 && (
                  <p className="text-xs text-[var(--text-muted)]">This draft has no conditions yet — it always matches, regardless of the values entered below.</p>
                )}
                {testFieldGroups.map(({ group, fields }) => (
                  <div key={group} className="flex flex-col gap-2.5">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{group}</div>
                    {fields.map((f) => {
                      const hint = draftConditionHints.get(f.field);
                      return (
                        <div key={f.field} className="flex flex-col gap-1">
                          <label className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">
                            {f.label}
                            {hint && <span className="rounded-full bg-[var(--accent)]/15 px-1.5 py-px text-[9px] font-bold normal-case tracking-normal text-[var(--accent)]">used by this rule</span>}
                          </label>
                          {hint && <span className="font-mono text-[10px] text-[var(--accent)]">{hint}</span>}
                          {f.controlType === 'select' || f.controlType === 'boolean' ? (
                            <select
                              className="input-cls"
                              value={testParams[f.field] ?? ''}
                              onChange={(e) => setTestParams({ ...testParams, [f.field]: e.target.value })}
                            >
                              <option value="">Select…</option>
                              {f.values.filter((v) => v.isActive).map((v) => (
                                <option key={v.code} value={v.code}>{v.label}</option>
                              ))}
                            </select>
                          ) : (
                            <input
                              type={f.controlType === 'number' ? 'number' : f.controlType === 'time' ? 'time' : 'text'}
                              className="input-cls"
                              value={testParams[f.field] ?? ''}
                              onChange={(e) => setTestParams({ ...testParams, [f.field]: e.target.value })}
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
                {/* POST /api/rules/test-draft — config:rule:evaluate. */}
                <Can permission={PERM.configRuleEvaluate} mode="disable">
                <button
                  type="button"
                  className="btn-primary h-38px mt-2 justify-center gap-2 disabled:pointer-events-none disabled:opacity-50"
                  onClick={runDraftTest}
                  disabled={testing || !tenantId}
                >
                  {testing ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />} {testing ? 'Evaluating…' : 'Evaluate Rule'}
                </button>
                </Can>
              </div>
            </section>

            <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
              <header className="border-b border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-3 text-sm font-semibold text-[var(--text-primary)]">Result</header>
              <div className="p-4">
                {!testResult ? (
                  <div className="flex flex-col items-center gap-1 py-10 text-center text-[var(--text-muted)]">
                    <Beaker size={32} className="opacity-40" />
                    <p className="text-sm">Click Evaluate Rule to see whether the conditions match.</p>
                  </div>
                ) : (
                  <>
                    <div className={`mb-3 flex items-center gap-3 rounded-md border p-3 ${testResult.matched ? 'border-[var(--accent-green)] bg-[var(--accent-green)]/10' : 'border-[var(--text-muted)] bg-[var(--bg-secondary)]'}`}>
                      {testResult.matched ? <Check size={20} className="text-[var(--accent-green)]" /> : <X size={20} className="text-[var(--text-muted)]" />}
                      <div className={`font-bold text-sm ${testResult.matched ? 'text-[var(--accent-green)]' : 'text-[var(--text-secondary)]'}`}>
                        {testResult.matched ? 'MATCHED' : 'NOT MATCHED'}
                      </div>
                    </div>
                    {testResult.matched && <ActionsGenerated actions={testResult.actions} approvalMatrix={testResult.approvalMatrix} />}
                    <TestTrace node={testResult.conditionResultTree} catalog={conditionCatalog} />
                  </>
                )}
              </div>
            </section>
          </div>
        )}
      </PageBody>
    </PageShell>
  );
}

/**
 * The Charge Action Type's dependent fields, as the catalog describes them:
 * grouped under their section headings, in display order. Result Type renders as
 * the Fixed / Percentage toggle; every other enum as a dropdown; numbers as inputs.
 */
function ChargeFieldsEditor({
  fields,
  form,
  submitted,
  onChange,
}: {
  fields: RuleActionFieldDef[];
  form: RuleForm;
  submitted: boolean;
  onChange: (field: string, value: string) => void;
}) {
  const sections: { section: string | null; fields: RuleActionFieldDef[] }[] = [];
  for (const field of fields) {
    const key = field.section ?? null;
    const existing = sections.find((s) => s.section === key);
    if (existing) existing.fields.push(field);
    else sections.push({ section: key, fields: [field] });
  }

  return (
    <div className="flex flex-col gap-4">
      {sections.map(({ section, fields: sectionFields }) => {
        const toggles = sectionFields.filter((f) => f.field === 'ResultType');
        const inputs = sectionFields.filter((f) => f.field !== 'ResultType');
        return (
          <div key={section ?? 'default'} className={section ? 'flex flex-col gap-3 rounded-md border border-[var(--border)] p-3' : 'flex flex-col gap-3'}>
            {section && <h4 className="mb-1">{section}</h4>}
            {toggles.map((f) => (
              <div key={f.field} className="tab-main sub-tab mb-[12px]" role="group" aria-label={f.label}>
                {f.options.filter((o) => o.isActive).map((o) => (
                  <ResultTypeButton
                    key={o.code}
                    active={getChargeFieldValue(form, f.field) === o.code}
                    icon={o.code === PERCENTAGE_RESULT_TYPE ? <Percent size={18} /> : <Banknote size={18} />}
                    label={o.label}
                    onClick={() => onChange(f.field, o.code)}
                  />
                ))}
              </div>
            ))}
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {inputs.map((f) => {
                const value = getChargeFieldValue(form, f.field);
                // Amount / Percentage reads as whichever the Result Type toggle selected.
                const label = f.field === 'ResultValue'
                  ? (fields.find((x) => x.field === 'ResultType')?.options.find((o) => o.code === form.resultType)?.label ?? f.label)
                  : f.label;
                const inputId = `charge-field-${f.field}`;
                return (
                  <div key={f.field} className="flex flex-col gap-1.5">
                    <label className="input-label" htmlFor={inputId}>{label}{f.isRequired ? ' *' : ''}</label>
                    {f.valueType === 'enum' ? (
                      <select id={inputId} className="input-cls" value={value} onChange={(e) => onChange(f.field, e.target.value)}>
                        {!value && <option value="" disabled>{f.placeholder ?? 'Select…'}</option>}
                        {selectableOptions(f.options, value).map((o) => (
                          <option key={o.value} value={o.value}>{o.label}</option>
                        ))}
                      </select>
                    ) : (
                      <input
                        id={inputId}
                        className="input-cls"
                        type={f.valueType === 'number' ? 'number' : 'text'}
                        step={f.valueType === 'number' ? '0.01' : undefined}
                        placeholder={f.placeholder ?? undefined}
                        value={value}
                        onChange={(e) => onChange(f.field, e.target.value)}
                      />
                    )}
                    {submitted && f.isRequired && !value && <span className="text-xs text-[var(--accent-red)]">Required</span>}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function InfoNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-blue-200 bg-[#eff6ff] p-3 text-xs text-[#1e40af]">
      {children}
    </div>
  );
}

function ChecklistItem({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      {ok ? <Check size={14} className="text-[var(--accent-green)]" /> : <X size={14} className="text-[var(--text-muted)]" />}
      <span className={ok ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}>{label}</span>
    </div>
  );
}

function ResultTypeButton({ active, icon, label, onClick }: { active: boolean; icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={
        active
          ? 'flex gap-2 items-center tab-pills active-tab'
          : 'tab-pills flex gap-2 items-center'
      }
    >
      {icon}
      <span className="text-xs">{label}</span>
    </button>
  );
}

function TestTrace({ node, catalog, depth = 0 }: { node: ConditionTestNode | null; catalog: ConditionCatalog; depth?: number }) {
  if (!node) return <p className="text-sm text-[var(--text-muted)]">No conditions to evaluate.</p>;
  if (node.type === 'group') {
    return (
      <div className={depth > 0 ? 'ml-4 mt-1.5 border-l border-[var(--border)] pl-3' : 'mt-1.5'}>
        <div className="mb-1 flex items-center gap-2 text-xs font-semibold text-[var(--text-muted)]">
          <span>{node.operator === 'OR' ? 'ANY (OR) of:' : 'ALL (AND) of:'}</span>
          <ResultDot passed={node.passed} />
        </div>
        {node.children.map((c, i) => <TestTrace key={i} node={c} catalog={catalog} depth={depth + 1} />)}
      </div>
    );
  }
  return (
    <div className={depth > 0 ? 'ml-4 flex items-center gap-2 py-0.5 text-xs' : 'flex items-center gap-2 py-0.5 text-xs'}>
      <ResultDot passed={node.passed} />
      <span className="font-mono">{node.field}</span>
      <span className="text-[var(--text-muted)]">{getOperatorLabel(catalog, node.operator, node.field)}</span>
      <span className="font-mono">{node.expectedValue}</span>
      <span className="text-[var(--text-muted)]">(actual: {node.actualValue ?? '—'})</span>
    </div>
  );
}

function ResultDot({ passed }: { passed: boolean }) {
  return (
    <span className={`inline-flex h-4 w-4 items-center justify-center rounded-full ${passed ? 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]' : 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]'}`}>
      {passed ? <Check size={10} /> : <X size={10} />}
    </span>
  );
}
