import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Beaker, Check, Filter, FlaskConical, Loader2, Play, RefreshCw, X } from 'lucide-react';
import { Badge, Button, Can, PageBody, PageHeader, PageShell, Select } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { useAuthStore } from '../../stores/authStore';
import { ruleEngineApi } from './api';
import { ActionsGenerated } from './ActionsGenerated';
import { collectConditionLeaves, getOperatorLabel, type ConditionCatalog } from './types';
import { useConditionCatalog } from './useRuleMetadata';
import type { ChargeRuleListItem, ConditionNode, ConditionTestNode, TestRuleResponse } from './types';

/**
 * Rule Test Console — port of the Angular admin-portal's RuleTestComponent
 * (frontend/admin-portal/src/app/views/ops-console/rules/rule-test.component.ts),
 * extended per FSD Section 10.4 (Screen G): the Sample Payment Context form
 * shows the FULL condition-field catalog grouped by category — not just the
 * fields the selected rule happens to reference — so any transaction detail
 * can be set, with the rule's own conditions highlighted for guidance.
 */

/** One distinct field the selected rule's conditions reference, used only to annotate the full form with a hint. */
interface RuleConditionHint {
  /** Human-readable summary of what this rule checks for this field, e.g. "GreaterThan 50000". */
  summary: string;
}

/** One display row of a flattened condition-result tree — a bracket header or a leaf's pass/fail. */
interface ConditionResultRow {
  kind: 'group' | 'leaf';
  depth: number;
  operator?: string;
  field?: string;
  expectedValue?: string;
  actualValue?: string | null;
  passed: boolean;
}

/** Every field this rule's own conditions reference, keyed by field, for the "used by this rule" hint on the full form. */
function buildConditionHints(tree: ConditionNode | null, catalog: ConditionCatalog): Map<string, RuleConditionHint> {
  const byField = new Map<string, { operator: string; value: string; valueTo?: string }[]>();
  for (const leaf of collectConditionLeaves(tree)) {
    const list = byField.get(leaf.field) ?? [];
    list.push({ operator: leaf.operator, value: leaf.value, valueTo: leaf.valueTo });
    byField.set(leaf.field, list);
  }
  const hints = new Map<string, RuleConditionHint>();
  for (const [field, leaves] of byField) {
    hints.set(field, { summary: leaves.map((l) => `${getOperatorLabel(catalog, l.operator, field)} ${l.valueTo ? `${l.value}-${l.valueTo}` : l.value}`).join(' / ') });
  }
  return hints;
}

function flattenConditionResults(node: ConditionTestNode | null, depth = 0): ConditionResultRow[] {
  if (!node) return [];
  if (node.type === 'group') {
    return [
      { kind: 'group', depth, operator: node.operator, passed: node.passed },
      ...node.children.flatMap((c) => flattenConditionResults(c, depth + 1)),
    ];
  }
  return [{ kind: 'leaf', depth, field: node.field, operator: node.operator, expectedValue: node.expectedValue, actualValue: node.actualValue, passed: node.passed }];
}

const STATUS_BADGE_VARIANT: Record<string, 'green' | 'default' | 'amber' | 'blue' | 'red'> = {
  Active: 'green', Inactive: 'default', Draft: 'amber', Pending: 'blue', Rejected: 'red',
};

export function RuleTestConsolePage() {
  const navigate = useNavigate();
  const tenantId = useAuthStore((s) => s.activeTenantId);

  const [rules, setRules] = useState<ChargeRuleListItem[]>([]);
  const [loadingRules, setLoadingRules] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [selectedRuleId, setSelectedRuleId] = useState<number | null>(null);
  const [selectedRule, setSelectedRule] = useState<ChargeRuleListItem | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [conditionTree, setConditionTree] = useState<ConditionNode | null>(null);
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  // The full parameter catalog (every Rule Type), as configured — only active parameters are offered as inputs.
  const { catalog } = useConditionCatalog(tenantId);
  const fieldGroups = useMemo(
    () => catalog.groups.map((g) => ({ group: g.label, fields: g.fields.filter((f) => f.isActive) })).filter((g) => g.fields.length > 0),
    [catalog],
  );
  const conditionHints = useMemo(() => buildConditionHints(conditionTree, catalog), [conditionTree, catalog]);

  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<TestRuleResponse | null>(null);

  useEffect(() => {
    if (!tenantId) return;
    setLoadingRules(true);
    setLoadError(null);
    ruleEngineApi
      .list(tenantId)
      .then((res) => setRules(res.data.filter((r) => r.isCurrentVersion)))
      .catch(() => setLoadError('Failed to load rules. Please try again.'))
      .finally(() => setLoadingRules(false));
  }, [tenantId]);

  const conditionResultRows = useMemo(() => flattenConditionResults(result?.conditionResultTree ?? null), [result]);

  function onRuleSelected(value: string) {
    const ruleId = value ? Number(value) : null;
    setSelectedRuleId(ruleId);
    setResult(null);
    setSelectedRule(null);
    setConditionTree(null);
    setParamValues({});
    if (ruleId == null) return;

    setSelectedRule(rules.find((r) => r.ruleId === ruleId) ?? null);
    setLoadingDetail(true);
    setLoadError(null);

    ruleEngineApi
      .getById(ruleId)
      .then((res) => {
        setLoadingDetail(false);
        setConditionTree(res.data.conditionTree);
      })
      .catch(() => {
        setLoadingDetail(false);
        setLoadError('Failed to load rule. Please try again.');
      });
  }

  function reset() {
    setResult(null);
    setParamValues({});
  }

  function runTest() {
    if (!selectedRuleId) return;
    setTesting(true);
    setResult(null);

    const parameters: Record<string, string> = {};
    for (const [key, value] of Object.entries(paramValues)) {
      if (value !== '' && value != null) parameters[key] = String(value);
    }

    ruleEngineApi
      .test(selectedRuleId, parameters)
      .then((res) => setResult(res.data))
      .catch(() => setLoadError('Something went wrong. Please try again.'))
      .finally(() => setTesting(false));
  }

  return (
    <PageShell>
      <PageHeader
        title={
          <span className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate('/rule-engine')} title="Back to rules list"><ArrowLeft size={16} /></Button>
            <FlaskConical size={18} className="text-[var(--accent)]" /> Rule Test Console
          </span>
        }
        subtitle="Select any rule, build a sample transaction, and run it through the Rule Engine to see which conditions pass"
      />

      <PageBody>
        {!tenantId && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            No tenant context found for the current user — please sign in again.
          </div>
        )}
        {loadError && (
          <div className="mb-4 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-3.5 py-2.5 text-sm text-[var(--accent-red)]">
            {loadError}
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* Left: Rule selection + dynamic condition parameters */}
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <header className="border-b border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-3 text-sm font-semibold text-[var(--text-primary)]">Select Rule</header>
            <div className="flex flex-col gap-4 p-4">
              <Select
                label="Rule"
                placeholder={loadingRules ? 'Loading rules…' : 'Select a rule to test'}
                disabled={loadingRules}
                options={rules.map((r) => ({ label: `${r.ruleCode} — ${r.ruleName}`, value: String(r.ruleId) }))}
                value={selectedRuleId != null ? String(selectedRuleId) : ''}
                onValueChange={onRuleSelected}
                helperText={!loadingRules && rules.length === 0 ? 'No rules found for this tenant.' : undefined}
              />

              {loadingDetail && (
                <div className="flex items-center gap-2 text-sm text-[var(--text-muted)]"><Loader2 size={14} className="animate-spin" /> Loading rule…</div>
              )}

              {selectedRule && !loadingDetail && (
                <>
                  <div className="flex flex-wrap items-center gap-2 rounded-md bg-[var(--bg-secondary)] p-2.5">
                    <Badge variant="outline">{selectedRule.rail}</Badge>
                    <span className="text-xs font-semibold text-[var(--text-primary)]">{selectedRule.ruleType}</span>
                    {selectedRule.chargeActionType && <span className="text-xs text-[var(--accent)]">{selectedRule.chargeActionType}</span>}
                    <Badge className="ml-auto" variant={STATUS_BADGE_VARIANT[selectedRule.ruleStatus] ?? 'default'}>{selectedRule.ruleStatus}</Badge>
                  </div>

                  {conditionHints.size === 0 && (
                    <div className="flex items-center gap-2 rounded-md bg-[var(--bg-secondary)] px-3 py-2 text-xs text-[var(--text-muted)]">
                      <Filter size={14} className="opacity-60 shrink-0" /> This rule has no conditions — it will always match, regardless of the values entered below.
                    </div>
                  )}
                  <div className="border-b border-[var(--border)] pb-1.5 text-sm font-semibold text-[var(--text-primary)]">Sample Payment Context</div>
                  <div className="flex flex-col gap-4">
                    {fieldGroups.map(({ group, fields }) => (
                      <div key={group} className="flex flex-col gap-2.5">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{group}</div>
                        {fields.map((f) => {
                          const hint = conditionHints.get(f.field);
                          return (
                            <div key={f.field} className="flex flex-col gap-1">
                              <label className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">
                                {f.label}
                                {hint && <span className="rounded-full bg-[var(--accent)]/15 px-1.5 py-px text-[9px] font-bold normal-case tracking-normal text-[var(--accent)]">used by this rule</span>}
                              </label>
                              {hint && <span className="font-mono text-[10px] text-[var(--accent)]">{hint.summary}</span>}
                              {f.controlType === 'number' && (
                                <input
                                  type="number"
                                  className="rounded-md border border-[var(--border)] bg-[var(--bg-primary)] px-3 py-2 text-sm text-[var(--text-primary)]"
                                  placeholder="Enter value"
                                  value={paramValues[f.field] ?? ''}
                                  onChange={(e) => setParamValues({ ...paramValues, [f.field]: e.target.value })}
                                />
                              )}
                              {f.controlType === 'time' && (
                                <input
                                  type="time"
                                  className="rounded-md border border-[var(--border)] bg-[var(--bg-primary)] px-3 py-2 text-sm text-[var(--text-primary)]"
                                  value={paramValues[f.field] ?? ''}
                                  onChange={(e) => setParamValues({ ...paramValues, [f.field]: e.target.value })}
                                />
                              )}
                              {f.controlType === 'boolean' && (
                                <Select
                                  placeholder="Select…"
                                  options={f.values.filter((v) => v.isActive).map((v) => ({ label: v.label, value: v.code }))}
                                  value={paramValues[f.field] ?? ''}
                                  onValueChange={(v) => setParamValues({ ...paramValues, [f.field]: v })}
                                />
                              )}
                              {f.controlType === 'select' && (
                                <Select
                                  placeholder="Select…"
                                  options={f.values.filter((v) => v.isActive).map((v) => ({ label: v.label, value: v.code }))}
                                  value={paramValues[f.field] ?? ''}
                                  onValueChange={(v) => setParamValues({ ...paramValues, [f.field]: v })}
                                />
                              )}
                              {f.controlType === 'text' && (
                                <input
                                  type="text"
                                  className="rounded-md border border-[var(--border)] bg-[var(--bg-primary)] px-3 py-2 text-sm text-[var(--text-primary)]"
                                  placeholder="Enter value"
                                  value={paramValues[f.field] ?? ''}
                                  onChange={(e) => setParamValues({ ...paramValues, [f.field]: e.target.value })}
                                />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="flex justify-end gap-2 border-t border-[var(--border)] pt-4">
                <Button variant="secondary" size="sm" onClick={reset}><RefreshCw size={14} /> Reset</Button>
                <Can permission={PERM.configRuleEvaluate} mode="disable">
                <Button variant="primary" size="sm" onClick={runTest} disabled={!selectedRuleId || testing || loadingDetail}>
                  {testing ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />} {testing ? 'Running…' : 'Rule Execution'}
                </Button>
                </Can>
              </div>
            </div>
          </section>

          {/* Right: Result */}
          <section className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <header className="flex items-center gap-2 border-b border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-3 text-sm font-semibold text-[var(--text-primary)]">
              <FlaskConical size={16} className="text-[var(--accent)]" /> Test Result
              {result && <span className="ml-auto font-mono text-xs text-[var(--text-muted)]">{result.executionDurationMs}ms</span>}
            </header>
            <div className="p-4">
              {!result ? (
                <div className="flex flex-col items-center gap-1 py-12 text-center text-[var(--text-muted)]">
                  <Beaker size={40} className="opacity-40" />
                  <p className="font-semibold text-[var(--text-primary)]">No test run yet</p>
                  <span className="text-xs">Select a rule, fill in the transaction details, and click &quot;Rule Execution&quot;</span>
                </div>
              ) : !result.success ? (
                <div className="mb-4 flex items-center gap-3 rounded-md border border-[var(--accent-red)] bg-[var(--accent-red)]/10 p-4">
                  <X size={24} className="text-[var(--accent-red)]" />
                  <div>
                    <div className="font-bold text-[var(--accent-red)]">Test failed</div>
                    <div className="text-xs text-[var(--text-muted)]">{result.errorMessage}</div>
                  </div>
                </div>
              ) : (
                <>
                  <div className={`mb-4 flex items-center gap-3 rounded-md border p-4 ${result.matched ? 'border-[var(--accent-green)] bg-[var(--accent-green)]/10' : 'border-[var(--text-muted)] bg-[var(--bg-secondary)]'}`}>
                    {result.matched ? <Check size={24} className="text-[var(--accent-green)]" /> : <X size={24} className="text-[var(--text-muted)]" />}
                    <div>
                      <div className={`font-bold ${result.matched ? 'text-[var(--accent-green)]' : 'text-[var(--text-secondary)]'}`}>{result.matched ? 'PASSED' : 'NOT MATCHED'}</div>
                      <div className="text-xs text-[var(--text-muted)]">{result.ruleCode} — {result.ruleName}</div>
                    </div>
                  </div>

                  {result.matched && (
                    <div className="mb-2 flex flex-col gap-2 rounded-md bg-[var(--bg-secondary)] p-3">
                      <label className="text-[10px] uppercase tracking-wide text-[var(--text-muted)]">Action</label>
                      <span className="font-mono text-sm font-semibold text-[var(--accent)]">{result.actionDescription}</span>
                      <ActionsGenerated actions={result.actions} approvalMatrix={result.approvalMatrix} />
                    </div>
                  )}

                  {conditionResultRows.length > 0 && (
                    <>
                      <div className="mb-2 mt-4 border-b border-[var(--border)] pb-1.5 text-sm font-semibold text-[var(--text-primary)]">Condition Breakdown</div>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse text-xs">
                          <thead>
                            <tr className="bg-[var(--bg-secondary)] text-left text-[10px] uppercase text-[var(--text-muted)]">
                              <th className="px-2.5 py-2">Field</th>
                              <th className="px-2.5 py-2">Operator</th>
                              <th className="px-2.5 py-2">Expected</th>
                              <th className="px-2.5 py-2">Actual</th>
                              <th className="px-2.5 py-2">Result</th>
                            </tr>
                          </thead>
                          <tbody>
                            {conditionResultRows.map((row, i) => (
                              row.kind === 'group' ? (
                                <tr key={i} className="border-b border-[var(--border)] italic text-[var(--text-muted)]">
                                  <td colSpan={4} style={{ paddingLeft: 10 + row.depth * 16 }} className="py-2">
                                    Group — match {row.operator === 'OR' ? 'ANY (OR)' : 'ALL (AND)'} of:
                                  </td>
                                  <td className="py-2"><ResultDot passed={row.passed} /></td>
                                </tr>
                              ) : (
                                <tr key={i} className="border-b border-[var(--border)]">
                                  <td className="py-2 font-mono" style={{ paddingLeft: 10 + row.depth * 16 }}>{row.field}</td>
                                  <td className="py-2">{getOperatorLabel(catalog, row.operator ?? '', row.field)}</td>
                                  <td className="py-2 font-mono">{row.expectedValue}</td>
                                  <td className="py-2 font-mono">{row.actualValue || '—'}</td>
                                  <td className="py-2"><ResultDot passed={row.passed} /></td>
                                </tr>
                              )
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </>
                  )}
                </>
              )}
            </div>
          </section>
        </div>
      </PageBody>
    </PageShell>
  );
}

function ResultDot({ passed }: { passed: boolean }) {
  return (
    <span className={`inline-flex h-5 w-5 items-center justify-center rounded-full ${passed ? 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]' : 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]'}`}>
      {passed ? <Check size={12} /> : <X size={12} />}
    </span>
  );
}
