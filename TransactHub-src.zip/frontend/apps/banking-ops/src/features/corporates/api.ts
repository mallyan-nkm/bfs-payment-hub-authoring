import { bankingApi } from '../../shared/api/bankingApi';
import type {
  BranchOption,
  CorporateDetail,
  CorporateListParams,
  CorporateListResult,
  CorporateRegistration,
  CorporateRegistrationResponse,
  FreezoneOption,
} from './types';

/** Channel identifier the WpsBusiness endpoints require on every corporate call. */
const DEFAULT_CHANNEL = 'IBusiness';

/**
 * X-Channel is mandatory on every corporate call (CorporateRegistrationEndpoints).
 *
 * X-Tenant-Id used to be pinned to 'DIB' here, on the reasoning that corporate reference data
 * (corporate.CorporateHeaders, FreezoneHeaders, BankBranchHeaders) is only seeded for DIB and
 * sending the user's own tenant would return zero rows. The API now verifies the header against
 * the caller's tenant assignments, so pinning it would refuse every non-DIB user outright — and
 * zero rows is the correct answer for a tenant whose reference data has not been seeded. The
 * tenant is stamped by bankingApi from the session's active tenant instead.
 */
const corporateHeaders = { 'X-Channel': DEFAULT_CHANNEL };

const BASE = '/v1/corporates';

export const corporatesApi = {
  register: (payload: CorporateRegistration) =>
    bankingApi
      .post<CorporateRegistrationResponse>(`${BASE}/registration`, payload, { headers: corporateHeaders })
      .then((r) => r.data),

  getByCif: (cifNumber: string) =>
    bankingApi
      .get<CorporateDetail>(`${BASE}/${encodeURIComponent(cifNumber)}`, { headers: corporateHeaders })
      .then((r) => r.data),

  getFreezones: () =>
    bankingApi.get<FreezoneOption[]>(`${BASE}/freezones`, { headers: corporateHeaders }).then((r) => r.data),

  getBranches: () =>
    bankingApi.get<BranchOption[]>(`${BASE}/branches`, { headers: corporateHeaders }).then((r) => r.data),

  list: (params: CorporateListParams) =>
    bankingApi
      .get<CorporateListResult>(BASE, {
        headers: corporateHeaders,
        // Absent filters are left off the query string rather than sent empty.
        params: Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== '')),
      })
      .then((r) => r.data),
};
