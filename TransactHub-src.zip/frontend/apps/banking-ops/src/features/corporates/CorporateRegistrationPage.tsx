import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Building2, ChevronDown, Landmark, Plus, RefreshCw, User, Users, X } from 'lucide-react';
import { Can, PageBody, PageShell, cn } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { corporatesApi } from './api';
import {
  CORPORATE_SUCCESS_STATUS,
  CORPORATE_TYPE_OPTIONS,
  EMIRATE_OPTIONS,
  createEmptyCorporateRegistration,
} from './types';
import type {
  CorporateDetail,
  CorporateRegistration,
  CorporateRegistrationError,
  CorporateRegistrationResponse,
} from './types';

const HINT = 'mt-1 block text-[11px] text-[var(--text-muted)]';

function detailToForm(detail: CorporateDetail, cif: string): CorporateRegistration {
  return {
    ...createEmptyCorporateRegistration(),
    cifNumber: detail.cifNumber ?? cif,
    accountNo: detail.accountNo ?? '',
    corporateName: detail.corporateName ?? '',
    molEstablishmentId: detail.moleEstablishmentId ?? '',
    unifiedNumber: detail.unifiedNumber ?? '',
    corporateType: detail.corporateType ?? '',
    contactName: detail.contactPerson ?? '',
    contactNumber: detail.telephone ?? '',
    email: detail.emailId ?? '',
    emirate: detail.emirateRefCode ? Number(detail.emirateRefCode) : null,
    branchName: detail.branchId ?? '',
    address1: detail.address1 ?? '',
    address2: detail.address2 ?? '',
    freezoneId: detail.freezoneId ?? '',
    tradeLicenseNo: detail.tradeLicenceNo ?? '',
    licenceExpiryDate: detail.licenceExpiryDate ? detail.licenceExpiryDate.substring(0, 10) : '',
    isActive: detail.isActive ?? true,
    wpsRegFormHeld: detail.wpsRegFormHeld ?? false,
    isEdit: '1',
    is_mol_registered: detail.isMolRegistered ? 1 : 0,
    rmName: detail.rmName ?? '',
    rmEmail: detail.rmEmail ?? '',
    bmName: detail.bmName ?? '',
    bmEmail: detail.bmEmail ?? '',
    emails: detail.emails ?? [],
    accountNumbers: detail.accountNumbers ?? [],
  };
}

export function CorporateRegistrationPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const cif = params.get('cif');

  const [form, setForm] = useState<CorporateRegistration>(createEmptyCorporateRegistration);
  const [isEditMode, setIsEditMode] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [serverErrors, setServerErrors] = useState<CorporateRegistrationError[]>([]);
  const [statusMessage, setStatusMessage] = useState('');
  const [toast, setToast] = useState<ToastState | null>(null);
  const [newEmail, setNewEmail] = useState('');
  const [newAccountNumber, setNewAccountNumber] = useState('');
  const errorBannerRef = useRef<HTMLDivElement | null>(null);

  const set = <K extends keyof CorporateRegistration>(key: K, value: CorporateRegistration[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const freezonesQ = useQuery({ queryKey: ['corporate-freezones'], queryFn: () => corporatesApi.getFreezones() });
  const branchesQ = useQuery({ queryKey: ['corporate-branches'], queryFn: () => corporatesApi.getBranches() });
  const referenceDataError = freezonesQ.isError
    ? 'Could not load freezone list from the server.'
    : branchesQ.isError
      ? 'Could not load branch list from the server.'
      : '';

  const detailQ = useQuery({
    queryKey: ['corporate-detail', cif],
    enabled: !!cif,
    queryFn: () => corporatesApi.getByCif(cif as string),
  });

  useEffect(() => {
    if (detailQ.data && cif) {
      setForm(detailToForm(detailQ.data, cif));
      setIsEditMode(true);
    }
  }, [detailQ.data, cif]);

  useEffect(() => {
    if (detailQ.isError && cif) setStatusMessage(`Could not load corporate with CIF ${cif}.`);
  }, [detailQ.isError, cif]);

  // Double rAF: the first waits for React to commit the state update that renders the banner,
  // the second waits for that commit to actually paint — a single setTimeout(0) can still race
  // React 18's batched/async updates and silently no-op on a not-yet-mounted ref. `block:
  // 'center'` (not 'start') keeps the banner from landing flush under the page header. Focusing
  // it (via tabIndex="-1") is a second, browser-native "scroll into view" path and announces the
  // error to screen readers, so the user isn't relying on the smooth-scroll animation alone.
  const scrollToErrorBanner = () =>
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        errorBannerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        errorBannerRef.current?.focus();
      }),
    );

  const hasRequiredFieldErrors =
    !form.cifNumber.trim() ||
    !form.corporateName.trim() ||
    !form.corporateType.trim() ||
    !form.accountNo.trim() ||
    !form.branchName.trim() ||
    form.emirate === null ||
    !form.contactName.trim() ||
    !form.contactNumber.trim() ||
    !form.email.trim() ||
    !form.tradeLicenseNo.trim();

  const invalid = (value: string | null | undefined) => submitted && !value?.trim();
  const emirateInvalid = submitted && form.emirate === null;
  const borderFor = (isInvalid: boolean) => (isInvalid ? '!border-red-500 focus:!border-red-500' : '');

  const resetForm = () => {
    setForm(createEmptyCorporateRegistration());
    setNewEmail('');
    setNewAccountNumber('');
    setSubmitted(false);
    setServerErrors([]);
    setStatusMessage('');
    setIsEditMode(false);
  };

  const failureHeading = (wasEdit: boolean) =>
    wasEdit
      ? 'Corporate update failed. Please review the errors below.'
      : 'Corporate registration failed. Please review the errors below.';

  const registerM = useMutation({
    mutationFn: (payload: CorporateRegistration) => corporatesApi.register(payload),
    onSuccess: (response) => {
      const wasEdit = isEditMode;
      if (response.statusCode === CORPORATE_SUCCESS_STATUS) {
        resetForm();
        setToast({
          tone: 'success',
          message:
            response.statusDesc?.trim() ||
            (wasEdit ? 'Corporate updated successfully.' : 'Corporate registered successfully.'),
        });
        return;
      }
      setStatusMessage(failureHeading(wasEdit));
      setServerErrors(response.errors ?? []);
      scrollToErrorBanner();
    },
    onError: (err: unknown) => {
      const body = (err as { response?: { data?: CorporateRegistrationResponse } }).response?.data;
      if (body) {
        setStatusMessage(body.statusDesc && body.statusDesc !== 'FAILED' ? body.statusDesc : failureHeading(isEditMode));
        setServerErrors(body.errors ?? []);
      } else {
        setStatusMessage('Could not reach the corporate registration service. Please try again.');
        setServerErrors([]);
      }
      scrollToErrorBanner();
    },
  });

  const submitRegistration = () => {
    setSubmitted(true);
    setServerErrors([]);
    setToast(null);
    if (hasRequiredFieldErrors) {
      scrollToErrorBanner();
      return;
    }
    registerM.mutate({ ...form, isEdit: isEditMode ? '1' : '0' });
  };

  const loadSampleData = () => {
    const suffix = Math.floor(1000 + Math.random() * 9000).toString();
    const sampleCif = `DIB${suffix}`;
    setForm({
      ...createEmptyCorporateRegistration(),
      cifNumber: sampleCif,
      accountNo: `012345${sampleCif}01`,
      corporateName: 'Test Comp LLC',
      molEstablishmentId: '0001234567890',
      unifiedNumber: 'P12345',
      corporateType: 'C',
      contactName: 'John Doe',
      contactNumber: '0501234567',
      email: 'dib@example.com',
      emirate: 1,
      branchName: 'DIB001',
      address1: 'Business Bay',
      address2: 'Dubai',
      freezoneId: '000',
      tradeLicenseNo: 'TL12345',
      licenceExpiryDate: '2027-12-31',
      isActive: true,
      wpsRegFormHeld: true,
      isEdit: isEditMode ? '1' : '0',
      is_mol_registered: 0,
      rmName: 'RM Name',
      rmEmail: 'rm@example.com',
      bmName: 'BM Name',
      bmEmail: 'bm@example.com',
      emails: ['ops@example.com', 'ops2@example.com'],
      accountNumbers: [`012345${sampleCif}02`],
    });
    setSubmitted(false);
    setServerErrors([]);
    setStatusMessage('');
    setToast(null);
  };

  const addEmail = () => {
    const value = newEmail.trim();
    if (value && !form.emails.includes(value)) set('emails', [...form.emails, value]);
    setNewEmail('');
  };
  const addAccountNumber = () => {
    const value = newAccountNumber.trim();
    if (value && !form.accountNumbers.includes(value)) set('accountNumbers', [...form.accountNumbers, value]);
    setNewAccountNumber('');
  };

  const saving = registerM.isPending;

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pb-6 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / Admin / '}
              <button onClick={() => navigate('/corporates/list')} className="text-[var(--primary-blue)] hover:underline">
                Registered Corporates
              </button>
              {' / '}
              <span className="text-[var(--text-secondary)]">Corporate Registration</span>
            </p>
          </div>

          {/* Title Header & Actions */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                Corporate Registration
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Register a new corporate customer or update an existing one
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={loadSampleData}
                className="btn-secondary h-38px inline-flex items-center gap-1.5 text-xs"
              >
                <RefreshCw size={13} /> Load Sample
              </button>
              <div className='flex btn-tertiary h-38px'>
                 <label className="flex cursor-pointer items-center gap-2 text-xs font-semibold text-[var(--text-secondary)]">
                <input
                  type="checkbox"
                  checked={isEditMode}
                  onChange={(e) => setIsEditMode(e.target.checked)}
                  className="size-4 rounded accent-[var(--primary-blue)]"
                />
                Edit mode
              </label>
              </div>
             
            </div>
          </div>

          {referenceDataError && (
            <div className="flex items-start gap-2.5 rounded-xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-900 shadow-xs">
              <span aria-hidden="true" className="font-bold">⚠</span>
              <div>
                <p className="font-semibold">{referenceDataError}</p>
                <p className="mt-0.5 text-[11px] text-amber-800">
                  Freezone / Branch dropdowns may be empty until the reference-data service is reachable.
                </p>
              </div>
            </div>
          )}

          {(statusMessage || (submitted && hasRequiredFieldErrors)) && (
            <div
              ref={errorBannerRef}
              tabIndex={-1}
              className="flex items-start gap-2.5 rounded-xl border border-red-300 bg-red-50 p-4 text-xs text-red-900 shadow-xs outline-none"
            >
              <span aria-hidden="true" className="font-bold">⚠</span>
              <div>
                <p className="font-semibold">{statusMessage || 'Please complete all required fields'}</p>
                {serverErrors.length > 0 ? (
                  <ul className="mt-1 list-inside list-disc text-[11px]">
                    {serverErrors.map((err) => (
                      <li key={err.errorCode}>
                        [{err.errorCode}] {err.errorDesc}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-0.5 text-[11px] text-red-800">
                    Fields marked with <span className="text-red-600 font-bold">*</span> are mandatory.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* ═══ Corporate Identification ═══ */}
          <Card icon={<Building2 size={18} className="text-[var(--primary-blue)]" />} title="Corporate Identification" subtitle="CIF, licensing and registration identifiers">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="CIF Number" required hint="Exactly 7 alphanumeric characters">
                <input
                  value={form.cifNumber}
                  onChange={(e) => set('cifNumber', e.target.value)}
                  maxLength={7}
                  placeholder="e.g. DIB1586"
                  className={cn('input-cls h-10 w-full text-xs font-mono', borderFor(invalid(form.cifNumber)))}
                />
              </Field>
              <Field label="Corporate Name" required>
                <input
                  value={form.corporateName}
                  onChange={(e) => set('corporateName', e.target.value)}
                  placeholder="e.g. Test Comp LLC"
                  className={cn('input-cls h-10 w-full text-xs', borderFor(invalid(form.corporateName)))}
                />
              </Field>
              <Field label="Corporate Type" required>
                <div className="relative">
                  <select
                    value={form.corporateType}
                    onChange={(e) => set('corporateType', e.target.value)}
                    className={cn('input-cls h-10 w-full appearance-none pr-9 text-xs', borderFor(invalid(form.corporateType)))}
                  >
                    <option value="">— Select Type —</option>
                    {CORPORATE_TYPE_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label} ({o.value})
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
                </div>
              </Field>
              <Field label="Unified Number">
                <input
                  value={form.unifiedNumber}
                  onChange={(e) => set('unifiedNumber', e.target.value)}
                  placeholder="e.g. P12345"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
              <Field label="MOL Establishment ID">
                <input
                  value={form.molEstablishmentId}
                  onChange={(e) => set('molEstablishmentId', e.target.value)}
                  placeholder="e.g. 0001234567890"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
              <Field label="Trade License No" required>
                <input
                  value={form.tradeLicenseNo}
                  onChange={(e) => set('tradeLicenseNo', e.target.value)}
                  placeholder="e.g. TL12345"
                  className={cn('input-cls h-10 w-full text-xs', borderFor(invalid(form.tradeLicenseNo)))}
                />
              </Field>
              <Field label="Licence Expiry Date">
                <input
                  type="date"
                  value={form.licenceExpiryDate}
                  onChange={(e) => set('licenceExpiryDate', e.target.value)}
                  className="input-cls h-10 w-full text-xs d-block"
                />
              </Field>
              <Field label="Freezone ID" hint="Derived by server from MOL Establishment ID">
                <div className="relative">
                  <select
                    value={form.freezoneId}
                    onChange={(e) => set('freezoneId', e.target.value)}
                    className="input-cls h-10 w-full appearance-none pr-9 text-xs"
                  >
                    <option value="">— Select Freezone —</option>
                    {(freezonesQ.data ?? []).map((o) => (
                      <option key={o.freezoneId} value={o.freezoneId}>
                        {o.freezoneId} — {o.description}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
                </div>
              </Field>
            </div>

            <div className="mt-5 flex flex-wrap gap-6 border-t border-[var(--border)] pt-4">
              <Toggle
                label="MOL Registered"
                checked={form.is_mol_registered === 1}
                onChange={(v) => set('is_mol_registered', v ? 1 : 0)}
              />
              <Toggle
                label="WPS Registration Form Held"
                checked={form.wpsRegFormHeld}
                onChange={(v) => set('wpsRegFormHeld', v)}
              />
              <Toggle label="Active" checked={form.isActive} onChange={(v) => set('isActive', v)} />
            </div>
          </Card>

          {/* ═══ Account & Address ═══ */}
          <Card icon={<Landmark size={18} className="text-[var(--primary-blue)]" />} title="Account & Address" subtitle="Primary account, branch and location details">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Primary Account No" required hint="15 characters — CIF at pos 7">
                <input
                  value={form.accountNo}
                  onChange={(e) => set('accountNo', e.target.value)}
                  maxLength={15}
                  placeholder="e.g. 012345DIB158601"
                  className={cn('input-cls h-10 w-full text-xs font-mono', borderFor(invalid(form.accountNo)))}
                />
              </Field>
              <Field label="Branch" required>
                <div className="relative">
                  <select
                    value={form.branchName}
                    onChange={(e) => set('branchName', e.target.value)}
                    className={cn('input-cls h-10 w-full appearance-none pr-9 text-xs', borderFor(invalid(form.branchName)))}
                  >
                    <option value="">— Select Branch —</option>
                    {(branchesQ.data ?? []).map((o) => (
                      <option key={o.branchId} value={o.branchId}>
                        {o.branchId} — {o.branchName}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
                </div>
              </Field>
              <Field label="Emirate" required>
                <div className="relative">
                  <select
                    value={form.emirate ?? ''}
                    onChange={(e) => set('emirate', e.target.value === '' ? null : Number(e.target.value))}
                    className={cn('input-cls h-10 w-full appearance-none pr-9 text-xs', borderFor(emirateInvalid))}
                  >
                    <option value="">— Select Emirate —</option>
                    {EMIRATE_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
                </div>
              </Field>
              <Field label="Address Line 1">
                <input
                  value={form.address1}
                  onChange={(e) => set('address1', e.target.value)}
                  placeholder="e.g. Business Bay"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
              <Field label="Address Line 2">
                <input
                  value={form.address2}
                  onChange={(e) => set('address2', e.target.value)}
                  placeholder="e.g. Dubai"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
            </div>

            <TagRepeater
              label="Additional Account Numbers"
              values={form.accountNumbers}
              onRemove={(i) => set('accountNumbers', form.accountNumbers.filter((_, idx) => idx !== i))}
              inputValue={newAccountNumber}
              onInputChange={setNewAccountNumber}
              onAdd={addAccountNumber}
              placeholder="e.g. 012345DIB165902"
              maxLength={15}
            />
          </Card>

          {/* ═══ Contact Details ═══ */}
          <Card icon={<User size={18} className="text-[var(--primary-blue)]" />} title="Contact Details" subtitle="Primary point of contact for this corporate">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Contact Name" required>
                <input
                  value={form.contactName}
                  onChange={(e) => set('contactName', e.target.value)}
                  placeholder="e.g. John Doe"
                  className={cn('input-cls h-10 w-full text-xs', borderFor(invalid(form.contactName)))}
                />
              </Field>
              <Field label="Contact Number" required>
                <input
                  type="tel"
                  value={form.contactNumber}
                  onChange={(e) => set('contactNumber', e.target.value)}
                  placeholder="e.g. 0501234567"
                  className={cn('input-cls h-10 w-full text-xs', borderFor(invalid(form.contactNumber)))}
                />
              </Field>
              <Field label="Email" required>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => set('email', e.target.value)}
                  placeholder="e.g. dib@example.com"
                  className={cn('input-cls h-10 w-full text-xs', borderFor(invalid(form.email)))}
                />
              </Field>
            </div>

            <TagRepeater
              label="Additional Emails"
              values={form.emails}
              onRemove={(i) => set('emails', form.emails.filter((_, idx) => idx !== i))}
              inputValue={newEmail}
              onInputChange={setNewEmail}
              onAdd={addEmail}
              placeholder="e.g. ops@example.com"
              type="email"
            />
          </Card>

          {/* ═══ Relationship Management ═══ */}
          <Card icon={<Users size={18} className="text-[var(--primary-blue)]" />} title="Relationship Management" subtitle="Assigned relationship and branch managers">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Field label="RM Name">
                <input
                  value={form.rmName}
                  onChange={(e) => set('rmName', e.target.value)}
                  placeholder="e.g. RM Name"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
              <Field label="RM Email">
                <input
                  type="email"
                  value={form.rmEmail}
                  onChange={(e) => set('rmEmail', e.target.value)}
                  placeholder="e.g. rm@example.com"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
              <Field label="BM Name">
                <input
                  value={form.bmName}
                  onChange={(e) => set('bmName', e.target.value)}
                  placeholder="e.g. BM Name"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
              <Field label="BM Email">
                <input
                  type="email"
                  value={form.bmEmail}
                  onChange={(e) => set('bmEmail', e.target.value)}
                  placeholder="e.g. bm@example.com"
                  className="input-cls h-10 w-full text-xs"
                />
              </Field>
            </div>
          </Card>

          {/* ═══ Footer Actions ═══ */}
          <div className="flex flex-wrap justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={resetForm}
              disabled={saving}
              className="btn-secondary large-btn !w-28 justify-center disabled:opacity-45"
            >
              Reset
            </button>
            {/* The server admits the route on create OR edit, then requires create for isEdit="0"
                and edit for isEdit="1" (AuthorizeIsEditAsync). The button asks the same question. */}
            <Can permission={isEditMode ? PERM.corporateEdit : PERM.corporateCreate}>
              <button
                type="button"
                onClick={submitRegistration}
                disabled={saving}
                className="btn-primary large-btn !w-44 justify-center disabled:cursor-not-allowed disabled:opacity-60"
              >
                {saving ? 'Submitting…' : isEditMode ? 'Save Changes' : 'Submit Registration'}
              </button>
            </Can>
          </div>
        </div>
      </PageBody>

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}

function Card({ icon, title, subtitle, children }: { icon: ReactNode; title: string; subtitle: string; children: ReactNode }) {
  return (
    <section className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm">
      <div className="flex items-center gap-3 border-b border-[var(--border)] bg-[var(--bg-secondary)]/50 px-5 py-3.5">
        <span className="grid size-9 place-items-center rounded-lg border border-[var(--border)] bg-[var(--bg-card)] shadow-xs">
          {icon}
        </span>
        <div>
          <p className="text-[14px] font-bold text-[var(--text-primary)]">{title}</p>
          <p className="text-xs text-[var(--text-muted)]">{subtitle}</p>
        </div>
      </div>
      <div className="p-5">{children}</div>
    </section>
  );
}

function Field({ label, required, hint, children }: { label: string; required?: boolean; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="input-label mb-1.5 block">
        {label} {required && <span className="text-red-500 font-bold">*</span>}
      </span>
      {children}
      {hint && <span className={HINT}>{hint}</span>}
    </label>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer items-center gap-2 text-xs font-semibold text-[var(--text-secondary)]">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="peer sr-only" />
      <span
        className={cn(
          'relative h-5 w-9 shrink-0 rounded-full transition-colors',
          checked ? 'bg-[var(--primary-blue)]' : 'bg-[var(--border)]',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 size-4 rounded-full bg-white switch-bg transition-all shadow-xs',
            checked ? 'left-[18px]' : 'left-0.5',
          )}
        />
      </span>
      {label}
    </label>
  );
}

interface TagRepeaterProps {
  label: string;
  values: string[];
  onRemove: (index: number) => void;
  inputValue: string;
  onInputChange: (value: string) => void;
  onAdd: () => void;
  placeholder: string;
  maxLength?: number;
  type?: string;
}

function TagRepeater({
  label,
  values,
  onRemove,
  inputValue,
  onInputChange,
  onAdd,
  placeholder,
  maxLength,
  type = 'text',
}: TagRepeaterProps) {
  return (
    <div className="mt-5 border-t border-[var(--border)] pt-4">
      <span className="input-label mb-2 block">{label}</span>
      <div className="flex flex-wrap items-center gap-2">
        {values.map((value, i) => (
          <span
            key={value}
            className="inline-flex items-center gap-1.5 rounded-full border border-[var(--border)] bg-[var(--bg-secondary)]/60 px-3 py-1 text-xs font-semibold text-[var(--text-primary)]"
          >
            {value}
            <button
              type="button"
              onClick={() => onRemove(i)}
              aria-label={`Remove ${value}`}
              className="text-[var(--text-muted)] hover:text-red-600 transition-colors"
            >
              <X size={12} />
            </button>
          </span>
        ))}
        <span className="flex items-center gap-2">
          <input
            type={type}
            value={inputValue}
            maxLength={maxLength}
            onChange={(e) => onInputChange(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                onAdd();
              }
            }}
            placeholder={placeholder}
            aria-label={label}
            className="input-cls h-8 w-60 text-xs"
          />
          <button
            type="button"
            onClick={onAdd}
            className="btn-secondary large-btn !py-1 !px-3 text-xs inline-flex items-center gap-1"
          >
            <Plus size={12} /> Add
          </button>
        </span>
      </div>
    </div>
  );
}