/**
 * Corporate registration — mirrors the POST /api/v1/corporates/registration payload
 * (PaymentHub.WpsBusiness.Application.Features.CorporateRegistration).
 */
export interface CorporateRegistration {
  cifNumber: string;
  accountNo: string;
  corporateName: string;
  molEstablishmentId: string;
  unifiedNumber: string;
  corporateType: string;
  contactName: string;
  contactNumber: string;
  email: string;
  emirate: number | null;
  branchName: string;
  address1: string;
  address2: string;
  freezoneId: string;
  tradeLicenseNo: string;
  licenceExpiryDate: string;
  isActive: boolean;
  wpsRegFormHeld: boolean;
  isEdit: '0' | '1';
  is_mol_registered: 0 | 1;
  rmName: string;
  rmEmail: string;
  bmName: string;
  bmEmail: string;
  emails: string[];
  accountNumbers: string[];
}

export function createEmptyCorporateRegistration(): CorporateRegistration {
  return {
    cifNumber: '',
    accountNo: '',
    corporateName: '',
    molEstablishmentId: '',
    unifiedNumber: '',
    corporateType: '',
    contactName: '',
    contactNumber: '',
    email: '',
    emirate: null,
    branchName: '',
    address1: '',
    address2: '',
    freezoneId: '',
    tradeLicenseNo: '',
    licenceExpiryDate: '',
    isActive: true,
    wpsRegFormHeld: false,
    isEdit: '0',
    is_mol_registered: 0,
    rmName: '',
    rmEmail: '',
    bmName: '',
    bmEmail: '',
    emails: [],
    accountNumbers: [],
  };
}

export interface SelectOption {
  value: string;
  label: string;
}

/** Real backend rule (CorporateRegistrationValidator, error 135): only "C", "S" or "R" are accepted. */
export const CORPORATE_TYPE_OPTIONS: SelectOption[] = [
  { value: 'C', label: 'Corporate' },
  { value: 'S', label: 'SME' },
  { value: 'R', label: 'Retail' },
];

/**
 * Emirate codes. The backend only validates the numeric range 1-7 — there is no server-side
 * name lookup, so this mapping is a UI-only convention carried over from the Angular portal.
 * Note `corporate.BankBranchHeaders` uses a different 2-digit convention; don't cross-reference.
 */
export const EMIRATE_OPTIONS: ReadonlyArray<{ value: number; label: string }> = [
  { value: 1, label: 'Dubai' },
  { value: 2, label: 'Abu Dhabi' },
  { value: 3, label: 'Sharjah' },
  { value: 4, label: 'Ajman' },
  { value: 5, label: 'Umm Al Quwain' },
  { value: 6, label: 'Ras Al Khaimah' },
  { value: 7, label: 'Fujairah' },
];

export interface CorporateRegistrationError {
  errorCode: string;
  errorDesc: string;
}

/** Matches the flat CorporateRegistrationResponse record the WpsBusiness API actually returns. */
export interface CorporateRegistrationResponse {
  cifNumber: string;
  accountNo: string;
  statusCode: number;
  statusDesc: string;
  errors?: CorporateRegistrationError[];
}

/** Status code the backend returns on a successful registration / update. */
export const CORPORATE_SUCCESS_STATUS = 111;

export interface FreezoneOption {
  freezoneId: string;
  description: string | null;
}

export interface BranchOption {
  branchId: string;
  branchName: string;
  emirateRefCode: string | null;
}

export interface CorporateListRow {
  corporateId: string;
  cifNumber: string | null;
  corporateName: string;
  molEstablishmentId: string | null;
  corporateType: string | null;
  branchId: string | null;
  emirateRefCode: string | null;
  accountNo: string | null;
  isActive: boolean;
  createdAt: string;
}

/**
 * Query string of GET /v1/corporates. The column filters mirror the grid's columns one for one;
 * `corporateType` is the existing C / S / R value, `status` is ACTIVE / INACTIVE, and the two created
 * bounds are inclusive yyyy-MM-dd days. `sortBy` is a column's API field name.
 */
export interface CorporateListParams {
  page: number;
  pageSize: number;
  search?: string;
  cifNumber?: string;
  corporateName?: string;
  molEstablishmentId?: string;
  corporateType?: string;
  branchId?: string;
  emirateRefCode?: string;
  accountNo?: string;
  status?: string;
  createdFrom?: string;
  createdTo?: string;
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
}

export interface CorporateListResult {
  totalRecords: number;
  page: number;
  pageSize: number;
  data: CorporateListRow[];
}

/** Shape returned by GET /v1/corporates/{cif} — used to seed the form in edit mode. */
export interface CorporateDetail {
  cifNumber?: string;
  accountNo?: string;
  corporateName?: string;
  moleEstablishmentId?: string;
  unifiedNumber?: string;
  corporateType?: string;
  contactPerson?: string;
  telephone?: string;
  emailId?: string;
  emirateRefCode?: string;
  branchId?: string;
  address1?: string;
  address2?: string;
  freezoneId?: string;
  tradeLicenceNo?: string;
  licenceExpiryDate?: string;
  isActive?: boolean;
  wpsRegFormHeld?: boolean;
  isMolRegistered?: boolean;
  rmName?: string;
  rmEmail?: string;
  bmName?: string;
  bmEmail?: string;
  emails?: string[];
  accountNumbers?: string[];
}
