import type { RefObject } from 'react';
import type { SmartGridColumn } from '@paymenthub/ui';
import { Can, cn, sessionInstant } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { CORPORATE_TYPE_OPTIONS, EMIRATE_OPTIONS } from './types';
import type { CorporateListRow } from './types';

export const emirateLabel = (code: string | null) => {
  if (!code) return '—';
  return EMIRATE_OPTIONS.find((o) => o.value === Number(code))?.label ?? code;
};

export const corporateTypeLabel = (type: string | null) => {
  if (!type) return '—';
  return CORPORATE_TYPE_OPTIONS.find((o) => o.value === type)?.label ?? type;
};

/** The day an instant (`createdAt`) falls on in the session zone, `dd-MM-yyyy`; a thin delegate. */
export const formatDate = (iso: string) => sessionInstant(iso, 'date');

/** Filter options are `{ value: <what the API takes>, label: <what the operator reads> }`. */
const TYPE_FILTER_OPTIONS = CORPORATE_TYPE_OPTIONS.map((o) => ({ value: o.value, label: o.label }));
const EMIRATE_FILTER_OPTIONS = EMIRATE_OPTIONS.map((o) => ({ value: String(o.value), label: o.label }));
const STATUS_FILTER_OPTIONS = [
  { value: 'ACTIVE', label: 'Active' },
  { value: 'INACTIVE', label: 'Inactive' },
];

/**
 * What the row action needs from the page. SmartGrid snapshots column definitions on first mount
 * and never re-reads them, so the render closure reads through a ref to see today's handler.
 */
export interface CorporateGridView {
  onViewEdit: (row: CorporateListRow) => void;
}

/**
 * The Registered Corporates grid: the original columns plus MOL ID, each filterable and sortable
 * server-side. `filterKey` is the key in the grid's filter record; the page maps it onto the
 * request. `sortKey` is the API field name the backend's sort allow-list accepts.
 */
export function buildColumns(view: RefObject<CorporateGridView>): SmartGridColumn<CorporateListRow>[] {
  return [
    {
      key: 'cifNumber',
      label: 'CIF',
      filterKey: 'cifNumber',
      sortKey: 'cifNumber',
      getValue: (r) => r.cifNumber ?? '',
      render: (r) => <span className="text-[var(--primary-blue)]">{r.cifNumber || '—'}</span>,
    },
    {
      key: 'corporateName',
      label: 'Corporate Name',
      filterKey: 'corporateName',
      sortKey: 'corporateName',
      getValue: (r) => r.corporateName,
    },
    {
      key: 'molEstablishmentId',
      label: 'MOL ID',
      filterKey: 'molEstablishmentId',
      sortKey: 'molEstablishmentId',
      getValue: (r) => r.molEstablishmentId ?? '',
      render: (r) => r.molEstablishmentId || '—',
    },
    {
      key: 'corporateType',
      label: 'Type',
      filterKey: 'corporateType',
      filterType: 'select',
      filterOptions: TYPE_FILTER_OPTIONS,
      sortKey: 'corporateType',
      getValue: (r) => corporateTypeLabel(r.corporateType),
    },
    {
      key: 'branchId',
      label: 'Branch',
      filterKey: 'branchId',
      sortKey: 'branchId',
      getValue: (r) => r.branchId || '—',
    },
    {
      key: 'emirateRefCode',
      label: 'Emirate',
      filterKey: 'emirateRefCode',
      filterType: 'select',
      filterOptions: EMIRATE_FILTER_OPTIONS,
      sortKey: 'emirateRefCode',
      getValue: (r) => emirateLabel(r.emirateRefCode),
    },
    {
      key: 'accountNo',
      label: 'Account No',
      filterKey: 'accountNo',
      sortKey: 'accountNo',
      getValue: (r) => r.accountNo || '—',
    },
    {
      key: 'status',
      label: 'Status',
      filterKey: 'status',
      filterType: 'select',
      filterOptions: STATUS_FILTER_OPTIONS,
      sortKey: 'isActive',
      getValue: (r) => (r.isActive ? 'Active' : 'Inactive'),
      render: (r) => (
        <span
          className={cn(
            'inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase',
            r.isActive
              ? 'border-green-300 bg-green-50 text-green-700'
              : 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-muted)]',
          )}
        >
          {r.isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'createdAt',
      label: 'Created',
      // A dateRange filter yields two keys - `createdFrom` and `createdTo`.
      filterKey: 'created',
      filterType: 'dateRange',
      sortKey: 'createdAt',
      getValue: (r) => formatDate(r.createdAt),
    },
    {
      key: 'actions',
      label: 'Actions',
      locked: true,
      render: (r) => (
        // Checker-only. Disabled rather than hidden: the row action is part of the grid's shape,
        // and a maker seeing it greyed out learns the capability exists and can ask for it.
        <Can permission={PERM.corporateEdit} mode="disable">
          <button
            type="button"
            onClick={() => view.current.onViewEdit(r)}
            disabled={!r.cifNumber}
            className="btn-tertiary !py-1 !px-2.5 inline-flex items-center gap-1 disabled:cursor-not-allowed disabled:opacity-40"
          >
            View / Edit
          </button>
        </Can>
      ),
    },
  ];
}
