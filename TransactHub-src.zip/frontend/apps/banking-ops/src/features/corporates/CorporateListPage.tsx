import { useEffect, useMemo, useRef, useState } from 'react';
import { PERM } from '../../shared/auth/permissionKeys';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { Can, PageBody, PageShell, SmartGrid } from '@paymenthub/ui';
import type { SmartGridQueryChange } from '@paymenthub/ui';
import { corporatesApi } from './api';
import { buildColumns } from './columns';
import type { CorporateGridView } from './columns';
import type { CorporateListParams, CorporateListRow } from './types';

interface Query {
  page: number;
  pageSize: number;
  filters: Record<string, string>;
  sortBy: string | null;
  sortDir: 'asc' | 'desc';
}

/** Newest registration first - the same order the server uses when no sort is requested. */
const EMPTY_QUERY: Query = { page: 1, pageSize: 20, filters: {}, sortBy: 'createdAt', sortDir: 'desc' };

const PAGE_SIZES = [10, 20, 50];

/**
 * Registered Corporates. Grid mechanics - per-column filters, sorting, column visibility and
 * reorder, pagination - all come from the shared `SmartGrid` in server mode; this page owns the
 * query state, the free-text search that sits beside the grid's own controls, and the mapping of
 * the grid's filter record onto the request.
 */
export function CorporateListPage() {
  const navigate = useNavigate();
  const [query, setQuery] = useState<Query>(EMPTY_QUERY);
  const [searchInput, setSearchInput] = useState('');
  const [appliedSearch, setAppliedSearch] = useState('');

  const listParams: CorporateListParams = useMemo(() => {
    const f = query.filters;
    const value = (key: string) => f[key]?.trim() || undefined;

    return {
      page: query.page,
      pageSize: query.pageSize,
      search: appliedSearch || undefined,
      cifNumber: value('cifNumber'),
      corporateName: value('corporateName'),
      molEstablishmentId: value('molEstablishmentId'),
      corporateType: value('corporateType'),
      branchId: value('branchId'),
      emirateRefCode: value('emirateRefCode'),
      accountNo: value('accountNo'),
      status: value('status'),
      createdFrom: value('createdFrom'),
      createdTo: value('createdTo'),
      sortBy: query.sortBy ?? undefined,
      sortDir: query.sortBy ? query.sortDir : undefined,
    };
  }, [query, appliedSearch]);

  const listQ = useQuery({
    queryKey: ['corporates', listParams],
    queryFn: () => corporatesApi.list(listParams),
    // Hold the previous page on screen while the next one loads, so the total (and with it the
    // clamp below) is never read as zero in the gap between two requests.
    placeholderData: keepPreviousData,
  });

  const rows = listQ.data?.data ?? [];
  const totalRecords = listQ.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalRecords / query.pageSize));
  const hasSettledTotal = listQ.data !== undefined && !listQ.isPlaceholderData;

  // Filtering can shrink the result set below the page the operator was on. SmartGrid's server
  // mode trusts the caller to clamp - without this the query keeps asking for an out-of-range page.
  useEffect(() => {
    if (hasSettledTotal && query.page > totalPages) setQuery((q) => ({ ...q, page: 1 }));
  }, [hasSettledTotal, query.page, totalPages]);

  function handleQueryChange(change: SmartGridQueryChange) {
    setQuery((prev) => ({
      page: change.page ?? prev.page,
      pageSize: change.pageSize ?? prev.pageSize,
      filters: change.filters ?? prev.filters,
      sortBy: change.sortBy !== undefined ? change.sortBy : prev.sortBy,
      sortDir: change.sortDir ?? prev.sortDir,
    }));
  }

  const applySearch = () => {
    setAppliedSearch(searchInput.trim());
    setQuery((q) => ({ ...q, page: 1 }));
  };

  const clearSearch = () => {
    setSearchInput('');
    setAppliedSearch('');
    setQuery((q) => ({ ...q, page: 1 }));
  };

  // SmartGrid snapshots column definitions on first mount, so the row action reads the handler
  // through a ref rather than from the closure it was built with.
  const gridView = useRef<CorporateGridView>({ onViewEdit: () => undefined });
  gridView.current = {
    onViewEdit: (row: CorporateListRow) => {
      if (row.cifNumber) navigate(`/corporates/registration?cif=${encodeURIComponent(row.cifNumber)}`);
    },
  };
  const columns = useMemo(() => buildColumns(gridView), []);

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / Admin / '}
              <span className="text-[var(--text-secondary)]">Registered Corporates</span>
            </p>
          </div>

          {/* Title Header & Main Action */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                Registered Corporates
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Search and manage corporate customer registrations
              </p>
            </div>
            {/* Gated on the create action itself, not on a control key of its own. This is the
                pattern the base expects: the button names the capability the server enforces, so
                the two cannot drift and there is no key in the catalog that guards nothing.

                Maker-only. Hidden rather than disabled: a checker has no path to this capability,
                so advertising it would only invite a support ticket. The server refuses a create
                from a checker regardless — POST /registration checks the isEdit flag against the
                caller's authority, so re-enabling this in dev-tools achieves nothing. */}
            <Can permission={PERM.corporateCreate} mode="hide">
              <button
                type="button"
                onClick={() => navigate('/corporates/registration')}
                className="btn-secondary large-btn inline-flex items-center gap-1.5"
              >
                <Plus size={14} /> New Registration
              </button>
            </Can>
          </div>

          {listQ.isError && (
            <p className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-semibold text-red-600">
              <span aria-hidden="true">⚠</span>
              Could not load the registered corporates list from the server.
            </p>
          )}

          <SmartGrid<CorporateListRow>
            columns={columns}
            rows={rows}
            getRowId={(r) => r.corporateId}
            storageKey="registered-corporates-columns-v1"
            loading={listQ.isFetching}
            pageSizeOptions={PAGE_SIZES}
            emptyTitle="No registered corporates found"
            emptyMessage="No registered corporates match the current search and filters."
            // The list has never offered an export; an empty list renders no export control.
            exportFormats={[]}
            // The toolbar's own Search / Clear buttons apply and reset the free-text box too.
            onSearch={applySearch}
            onClear={clearSearch}
            toolbarStart={
              <input
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') applySearch();
                }}
                placeholder="Search by CIF, corporate name or MOL ID…"
                aria-label="Search corporates"
                className="input-cls h-38px !w-auto min-w-[12rem] flex-1 px-3 text-xs"
              />
            }
            server={{
              page: query.page,
              pageSize: query.pageSize,
              total: totalRecords,
              sortBy: query.sortBy,
              sortDir: query.sortDir,
              onQueryChange: handleQueryChange,
            }}
          />
        </div>
      </PageBody>
    </PageShell>
  );
}
