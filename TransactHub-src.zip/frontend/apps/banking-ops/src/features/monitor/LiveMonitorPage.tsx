import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Radio } from 'lucide-react';
import {
  Badge,
  StatusBadge,
  DataTable,
  PageShell,
  PageHeader,
  PageBody,
} from '@paymenthub/ui';
import type { DataTableColumn, Payment } from '@paymenthub/ui';
import { transactionsApi } from '../operations/transactions/api';

/** Live Monitor — auto-refreshing feed of the most recent transactions (real data). */
export function LiveMonitorPage() {
  const navigate = useNavigate();
  const { data, isFetching } = useQuery({
    queryKey: ['live-monitor'],
    queryFn: () => transactionsApi.search({ page: 1, pageSize: 50 }).then((r) => r.data.items),
    refetchInterval: 10_000,
  });
  const rows = data ?? [];

  const columns: DataTableColumn<Payment>[] = [
    { key: 'referenceNumber', header: 'Transaction ID', render: (r) => <span className="font-mono text-xs text-[var(--accent)]">{r.referenceNumber}</span> },
    { key: 'submittedAt', header: 'Date / Time', kind: 'instant' },
    { key: 'rail', header: 'Application', render: (r) => <Badge variant="outline">{r.rail}</Badge> },
    { key: 'debtorAccount', header: 'Sender', render: (r) => r.debtorAccount || '—' },
    { key: 'creditorAccount', header: 'Receiver', render: (r) => r.creditorAccount || '—' },
    { key: 'amount', header: 'Amount', align: 'right', render: (r) => `${r.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })} ${r.currency}` },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Live Monitor"
        subtitle="Real-time transaction feed · refreshes every 10s"
        actions={
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-green)]/12 px-2.5 py-1 text-xs font-medium text-[var(--accent-green)]">
            <Radio size={13} className={isFetching ? 'animate-pulse' : ''} /> Live
          </span>
        }
      />
      <PageBody>
        <div className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={rows}
            rowKey={(r) => r.id}
            onRowClick={(r) => navigate(`/operations/transactions/${encodeURIComponent(r.id)}/360`)}
            loading={isFetching && rows.length === 0}
            pageSize={25}
            emptyTitle="No live transactions"
            emptyMessage="Nothing has flowed through in the current window."
          />
        </div>
      </PageBody>
    </PageShell>
  );
}
