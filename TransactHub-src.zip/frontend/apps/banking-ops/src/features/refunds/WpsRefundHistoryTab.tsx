import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { Info, SlidersHorizontal, X } from 'lucide-react';
import { SmartGrid, cn, sessionDayOf } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { formatDate } from '../../shared/utils/formatDate';
import { RfrRefund360Drawer } from './RfrRefund360Drawer';
import { RfrAuditTrailDrawer } from './SifAuditTrailDrawer';
import { CHANNEL_TONE, CHIP, OUTCOME_MODIFIER, PILL, PRIORITY_MODIFIER, SMALL_BADGE, STAGE_TONE, STATUS_MODIFIER, dateTime } from './wpsStyles';
import { formatAmount } from './data';
import { RFR_HISTORY, SIF_FILES, rfrRecords } from './wpsData';
import type { RfrHistoryEntry, RfrRecord, RfrStatus, SifFile } from './wpsData';

const STATUSES: RfrStatus[] = ['Pending', 'CB Pending', 'ACK', 'NAK', 'Rejected'];

interface Filters {
  systemRef: string;
  employerAccount: string;
  sifFileName: string;
  originalFileName: string;
  from: string;
  to: string;
  status: RfrStatus | '';
}

/** The period the search opens on — the RFRs of the current month. */
const DEFAULT_FILTERS: Filters = {
  systemRef: '',
  employerAccount: '',
  sifFileName: '',
  originalFileName: '',
  from: '2026-09-01',
  to: '2026-09-30',
  status: '',
};

/** An RSU count: a coloured badge when there is something to count, a muted 0 otherwise. */
function Count({ value, modifier }: { value: number; modifier: string }) {
  return value > 0 ? <span className={cn(SMALL_BADGE, modifier)}>{value}</span> : <span className="text-[var(--text-muted)]">0</span>;
}

/** Handlers behind a ref: SmartGrid snapshots column definitions on first mount. */
interface HistoryGridView {
  rows: RfrHistoryEntry[];
  onDetails: (e: RfrHistoryEntry) => void;
  onRefund360: (e: RfrHistoryEntry) => void;
  onAudit: (e: RfrHistoryEntry) => void;
}

function columns(view: RefObject<HistoryGridView>): SmartGridColumn<RfrHistoryEntry>[] {
  const count = (key: 'acceptedCount' | 'rejectedCount' | 'pendingCount', label: string, modifier: string): SmartGridColumn<RfrHistoryEntry> => ({
    key,
    label,
    numeric: true,
    getValue: (e) => String(e[key]),
    render: (e) => <Count value={e[key]} modifier={modifier} />,
  });
  return [
    {
      key: 'sl',
      label: 'SL',
      locked: true,
      numeric: true,
      render: (e) => {
        const i = view.current.rows.indexOf(e);
        return i < 0 ? '—' : i + 1;
      },
    },
    {
      key: 'rfrFileName',
      label: 'RFR File Name',
      getValue: (e) => e.rfrFileName ?? '',
      render: (e) => (e.rfrFileName ? <span className="font-mono text-xs">{e.rfrFileName}</span> : <span className="text-[var(--text-muted)]">–</span>),
    },
    {
      key: 'rfrRef',
      label: 'RFR Ref. No.',
      sortKey: 'rfrRef',
      getValue: (e) => e.rfrRef ?? '',
      render: (e) => (e.rfrRef ? <span className="font-bold text-[var(--text-primary)]">{e.rfrRef}</span> : <span className="text-[var(--text-muted)]">—</span>),
    },
    {
      key: 'rfrInitiatedAt',
      label: 'RFR Initiation Date',
      sortKey: 'rfrInitiatedAt',
      getValue: (e) => dateTime(e.rfrInitiatedAt),
      getSortValue: (e) => e.rfrInitiatedAt,
    },
    {
      key: 'txnInitiatedAt',
      label: 'Transaction Initiated Date',
      getValue: (e) => dateTime(e.txnInitiatedAt),
      getSortValue: (e) => e.txnInitiatedAt,
    },
    { key: 'initiatedBy', label: 'RFR Initiated By', filterKey: 'initiatedBy', getValue: (e) => e.initiatedBy },
    {
      key: 'employer',
      label: 'Employer (Name / MOL ID)',
      sortKey: 'employerName',
      getValue: (e) => `${e.employerName} ${e.employerId}`,
      render: (e) => (
        <div>
          <p className="text-[var(--text-primary)]">{e.employerName}</p>
          <p className="font-mono text-xs text-[var(--text-muted)]">{e.employerId}</p>
        </div>
      ),
    },
    { key: 'sifFileName', label: 'SIF File Name', getValue: (e) => e.sifFileName, render: (e) => <span className="font-mono text-xs">{e.sifFileName}</span> },
    {
      key: 'originalFileName',
      label: 'SIF Original File Name',
      getValue: (e) => e.originalFileName,
      render: (e) => <span className="font-mono text-xs">{e.originalFileName}</span>,
    },
    { key: 'valueDate', label: 'Value Date', getValue: (e) => formatDate(e.valueDate), getSortValue: (e) => e.valueDate },
    { key: 'records', label: 'No. of Records', numeric: true, getValue: (e) => String(e.records) },
    count('acceptedCount', 'Refund Accepted Count (RSU)', 'success'),
    count('rejectedCount', 'Refund Rejected Count (RSU)', 'error'),
    count('pendingCount', 'Pending Count (RSU)', 'warn'),
    {
      key: 'totalRefund',
      label: 'Total Refund Amount (AED)',
      numeric: true,
      sortKey: 'totalRefund',
      getValue: (e) => formatAmount(e.totalRefund),
      getSortValue: (e) => e.totalRefund,
      render: (e) => <span className="font-bold text-[var(--text-primary)]">{formatAmount(e.totalRefund)}</span>,
    },
    { key: 'currency', label: 'Currency', getValue: (e) => e.currency },
    { key: 'totalCharges', label: 'Total Refund Charges (AED)', numeric: true, getValue: (e) => formatAmount(e.totalCharges) },
    {
      key: 'chargeWaived',
      label: 'RFR Charge Waived',
      getValue: (e) => (e.chargeWaived ? 'Yes' : 'No'),
      render: (e) => <span className={CHIP}>{e.chargeWaived ? 'Yes' : 'No'}</span>,
    },
    {
      key: 'channel',
      label: 'Channel',
      getValue: (e) => e.channel,
      render: (e) => <span className={cn(PILL, CHANNEL_TONE[e.channel])}>{e.channel}</span>,
    },
    {
      key: 'priority',
      label: 'Priority',
      getValue: (e) => e.priority,
      render: (e) => <span className={cn(SMALL_BADGE, PRIORITY_MODIFIER[e.priority])}>{e.priority}</span>,
    },
    {
      key: 'status',
      label: 'Current Status',
      getValue: (e) => e.status,
      render: (e) => <span className={cn(SMALL_BADGE, STATUS_MODIFIER[e.status])}>{e.status}</span>,
    },
    {
      key: 'actions',
      label: 'Action',
      locked: true,
      render: (e) => (
        <div className="pq-row-actions">
          <button type="button" onClick={() => view.current.onDetails(e)} className="btn-secondary pq-view-action-btn">
            View Details
          </button>
          <button type="button" onClick={() => view.current.onRefund360(e)} className="btn-secondary pq-view-action-btn">
            Refund 360
          </button>
          <button type="button" onClick={() => view.current.onAudit(e)} className="btn-secondary pq-view-action-btn">
            Audit
          </button>
        </div>
      ),
    },
  ];
}

function matches(e: RfrHistoryEntry, f: Filters): boolean {
  const has = (value: string | null, q: string) => (value ?? '').toLowerCase().includes(q.trim().toLowerCase());
  const day = sessionDayOf(e.rfrInitiatedAt);
  return (
    // System Reference Number matches the SIF file or the refund reference.
    (!f.systemRef.trim() || has(e.sifFileName, f.systemRef) || has(e.rfrRef, f.systemRef)) &&
    (!f.employerAccount.trim() || has(e.employerAccount, f.employerAccount)) &&
    (!f.sifFileName.trim() || has(e.sifFileName, f.sifFileName)) &&
    (!f.originalFileName.trim() || has(e.originalFileName, f.originalFileName)) &&
    (!f.from || day >= f.from) &&
    (!f.to || day <= f.to) &&
    (!f.status || e.status === f.status)
  );
}

/** The RFR Details grid — one RFR's employee records and where each stands. */
const DETAIL_COLUMNS: SmartGridColumn<RfrRecord>[] = [
  { key: 'sl', label: 'SL', numeric: true, getValue: (r) => String(r.sl), render: (r) => <span className="text-[var(--text-muted)]">{r.sl}</span> },
  { key: 'refundRef', label: 'Refund Ref.', getValue: (r) => r.refundRef, render: (r) => <span className="font-bold text-[var(--text-primary)]">{r.refundRef}</span> },
  { key: 'systemRef', label: 'System Reference No.', getValue: (r) => r.systemRef },
  { key: 'sifFileName', label: 'SIF File Name', getValue: (r) => r.sifFileName, render: (r) => <span className="font-mono text-xs">{r.sifFileName}</span> },
  { key: 'originalFileName', label: 'Original File Name', getValue: (r) => r.originalFileName, render: (r) => <span className="font-mono text-xs">{r.originalFileName}</span> },
  { key: 'employeeId', label: 'Employee ID (MOL ID)', getValue: (r) => r.employeeId, render: (r) => <span className="font-mono text-xs">{r.employeeId}</span> },
  { key: 'employeeName', label: 'Creditor Name (Employee Name)', sortKey: 'employeeName', getValue: (r) => r.employeeName },
  { key: 'employerName', label: 'Employer Name', getValue: (r) => r.employerName },
  { key: 'totalSalary', label: 'Total Salary Amount (Fixed + Variable) (AED)', numeric: true, getValue: (r) => formatAmount(r.totalSalary), getSortValue: (r) => r.totalSalary },
  { key: 'amount', label: 'Refund Amount (AED)', numeric: true, getValue: (r) => formatAmount(r.amount), getSortValue: (r) => r.amount },
  {
    key: 'refundType',
    label: 'Refund Type',
    getValue: (r) => r.refundType,
    render: (r) => <span className={cn(PILL, CHANNEL_TONE['Web Portal'])}>{r.refundType}</span>,
  },
  { key: 'reason', label: 'Refund Reason', getValue: (r) => r.reason },
  {
    key: 'initiated',
    label: 'Initiated By / Date',
    getValue: (r) => `${r.initiatedBy} ${dateTime(r.initiatedAt)}`,
    render: (r) => (
      <div>
        <p className="text-[var(--text-primary)]">{r.initiatedBy}</p>
        <p className="text-xs text-[var(--text-muted)]">{dateTime(r.initiatedAt)}</p>
      </div>
    ),
  },
  {
    key: 'stage',
    label: 'Current Stage',
    getValue: (r) => r.stage,
    render: (r) => <span className={cn(PILL, STAGE_TONE[r.stageTone])}>{r.stage}</span>,
  },
  {
    key: 'status',
    label: 'Refund Status',
    getValue: (r) => r.status,
    render: (r) => <span className={cn(SMALL_BADGE, OUTCOME_MODIFIER[r.status])}>{r.status}</span>,
  },
  {
    key: 'statusDate',
    label: 'Status Date',
    getValue: (r) => (r.statusDate ? dateTime(r.statusDate) : '—'),
    render: (r) => (r.statusDate ? dateTime(r.statusDate) : <span className="text-[var(--text-muted)]">—</span>),
  },
];
/** The count tiles above the history, each with its status's colour. */
const COUNT_TILES: { label: string; status: RfrStatus | null; tone: string }[] = [
  { label: 'All RFRs', status: null, tone: 'text-[var(--accent-blue)]' },
  { label: 'Pending', status: 'Pending', tone: 'text-[var(--accent-amber)]' },
  { label: 'CB Pending', status: 'CB Pending', tone: 'text-[var(--accent-blue)]' },
  { label: 'ACK', status: 'ACK', tone: 'text-[var(--accent-green)]' },
  { label: 'NAK', status: 'NAK', tone: 'text-[var(--accent-red)]' },
  { label: 'Rejected', status: 'Rejected', tone: 'text-[var(--accent-red)]' },
];

/** How many filters differ from the default search. */
function activeCount(f: Filters): number {
  return (Object.keys(f) as (keyof Filters)[]).filter((k) => f[k] !== DEFAULT_FILTERS[k]).length;
}

/** A labelled text input of the filter panel. */
function TextGroup({ id, title, value, placeholder, onChange }: { id: string; title: string; value: string; placeholder: string; onChange: (v: string) => void }) {
  return (
    <div className="pq-filter-group">
      <div className="pq-filter-group-head">
        <label htmlFor={id} className="input-label">
          {title}
        </label>
      </div>
      <input id={id} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="input-cls pq-filter-select" />
    </div>
  );
}

/**
 * WPS refund History — every RFR raised, one row per file, with its RSU outcome counts, amounts and
 * status. View Details shows the RFR's employee records under the grid; Refund 360 and Audit open
 * the RFR's 360 and the SIF's audit trail.
 */
export function WpsRefundHistoryTab({
  onOpen360,
  onUnavailable,
}: {
  onOpen360: (sif: SifFile) => void;
  onUnavailable: (message: string) => void;
}) {
  const [input, setInput] = useState<Filters>(DEFAULT_FILTERS);
  const [applied, setApplied] = useState<Filters>(DEFAULT_FILTERS);
  const [details, setDetails] = useState<RfrHistoryEntry | null>(null);
  const [rfr360, setRfr360] = useState<RfrHistoryEntry | null>(null);
  const [rfrAudit, setRfrAudit] = useState<RfrHistoryEntry | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const filterCount = activeCount(applied);

  const rows = useMemo(() => RFR_HISTORY.filter((e) => matches(e, applied)), [applied]);

  /** The SIF behind an RFR, when this static screen has its 360 / audit data. */
  const sifOf = (e: RfrHistoryEntry) => SIF_FILES.find((s) => s.sifFileName === e.sifFileName);
  const withSif = (e: RfrHistoryEntry, open: (sif: SifFile) => void, what: string) => {
    const sif = sifOf(e);
    if (sif) open(sif);
    else onUnavailable(`${what} for ${e.sifFileName} is not available on this static screen yet.`);
  };

  const gridView = useRef<HistoryGridView>({
    rows,
    onDetails: setDetails,
    onRefund360: setRfr360,
    onAudit: setRfrAudit,
  });
  gridView.current.rows = rows;

  // Built once: SmartGrid never re-reads column definitions, and the closures read through the ref.
  const cols = useMemo(() => columns(gridView), []);
  const closeDetails = useCallback(() => setDetails(null), []);
  const detailsRef = useRef<HTMLElement | null>(null);

  // Bring the newly shown RFR details into view.
  useEffect(() => {
    if (details) detailsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [details]);

  function setFilter<K extends keyof Filters>(key: K, value: Filters[K]) {
    setInput((prev) => ({ ...prev, [key]: value }));
  }

  // Shown above the grid's toolbar: the Advanced Filter button at the right end, and the panel under it while open.
  const filterPanel = (
    <>
      <div className="mb-3 flex justify-end">
        <button
          type="button"
          onClick={() => setFiltersOpen((o) => !o)}
          aria-expanded={filtersOpen}
          aria-controls="rfr-history-advanced-filters"
          className={cn('btn-secondary h-38px gap-2', filtersOpen && 'active')}
        >
          <SlidersHorizontal size={14} aria-hidden="true" />
          Advanced Filter
          {filterCount > 0 && <span className="pq-tab-count">{filterCount}</span>}
        </button>
      </div>
      {filtersOpen && (
        <div id="rfr-history-advanced-filters" className="pq-filter-panel mb-3" aria-label="Advanced filters">
          <div className="pq-filter-grid">
            <TextGroup id="rh-ref" title="System Reference Number" value={input.systemRef} placeholder="SIF or refund reference no." onChange={(v) => setFilter('systemRef', v)} />
            <TextGroup id="rh-account" title="Employer Account Number" value={input.employerAccount} placeholder="e.g. AE070331452100001" onChange={(v) => setFilter('employerAccount', v)} />
            <TextGroup id="rh-sif" title="SIF File Name" value={input.sifFileName} placeholder="e.g. WPS109928838.SIF" onChange={(v) => setFilter('sifFileName', v)} />
            <TextGroup id="rh-original" title="Original File Name" value={input.originalFileName} placeholder="e.g. EmiratesSteel_Salary_Aug26.xlsx" onChange={(v) => setFilter('originalFileName', v)} />
            <div className="pq-filter-group">
              <div className="pq-filter-group-head">
                <label htmlFor="rh-status" className="input-label">
                  Current Status
                </label>
              </div>
              <select id="rh-status" value={input.status} onChange={(e) => setFilter('status', e.target.value as RfrStatus | '')} className="input-cls pq-filter-select">
                <option value="">All</option>
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <div className="pq-filter-group">
              <div className="pq-filter-group-head">
                <span className="input-label">Start Date</span>
              </div>
              <div className="pq-range-row">
                <input type="date" value={input.from} max={input.to || undefined} onChange={(e) => setFilter('from', e.target.value)} aria-label="From date" className="input-cls pq-range-input d-block" />
              </div>
            </div>
            <div className="pq-filter-group">
              <div className="pq-filter-group-head">
                <span className="input-label">End Date</span>
              </div>
              <div className="pq-range-row">
                <input type="date" value={input.to} min={input.from || undefined} onChange={(e) => setFilter('to', e.target.value)} aria-label="To date" className="input-cls pq-range-input d-block" />
              </div>
            </div>
          </div>
          <div className="pq-filter-footer">
            <button
              type="button"
              onClick={() => {
                setInput(DEFAULT_FILTERS);
                setApplied(DEFAULT_FILTERS);
              }}
              className="btn-tertiary h-38px"
            >
              Reset
            </button>
            <div className="pq-filter-footer-actions">
              <button type="button" onClick={() => setApplied(input)} className="btn-primary h-38px">
                Search
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );

  return (
    <>
      {/* RFR counts by status, over every RFR in the history */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
        {COUNT_TILES.map((t) => (
          <div key={t.label} className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] px-5 py-3 shadow-[var(--shadow-sm)]">
            <p className={cn('text-2xl font-black tabular-nums', t.tone)}>{t.status ? RFR_HISTORY.filter((e) => e.status === t.status).length : RFR_HISTORY.length}</p>
            <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">{t.label}</p>
          </div>
        ))}
      </div>

      <p
        role="note"
        className="flex items-start gap-2 rounded-xl border border-[color-mix(in_srgb,var(--accent-blue)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] px-4 py-3 text-sm text-[var(--accent-blue)]"
      >
        <Info size={15} className="mt-0.5 shrink-0" aria-hidden="true" />
        <span>
          Every RFR raised for WPS is listed here file-wise — one row per RFR. Use <strong>View Details</strong> to see the
          individual employee records of an RFR and their outcome.
        </span>
      </p>

      <SmartGrid<RfrHistoryEntry>
        columns={cols}
        rows={rows}
        getRowId={(e) => e.id}
        storageKey="refund-initiation-wps-rfr-history-columns-v1"
        emptyTitle="No RFR files found"
        emptyMessage="No refund requests match the search. Widen the date period or clear the search."
        exportFilename="wps-refund-history"
        exportFormats={['csv']}
        toolbarTop={filterPanel}
      />

      {rfrAudit && <RfrAuditTrailDrawer entry={rfrAudit} onClose={() => setRfrAudit(null)} onUnavailable={onUnavailable} />}

      {rfr360 && (
        <RfrRefund360Drawer
          entry={rfr360}
          onClose={() => setRfr360(null)}
          onOpenSif360={(e) => withSif(e, onOpen360, 'SIF 360')}
          onUnavailable={onUnavailable}
        />
      )}

      {/* RFR Details — under the grid; the page scrolls to it when it opens. Keyed by RFR, so each starts fresh. */}
      {details && (
        <section ref={detailsRef} className="scroll-mt-4" aria-label={`RFR details — ${details.requestRef}`}>
          <SmartGrid<RfrRecord>
            key={details.id}
            columns={DETAIL_COLUMNS}
            rows={rfrRecords(details)}
            getRowId={(r) => String(r.sl)}
            storageKey="refund-initiation-wps-rfr-details-columns-v1"
            emptyTitle="No records"
            emptyMessage="This RFR has no employee records."
            exportFilename={`rfr-details-${details.requestRef.toLowerCase()}`}
            exportFormats={['csv']}
            toolbarTop={
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-[15px] font-bold text-[var(--text-primary)]">
                  RFR Details — <span className="font-mono text-sm">{details.requestRef}</span>
                </h2>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-[var(--text-muted)]">{details.records} records</span>
                  <button
                    type="button"
                    onClick={closeDetails}
                    className="inline-flex items-center gap-1 text-sm font-semibold text-[var(--primary-blue)] hover:underline"
                  >
                    <X size={15} aria-hidden="true" />
                    Close
                  </button>
                </div>
              </div>
            }
          />
        </section>
      )}
    </>
  );
}
