import { rfrCbFiles } from './wpsData';
import type { RfrChannel, RfrHistoryEntry, SifFile } from './wpsData';

/**
 * Static audit trail of a SIF's life — upload, validation, approval, CB exchange, posting, and the
 * refund cycle if it had one. Built from the SIF's own seed data, so every SIF has a trail.
 */

export interface AuditDownload {
  label: string;
  fileName: string;
}

export interface AuditUserRemark {
  name: string;
  role: string;
  remarks: string;
}

/** What "More Details" shows for an activity. */
export interface AuditActivityDetail {
  title: string;
  subtitle: string;
  remarks: AuditUserRemark[];
  downloads: AuditDownload[];
}

export interface AuditActivity {
  id: string;
  activity: string;
  /** A person's name, or a system actor ("System", "Central Bank"). */
  actionBy: string;
  /** Whether `actionBy` names a person — personal data, masked until PII is unmasked. */
  actionByIsPerson: boolean;
  startedAt: string;
  endedAt: string;
  channel: 'Web Portal' | 'System' | 'API';
  /** 'Failure' is the wording the Refund Queue's trails use for a rejected file or recall. */
  status: 'Success' | 'Failed' | 'Failure' | 'Pending';
  remarks: string;
  detail?: AuditActivityDetail;
}

/** `2026-08-27T09:30` plus `seconds` → `2026-08-27T09:30:ss`. */
function at(base: string, seconds: number): string {
  // date-format-ok-begin: mock-data arithmetic on zoneless wall-clock strings, not display
  const d = new Date(base);
  d.setSeconds(d.getSeconds() + seconds);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  // date-format-ok-end
}

const logs = (what: string): AuditDownload[] => [
  { label: `${what} — Request Log`, fileName: `${what.replace(/\W+/g, '_')}_request.json` },
  { label: `${what} — Response Log`, fileName: `${what.replace(/\W+/g, '_')}_response.json` },
];

export function auditActivities(sif: SifFile): AuditActivity[] {
  const v = sif.view360;
  const period = `${sif.salaryMonth}-${sif.salaryYear}`;
  const system = (id: string, activity: string, start: string, seconds: number, channel: AuditActivity['channel'], remarks: string, detail?: AuditActivityDetail, actor = 'System'): AuditActivity => ({
    id,
    activity,
    actionBy: actor,
    actionByIsPerson: false,
    startedAt: start,
    endedAt: at(start, seconds),
    channel,
    status: 'Success',
    remarks,
    detail,
  });
  const person = (id: string, activity: string, name: string, start: string, seconds: number, remarks: string, detail: AuditActivityDetail): AuditActivity => ({
    id,
    activity,
    actionBy: name,
    actionByIsPerson: true,
    startedAt: start,
    endedAt: at(start, seconds),
    channel: 'Web Portal',
    status: 'Success',
    remarks,
    detail,
  });

  const uploadAt = at(sif.initiatedAt, 11);
  const approveAt = at(v.approvedAt, 0);
  const sentAt = at(v.sentToCbAt, 25);
  const ackAt = at(v.sentToCbAt, 198);

  const activities: AuditActivity[] = [
    person('upload', 'SIF File Uploaded', v.initiatedBy, uploadAt, 2, `File received via ${sif.source} — original file ${sif.originalFileName}`, {
      title: 'Uploaded File',
      subtitle: 'Original file and converted SIF — available for download',
      remarks: [
        {
          name: v.initiatedBy,
          role: 'Payment Initiator (Maker)',
          remarks: `Uploading WPS salary file for ${sif.employerName} — ${period} payroll, ${sif.records} employee records`,
        },
      ],
      downloads: [
        { label: 'Original File', fileName: sif.originalFileName },
        { label: 'Converted SIF File', fileName: sif.sifFileName },
      ],
    }),
    system('extract', 'File Extraction', at(uploadAt, 2), 1, 'System', `SIF file parsed — ${sif.records} records extracted and ready for validation`),
    system('validate', 'Format & Structure Validation', at(uploadAt, 3), 4, 'System', 'SIF filename and record structure validated — 8/8 checks passed'),
    person('approve', 'Transaction Approved', v.approvedBy, approveAt, 8, `Payment authorized by ${v.approvedBy} — cleared for CB submission`, {
      title: 'Transaction Approved',
      subtitle: 'Checker decision on the SIF payment',
      remarks: [{ name: v.approvedBy, role: 'Payment Approver (Checker)', remarks: `Approved — payroll matches HR confirmation for ${period}` }],
      downloads: [],
    }),
    system('balance', 'Balance Enquiry — Core Banking Call', at(approveAt, 10), 2, 'System', 'Employer account balance verified — funds available for salary debit', {
      title: 'Balance Enquiry',
      subtitle: 'Core banking request and response',
      remarks: [],
      downloads: logs('Balance Enquiry'),
    }),
    system('submit', 'File Submitted to Central Bank', sentAt, 4, 'API', 'SIF file transmitted to CBUAE WPS gateway', {
      title: 'File Submitted to Central Bank',
      subtitle: 'SIF file sent to the CBUAE WPS gateway',
      remarks: [],
      downloads: [{ label: 'Submitted SIF File', fileName: sif.sifFileName }, ...logs('CB Gateway')],
    }),
    system('ack', 'CB ACK Received', ackAt, 2, 'API', `${v.systemAccepted} salary records accepted by Central Bank`, {
      title: 'CB ACK Received',
      subtitle: 'Central Bank acknowledgement',
      remarks: [],
      downloads: [{ label: 'ACK File', fileName: v.ackFileName }],
    }, 'Central Bank'),
    system('debit', 'Core Banking Debit Posting', at(ackAt, 27), 3, 'System', 'Employer account debited successfully for salary disbursement', {
      title: 'Core Banking Debit Posting',
      subtitle: 'Salary debit posting to the employer account',
      remarks: [],
      downloads: logs('Debit Posting'),
    }),
  ];

  const r = v.refund;
  if (!r) return activities;

  return [
    ...activities,
    person('rfr', 'Refund Initiated (RFR)', r.initiatedBy, '2026-09-22T09:30:05', 35, `${r.records} employee record(s) selected for refund`, {
      title: 'Refund Initiated',
      subtitle: `Refund request ${r.refundRef}`,
      remarks: [{ name: r.initiatedBy, role: 'Refund Initiator (Maker)', remarks: 'Refund raised — salary credited to an account the employee has closed' }],
      downloads: [],
    }),
    person('rfr-push', 'Refund Verified — RFR Pushed to CB', r.approvedBy, '2026-09-22T10:02:11', 8, 'RFR generated and pushed to CB-WPS SFTP', {
      title: 'Refund Verified',
      subtitle: 'RFR generated and pushed to the Central Bank',
      remarks: [{ name: r.approvedBy, role: 'Refund Approver (Checker)', remarks: 'Verified against the employee closure confirmation — approved' }],
      downloads: [{ label: 'RFR File', fileName: r.rfrFileName }],
    }),
    system('rsu', 'RSU Received', '2026-09-24T11:15:02', 3, 'API', `${r.records} refund record(s) accepted by the agent bank`, undefined, 'Central Bank'),
    system('refund-credit', 'Refund Credit Posting', '2026-09-24T11:40:10', 3, 'System', 'Refund amount credited back to employer account', {
      title: 'Refund Credit Posting',
      subtitle: 'Refund credit to the employer account',
      remarks: [],
      downloads: [{ label: 'RSU File', fileName: r.rsuFileName }, ...logs('Refund Credit Posting')],
    }),
  ];
}

/** "Ali Hassan" → "A** H*****" — what a masked name shows. */
export function maskName(name: string): string {
  return name
    .split(' ')
    .map((w) => (w.length <= 1 ? w : `${w[0]}${'*'.repeat(w.length - 1)}`))
    .join(' ');
}

/** The Bank Maker and Checker who work refund requests in the seed. */
const RFR_MAKER = 'Omar Rashid';
const RFR_CHECKER = 'Sooraj K';

const CHANNEL_NAME: Record<RfrChannel, string> = {
  'Web Portal': 'Web Portal',
  IB: 'I-Business',
  CBX: 'CBX',
  MB: 'Mobile Banking',
};

/**
 * The audit trail of one RFR — created, validated, forwarded, verified, pushed to the CB, and the
 * CB's ACK/NAK and RSU — as far as the request has got. Every step carries the RFR's own time.
 */
export function rfrAuditActivities(e: RfrHistoryEntry): AuditActivity[] {
  const when = `${e.rfrInitiatedAt}:00`;
  const files = rfrCbFiles(e);
  const step = (
    id: string,
    activity: string,
    actionBy: string,
    actionByIsPerson: boolean,
    channel: AuditActivity['channel'],
    remarks: string,
    detail?: AuditActivityDetail,
    status: AuditActivity['status'] = 'Success',
  ): AuditActivity => ({ id, activity, actionBy, actionByIsPerson, startedAt: when, endedAt: when, channel, status, remarks, detail });
  const userDetail = (title: string, name: string, role: string, remarks: string): AuditActivityDetail => ({
    title,
    subtitle: role,
    remarks: [{ name, role, remarks }],
    downloads: [],
  });
  const fileDetail = (title: string, downloads: AuditDownload[]): AuditActivityDetail => ({ title, subtitle: 'System', remarks: [], downloads });

  const activities: AuditActivity[] = [
    step(
      'created',
      'Refund request created',
      e.initiatedBy,
      !e.initiatedBy.includes('('),
      'System',
      `Refund request created via ${CHANNEL_NAME[e.channel]} — ${e.records} records, AED ${e.totalRefund.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
    ),
    step('validated', 'File auto-validated by service', 'System', false, 'System', 'File auto-validated by service — accepted. Email sent to corporate.'),
    step('forwarded', 'Forwarded to Checker', RFR_MAKER, true, 'Web Portal', 'Forwarded to Checker', userDetail('Forwarded to Checker', RFR_MAKER, 'Bank Maker', 'Forwarded to Checker')),
  ];
  if (e.status === 'Pending') return activities;

  if (e.status === 'Rejected') {
    const why = 'Rejected — supporting documents missing';
    return [...activities, step('rejected', 'Rejected', RFR_CHECKER, true, 'Web Portal', why, userDetail('Rejected', RFR_CHECKER, 'Bank Checker', why))];
  }

  // Verified's More Details: the Checker's remarks and every CB file the RFR has produced so far.
  const verifiedDownloads: AuditDownload[] = [
    ...(files.rfr ? [{ label: 'RFR File', fileName: files.rfr }] : []),
    ...(files.ack ? [{ label: 'ACK / NAK File', fileName: files.ack }] : []),
    ...(files.rsu ? [{ label: 'RSU File', fileName: files.rsu }] : []),
  ];
  activities.push(
    step('verified', 'Verified', RFR_CHECKER, true, 'Web Portal', 'Verified — RFR generation queued', {
      title: 'Verified',
      subtitle: 'Files',
      remarks: [{ name: RFR_CHECKER, role: 'Bank Checker', remarks: 'Verified — RFR generation queued' }],
      downloads: verifiedDownloads,
    }),
  );
  if (files.rfr) {
    activities.push(
      step('pushed', `RFR ${files.rfr} pushed to CB-WPS SFTP`, 'System', false, 'System', `RFR ${files.rfr} pushed to CB-WPS SFTP`,
        fileDetail('RFR pushed to CB-WPS SFTP', [{ label: 'RFR File', fileName: files.rfr }])),
    );
  }
  if (files.ack) {
    const nak = e.status === 'NAK';
    activities.push(
      step(
        'ack',
        `RFR ${nak ? 'NAK' : 'ACK'} attached by service`,
        'System',
        false,
        'System',
        nak ? 'RFR NAK attached by service — file rejected by Central Bank' : `RFR ACK attached by service — ${e.pendingCount > 0 ? 'awaiting agent bank' : 'agent bank responded'}`,
        fileDetail(`RFR ${nak ? 'NAK' : 'ACK'} attached by service`, [
          { label: `${nak ? 'NAK' : 'ACK'} File`, fileName: files.ack },
          ...(files.ackDetail ? [{ label: 'Detailed Acknowledgement', fileName: files.ackDetail }] : []),
        ]),
        nak ? 'Failed' : 'Success',
      ),
    );
  }
  if (files.rsu) {
    activities.push(
      step('rsu', 'RSU received', 'Central Bank', false, 'API', `${e.acceptedCount} accepted · ${e.rejectedCount} rejected by the agent bank`,
        fileDetail('RSU received', [{ label: 'RSU File', fileName: files.rsu }])),
    );
  }
  if (e.acceptedCount > 0) {
    activities.push(step('credit', 'Refund credit posting', 'System', false, 'System', 'Refund amount credited back to employer account'));
  }
  return activities;
}