import type { ReactNode } from 'react';
import { cn } from '@paymenthub/ui';
import { BADGE, TD, TH, aed } from '../drawerParts';
import { EDR_EDGE, EDR_HEAD, EVP_EDGE, EVP_HEAD } from '../Sif360Drawer';
import type { RfrRecord } from '../wpsData';
import { sifRecordDetails } from './queueData';

interface Cell {
  label: string;
  value: ReactNode;
  mono?: boolean;
  amount?: boolean;
}

const AMOUNT = 'text-right font-mono font-bold text-[var(--text-primary)]';

/**
 * One employee's SIF lines — the EDR (Employee Detail Record) and EVP (Employee Variable Pay)
 * groups side by side, tinted as SIF Summary 360 tints them. `period` is the salary month, `YYYY-MM`.
 */
export function SifDetailsTable({ record, period }: { record: RfrRecord; period: string | null }) {
  const d = sifRecordDetails(record, period);
  const edr: Cell[] = [
    { label: 'Employee Unique ID', value: record.employeeId, mono: true },
    { label: 'Credit Account No.', value: d.creditAccount, mono: true },
    { label: 'Routing Code', value: d.routingCode, mono: true },
    { label: 'Pay Start Date', value: d.payStart, mono: true },
    { label: 'Pay End Date', value: d.payEnd, mono: true },
    { label: 'No of Days', value: d.days },
    { label: 'Fixed Amount', value: aed(d.fixed), amount: true },
    { label: 'Variable Amount', value: aed(d.variable), amount: true },
    { label: 'Leave Days', value: d.leaveDays },
    { label: 'MOHRE Update Status', value: <span className={cn(BADGE, d.mohreStatus === 'Updated' ? 'success' : 'warn')}>{d.mohreStatus}</span> },
  ];
  const evp: Cell[] = [
    { label: 'Account Type', value: <span className={cn(BADGE, 'blue')}>{d.accountType}</span> },
    { label: 'Housing Allow.', value: aed(d.housing), amount: true },
    { label: 'Conveyance Allow.', value: aed(d.conveyance), amount: true },
    { label: 'Medical Allow.', value: aed(d.medical), amount: true },
    { label: 'Annual Passage', value: aed(d.annualPassage), amount: true },
    { label: 'Overtime Allow.', value: aed(d.overtime), amount: true },
    { label: 'Other Allow.', value: aed(d.other), amount: true },
    { label: 'Leave Encashment', value: aed(d.leaveEncashment), amount: true },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-max text-xs">
        <thead>
          <tr>
            <th colSpan={edr.length} className={cn(TH, EDR_HEAD, EDR_EDGE, '!text-[11px] !font-bold')}>
              EDR — Employee Detail Record
            </th>
            <th colSpan={evp.length} className={cn(TH, EVP_HEAD, EVP_EDGE, '!text-[11px] !font-bold')}>
              EVP — Employee Variable Pay
            </th>
          </tr>
          <tr className="border-b border-[var(--border)]">
            {edr.map((c, i) => (
              <th key={c.label} className={cn(TH, EDR_HEAD, i === 0 && EDR_EDGE)}>
                {c.label}
              </th>
            ))}
            {evp.map((c, i) => (
              <th key={c.label} className={cn(TH, EVP_HEAD, i === 0 && EVP_EDGE)}>
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            {edr.map((c, i) => (
              <td key={c.label} className={cn(TD, i === 0 && EDR_EDGE, c.mono && 'font-mono text-[11px]', c.amount && AMOUNT)}>
                {c.value}
              </td>
            ))}
            {evp.map((c, i) => (
              <td key={c.label} className={cn(TD, i === 0 && EVP_EDGE, c.amount && AMOUNT)}>
                {c.value}
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
