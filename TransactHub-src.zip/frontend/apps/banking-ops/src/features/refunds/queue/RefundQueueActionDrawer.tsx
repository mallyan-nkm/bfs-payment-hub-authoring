import { useEffect, useRef, useState } from 'react';
import { Check, Clock, X } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { formatAmount } from '../data';
import { BADGE, CARD, CARD_HEAD, DrawerTabs, TD, TH, aed } from '../drawerParts';
import { RefundDrawer } from '../RefundDrawer';
import type { RfrRecord } from '../wpsData';
import { CHIP, PILL, dateTime } from '../wpsStyles';
import { MakerMeta, MakerRecordList, MakerTransactionDetails } from './MakerQueueSections';
import {
  actionHistory,
  debitAccountOf,
  queueCharges,
  queueRecords,
  queueSteps,
  salaryMonth,
  salaryPeriodOf,
} from './queueData';
import type { QueueItem, QueueOwner } from './queueData';
import { QUEUE_CHANNEL_TONE, RAIL_PILL, when } from './queueStyles';
import { SifDetailsTable } from './SifDetailsTable';

type Tab = 'details' | 'records';

const TABS: readonly { key: Tab; label: string }[] = [
  { key: 'details', label: 'Transaction Details' },
  { key: 'records', label: 'Record List' },
];

const CARD_TITLE = 'text-[13px] font-bold uppercase tracking-wider text-[var(--text-primary)]';

/** A label / value cell of the Request Summary grid. */
function Field({ label, value, mono, strong }: { label: string; value: string; mono?: boolean; strong?: boolean }) {
  return (
    <div className="flex flex-col gap-1">
      <dt className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{label}</dt>
      <dd
        className={cn(
          'break-all text-sm text-[var(--text-primary)]',
          mono && 'font-mono text-xs',
          strong ? 'font-bold' : 'font-medium',
        )}
      >
        {value}
      </dd>
    </div>
  );
}

/** Progress of the request — the SIF Upload stepper's shared `stepper-*` classes, with the Checker's task under the current step. */
function Stepper({ item }: { item: QueueItem }) {
  const steps = queueSteps(item);
  return (
    <div className="flex flex-wrap items-start justify-center gap-y-3 py-2" aria-label="Refund progress">
      {steps.map((s, i) => (
        <div key={s.label} className="stepper-repeat relative flex items-start gap-3" aria-current={s.state === 'current' ? 'step' : undefined}>
          <span
            className={cn(
              'stepper-count',
              s.state === 'done' && 'stepper-count-completed',
              s.state === 'current' && 'stepper-count-active',
              s.state === 'failed' && '!border-[var(--accent-red)] !bg-[var(--accent-red)] !text-white',
            )}
          >
            {s.state === 'done' ? <Check size={14} /> : s.state === 'failed' ? <X size={14} /> : i + 1}
          </span>
          <span className="flex flex-col">
            <span
              className={cn(
                'stepper-text',
                s.state !== 'todo' && 'stepper-text-completed',
                s.state === 'failed' && '!text-[var(--accent-red)]',
              )}
            >
              {s.label}
            </span>
            {s.hint && <span className="max-w-[14rem] text-[11px] text-[var(--text-muted)]">{s.hint}</span>}
          </span>
        </div>
      ))}
    </div>
  );
}

function TransactionDetails({ item }: { item: QueueItem }) {
  const wps = item.rail === 'WPS';
  const charges = queueCharges(item);
  const debit = debitAccountOf(item);
  const history = actionHistory(item);

  const summary: { label: string; value: string; mono?: boolean; strong?: boolean }[] = wps
    ? [
        { label: 'Refund Reference', value: item.refundRef, mono: true, strong: true },
        { label: 'Channel', value: item.channel },
        { label: 'Corporate Name', value: item.debtorName },
        { label: 'MOL ID (Employer)', value: item.rfr?.employerId ?? '—', mono: true },
        { label: 'SIF File Name (sent to CB)', value: item.originalRef, mono: true },
        { label: 'Original File Name (received from bank)', value: item.rfr?.originalFileName ?? '—', mono: true },
        { label: 'Refund Request File', value: '— (SIF selection)' },
        { label: 'Initiated By', value: item.initiatedBy },
        { label: 'Initiated Date', value: dateTime(item.refundInitiatedAt) },
        { label: 'Total Records', value: String(item.records) },
        { label: 'Total Refund Amount', value: aed(item.refundAmount), strong: true },
      ]
    : [
        { label: 'Refund Reference', value: item.refundRef, mono: true, strong: true },
        { label: 'Channel', value: item.channel },
        { label: 'Debtor Name', value: item.debtorName },
        { label: 'Debtor Account', value: debit, mono: true },
        { label: 'Original Txn Ref.', value: item.originalRef, mono: true },
        { label: 'End-to-End ID', value: item.txn?.e2eId ?? '—', mono: true },
        { label: 'Message Type', value: item.messageType },
        { label: 'Refund Reason', value: item.reason },
        { label: 'Initiated By', value: item.initiatedBy },
        { label: 'Initiated Date', value: dateTime(item.refundInitiatedAt) },
        { label: 'Total Records', value: String(item.records) },
        { label: 'Total Refund Amount', value: aed(item.refundAmount), strong: true },
      ];

  return (
    <div className="flex flex-col gap-5">
      <section className={cn(CARD, 'px-5 py-3')}>
        <Stepper item={item} />
      </section>

      {/* Request Summary */}
      <section className={CARD}>
        <div className={CARD_HEAD}>
          <h3 className={CARD_TITLE}>Request Summary</h3>
        </div>
        <div className="flex flex-col gap-4 p-5">
          <dl className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2 lg:grid-cols-4">
            {summary.map((f) => (
              <Field key={f.label} {...f} />
            ))}
          </dl>
          <p className="rounded-lg border border-[color-mix(in_srgb,var(--accent-amber)_35%,transparent)] bg-[color-mix(in_srgb,var(--accent-amber)_10%,transparent)] px-4 py-3 text-sm text-[var(--text-primary)]">
            <span className="font-bold text-[var(--accent-amber)]">Maker remarks: </span>
            {item.makerRemarks}
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        {/* Charge Details */}
        <section className={cn(CARD, 'self-start')}>
          <div className={cn(CARD_HEAD, 'flex flex-wrap items-center justify-between gap-2')}>
            <h3 className={CARD_TITLE}>Charge Details</h3>
            <span className="inline-flex items-center gap-2 text-xs text-[var(--text-muted)]">
              Charge Source
              <span className={cn(PILL, 'bg-[color-mix(in_srgb,var(--accent-amber)_15%,transparent)] text-[var(--accent-amber)]')}>Charge Configuration</span>
            </span>
          </div>
          <div className="p-5">
            {charges.lines.map((l) => (
              <div key={l.label} className="flex items-baseline justify-between gap-4 border-b border-[var(--border)] py-2 last:border-b-0">
                <span className="text-sm text-[var(--text-muted)]">{l.label}</span>
                <span className="text-right text-sm font-semibold tabular-nums text-[var(--text-primary)]">{aed(l.amount)}</span>
              </div>
            ))}
            <div className="mt-3 flex items-center justify-between gap-3 rounded-lg border border-[color-mix(in_srgb,var(--accent-blue)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] px-4 py-3 font-bold text-[var(--accent-blue)]">
              <span>Total Refund Charges</span>
              <span className="tabular-nums">{aed(charges.total)}</span>
            </div>
          </div>
        </section>

        {/* Posting Details */}
        <section className={cn(CARD, 'self-start')}>
          <div className={CARD_HEAD}>
            <h3 className={CARD_TITLE}>Posting Details</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]">
                <tr>
                  <th className={TH}>Posting Type</th>
                  <th className={TH}>Debit Account</th>
                  <th className={TH}>Credit Account</th>
                  <th className={TH}>Status</th>
                </tr>
              </thead>
              <tbody>
                {charges.lines.map((l) => (
                  <tr key={l.label} className="border-t border-[var(--border)]">
                    <td className={TD}>
                      <span className={cn(PILL, 'bg-[color-mix(in_srgb,var(--accent-blue)_12%,transparent)] text-[var(--accent-blue)]')}>{l.posting.type}</span>
                    </td>
                    <td className={TD}>
                      <span className="block font-mono text-[11px] font-semibold text-[var(--text-primary)]">{debit}</span>
                      <span className="text-[11px] text-[var(--text-muted)]">{item.rail === 'WPS' ? 'Employer A/c' : 'Debtor A/c'}</span>
                    </td>
                    <td className={TD}>
                      <span className={cn(CHIP, 'font-mono')}>{l.posting.account}</span>
                      <span className="ml-2 text-[11px] text-[var(--text-muted)]">{l.posting.accountLabel}</span>
                    </td>
                    <td className={TD}>
                      <span className={cn(BADGE, 'warn')}>Pending</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>

      {/* Action History */}
      <section className={CARD}>
        <div className={CARD_HEAD}>
          <h3 className={CARD_TITLE}>Action History</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]">
              <tr>
                <th className={TH}>Name (Role)</th>
                <th className={TH}>Date &amp; Time</th>
                <th className={TH}>Action</th>
                <th className={TH}>Comments</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={`${h.action}-${h.name}`} className="border-t border-[var(--border)]">
                  <td className={TD}>
                    <span className="font-semibold text-[var(--text-primary)]">{h.name}</span> ({h.role})
                  </td>
                  <td className={cn(TD, 'font-mono text-[11px]')}>{dateTime(h.at)}</td>
                  <td className={TD}>
                    <span className={cn(BADGE, h.modifier)}>{h.action}</span>
                  </td>
                  <td className={cn(TD, 'whitespace-normal')}>{h.comments}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

/** The selected employee's EDR and EVP lines, under the Record List. */
function SifDetails({ record, item, onClose }: { record: RfrRecord; item: QueueItem; onClose: () => void }) {
  return (
    <section className={CARD} aria-label={`SIF details — ${record.employeeName}`}>
      <div className={cn(CARD_HEAD, 'flex flex-wrap items-center justify-between gap-2')}>
        <h3 className="text-[15px] font-bold text-[var(--text-primary)]">
          SIF Details — {record.employeeName} <span className="font-mono text-sm">({record.employeeId})</span>
        </h3>
        <button type="button" onClick={onClose} className="inline-flex items-center gap-1 text-sm font-semibold text-[var(--primary-blue)] hover:underline">
          <X size={15} aria-hidden="true" />
          Close
        </button>
      </div>
      <SifDetailsTable record={record} period={salaryPeriodOf(item)} />
    </section>
  );
}

function RecordList({ item }: { item: QueueItem }) {
  const [sifRecord, setSifRecord] = useState<RfrRecord | null>(null);
  const sifRef = useRef<HTMLDivElement | null>(null);

  // Bring the SIF Details section into view when it opens or changes employee.
  useEffect(() => {
    if (sifRecord) sifRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [sifRecord]);

  if (item.rail !== 'WPS') {
    const t = item.txn;
    return (
      <section className={CARD}>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]">
              <tr>
                {['#', 'Original Txn Ref.', 'Creditor Name', 'Creditor Account', 'Bank Name', 'Original Amount (AED)', 'Refund Amount (AED)', 'Refund Type', 'Refund Reason', 'Refund Status'].map((h) => (
                  <th key={h} className={cn(TH, h.includes('(AED)') && '!text-right')}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-[var(--border)]">
                <td className={cn(TD, 'text-[var(--text-muted)]')}>1</td>
                <td className={cn(TD, 'font-mono text-[11px] text-[var(--text-primary)]')}>{item.originalRef}</td>
                <td className={cn(TD, 'text-[var(--text-primary)]')}>{t?.creditorName ?? '—'}</td>
                <td className={cn(TD, 'font-mono text-[11px]')}>{t?.creditorAccount ?? '—'}</td>
                <td className={TD}>{t?.creditorBank ?? '—'}</td>
                <td className={cn(TD, 'text-right tabular-nums')}>{formatAmount(item.originalAmount)}</td>
                <td className={cn(TD, 'text-right font-bold tabular-nums text-[var(--text-primary)]')}>{formatAmount(item.refundAmount)}</td>
                <td className={TD}>
                  <span className={cn(BADGE, 'blue')}>{item.refundAmount === item.originalAmount ? 'Full Refund' : 'Partial Refund'}</span>
                </td>
                <td className={TD}>{item.reason}</td>
                <td className={TD}>
                  <span className={cn(BADGE, 'warn')}>Pending</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    );
  }

  const records = queueRecords(item);
  const header: { label: string; value: string; mono?: boolean }[] = [
    { label: 'Employer Unique ID', value: item.rfr?.employerId ?? '—', mono: true },
    { label: 'Employer Name', value: item.debtorName },
    { label: 'Debit Account Number', value: debitAccountOf(item), mono: true },
    { label: 'Salary Month-Year', value: salaryMonth(salaryPeriodOf(item)) },
  ];

  return (
    <div className="flex flex-col gap-5">
      <section className={cn(CARD, 'p-5')}>
        <dl className="grid grid-cols-1 gap-x-6 gap-y-4 sm:grid-cols-2 lg:grid-cols-4">
          {header.map((h) => (
            <Field key={h.label} label={h.label} value={h.value} mono={h.mono} />
          ))}
        </dl>
      </section>

      <section className={CARD}>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]">
              <tr>
                {['#', 'Employee ID (MOL ID)', 'Creditor Name', 'Total Salary (AED)', 'Refund Amount (AED)', 'Accepted Amount (AED)', 'Refund Type', 'Refund Reason', 'Refund Status', 'Action'].map((h) => (
                  <th key={h} className={cn(TH, h.includes('(AED)') && '!text-right')}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr
                  key={r.sl}
                  className={cn(
                    'border-t border-[var(--border)]',
                    sifRecord?.sl === r.sl && 'bg-[color-mix(in_srgb,var(--accent-blue)_8%,transparent)]',
                  )}
                >
                  <td className={cn(TD, 'text-[var(--text-muted)]')}>{r.sl}</td>
                  <td className={cn(TD, 'font-mono text-[11px] text-[var(--text-primary)]')}>{r.employeeId}</td>
                  <td className={cn(TD, 'text-[var(--text-primary)]')}>{r.employeeName}</td>
                  <td className={cn(TD, 'text-right tabular-nums')}>{formatAmount(r.totalSalary)}</td>
                  <td className={cn(TD, 'text-right font-bold tabular-nums text-[var(--text-primary)]')}>{formatAmount(r.amount)}</td>
                  <td className={cn(TD, 'text-right text-[var(--text-muted)]')}>—</td>
                  <td className={TD}>
                    <span className={cn(BADGE, 'blue')}>{r.refundType === 'Full' ? 'Full Refund' : 'Partial Refund'}</span>
                  </td>
                  <td className={TD}>{r.reason}</td>
                  <td className={TD}>
                    <span className={cn(BADGE, 'warn')}>Pending</span>
                  </td>
                  <td className={TD}>
                    <button type="button" onClick={() => setSifRecord(r)} className="btn-secondary pq-view-action-btn">
                      View SIF Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {sifRecord && (
        <div ref={sifRef} className="scroll-mt-4">
          <SifDetails record={sifRecord} item={item} onClose={() => setSifRecord(null)} />
        </div>
      )}
    </div>
  );
}

export type QueueDecision = 'approve' | 'reject';

/**
 * Refund Queue's View & Action — the Checker or Maker reviews a refund request (its progress,
 * summary, charges, postings, history and records) and actions it with mandatory notes. The
 * Maker's view lays the same content out as headed sections (`MakerQueueSections`), and shows
 * Record List only for a WPS file. Static: everything comes from `queueData.ts`.
 */
export function RefundQueueActionDrawer({
  item,
  owner,
  onDecide,
  onClose,
}: {
  item: QueueItem;
  /** Whose queue the request is in — picks the layout. */
  owner: QueueOwner;
  onDecide: (item: QueueItem, decision: QueueDecision, remarks: string) => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<Tab>('details');
  const [remarks, setRemarks] = useState('');
  const [tried, setTried] = useState(false);
  const missing = remarks.trim() === '';
  const nak = item.stage === 'nak';
  // Declined by the beneficiary bank: nothing to reject, the Maker only acknowledges and closes.
  const declined = item.stage === 'declined';
  const maker = owner === 'maker';
  const tabs = maker && item.rail !== 'WPS' ? TABS.slice(0, 1) : TABS;

  function decide(decision: QueueDecision) {
    setTried(true);
    if (missing) return;
    onDecide(item, decision, remarks.trim());
  }

  const footer = (
    <div className="flex flex-col gap-3 border-t border-[var(--border)] bg-[var(--bg-card)] p-6">
      <label htmlFor="rq-remarks" className="input-label text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
        Add Comment / Notes (Mandatory)
      </label>
      <textarea
        id="rq-remarks"
        value={remarks}
        onChange={(e) => setRemarks(e.target.value)}
        rows={2}
        maxLength={500}
        placeholder={maker ? 'Enter remarks...' : 'Enter your comments before approving or rejecting...'}
        aria-invalid={missing}
        className={cn('input-cls w-full resize-y text-sm')}
      />
      {tried && missing && (
        <p role="alert" className="text-xs text-[var(--accent-red)]">
          Comments are mandatory to {nak ? 'acknowledge or resubmit' : declined ? 'approve' : 'approve or reject'}.
        </p>
      )}
      <div className="flex flex-wrap items-center justify-end gap-3">
       <button type="button" onClick={onClose} className="large-btn btn-tertiary justify-center">
          Cancel
        </button>
        {!declined && (
          <button type="button" onClick={() => decide('reject')} className="large-btn btn-secondary danger justify-center">
            {nak ? 'Acknowledge NAK' : 'Reject'}
          </button>
        )}
        <button type="button" onClick={() => decide('approve')} className="large-btn btn-primary success justify-center">
          {nak ? 'Repair & Resubmit' : 'Approve'}
        </button>
       
      </div>
    </div>
  );

  return (
    <RefundDrawer
      eyebrow={`${item.refundRef} · ${item.rail} · ${item.bankLabel ?? (item.rail === 'WPS' ? 'Employer Bank' : 'Debtor Bank')}`}
      // The Maker's non-WPS view names both parties: "Debtor → Creditor".
      title={maker && item.txn ? `${item.debtorName} → ${item.txn.creditorName}` : item.debtorName}
      ariaLabel={`View and action — ${item.refundRef}`}
      meta={
        maker ? (
          <MakerMeta item={item} />
        ) : (
        <>
          <span className={cn(PILL, RAIL_PILL[item.rail])}>{item.rail}</span>
          {item.rfr ? (
            <span className={cn(CHIP, 'font-mono')}>MOL ID {item.rfr.employerId}</span>
          ) : (
            <span className={cn(CHIP, 'font-mono')}>{item.originalRef}</span>
          )}
          <span className={cn(PILL, QUEUE_CHANNEL_TONE[item.channel])}>{item.channel}</span>
          <span className={CHIP}>{when(item.refundInitiatedAt)}</span>
          <span className={cn(BADGE, item.statusModifier)}>{item.status}</span>
          <span
            className={cn(
              'inline-flex items-center gap-1 text-xs font-semibold',
              item.slaBreached ? 'text-[var(--accent-red)]' : 'text-[var(--text-muted)]',
            )}
          >
            <Clock size={13} aria-hidden="true" />
            {item.age}
            {item.slaBreached ? ' — SLA breached' : ' in queue'}
          </span>
        </>
        )
      }
      tabs={<DrawerTabs tabs={tabs} value={tab} onChange={setTab} />}
      footer={footer}
      onClose={onClose}
    >
      {maker ? (
        tab === 'details' ? <MakerTransactionDetails item={item} /> : <MakerRecordList item={item} />
      ) : tab === 'details' ? (
        <TransactionDetails item={item} />
      ) : (
        <RecordList item={item} />
      )}
    </RefundDrawer>
  );
}
