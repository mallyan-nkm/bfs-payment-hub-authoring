import { RFR_HISTORY, rfrRecords } from '../wpsData';
import type { RfrHistoryEntry, RfrRecord, SifPriority } from '../wpsData';
import type { AuditActivity, AuditActivityDetail, AuditDownload, AuditUserRemark } from '../wpsAudit';

/**
 * Static seed data for the Refund Queue — the Checker's worklist of refund requests raised by
 * Makers in Refund Initiation. This screen has no backend yet.
 *
 * WPS requests are the same RFRs the Refund Initiation History tab lists (`RFR_HISTORY`), so the
 * two screens agree on references, records and amounts.
 */

export type QueueRail = 'IPI' | 'UAEFTS' | 'WPS' | 'IPP';
export type QueueChannel = 'Web Portal' | 'IB' | 'CBX' | 'Direct Entry';
export type QueueSubType = 'Batch' | 'Single';
export type QueueMessageType = 'SIF' | 'pacs.008' | 'ISO8583' | 'MT103';

/**
 * Where a request stands in its cycle, and so which stepper step is current. `maker`: back with
 * the Maker to review and forward; `declined`: the beneficiary bank declined the recall.
 */
export type QueueStage = 'checker' | 'maker' | 'nak' | 'post' | 'declined' | 'done' | 'rejected';

/** The single transaction behind an IPI / UAEFTS / IPP request. */
export interface QueueTransaction {
  debtorAccount: string;
  creditorName: string;
  creditorAccount: string;
  creditorBank: string;
  e2eId: string;
  /** The rail's own name for `e2eId`, e.g. "UETR / MT103 Ref". */
  e2eLabel?: string;
}

/** A box at the top of the Maker's Transaction Details; `strong` is a part of `text` shown bold. */
export interface QueueNotice {
  tone: 'blue' | 'red';
  title?: string;
  text: string;
  strong?: string;
}

export interface QueueItem {
  id: string;
  rail: QueueRail;
  refundRef: string;
  /** Original transaction reference, or the SIF file name for WPS. */
  originalRef: string;
  systemRef: string;
  /** Debtor, or the employer for WPS. */
  debtorName: string;
  /** `YYYY-MM-DDTHH:mm`, or `YYYY-MM-DD` when the rail records a date only. */
  txnInitiatedAt: string;
  valueDate: string | null;
  records: number;
  originalAmount: number;
  currency: string;
  messageType: QueueMessageType;
  subType: QueueSubType;
  /** `YYYY-MM-DDTHH:mm` */
  refundInitiatedAt: string;
  initiatedBy: string;
  refundAmount: number;
  /** A single reason, or "Multiple (see Record List)" when each record has its own. */
  reason: string;
  priority: SifPriority;
  channel: QueueChannel;
  assignedTo: string;
  status: string;
  /** `.status-badge` modifier of `status`. */
  statusModifier: string;
  /** What the Checker is asked to do — the line under the status. */
  yourAction: string;
  stage: QueueStage;
  /** Time in the queue, e.g. "1d 1h". */
  age: string;
  slaBreached: boolean;
  makerRemarks: string;
  /** The RFR behind a WPS request. */
  rfr?: RfrHistoryEntry;
  /** The transaction behind any other rail's request. */
  txn?: QueueTransaction;
  /** The last part of the popup's eyebrow, e.g. "Employer Bank"; defaults by rail. */
  bankLabel?: string;
  /** The employer or debtor account, where it differs from the RFR's. */
  debitAccount?: string;
  /** `YYYY-MM` of the salaries a WPS request refunds, where it differs from the value date's month. */
  salaryPeriod?: string;
  /** The employee records, where they differ from the RFR's derived ones. */
  recordList?: RfrRecord[];
  /** The refund request file the corporate uploaded, if it came as a file. */
  refundRequestFile?: string;
  /** Recall message pair, e.g. "MT192 / MT196". */
  recallMessage?: string;
  notice?: QueueNotice;
  /** Who has acted so far, newest first, where it differs from the derived history. */
  history?: ActionHistoryEntry[];
}

/** Which user type's queue a request sits in. */
export type QueueOwner = 'checker' | 'maker';

export const MULTIPLE_REASONS = 'Multiple (see Record List)';

export const QUEUE_RAILS: { code: QueueRail | 'ALL'; label: string; description: string }[] = [
  { code: 'ALL', label: 'All Rails', description: 'Every rail' },
  { code: 'IPI', label: 'IPI', description: 'Real-time AED' },
  { code: 'UAEFTS', label: 'UAEFTS', description: 'AED interbank' },
  { code: 'WPS', label: 'WPS', description: 'MOL salary' },
  { code: 'IPP', label: 'IPP', description: 'Card & merchant' },
];

export const SUB_TYPES: QueueSubType[] = ['Batch', 'Single'];
export const QUEUE_CHANNELS: QueueChannel[] = ['CBX', 'IB', 'Direct Entry'];
export const PRIORITIES: SifPriority[] = ['Urgent', 'High', 'Normal'];
export const ASSIGNEES = ['Sooraj K', 'Checker Pool'];

/** The Checker this static screen acts as. */
export const CURRENT_CHECKER = 'Sooraj K';

const rfr = (requestRef: string): RfrHistoryEntry => {
  const e = RFR_HISTORY.find((x) => x.requestRef === requestRef);
  if (!e) throw new Error(`Unknown RFR ${requestRef}`);
  return e;
};

const PENDING = 'Pending with Checker';
const VERIFY_WPS = 'Verify, generate RFR & push to CB';
const RECALL = 'Approve & send recall to network';

/** A WPS request, from its RFR. */
function wps(
  id: string,
  e: RfrHistoryEntry,
  over: Partial<QueueItem> & Pick<QueueItem, 'reason' | 'channel' | 'age' | 'makerRemarks'>,
): QueueItem {
  return {
    id,
    rail: 'WPS',
    refundRef: e.requestRef,
    originalRef: e.sifFileName,
    systemRef: e.systemRef,
    debtorName: e.employerName,
    txnInitiatedAt: e.txnInitiatedAt,
    valueDate: e.valueDate,
    records: e.records,
    originalAmount: e.sifFileName === 'WPS109928838.SIF' ? 612450 : e.sifFileName === 'WPS109928601.SIF' ? 2845300 : 134900,
    currency: 'AED',
    messageType: 'SIF',
    subType: 'Batch',
    refundInitiatedAt: e.rfrInitiatedAt,
    initiatedBy: e.initiatedBy,
    refundAmount: e.totalRefund,
    priority: e.priority,
    assignedTo: CURRENT_CHECKER,
    status: PENDING,
    statusModifier: 'warn',
    yourAction: VERIFY_WPS,
    stage: 'checker',
    slaBreached: true,
    rfr: e,
    ...over,
  };
}

/** The Outward — Request Initiation Cycle tab: requests waiting on the Checker, as the design lists them. */
export const QUEUE_ITEMS: readonly QueueItem[] = [
  wps('q-1', rfr('RFR-2026-00131'), {
    reason: MULTIPLE_REASONS,
    channel: 'Web Portal',
    priority: 'Urgent',
    age: '1d 1h',
    makerRemarks: 'Employees resigned before salary credit — refund requested urgently per employer letter dated 28-Sep-2026.',
  }),
  wps('q-2', rfr('RFR-2026-00130'), {
    reason: MULTIPLE_REASONS,
    channel: 'IB',
    priority: 'Normal',
    age: '1d 1h',
    makerRemarks: 'Duplicate salary lines found for August payroll — employer requested refund of the extra credits.',
  }),
  wps('q-3', rfr('RFR-2026-00126'), {
    reason: MULTIPLE_REASONS,
    channel: 'CBX',
    age: '1d 10h',
    status: 'CB NAK — Pending with Checker',
    statusModifier: 'error',
    yourAction: 'Repair & resubmit, or Acknowledge NAK',
    stage: 'nak',
    assignedTo: 'Checker Pool',
    makerRemarks: 'Refund for two employees whose accounts were closed before credit.',
  }),
  wps('q-4', rfr('RFR-2026-00127'), {
    reason: 'Incorrect salary amount',
    channel: 'Web Portal',
    priority: 'Normal',
    age: '1d 9h',
    makerRemarks: 'Salary credited with the wrong amount — employer asked for the full line to be refunded and re-paid.',
  }),
  {
    id: 'q-5',
    rail: 'IPI',
    refundRef: 'RFD-2026-00241',
    originalRef: 'IPI-2026-00401',
    systemRef: 'IPI-2026-00401',
    debtorName: 'Blue Ocean FZE',
    txnInitiatedAt: '2026-09-22',
    valueDate: '2026-09-22',
    records: 1,
    originalAmount: 4750,
    currency: 'AED',
    messageType: 'pacs.008',
    subType: 'Single',
    refundInitiatedAt: '2026-09-30T09:05',
    initiatedBy: 'Omar Rashid',
    refundAmount: 4750,
    reason: 'DUPL — Duplicate payment',
    priority: 'Normal',
    channel: 'Direct Entry',
    assignedTo: CURRENT_CHECKER,
    status: PENDING,
    statusModifier: 'warn',
    yourAction: RECALL,
    stage: 'checker',
    age: '0d 4h',
    slaBreached: false,
    makerRemarks: 'Customer paid the same invoice twice — recall of the second payment requested.',
    txn: {
      debtorAccount: 'AE330330000055667',
      creditorName: 'Maria Santos',
      creditorAccount: 'AE670350000112233',
      creditorBank: 'Mashreq Bank',
      e2eId: 'E2E20260922000401',
    },
  },
  {
    id: 'q-6',
    rail: 'IPI',
    refundRef: 'RFD-2026-00233',
    originalRef: 'IPI-2026-00352',
    systemRef: 'IPI-2026-00352',
    debtorName: 'Blue Ocean FZE',
    txnInitiatedAt: '2026-09-28',
    valueDate: null,
    records: 1,
    originalAmount: 9300,
    currency: 'AED',
    messageType: 'pacs.008',
    subType: 'Single',
    refundInitiatedAt: '2026-09-28T11:40',
    initiatedBy: 'Omar Rashid',
    refundAmount: 9300,
    reason: 'AM09 — Wrong amount',
    priority: 'Normal',
    channel: 'IB',
    assignedTo: CURRENT_CHECKER,
    status: PENDING,
    statusModifier: 'warn',
    yourAction: 'Verify & post refund to debtor',
    stage: 'post',
    age: '2d 1h',
    slaBreached: true,
    makerRemarks: 'Beneficiary bank returned the funds (pacs.004) — post the refund back to the debtor.',
    txn: {
      debtorAccount: 'AE330330000055667',
      creditorName: 'Gulf Line Logistics',
      creditorAccount: 'AE140260000556677',
      creditorBank: 'Emirates NBD',
      e2eId: 'E2E20260928000352',
    },
  },
  {
    id: 'q-7',
    rail: 'IPP',
    refundRef: 'RFD-2026-00231',
    originalRef: 'IPP-2026-00380',
    systemRef: 'IPP-2026-00380',
    debtorName: 'Carrefour UAE',
    txnInitiatedAt: '2026-09-27',
    valueDate: null,
    records: 1,
    originalAmount: 1850,
    currency: 'AED',
    messageType: 'ISO8583',
    subType: 'Single',
    refundInitiatedAt: '2026-09-27T09:15',
    initiatedBy: 'Omar Rashid',
    refundAmount: 1850,
    reason: 'TECH — Technical problem',
    priority: 'Normal',
    channel: 'CBX',
    assignedTo: 'Checker Pool',
    status: PENDING,
    statusModifier: 'warn',
    yourAction: RECALL,
    stage: 'checker',
    age: '3d 0h',
    slaBreached: true,
    makerRemarks: 'Terminal timed out but the card was debited — recall requested.',
    txn: {
      debtorAccount: 'AE660330000044321',
      creditorName: 'Omar Farouk',
      creditorAccount: 'AE770260000334455',
      creditorBank: 'Emirates NBD',
      e2eId: 'IPP-TXN-88230380',
    },
  },
];

/** The Maker's Outward — Request Initiation Cycle tab: requests back with the Maker, as the design lists them. */
const MAF = rfr('RFR-2026-00129');
const MAF_RECORDS: RfrRecord[] = rfrRecords(MAF).map((r, i) => ({
  ...r,
  employeeId: `110000000${5003 + i}`,
  employeeName: ['Priya Menon', 'Mohammed Rafi'][i] ?? r.employeeName,
}));

export const MAKER_QUEUE_ITEMS: readonly QueueItem[] = [
  wps('m-1', MAF, {
    systemRef: 'WPS-2026-00826',
    originalAmount: 174800,
    reason: MULTIPLE_REASONS,
    channel: 'IB',
    status: 'Pending with Maker',
    yourAction: 'Review & forward to Checker',
    stage: 'maker',
    age: '1d 2h',
    makerRemarks: '',
    debitAccount: 'AE070331452100129',
    salaryPeriod: '2026-06',
    recordList: MAF_RECORDS,
    refundRequestFile: 'maf_rfr_sep26.xls',
    notice: {
      tone: 'blue',
      text: 'Uploaded by the corporate through I-Business and auto-validated by the service. Review the records and forward to the Checker.',
      strong: 'I-Business',
    },
    history: [{ name: 'I-Business', role: 'corp.user01', at: '2026-09-29T08:15', action: 'Initiated', modifier: 'blue', comments: '—' }],
  }),
  {
    id: 'm-2',
    rail: 'UAEFTS',
    refundRef: 'RFD-2026-00235',
    originalRef: 'FTS-2026-00381',
    systemRef: 'FTS-2026-00381',
    debtorName: 'Al Ghurair Foods',
    txnInitiatedAt: '2026-09-27',
    valueDate: null,
    records: 1,
    originalAmount: 38900,
    currency: 'AED',
    messageType: 'MT103',
    subType: 'Single',
    refundInitiatedAt: '2026-09-27T16:30',
    initiatedBy: 'Priya Nair',
    refundAmount: 38900,
    reason: 'CUST — Requested by customer',
    priority: 'Normal',
    channel: 'IB',
    assignedTo: 'Priya Nair',
    status: 'Pending with Maker',
    statusModifier: 'error',
    yourAction: 'Acknowledge & close',
    stage: 'declined',
    age: '2d 18h',
    slaBreached: true,
    makerRemarks: '',
    bankLabel: 'Outward Refund',
    recallMessage: 'MT192 / MT196',
    txn: {
      debtorAccount: 'AE03300000023512',
      creditorName: 'Metro Logistics',
      creditorAccount: 'AE450260000778899',
      creditorBank: 'ADCB',
      e2eId: 'MT103-DIBUAEAD-00381',
      e2eLabel: 'UETR / MT103 Ref',
    },
    notice: {
      tone: 'red',
      title: 'Refund declined by beneficiary bank',
      text: 'MT196: Funds already credited and withdrawn by beneficiary (NOAS).',
    },
    history: [
      { name: CURRENT_CHECKER, role: 'Checker', at: '2026-09-27T16:30', action: 'Approved', modifier: 'success', comments: 'Request verified. Details match the supporting documents.' },
      { name: 'Priya Nair', role: 'Maker', at: '2026-09-27T16:30', action: 'Initiated', modifier: 'blue', comments: '—' },
    ],
  },
];

/** A request the Checker has already actioned. */
function actioned(
  id: string,
  e: RfrHistoryEntry,
  status: string,
  statusModifier: string,
  stage: QueueStage,
): QueueItem {
  return wps(id, e, {
    reason: MULTIPLE_REASONS,
    channel: e.channel === 'MB' ? 'Direct Entry' : e.channel,
    age: '—',
    slaBreached: false,
    status,
    statusModifier,
    yourAction: '',
    stage,
    originalAmount: Math.round(e.totalRefund * 4.2),
    makerRemarks: 'Refund requested per employer letter.',
  });
}

/** The History tab: requests the Checker has approved or rejected. */
export const HISTORY_ITEMS: readonly QueueItem[] = [
  actioned('h-1', rfr('RFR-2026-00128'), 'Approved — RFR sent to CB', 'blue', 'done'),
  actioned('h-2', rfr('RFR-2026-00124'), 'Completed — CB ACK', 'success', 'done'),
  actioned('h-3', rfr('RFR-2026-00121'), 'Completed — CB ACK', 'success', 'done'),
  actioned('h-4', rfr('RFR-2026-00119'), 'Completed — CB ACK', 'success', 'done'),
  actioned('h-5', rfr('RFR-2026-00115'), 'Completed — CB ACK', 'success', 'done'),
  actioned('h-6', rfr('RFR-2026-00112'), 'Rejected by Checker', 'error', 'rejected'),
  {
    ...QUEUE_ITEMS[4],
    id: 'h-7',
    refundRef: 'RFD-2026-00228',
    originalRef: 'IPI-2026-00339',
    systemRef: 'IPI-2026-00339',
    txnInitiatedAt: '2026-09-20',
    valueDate: '2026-09-20',
    refundInitiatedAt: '2026-09-24T10:30',
    originalAmount: 6200,
    refundAmount: 6200,
    reason: 'AC03 — Invalid creditor account',
    status: 'Completed — pacs.004 received',
    statusModifier: 'success',
    yourAction: '',
    stage: 'done',
    age: '—',
    slaBreached: false,
  },
];

/** The employee records of a WPS request, as the Record List tab shows them. */
export function queueRecords(item: QueueItem): RfrRecord[] {
  return item.recordList ?? (item.rfr ? rfrRecords(item.rfr) : []);
}

/** `YYYY-MM` of the salaries a WPS request refunds: its own period, else the value date's month. */
export function salaryPeriodOf(item: QueueItem): string | null {
  return item.salaryPeriod ?? item.valueDate?.slice(0, 7) ?? null;
}

/** `2026-08` (or `2026-08-28`) → `08/2026`. */
export function salaryMonth(period: string | null): string {
  return period ? `${period.slice(5, 7)}/${period.slice(0, 4)}` : '—';
}

/** One employee's SIF lines — its EDR and EVP — as the SIF Details section shows them. */
export interface SifRecordDetails {
  creditAccount: string;
  routingCode: string;
  payStart: string;
  payEnd: string;
  days: number;
  fixed: number;
  variable: number;
  leaveDays: number;
  mohreStatus: 'Updated' | 'Pending';
  accountType: 'Own Bank' | 'Other Bank';
  housing: number;
  conveyance: number;
  medical: number;
  annualPassage: number;
  overtime: number;
  other: number;
  leaveEncashment: number;
}

/** Derived from the record's salary and the salary period (`YYYY-MM`): 85% fixed, 10% of that housing. */
export function sifRecordDetails(record: RfrRecord, period: string | null): SifRecordDetails {
  const [year, month] = period ? [Number(period.slice(0, 4)), Number(period.slice(5, 7))] : [2026, 1];
  const days = new Date(year, month, 0).getDate();
  const mm = String(month).padStart(2, '0');
  const fixed = Math.round(record.totalSalary * 0.85 * 100) / 100;
  return {
    creditAccount: `AE6003300002300${String(10 + record.sl).padStart(2, '0')}`,
    routingCode: '033100101',
    payStart: `01-${mm}-${year}`,
    payEnd: `${days}-${mm}-${year}`,
    days,
    fixed,
    variable: Math.round((record.totalSalary - fixed) * 100) / 100,
    leaveDays: 0,
    mohreStatus: 'Updated',
    accountType: 'Own Bank',
    housing: Math.round(fixed * 0.1 * 100) / 100,
    conveyance: 200,
    medical: 150,
    annualPassage: 0,
    overtime: 0,
    other: 0,
    leaveEncashment: 0,
  };
}

/** One charge line of a request. */
export interface ChargeLine {
  label: string;
  amount: number;
  /** Posting Type and the GL account it credits. */
  posting: { type: 'Charge' | 'CB Charge' | 'VAT'; account: string; accountLabel: string };
}

const PL = { account: 'PL-AED-0042', accountLabel: 'Refund Charge P&L A/c' };

/** Charges as Charge Configuration supplies them: per file and per record for WPS, per record otherwise. */
export function queueCharges(item: QueueItem): { lines: ChargeLine[]; total: number } {
  const base: ChargeLine[] =
    item.rail === 'WPS'
      ? [
          { label: 'Refund Charge per File (AED 10.00 × 1)', amount: 10, posting: { type: 'Charge', ...PL } },
          { label: `Refund Charge per Record (AED 2.00 × ${item.records})`, amount: 2 * item.records, posting: { type: 'Charge', ...PL } },
          { label: 'CB Charge (AED 5.00 × 1)', amount: 5, posting: { type: 'CB Charge', account: 'BANK-FEE-AED-001', accountLabel: 'CB Charge A/c' } },
        ]
      : [
          { label: `Refund Charge per Record (AED 25.00 × ${item.records})`, amount: 25 * item.records, posting: { type: 'Charge', ...PL } },
          { label: 'CB Charge (AED 5.00 × 1)', amount: 5, posting: { type: 'CB Charge', account: 'BANK-FEE-AED-001', accountLabel: 'CB Charge A/c' } },
        ];
  const subtotal = base.reduce((s, l) => s + l.amount, 0);
  const vat = Math.round(subtotal * 0.05 * 100) / 100;
  const lines = [...base, { label: 'VAT (5%)', amount: vat, posting: { type: 'VAT' as const, account: 'VAT-AED-0010', accountLabel: 'VAT A/c' } }];
  return { lines, total: Math.round((subtotal + vat) * 100) / 100 };
}

/** The account charges are debited from. */
export function debitAccountOf(item: QueueItem): string {
  return item.debitAccount ?? item.rfr?.employerAccount ?? item.txn?.debtorAccount ?? '—';
}

export interface ActionHistoryEntry {
  name: string;
  role: string;
  at: string;
  action: string;
  /** `.status-badge` modifier of `action`. */
  modifier: string;
  comments: string;
}

/** Who has acted on the request so far. */
export function actionHistory(item: QueueItem): ActionHistoryEntry[] {
  if (item.history) return item.history;
  const entries: ActionHistoryEntry[] = [
    { name: item.initiatedBy, role: 'Bank Maker', at: item.refundInitiatedAt, action: 'Initiated', modifier: 'blue', comments: item.makerRemarks },
  ];
  if (item.stage === 'nak' || item.stage === 'done') {
    entries.push({ name: CURRENT_CHECKER, role: 'Bank Checker', at: item.refundInitiatedAt, action: 'Approved', modifier: 'success', comments: 'Verified — RFR generation queued' });
  }
  if (item.stage === 'nak') {
    entries.push({ name: 'Central Bank', role: 'System', at: item.refundInitiatedAt, action: 'NAK', modifier: 'error', comments: 'RFR rejected by Central Bank — file validation failed' });
  }
  if (item.stage === 'rejected') {
    entries.push({ name: CURRENT_CHECKER, role: 'Bank Checker', at: item.refundInitiatedAt, action: 'Rejected', modifier: 'error', comments: 'Rejected — supporting documents missing' });
  }
  return entries;
}

export type StepState = 'done' | 'current' | 'failed' | 'todo';

/** The request's progress, as the popup's stepper shows it. */
export function queueSteps(item: QueueItem): { label: string; state: StepState; hint?: string }[] {
  if (item.stage === 'declined') {
    // Approved and recalled, but the beneficiary bank declined: the Maker acknowledges and closes.
    const labels = ['Initiated', 'Checker Approved', 'Recall Sent', 'Bank Response', 'Posted'];
    return labels.map((label, i) =>
      i < 3 ? { label, state: 'done' } : i === 3 ? { label, state: 'failed', hint: item.yourAction } : { label, state: 'todo' },
    );
  }
  const labels =
    item.rail === 'WPS'
      ? ['Initiated', 'Checker Verified', 'RFR Sent to CB', 'RFR ACK']
      : item.stage === 'post'
        ? ['Initiated', 'Recall Sent', 'Return Received', 'Checker Verified']
        : ['Initiated', 'Checker Verified', 'Recall Sent', 'Network Response'];
  // Index of the current step; anything before it is done.
  const current =
    item.stage === 'maker' ? 0 : item.stage === 'nak' || item.stage === 'post' ? 3 : item.stage === 'done' ? labels.length : 1;
  return labels.map((label, i) => {
    if (i < current) return { label, state: 'done' };
    if (i === current) {
      return item.stage === 'nak'
        ? { label: 'RFR NAK', state: 'failed', hint: item.yourAction }
        : { label, state: 'current', hint: item.yourAction };
    }
    return { label, state: 'todo' };
  });
}

/** ACK / NAK file names the CB sent, where the design names them. */
const CB_RESPONSE_FILES: Record<string, string> = {
  'RFR-2026-00126': '00000049388010020517125961000000262.NAK',
};

const money = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** How the request reached the bank, as the audit trail words it. */
function createdVia(item: QueueItem): string {
  if (item.initiatedBy.startsWith('I-Business')) return 'I-Business';
  return item.channel === 'Direct Entry' ? 'Web Portal' : item.channel;
}

/** What More Details shows: the user's remarks, if a user acted, and the files behind the step. */
function detail(title: string, downloads: AuditDownload[], remarks: AuditUserRemark[] = []): AuditActivityDetail {
  return { title, subtitle: 'Files', remarks, downloads };
}

/**
 * The audit trail of a queued request — created, then each step it has passed: the Checker's
 * verification, the file or recall sent, and the CB's or beneficiary bank's answer. Every step
 * carries the request's own time.
 */
export function queueAuditActivities(item: QueueItem): AuditActivity[] {
  const when = `${item.refundInitiatedAt}:00`;
  const step = (
    id: string,
    activity: string,
    actionBy: string,
    actionByIsPerson: boolean,
    channel: AuditActivity['channel'],
    remarks: string,
    more?: AuditActivityDetail,
    status: AuditActivity['status'] = 'Success',
  ): AuditActivity => ({ id, activity, actionBy, actionByIsPerson, startedAt: when, endedAt: when, channel, status, remarks, detail: more });
  const records = `${item.records} record${item.records === 1 ? '' : 's'}`;

  const activities: AuditActivity[] = [
    step(
      'created',
      'Refund request created',
      item.initiatedBy,
      // A corporate channel user ("I-Business (corp.user01)") is a system login, not a named person.
      !item.initiatedBy.includes('('),
      'System',
      `Refund request created via ${createdVia(item)} — ${records}, AED ${money(item.refundAmount)}`,
    ),
  ];

  // Uploaded by the corporate: the service validates the file before the Maker reviews it.
  if (item.stage === 'maker') {
    activities.push(step('validated', 'File auto-validated by service', 'System', false, 'System', 'File auto-validated by service — accepted. Email sent to corporate.'));
    return activities;
  }

  if (item.rail === 'WPS') {
    if (item.stage !== 'nak' && item.stage !== 'done') return activities;
    const rfrFile = item.rfr?.rfrFileName ?? `${item.refundRef}.RFR`;
    const nak = item.stage === 'nak';
    const response = CB_RESPONSE_FILES[item.refundRef] ?? `${rfrFile.replace(/\.RFR$/i, '')}_RESP.${nak ? 'NAK' : 'ACK'}`;
    const verified = 'Verified — RFR generation queued';
    const answer = `RFR ${nak ? 'NAK' : 'ACK'} attached by service`;
    activities.push(
      step(
        'verified',
        'Verified',
        CURRENT_CHECKER,
        true,
        'Web Portal',
        verified,
        detail('Verified', [{ label: 'RFR File', fileName: rfrFile }, { label: 'ACK / NAK File', fileName: response }], [
          { name: CURRENT_CHECKER, role: 'Bank Checker', remarks: verified },
        ]),
      ),
      step('pushed', `RFR ${rfrFile} pushed to CB-WPS SFTP`, 'System', false, 'System', `RFR ${rfrFile} pushed to CB-WPS SFTP`,
        detail('RFR pushed to CB-WPS SFTP', [{ label: 'RFR File', fileName: rfrFile }])),
      step('response', answer, 'System', false, 'System', answer, detail(answer, [{ label: 'ACK / NAK File', fileName: response }]), nak ? 'Failure' : 'Success'),
    );
    return activities;
  }

  // IPI / UAEFTS / IPP: approved by the Checker, recalled, then the beneficiary bank's answer.
  if (item.stage !== 'declined' && item.stage !== 'done' && item.stage !== 'post') return activities;
  const [recall = 'camt.056', reply = 'pacs.004'] = (item.recallMessage ?? 'camt.056 / pacs.004').split(' / ');
  const ref = item.refundRef.toLowerCase();
  const recallFile = { label: `${recall} Recall`, fileName: `${ref}_${recall.toLowerCase()}.xml` };
  const approved = item.history?.find((h) => h.action === 'Approved')?.comments ?? 'Verified — recall sent to network';
  const declined = item.stage === 'declined';
  const answer = `${reply} ${declined ? 'response received — refund declined' : 'return received'}`;
  // Awaiting verification of a return (`post`): the recall went out before any Checker approval.
  if (item.stage !== 'post') {
    activities.push(
      step('approved', 'Approved', CURRENT_CHECKER, true, 'Web Portal', approved,
        detail('Approved', [recallFile], [{ name: CURRENT_CHECKER, role: 'Bank Checker', remarks: approved }])),
    );
  }
  activities.push(
    step('recall', `${recall} recall sent`, 'System', false, 'System', `${recall} recall sent to the beneficiary bank`, detail(`${recall} recall sent`, [recallFile])),
    step(
      'answer',
      answer,
      'System',
      false,
      'API',
      declined ? (item.notice?.text ?? `${reply}: refund declined`) : 'Funds returned and credited to the debtor',
      detail(answer, [{ label: `${reply} Response`, fileName: `${ref}_${reply.toLowerCase()}.xml` }]),
      declined ? 'Failure' : 'Success',
    ),
  );
  return activities;
}
