import { useMemo, useRef, useState } from 'react';
import type { ReactNode, RefObject } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, Globe, Landmark, Layers, Play, SlidersHorizontal, Wallet } from 'lucide-react';
import { PageBody, PageShell, SmartGrid, cn } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { Toast } from '../../../shared/components/Toast';
import type { ToastState } from '../../../shared/components/Toast';
import { formatAmount } from '../data';
import { Sif360Drawer } from '../Sif360Drawer';
import { AuditTrailDrawer } from '../SifAuditTrailDrawer';
import { maskName } from '../wpsAudit';
import { RFR_HISTORY } from '../wpsData';
import type { SifFile, SifPriority } from '../wpsData';
import { WpsRefundHistoryTab } from '../WpsRefundHistoryTab';
import { PILL, PRIORITY_MODIFIER, SMALL_BADGE, dateTime } from '../wpsStyles';
import {
  ASSIGNEES,
  MAKER_QUEUE_ITEMS,
  MULTIPLE_REASONS,
  PRIORITIES,
  QUEUE_CHANNELS,
  QUEUE_ITEMS,
  QUEUE_RAILS,
  SUB_TYPES,
  queueAuditActivities,
} from './queueData';
import type { QueueChannel, QueueItem, QueueOwner, QueueRail, QueueSubType } from './queueData';
import { RecallAuditTrailDrawer } from './MakerQueueSections';
import { RefundQueueActionDrawer } from './RefundQueueActionDrawer';
import type { QueueDecision } from './RefundQueueActionDrawer';
import { RAIL_PILL, when } from './queueStyles';

type Tab = 'queue' | 'history';
type RailFilter = QueueRail | 'ALL';

/** Rail tile icons — the same ones Refund Initiation and Domestic Payments use. */
const RAIL_ICON: Record<RailFilter, ReactNode> = {
  ALL: <Layers size={18} />,
  IPI: <Wallet size={18} />,
  UAEFTS: <Landmark size={18} />,
  WPS: <Briefcase size={18} />,
  IPP: <Globe size={18} />,
};

interface Filters {
  subType: QueueSubType | '';
  channel: QueueChannel | '';
  priority: SifPriority | '';
  amountMin: string;
  amountMax: string;
  from: string;
  to: string;
  assignedTo: string;
}

const EMPTY_FILTERS: Filters = {
  subType: '',
  channel: '',
  priority: '',
  amountMin: '',
  amountMax: '',
  from: '',
  to: '',
  assignedTo: '',
};

/** How many filters are set — the count on the Advanced Filter button. */
function activeCount(f: Filters): number {
  return Object.values(f).filter((v) => v !== '').length;
}

function matches(item: QueueItem, rail: RailFilter, f: Filters): boolean {
  const min = Number(f.amountMin);
  const max = Number(f.amountMax);
  const day = item.refundInitiatedAt.slice(0, 10);
  return (
    (rail === 'ALL' || item.rail === rail) &&
    (!f.subType || item.subType === f.subType) &&
    (!f.channel || item.channel === f.channel) &&
    (!f.priority || item.priority === f.priority) &&
    (f.amountMin === '' || item.refundAmount >= min) &&
    (f.amountMax === '' || item.refundAmount <= max) &&
    (!f.from || day >= f.from) &&
    (!f.to || day <= f.to) &&
    (!f.assignedTo || item.assignedTo === f.assignedTo)
  );
}

/** A single-choice dropdown — the Payment Queue's advanced-filter `SelectGroup`. */
function SelectGroup<T extends string>({
  title,
  options,
  value,
  onSelect,
  allLabel = 'All',
}: {
  title: string;
  options: readonly T[];
  value: T | '';
  onSelect: (value: T | '') => void;
  allLabel?: string;
}) {
  return (
    <div className="pq-filter-group">
      <div className="pq-filter-group-head">
        <span className="input-label">{title}</span>
      </div>
      <select value={value} onChange={(e) => onSelect(e.target.value as T | '')} aria-label={title} className="input-cls pq-filter-select">
        <option value="">{allLabel}</option>
        {options.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>
    </div>
  );
}

/** A labelled single input of the panel, e.g. a date. */
function InputGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="pq-filter-group">
      <div className="pq-filter-group-head">
        <span className="input-label">{title}</span>
      </div>
      <div className="pq-range-row">{children}</div>
    </div>
  );
}

/**
 * The advanced filters — the Payment Queue Outward's horizontal panel above the grid: dropdowns,
 * amount range and dates, with Reset, Save Filter and Set Default underneath.
 */
function AdvancedFilterPanel({
  value,
  onChange,
  onSave,
  onSetDefault,
}: {
  value: Filters;
  onChange: (next: Filters) => void;
  onSave: () => void;
  onSetDefault: () => void;
}) {
  const set = <K extends keyof Filters>(key: K, v: Filters[K]) => onChange({ ...value, [key]: v });
  return (
    <div className="pq-filter-panel mb-3" aria-label="Advanced filters">
      <div className="pq-filter-grid">
        <SelectGroup title="Payment Sub-Type" options={SUB_TYPES} value={value.subType} onSelect={(v) => set('subType', v)} />
        <SelectGroup title="Channel" options={QUEUE_CHANNELS} value={value.channel} onSelect={(v) => set('channel', v)} />
        <SelectGroup title="Priority" options={PRIORITIES} value={value.priority} onSelect={(v) => set('priority', v)} />
        <SelectGroup title="Assigned To" options={ASSIGNEES} value={value.assignedTo} onSelect={(v) => set('assignedTo', v)} allLabel="Any" />

        <InputGroup title="Amount">
          <input
            type="number"
            min={0}
            placeholder="Min"
            value={value.amountMin}
            onChange={(e) => set('amountMin', e.target.value)}
            className="input-cls pq-range-input"
            aria-label="Minimum refund amount"
          />
          <span className="pq-range-sep">—</span>
          <input
            type="number"
            min={0}
            placeholder="Max"
            value={value.amountMax}
            onChange={(e) => set('amountMax', e.target.value)}
            className="input-cls pq-range-input"
            aria-label="Maximum refund amount"
          />
        </InputGroup>

        <InputGroup title="Start Date">
          <input type="date" value={value.from} onChange={(e) => set('from', e.target.value)} className="input-cls pq-range-input d-block" aria-label="Date from" />
        </InputGroup>
        <InputGroup title="End Date">
          <input type="date" value={value.to} onChange={(e) => set('to', e.target.value)} className="input-cls pq-range-input d-block" aria-label="Date to" />
        </InputGroup>
      </div>

      <div className="pq-filter-footer">
        <button type="button" onClick={() => onChange(EMPTY_FILTERS)} className="btn-tertiary h-38px">
          Reset
        </button>
        <div className="pq-filter-footer-actions">
          <button type="button" onClick={onSave} className="btn-secondary h-38px">
            Save Filter
          </button>
          <button type="button" onClick={onSetDefault} className="btn-primary h-38px">
            Set Default
          </button>
        </div>
      </div>
    </div>
  );
}

/** Handlers behind a ref: SmartGrid snapshots column definitions on first mount. */
interface QueueGridView {
  unmasked: boolean;
  onAction: (item: QueueItem) => void;
  onAudit: (item: QueueItem) => void;
}

function columns(view: RefObject<QueueGridView>, history: boolean): SmartGridColumn<QueueItem>[] {
  return [
    { key: 'sl', label: 'SL', numeric: true, getValue: (r) => r.id, render: (r) => <span className="text-[var(--text-muted)]">{r.id.slice(2)}</span> },
    {
      key: 'rail',
      label: 'Rail',
      filterKey: 'rail',
      getValue: (r) => r.rail,
      render: (r) => <span className={cn(PILL, RAIL_PILL[r.rail])}>{r.rail}</span>,
    },
    {
      key: 'refundRef',
      label: 'Refund Ref. No.',
      filterKey: 'refundRef',
      getValue: (r) => r.refundRef,
      render: (r) => <span className="font-bold text-[var(--text-primary)]">{r.refundRef}</span>,
    },
    {
      key: 'originalRef',
      label: 'Original Txn / File Ref.',
      filterKey: 'originalRef',
      getValue: (r) => r.originalRef,
      render: (r) => <span className="font-mono text-xs">{r.originalRef}</span>,
    },
    { key: 'systemRef', label: 'System Reference No.', filterKey: 'systemRef', getValue: (r) => r.systemRef },
    {
      key: 'debtorName',
      label: 'Debtor / Employer Name',
      filterKey: 'debtorName',
      pii: true,
      getMasked: (r) => ({ maskedValue: maskName(r.debtorName), actualValue: view.current.unmasked ? r.debtorName : null }),
    },
    {
      key: 'txnInitiatedAt',
      label: 'Transaction Initiated Date',
      sortKey: 'txnInitiatedAt',
      getValue: (r) => when(r.txnInitiatedAt),
      getSortValue: (r) => r.txnInitiatedAt,
    },
    { key: 'valueDate', label: 'Value Date', getValue: (r) => when(r.valueDate) },
    { key: 'records', label: 'No. of Records', numeric: true, getValue: (r) => String(r.records) },
    {
      key: 'originalAmount',
      label: 'Original Amount (AED)',
      numeric: true,
      sortKey: 'originalAmount',
      getValue: (r) => formatAmount(r.originalAmount),
      getSortValue: (r) => r.originalAmount,
    },
    { key: 'currency', label: 'Currency', getValue: (r) => r.currency },
    { key: 'messageType', label: 'Message Type', filterKey: 'messageType', getValue: (r) => r.messageType },
    { key: 'subType', label: 'Payment Sub-Type', getValue: (r) => r.subType },
    {
      key: 'refundInitiatedAt',
      label: 'Refund Initiated Date',
      sortKey: 'refundInitiatedAt',
      getValue: (r) => dateTime(r.refundInitiatedAt),
      getSortValue: (r) => r.refundInitiatedAt,
    },
    { key: 'initiatedBy', label: 'Refund Initiated By', filterKey: 'initiatedBy', getValue: (r) => r.initiatedBy },
    {
      key: 'refundAmount',
      label: 'Refund Amount (AED)',
      numeric: true,
      sortKey: 'refundAmount',
      getValue: (r) => formatAmount(r.refundAmount),
      getSortValue: (r) => r.refundAmount,
      render: (r) => <span className="font-bold text-[var(--text-primary)]">{formatAmount(r.refundAmount)}</span>,
    },
    {
      key: 'reason',
      label: 'Refund Reason',
      getValue: (r) => r.reason,
      render: (r) =>
        r.reason === MULTIPLE_REASONS ? (
          <span>
            Multiple <span className="text-[var(--text-muted)]">(see Record List)</span>
          </span>
        ) : (
          r.reason
        ),
    },
    {
      key: 'priority',
      label: 'Priority',
      getValue: (r) => r.priority,
      render: (r) => <span className={cn(SMALL_BADGE, PRIORITY_MODIFIER[r.priority])}>{r.priority}</span>,
    },
    {
      key: 'status',
      label: 'Status',
      getValue: (r) => r.status,
      render: (r) => (
        <div className="flex flex-col gap-1">
          <span className={cn(SMALL_BADGE, 'w-fit', r.statusModifier)}>{r.status}</span>
          {r.yourAction && <span className="text-[11px] font-semibold text-[var(--primary-blue)]">▸ Your action: {r.yourAction}</span>}
        </div>
      ),
    },
    {
      key: 'actions',
      label: 'Action',
      locked: true,
      render: (r) => (
        <div className="pq-row-actions">
          {/* Each user type sees only its own queue, so every pending row can be actioned. */}
          {!history && (
            <button type="button" onClick={() => view.current.onAction(r)} className="btn-secondary pq-view-action-btn">
              View &amp; Action
            </button>
          )}
          <button type="button" onClick={() => view.current.onAudit(r)} className="btn-secondary pq-view-action-btn">
            {r.rail === 'WPS' ? 'Audit' : 'Audit Trail'}
          </button>
        </div>
      ),
    },
  ];
}

/**
 * Refund Queue — the Checker's worklist of refund requests raised in Refund Initiation, across all
 * payment rails. Pick a rail, narrow with the filter panel, and View & Action a request to approve
 * or reject it; History lists the requests already actioned. Static: data comes from `queueData.ts`.
 */
export function RefundQueuePage() {
  const navigate = useNavigate();
  const [rail, setRail] = useState<RailFilter>('ALL');
  const [tab, setTab] = useState<Tab>('queue');
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  // The advanced filters show only once the Advanced Filter button opens them.
  const [filtersOpen, setFiltersOpen] = useState(false);
  // Static data with no backend: the page always shows the Checker's queue. The dummy Maker/Checker switch that
  // chose the owner was removed with Profile Switching (OD-3); a real owner comes from the active role when this gets an API.
  const owner: QueueOwner = 'checker';
  const [queues, setQueues] = useState<Record<QueueOwner, QueueItem[]>>(() => ({ checker: [...QUEUE_ITEMS], maker: [...MAKER_QUEUE_ITEMS] }));
  const queue = queues[owner];
  // The History tab's SIF 360, opened from an RFR's Refund 360.
  const [view360, setView360] = useState<SifFile | null>(null);
  const [unmasked, setUnmasked] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [actionItem, setActionItem] = useState<QueueItem | null>(null);
  const [auditItem, setAuditItem] = useState<QueueItem | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);

  const gridView = useRef<QueueGridView>({ unmasked, onAction: setActionItem, onAudit: setAuditItem });
  gridView.current.unmasked = unmasked;
  // Built once: SmartGrid never re-reads column definitions, and the closures read through the ref.
  const queueCols = useMemo(() => columns(gridView, false), []);

  const queueRows = useMemo(() => queue.filter((r) => matches(r, rail, filters)), [queue, rail, filters]);

  const unavailable = (message: string) => setToast({ tone: 'info', message });
  const filterCount = activeCount(filters);

  // Shared by both tabs' grids, above the toolbar: the Advanced Filter button at the right end, and the panel under it while open.
  const filterButton = (
    <button
      type="button"
      onClick={() => setFiltersOpen((o) => !o)}
      aria-expanded={filtersOpen}
      aria-controls="refund-queue-advanced-filters"
      className={cn('btn-secondary h-38px gap-2', filtersOpen && 'active')}
    >
      <SlidersHorizontal size={14} aria-hidden="true" />
      Advanced Filter
      {filterCount > 0 && <span className="pq-tab-count">{filterCount}</span>}
    </button>
  );
  const filterPanel = (
    <>
      <div className="mb-3 flex justify-end">{filterButton}</div>
      {filtersOpen && (
        <div id="refund-queue-advanced-filters">
          <AdvancedFilterPanel
            value={filters}
            onChange={setFilters}
            onSave={() => unavailable('Saving filters is not available on this static screen yet.')}
            onSetDefault={() => unavailable('Setting a default filter is not available on this static screen yet.')}
          />
        </div>
      )}
    </>
  );

  /** What a request's status becomes once its owner actions it. */
  function decidedStatus(item: QueueItem, decision: QueueDecision): string {
    const approve = decision === 'approve';
    if (item.stage === 'declined') return 'Acknowledged & closed';
    if (item.stage === 'maker') return approve ? 'Forwarded to Checker' : 'Rejected by Maker';
    if (item.stage === 'nak') return approve ? 'Resubmitted to CB' : 'NAK Acknowledged';
    if (!approve) return 'Rejected by Checker';
    return item.rail === 'WPS' ? 'Approved — RFR sent to CB' : 'Approved — recall sent';
  }

  function decide(item: QueueItem, decision: QueueDecision, remarks: string) {
    const status = decidedStatus(item, decision);
    // The actioned request leaves the queue; History lists RFR files, as Refund Initiation's does.
    setQueues((q) => ({ ...q, [owner]: q[owner].filter((r) => r.id !== item.id) }));
    setActionItem(null);
    setToast({ tone: decision === 'approve' ? 'success' : 'info', message: `${item.refundRef}: ${status}.` });
    // `remarks` goes to the audit trail once this is wired to a backend.
    void remarks;
  }

  const tabs: { key: Tab; label: string; count: number }[] = [
    { key: 'queue', label: 'Outward — Request Initiation Cycle', count: queueRows.length },
    { key: 'history', label: 'History', count: RFR_HISTORY.length },
  ];

  const pii = {
    unmasked,
    canUnmask: true,
    notice,
    onApply: (next: boolean) => {
      setUnmasked(next);
      setNotice(next ? 'Unmasked successfully.' : 'Masked again.');
    },
  };

  return (
    <PageShell>
      <PageBody>
        <div className="pq-page pr-2">
          {/* Breadcrumb */}
          <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
            <button onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">
              Dashboard
            </button>
            {' / Refunds / '}
            <span>Refund Queue</span>
          </p>

          {/* Title header */}
          <div className="pq-header flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">Refund Queue</h1>
              <p className="pq-header-subtitle">Track and action refund requests across all payment rails</p>
            </div>
            <span className="inline-flex items-center gap-2 text-xs text-[var(--text-muted)]">
              <span className="size-2 rounded-full bg-[var(--accent-green)]" aria-hidden="true" />
              <span className="font-semibold text-[var(--accent-green)]">Live</span>· network responses polled automatically
            </span>
          </div>

          {/* Rail picker */}
          <section className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 shadow-[var(--shadow-sm)]">
            <h2 className="mb-4 flex items-center gap-2 text-[13px] font-bold uppercase tracking-wider text-[var(--text-primary)]">
              <Play size={11} className="fill-current" aria-hidden="true" />
              Select Payment Rail
            </h2>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 lg:grid-cols-5" role="radiogroup" aria-label="Payment rail">
              {QUEUE_RAILS.map((r) => {
                const active = rail === r.code;
                return (
                  <button
                    key={r.code}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => setRail(r.code)}
                    className={cn('rail-card cursor-pointer', active && 'rail-card-selected')}
                  >
                    <span className="rail-icon" aria-hidden="true">
                      {RAIL_ICON[r.code]}
                    </span>
                    <span className="rail-text text-left">
                      <span className="block text-sm font-bold text-[var(--text-primary)]">{r.label}</span>
                      <span className="block text-xs text-[var(--text-muted)]">{r.description}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          <div className="pq-tabs" role="tablist" aria-label="Refund queue">
            {tabs.map((t) => (
              <button
                key={t.key}
                type="button"
                role="tab"
                aria-selected={tab === t.key}
                onClick={() => setTab(t.key)}
                className={cn('pq-tab', tab === t.key && 'pq-tab-active')}
              >
                <span className="pq-tab-label">{t.label}</span>
                <span className="pq-tab-count">{t.count}</span>
              </button>
            ))}
          </div>

          {tab === 'queue' ? (
            <SmartGrid<QueueItem>
              key="queue"
              columns={queueCols}
              rows={queueRows}
              getRowId={(r) => r.id}
              storageKey="refund-queue-columns-v1"
              emptyTitle="No refund requests"
              emptyMessage="No refund requests are waiting on this rail and filter. Choose All Rails or reset the advanced filters."
              exportFilename="refund-queue"
              exportFormats={['csv']}
              pii={pii}
              toolbarTop={filterPanel}
            />
          ) : (
            // The same History as Refund Initiation's WPS History tab: counts, filter, RFR grid, Refund 360 and Audit.
            <WpsRefundHistoryTab onOpen360={setView360} onUnavailable={unavailable} />
          )}
        </div>
      </PageBody>

      {actionItem && <RefundQueueActionDrawer item={actionItem} owner={owner} onDecide={decide} onClose={() => setActionItem(null)} />}

      {/* Audit (a WPS RFR): the activity grid. Audit Trail (IPI / UAEFTS / IPP): the request's read-only transaction view. */}
      {auditItem && auditItem.rail !== 'WPS' && <RecallAuditTrailDrawer item={auditItem} onClose={() => setAuditItem(null)} />}
      {auditItem && auditItem.rail === 'WPS' && (
        <AuditTrailDrawer
          reference={auditItem.refundRef}
          summary={[
            { label: 'Reference', value: auditItem.refundRef, mono: true },
            { label: 'Transaction Type', value: 'WPS — Request for Refund (RFR)' },
            { label: 'Employer Name', value: auditItem.debtorName },
            { label: 'CB / Platform Reference ID', value: auditItem.rfr?.rfrFileName ?? '—', mono: true },
          ]}
          // A file the CB rejected reads as its NAK, as the RFR's own trail shows it.
          status={auditItem.stage === 'nak' ? { text: 'NAK', modifier: 'error' } : { text: auditItem.status, modifier: auditItem.statusModifier }}
          activities={queueAuditActivities(auditItem)}
          storageKey="refund-queue-audit-columns-v1"
          exportFilename={`refund-audit-trail-${auditItem.refundRef.toLowerCase()}`}
          onClose={() => setAuditItem(null)}
          onUnavailable={unavailable}
        />
      )}

      {view360 && <Sif360Drawer sif={view360} onClose={() => setView360(null)} onUnavailable={unavailable} />}

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}
