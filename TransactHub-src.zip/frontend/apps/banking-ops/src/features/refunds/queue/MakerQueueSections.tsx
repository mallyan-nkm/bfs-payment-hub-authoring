import { Fragment, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Check, Download, X } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { formatAmount } from '../data';
import { BADGE, DrawerTabs, aed } from '../drawerParts';
import { RefundDrawer } from '../RefundDrawer';
import type { RfrRecord } from '../wpsData';
import { PILL, dateTime } from '../wpsStyles';
import { actionHistory, debitAccountOf, queueCharges, queueRecords, queueSteps, salaryMonth, salaryPeriodOf } from './queueData';
import type { ChargeLine, QueueItem, QueueNotice } from './queueData';
import { QUEUE_CHANNEL_TONE, RAIL_PILL, when } from './queueStyles';
import { SifDetailsTable } from './SifDetailsTable';

/**
 * The Refund Queue popup's sections as an Administrator Maker sees them — headed sections of
 * label / value rows rather than cards, a progress stepper across the top, and the request's
 * notice (how it arrived, or why it came back).
 */

const HEADING = 'border-b border-[var(--border)] pb-2 text-[15px] font-bold text-[var(--text-primary)]';
const MTH = 'whitespace-nowrap px-3 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[var(--text-2)]';
const MTD = 'px-3 py-3 align-top text-sm text-[var(--text-primary)]';

const POSTING_TONE: Record<ChargeLine['posting']['type'], string> = {
  Charge: 'border-orange-400/60 bg-orange-500/10 text-orange-600',
  'CB Charge': 'border-teal-500/50 bg-teal-500/10 text-teal-600',
  VAT: 'border-purple-400/50 bg-purple-500/10 text-purple-600',
};

const GL_CHIP =
  'inline-block rounded-md border border-[color-mix(in_srgb,var(--accent-green)_45%,transparent)] bg-[color-mix(in_srgb,var(--accent-green)_10%,transparent)] px-2 py-0.5 font-mono text-xs font-bold text-[var(--accent-green)]';

/** "SIF File Name (sent to CB)" → the name, with its parenthetical muted. */
function Label({ text }: { text: string }) {
  const i = text.indexOf(' (');
  if (i < 0) return <>{text}</>;
  return (
    <>
      {text.slice(0, i)} <span className="text-[var(--text-muted)]">{text.slice(i + 1)}</span>
    </>
  );
}

/** One label / value row, value right-aligned. */
function KV({ label, value, mono, strong }: { label: string; value: ReactNode; mono?: boolean; strong?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-[var(--border)] py-2.5">
      <span className="text-sm text-[var(--text-2)]">
        <Label text={label} />
      </span>
      <span className={cn('text-right text-sm text-[var(--text-primary)]', mono && 'font-mono text-xs', strong ? 'font-bold' : 'font-medium')}>{value}</span>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="flex flex-col">
      <h3 className={HEADING}>{title}</h3>
      {children}
    </section>
  );
}

/** Rows in two columns, filled left then right per line. */
function TwoColumns({ rows }: { rows: { label: string; value: ReactNode; mono?: boolean; strong?: boolean }[] }) {
  return (
    <div className="grid grid-cols-1 gap-x-8 sm:grid-cols-2">
      {rows.map((r) => (
        <KV key={r.label} {...r} />
      ))}
    </div>
  );
}

/** The header's chips, separated by middots as the design lays them out. */
export function MakerMeta({ item }: { item: QueueItem }) {
  const parts: ReactNode[] = [
    <span key="rail" className={cn(PILL, RAIL_PILL[item.rail])}>
      {item.rail}
    </span>,
    item.rfr ? `MOL ID ${item.rfr.employerId}` : item.originalRef,
  ];
  if (item.rail === 'WPS') {
    parts.push(
      <span key="channel" className={cn(PILL, QUEUE_CHANNEL_TONE[item.channel])}>
        {item.channel}
      </span>,
    );
  }
  parts.push(
    when(item.refundInitiatedAt),
    <span key="status" className={cn(BADGE, item.statusModifier)}>
      {item.status}
    </span>,
    <span key="sla" className={cn('text-xs font-semibold', item.slaBreached ? 'text-[var(--accent-red)]' : 'text-[var(--text-muted)]')}>
      ⏱ {item.age}
      {item.slaBreached ? ' — SLA breached' : ' in queue'}
    </span>,
  );
  return (
    <>
      {parts.map((p, i) => (
        <Fragment key={i}>
          {i > 0 && <span className="text-[var(--text-muted)]">·</span>}
          {typeof p === 'string' ? <span className="text-xs text-[var(--text-2)]">{p}</span> : p}
        </Fragment>
      ))}
    </>
  );
}

/** Progress across the top: done green, current blue, failed red; the Maker's task under the current step. */
function Stepper({ item }: { item: QueueItem }) {
  const steps = queueSteps(item);
  return (
    <ol className="grid py-2" style={{ gridTemplateColumns: `repeat(${steps.length}, minmax(0, 1fr))` }} aria-label="Refund progress">
      {steps.map((s, i) => {
        const next = steps[i + 1];
        return (
          <li key={s.label} className="relative flex flex-col items-center gap-1.5 px-1 text-center" aria-current={s.state === 'current' ? 'step' : undefined}>
            {/* Line to the next step — green once this step is done and the next has been reached. */}
            {next && (
              <span
                aria-hidden="true"
                className={cn(
                  'absolute left-1/2 top-3 h-0.5 w-full',
                  s.state === 'done' && next.state !== 'todo' ? 'bg-[var(--accent-green)]' : 'bg-[var(--border)]',
                )}
              />
            )}
            <span
              className={cn(
                'relative z-[1] grid size-6 place-items-center rounded-full text-xs font-bold',
                s.state === 'done' && 'bg-[var(--accent-green)] text-white',
                s.state === 'current' && 'bg-[var(--primary-blue)] text-white ring-4 ring-[color-mix(in_srgb,var(--primary-blue)_20%,transparent)]',
                s.state === 'failed' && 'bg-[var(--accent-red)] text-white ring-4 ring-[color-mix(in_srgb,var(--accent-red)_20%,transparent)]',
                s.state === 'todo' && 'border border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-muted)]',
              )}
            >
              {s.state === 'done' ? <Check size={13} strokeWidth={3} /> : s.state === 'failed' ? '!' : i + 1}
            </span>
            <span
              className={cn(
                'text-xs font-semibold',
                s.state === 'done' && 'text-[var(--accent-green)]',
                s.state === 'current' && 'text-[var(--primary-blue)]',
                s.state === 'failed' && 'text-[var(--accent-red)]',
                s.state === 'todo' && 'text-[var(--text-muted)]',
              )}
            >
              {s.label}
            </span>
            {s.hint && <span className="text-[11px] text-[var(--text-muted)]">{s.hint}</span>}
          </li>
        );
      })}
    </ol>
  );
}

function Notice({ notice }: { notice: QueueNotice }) {
  const red = notice.tone === 'red';
  const i = notice.strong ? notice.text.indexOf(notice.strong) : -1;
  const text =
    i < 0 || !notice.strong ? (
      notice.text
    ) : (
      <>
        {notice.text.slice(0, i)}
        <strong>{notice.strong}</strong>
        {notice.text.slice(i + notice.strong.length)}
      </>
    );
  return (
    <div
      role={red ? 'alert' : 'note'}
      className={cn(
        'rounded-lg border px-4 py-3 text-sm',
        red
          ? 'border-[color-mix(in_srgb,var(--accent-red)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-red)_8%,transparent)] text-[var(--accent-red)]'
          : 'border-[color-mix(in_srgb,var(--primary-blue)_30%,transparent)] bg-[color-mix(in_srgb,var(--primary-blue)_8%,transparent)] text-[var(--primary-blue)]',
      )}
    >
      {notice.title && <p className="font-bold">{notice.title}</p>}
      <p>{text}</p>
    </div>
  );
}

export function MakerTransactionDetails({ item }: { item: QueueItem }) {
  const wps = item.rail === 'WPS';
  const charges = queueCharges(item);
  const debit = debitAccountOf(item);
  const history = actionHistory(item);
  const t = item.txn;

  return (
    <div className="flex flex-col gap-6">
      <Stepper item={item} />
      {item.notice && <Notice notice={item.notice} />}

      {wps ? (
        <Section title="Request Summary">
          <TwoColumns
            rows={[
              { label: 'Refund Reference', value: item.refundRef, strong: true },
              { label: 'Channel', value: <span className={cn(PILL, QUEUE_CHANNEL_TONE[item.channel])}>{item.channel}</span> },
              { label: 'Corporate Name', value: item.debtorName },
              { label: 'MOL ID (Employer)', value: item.rfr?.employerId ?? '—', mono: true },
              { label: 'SIF File Name (sent to CB)', value: item.originalRef, mono: true },
              { label: 'Original File Name (received from bank)', value: item.rfr?.originalFileName ?? '—', mono: true },
              {
                label: 'Refund Request File',
                value: item.refundRequestFile ? (
                  <span className="inline-flex items-center gap-1 font-mono text-xs text-[var(--primary-blue)]">
                    <Download size={12} aria-hidden="true" />
                    {item.refundRequestFile}
                  </span>
                ) : (
                  '— (SIF selection)'
                ),
              },
              { label: 'Initiated By', value: item.initiatedBy },
              { label: 'Initiated Date', value: dateTime(item.refundInitiatedAt) },
              { label: 'Total Records', value: item.records },
              { label: 'Total Refund Amount', value: aed(item.refundAmount), strong: true },
            ]}
          />
        </Section>
      ) : (
        <>
          <Section title="Refund Request">
            <TwoColumns
              rows={[
                { label: 'Refund Reference', value: item.refundRef, strong: true },
                { label: 'Rail', value: <span className={cn('rounded-md px-2 py-0.5 text-xs font-bold', RAIL_PILL[item.rail])}>{item.rail}</span> },
                { label: 'Refund Reason', value: item.reason },
                { label: 'Recall Message', value: item.recallMessage ?? 'camt.056 / pacs.004' },
                { label: 'Initiated By', value: item.initiatedBy },
                { label: 'Initiated Date', value: dateTime(item.refundInitiatedAt) },
                { label: 'Refund Amount', value: aed(item.refundAmount), strong: true },
                { label: 'Refund Type', value: item.refundAmount === item.originalAmount ? 'Full' : 'Partial' },
              ]}
            />
          </Section>
          <Section title="Original Transaction">
            <TwoColumns
              rows={[
                { label: 'System Reference No.', value: item.systemRef },
                { label: t?.e2eLabel ?? 'End-to-End ID', value: t?.e2eId ?? '—', mono: true },
                { label: 'Debtor Name', value: item.debtorName },
                { label: 'Creditor Name', value: t?.creditorName ?? '—' },
                { label: 'Creditor Bank', value: t?.creditorBank ?? '—' },
                { label: 'Original Amount', value: aed(item.originalAmount) },
              ]}
            />
          </Section>
        </>
      )}

      <Section title="Charge Details">
        <KV
          label="Charge Source"
          value={<span className="rounded-md bg-[color-mix(in_srgb,var(--accent-amber)_18%,transparent)] px-2 py-0.5 text-xs font-bold text-[var(--accent-amber)]">Charge Configuration</span>}
        />
        {charges.lines.map((l) => (
          <KV key={l.label} label={l.label} value={aed(l.amount)} />
        ))}
        <div className="mt-3 flex items-center justify-between gap-3 rounded-lg border border-[color-mix(in_srgb,var(--accent-blue)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] px-4 py-3 font-bold text-[var(--accent-blue)]">
          <span>Total Refund Charges</span>
          <span className="tabular-nums">{aed(charges.total)}</span>
        </div>
      </Section>

      <Section title="Posting Details">
        <div className="mt-2 overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[var(--bg-secondary)]">
              <tr>
                <th className={MTH}>Posting Type</th>
                <th className={MTH}>Debit Account</th>
                <th className={MTH}>Credit Account</th>
                <th className={MTH}>Status</th>
              </tr>
            </thead>
            <tbody>
              {charges.lines.map((l) => (
                <tr key={l.label} className="border-b border-[var(--border)]">
                  <td className={MTD}>
                    <span className={cn('inline-block rounded-md border px-2 py-0.5 text-xs font-bold', POSTING_TONE[l.posting.type])}>{l.posting.type}</span>
                  </td>
                  <td className={MTD}>
                    <span className="block font-mono text-xs font-semibold">{debit}</span>
                    <span className="text-xs text-[var(--text-muted)]">{wps ? 'Employer A/c' : 'Debtor A/c'}</span>
                  </td>
                  <td className={MTD}>
                    <span className={GL_CHIP}>{l.posting.account}</span>
                    <span className="mt-1 block text-xs text-[var(--text-muted)]">{l.posting.accountLabel}</span>
                  </td>
                  <td className={MTD}>
                    <span className={BADGE}>Pending</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      <Section title="Action History">
        <div className="mt-2 overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[var(--bg-secondary)]">
              <tr>
                <th className={MTH}>Name (Role)</th>
                <th className={MTH}>Date &amp; Time</th>
                <th className={MTH}>Action</th>
                <th className={MTH}>Comments</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={`${h.action}-${h.name}`} className="border-b border-[var(--border)]">
                  <td className={MTD}>
                    <span className="block font-bold">{h.name}</span>
                    <span className="text-xs text-[var(--text-muted)]">({h.role})</span>
                  </td>
                  <td className={MTD}>{dateTime(h.at)}</td>
                  <td className={MTD}>
                    <span className={cn(BADGE, h.modifier)}>{h.action}</span>
                  </td>
                  <td className={MTD}>{h.comments || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>
    </div>
  );
}

/** Record List — the employer's details, the employee records, and one employee's SIF lines on demand. */
export function MakerRecordList({ item }: { item: QueueItem }) {
  return (
    <SifRecordList
      header={[
        { label: 'Employer Unique ID', value: item.rfr?.employerId ?? '—', mono: true },
        { label: 'Employer Name', value: item.debtorName, strong: true },
        { label: 'Debit Account Number', value: debitAccountOf(item), mono: true },
        { label: 'Salary Month-Year', value: salaryMonth(salaryPeriodOf(item)), mono: true },
      ]}
      records={queueRecords(item)}
      period={salaryPeriodOf(item)}
    />
  );
}

/** A record's Refund Status badge modifier. */
const OUTCOME_BADGE: Record<RfrRecord['status'], string> = { Accepted: 'success', Rejected: 'error', Pending: 'warn' };

/**
 * A WPS refund's records — the employer header, the records table and, from a record's View SIF
 * Details, that employee's EDR / EVP lines under it. Shared by the Refund Queue and Refund 360.
 * `settled` shows each record's RSU outcome; until then every record is Pending.
 */
export function SifRecordList({
  header,
  records,
  period,
  settled = false,
}: {
  header: { label: string; value: string; mono?: boolean; strong?: boolean }[];
  records: RfrRecord[];
  /** The salary month, `YYYY-MM`. */
  period: string | null;
  settled?: boolean;
}) {
  const [sifRecord, setSifRecord] = useState<RfrRecord | null>(null);
  const sifRef = useRef<HTMLElement | null>(null);

  // Bring the SIF Details section into view when it opens or changes employee.
  useEffect(() => {
    if (sifRecord) sifRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [sifRecord]);

  return (
    <div className="flex flex-col gap-6">
      <dl className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
        {header.map((h) => (
          <div key={h.label} className="flex items-baseline gap-4 border-b border-[var(--border)] py-2">
            <dt className="w-48 shrink-0 text-xs text-[var(--text-2)]">{h.label}:</dt>
            <dd className={cn('text-sm text-[var(--text-primary)]', h.mono && 'font-mono text-xs', h.strong && 'font-semibold')}>{h.value}</dd>
          </div>
        ))}
      </dl>

      <div className="-mt-2 overflow-x-auto">
        <table className="w-full">
          <thead className="bg-[var(--bg-secondary)]">
            <tr>
              {['#', 'Employee ID (MOL ID)', 'Creditor Name', 'Total Salary (AED)', 'Refund Amount (AED)', 'Accepted Amount (AED)', 'Refund Type', 'Refund Reason', 'Refund Status', 'Action'].map((h) => (
                <th key={h} className={cn(MTH, h.includes('(AED)') && '!text-right')}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr
                key={r.sl}
                className={cn('border-b border-[var(--border)]', sifRecord?.sl === r.sl && 'bg-[color-mix(in_srgb,var(--accent-blue)_6%,transparent)]')}
              >
                <td className={cn(MTD, 'text-[var(--text-2)]')}>{r.sl}</td>
                <td className={cn(MTD, 'font-mono text-xs')}>{r.employeeId}</td>
                <td className={MTD}>{r.employeeName}</td>
                <td className={cn(MTD, 'text-right tabular-nums')}>{formatAmount(r.totalSalary)}</td>
                <td className={cn(MTD, 'text-right tabular-nums')}>{formatAmount(r.amount)}</td>
                <td className={cn(MTD, 'text-right tabular-nums', !(settled && r.status === 'Accepted') && 'text-[var(--text-muted)]')}>{settled && r.status === 'Accepted' ? formatAmount(r.amount) : '—'}</td>
                <td className={MTD}>
                  <span className={cn(BADGE, 'blue')}>{r.refundType === 'Full' ? 'Full Refund' : 'Partial Refund'}</span>
                </td>
                <td className={cn(MTD, 'whitespace-nowrap')}>{r.reason}</td>
                <td className={MTD}>
                  <span className={cn(BADGE, settled ? OUTCOME_BADGE[r.status] : 'warn')}>{settled ? r.status : 'Pending'}</span>
                </td>
                <td className={MTD}>
                  <button type="button" onClick={() => setSifRecord(r)} className="btn-secondary pq-view-action-btn whitespace-nowrap">
                    View SIF Details
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {sifRecord && (
        <section ref={sifRef} className="scroll-mt-4" aria-label={`SIF details — ${sifRecord.employeeName}`}>
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border)] pb-2">
            <h3 className="text-[15px] font-bold text-[var(--text-primary)]">
              SIF Details — {sifRecord.employeeName} <span className="font-mono text-sm font-normal">({sifRecord.employeeId})</span>
            </h3>
            <button
              type="button"
              onClick={() => setSifRecord(null)}
              className="inline-flex items-center gap-1 font-mono text-sm text-[var(--accent-green)] hover:underline"
            >
              <X size={15} aria-hidden="true" />
              Close
            </button>
          </div>
          <div className="mt-3 overflow-hidden rounded-lg border border-[var(--border)]">
            <SifDetailsTable record={sifRecord} period={period} />
          </div>
        </section>
      )}
    </div>
  );
}

/**
 * Audit Trail of an IPI / UAEFTS / IPP refund — the request's progress, the bank's answer, its
 * request and original transaction, charges, postings and action history, read-only. (A WPS RFR's
 * Audit is the activity grid instead — `AuditTrailDrawer`.)
 */
export function RecallAuditTrailDrawer({ item, onClose }: { item: QueueItem; onClose: () => void }) {
  return (
    <RefundDrawer
      eyebrow={`${item.refundRef} · ${item.rail} · ${item.bankLabel ?? 'Outward Refund'}`}
      title={item.txn ? `${item.debtorName} → ${item.txn.creditorName}` : item.debtorName}
      ariaLabel={`Audit trail — ${item.refundRef}`}
      meta={<MakerMeta item={item} />}
      tabs={<DrawerTabs tabs={[{ key: 'details', label: 'Transaction Details' }]} value="details" onChange={() => undefined} />}
      onClose={onClose}
    >
      <MakerTransactionDetails item={item} />
    </RefundDrawer>
  );
}
