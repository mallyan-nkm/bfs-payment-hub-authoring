import { formatDate } from '../../../shared/utils/formatDate';
import { dateTime } from '../wpsStyles';
import type { QueueChannel, QueueRail } from './queueData';

/** Rail pills — theme-token accents mixed with transparency, so they follow every theme. */
export const RAIL_PILL: Record<QueueRail, string> = {
  WPS: 'bg-[color-mix(in_srgb,var(--accent-green)_14%,transparent)] text-[var(--accent-green)]',
  IPI: 'bg-[color-mix(in_srgb,var(--accent-blue)_14%,transparent)] text-[var(--accent-blue)]',
  IPP: 'bg-orange-500/15 text-orange-600',
  UAEFTS: 'bg-purple-500/15 text-purple-500',
};

export const QUEUE_CHANNEL_TONE: Record<QueueChannel, string> = {
  'Web Portal': 'bg-[color-mix(in_srgb,var(--accent-blue)_14%,transparent)] text-[var(--accent-blue)]',
  IB: 'bg-purple-500/15 text-purple-500',
  CBX: 'bg-[color-mix(in_srgb,var(--accent-green)_14%,transparent)] text-[var(--accent-green)]',
  'Direct Entry': 'bg-[color-mix(in_srgb,var(--accent-amber)_16%,transparent)] text-[var(--accent-amber)]',
};

/** A date with its time when the rail records one: `27-Aug-2026 09:30`, else `22-Sep-2026`. */
export function when(iso: string | null): string {
  if (!iso) return '—';
  return iso.length > 10 ? dateTime(iso) : formatDate(iso);
}
