import { useEffect, useMemo, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { X } from 'lucide-react';
import { SmartGrid, cn, sessionDayOf, sessionInstant } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { formatDate } from '../../shared/utils/formatDate';
import { formatAmount } from './data';
import type { RefundRecord } from './data';
import { RefundSelectionGrid, mutedFor } from './RefundSelectionGrid';
import { Sif360Drawer } from './Sif360Drawer';
import { SifAuditTrailDrawer } from './SifAuditTrailDrawer';
import { EDR_RECORDS, RFR_HISTORY, SIF_FILES } from './wpsData';
import type { EdrRecord, SifFile, SifPriority, SifSource } from './wpsData';
import { WpsRefundHistoryTab } from './WpsRefundHistoryTab';

type Tab = 'sif' | 'history';

interface Filters {
  employerId: string;
  employerAccount: string;
  systemRef: string;
  originalFileName: string;
  from: string;
  to: string;
}

/** The date period the search panel opens on. */
const DEFAULT_FILTERS: Filters = {
  employerId: '',
  employerAccount: '',
  systemRef: '',
  originalFileName: '',
  from: '2026-08-01',
  to: '2026-09-30',
};

/**
 * The list opens unfiltered — every processed SIF, as the design shows (its June file sits outside
 * the default period). The period applies once the user searches.
 */
const OPEN_FILTERS: Filters = { ...DEFAULT_FILTERS, from: '', to: '' };

/**
 * Source as a coloured dot beside the name. The text stays in the theme's own colour, so it reads
 * in every theme; only the small dot carries the source's colour.
 */
const SOURCE_DOT: Record<SifSource, string> = {
  CBX: 'bg-[var(--accent-blue)]',
  'I-Business': 'bg-purple-500',
  'Host-to-Host (SFTP)': 'bg-[var(--accent-green)]',
  'Direct Entry (Branch)': 'bg-[var(--text-muted)]',
};

function SourceTag({ source }: { source: SifSource }) {
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap text-[var(--text-primary)]">
      <span className={cn('size-2 shrink-0 rounded-full', SOURCE_DOT[source])} aria-hidden="true" />
      {source}
    </span>
  );
}

/** Modifiers on the shared `.status-badge` (sass/_typography.scss) — the Department listing's status style. */
const PRIORITY_MODIFIER: Record<SifPriority, string> = {
  Urgent: 'error',
  High: 'warn',
  Normal: '',
};


/** A neutral bordered chip in the theme's own colours, e.g. the employer's group tag. */
const CHIP =
  'inline-block whitespace-nowrap rounded-full border border-[var(--border)] bg-[var(--bg-secondary)] px-2.5 py-0.5 text-xs font-semibold text-[var(--text-primary)]';

/** An instant in the session zone, `dd-MM-yyyy HH:mm:ss` (a zoneless mock value is UTC); a thin delegate. */
function initiatedText(iso: string): string {
  return sessionInstant(iso);
}

/** Handlers and the live row list behind a ref: SmartGrid snapshots column definitions on first mount. */
interface SifGridView {
  rows: SifFile[];
  onSelect: (sif: SifFile) => void;
  onView360: (sif: SifFile) => void;
  onAuditTrail: (sif: SifFile) => void;
}

function sifColumns(view: RefObject<SifGridView>): SmartGridColumn<SifFile>[] {
  return [
    {
      key: 'sl',
      label: 'SL',
      locked: true,
      numeric: true,
      render: (s) => {
        const i = view.current.rows.indexOf(s);
        return i < 0 ? '—' : i + 1;
      },
    },
    { key: 'sifFileName', label: 'SIF File Name', getValue: (s) => s.sifFileName, render: (s) => <span className="font-mono text-xs">{s.sifFileName}</span> },
    {
      key: 'originalFileName',
      label: 'Original File Name',
      getValue: (s) => s.originalFileName,
      render: (s) => <span className="font-mono text-xs">{s.originalFileName}</span>,
    },
    {
      key: 'systemRef',
      label: 'System Reference No.',
      sortKey: 'systemRef',
      getValue: (s) => s.systemRef,
      render: (s) => <span className="font-mono font-bold">{s.systemRef}</span>,
    },
    { key: 'employerId', label: 'Employer ID (MOL ID)', getValue: (s) => s.employerId, render: (s) => <span className="font-mono text-xs">{s.employerId}</span> },
    {
      key: 'employerName',
      label: 'Employer Name',
      sortKey: 'employerName',
      getValue: (s) => s.employerName,
      render: (s) => (
        <span className="inline-flex items-center gap-2 whitespace-nowrap">
          {s.employerName}
          {s.employerTag && <span className={CHIP}>{s.employerTag}</span>}
        </span>
      ),
    },
    { key: 'salaryMonth', label: 'Salary Month', getValue: (s) => s.salaryMonth },
    { key: 'salaryYear', label: 'Salary Year', getValue: (s) => s.salaryYear },
    {
      key: 'initiatedAt',
      label: 'Transaction Initiated Date',
      sortKey: 'initiatedAt',
      getValue: (s) => initiatedText(s.initiatedAt),
      getSortValue: (s) => s.initiatedAt,
    },
    { key: 'valueDate', label: 'Value Date', getValue: (s) => formatDate(s.valueDate), getSortValue: (s) => s.valueDate },
    { key: 'records', label: 'No. of Records', numeric: true, getValue: (s) => String(s.records) },
    { key: 'refundReturnCount', label: 'Refund-Return Count', numeric: true, getValue: (s) => String(s.refundReturnCount) },
    {
      key: 'totalSalary',
      label: 'Total Salary Amount (Fixed + Variable) (AED) excl. charges',
      numeric: true,
      sortKey: 'totalSalary',
      getValue: (s) => formatAmount(s.totalSalary),
      getSortValue: (s) => s.totalSalary,
    },
    { key: 'currency', label: 'Currency', getValue: (s) => s.currency },
    {
      key: 'source',
      label: 'Source',
      getValue: (s) => s.source,
      render: (s) => <SourceTag source={s.source} />,
    },
    {
      key: 'priority',
      label: 'Priority',
      getValue: (s) => s.priority,
      render: (s) => <span className={cn('status-badge', PRIORITY_MODIFIER[s.priority])}>{s.priority}</span>,
    },
    {
      key: 'actions',
      label: 'Action',
      locked: true,
      render: (s) => (
        <div className="pq-row-actions">
          <button type="button" onClick={() => view.current.onSelect(s)} className="btn-secondary pq-view-action-btn">
            Select
          </button>
          <button type="button" onClick={() => view.current.onView360(s)} className="btn-secondary pq-view-action-btn">
            360 View
          </button>
          <button type="button" onClick={() => view.current.onAuditTrail(s)} className="btn-secondary pq-view-action-btn">
            Audit Trail
          </button>
        </div>
      ),
    },
  ];
}

/** What an EDR record is — the columns before the shared refund ones. */
function edrColumns(): SmartGridColumn<EdrRecord>[] {
  const amount = (key: 'incomeFixed' | 'incomeVariable' | 'originalAmount', label: string): SmartGridColumn<EdrRecord> => ({
    key,
    label,
    numeric: true,
    getValue: (r) => formatAmount(r[key]),
    getSortValue: (r) => r[key],
    render: (r) => <span className={mutedFor(r)}>{formatAmount(r[key])}</span>,
  });
  return [
    { key: 'sl', label: 'SL', numeric: true, getValue: (r) => String(r.sl), render: (r) => <span className={mutedFor(r)}>{r.sl}</span> },
    {
      key: 'employeeId',
      label: 'Employee ID (MOL ID)',
      getValue: (r) => r.employeeId,
      render: (r) => <span className={cn('font-mono text-xs', mutedFor(r))}>{r.employeeId}</span>,
    },
    {
      key: 'creditorName',
      label: 'Creditor Name (Employee Name)',
      sortKey: 'creditorName',
      getValue: (r) => r.creditorName,
      render: (r) => <span className={mutedFor(r)}>{r.creditorName}</span>,
    },
    {
      key: 'creditorAccount',
      label: 'Creditor Account (Employee A/C)',
      getValue: (r) => r.creditorAccount,
      render: (r) => <span className={cn('font-mono text-xs', mutedFor(r))}>{r.creditorAccount}</span>,
    },
    {
      key: 'bank',
      label: 'Bank Name (Bank Code)',
      getValue: (r) => `${r.creditorBank} (${r.bankCode})`,
      render: (r) => <span className={cn('whitespace-nowrap', mutedFor(r))}>{`${r.creditorBank} (${r.bankCode})`}</span>,
    },
    amount('incomeFixed', 'Income Fixed'),
    amount('incomeVariable', 'Income Variable'),
    amount('originalAmount', 'Total Salary (Variable + Fixed) (AED)'),
  ];
}

function matches(s: SifFile, f: Filters): boolean {
  const has = (value: string, q: string) => value.toLowerCase().includes(q.trim().toLowerCase());
  const day = sessionDayOf(s.initiatedAt);
  return (
    (!f.employerId.trim() || has(s.employerId, f.employerId)) &&
    (!f.employerAccount.trim() || has(s.employerAccount, f.employerAccount)) &&
    (!f.systemRef.trim() || has(s.systemRef, f.systemRef)) &&
    (!f.originalFileName.trim() || has(s.originalFileName, f.originalFileName)) &&
    (!f.from || day >= f.from) &&
    (!f.to || day <= f.to)
  );
}

/** Label above, read-only value below. */
function ReadOnlyField({ label, value }: { label: string; value: string }) {
  const id = `sif-${label.replace(/\W+/g, '-').toLowerCase()}`;
  return (
    <div className="min-w-0">
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-[var(--text-primary)]">
        {label}
      </label>
      <input id={id} value={value} readOnly className="input-cls h-10 w-full text-sm" />
    </div>
  );
}

const LABEL = 'mb-1.5 block text-sm font-medium text-[var(--text-primary)]';
const CARD = 'rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 shadow-[var(--shadow-sm)]';

/**
 * WPS refund flow. WPS pays salaries in SIF files, so a refund starts from a successfully
 * processed SIF: search and Select one, then refund individual employee salary records (EDRs) in
 * the shared selection grid below it. The History tab lists earlier WPS refund requests.
 */
export function WpsRefundPanel({ onNext }: { onNext: (records: RefundRecord[]) => void }) {
  const [tab, setTab] = useState<Tab>('sif');
  const [input, setInput] = useState<Filters>(DEFAULT_FILTERS);
  const [applied, setApplied] = useState<Filters>(OPEN_FILTERS);
  const [selectedSif, setSelectedSif] = useState<SifFile | null>(null);
  const [view360, setView360] = useState<SifFile | null>(null);
  const [auditSif, setAuditSif] = useState<SifFile | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);
  const selectedRef = useRef<HTMLElement | null>(null);

  const rows = useMemo(() => SIF_FILES.filter((s) => matches(s, applied)), [applied]);

  const gridView = useRef<SifGridView>({
    rows,
    onSelect: setSelectedSif,
    onView360: setView360,
    onAuditTrail: setAuditSif,
  });
  gridView.current.rows = rows;

  // Built once: SmartGrid never re-reads column definitions, and the closures read through the ref.
  const columns = useMemo(() => sifColumns(gridView), []);
  const edrCols = useMemo(() => edrColumns(), []);

  // Bring the newly shown SIF details into view.
  useEffect(() => {
    if (selectedSif) selectedRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [selectedSif]);

  function setFilter<K extends keyof Filters>(key: K, value: Filters[K]) {
    setInput((prev) => ({ ...prev, [key]: value }));
  }

  const tabs: { key: Tab; label: string; count?: number }[] = [
    { key: 'sif', label: 'Successfully Processed SIF' },
    { key: 'history', label: 'History', count: RFR_HISTORY.length },
  ];

  return (
    <>
      <div className="pq-tabs" role="tablist" aria-label="WPS refunds">
        {tabs.map((t) => (
          <button
            key={t.key}
            type="button"
            role="tab"
            aria-selected={tab === t.key}
            onClick={() => setTab(t.key)}
            className={cn('pq-tab', tab === t.key && 'pq-tab-active')}
          >
            <span className="pq-tab-label">{t.label}</span>
            {t.count !== undefined && <span className="pq-tab-count">{t.count}</span>}
          </button>
        ))}
      </div>

      {tab === 'history' ? (
        <WpsRefundHistoryTab
          onOpen360={setView360}
          onUnavailable={(message) => setToast({ tone: 'info', message })}
        />
      ) : (
        <>
          {/* Search */}
          <section className={CARD}>
            <div className="grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <label htmlFor="wps-employer-id" className={LABEL}>
                  Employer ID (MOL ID)
                </label>
                <input
                  id="wps-employer-id"
                  value={input.employerId}
                  onChange={(e) => setFilter('employerId', e.target.value)}
                  placeholder="e.g. 808977026654343"
                  className="input-cls h-10 w-full text-sm"
                />
              </div>
              <div>
                <label htmlFor="wps-employer-account" className={LABEL}>
                  Employer Account Number
                </label>
                <input
                  id="wps-employer-account"
                  value={input.employerAccount}
                  onChange={(e) => setFilter('employerAccount', e.target.value)}
                  placeholder="e.g. AE070331452100001"
                  className="input-cls h-10 w-full text-sm"
                />
              </div>
              <div>
                <label htmlFor="wps-system-ref" className={LABEL}>
                  System Reference Number
                </label>
                <input
                  id="wps-system-ref"
                  value={input.systemRef}
                  onChange={(e) => setFilter('systemRef', e.target.value)}
                  placeholder="e.g. WPS-2026-00419"
                  className="input-cls h-10 w-full text-sm"
                />
              </div>
              <div>
                <label htmlFor="wps-file-name" className={LABEL}>
                  Original File Name
                </label>
                <input
                  id="wps-file-name"
                  value={input.originalFileName}
                  onChange={(e) => setFilter('originalFileName', e.target.value)}
                  placeholder="e.g. EmiratesSteel_Salary_Aug26.xlsx"
                  className="input-cls h-10 w-full text-sm"
                />
              </div>
              <fieldset className="sm:col-span-2 lg:col-span-1">
                <legend className={LABEL}>Date Period</legend>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    value={input.from}
                    max={input.to || undefined}
                    onChange={(e) => setFilter('from', e.target.value)}
                    aria-label="From date"
                    className="input-cls d-block h-10 w-full text-sm"
                  />
                  <input
                    type="date"
                    value={input.to}
                    min={input.from || undefined}
                    onChange={(e) => setFilter('to', e.target.value)}
                    aria-label="To date"
                    className="input-cls d-block h-10 w-full text-sm"
                  />
                </div>
              </fieldset>
            </div>
            <div className="mt-4 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setInput(DEFAULT_FILTERS);
                  setApplied(OPEN_FILTERS);
                }}
                className="btn-secondary large-btn justify-center !py-2.5 text-sm"
              >
                Clear
              </button>
              <button type="button" onClick={() => setApplied(input)} className="btn-primary large-btn justify-center !py-2.5 text-sm">
                Search
              </button>
            </div>
          </section>

          {/* Processed SIFs */}
          <SmartGrid<SifFile>
            columns={columns}
            rows={rows}
            getRowId={(s) => s.id}
            storageKey="refund-initiation-wps-sif-columns-v1"
            emptyTitle="No processed SIF files found"
            emptyMessage="No successfully processed SIF files match the search. Widen the date period or clear the search."
            exportFilename="wps-processed-sif-files"
            exportFormats={['csv']}
          />

          {selectedSif && (
            <>
              {/* Selected SIF */}
              <section ref={selectedRef} className={cn(CARD, 'scroll-mt-4')} aria-label="Selected SIF">
                <div className="mb-4 flex items-center justify-between gap-2">
                  <h2 className="text-[15px] font-bold text-[var(--text-primary)]">Selected SIF</h2>
                  <button
                    type="button"
                    onClick={() => setSelectedSif(null)}
                    className="inline-flex items-center gap-1 text-sm font-semibold text-[var(--primary-blue)] hover:underline"
                  >
                    <X size={15} aria-hidden="true" />
                    Change SIF
                  </button>
                </div>
                <div className="grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2 lg:grid-cols-4">
                  <ReadOnlyField label="SIF File Name" value={selectedSif.sifFileName} />
                  <ReadOnlyField label="Original File Name" value={selectedSif.originalFileName} />
                  <ReadOnlyField label="System Reference No." value={selectedSif.systemRef} />
                  <ReadOnlyField label="Source" value={selectedSif.source} />
                  <ReadOnlyField label="Employer ID (MOL ID)" value={selectedSif.employerId} />
                  <ReadOnlyField label="Employer Name" value={selectedSif.employerName} />
                  <ReadOnlyField label="Salary Month" value={selectedSif.salaryMonth} />
                  <ReadOnlyField label="Salary Year" value={selectedSif.salaryYear} />
                  <ReadOnlyField label="Transaction Initiated Date" value={initiatedText(selectedSif.initiatedAt)} />
                  <ReadOnlyField label="No. of Records" value={String(selectedSif.records)} />
                  <ReadOnlyField label="Refund-Return Count" value={String(selectedSif.refundReturnCount)} />
                  <ReadOnlyField
                    label="Total Salary Amount (Fixed + Variable) (AED, excl. charges)"
                    value={formatAmount(selectedSif.totalSalary)}
                  />
                </div>
              </section>

              {/* EDR records — keyed by SIF, so changing the SIF starts a clean selection. */}
              <RefundSelectionGrid<EdrRecord>
                key={selectedSif.id}
                rows={EDR_RECORDS[selectedSif.id] ?? []}
                leadingColumns={edrCols}
                title="EDR Details — select records to refund"
                note="Refund amount defaults to the credited salary · Refund Reason is mandatory for each selected record"
                noun="records"
                storageKey="refund-initiation-wps-edr-columns-v1"
                exportFilename={`wps-edr-${selectedSif.systemRef.toLowerCase()}`}
                emptyTitle="No EDR records"
                emptyMessage="This SIF has no employee salary records to refund."
                onNext={onNext}
              />
            </>
          )}
        </>
      )}

      {view360 && (
        <Sif360Drawer
          sif={view360}
          onClose={() => setView360(null)}
          onUnavailable={(message) => setToast({ tone: 'info', message })}
        />
      )}
      {auditSif && (
        <SifAuditTrailDrawer
          sif={auditSif}
          onClose={() => setAuditSif(null)}
          onUnavailable={(message) => setToast({ tone: 'info', message })}
        />
      )}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </>
  );
}
