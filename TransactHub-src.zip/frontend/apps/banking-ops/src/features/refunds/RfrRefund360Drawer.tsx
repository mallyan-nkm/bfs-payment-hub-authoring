import { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { formatAmount } from './data';
import { BADGE, DrawerTabs, FileLink, RelatedMessagesPanel, Row, SECTION, TD, TH, Tile, addMinutes, aed } from './drawerParts';
import type { Message, MsgField } from './drawerParts';
import { SifRecordList } from './queue/MakerQueueSections';
import { salaryMonth } from './queue/queueData';
import { RefundDrawer } from './RefundDrawer';
import { rfrCbFiles, rfrRecords } from './wpsData';
import type { RfrHistoryEntry, RfrRecord } from './wpsData';
import { CHANNEL_TONE, PILL, STATUS_MODIFIER, dateTime } from './wpsStyles';

/**
 * Refund 360 — one RFR's whole story, in the same drawer, tabs, rows, tiles and Related Messages
 * panel as SIF Summary 360: what was requested, the charges and postings it made, and its records.
 */

type Tab = 'summary' | 'charges' | 'records';

const TABS = [
  { key: 'summary', label: 'RFR Summary' },
  { key: 'charges', label: 'Charges & Posting' },
  { key: 'records', label: 'Record List' },
] as const;

/** The checker who approves RFRs in the seed. */
const APPROVER = 'Sooraj K';

/** The salary month the SIF paid, `YYYY-MM` — the month before its value date. */
function salaryPeriod(e: RfrHistoryEntry): string {
  const d = new Date(`${e.valueDate.slice(0, 7)}-01T00:00`);
  d.setMonth(d.getMonth() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

/** Where the RFR stands, in words. */
function stageOf(e: RfrHistoryEntry): string {
  switch (e.status) {
    case 'Pending':
      return 'Pending Checker Verification';
    case 'CB Pending':
      return 'RFR Sent — Awaiting ACK/NAK';
    case 'NAK':
      return 'CB NAK — RFR Rejected';
    case 'Rejected':
      return 'Rejected by Checker';
    default:
      return e.pendingCount > 0 ? 'ACK Received — Awaiting RSU' : 'RSU Received — Refund Completed';
  }
}

function rejectionRemarks(e: RfrHistoryEntry): string {
  if (e.status === 'NAK') return 'File rejected by CB — invalid employee reference';
  if (e.status === 'Rejected') return 'Rejected by Checker — supporting documents missing';
  return '—';
}

/** The agent bank's routing code — the employer's bank in the seed. */
const AGENT_ROUTING_CODE = '033100101';

/** The WPS reference the CB gives an RFR file: `006` + year + the RFR's sequence, e.g. `006202600105`. */
function wpsFileRef(e: RfrHistoryEntry): string {
  const [, year = '', seq = ''] = e.requestRef.split('-');
  return `006${year}${seq}`;
}

/** The RFR → RFR ACK/NAK → RSU exchange with the CB. */
function messages(e: RfrHistoryEntry): Message[] {
  const files = rfrCbFiles(e);
  const sentAt = dateTime(e.rfrInitiatedAt);
  // The CB answers within the minute in the design, so the ACK and RSU carry the send time.
  const answeredAt = sentAt;
  const settledAt = sentAt;
  const pending = (id: string, label: string): Message => ({ id, label, receivedText: 'Pending' });
  const records = rfrRecords(e);
  const fileRef = wpsFileRef(e);
  const sumOf = (status: RfrRecord['status']) => records.filter((r) => r.status === status).reduce((sum, r) => sum + r.amount, 0);
  /** The file's identity card in the Data Fields tab. */
  const card = (fileName: string): MsgField[] => [
    { label: 'File Name', value: fileName, mono: true },
    { label: 'MOL ID', value: e.employerId, mono: true },
    { label: 'Corporate Name', value: e.employerName },
  ];
  /** The fields of a file received from the CB — nobody initiates or approves it. */
  const received = (fileName: string): MsgField[] => [
    { label: 'File Name', value: fileName, mono: true },
    { label: 'Direction', value: '↓ Received from CB', badge: 'green' },
    { label: 'Initiated By', value: '—' },
    { label: 'Approved By', value: '—' },
    { label: 'Initiated DateTime', value: '—' },
    { label: 'Approved DateTime', value: '—' },
    { label: 'Total Records', value: String(e.records) },
    { label: 'Total Amount', value: aed(e.totalRefund), mono: true },
  ];

  const rfr: Message = files.rfr
    ? {
        id: 'rfr',
        label: 'RFR',
        receivedText: `↑ To CB · ${sentAt}`,
        status: { text: 'Sent', tone: 'blue' },
        detail: {
          tabbed: true,
          headerItems: [
            { label: 'Sent DateTime', value: sentAt },
            { label: 'Processed DateTime', value: sentAt },
          ],
          fields: [
            { label: 'File Name', value: files.rfr, mono: true },
            { label: 'Direction', value: '↑ Sent to CB', badge: 'blue' },
            { label: 'Initiated By', value: e.initiatedBy },
            { label: 'Approved By', value: `${APPROVER} (Checker)` },
            { label: 'Initiated DateTime', value: sentAt },
            { label: 'Approved DateTime', value: sentAt },
            { label: 'Total Records', value: String(e.records) },
            { label: 'Total Amount', value: aed(e.totalRefund), mono: true },
          ],
          card: card(files.rfr),
          rawFiles: [{ fileName: files.rfr, description: 'RFR file — sent to Central Bank' }],
          noErrorsText: 'No errors — awaiting Central Bank response.',
        },
      }
    : pending('rfr', 'RFR');

  const nak = e.status === 'NAK';
  const ack: Message = files.ack
    ? {
        id: 'rfr-ack',
        label: 'RFR ACK/NAK',
        receivedText: `↓ From CB · ${answeredAt}`,
        status: { text: nak ? 'NAK' : 'ACK', tone: nak ? 'red' : 'green' },
        detail: {
          tabbed: true,
          headerItems: [
            { label: 'Received DateTime', value: answeredAt },
            { label: 'Processed DateTime', value: answeredAt },
          ],
          fields: received(files.ack),
          card: card(files.ack),
          summary: {
            title: nak ? 'NAK — File Rejected' : 'ACK — File Accepted',
            tone: nak ? 'error' : 'success',
            items: [
              { label: 'Processed File Name', value: files.rfr ?? '—', mono: true },
              { label: 'Number of Records', value: String(e.records), mono: true },
              { label: 'Status', value: nak ? 'REJECTED' : 'ACCEPTED', badge: nak ? 'red' : 'green' },
            ],
          },
          rawFiles: [
            { fileName: files.ack, description: `Main ${nak ? 'NAK' : 'ACK'} file — received from Central Bank` },
            ...(files.ackDetail
              ? [{ fileName: files.ackDetail, description: 'Detailed acknowledgement — record-level status from Central Bank' }]
              : []),
          ],
          errors: nak ? [`Invalid employee reference on ${e.rejectedCount} record(s)`] : [],
        },
      }
    : pending('rfr-ack', 'RFR ACK/NAK');

  const rsu: Message = files.rsu
    ? {
        id: 'rsu',
        label: 'RSU',
        receivedText: `↓ From CB · ${settledAt}`,
        status:
          e.acceptedCount > 0
            ? { text: `${e.acceptedCount} Accepted`, tone: 'green' }
            : { text: `${e.rejectedCount} Rejected`, tone: 'red' },
        detail: {
          tabbed: true,
          headerItems: [
            { label: 'Received DateTime', value: settledAt },
            { label: 'Processed DateTime', value: settledAt },
          ],
          fields: received(files.rsu),
          card: card(files.rsu),
          cardFields: [
            { label: 'WPS Reference for the File', value: fileRef, mono: true },
            { label: 'Agent Routing Code', value: AGENT_ROUTING_CODE, mono: true },
          ],
          // Accepted records when any were accepted; otherwise the RSU reports the rejections.
          summary:
            e.acceptedCount > 0
              ? {
                  title: 'RSU — Accepted Records',
                  tone: 'success',
                  items: [
                    { label: 'Accepted Count', value: String(e.acceptedCount), mono: true },
                    { label: 'Accepted Amount', value: aed(sumOf('Accepted')), mono: true },
                  ],
                }
              : {
                  title: 'RSU — Rejected Records',
                  tone: 'error',
                  items: [
                    { label: 'Rejected Count', value: String(e.rejectedCount), mono: true },
                    { label: 'Rejected Amount', value: aed(sumOf('Rejected')), mono: true },
                  ],
                },
          table: {
            title: 'Refund Status Records',
            columns: [
              '#',
              'WPS Reference for the Line Item',
              'Employee Unique ID',
              'Refund Amount Requested (AED)',
              'Refund Status',
              'Bank Code of the Employer',
              'Employer Account Number',
              'Reject Reason',
              'Balance Outstanding with Agent (AED)',
            ],
            rows: records.map((r) => [
              { label: 'sl', value: String(r.sl) },
              // Line number (from 000) + the SIF's number + the file's WPS reference.
              { label: 'lineRef', value: `${String(r.sl - 1).padStart(3, '0')}${e.sifFileName.replace(/\D/g, '')}${fileRef}`, mono: true },
              { label: 'employeeId', value: r.employeeId, mono: true },
              { label: 'amount', value: formatAmount(r.amount) },
              { label: 'status', value: r.status.toUpperCase(), badge: r.status === 'Accepted' ? 'green' : r.status === 'Rejected' ? 'red' : 'blue' },
              { label: 'bankCode', value: AGENT_ROUTING_CODE, mono: true },
              { label: 'account', value: e.employerAccount, mono: true },
              { label: 'rejectReason', value: r.status === 'Rejected' ? r.reason : '—' },
              { label: 'balance', value: formatAmount(r.status === 'Accepted' ? 0 : r.amount) },
            ]),
          },
          rawFiles: [{ fileName: files.rsu, description: 'Main RSU file — received from Central Bank' }],
          errors: e.rejectedCount > 0 ? [`${e.rejectedCount} record(s) rejected by the agent bank`] : [],
        },
      }
    : pending('rsu', 'RSU');

  return [rfr, ack, rsu];
}

/** Posting-type tags: charges orange, the CB charge teal, VAT purple, refund credits blue. */
const TAG = 'inline-block rounded-md border px-2.5 py-1 text-xs font-bold';
const TAG_TONE = {
  charge: 'border-orange-400/60 bg-orange-500/10 text-orange-600',
  cb: 'border-teal-500/50 bg-teal-500/10 text-teal-600',
  vat: 'border-purple-400/50 bg-purple-500/10 text-purple-600',
  refund: 'border-[color-mix(in_srgb,var(--accent-blue)_40%,transparent)] bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] text-[var(--accent-blue)]',
} as const;
const ACCOUNT_CHIP =
  'inline-block rounded-md border border-[color-mix(in_srgb,var(--accent-green)_45%,transparent)] bg-[color-mix(in_srgb,var(--accent-green)_10%,transparent)] px-2 py-0.5 font-mono text-xs font-bold text-[var(--accent-green)]';
const CAPTION = 'text-xs text-[var(--text-muted)]';
const POST_CARD = 'rounded-xl border border-[var(--border)] bg-[var(--bg-card)] px-5 py-4';

/** The bank's CB nostro, which refund credits are debited from. */
const CB_NOSTRO = 'NOSTRO-CB-AED-001';

interface Posting {
  label: string;
  tone: keyof typeof TAG_TONE;
  debit: { account: string; label: string };
  credit: { account: string; label: string };
  amount: number;
  narration: string;
}

/** A green underlined "View" for a request / response log. */
function ViewLog({ onView }: { onView: () => void }) {
  return (
    <button type="button" onClick={onView} className="text-sm font-semibold text-[var(--accent-green)] underline underline-offset-2 hover:opacity-80">
      View
    </button>
  );
}

function Account({ caption, account, label, chip }: { caption: string; account: string; label: string; chip?: boolean }) {
  return (
    <div className="min-w-0">
      <p className={CAPTION}>{caption}</p>
      <p className="mt-0.5">
        <span className={chip ? ACCOUNT_CHIP : 'font-mono text-xs font-bold text-[var(--text-primary)]'}>{account}</span>
      </p>
      <p className={cn(CAPTION, 'mt-1')}>{label}</p>
    </div>
  );
}

/** One posting's tag, accounts and amount, with its narration under them. */
function PostingLine({ posting, tagged }: { posting: Posting; tagged: boolean }) {
  return (
    <div className="flex flex-col gap-3 border-b border-dashed border-[var(--border)] py-3 first:pt-0">
      <div className={cn('grid grid-cols-1 gap-3', tagged ? 'sm:grid-cols-[10rem_1fr_1fr_8rem]' : 'sm:grid-cols-[1fr_1fr_8rem]')}>
        {tagged && (
          <div>
            <span className={cn(TAG, TAG_TONE[posting.tone])}>{posting.label}</span>
          </div>
        )}
        <Account caption="Debit Account" {...posting.debit} />
        <Account caption="Credit Account" {...posting.credit} chip />
        <div>
          <p className={CAPTION}>Amount</p>
          <p className="mt-0.5 text-sm font-bold tabular-nums text-[var(--text-primary)]">{aed(posting.amount)}</p>
        </div>
      </div>
      <div>
        <p className={CAPTION}>Posting Narration</p>
        <p className="mt-0.5 text-sm text-[var(--text-primary)]">{posting.narration}</p>
      </div>
    </div>
  );
}

/** A posting card's footer: its core reference, when it posted, and its logs. */
function PostingFooter({ reference, at, onView }: { reference: string; at: string; onView: (what: string) => void }) {
  return (
    <dl className="grid grid-cols-2 gap-3 pt-3 sm:grid-cols-[1fr_1fr_0.8fr_0.8fr]">
      <div>
        <dt className={CAPTION}>Posting Reference Number</dt>
        <dd className="mt-0.5 font-mono text-xs font-bold text-[var(--text-primary)]">{reference}</dd>
      </div>
      <div>
        <dt className={CAPTION}>Posting Date &amp; Time</dt>
        <dd className="mt-0.5 text-sm text-[var(--text-primary)]">{at}</dd>
      </div>
      <div>
        <dt className={CAPTION}>Req Log</dt>
        <dd className="mt-0.5">
          <ViewLog onView={() => onView(`${reference} request log`)} />
        </dd>
      </div>
      <div>
        <dt className={CAPTION}>Res Log</dt>
        <dd className="mt-0.5">
          <ViewLog onView={() => onView(`${reference} response log`)} />
        </dd>
      </div>
    </dl>
  );
}

/** Posted / Pending / Not Posted, for a posting card's corner. */
function PostingStatus({ e, done }: { e: RfrHistoryEntry; done: boolean }) {
  const failed = e.status === 'Rejected' || e.status === 'NAK';
  return <span className={cn(BADGE, done ? 'success' : failed ? 'error' : 'warn')}>{done ? 'Posted' : failed ? 'Not Posted' : 'Pending'}</span>;
}

/**
 * Charges & Posting — the charge lines and their total; the charges as one core posting of four
 * entries, then one refund credit per accepted RSU record; and the calls made to outside systems.
 */
function ChargesPosting({ e, onUnavailable }: { e: RfrHistoryEntry; onUnavailable: (message: string) => void }) {
  const sent = e.status !== 'Pending' && e.status !== 'Rejected';
  const charged = sent && !e.chargeWaived;
  const view = (what: string) => onUnavailable(`Viewing the ${what} is not available on this static screen yet.`);
  const seq = e.requestRef.slice(-3);
  const employer = { account: e.employerAccount, label: 'Employer A/c' };
  const pl = { account: 'PL-AED-0042', label: 'Refund Charge P&L A/c' };

  // The configured WPS refund charges: per file, per record and the CB's, plus 5% VAT on them.
  const perRecord = 2 * e.records;
  const subtotal = 10 + perRecord + 5;
  const vat = Math.round(subtotal * 0.05 * 100) / 100;
  const lines = [
    { label: 'Refund Charge per File (AED 10.00 × 1)', amount: 10 },
    { label: `Refund Charge per Record (AED 2.00 × ${e.records})`, amount: perRecord },
    { label: 'CB Charge (AED 5.00 × 1)', amount: 5 },
    { label: 'VAT (5%)', amount: vat },
  ];
  const total = Math.round((subtotal + vat) * 100) / 100;

  const chargePostings: Posting[] = [
    { label: 'Refund Charge per File', tone: 'charge', debit: employer, credit: pl, amount: 10, narration: `Refund Charge per File — ${e.requestRef}` },
    { label: 'Refund Charge per Record', tone: 'charge', debit: employer, credit: pl, amount: perRecord, narration: `Refund Charge per Record — ${e.requestRef}` },
    { label: 'CB Charge', tone: 'cb', debit: employer, credit: { account: 'BANK-FEE-AED-001', label: 'CB Charge A/c' }, amount: 5, narration: `CB Charge — ${e.requestRef}` },
    { label: 'VAT', tone: 'vat', debit: employer, credit: { account: 'VAT-AED-0010', label: 'VAT A/c' }, amount: vat, narration: `VAT on refund charges — ${e.requestRef}` },
  ];
  // One refund credit per record the agent bank accepted in the RSU.
  const refunds = rfrRecords(e).filter((r) => r.status === 'Accepted');

  const external = [
    { action: 'Balance Enquiry', start: 3, end: 4 },
    { action: 'Core Posting — Charges', start: 10, end: 12 },
    { action: 'Notification Email', start: 14, end: 15 },
  ];

  return (
    <div className="flex flex-col gap-6">
      <section>
        <p className={cn(SECTION, 'mb-3 border-b border-[var(--border)] pb-2')}>Charge Details</p>
        <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-secondary)_40%,transparent)]">
          {[...lines, { label: 'Total Refund Charges', amount: total }].map((l, i, all) => {
            const last = i === all.length - 1;
            return (
              <div key={l.label} className="flex items-center justify-between gap-4 border-b border-[var(--border)] px-5 py-3 last:border-b-0">
                <span className={cn('text-sm', last ? 'font-bold text-[var(--text-primary)]' : 'text-[var(--text-secondary)]')}>{l.label}</span>
                <span className="font-mono text-sm font-bold tabular-nums text-[var(--text-primary)]">{aed(l.amount)}</span>
              </div>
            );
          })}
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <p className={cn(SECTION, 'border-b border-[var(--border)] pb-2')}>Posting Details</p>
        <div className={POST_CARD}>
          <div className="mb-3 flex items-center justify-between gap-3 border-b border-dashed border-[var(--border)] pb-3">
            <h3 className="text-sm font-bold text-[var(--text-primary)]">Single core posting — {chargePostings.length} postings</h3>
            <PostingStatus e={e} done={charged} />
          </div>
          {chargePostings.map((p) => (
            <PostingLine key={p.label} posting={p} tagged />
          ))}
          {charged && <PostingFooter reference={`CPT00${seq}01`} at={dateTime(addMinutes(e.rfrInitiatedAt, 10))} onView={view} />}
        </div>

        {refunds.map((r, i) => (
          <div key={r.sl} className={POST_CARD}>
            <div className="mb-3 flex items-center justify-between gap-3">
              <span className={cn(TAG, TAG_TONE.refund)}>Refund {i + 1}</span>
              <PostingStatus e={e} done />
            </div>
            <PostingLine
              tagged={false}
              posting={{
                label: `Refund ${i + 1}`,
                tone: 'refund',
                debit: { account: CB_NOSTRO, label: 'CB Nostro A/c' },
                credit: employer,
                amount: r.amount,
                narration: `Refund credit — ${e.requestRef} (RSU ${i + 1})`,
              }}
            />
            <PostingFooter reference={`CPT00${seq}${20 + i}`} at={dateTime(addMinutes(e.rfrInitiatedAt, 20 + 5 * i))} onView={view} />
          </div>
        ))}
      </section>

      <section>
        <p className={cn(SECTION, 'mb-3 border-b border-[var(--border)] pb-2')}>External Channel Communication</p>
        {sent ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-max text-sm">
              <thead className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]">
                <tr className="border-b border-[var(--border)]">
                  {['Source', 'Action', 'Start DateTime', 'End DateTime', 'Status', 'Direction', 'Req Log', 'Res Log', 'Failure Reason', 'Retry'].map((h) => (
                    <th key={h} className={TH}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {external.map((x) => (
                  <tr key={x.action} className="border-b border-[var(--border)] last:border-b-0">
                    <td className={cn(TD, 'text-sm font-bold text-[var(--text-primary)]')}>Transact Hub</td>
                    <td className={cn(TD, 'text-sm')}>{x.action}</td>
                    <td className={cn(TD, 'font-mono')}>{dateTime(addMinutes(e.rfrInitiatedAt, x.start))}</td>
                    <td className={cn(TD, 'font-mono')}>{dateTime(addMinutes(e.rfrInitiatedAt, x.end))}</td>
                    <td className={TD}>
                      <span className={cn(BADGE, 'success')}>Success</span>
                    </td>
                    <td className={TD}>
                      <span className={cn(BADGE, 'blue')}>↑ OutGoing</span>
                    </td>
                    <td className={TD}>
                      <ViewLog onView={() => view(`${x.action} request log`)} />
                    </td>
                    <td className={TD}>
                      <ViewLog onView={() => view(`${x.action} response log`)} />
                    </td>
                    <td className={cn(TD, 'text-[var(--text-muted)]')}>—</td>
                    <td className={cn(TD, 'tabular-nums')}>0</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-xs text-[var(--text-secondary)]">No external channel communication yet — the RFR has not been sent to the Central Bank.</p>
        )}
      </section>
    </div>
  );
}

export function RfrRefund360Drawer({
  entry,
  onClose,
  onOpenSif360,
  onUnavailable,
}: {
  entry: RfrHistoryEntry;
  onClose: () => void;
  /** Opens the SIF's own 360 from the "SIF 360" link. */
  onOpenSif360: (entry: RfrHistoryEntry) => void;
  onUnavailable: (message: string) => void;
}) {
  const [tab, setTab] = useState<Tab>('summary');
  const e = entry;
  const files = rfrCbFiles(e);
  const settledYet = e.status !== 'Pending' && e.status !== 'CB Pending';
  const download = (name: string) => onUnavailable(`Downloading ${name} is not available on this static screen yet.`);
  const records = rfrRecords(e);
  const period = salaryPeriod(e);

  return (
    <RefundDrawer
      title="Refund 360"
      subtitle={`${e.rfrFileName ?? 'RFR not generated yet'} · ${e.requestRef}`}
      ariaLabel={`Refund 360 — ${e.requestRef}`}
      onClose={onClose}
      tabs={<DrawerTabs tabs={TABS} value={tab} onChange={setTab} />}
    >
      {/* ═══ RFR Summary ═══ */}
      {tab === 'summary' && (
        <div className="flex flex-col gap-6">
          <section>
            <p className={cn(SECTION, 'mb-3 border-b border-[var(--border)] pb-2')}>RFR Details</p>
            <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
              <Row label="RFR File Name" value={e.rfrFileName ?? '—'} mono />
              <Row label="RFR Reference Number" value={e.requestRef} mono />
              <Row label="RFR Initiation Date" value={dateTime(e.rfrInitiatedAt)} mono />
              <Row label="Initiated By" value={e.initiatedBy} />
              <Row label="Employer Name" value={e.employerName} />
              <Row label="Employer ID (MOL ID)" value={e.employerId} mono />
              <Row label="SIF File Name" value={e.sifFileName} mono />
              <Row
                label="SIF Original File Name"
                value={
                  <span className="inline-flex flex-wrap items-center gap-3">
                    <span className="font-mono text-[11px]">{e.originalFileName}</span>
                    <button
                      type="button"
                      onClick={() => onOpenSif360(e)}
                      className="inline-flex items-center gap-0.5 font-mono font-bold text-[var(--accent-green)] hover:underline"
                    >
                      <ArrowUpRight size={13} aria-hidden="true" />
                      SIF 360
                    </button>
                  </span>
                }
              />
              <Row label="System Reference No." value={e.systemRef} mono />
              <Row label="Channel" value={<span className={cn(PILL, CHANNEL_TONE[e.channel])}>{e.channel}</span>} />
              <Row label="Current Status" value={<span className={cn(BADGE, STATUS_MODIFIER[e.status])}>{e.status}</span>} />
              <Row label="Stage" value={stageOf(e)} />
            </dl>
          </section>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Tile label="No. of Records" value={e.records} />
            <Tile label="Accepted" value={settledYet ? e.acceptedCount : '—'} tone="text-[var(--accent-green)]" />
            <Tile label="Rejected" value={settledYet ? e.rejectedCount : '—'} tone="text-[var(--accent-red)]" />
          </div>

          <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
            <Row label="Total Refund Amount" value={aed(e.totalRefund)} mono />
            <Row label="Total Refund Charges" value={aed(e.totalCharges)} mono />
            <Row label="RFR Charge Waived" value={e.chargeWaived ? 'Yes' : 'No'} />
            <Row label="Maker Remarks" value="—" />
          </dl>

          <section>
            <p className={cn(SECTION, 'mb-3 border-b border-[var(--border)] pb-2')}>Central Bank Files</p>
            <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
              <Row label="RFR File" value={files.rfr ? <FileLink name={files.rfr} /> : '—'} />
              <Row label="RFR ACK / NAK" value={files.ack ? <FileLink name={files.ack} /> : '—'} />
              <Row label="RSU File" value={files.rsu ? <FileLink name={files.rsu} /> : '—'} />
              <Row label="Rejection Remarks" value={rejectionRemarks(e)} />
            </dl>
          </section>

          <section>
            <p className={cn(SECTION, 'border-b border-[var(--border)] pb-2')}>Related Messages</p>
            <RelatedMessagesPanel messages={messages(e)} onDownload={download} accent="green" />
          </section>
        </div>
      )}

      {/* ═══ Charges & Posting ═══ */}
      {tab === 'charges' && <ChargesPosting e={e} onUnavailable={onUnavailable} />}

      {/* ═══ Record List ═══ */}
      {tab === 'records' && (
        <SifRecordList
          header={[
            { label: 'Employer Unique ID', value: e.employerId, mono: true },
            { label: 'Employer Name', value: e.employerName, strong: true },
            { label: 'Debit Account Number', value: e.employerAccount, mono: true },
            { label: 'Salary Month-Year', value: salaryMonth(period), mono: true },
          ]}
          records={records}
          period={period}
          settled={settledYet}
        />
      )}
    </RefundDrawer>
  );
}
