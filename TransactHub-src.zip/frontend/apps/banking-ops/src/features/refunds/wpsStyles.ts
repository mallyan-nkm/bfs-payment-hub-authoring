import type { RfrChannel, RfrRecordOutcome, RfrStageTone, RfrStatus, SifPriority } from './wpsData';
import { sessionInstant } from '@paymenthub/ui';

/**
 * Colours and formats the WPS refund History tab and its Refund 360 drawer share. Status badges
 * use the shared `.status-badge`; pills mix theme accents with transparency — both follow every theme.
 */

export const PILL = 'inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold';
export const SMALL_BADGE = 'status-badge inline-block !px-2 !py-0.5 !text-xs font-semibold';
export const CHIP =
  'inline-block whitespace-nowrap rounded-full border border-[var(--border)] bg-[var(--bg-secondary)] px-2.5 py-0.5 text-xs font-semibold text-[var(--text-2)]';
/** Modifiers on the shared `.status-badge` — the app's status style, readable in every theme. */
export const STATUS_MODIFIER: Record<RfrStatus, string> = {
  Pending: 'warn',
  'CB Pending': 'blue',
  ACK: 'success',
  NAK: 'error',
  Rejected: 'error',
};

export const PRIORITY_MODIFIER: Record<SifPriority, string> = { Urgent: 'error', High: 'warn', Normal: '' };

export const OUTCOME_MODIFIER: Record<RfrRecordOutcome, string> = { Accepted: 'success', Rejected: 'error', Pending: 'warn' };

/** Channel pills — theme-token accents mixed with transparency, so they follow every theme. */
export const CHANNEL_TONE: Record<RfrChannel, string> = {
  'Web Portal': 'bg-[color-mix(in_srgb,var(--accent-blue)_14%,transparent)] text-[var(--accent-blue)]',
  IB: 'bg-purple-500/15 text-purple-500',
  CBX: 'bg-[color-mix(in_srgb,var(--accent-green)_14%,transparent)] text-[var(--accent-green)]',
  MB: 'bg-[color-mix(in_srgb,var(--accent-amber)_16%,transparent)] text-[var(--accent-amber)]',
};


/** An instant in the session zone, `dd-MM-yyyy HH:mm:ss` (a zoneless mock value is UTC); a thin delegate. */
export function dateTime(iso: string): string {
  return sessionInstant(iso);
}

export const STAGE_TONE: Record<RfrStageTone, string> = {
  amber: 'bg-[color-mix(in_srgb,var(--accent-amber)_16%,transparent)] text-[var(--accent-amber)]',
  blue: 'bg-[color-mix(in_srgb,var(--accent-blue)_14%,transparent)] text-[var(--accent-blue)]',
  green: 'bg-[color-mix(in_srgb,var(--accent-green)_14%,transparent)] text-[var(--accent-green)]',
  red: 'bg-[color-mix(in_srgb,var(--accent-red)_12%,transparent)] text-[var(--accent-red)]',
};

