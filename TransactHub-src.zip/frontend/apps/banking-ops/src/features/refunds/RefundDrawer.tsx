import { useState } from 'react';
import type { ReactNode } from 'react';
import { Maximize2, Minimize2, X } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { useContentAreaWidth } from '../../shared/hooks/useContentAreaWidth';

/** The shared SideSheet's header icon button. */
const ICON_BUTTON =
  'grid size-9 shrink-0 place-items-center rounded-full text-[var(--text-primary)] transition-colors hover:bg-[var(--border)]';

/**
 * The right-hand drawer frame of the SIF Summary Report's 360 and Audit Trail drawers — header,
 * Maximize / Close, scrolling body and Close footer — sized to the page area beside the sidebar,
 * or the whole viewport while maximized (as the shared SideSheet's Maximize does).
 */
export function RefundDrawer({
  title,
  subtitle,
  eyebrow,
  meta,
  ariaLabel,
  headerActions,
  tabs,
  footerStart,
  footer,
  onClose,
  children,
}: {
  title: string;
  /** Monospace line under the title, e.g. the SIF file name. */
  subtitle?: string;
  /** Small uppercase line above the title, e.g. "RFR-2026-00131 · WPS · EMPLOYER BANK". */
  eyebrow?: string;
  /** A line of chips under the title. */
  meta?: ReactNode;
  ariaLabel: string;
  /** Controls beside the close button. */
  headerActions?: ReactNode;
  /** A tab strip under the header, outside the scrolling body. */
  tabs?: ReactNode;
  /** Left side of the footer, e.g. a count. */
  footerStart?: ReactNode;
  /** Replaces the default footer (count + Close), e.g. with remarks and approval actions. */
  footer?: ReactNode;
  onClose: () => void;
  children: ReactNode;
}) {
  const contentAreaWidth = useContentAreaWidth();
  const [maximized, setMaximized] = useState(false);

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={ariaLabel}
      onClick={onClose}
    >
      <aside
        // As wide as the page area beside the sidebar (tracks it collapsing); the fixed cap is only
        // the fallback until that width is measured. Maximized, it takes the whole viewport.
        className={cn(
          'flex h-full w-full flex-col overflow-hidden border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all',
          maximized ? 'max-w-none' : 'rounded-bl-[40px] rounded-tl-[40px]',
          !maximized && contentAreaWidth === undefined && 'max-w-4xl sm:max-w-5xl',
        )}
        style={maximized || contentAreaWidth === undefined ? undefined : { maxWidth: contentAreaWidth }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-secondary)_50%,transparent)] p-6">
          <div className="min-w-0">
            {eyebrow && <p className="mb-1 truncate text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{eyebrow}</p>}
            <h2 className="text-xl font-bold text-[var(--text-primary)]">{title}</h2>
            {subtitle && <p className="mt-1 truncate font-mono text-xs text-[var(--text-muted)]">{subtitle}</p>}
            {meta && <div className="mt-2 flex flex-wrap items-center gap-2">{meta}</div>}
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {headerActions}
            {/* Maximize / Close — the same controls, styling and labels as the shared SideSheet's. */}
            <button
              type="button"
              onClick={() => setMaximized((m) => !m)}
              aria-label={maximized ? 'Restore' : 'Maximize'}
              title={maximized ? 'Restore' : 'Maximize'}
              className={ICON_BUTTON}
            >
              {maximized ? <Minimize2 size={18} strokeWidth={2.5} aria-hidden="true" /> : <Maximize2 size={18} strokeWidth={2.5} aria-hidden="true" />}
            </button>
            <button type="button" onClick={onClose} aria-label="Close drawer" className={ICON_BUTTON}>
              <X size={18} strokeWidth={2.5} aria-hidden="true" />
            </button>
          </div>
        </div>

        {tabs}

        <div className="flex-1 overflow-y-auto p-6">{children}</div>

        {footer ?? (
          <div className="flex items-center justify-between gap-3 border-t border-[var(--border)] bg-[var(--bg-card)] p-6">
            <span className="text-xs text-[var(--text-muted)]">{footerStart}</span>
            <button type="button" onClick={onClose} className="btn-secondary large-btn !w-32 justify-center">
              Close
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
