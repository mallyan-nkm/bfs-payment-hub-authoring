import { useMemo, useState } from 'react';
import { cn } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { formatDate } from '../../shared/utils/formatDate';
import { CHANNELS, SETTLED_TRANSACTIONS, formatAmount } from './data';
import type { RefundRail, RefundRailTone, RefundRecord, SettledTransaction } from './data';
import { RefundSelectionGrid, mutedFor, parseAmount } from './RefundSelectionGrid';

interface Filters {
  txnRef: string;
  e2eId: string;
  debtor: string;
  amount: string;
  from: string;
  to: string;
  channel: string;
}

/** The search opens on the current settlement month, as the design does. */
const DEFAULT_FILTERS: Filters = { txnRef: '', e2eId: '', debtor: '', amount: '', from: '2026-09-01', to: '2026-09-30', channel: '' };

/** The rail's tag beside the search title — theme-token accents. */
export const RAIL_TONE: Record<RefundRailTone, string> = {
  blue: 'bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] text-[var(--accent-blue)]',
  purple: 'bg-purple-500/15 text-purple-600',
  amber: 'bg-[color-mix(in_srgb,var(--accent-amber)_15%,transparent)] text-[var(--accent-amber)]',
  orange: 'bg-orange-500/15 text-orange-600',
  green: 'bg-[color-mix(in_srgb,var(--accent-green)_15%,transparent)] text-[var(--accent-green)]',
};

/** Two-line cell: a name over a monospace account number. */
function NameAccount({ name, account }: { name: string; account: string }) {
  return (
    <div>
      <p>{name}</p>
      <p className="font-mono text-xs opacity-70">{account}</p>
    </div>
  );
}

/** What a settled transaction is — the columns before the shared refund ones. */
function transactionColumns(rail: RefundRail): SmartGridColumn<SettledTransaction>[] {
  return [
    {
      key: 'txnRef',
      label: 'Original Txn / File Ref.',
      sortKey: 'txnRef',
      getValue: (t) => t.txnRef,
      render: (t) => <span className={cn('font-bold', mutedFor(t))}>{t.txnRef}</span>,
    },
    {
      key: 'e2eId',
      label: `Network / Scheme Ref. (${rail.schemeRefLabel})`,
      getValue: (t) => t.e2eId,
      render: (t) => <span className={cn('font-mono text-xs', mutedFor(t))}>{t.e2eId}</span>,
    },
    {
      key: 'valueDate',
      label: 'Value Date',
      sortKey: 'valueDate',
      getValue: (t) => formatDate(t.valueDate),
      getSortValue: (t) => t.valueDate,
      render: (t) => <span className={mutedFor(t)}>{formatDate(t.valueDate)}</span>,
    },
    {
      key: 'debtor',
      label: 'Debtor Name / Account',
      getValue: (t) => `${t.debtorName} ${t.debtorAccount}`,
      render: (t) => (
        <div className={mutedFor(t)}>
          <NameAccount name={t.debtorName} account={t.debtorAccount} />
        </div>
      ),
    },
    {
      key: 'creditor',
      label: 'Creditor Name / Account',
      getValue: (t) => `${t.creditorName} ${t.creditorAccount}`,
      render: (t) => (
        <div className={mutedFor(t)}>
          <NameAccount name={t.creditorName} account={t.creditorAccount} />
        </div>
      ),
    },
    {
      key: 'creditorBank',
      label: 'Creditor Bank',
      sortKey: 'creditorBank',
      getValue: (t) => t.creditorBank,
      render: (t) => <span className={mutedFor(t)}>{t.creditorBank}</span>,
    },
    {
      key: 'records',
      label: 'No. of Records',
      numeric: true,
      getValue: (t) => String(t.records),
      render: (t) => <span className={mutedFor(t) ?? 'text-[var(--primary-blue)]'}>{t.records}</span>,
    },
    {
      key: 'originalAmount',
      label: 'Original Amount (AED)',
      numeric: true,
      sortKey: 'originalAmount',
      getValue: (t) => formatAmount(t.originalAmount),
      getSortValue: (t) => t.originalAmount,
      render: (t) => <span className={mutedFor(t)}>{formatAmount(t.originalAmount)}</span>,
    },
  ];
}

/** Matches a transaction against the search panel. */
function matches(t: SettledTransaction, f: Filters): boolean {
  const has = (value: string, q: string) => value.toLowerCase().includes(q.trim().toLowerCase());
  const amount = parseAmount(f.amount);
  return (
    (!f.txnRef.trim() || has(t.txnRef, f.txnRef)) &&
    (!f.e2eId.trim() || has(t.e2eId, f.e2eId)) &&
    (!f.debtor.trim() || has(t.debtorName, f.debtor) || has(t.debtorAccount, f.debtor)) &&
    (!Number.isFinite(amount) || t.originalAmount === amount) &&
    (!f.from || t.valueDate >= f.from) &&
    (!f.to || t.valueDate <= f.to) &&
    (!f.channel || t.channel === f.channel)
  );
}

const LABEL = 'mb-1.5 block text-sm font-medium text-[var(--text-primary)]';

/**
 * A transaction rail's refund flow (IPI, UAEFTS, IPP): search its settled outward transactions,
 * then tick the ones to refund in the shared selection grid.
 */
export function RailRefundPanel({
  rail,
  onNext,
}: {
  rail: RefundRail;
  /** Called by Next once every selected row has a valid amount and reason. */
  onNext: (records: RefundRecord[]) => void;
}) {
  const all = SETTLED_TRANSACTIONS[rail.code];
  const [input, setInput] = useState<Filters>(DEFAULT_FILTERS);
  const [applied, setApplied] = useState<Filters>(DEFAULT_FILTERS);

  const rows = useMemo(() => all.filter((t) => matches(t, applied)), [all, applied]);
  const columns = useMemo(() => transactionColumns(rail), [rail]);

  function setFilter<K extends keyof Filters>(key: K, value: Filters[K]) {
    setInput((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <>
      {/* Search */}
      <section className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 shadow-[var(--shadow-sm)]">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h2 className="flex items-center gap-2 text-[15px] font-bold text-[var(--text-primary)]">
            Search Processed Transactions
            <span className={cn('rounded-md px-2 py-0.5 text-xs font-bold', RAIL_TONE[rail.tone])}>{rail.label}</span>
          </h2>
          <p className="text-xs text-[var(--text-muted)]">Only successfully settled outward transactions are listed</p>
        </div>
        <div className="grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label htmlFor="rf-ref" className={LABEL}>
              System Reference No.
            </label>
            <input
              id="rf-ref"
              value={input.txnRef}
              onChange={(e) => setFilter('txnRef', e.target.value)}
              placeholder={`e.g. ${all[0]?.txnRef ?? ''}`}
              className="input-cls h-10 w-full text-sm"
            />
          </div>
          <div>
            <label htmlFor="rf-e2e" className={LABEL}>
              {rail.schemeRefLabel}
            </label>
            <input id="rf-e2e" value={input.e2eId} onChange={(e) => setFilter('e2eId', e.target.value)} className="input-cls h-10 w-full text-sm" />
          </div>
          <div>
            <label htmlFor="rf-debtor" className={LABEL}>
              Debtor Account / Name
            </label>
            <input
              id="rf-debtor"
              value={input.debtor}
              onChange={(e) => setFilter('debtor', e.target.value)}
              placeholder="Account number or name"
              className="input-cls h-10 w-full text-sm"
            />
          </div>
          <div>
            <label htmlFor="rf-amount" className={LABEL}>
              Amount (AED)
            </label>
            <input
              id="rf-amount"
              value={input.amount}
              onChange={(e) => setFilter('amount', e.target.value)}
              placeholder="Exact amount"
              inputMode="decimal"
              className="input-cls h-10 w-full text-sm"
            />
          </div>
          <div>
            <label htmlFor="rf-from" className={LABEL}>
              From Date
            </label>
            <input
              id="rf-from"
              type="date"
              value={input.from}
              max={input.to || undefined}
              onChange={(e) => setFilter('from', e.target.value)}
              className="input-cls d-block h-10 w-full text-sm"
            />
          </div>
          <div>
            <label htmlFor="rf-to" className={LABEL}>
              To Date
            </label>
            <input
              id="rf-to"
              type="date"
              value={input.to}
              min={input.from || undefined}
              onChange={(e) => setFilter('to', e.target.value)}
              className="input-cls d-block h-10 w-full text-sm"
            />
          </div>
          <div>
            <label htmlFor="rf-channel" className={LABEL}>
              Channel
            </label>
            <select id="rf-channel" value={input.channel} onChange={(e) => setFilter('channel', e.target.value)} className="input-cls h-10 w-full text-sm">
              <option value="">All</option>
              {CHANNELS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-end justify-end gap-3">
            <button
              type="button"
              onClick={() => {
                setInput(DEFAULT_FILTERS);
                setApplied(DEFAULT_FILTERS);
              }}
              className="btn-secondary large-btn justify-center !py-2.5 text-sm"
            >
              Clear
            </button>
            <button type="button" onClick={() => setApplied(input)} className="btn-primary large-btn justify-center !py-2.5 text-sm">
              Search
            </button>
          </div>
        </div>
      </section>

      <RefundSelectionGrid<SettledTransaction>
        rows={rows}
        leadingColumns={columns}
        title="Settled Transactions — select transactions to refund"
        note="Refund Reason is mandatory for each selected transaction"
        noun="transactions"
        storageKey={`refund-initiation-${rail.code.toLowerCase()}-columns-v1`}
        exportFilename={`refund-${rail.code.toLowerCase()}-settled-transactions`}
        emptyTitle="No settled transactions found"
        emptyMessage="No settled outward transactions match the search. Widen the date range or clear the search."
        onNext={onNext}
      />
    </>
  );
}
