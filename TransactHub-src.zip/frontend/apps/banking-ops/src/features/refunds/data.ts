/**
 * Static configuration and seed data for Refund Initiation — this screen has no backend yet.
 *
 * To add a rail: add an entry to `REFUND_RAILS`. `code` is the rail code the shared rail-access
 * check understands (the same codes New Payment uses), so a rail the session can't use shows as
 * "No Access" without further wiring. Its settled transactions come from `SETTLED_TRANSACTIONS`.
 */

export type RefundRailCode = 'IPI' | 'UAEFTS' | 'WPS' | 'IPP';

/** Icon name per rail; the page maps it to a lucide icon and a theme-token colour. */
export type RefundRailIcon = 'instant' | 'interbank' | 'salary' | 'card';

/** Colour of the rail's tag beside "Search Processed Transactions" — a theme-token accent. */
export type RefundRailTone = 'blue' | 'purple' | 'amber' | 'orange' | 'green';

export interface RefundRail {
  code: RefundRailCode;
  label: string;
  description: string;
  icon: RefundRailIcon;
  /** False shows the tile as "Coming Soon" and not selectable. */
  enabled: boolean;
  /** What this rail's network / scheme reference is called — a search field and a grid column. */
  schemeRefLabel: string;
  tone: RefundRailTone;
}

export const REFUND_RAILS: RefundRail[] = [
  { code: 'IPI', label: 'IPI', description: 'Real-time AED', icon: 'instant', enabled: true, schemeRefLabel: 'End-to-End ID', tone: 'blue' },
  {
    code: 'UAEFTS',
    label: 'UAEFTS',
    description: 'AED interbank',
    icon: 'interbank',
    enabled: true,
    schemeRefLabel: 'UETR / MT103 Ref',
    tone: 'purple',
  },
  { code: 'WPS', label: 'WPS', description: 'MOL salary', icon: 'salary', enabled: true, schemeRefLabel: 'End-to-End ID', tone: 'amber' },
  { code: 'IPP', label: 'IPP', description: 'Card & merchant', icon: 'card', enabled: true, schemeRefLabel: 'Transaction ID', tone: 'orange' },
];

export const CHANNELS = ['Internet Banking', 'Mobile Banking', 'Branch', 'Host-to-Host'];

/** Refund (recall) reasons with their ISO 20022 camt.056 reason codes. */
export const REFUND_REASONS: { code: string; label: string }[] = [
  { code: 'DUPL', label: 'Duplicate payment' },
  { code: 'AM09', label: 'Wrong amount' },
  { code: 'AC03', label: 'Invalid creditor account' },
  { code: 'CUST', label: 'Requested by customer' },
  { code: 'UPAY', label: 'Undue payment' },
  { code: 'FRAD', label: 'Fraudulent origin' },
];

/** `DUPL` → `DUPL — Duplicate payment`. */
export function reasonText(code: string): string {
  const r = REFUND_REASONS.find((x) => x.code === code);
  return r ? `${r.code} — ${r.label}` : code;
}

/** The recall message pair a refund is sent as. */
export const RECALL_MESSAGE = 'camt.056 → pacs.004';

/**
 * Refund charges, as Charge Configuration would supply them. Charges are debited from the
 * original debtor's account; VAT applies to the charges, not the refund.
 */
export const REFUND_CHARGES = { perRecord: 25, cbPerRecord: 2, vatRate: 0.05 };

/** GL accounts each charge posting credits, as GL mapping would supply them. */
export const CHARGE_POSTING_GL = {
  perRecord: 'Refund Charge Income GL',
  cb: 'CB Charge Payable GL',
  vat: 'VAT Payable GL',
};

/** One selected transaction as step 2 receives it: how much to refund and why. */
export interface RefundRecord {
  txn: SettledTransaction;
  amount: number;
  /** Reason code, e.g. DUPL. */
  reason: string;
}

/** One earlier refund against a transaction, shown by its History link. */
export interface RefundHistoryItem {
  ref: string;
  at: string;
  amount: number;
  reason: string;
  status: 'Completed' | 'In Progress' | 'Rejected';
}

/** A settled outward transaction that can be refunded. Amounts are AED. */
export interface SettledTransaction {
  id: string;
  rail: RefundRailCode;
  /** Original transaction or file reference, e.g. IPI-2026-00415. */
  txnRef: string;
  /** Network / scheme reference (End-to-End ID). */
  e2eId: string;
  valueDate: string;
  debtorName: string;
  debtorAccount: string;
  creditorName: string;
  creditorAccount: string;
  creditorBank: string;
  channel: string;
  records: number;
  originalAmount: number;
  /** Sum of completed refunds so far. */
  refundedAmount: number;
  /** Earlier refunds, completed or not. An In Progress one blocks a new refund. */
  history: RefundHistoryItem[];
}

export type RefundStatus = 'Not Refunded' | 'Partially refunded' | 'Fully refunded' | 'Refund in progress';

/** The refund still running against a transaction, if any — it blocks a new refund until it completes. */
export function inProgressRefund(t: SettledTransaction): RefundHistoryItem | undefined {
  return t.history.find((h) => h.status === 'In Progress');
}

export function refundStatus(t: SettledTransaction): RefundStatus {
  if (inProgressRefund(t)) return 'Refund in progress';
  if (t.refundedAmount >= t.originalAmount) return 'Fully refunded';
  if (t.refundedAmount > 0) return 'Partially refunded';
  return 'Not Refunded';
}

/** What is left to refund. */
export function balanceOf(t: SettledTransaction): number {
  return Math.max(0, t.originalAmount - t.refundedAmount);
}

/** A transaction can be picked for a new refund only with a balance left and no refund in progress. */
export function isRefundable(t: SettledTransaction): boolean {
  return !inProgressRefund(t) && balanceOf(t) > 0;
}

/** `310000` → `310,000.00`. */
export function formatAmount(n: number): string {
  return n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** The same four sample shapes on every rail, with that rail's references. */
function sample(rail: RefundRailCode, seq: number): SettledTransaction[] {
  const ref = (n: number) => `${rail}-2026-${String(n).padStart(5, '0')}`;
  const e2e = (date: string, n: number) => `E2E-DIB-${date}-${String(n).padStart(6, '0')}`;
  return [
    {
      id: `${rail}-1`,
      rail,
      txnRef: ref(seq),
      e2eId: e2e('20260924', seq),
      valueDate: '2026-09-24',
      debtorName: `${rail} Dubai Properties`,
      debtorAccount: 'AE980330000099887',
      creditorName: 'Nasser Al Mansoori',
      creditorAccount: 'AE180200000445566',
      creditorBank: 'Dubai Islamic Bank',
      channel: 'Internet Banking',
      records: 1,
      originalAmount: 310000,
      refundedAmount: 0,
      history: [],
    },
    {
      id: `${rail}-2`,
      rail,
      txnRef: ref(seq - 6),
      e2eId: e2e('20260923', seq - 6),
      valueDate: '2026-09-23',
      debtorName: 'Gulf Trading LLC',
      debtorAccount: 'AE120330000011234',
      creditorName: 'Ahmed Al Suwaidi',
      creditorAccount: 'AE450260000778899',
      creditorBank: 'Emirates NBD',
      channel: 'Mobile Banking',
      records: 1,
      originalAmount: 12500,
      refundedAmount: 0,
      history: [],
    },
    {
      id: `${rail}-3`,
      rail,
      txnRef: ref(seq - 14),
      e2eId: e2e('20260922', seq - 14),
      valueDate: '2026-09-22',
      debtorName: 'Blue Ocean FZE',
      debtorAccount: 'AE330330000055667',
      creditorName: 'Maria Santos',
      creditorAccount: 'AE670350000112233',
      creditorBank: 'Mashreq Bank',
      channel: 'Branch',
      records: 1,
      originalAmount: 4750,
      refundedAmount: 0,
      history: [
        { ref: 'RFD-2026-00241', at: '2026-09-25T10:20:00', amount: 4750, reason: 'Incorrect beneficiary', status: 'In Progress' },
      ],
    },
    {
      id: `${rail}-4`,
      rail,
      txnRef: ref(seq - 17),
      e2eId: e2e('20260921', seq - 17),
      valueDate: '2026-09-21',
      debtorName: 'Gulf Trading LLC',
      debtorAccount: 'AE120330000011234',
      creditorName: 'Khalid Traders',
      creditorAccount: 'AE210330000998877',
      creditorBank: 'ADCB',
      channel: 'Host-to-Host',
      records: 1,
      originalAmount: 88000,
      refundedAmount: 8000,
      history: [
        { ref: 'RFD-2026-00198', at: '2026-09-22T14:05:00', amount: 8000, reason: 'Incorrect amount', status: 'Completed' },
      ],
    },
  ];
}

/** UAEFTS settles over MT103, so its references are FTS-… and MT103-…; one is already fully refunded. */
const UAEFTS_TRANSACTIONS: SettledTransaction[] = [
  {
    id: 'UAEFTS-1',
    rail: 'UAEFTS',
    txnRef: 'FTS-2026-00408',
    e2eId: 'MT103-DIBUAEAD-00408',
    valueDate: '2026-09-24',
    debtorName: 'Emaar Properties',
    debtorAccount: 'AE380330000077654',
    creditorName: 'Hind Al Marzouqi',
    creditorAccount: 'AE310020000567890',
    creditorBank: 'RAK Bank',
    channel: 'Internet Banking',
    records: 1,
    originalAmount: 750000,
    refundedAmount: 0,
    history: [],
  },
  {
    id: 'UAEFTS-2',
    rail: 'UAEFTS',
    txnRef: 'FTS-2026-00395',
    e2eId: 'MT103-DIBUAEAD-00395',
    valueDate: '2026-09-22',
    debtorName: 'Al Ghurair Foods',
    debtorAccount: 'AE520330000033445',
    creditorName: 'Star Packaging LLC',
    creditorAccount: 'AE880230000445566',
    creditorBank: 'CBD',
    channel: 'Host-to-Host',
    records: 1,
    originalAmount: 126400,
    refundedAmount: 0,
    history: [],
  },
  {
    id: 'UAEFTS-3',
    rail: 'UAEFTS',
    txnRef: 'FTS-2026-00390',
    e2eId: 'MT103-DIBUAEAD-00390',
    valueDate: '2026-09-21',
    debtorName: 'Emaar Properties',
    debtorAccount: 'AE380330000077654',
    creditorName: 'City Contracting',
    creditorAccount: 'AE140400000887766',
    creditorBank: 'FAB',
    channel: 'Internet Banking',
    records: 1,
    originalAmount: 54200,
    refundedAmount: 54200,
    history: [
      { ref: 'RFD-2026-00187', at: '2026-09-22T11:30:00', amount: 54200, reason: 'Duplicate payment', status: 'Completed' },
    ],
  },
];

/** IPP references its payments by an IPP transaction ID. */
const IPP_TRANSACTIONS: SettledTransaction[] = [
  {
    id: 'IPP-1',
    rail: 'IPP',
    txnRef: 'IPP-2026-00401',
    e2eId: 'IPP-TXN-88230401',
    valueDate: '2026-09-24',
    debtorName: 'Majid Al Futtaim',
    debtorAccount: 'AE120330000088432',
    creditorName: 'Laila Al Hashimi',
    creditorAccount: 'AE830090001122334',
    creditorBank: 'Commercial Bank of Dubai',
    channel: 'Mobile Banking',
    records: 1,
    originalAmount: 55000,
    refundedAmount: 0,
    history: [],
  },
  {
    id: 'IPP-2',
    rail: 'IPP',
    txnRef: 'IPP-2026-00397',
    e2eId: 'IPP-TXN-88230397',
    valueDate: '2026-09-23',
    debtorName: 'Carrefour UAE',
    debtorAccount: 'AE660330000044321',
    creditorName: 'Omar Farouk',
    creditorAccount: 'AE770260000334455',
    creditorBank: 'Emirates NBD',
    channel: 'Internet Banking',
    records: 1,
    originalAmount: 1850,
    refundedAmount: 0,
    history: [],
  },
];

/** Settled outward transactions per rail. */
export const SETTLED_TRANSACTIONS: Record<RefundRailCode, SettledTransaction[]> = {
  IPI: sample('IPI', 415),
  UAEFTS: UAEFTS_TRANSACTIONS,
  WPS: sample('WPS', 120),
  IPP: IPP_TRANSACTIONS,
};
