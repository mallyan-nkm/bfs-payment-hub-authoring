import { useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode, RefObject } from 'react';
import { ArrowRight } from 'lucide-react';
import { SmartGrid, cn } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { REFUND_REASONS, balanceOf, formatAmount, inProgressRefund, isRefundable, refundStatus } from './data';
import type { RefundRecord, RefundStatus, SettledTransaction } from './data';
import { RefundHistorySheet } from './RefundHistorySheet';

/** `"310,000.00"` → `310000`; anything unparseable → NaN. */
export function parseAmount(text: string): number {
  const cleaned = text.replace(/,/g, '').trim();
  return cleaned === '' ? Number.NaN : Number(cleaned);
}

/** Modifier on the shared `.status-badge` (sass/_typography.scss) — the Department listing's status style. */
const STATUS_MODIFIER: Record<RefundStatus, string> = {
  'Not Refunded': '',
  'Refund in progress': 'warn',
  'Partially refunded': 'blue',
  'Fully refunded': 'success',
};

/**
 * Handlers and live edit state behind a ref: SmartGrid snapshots column definitions on first
 * mount, so the cell renderers read today's values through it.
 */
interface GridView {
  selected: Set<string>;
  amounts: Record<string, string>;
  reasons: Record<string, string>;
  /** Show required-field errors on selected rows — set once Next is tried. */
  showErrors: boolean;
  setAmount: (id: string, text: string) => void;
  setReason: (id: string, reason: string) => void;
  onHistory: (txn: SettledTransaction) => void;
}

/** The refund amount a row will use: the edited text, else its full balance. */
function amountText(view: GridView, t: SettledTransaction): string {
  return view.amounts[t.id] ?? formatAmount(balanceOf(t));
}

/** Why a selected row can't be submitted yet, per field. */
function rowErrors(view: GridView, t: SettledTransaction): { amount?: string; reason?: string } {
  const amount = parseAmount(amountText(view, t));
  const errors: { amount?: string; reason?: string } = {};
  if (!Number.isFinite(amount) || amount <= 0) errors.amount = 'Enter an amount';
  else if (amount > balanceOf(t)) errors.amount = `Max AED ${formatAmount(balanceOf(t))}`;
  if (!view.reasons[t.id]) errors.reason = 'Select a reason';
  return errors;
}

/** Muted text for a row that can't be refunded — a refund in progress, or nothing left to refund. */
export function mutedFor(t: SettledTransaction): string | undefined {
  return isRefundable(t) ? undefined : 'text-[var(--text-muted)]';
}

/** The refund columns every list shares: refunded so far, the refund amount and reason, the status. */
function refundColumns<T extends SettledTransaction>(view: RefObject<GridView>): SmartGridColumn<T>[] {
  return [
    {
      key: 'refundedAmount',
      label: 'Total Refunded Amount (AED)',
      numeric: true,
      getValue: (t) => formatAmount(t.refundedAmount),
      render: (t) => (
        <div className="flex flex-col items-end">
          <span className={mutedFor(t)}>{formatAmount(t.refundedAmount)}</span>
          {t.history.length > 0 && (
            <button
              type="button"
              onClick={() => view.current.onHistory(t)}
              className="text-xs font-medium text-[var(--text-link)] hover:underline"
            >
              History ({t.history.length})
            </button>
          )}
        </div>
      ),
    },
    {
      key: 'refundAmount',
      label: 'Refund Amount (AED) *',
      align: 'right',
      getValue: (t) => (isRefundable(t) ? amountText(view.current, t) : ''),
      render: (t) => {
        const refundable = isRefundable(t);
        const error = view.current.selected.has(t.id) ? rowErrors(view.current, t).amount : undefined;
        return (
          <div className="flex flex-col items-end">
            <input
              value={refundable ? amountText(view.current, t) : ''}
              disabled={!refundable}
              inputMode="decimal"
              aria-label={`Refund amount for ${t.txnRef}`}
              aria-invalid={Boolean(error)}
              onChange={(e) => view.current.setAmount(t.id, e.target.value)}
              onBlur={(e) => {
                const n = parseAmount(e.target.value);
                if (Number.isFinite(n)) view.current.setAmount(t.id, formatAmount(n));
              }}
              className={cn(
                'input-cls h-10 !w-40 text-right text-sm tabular-nums disabled:opacity-60',
                error && '!border-[var(--accent-red)]',
              )}
            />
            {error ? (
              <span className="mt-1 text-[11px] text-[var(--accent-red)]">{error}</span>
            ) : (
              refundable &&
              t.refundedAmount > 0 && (
                <span className="mt-1 text-xs text-[var(--text-muted)]">
                  Balance AED {formatAmount(balanceOf(t))} of {formatAmount(t.originalAmount)}
                </span>
              )
            )}
          </div>
        );
      },
    },
    {
      key: 'refundReason',
      label: 'Refund Reason *',
      getValue: (t) => view.current.reasons[t.id] ?? '',
      render: (t) => {
        const refundable = isRefundable(t);
        const error =
          view.current.showErrors && view.current.selected.has(t.id) ? rowErrors(view.current, t).reason : undefined;
        return (
          <div>
            <select
              value={view.current.reasons[t.id] ?? ''}
              disabled={!refundable}
              aria-label={`Refund reason for ${t.txnRef}`}
              aria-invalid={Boolean(error)}
              onChange={(e) => view.current.setReason(t.id, e.target.value)}
              className={cn('input-cls h-10 !w-56 text-sm disabled:opacity-60', error && '!border-[var(--accent-red)]')}
            >
              <option value="">— Select —</option>
              {REFUND_REASONS.map((r) => (
                <option key={r.code} value={r.code}>
                  {r.code} — {r.label}
                </option>
              ))}
            </select>
            {error && <p className="mt-1 text-[11px] text-[var(--accent-red)]">{error}</p>}
          </div>
        );
      },
    },
    {
      key: 'refundStatus',
      label: 'Refund Status',
      getValue: (t) => refundStatus(t),
      render: (t) => {
        const status = refundStatus(t);
        const running = inProgressRefund(t);
        return (
          <div>
            <span className={cn('status-badge inline-block', STATUS_MODIFIER[status])}>{status}</span>
            {running && (
              <p className="mt-1 whitespace-nowrap text-xs text-[var(--text-muted)]">
                AED {formatAmount(running.amount)} · {running.ref} — new refund not allowed
              </p>
            )}
          </div>
        );
      },
    },
  ];
}

/**
 * The refund selection list every rail shares: the caller's own leading columns (what the row
 * is), then the refund columns, with checkboxes, a refund amount (defaulting to the balance) and
 * reason per row, and the selection strip — shown while anything is ticked — that totals the
 * selection, can apply one reason to all of it, and hands it on with Next.
 *
 * Rows that can't be refunded (a refund in progress, or nothing left) can't be ticked.
 */
export function RefundSelectionGrid<T extends SettledTransaction>({
  rows,
  leadingColumns,
  title,
  note,
  noun,
  storageKey,
  exportFilename,
  emptyTitle,
  emptyMessage,
  onNext,
}: {
  rows: T[];
  /** The columns before the refund ones. Read once, like any SmartGrid column set. */
  leadingColumns: SmartGridColumn<T>[];
  title: ReactNode;
  note: ReactNode;
  /** What one row is called in the strip and messages, plural — e.g. "transactions", "records". */
  noun: string;
  storageKey: string;
  exportFilename: string;
  emptyTitle: string;
  emptyMessage: string;
  /** Called by Next once every selected row has a valid amount and reason. */
  onNext: (records: RefundRecord[]) => void;
}) {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [amounts, setAmounts] = useState<Record<string, string>>({});
  const [reasons, setReasons] = useState<Record<string, string>>({});
  const [commonReason, setCommonReason] = useState('');
  const [applyToAll, setApplyToAll] = useState(false);
  const [showErrors, setShowErrors] = useState(false);
  const [historyTxn, setHistoryTxn] = useState<SettledTransaction | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);

  // A new search can drop rows that were ticked; the selection follows what is listed.
  useEffect(() => {
    const listed = new Set(rows.map((r) => r.id));
    setSelected((prev) => {
      const kept = [...prev].filter((id) => listed.has(id));
      return kept.length === prev.size ? prev : new Set(kept);
    });
  }, [rows]);

  const gridView = useRef<GridView>({
    selected,
    amounts,
    reasons,
    showErrors,
    setAmount: (id, text) => setAmounts((prev) => ({ ...prev, [id]: text })),
    setReason: (id, reason) => setReasons((prev) => ({ ...prev, [id]: reason })),
    onHistory: setHistoryTxn,
  });
  Object.assign(gridView.current, { selected, amounts, reasons, showErrors });

  // Built once: SmartGrid never re-reads column definitions, and the closures read through the ref.
  // `leadingColumns` is read once on purpose, for the same reason.
  const columns = useMemo(() => [...leadingColumns, ...refundColumns<T>(gridView)], []);

  const selectedRows = rows.filter((t) => selected.has(t.id));
  const total = selectedRows.reduce((sum, t) => {
    const n = parseAmount(amountText(gridView.current, t));
    return sum + (Number.isFinite(n) ? n : 0);
  }, 0);

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else {
        next.add(id);
        // A row ticked while "apply to all" is on takes the common reason too.
        if (applyToAll && commonReason) setReasons((r) => ({ ...r, [id]: commonReason }));
      }
      return next;
    });
  }

  function applyCommon(reason: string, on: boolean) {
    setCommonReason(reason);
    setApplyToAll(on);
    if (on && reason) setReasons((prev) => ({ ...prev, ...Object.fromEntries([...selected].map((id) => [id, reason])) }));
  }

  function closeStrip() {
    setSelected(new Set());
    setShowErrors(false);
  }

  function next() {
    const invalid = selectedRows.filter((t) => Object.keys(rowErrors(gridView.current, t)).length > 0);
    if (invalid.length > 0) {
      setShowErrors(true);
      setToast({ tone: 'error', message: `Complete the refund amount and reason for ${invalid.length} selected ${noun}.` });
      return;
    }
    setShowErrors(false);
    onNext(
      selectedRows.map((t) => ({
        txn: t,
        amount: parseAmount(amountText(gridView.current, t)),
        reason: gridView.current.reasons[t.id],
      })),
    );
  }

  return (
    <>
      <SmartGrid<T>
        columns={columns}
        rows={rows}
        getRowId={(t) => t.id}
        storageKey={storageKey}
        emptyTitle={emptyTitle}
        emptyMessage={emptyMessage}
        exportFilename={exportFilename}
        exportFormats={['csv']}
        selectable
        selectedIds={selected}
        onToggleSelect={toggle}
        // A refund in progress (or nothing left to refund) blocks a new refund until it completes.
        isRowSelectable={isRefundable}
        toolbarTop={
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-[15px] font-bold text-[var(--text-primary)]">{title}</h2>
            <p className="text-xs text-[var(--text-muted)]">{note}</p>
          </div>
        }
      />

      {/* Selection strip — only while something is selected. A card like the panels above it, with a
          shadow along its top edge only, so it stands out over the grid scrolling beneath it. */}
      {selected.size > 0 && (
        <div
          role="region"
          aria-label="Selected refunds"
          className="sticky bottom-3 z-20 flex flex-wrap items-center gap-x-8 gap-y-3 rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 text-[var(--text-primary)] shadow-[0_-8px_24px_-6px_rgba(15,23,42,0.22)]"
        >
          <div>
            <p className="text-xs opacity-75">Selected</p>
            <p className="text-sm">
              <strong className="text-base">{selected.size}</strong> {noun}
            </p>
          </div>
          <div>
            <p className="text-xs opacity-75">Total Refund</p>
            <p className="text-base font-bold tabular-nums">AED {formatAmount(total)}</p>
          </div>
          <div className="min-w-[14rem]">
            <label htmlFor="rf-common-reason" className="text-xs opacity-75">
              Common Refund Reason
            </label>
            <select
              id="rf-common-reason"
              value={commonReason}
              onChange={(e) => applyCommon(e.target.value, applyToAll)}
              className="input-cls mt-1 h-10 w-full text-sm"
            >
              <option value="">— Select —</option>
              {REFUND_REASONS.map((r) => (
                <option key={r.code} value={r.code}>
                  {r.code} — {r.label}
                </option>
              ))}
            </select>
          </div>
          <label className="flex cursor-pointer items-center gap-2 self-end pb-2.5 text-sm">
            <input
              type="checkbox"
              checked={applyToAll}
              onChange={(e) => applyCommon(commonReason, e.target.checked)}
              className="size-4"
            />
            Apply to all selected records
          </label>
          <div className="ml-auto flex gap-3">
            <button type="button" onClick={closeStrip} className="btn-tertiary large-btn justify-center !py-2.5 text-sm">
              Close
            </button>
            <button type="button" onClick={next} className="btn-secondary large-btn justify-center !py-2.5 text-sm">
              Next
              <ArrowRight size={15} aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      {historyTxn && <RefundHistorySheet txn={historyTxn} onClose={() => setHistoryTxn(null)} />}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </>
  );
}
