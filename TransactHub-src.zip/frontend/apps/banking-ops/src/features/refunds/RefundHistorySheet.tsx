import { cn } from '@paymenthub/ui';
import { SideSheet } from '../../shared/components/SideSheet';
import { formatDateTime } from '../../shared/utils/formatDate';
import { formatAmount } from './data';
import type { RefundHistoryItem, SettledTransaction } from './data';

const STATUS_MODIFIER: Record<RefundHistoryItem['status'], string> = {
  Completed: 'success',
  'In Progress': 'warn',
  Rejected: 'error',
};

/** Refund History — every earlier refund against one transaction, newest first. */
export function RefundHistorySheet({ txn, onClose }: { txn: SettledTransaction; onClose: () => void }) {
  const items = [...txn.history].sort((a, b) => b.at.localeCompare(a.at));

  return (
    <SideSheet
      maximizable
      eyebrow="Refund History"
      title={txn.txnRef}
      subtitle={`Original amount AED ${formatAmount(txn.originalAmount)} · refunded AED ${formatAmount(txn.refundedAmount)}`}
      onClose={onClose}
      footer={
        <div className="flex w-full justify-end">
          <button type="button" onClick={onClose} className="btn-secondary large-btn justify-center !py-2.5 text-sm">
            Close
          </button>
        </div>
      }
    >
      <div className="table-holder overflow-x-auto rounded-lg border border-[var(--border)]">
        <table className="w-full text-sm">
          <thead>
            <tr>
              <th>Refund Ref.</th>
              <th>Date &amp; Time</th>
              <th className="!text-right">Amount (AED)</th>
              <th>Reason</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {items.map((h) => (
              <tr key={h.ref}>
                <td className="font-mono font-semibold">{h.ref}</td>
                <td className="whitespace-nowrap">{formatDateTime(h.at)}</td>
                <td className="text-right tabular-nums">{formatAmount(h.amount)}</td>
                <td>{h.reason}</td>
                <td>
                  <span className={cn('status-badge whitespace-nowrap', STATUS_MODIFIER[h.status])}>{h.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SideSheet>
  );
}
