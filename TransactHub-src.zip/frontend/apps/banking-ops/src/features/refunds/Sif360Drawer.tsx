import { useState } from 'react';
import { ArrowLeftRight, Hexagon } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { RefundDrawer } from './RefundDrawer';
import {
  BADGE,
  CARD,
  CARD_HEAD,
  FileLink,
  LogLink,
  RelatedMessagesPanel,
  Row,
  SECTION,
  TD,
  TH,
  Tile,
  addMinutes,
  aed,
  dateTime,
} from './drawerParts';
import type { Message } from './drawerParts';
import { formatDate } from '../../shared/utils/formatDate';
import { inProgressRefund, refundStatus } from './data';
import { EDR_RECORDS } from './wpsData';
import type { EdrRecord, SifFile } from './wpsData';

/**
 * SIF Summary 360 for Refund Initiation — the SIF Summary Report's drawer of the same name, with
 * the same shell, tabs, rows and tiles, and a Related Messages panel styled as the report's (with the
 * per-message layouts the refund cycle needs), fed from this screen's static data instead of the report API.
 */

type Tab = 'file' | 'integration' | 'records';
type IntegrationTab = 'core' | 'external';


/** The CB message timeline for one SIF, in the order the WPS cycle produces them. */
function relatedMessages(sif: SifFile): Message[] {
  const v = sif.view360;
  const ackAt = dateTime(addMinutes(v.sentToCbAt, 3));
  const day = formatDate(v.sentToCbAt);
  const pending = (id: string, label: string): Message => ({ id, label, receivedText: 'Pending' });
  const accepted = v.cbResponse === 'ACK';

  const messages: Message[] = [
    {
      id: 'sif-ack',
      label: 'SIF ACK/NAK',
      receivedText: `↓ From CB · ${ackAt}`,
      status: { text: v.cbResponse, tone: 'green' },
      detail: {
        headerItems: [
          { label: 'Received DateTime', value: ackAt },
          { label: 'Processed DateTime', value: ackAt },
        ],
        fields: [
          { label: 'File Name', value: v.ackFileName, mono: true },
          { label: 'Direction', value: '↓ Received from CB', badge: 'green' },
          { label: 'Employer ID (MOL ID)', value: sif.employerId, mono: true },
          { label: 'Employer Name', value: sif.employerName },
          { label: 'Total Records', value: String(sif.records) },
          { label: 'Total Amount', value: aed(sif.totalSalary), mono: true },
        ],
        section: {
          title: accepted ? 'ACK — File Accepted' : 'NAK — File Rejected',
          processedFileName: sif.sifFileName,
          records: accepted ? v.systemAccepted : v.systemRejected,
          status: accepted ? 'ACCEPTED' : 'REJECTED',
          tone: accepted ? 'success' : 'error',
        },
        download: v.ackFileName,
      },
    },
    pending('rtc', 'RTC'),
    pending('paf', 'PAF'),
    pending('prc', 'PRC'),
    pending('prc-ack', 'PRCACK/NAK'),
    pending('dif', 'DIF'),
    pending('dif-ack', 'DIF ACK/NAK'),
    pending('rfa', 'RFA'),
    pending('rfa-ack', 'RFA ACK/NAK'),
  ];

  const r = v.refund;
  if (!r) return [...messages, pending('rfr', 'RFR'), pending('rfr-ack', 'RFR ACK/NAK'), pending('rsu', 'RSU')];

  return [
    ...messages,
    {
      id: 'rfr',
      label: 'RFR',
      receivedText: `↑ To CB · ${day}`,
      status: { text: 'Sent', tone: 'blue' },
      detail: {
        fields: [
          { label: 'File Name', value: r.rfrFileName, mono: true },
          { label: 'Direction', value: '↑ Sent to CB', badge: 'blue' },
          { label: 'Records', value: String(r.records) },
          { label: 'Initiated By', value: r.initiatedBy },
          { label: 'Approved By', value: r.approvedBy },
          { label: 'Refund Reference', value: r.refundRef },
        ],
        download: r.rfrFileName,
      },
    },
    {
      id: 'rfr-ack',
      label: 'RFR ACK/NAK',
      receivedText: `↓ From CB · ${day}`,
      status: { text: 'ACK', tone: 'green' },
      detail: {
        fields: [
          { label: 'File Name', value: r.rfrAckFileName, mono: true },
          { label: 'Direction', value: '↓ Received from CB', badge: 'green' },
          { label: 'CB Response', value: 'ACK', badge: 'green' },
          { label: 'Records', value: String(r.records) },
        ],
      },
    },
    {
      id: 'rsu',
      label: 'RSU',
      receivedText: `↓ From CB · ${day}`,
      status: { text: `${r.records} Accepted`, tone: 'green' },
      detail: {
        fields: [
          { label: 'File Name', value: r.rsuFileName, mono: true },
          { label: 'Direction', value: '↓ Received from CB', badge: 'green' },
          { label: 'Accepted Records', value: String(r.records), badge: 'green' },
          { label: 'Rejected Records', value: '0' },
          { label: 'Posting', value: 'Refund posted to employer account', badge: 'green' },
        ],
      },
    },
  ];
}

/** Pay period of a salary month: the 1st to the 30th. */
function payPeriod(sif: SifFile): { start: string; end: string } {
  return { start: `01-${sif.salaryMonth}-${sif.salaryYear}`, end: `30-${sif.salaryMonth}-${sif.salaryYear}` };
}

/** Variable-pay breakdown of one record: housing is 10% of fixed, the rest standard allowances. */
function evp(r: EdrRecord) {
  return {
    housing: Math.round(r.incomeFixed * 0.1 * 100) / 100,
    conveyance: 200,
    medical: 150,
    passage: 0,
    overtime: 0,
    other: 0,
    leaveEncashment: 0,
  };
}

const EVP_COLUMNS: { key: keyof ReturnType<typeof evp>; label: string }[] = [
  { key: 'housing', label: 'Housing Allow.' },
  { key: 'conveyance', label: 'Conveyance Allow.' },
  { key: 'medical', label: 'Medical Allow.' },
  { key: 'passage', label: 'Annual Passage' },
  { key: 'overtime', label: 'Overtime' },
  { key: 'other', label: 'Other Allow.' },
  { key: 'leaveEncashment', label: 'Leave Encashment' },
];

/** EDR / EVP group header tints — theme accents. */
export const EDR_HEAD = 'bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] text-[var(--accent-blue)]';
export const EVP_HEAD = 'bg-purple-500/10 text-purple-600';

/** The coloured line down the table where each record-type block starts. */
export const EDR_EDGE = 'border-l-2 border-l-[color-mix(in_srgb,var(--accent-blue)_50%,transparent)]';
export const EVP_EDGE = 'border-l-2 border-l-purple-500/50';

export function Sif360Drawer({
  sif,
  onClose,
  onUnavailable,
}: {
  sif: SifFile;
  onClose: () => void;
  /** Called for an action this static screen can't perform, e.g. opening a request log. */
  onUnavailable: (message: string) => void;
}) {
  const [tab, setTab] = useState<Tab>('file');
  const [integrationTab, setIntegrationTab] = useState<IntegrationTab>('core');
  const v = sif.view360;
  const records = EDR_RECORDS[sif.id] ?? [];
  const period = payPeriod(sif);
  const viewLog = (what: string) => () => onUnavailable(`${what} is not available on this static screen yet.`);

  const postings = [
    { stage: 'SIF Posting-1', type: 'Dr Cust – Cr Sus', status: 'Success', start: '09:32:10', end: '09:32:12' },
    { stage: 'SIF Posting-2', type: 'Dr Sus – Cr CB Nostro', status: 'Success', start: '09:32:13', end: '09:32:15' },
    { stage: 'SIF Posting-3', type: 'Dr Sus – Cr Charge GL', status: 'Success', start: '09:32:16', end: '09:32:17' },
    { stage: 'RTC', type: 'Dr CB Nostro – Cr Cust A/c', status: 'Pending', start: '', end: '' },
    ...(sif.refundReturnCount > 0
      ? [{ stage: 'Refund (RSU)', type: 'Dr CB Nostro – Cr Employer A/c', status: 'Success', start: '10:05:02', end: '10:05:04' }]
      : []),
  ];

  const external = [
    { channel: sif.source === 'CBX' ? 'CBX' : sif.source.split(' ')[0], action: 'SIF Payment', at: sif.initiatedAt, direction: 'in' as const },
    { channel: 'SMTP', action: 'Notification Email', at: addMinutes(v.sentToCbAt, 3), direction: 'out' as const },
  ];

  const totals = records.reduce(
    (t, r) => ({ fixed: t.fixed + r.incomeFixed, variable: t.variable + r.incomeVariable }),
    { fixed: 0, variable: 0 },
  );

  return (
    <RefundDrawer
      title="SIF Summary 360"
      subtitle={`${sif.sifFileName} · ${sif.systemRef}`}
      ariaLabel="SIF Summary 360"
      onClose={onClose}
      tabs={
        <div className="flex items-center gap-1 border-b border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-secondary)_30%,transparent)] px-6 pt-2" role="tablist">
          {(
            [
              { key: 'file', label: 'File Summary' },
              { key: 'integration', label: 'Integration 360' },
              { key: 'records', label: 'Record List' },
            ] as const
          ).map((t) => (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={tab === t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                'whitespace-nowrap border-b-2 px-4 py-2.5 text-xs font-bold transition-colors',
                tab === t.key
                  ? 'rounded-t-md border-[var(--primary-blue)] bg-[var(--bg-card)] text-[var(--primary-blue)]'
                  : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]',
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      }
    >
          {/* ═══ File Summary ═══ */}
          {tab === 'file' && (
            <div className="flex flex-col gap-6">
              <div className={CARD}>
                <div className={CARD_HEAD}>
                  <p className={SECTION}>File Details</p>
                </div>
                <dl className="grid grid-cols-1 gap-x-8 gap-y-3 p-5 sm:grid-cols-2">
                  <Row label="SIF File Name" value={sif.sifFileName} mono />
                  <Row label="Original File Name" value={sif.originalFileName} mono />
                  <Row label="System Reference No." value={sif.systemRef} mono />
                  <Row label="Source" value={<span className={cn(BADGE, 'blue')}>{sif.source}</span>} />
                  <Row label="Employer ID (MOL ID)" value={sif.employerId} mono />
                  <Row label="Employer Name" value={sif.employerName} />
                  <Row label="Salary Month" value={sif.salaryMonth} />
                  <Row label="Salary Year" value={sif.salaryYear} />
                  <Row label="Current File Processing Status" value={<span className={cn(BADGE, 'success')}>{v.processingStatus}</span>} />
                  <Row
                    label="Partially Processed"
                    value={<strong className={v.partiallyProcessed === 'N' ? 'text-[var(--accent-green)]' : 'text-[var(--accent-amber)]'}>{v.partiallyProcessed}</strong>}
                  />
                  <Row label="Initiated By" value={v.initiatedBy} />
                  <Row label="Approved By" value={v.approvedBy} />
                  <Row label="Transaction Initiated Date" value={dateTime(sif.initiatedAt)} mono />
                  <Row label="Approved Date Time" value={dateTime(v.approvedAt)} mono />
                </dl>
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                <Tile label="Total Records" value={sif.records} />
                <Tile label="System Accepted" value={v.systemAccepted} tone="text-[var(--accent-green)]" />
                <Tile label="System Rejected" value={v.systemRejected} tone="text-[var(--accent-red)]" />
                <Tile label="Own A/Cs" value={v.ownAccounts} tone="text-[var(--accent-blue)]" />
                <Tile label="Other Bank A/C" value={sif.records - v.ownAccounts} tone="text-[var(--accent-blue)]" />
                <Tile label="Refund-Return Count" value={sif.refundReturnCount} tone="text-[var(--accent-amber)]" />
              </div>

              <div className={CARD}>
                <div className={CARD_HEAD}>
                  <p className={SECTION}>Central Bank Gateway Details</p>
                </div>
                <dl className="grid grid-cols-1 gap-x-8 gap-y-3 p-5 sm:grid-cols-2">
                  <Row label="Sent to CB Date Time" value={dateTime(v.sentToCbAt)} mono />
                  <Row label="CB File Name" value={<FileLink name={sif.sifFileName} />} />
                  <Row label="CB Response" value={<span className={cn(BADGE, v.cbResponse === 'ACK' ? 'success' : 'error')}>{v.cbResponse}</span>} />
                  <Row label="ACK/NAK File Name" value={<FileLink name={v.ackFileName} />} />
                  <Row label="Total Salary Amount (Fixed + Variable) (excl. charges)" value={aed(sif.totalSalary)} mono />
                  <Row label="CB / Platform Reference ID" value={v.cbPlatformRef} mono />
                </dl>
              </div>

              <div>
                <p className={SECTION}>Related Messages</p>
                <RelatedMessagesPanel
                  messages={relatedMessages(sif)}
                  onDownload={(name) => onUnavailable(`Downloading ${name} is not available on this static screen yet.`)}
                />
              </div>
            </div>
          )}

          {/* ═══ Integration 360 ═══ */}
          {tab === 'integration' && (
            <div className="flex flex-col gap-6">
              <div className="flex flex-wrap items-center gap-2">
                {(
                  [
                    { key: 'core', label: 'CORE', icon: Hexagon },
                    { key: 'external', label: 'External Integration', icon: ArrowLeftRight },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.key}
                    type="button"
                    onClick={() => setIntegrationTab(t.key)}
                    className={cn(
                      'inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-semibold transition-colors',
                      integrationTab === t.key
                        ? 'bg-[var(--primary-blue)] text-white shadow-sm'
                        : 'border border-[var(--border)] bg-[var(--bg-card)] text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
                    )}
                  >
                    <t.icon size={13} aria-hidden="true" />
                    {t.label}
                  </button>
                ))}
              </div>

              {integrationTab === 'core' ? (
                <>
                  <div>
                    <p className={SECTION}>Summary Amounts</p>
                    <div className="mt-2.5 overflow-hidden rounded-xl border border-[var(--border)]">
                      {(
                        [
                          ['Total Transaction Amount', sif.totalSalary + v.chargeAmount + v.vatAmount],
                          ['Total Salary Amount (Fixed + Variable) (excl. charges)', sif.totalSalary],
                          ['Charge Amount', v.chargeAmount],
                          ['VAT', v.vatAmount],
                        ] as const
                      ).map(([label, value], i) => (
                        <div
                          key={label}
                          className={cn(
                            'flex items-center justify-between gap-4 px-4 py-3 text-xs',
                            i % 2 === 0 ? 'bg-[var(--bg-card)]' : 'bg-[color-mix(in_srgb,var(--bg-secondary)_40%,transparent)]',
                          )}
                        >
                          <span className="font-medium text-[var(--text-secondary)]">{label}</span>
                          <span className="font-mono text-xs font-bold tabular-nums text-[var(--text-primary)]">{aed(value)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className={SECTION}>Posting Details</p>
                    <div className="mt-2.5 overflow-x-auto rounded-xl border border-[var(--border)]">
                      <table className="w-full min-w-max text-xs">
                        <thead className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]">
                          <tr className="border-b border-[var(--border)]">
                            {['Posting Stage', 'Posting Type', 'Status', 'Start Time', 'End Time', 'Req Log', 'Res Log', 'Failure Reason'].map((h) => (
                              <th key={h} className={TH}>
                                {h}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {postings.map((p) => {
                            const done = p.status === 'Success';
                            return (
                              <tr key={p.stage} className="border-b border-[var(--border)] last:border-b-0">
                                <td className={cn(TD, 'font-bold text-[var(--text-primary)]')}>{p.stage}</td>
                                <td className={cn(TD, 'font-mono text-[11px]')}>{p.type}</td>
                                <td className={TD}>
                                  <span className={cn(BADGE, done && 'success')}>{p.status}</span>
                                </td>
                                <td className={cn(TD, 'font-mono text-[11px]')}>{p.start || '—'}</td>
                                <td className={cn(TD, 'font-mono text-[11px]')}>{p.end || '—'}</td>
                                <td className={TD}>{done ? <LogLink onView={viewLog(`${p.stage} request log`)} /> : '—'}</td>
                                <td className={TD}>{done ? <LogLink onView={viewLog(`${p.stage} response log`)} /> : '—'}</td>
                                <td className={cn(TD, 'text-[var(--text-muted)]')}>—</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-[var(--border)]">
                  <table className="w-full min-w-max text-xs">
                    <thead className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]">
                      <tr className="border-b border-[var(--border)]">
                        {['Channel', 'Action', 'Start DateTime', 'End DateTime', 'Status', 'Direction', 'Req Log', 'Res Log', 'Failure Reason', 'Retry'].map((h) => (
                          <th key={h} className={TH}>
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {external.map((e) => (
                        <tr key={e.channel} className="border-b border-[var(--border)] last:border-b-0">
                          <td className={cn(TD, 'font-bold text-[var(--text-primary)]')}>{e.channel}</td>
                          <td className={TD}>{e.action}</td>
                          <td className={cn(TD, 'font-mono text-[11px]')}>{dateTime(e.at)}</td>
                          <td className={cn(TD, 'font-mono text-[11px]')}>{dateTime(e.at)}</td>
                          <td className={TD}>
                            <span className={cn(BADGE, 'success')}>Success</span>
                          </td>
                          <td className={TD}>
                            <span className={cn(BADGE, e.direction === 'in' ? 'success' : 'blue')}>
                              {e.direction === 'in' ? '↓ InComing' : '↑ OutGoing'}
                            </span>
                          </td>
                          <td className={TD}>
                            <LogLink onView={viewLog(`${e.channel} request log`)} />
                          </td>
                          <td className={TD}>
                            <LogLink onView={viewLog(`${e.channel} response log`)} />
                          </td>
                          <td className={cn(TD, 'text-[var(--text-muted)]')}>—</td>
                          <td className={cn(TD, 'tabular-nums')}>0</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ═══ Record List ═══ */}
          {tab === 'records' && (
            <div className="flex flex-col gap-3">
              <p className="text-xs text-[var(--text-muted)]">
                Showing {records.length} of {records.length} records
              </p>
              <div className="overflow-x-auto rounded-xl border border-[var(--border)]">
                <table className="w-full min-w-max text-xs">
                  <thead>
                    {/* Record-type groups, as the SIF file lays them out */}
                    <tr>
                      <th colSpan={3} className="bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]" />
                      <th colSpan={8} className={cn(TH, EDR_HEAD, EDR_EDGE, '!text-[11px] !font-bold')}>
                        EDR — Employee Detail Record
                      </th>
                      <th colSpan={EVP_COLUMNS.length} className={cn(TH, EVP_HEAD, EVP_EDGE, '!text-[11px] !font-bold')}>
                        EVP — Employee Variable Pay
                      </th>
                    </tr>
                    <tr className="border-b border-[var(--border)]">
                      <th className={cn(TH, 'bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]')}>#</th>
                      <th className={cn(TH, 'bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]')}>Employee ID (MOL ID)</th>
                      <th className={cn(TH, 'bg-[color-mix(in_srgb,var(--bg-secondary)_60%,transparent)]')}>Creditor Name</th>
                      {['Credit Account No.', 'Bank Name (Bank Code)', 'Pay Start Date', 'Pay End Date', 'No of Days', 'Fixed Amount', 'Variable Amount', 'Leave Days'].map((h, i) => (
                        <th key={h} className={cn(TH, EDR_HEAD, i === 0 && EDR_EDGE)}>
                          {h}
                        </th>
                      ))}
                      {EVP_COLUMNS.map((c, i) => (
                        <th key={c.key} className={cn(TH, EVP_HEAD, i === 0 && EVP_EDGE)}>
                          {c.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {records.map((r) => {
                      const status = refundStatus(r);
                      const pay = evp(r);
                      return (
                        <tr key={r.id} className="border-b border-[var(--border)]">
                          <td className={cn(TD, 'text-[var(--text-muted)]')}>{r.sl}</td>
                          <td className={cn(TD, 'font-mono text-[var(--text-primary)]')}>
                            <span className="inline-flex items-center gap-2">
                              {r.employeeId}
                              {inProgressRefund(r) && <span className={cn(BADGE, 'warn')}>Refund in progress</span>}
                              {status === 'Fully refunded' && <span className={cn(BADGE, 'warn')}>Refunded</span>}
                            </span>
                          </td>
                          <td className={cn(TD, 'text-[var(--text-primary)]')}>{r.creditorName}</td>
                          <td className={cn(TD, EDR_EDGE, 'font-mono text-[11px]')}>{r.creditorAccount}</td>
                          <td className={TD}>{`${r.creditorBank} (${r.bankCode})`}</td>
                          <td className={cn(TD, 'font-mono text-[11px]')}>{period.start}</td>
                          <td className={cn(TD, 'font-mono text-[11px]')}>{period.end}</td>
                          <td className={cn(TD, 'text-center tabular-nums')}>30</td>
                          <td className={cn(TD, 'text-right font-mono font-bold text-[var(--text-primary)]')}>{aed(r.incomeFixed)}</td>
                          <td className={cn(TD, 'text-right font-mono font-bold text-[var(--text-primary)]')}>{aed(r.incomeVariable)}</td>
                          <td className={cn(TD, 'text-center tabular-nums')}>0</td>
                          {EVP_COLUMNS.map((c, i) => (
                            <td
                              key={c.key}
                              className={cn(TD, 'text-right font-mono font-bold text-[var(--text-primary)]', i === 0 && EVP_EDGE)}
                            >
                              {aed(pay[c.key])}
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                    {/* SCR — the file's salary control record */}
                    <tr className="bg-[color-mix(in_srgb,var(--accent-amber)_10%,transparent)] italic">
                      <td className={cn(TD, 'text-[var(--accent-amber)]')}>—</td>
                      <td colSpan={2} className={cn(TD, 'font-bold text-[var(--accent-amber)]')}>
                        SCR — Salary Control Record | Salary Month: {sif.salaryMonth}/{sif.salaryYear}
                      </td>
                      {['credit', 'bank', 'start', 'end', 'days'].map((k, i) => (
                        <td key={k} className={cn(TD, 'text-center text-[var(--text-muted)]', i === 0 && EDR_EDGE)}>
                          —
                        </td>
                      ))}
                      <td className={cn(TD, 'text-right font-mono font-bold text-[var(--accent-amber)]')}>{aed(totals.fixed)}</td>
                      <td className={cn(TD, 'text-right font-mono font-bold text-[var(--accent-amber)]')}>{aed(totals.variable)}</td>
                      <td className={cn(TD, 'text-center text-[var(--text-muted)]')}>—</td>
                      {EVP_COLUMNS.map((c, i) => (
                        <td key={c.key} className={cn(TD, 'text-center text-[var(--text-muted)]', i === 0 && EVP_EDGE)}>
                          —
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="flex flex-wrap items-center gap-4 text-[11px] text-[var(--text-muted)]">
                <span className="inline-flex items-center gap-1.5">
                  <span className={cn('size-3 rounded-sm border border-[var(--border)]', EDR_HEAD)} aria-hidden="true" />
                  EDR — Employee Detail Record
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className={cn('size-3 rounded-sm border border-[var(--border)]', EVP_HEAD)} aria-hidden="true" />
                  EVP — Employee Variable Pay
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="size-3 rounded-sm border border-[var(--border)] bg-[color-mix(in_srgb,var(--accent-amber)_10%,transparent)]" aria-hidden="true" />
                  SCR — Salary Control Record (file totals)
                </span>
              </p>
            </div>
          )}
    </RefundDrawer>
  );
}