import { useState } from 'react';
import type { ReactNode } from 'react';
import { Download } from 'lucide-react';
import { cn, sessionInstant } from '@paymenthub/ui';
import { formatAmount } from './data';

/**
 * Building blocks the Refund module's 360 drawers share — the SIF Summary Report drawer's table,
 * row, tile and section styles, the file / log links, the drawer tab strip, and the Related
 * Messages panel — so SIF Summary 360 and Refund 360 read the same.
 */
// The report drawer's table and section styles, so both drawers read the same.
export const TH = 'px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wide text-[var(--text-muted)] whitespace-nowrap';
export const TD = 'px-3 py-2 text-[var(--text-secondary)] whitespace-nowrap text-xs';
export const SECTION = 'input-label text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]';
export const CARD = 'overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm';
export const CARD_HEAD = 'border-b border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-secondary)_40%,transparent)] px-5 py-3';

/** Modifiers on the shared `.status-badge` — readable in every theme. */
export const BADGE = 'status-badge inline-block !px-2 !py-0.5 !text-[11px] font-semibold';

export const aed = (n: number) => `AED ${formatAmount(n)}`;

/** An instant in the session zone, `dd-MM-yyyy HH:mm:ss` (a zoneless mock value is UTC); a thin delegate. */
export function dateTime(iso: string): string {
  return sessionInstant(iso);
}

/** `iso` plus `minutes`, as `YYYY-MM-DDTHH:mm` in local time. */
export function addMinutes(iso: string, minutes: number): string {
  // date-format-ok-begin: mock-data arithmetic on zoneless wall-clock strings, not display
  const d = new Date(iso);
  d.setMinutes(d.getMinutes() + minutes);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
  // date-format-ok-end
}

export function Row({ label, value, mono }: { label: string; value: ReactNode; mono?: boolean }) {
  return (
    <div className="flex flex-col gap-1 border-b border-[var(--border)] pb-2.5 sm:flex-row sm:items-baseline sm:gap-2">
      <dt className="min-w-[180px] text-[11px] font-semibold text-[var(--text-muted)]">{label}:</dt>
      <dd className={cn('min-w-0 break-all text-xs font-medium text-[var(--text-primary)]', mono && 'font-mono text-[11px]')}>{value}</dd>
    </div>
  );
}

/** A number tile; `value` may be "—" when there is nothing to count yet. */
export function Tile({ label, value, tone }: { label: string; value: number | string; tone?: string }) {
  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 text-center shadow-sm">
      <p className={cn('text-2xl font-bold tabular-nums', tone ?? 'text-[var(--text-primary)]')}>
        {typeof value === 'number' ? value.toLocaleString() : value}
      </p>
      <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{label}</p>
    </div>
  );
}

/** A file name the user would download — shown like a link; static screen, so there is nothing to fetch. */
export function FileLink({ name }: { name: string }) {
  return (
    <span className="inline-flex items-center gap-1 font-mono font-bold text-[var(--accent-green)]">
      <Download size={12} aria-hidden="true" />
      {name}
    </span>
  );
}

/** "View" for a request / response log — the static screen has no log store, so it says so. */
export function LogLink({ onView }: { onView: () => void }) {
  return (
    <button type="button" onClick={onView} className="font-semibold text-[var(--primary-blue)] underline-offset-2 hover:underline">
      View
    </button>
  );
}

export type Tone = 'green' | 'blue' | 'red';

export interface MsgField {
  label: string;
  value: string;
  mono?: boolean;
  /** Shown as a small badge in this tone. */
  badge?: Tone;
}

/** One CB message in the Related Messages timeline. */
export interface Message {
  id: string;
  label: string;
  /** Second line in the list — direction and date, or "Pending". */
  receivedText: string;
  status?: { text: string; tone: Tone };
  detail?: {
    /** Heading pairs above the fields, e.g. Sent DateTime / Direction. */
    headerItems?: { label: string; value: string }[];
    fields: MsgField[];
    /** The processed-file summary under the fields, e.g. "ACK — File Accepted". */
    section?: { title: string; processedFileName: string; records: number; status: string; tone: 'success' | 'error' };
    /** File offered as a download button. */
    download?: string;
    /**
     * The header and fields stay on top, with Data Fields / Raw File / Error tabs under them: the
     * `card`, `cardFields`, `summary` and `table`; the `rawFiles` cards; and `errors` (empty →
     * `noErrorsText`, else "No errors reported for this file.").
     */
    tabbed?: boolean;
    /** Data Fields: the file's identity, side by side in one card (File Name / MOL ID / Corporate Name). */
    card?: MsgField[];
    /** Data Fields: label / value pairs under the card, two to a row. */
    cardFields?: MsgField[];
    /** Data Fields: a titled outcome block, e.g. "ACK — File Accepted". */
    summary?: { title: string; tone: 'success' | 'error'; items: MsgField[] };
    /** Data Fields: a titled record table, e.g. the RSU's refund status records. */
    table?: { title: string; columns: string[]; rows: MsgField[][] };
    /** The files behind the message, each a card with its own Download in the Raw File tab. */
    rawFiles?: { fileName: string; description: string }[];
    errors?: string[];
    noErrorsText?: string;
  };
}

/** Accent of the Related Messages panel's selected message and detail tabs. */
export type PanelAccent = 'blue' | 'green';

const ACCENT: Record<PanelAccent, { item: string; tab: string }> = {
  blue: {
    item: 'border-l-4 border-l-[var(--primary-blue)] bg-[var(--bg-card)] font-bold shadow-sm',
    tab: 'border-[var(--primary-blue)] text-[var(--primary-blue)]',
  },
  green: {
    item: 'border-l-4 border-l-[var(--accent-green)] bg-[color-mix(in_srgb,var(--accent-green)_10%,var(--bg-card))] font-bold',
    tab: 'border-[var(--accent-green)] text-[var(--accent-green)]',
  },
};

/** Badge classes on the shared `.status-badge`, sized for the message panel. */
const TONE_BADGE: Record<Tone, string> = { green: 'success', blue: 'blue', red: 'error' };

type MessageDetail = NonNullable<Message['detail']>;

function HeaderItems({ items }: { items: { label: string; value: string }[] }) {
  return (
    <div className="flex flex-wrap gap-8 border-b border-[var(--border)] pb-3 text-xs">
      {items.map((h) => (
        <div key={h.label}>
          <p className="input-label mb-0.5 text-[10px]">{h.label}</p>
          <p className="font-mono font-bold text-[var(--text-primary)]">{h.value}</p>
        </div>
      ))}
    </div>
  );
}

function Fields({ fields }: { fields: MsgField[] }) {
  return (
    <dl className="grid grid-cols-1 gap-x-10 gap-y-3 lg:grid-cols-2">
      {fields.map((f) => (
        <div key={f.label} className="grid grid-cols-[11rem_minmax(0,1fr)] items-center gap-2">
          <dt className="text-[11px] font-semibold text-[var(--text-muted)]">{f.label}:</dt>
          <dd className={cn('min-w-0 break-all text-xs font-medium text-[var(--text-primary)]', f.mono && 'font-mono text-[11px]')}>
            {f.badge ? <span className={cn(BADGE, TONE_BADGE[f.badge])}>{f.value}</span> : f.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}

function Section({ section }: { section: NonNullable<MessageDetail['section']> }) {
  const ok = section.tone === 'success';
  return (
    <div
      className={cn(
        'overflow-hidden rounded-xl border',
        ok ? 'border-[color-mix(in_srgb,var(--accent-green)_40%,transparent)]' : 'border-[color-mix(in_srgb,var(--accent-red)_40%,transparent)]',
      )}
    >
      <p
        className={cn(
          'border-b px-4 py-2 text-[11px] font-bold uppercase tracking-wider',
          ok
            ? 'border-[color-mix(in_srgb,var(--accent-green)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-green)_10%,transparent)] text-[var(--accent-green)]'
            : 'border-[color-mix(in_srgb,var(--accent-red)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-red)_10%,transparent)] text-[var(--accent-red)]',
        )}
      >
        {section.title}
      </p>
      <div className="flex flex-col sm:flex-row">
        <div className="flex-[2] px-4 py-3">
          <p className="input-label mb-0.5 text-[10px]">Processed File Name</p>
          <p className="break-all font-mono text-xs font-bold text-[var(--text-primary)]">{section.processedFileName}</p>
        </div>
        <div className="flex-1 px-4 py-3">
          <p className="input-label mb-0.5 text-[10px]">Number of Records</p>
          <p className="font-mono text-xs font-bold text-[var(--text-primary)]">{section.records}</p>
        </div>
        <div className="flex-1 px-4 py-3">
          <p className="input-label mb-0.5 text-[10px]">Status</p>
          <span className={cn(BADGE, ok ? 'success' : 'error')}>{section.status}</span>
        </div>
      </div>
    </div>
  );
}

function DownloadButton({ fileName, onDownload }: { fileName: string; onDownload: (fileName: string) => void }) {
  return (
    <button
      type="button"
      onClick={() => onDownload(fileName)}
      className="inline-flex max-w-full items-center gap-1.5 break-all rounded-lg bg-[var(--accent-green)] px-5 py-2.5 text-left text-sm font-semibold text-white transition-opacity hover:opacity-90"
    >
      <Download size={15} className="shrink-0" aria-hidden="true" />
      {fileName}
    </button>
  );
}

const DETAIL_TABS = ['Data Fields', 'Raw File', 'Error'] as const;

/** A field's value: a badge in its tone, or the text. */
function FieldValue({ field }: { field: MsgField }) {
  return field.badge ? <span className={cn(BADGE, TONE_BADGE[field.badge])}>{field.value}</span> : <>{field.value}</>;
}

/** The file's identity in one card, side by side. */
function IdentityCard({ items }: { items: MsgField[] }) {
  return (
    <dl className="grid grid-cols-1 divide-y divide-[var(--border)] overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] sm:grid-cols-[2fr_1fr_1fr] sm:divide-x sm:divide-y-0">
      {items.map((f) => (
        <div key={f.label} className="min-w-0 px-4 py-3">
          <dt className="input-label mb-0.5 text-[10px] uppercase">{f.label}</dt>
          <dd className={cn('break-all text-xs font-bold text-[var(--text-primary)]', f.mono && 'font-mono')}>
            <FieldValue field={f} />
          </dd>
        </div>
      ))}
    </dl>
  );
}

/** A titled outcome block, green for an accepted file and red for a rejected one. */
function Summary({ summary }: { summary: NonNullable<MessageDetail['summary']> }) {
  const ok = summary.tone === 'success';
  return (
    <div
      className={cn(
        'overflow-hidden rounded-xl border bg-[var(--bg-card)]',
        ok ? 'border-[color-mix(in_srgb,var(--accent-green)_40%,transparent)]' : 'border-[color-mix(in_srgb,var(--accent-red)_40%,transparent)]',
      )}
    >
      <p
        className={cn(
          'border-b px-4 py-2 text-[11px] font-bold uppercase tracking-wider',
          ok
            ? 'border-[color-mix(in_srgb,var(--accent-green)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-green)_10%,transparent)] text-[var(--accent-green)]'
            : 'border-[color-mix(in_srgb,var(--accent-red)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-red)_10%,transparent)] text-[var(--accent-red)]',
        )}
      >
        {summary.title}
      </p>
      <dl className="flex flex-col sm:flex-row">
        {summary.items.map((f, i) => (
          <div key={f.label} className={cn('min-w-0 px-4 py-3', i === 0 && summary.items.length > 2 ? 'flex-[2]' : 'flex-1')}>
            <dt className="input-label mb-0.5 text-[10px] uppercase">{f.label}</dt>
            <dd className={cn('break-all text-xs font-bold text-[var(--text-primary)]', f.mono && 'font-mono')}>
              <FieldValue field={f} />
            </dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

function RecordTable({ table }: { table: NonNullable<MessageDetail['table']> }) {
  return (
    <section>
      <p className={cn(SECTION, 'mb-2')}>{table.title}</p>
      <div className="overflow-x-auto">
        <table className="w-full min-w-max text-xs">
          <thead>
            <tr className="border-b border-[var(--border)]">
              {table.columns.map((c) => (
                <th key={c} className={TH}>
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {table.rows.map((row, i) => (
              <tr key={i} className="border-b border-[var(--border)] last:border-b-0">
                {row.map((f) => (
                  <td key={f.label} className={cn(TD, 'text-[var(--text-primary)]', f.mono && 'font-mono text-[11px]')}>
                    <FieldValue field={f} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

/** A tabbed message detail: header and fields, then Data Fields / Raw File / Error. */
function TabbedDetail({ detail, accent, onDownload }: { detail: MessageDetail; accent: PanelAccent; onDownload: (fileName: string) => void }) {
  const [tab, setTab] = useState<(typeof DETAIL_TABS)[number]>('Data Fields');
  return (
    <>
      {detail.headerItems && <HeaderItems items={detail.headerItems} />}
      <Fields fields={detail.fields} />
      <div className="flex gap-1 border-b border-[var(--border)]" role="tablist">
        {DETAIL_TABS.map((t) => (
          <button
            key={t}
            type="button"
            role="tab"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={cn(
              'border-b-2 px-3 py-2 text-xs font-bold transition-colors',
              tab === t ? ACCENT[accent].tab : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]',
            )}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === 'Data Fields' && (
        <div className="space-y-4">
          {detail.card && <IdentityCard items={detail.card} />}
          {detail.cardFields && <Fields fields={detail.cardFields} />}
          {detail.summary && <Summary summary={detail.summary} />}
          {detail.table && <RecordTable table={detail.table} />}
        </div>
      )}
      {tab === 'Raw File' &&
        (detail.rawFiles && detail.rawFiles.length > 0 ? (
          <ul className="flex flex-col gap-3">
            {detail.rawFiles.map((file) => (
              <li
                key={file.fileName}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--bg-card)] px-5 py-4"
              >
                <div className="min-w-0">
                  <p className="break-all font-mono text-sm font-bold text-[var(--text-primary)]">{file.fileName}</p>
                  <p className="mt-0.5 text-xs text-[var(--text-muted)]">{file.description}</p>
                </div>
                <button
                  type="button"
                  onClick={() => onDownload(file.fileName)}
                  aria-label={`Download ${file.fileName}`}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-[var(--accent-green)] px-5 py-2.5 text-sm font-semibold text-white transition-opacity hover:opacity-90"
                >
                  <Download size={15} aria-hidden="true" />
                  Download
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="py-6 text-center text-xs italic text-[var(--text-muted)]">No raw file for this message yet.</p>
        ))}
      {tab === 'Error' &&
        (detail.errors && detail.errors.length > 0 ? (
          <ul className="list-disc space-y-1 pl-5 text-xs text-[var(--accent-red)]">
            {detail.errors.map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        ) : (
          <p className="text-xs text-[var(--text-secondary)]">{detail.noErrorsText ?? 'No errors reported for this file.'}</p>
        ))}
    </>
  );
}

/**
 * Related Messages — the message list on the left (styled as the SIF Summary Report's), and the
 * selected message's detail on the right: fields, file summary and download, or the same split
 * into Data Fields / Raw File / Error tabs when the message is `tabbed`.
 */
export function RelatedMessagesPanel({
  messages,
  onDownload,
  accent = 'blue',
}: {
  messages: Message[];
  onDownload: (fileName: string) => void;
  accent?: PanelAccent;
}) {
  const [selectedId, setSelectedId] = useState(messages[0]?.id ?? '');
  const selected = messages.find((m) => m.id === selectedId) ?? messages[0];
  const detail = selected?.detail;

  return (
    <div className="mt-2.5 flex min-h-[360px] flex-col overflow-hidden rounded-xl border border-[var(--border)] md:flex-row">
      <div className="w-full shrink-0 overflow-y-auto border-b border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-secondary)_40%,transparent)] md:max-h-[560px] md:w-[230px] md:border-b-0 md:border-r">
        {messages.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => setSelectedId(m.id)}
            aria-pressed={selected?.id === m.id}
            className={cn(
              'flex w-full items-center justify-between gap-2 border-b border-[var(--border)] px-4 py-3 text-left transition-colors last:border-b-0',
              selected?.id === m.id ? ACCENT[accent].item : 'hover:bg-[var(--bg-card-hover)]',
            )}
          >
            <span className="min-w-0">
              <span className="block text-xs text-[var(--text-primary)]">{m.label}</span>
              <span className="mt-0.5 block text-[10px] font-normal text-[var(--text-muted)]">{m.receivedText}</span>
            </span>
            {m.status && <span className={cn(BADGE, '!text-[9px]', TONE_BADGE[m.status.tone])}>{m.status.text}</span>}
          </button>
        ))}
      </div>

      <div className="min-w-0 flex-1 space-y-4 overflow-y-auto bg-[color-mix(in_srgb,var(--bg-secondary)_20%,transparent)] p-5">
        {!detail ? (
          <div className="flex h-full items-center justify-center text-xs italic text-[var(--text-muted)]">
            {selected?.label ?? 'Message'} — Pending processing. No message payload available yet.
          </div>
        ) : detail.tabbed ? (
          // Keyed by message, so switching messages starts on Data Fields.
          <TabbedDetail key={selected?.id} detail={detail} accent={accent} onDownload={onDownload} />
        ) : (
          <>
            {detail.headerItems && <HeaderItems items={detail.headerItems} />}
            <Fields fields={detail.fields} />
            {detail.section && <Section section={detail.section} />}
            {detail.download && <DownloadButton fileName={detail.download} onDownload={onDownload} />}
          </>
        )}
      </div>
    </div>
  );
}

/** The drawer tab strip under the header — the SIF Summary Report drawer's style. */
export function DrawerTabs<K extends string>({
  tabs,
  value,
  onChange,
}: {
  tabs: readonly { key: K; label: string }[];
  value: K;
  onChange: (key: K) => void;
}) {
  return (
    <div className="flex items-center gap-1 border-b border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-secondary)_30%,transparent)] px-6 pt-2" role="tablist">
      {tabs.map((t) => (
        <button
          key={t.key}
          type="button"
          role="tab"
          aria-selected={value === t.key}
          onClick={() => onChange(t.key)}
          className={cn(
            'whitespace-nowrap border-b-2 px-4 py-2.5 text-xs font-bold transition-colors',
            value === t.key
              ? 'rounded-t-md border-[var(--primary-blue)] bg-[var(--bg-card)] text-[var(--primary-blue)]'
              : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]',
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}