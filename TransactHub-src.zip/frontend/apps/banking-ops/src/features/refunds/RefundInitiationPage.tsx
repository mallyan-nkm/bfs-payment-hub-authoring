import { useState } from 'react';
import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, Check, Globe, Landmark, Play, RotateCw, Wallet } from 'lucide-react';
import { PageBody, PageShell, cn } from '@paymenthub/ui';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { ChargesPostingStep } from './ChargesPostingStep';
import { RECALL_MESSAGE, REFUND_RAILS, formatAmount } from './data';
import type { RefundRail, RefundRailCode, RefundRailIcon, RefundRecord } from './data';
import { RailRefundPanel } from './RailRefundPanel';
import { WpsRefundPanel } from './WpsRefundPanel';

type Step = 'select' | 'charges';

const STEPS: { key: Step; label: string }[] = [
  { key: 'select', label: 'Select Records' },
  { key: 'charges', label: 'Charges & Posting' },
];

/** Step progress — the SIF Upload stepper's markup and its shared `stepper-*` classes. */
function Stepper({ step }: { step: Step }) {
  const stepIndex = STEPS.findIndex((s) => s.key === step);
  return (
    <div className="flex flex-wrap items-center justify-center py-3" aria-label="Refund steps">
      {STEPS.map((s, i) => {
        const done = i < stepIndex;
        const current = i === stepIndex;
        return (
          <div
            key={s.key}
            className="stepper-repeat relative flex items-center gap-3"
            aria-current={current ? 'step' : undefined}
          >
            <span className={cn('stepper-count', done ? 'stepper-count-completed' : current ? 'stepper-count-active' : '')}>
              {done ? <Check size={14} /> : i + 1}
            </span>
            <span className={cn('stepper-text', current || done ? 'stepper-text-completed' : '')}>{s.label}</span>
          </div>
        );
      })}
    </div>
  );
}

/** Rail tile icons — the same ones Domestic Payments uses (NewPaymentPage). */
const RAIL_ICON: Record<RefundRailIcon, ReactNode> = {
  instant: <Wallet size={18} />,
  interbank: <Landmark size={18} />,
  salary: <Briefcase size={18} />,
  card: <Globe size={18} />,
};

/** Dashed empty-state panel under the rail picker. */
function Placeholder({ icon, title, message }: { icon: ReactNode; title: string; message: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-[var(--border)] bg-[var(--bg-card)] px-6 py-14 text-center">
      <span className="mb-2 text-[var(--text-muted)]" aria-hidden="true">
        {icon}
      </span>
      <p className="text-sm font-bold text-[var(--text-primary)]">{title}</p>
      <p className="text-sm text-[var(--text-secondary)]">{message}</p>
    </div>
  );
}

/**
 * Refund Initiation — pick the payment rail of the original transaction, then two steps:
 * 1. Select Records — search the rail's settled transactions, tick the ones to refund and set
 *    each amount and reason (`RailRefundPanel`);
 * 2. Charges & Posting — review the summary, charges and postings, add remarks and submit for
 *    Checker approval (`ChargesPostingStep`).
 * The rail tiles match New Payment's rail selection. Static: data comes from `data.ts`.
 */
export function RefundInitiationPage() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<RefundRailCode | null>(null);
  const [step, setStep] = useState<Step>('select');
  const [records, setRecords] = useState<RefundRecord[]>([]);
  // Bumped to remount the rail panel, clearing its search and selection.
  const [round, setRound] = useState(0);
  const [toast, setToast] = useState<ToastState | null>(null);

  const selectedRail = REFUND_RAILS.find((r) => r.code === selected);

  function select(rail: RefundRail) {
    // Re-checked here and not only on the tile: `disabled` is a rendering hint.
    if (!rail.enabled) return;
    setSelected(rail.code);
    setStep('select');
  }

  function goToCharges(next: RefundRecord[]) {
    setRecords(next);
    setStep('charges');
  }

  /** Back to the landing screen, discarding the selection. */
  function reset() {
    setSelected(null);
    setStep('select');
    setRecords([]);
    setRound((n) => n + 1);
  }

  function submit(remarks: string, totalCharges: number) {
    const ref = `RFD-2026-${String(Date.now()).slice(-5)}`;
    const amount = records.reduce((sum, r) => sum + r.amount, 0);
    setToast({
      tone: 'success',
      message: `Refund request ${ref} for ${records.length} record(s), AED ${formatAmount(amount)} (charges AED ${formatAmount(totalCharges)}), submitted for Checker approval.`,
    });
    // `remarks` goes to the Checker with the request once this is wired to a backend.
    void remarks;
    reset();
  }

  return (
    <PageShell>
      <PageBody>
        <div className="pq-page pr-2">
          {/* Breadcrumb */}
          <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
            <button onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">
              Dashboard
            </button>
            {' / Refunds / '}
            <span>Refund Initiation</span>
          </p>

          {/* Title header */}
          <div className="pq-header">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                Refund Initiation
              </h1>
              <p className="pq-header-subtitle">
                {step === 'charges' && selectedRail
                  ? `Raise a refund (recall) request for a settled ${selectedRail.label} outward payment — sent to the beneficiary bank as ${RECALL_MESSAGE}`
                  : 'Select the payment rail of the original transaction to raise a refund request'}
              </p>
            </div>
          </div>

          <>
            {selectedRail && <Stepper step={step} />}

            {/* Rail picker — step 1 only */}
            <section
              className={cn(
                'rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 shadow-[var(--shadow-sm)]',
                step === 'charges' && 'hidden',
              )}
            >
              <h2 className="mb-4 flex items-center gap-2 text-[13px] font-bold uppercase tracking-wider text-[var(--text-primary)]">
                <Play size={11} className="fill-current" aria-hidden="true" />
                Select Primary Payment Rail
              </h2>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4" role="radiogroup" aria-label="Payment rail">
                {REFUND_RAILS.map((rail) => {
                  const active = selected === rail.code;
                  // Static screen: any built rail can be picked. No per-rail permission check yet —
                  // add one here (and in `select`) when refunds are wired to a backend.
                  return (
                    <button
                      key={rail.code}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      onClick={() => select(rail)}
                      disabled={!rail.enabled}
                      className={cn(
                        'rail-card',
                        active ? 'rail-card-selected' : '',
                        rail.enabled ? 'cursor-pointer' : 'cursor-not-allowed',
                      )}
                    >
                      <span className="rail-icon" aria-hidden="true">
                        {RAIL_ICON[rail.icon]}
                      </span>
                      <span className="rail-text text-left">
                        <span className="block text-sm font-bold text-[var(--text-primary)]">{rail.label}</span>
                        <span className="block text-xs text-[var(--text-muted)]">{rail.description}</span>
                      </span>
                      {!rail.enabled && (
                        <span className="rounded bg-[var(--bg-secondary)] px-2 py-0.5 text-[10px] font-semibold text-[var(--text-muted)]">
                          Coming Soon
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </section>

            {selectedRail ? (
              <>
                {/* Kept mounted (hidden) during step 2 so Previous returns to the same selection.
                    Keyed by rail, so switching rails starts a clean search. */}
                <div className={cn('flex flex-col gap-4', step === 'charges' && 'hidden')}>
                  {/* WPS refunds work per SIF file, so it has its own panel; every other rail lists transactions. */}
                  {selectedRail.code === 'WPS' ? (
                    <WpsRefundPanel key={`WPS-${round}`} onNext={goToCharges} />
                  ) : (
                    <RailRefundPanel key={`${selectedRail.code}-${round}`} rail={selectedRail} onNext={goToCharges} />
                  )}
                </div>
                {step === 'charges' && (
                  <ChargesPostingStep
                    rail={selectedRail}
                    records={records}
                    onPrevious={() => setStep('select')}
                    onCancel={reset}
                    onSubmit={submit}
                  />
                )}
              </>
            ) : (
              <Placeholder
                icon={<RotateCw size={22} />}
                title="Select a rail to start a refund"
                message="Search criteria, record selection and refund reasons change based on the selected rail."
              />
            )}
          </>
        </div>
      </PageBody>

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}
