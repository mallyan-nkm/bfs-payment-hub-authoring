import { useCallback, useMemo, useRef, useState } from 'react';
import type { RefObject } from 'react';
import { Download } from 'lucide-react';
import { SmartGrid, cn, sessionInstant } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { SideSheet } from '../../shared/components/SideSheet';
import { RefundDrawer } from './RefundDrawer';
import { auditActivities, maskName, rfrAuditActivities } from './wpsAudit';
import type { AuditActivity } from './wpsAudit';
import type { RfrHistoryEntry, SifFile } from './wpsData';
import { STATUS_MODIFIER } from './wpsStyles';

const SECTION = 'input-label text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]';

/** An instant in the session zone, `dd-MM-yyyy HH:mm:ss` (a zoneless mock value is UTC); a thin delegate. */
function stamp(iso: string): string {
  return sessionInstant(iso);
}

/** Handlers behind a ref: SmartGrid snapshots column definitions on first mount. */
interface AuditGridView {
  /** Whether PII is unmasked — only then does a name's real value come with the row. */
  unmasked: boolean;
  onMoreDetails: (a: AuditActivity) => void;
}

function columns(view: RefObject<AuditGridView>): SmartGridColumn<AuditActivity>[] {
  return [
    {
      key: 'activity',
      label: 'Activity',
      filterKey: 'activity',
      getValue: (a) => a.activity,
      render: (a) => <span className="font-bold text-[var(--text-primary)]">{a.activity}</span>,
    },
    {
      key: 'actionBy',
      label: 'Action By',
      filterKey: 'actionBy',
      // A person's name is personal data: masked until PII is unmasked. System actors aren't.
      pii: true,
      // As the server's PII contract: the real value comes with the row only while unmasked.
      getMasked: (a) =>
        a.actionByIsPerson
          ? { maskedValue: maskName(a.actionBy), actualValue: view.current.unmasked ? a.actionBy : null }
          : { maskedValue: a.actionBy, actualValue: a.actionBy },
    },
    {
      key: 'startedAt',
      label: 'Actioned Start Date & Time',
      sortKey: 'startedAt',
      getValue: (a) => stamp(a.startedAt),
      getSortValue: (a) => a.startedAt,
      render: (a) => <span className="font-mono text-xs">{stamp(a.startedAt)}</span>,
    },
    {
      key: 'endedAt',
      label: 'Actioned End Date & Time',
      getValue: (a) => stamp(a.endedAt),
      getSortValue: (a) => a.endedAt,
      render: (a) => <span className="font-mono text-xs">{stamp(a.endedAt)}</span>,
    },
    {
      key: 'channel',
      label: 'Channel',
      filterKey: 'channel',
      filterType: 'select',
      filterOptions: ['Web Portal', 'System', 'API'],
      getValue: (a) => a.channel,
      render: (a) => <span className="text-[var(--text-muted)]">{a.channel}</span>,
    },
    {
      key: 'status',
      label: 'Status',
      getValue: (a) => a.status,
      render: (a) => (
        <span className={cn('status-badge', a.status === 'Success' ? 'success' : a.status === 'Failed' || a.status === 'Failure' ? 'error' : 'warn')}>{a.status}</span>
      ),
    },
    {
      key: 'remarks',
      label: 'Remarks',
      filterKey: 'remarks',
      getValue: (a) => a.remarks,
      wrap: true,
      maxWidth: 380,
    },
    {
      key: 'moreDetails',
      label: 'More Details',
      locked: true,
      render: (a) =>
        a.detail ? (
          <button type="button" onClick={() => view.current.onMoreDetails(a)} className="btn-secondary pq-view-action-btn">
            More Details
          </button>
        ) : (
          <span className="text-[var(--text-muted)]">—</span>
        ),
    },
  ];
}

/** More Details — the user remarks and downloadable files behind one activity. */
function ActivityDetailSheet({
  activity,
  unmasked,
  onClose,
  onDownload,
}: {
  activity: AuditActivity;
  /** Whether PII is unmasked — names here are masked like the grid's. */
  unmasked: boolean;
  onClose: () => void;
  onDownload: (fileName: string) => void;
}) {
  const detail = activity.detail;
  if (!detail) return null;

  return (
    <SideSheet
      maximizable
      // The activity's name over the title only when they differ (e.g. "SIF File Uploaded" › "Uploaded File").
      eyebrow={activity.activity !== detail.title ? activity.activity : undefined}
      title={detail.title}
      subtitle={detail.subtitle}
      onClose={onClose}
      footer={
        <div className="flex w-full justify-end">
          <button type="button" onClick={onClose} className="btn-secondary large-btn justify-center !py-2.5 text-sm">
            Close
          </button>
        </div>
      }
    >
      <div className="flex flex-col gap-6">
        {detail.remarks.length > 0 && (
          <section>
            <p className={cn(SECTION, 'mb-2')}>User Remarks</p>
            <div className="table-holder overflow-x-auto rounded-lg border border-[var(--border)]">
              <table className="w-full text-sm">
                <thead>
                  <tr>
                    <th>Sl. No</th>
                    <th>User Details</th>
                    <th>User Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.remarks.map((r, i) => (
                    <tr key={`${r.name}-${i}`} className="align-top">
                      <td className="text-center text-[var(--text-muted)]">{i + 1}</td>
                      <td>
                        <p className="font-bold text-[var(--text-primary)]">{unmasked ? r.name : maskName(r.name)}</p>
                        {/* Tinted from the text colour, so the chip reads in every theme. */}
                        <span className="mt-1 inline-block whitespace-nowrap rounded-full border border-[var(--border)] bg-[color-mix(in_srgb,var(--text-primary)_8%,transparent)] px-2.5 py-0.5 text-xs font-medium text-[var(--text-primary)]">
                          {r.role}
                        </span>
                      </td>
                      <td className="text-[var(--text-primary)]">{r.remarks}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {detail.downloads.length > 0 && (
          <section>
            <p className={cn(SECTION, 'mb-2')}>File &amp; Log Downloads</p>
            <ul className="flex flex-col gap-2">
              {detail.downloads.map((d) => (
                <li
                  key={d.label}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[var(--border)] bg-[color-mix(in_srgb,var(--bg-secondary)_40%,transparent)] px-4 py-3"
                >
                  <span className="text-sm font-medium text-[var(--text-primary)]">{d.label}</span>
                  <button type="button" onClick={() => onDownload(d.fileName)} className="btn-secondary pq-view-action-btn inline-flex items-center gap-1.5">
                    <Download size={13} aria-hidden="true" />
                    {d.fileName}
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}

        {detail.remarks.length === 0 && detail.downloads.length === 0 && (
          <p className="text-center text-sm italic text-[var(--text-muted)]">No further details recorded for this activity.</p>
        )}
      </div>
    </SideSheet>
  );
}

/**
 * Audit Trail — every activity of one SIF or RFR, in the shared grid (filters, columns, export, and
 * the Unmask PII control for the people who acted), under a summary strip. More Details opens the
 * remarks and files behind an activity.
 *
 * Static: activities come from `wpsAudit.ts`. Masked names come with the data and real ones only
 * once unmasked, as the server's PII contract works.
 */
export function AuditTrailDrawer({
  reference,
  summary,
  status,
  activities,
  storageKey,
  exportFilename,
  onClose,
  onUnavailable,
}: {
  /** Shown under the title, e.g. the SIF file name or RFR reference. */
  reference: string;
  summary: { label: string; value: string; mono?: boolean }[];
  /** The status at the end of the summary strip, as a shared `.status-badge`. */
  status: { text: string; modifier: string };
  activities: AuditActivity[];
  storageKey: string;
  exportFilename: string;
  onClose: () => void;
  /** Called for an action this static screen can't perform, e.g. a download. */
  onUnavailable: (message: string) => void;
}) {
  const [unmasked, setUnmasked] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [details, setDetails] = useState<AuditActivity | null>(null);

  const gridView = useRef<AuditGridView>({ unmasked, onMoreDetails: setDetails });
  gridView.current.unmasked = unmasked;
  // Stable, so the More Details sheet's focus/Escape effect doesn't re-run on every render.
  const closeDetails = useCallback(() => setDetails(null), []);
  // Built once: SmartGrid never re-reads column definitions, and the closures read through the ref.
  const cols = useMemo(() => columns(gridView), []);

  return (
    <>
      <RefundDrawer
        title="Audit Trail"
        subtitle={reference}
        ariaLabel={`Audit trail — ${reference}`}
        footerStart={`${activities.length} activities`}
        onClose={onClose}
      >
        <div className="flex flex-col gap-6">
          {/* Summary strip */}
          <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm">
            <dl className="flex flex-wrap divide-x divide-[var(--border)]">
              {summary.map((s) => (
                <div key={s.label} className="min-w-[10rem] flex-1 px-5 py-3">
                  <dt className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{s.label}</dt>
                  <dd className={cn('mt-1 text-sm font-medium text-[var(--text-primary)]', s.mono && 'font-mono text-xs font-bold')}>{s.value}</dd>
                </div>
              ))}
              <div className="min-w-[12rem] flex-1 px-5 py-3">
                <dt className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">Status</dt>
                <dd className="mt-1">
                  <span className={cn('status-badge', status.modifier)}>{status.text}</span>
                </dd>
              </div>
            </dl>
          </div>

          <SmartGrid<AuditActivity>
            columns={cols}
            rows={activities}
            getRowId={(a) => a.id}
            storageKey={storageKey}
            emptyTitle="No activities"
            emptyMessage="No activities are recorded yet."
            exportFilename={exportFilename}
            exportFormats={['csv']}
            pii={{
              unmasked,
              canUnmask: true,
              notice,
              onApply: (next) => {
                setUnmasked(next);
                setNotice(next ? 'Unmasked successfully.' : 'Masked again.');
              },
            }}
          />
        </div>
      </RefundDrawer>

      {details && (
        <ActivityDetailSheet
          activity={details}
          unmasked={unmasked}
          onClose={closeDetails}
          onDownload={(name) => onUnavailable(`Downloading ${name} is not available on this static screen yet.`)}
        />
      )}
    </>
  );
}

/** Audit Trail of one processed SIF — from upload to the refund credit. */
export function SifAuditTrailDrawer({
  sif,
  onClose,
  onUnavailable,
}: {
  sif: SifFile;
  onClose: () => void;
  onUnavailable: (message: string) => void;
}) {
  const activities = useMemo(() => auditActivities(sif), [sif]);
  return (
    <AuditTrailDrawer
      reference={sif.sifFileName}
      summary={[
        { label: 'Reference', value: sif.sifFileName, mono: true },
        { label: 'Transaction Type', value: 'WPS — SIF Salary File' },
        { label: 'Employer Name', value: sif.employerName },
        { label: 'CB / Platform Reference ID', value: sif.view360.cbPlatformRef, mono: true },
      ]}
      status={{ text: `${sif.view360.processingStatus}${sif.view360.refund ? ' · Refund Posted' : ''}`, modifier: 'success' }}
      activities={activities}
      storageKey="refund-initiation-wps-audit-columns-v1"
      exportFilename={`sif-audit-trail-${sif.systemRef.toLowerCase()}`}
      onClose={onClose}
      onUnavailable={onUnavailable}
    />
  );
}

/** Audit Trail of one RFR — the History tab's Audit. */
export function RfrAuditTrailDrawer({
  entry,
  onClose,
  onUnavailable,
}: {
  entry: RfrHistoryEntry;
  onClose: () => void;
  onUnavailable: (message: string) => void;
}) {
  const activities = useMemo(() => rfrAuditActivities(entry), [entry]);
  return (
    <AuditTrailDrawer
      reference={entry.requestRef}
      summary={[
        { label: 'Reference', value: entry.requestRef, mono: true },
        { label: 'Transaction Type', value: 'WPS — Request for Refund (RFR)' },
        { label: 'Employer Name', value: entry.employerName },
        { label: 'CB / Platform Reference ID', value: entry.rfrFileName ?? '—', mono: true },
      ]}
      status={{ text: entry.status, modifier: STATUS_MODIFIER[entry.status] }}
      activities={activities}
      storageKey="refund-initiation-wps-rfr-audit-columns-v1"
      exportFilename={`rfr-audit-trail-${entry.requestRef.toLowerCase()}`}
      onClose={onClose}
      onUnavailable={onUnavailable}
    />
  );
}