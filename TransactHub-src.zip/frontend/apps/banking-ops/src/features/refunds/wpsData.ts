import type { SettledTransaction } from './data';

/**
 * Static seed data for WPS refunds — no backend yet. WPS refunds work per SIF file: pick a
 * successfully processed SIF, then refund individual employee salary records (EDRs) inside it.
 */

export type SifSource = 'CBX' | 'I-Business' | 'Host-to-Host (SFTP)' | 'Direct Entry (Branch)';
export type SifPriority = 'Urgent' | 'High' | 'Normal';

/** A successfully processed SIF (salary information file). Amounts are AED. */
export interface SifFile {
  id: string;
  sifFileName: string;
  originalFileName: string;
  systemRef: string;
  employerId: string;
  employerName: string;
  /** Short tag shown beside the employer name, e.g. a group code. */
  employerTag?: string;
  employerAccount: string;
  salaryMonth: string;
  salaryYear: string;
  /** `YYYY-MM-DDTHH:mm` */
  initiatedAt: string;
  valueDate: string;
  records: number;
  refundReturnCount: number;
  /** Total salary (fixed + variable), excluding charges. */
  totalSalary: number;
  currency: string;
  source: SifSource;
  priority: SifPriority;
  /** The 360 view's file and Central Bank details. */
  view360: Sif360Details;
}

/** What SIF Summary 360 shows beyond the list row. */
export interface Sif360Details {
  processingStatus: string;
  partiallyProcessed: 'Y' | 'N';
  initiatedBy: string;
  approvedBy: string;
  approvedAt: string;
  systemAccepted: number;
  systemRejected: number;
  /** Records crediting accounts at this bank; the rest go to other banks. */
  ownAccounts: number;
  sentToCbAt: string;
  cbResponse: 'ACK' | 'NAK';
  ackFileName: string;
  cbPlatformRef: string;
  chargeAmount: number;
  vatAmount: number;
  /** The refund exchange with the CB (RFR → RFR ACK/NAK → RSU); only for a SIF with a refund. */
  refund?: {
    rfrFileName: string;
    rfrAckFileName: string;
    rsuFileName: string;
    refundRef: string;
    initiatedBy: string;
    approvedBy: string;
    records: number;
  };
}

/**
 * One employee salary record in a SIF, as a refundable row. It is a `SettledTransaction` so the
 * shared refund grid and Charges & Posting step treat it like any other rail's row: the employer
 * is the debtor, the employee the creditor, and the total salary the original amount.
 */
export interface EdrRecord extends SettledTransaction {
  sl: number;
  employeeId: string;
  bankCode: string;
  incomeFixed: number;
  incomeVariable: number;
}

/** Read-only: consumers filter and look up, never mutate, the seed. */
export const SIF_FILES: readonly SifFile[] = [
  {
    id: 'sif-1',
    sifFileName: 'WPS109928838.SIF',
    originalFileName: 'EmiratesSteel_Salary_Aug26.xlsx',
    systemRef: 'WPS-2026-00419',
    employerId: '808977026654343',
    employerName: 'Emirates Steel LLC',
    employerAccount: 'AE070331452100001',
    salaryMonth: '08',
    salaryYear: '2026',
    initiatedAt: '2026-08-27T09:30',
    valueDate: '2026-08-28',
    records: 7,
    refundReturnCount: 1,
    totalSalary: 612450,
    currency: 'AED',
    source: 'CBX',
    priority: 'Urgent',
    view360: {
      processingStatus: 'ACK Received',
      partiallyProcessed: 'N',
      initiatedBy: 'Ali Hassan',
      approvedBy: 'Sara Mohammed',
      approvedAt: '2026-08-27T09:45',
      systemAccepted: 7,
      systemRejected: 0,
      ownAccounts: 3,
      sentToCbAt: '2026-08-27T10:00',
      cbResponse: 'ACK',
      ackFileName: 'WPS8872766535.ACK',
      cbPlatformRef: 'CBUAE-WPS-27Au26-000140',
      chargeAmount: 42.5,
      vatAmount: 2.13,
      refund: {
        rfrFileName: '0000004938801002151712590.RFR',
        rfrAckFileName: '000000493880100215171259061000000250.ACK',
        rsuFileName: 'RSU_0000004938801002151712590.RSU',
        refundRef: 'RFR-2026-00115',
        initiatedBy: 'Omar Rashid',
        approvedBy: 'Sooraj K',
        records: 1,
      },
    },
  },
  {
    id: 'sif-2',
    sifFileName: 'WPS109928712.SIF',
    originalFileName: 'EmiratesSteel_Salary_Jul26.SIF',
    systemRef: 'WPS-2026-00352',
    employerId: '808977026654343',
    employerName: 'Emirates Steel LLC',
    employerAccount: 'AE070331452100001',
    salaryMonth: '07',
    salaryYear: '2026',
    initiatedAt: '2026-07-28T14:05',
    valueDate: '2026-07-29',
    records: 12,
    refundReturnCount: 0,
    totalSalary: 1200000,
    currency: 'AED',
    source: 'I-Business',
    priority: 'Urgent',
    view360: {
      processingStatus: 'ACK Received',
      partiallyProcessed: 'N',
      initiatedBy: 'Ali Hassan',
      approvedBy: 'Sara Mohammed',
      approvedAt: '2026-07-28T14:20',
      systemAccepted: 12,
      systemRejected: 0,
      ownAccounts: 5,
      sentToCbAt: '2026-07-28T14:35',
      cbResponse: 'ACK',
      ackFileName: 'WPS8872761204.ACK',
      cbPlatformRef: 'CBUAE-WPS-28Jl26-000118',
      chargeAmount: 72.0,
      vatAmount: 3.6,
    },
  },
  {
    id: 'sif-3',
    sifFileName: 'WPS109928601.SIF',
    originalFileName: 'ADNOC_Payroll_Aug2026.csv',
    systemRef: 'WPS-2026-00412',
    employerId: '100245880002211',
    employerName: 'ADNOC Distribution',
    employerAccount: 'AE450330000102211',
    salaryMonth: '08',
    salaryYear: '2026',
    initiatedAt: '2026-08-27T11:20',
    valueDate: '2026-08-27',
    records: 45,
    refundReturnCount: 2,
    totalSalary: 2845300,
    currency: 'AED',
    source: 'Host-to-Host (SFTP)',
    priority: 'Urgent',
    view360: {
      processingStatus: 'ACK Received',
      partiallyProcessed: 'N',
      initiatedBy: 'H2H Gateway',
      approvedBy: 'Omar Khalid',
      approvedAt: '2026-08-27T11:35',
      systemAccepted: 45,
      systemRejected: 0,
      ownAccounts: 18,
      sentToCbAt: '2026-08-27T11:50',
      cbResponse: 'ACK',
      ackFileName: 'WPS8872766610.ACK',
      cbPlatformRef: 'CBUAE-WPS-27Au26-000152',
      chargeAmount: 270.0,
      vatAmount: 13.5,
      refund: {
        rfrFileName: '0000004938801002151712601.RFR',
        rfrAckFileName: '000000493880100215171260161000000312.ACK',
        rsuFileName: 'RSU_0000004938801002151712601.RSU',
        refundRef: 'RFR-2026-00121',
        initiatedBy: 'Omar Rashid',
        approvedBy: 'Sooraj K',
        records: 2,
      },
    },
  },
  {
    id: 'sif-4',
    sifFileName: 'WPS109928490.SIF',
    originalFileName: 'AlNoor_WPS_June.xls',
    systemRef: 'WPS-2026-00288',
    employerId: '100399120004455',
    employerName: 'Al Noor Trading',
    employerTag: 'NOOR',
    employerAccount: 'AE910330000004455',
    salaryMonth: '06',
    salaryYear: '2026',
    initiatedAt: '2026-06-27T10:45',
    valueDate: '2026-06-28',
    records: 9,
    refundReturnCount: 0,
    totalSalary: 84900,
    currency: 'AED',
    source: 'Direct Entry (Branch)',
    priority: 'High',
    view360: {
      processingStatus: 'ACK Received',
      partiallyProcessed: 'N',
      initiatedBy: 'Branch User 07',
      approvedBy: 'Sara Mohammed',
      approvedAt: '2026-06-27T11:05',
      systemAccepted: 9,
      systemRejected: 0,
      ownAccounts: 4,
      sentToCbAt: '2026-06-27T11:20',
      cbResponse: 'ACK',
      ackFileName: 'WPS8872755021.ACK',
      cbPlatformRef: 'CBUAE-WPS-27Jn26-000097',
      chargeAmount: 54.0,
      vatAmount: 2.7,
    },
  },
];

const BANKS = [
  { name: 'Emirates NBD', code: '033000023' },
  { name: 'Mashreq Bank', code: '041000011' },
  { name: 'Abu Dhabi Commercial Bank', code: '026000019' },
  { name: 'First Abu Dhabi Bank', code: '035000016' },
];

const NAMES = [
  'Ahmed Khan', 'Priya Menon', 'Mohammed Rafi', 'Joseph Mathew', 'Sara Ali', 'Imran Qureshi', 'Fatima Noor',
  'Rahul Nair', 'Aisha Rahman', 'Omar Siddiqui', 'Deepa Pillai', 'Yusuf Hassan', 'Neha Sharma', 'Khalid Saeed',
];

/** Builds one EDR row; `refunded` / `history` default to a record never refunded. */
function edr(
  sif: SifFile,
  sl: number,
  name: string,
  bank: { name: string; code: string },
  incomeFixed: number,
  incomeVariable: number,
  refunded = 0,
  history: SettledTransaction['history'] = [],
): EdrRecord {
  const employeeId = `110000000${String(3722 + sl).padStart(5, '0')}`;
  return {
    id: `${sif.id}-edr-${sl}`,
    rail: 'WPS',
    sl,
    employeeId,
    bankCode: bank.code,
    incomeFixed,
    incomeVariable,
    // The record's reference in the refund summary: the SIF's system reference and its line.
    txnRef: `${sif.systemRef}/${String(sl).padStart(3, '0')}`,
    e2eId: employeeId,
    valueDate: sif.valueDate,
    debtorName: sif.employerName,
    debtorAccount: sif.employerAccount,
    creditorName: name,
    creditorAccount: `AE${10 + ((sl * 37) % 89)}0410011000000${String(3722 + sl).padStart(6, '0')}`,
    creditorBank: bank.name,
    channel: sif.source,
    records: 1,
    originalAmount: incomeFixed + incomeVariable,
    refundedAmount: refunded,
    history,
  };
}

/** The Emirates Steel August SIF, record for record as the design shows it. */
function emiratesSteelAug(sif: SifFile): EdrRecord[] {
  const [enbd, mashreq, adcb] = BANKS;
  return [
    { ...edr(sif, 1, 'Ahmed Khan', enbd, 100000, 0), creditorAccount: 'AE670410011000000003723' },
    {
      ...edr(sif, 2, 'Priya Menon', enbd, 85000, 2500, 20000, [
        { ref: 'RFR-2026-00098', at: '2026-08-30T10:15:00', amount: 12000, reason: 'Wrong amount', status: 'Completed' },
        { ref: 'RFR-2026-00112', at: '2026-09-04T15:40:00', amount: 8000, reason: 'Wrong amount', status: 'Completed' },
      ]),
      creditorAccount: 'AE400410011000000003724',
    },
    {
      ...edr(sif, 3, 'Mohammed Rafi', mashreq, 92000, 0, 0, [
        { ref: 'RFR-2026-00127', at: '2026-09-10T11:05:00', amount: 30000, reason: 'Undue payment', status: 'In Progress' },
      ]),
      creditorAccount: 'AE130410011000000003725',
    },
    { ...edr(sif, 4, 'Joseph Mathew', mashreq, 78500, 1200), creditorAccount: 'AE830410011000000003726' },
    { ...edr(sif, 5, 'Sara Ali', enbd, 96000, 0), creditorAccount: 'AE560410011000000003727' },
    {
      ...edr(sif, 6, 'Imran Qureshi', adcb, 88250, 750, 89000, [
        { ref: 'RFR-2026-00104', at: '2026-09-01T09:20:00', amount: 89000, reason: 'Duplicate payment', status: 'Completed' },
      ]),
      creditorAccount: 'AE290410011000000003728',
    },
    { ...edr(sif, 7, 'Fatima Noor', enbd, 71200, 0), creditorAccount: 'AE020410011000000003729' },
  ];
}

/** Plausible records for the other SIFs, one per declared record. */
function generated(sif: SifFile): EdrRecord[] {
  return Array.from({ length: sif.records }, (_, i) => {
    const sl = i + 1;
    const fixed = 40000 + ((sl * 7919) % 60) * 1000;
    const variable = sl % 3 === 0 ? 1500 : 0;
    return edr(sif, sl, NAMES[i % NAMES.length], BANKS[i % BANKS.length], fixed, variable);
  });
}

/** EDR records per SIF id. */
export const EDR_RECORDS: Record<string, EdrRecord[]> = Object.fromEntries(
  SIF_FILES.map((sif) => [sif.id, sif.id === 'sif-1' ? emiratesSteelAug(sif) : generated(sif)]),
);

export type RfrStatus = 'Pending' | 'CB Pending' | 'ACK' | 'NAK' | 'Rejected';
export type RfrChannel = 'Web Portal' | 'IB' | 'CBX' | 'MB';

/**
 * One RFR (refund request file) raised for WPS — the History tab lists them file-wise. A request
 * still awaiting approval has no RFR file or reference yet.
 */
export interface RfrHistoryEntry {
  id: string;
  rfrFileName: string | null;
  /** The RFR reference, once the file is generated (after Checker approval). */
  rfrRef: string | null;
  /** The refund request's reference — the RFR reference, or a provisional one while it awaits approval. */
  requestRef: string;
  /** The SIF's system reference number. */
  systemRef: string;
  /** `YYYY-MM-DDTHH:mm` */
  rfrInitiatedAt: string;
  txnInitiatedAt: string;
  initiatedBy: string;
  employerName: string;
  employerId: string;
  employerAccount: string;
  sifFileName: string;
  originalFileName: string;
  valueDate: string;
  records: number;
  acceptedCount: number;
  rejectedCount: number;
  pendingCount: number;
  totalRefund: number;
  currency: string;
  totalCharges: number;
  chargeWaived: boolean;
  channel: RfrChannel;
  priority: SifPriority;
  status: RfrStatus;
}

type RfrSeed = [
  rfrFileName: string | null,
  rfrRef: string | null,
  rfrInitiatedAt: string,
  txnInitiatedAt: string,
  initiatedBy: string,
  employerName: string,
  employerId: string,
  sifFileName: string,
  originalFileName: string,
  valueDate: string,
  records: number,
  counts: [accepted: number, rejected: number, pending: number],
  totalRefund: number,
  totalCharges: number,
  channel: RfrChannel,
  priority: SifPriority,
  status: RfrStatus,
];

const ES = ['Emirates Steel LLC', '808977026654343', 'WPS109928838.SIF', 'EmiratesSteel_Salary_Aug26.xlsx', '2026-08-28'] as const;

/** Employer account numbers by MOL ID, for the Employer Account Number search. */
const EMPLOYER_ACCOUNTS: Record<string, string> = {
  '808977026654343': 'AE070331452100001',
  '100245880002211': 'AE450330000102211',
};

const RFR_SEEDS: RfrSeed[] = [
  [null, null, '2026-09-29T09:10', '2026-08-27T09:30', 'Omar Rashid', ES[0], ES[1], ES[2], ES[3], ES[4], 3, [0, 0, 3], 263500, 22.05, 'Web Portal', 'Urgent', 'Pending'],
  [null, null, '2026-09-29T08:42', '2026-08-27T11:20', 'Priya Nair', 'ADNOC Distribution', '100245880002211', 'WPS109928601.SIF', 'ADNOC_Payroll_Aug2026.csv', '2026-08-27', 5, [0, 0, 5], 42750, 26.25, 'IB', 'Urgent', 'Pending'],
  [null, null, '2026-09-29T08:15', '2026-09-17T09:15', 'I-Business (corp.user01)', 'Majid Al Futtaim', '100511230007788', 'WPS109928264.SIF', 'MajidAlFuttaim_Salary_28264.xlsx', '2026-09-17', 2, [0, 0, 2], 18400, 19.95, 'IB', 'Normal', 'Pending'],
  ['0000004938801002061712590.RFR', 'RFR-2026-00128', '2026-09-29T07:55', '2026-09-17T09:15', 'Omar Rashid', 'DEWA', '100600450001234', 'WPS109928281.SIF', 'DEWA_Salary_28281.xlsx', '2026-09-17', 4, [0, 0, 4], 31900, 24.15, 'Web Portal', 'Normal', 'CB Pending'],
  [null, null, '2026-09-28T16:20', '2026-08-27T09:30', 'Omar Rashid', ES[0], ES[1], ES[2], ES[3], ES[4], 1, [0, 0, 1], 30000, 17.85, 'Web Portal', 'Urgent', 'Pending'],
  ['0000004938801002051712580.RFR', 'RFR-2026-00126', '2026-09-28T15:30', '2026-09-16T09:15', 'Suresh Babu', 'Etisalat Group', '100700980004321', 'WPS109928298.SIF', 'EtisalatGroup_Salary_28298.xlsx', '2026-09-16', 2, [0, 2, 0], 14200, 19.95, 'CBX', 'Normal', 'NAK'],
  ['0000006064821001071642330.RFR', 'RFR-2026-00124', '2026-09-28T11:05', '2026-09-16T09:15', 'Priya Nair', 'Emaar Properties', '100802310005566', 'WPS109928315.SIF', 'EmaarProperties_Salary_28315.xlsx', '2026-09-16', 6, [0, 0, 6], 58600, 28.35, 'IB', 'High', 'ACK'],
  ['0000004938801002151712590.RFR', 'RFR-2026-00121', '2026-09-26T10:20', '2026-09-14T09:15', 'Omar Rashid', 'Al Futtaim Motors', '100903440006677', 'WPS109928332.SIF', 'AlFuttaimMotors_Salary_28332.xlsx', '2026-09-14', 4, [0, 0, 4], 27300, 24.15, 'Web Portal', 'Normal', 'ACK'],
  ['0000004938801002101712590.RFR', 'RFR-2026-00119', '2026-09-25T14:45', '2026-09-13T09:15', 'Suresh Babu', 'Dubai Holding', '101004550007788', 'WPS109928349.SIF', 'DubaiHolding_Salary_28349.xlsx', '2026-09-13', 3, [0, 0, 3], 3000, 22.05, 'MB', 'Normal', 'ACK'],
  ['0000004938801002011712590.RFR', 'RFR-2026-00115', '2026-09-22T09:30', '2026-09-10T09:15', 'Omar Rashid', 'Nakheel PJSC', '101105660008899', 'WPS109928366.SIF', 'NakheelPJSC_Salary_28366.xlsx', '2026-09-10', 2, [2, 0, 0], 9800, 19.95, 'Web Portal', 'Normal', 'ACK'],
  [null, 'RFR-2026-00112', '2026-09-20T12:10', '2026-09-08T09:15', 'Priya Nair', 'Aldar Properties', '101206770009900', 'WPS109928383.SIF', 'AldarProperties_Salary_28383.xlsx', '2026-09-08', 3, [0, 3, 0], 21000, 22.05, 'IB', 'Normal', 'Rejected'],
  ['0000004938801001611712590.RFR', 'RFR-2026-00109', '2026-09-16T09:40', '2026-08-27T09:30', 'Priya Nair', ES[0], ES[1], ES[2], ES[3], ES[4], 1, [1, 0, 0], 89000, 17.85, 'Web Portal', 'Urgent', 'ACK'],
  [null, 'RFR-2026-00108', '2026-09-14T11:00', '2026-08-27T09:30', 'Omar Rashid', ES[0], ES[1], ES[2], ES[3], ES[4], 1, [0, 1, 0], 15000, 17.85, 'Web Portal', 'Urgent', 'Rejected'],
  ['0000004938801001011712590.RFR', 'RFR-2026-00105', '2026-09-10T10:15', '2026-08-27T09:30', 'Omar Rashid', ES[0], ES[1], ES[2], ES[3], ES[4], 1, [1, 0, 0], 20000, 17.85, 'Web Portal', 'Urgent', 'ACK'],
];

/** The WPS refund history, newest RFR first, exactly as the design lists it. */
/** Provisional references of requests still awaiting approval, by row — RFR references are issued on approval. */
const PROVISIONAL_REFS: Record<number, string> = { 0: 'RFR-2026-00131', 1: 'RFR-2026-00130', 2: 'RFR-2026-00129', 4: 'RFR-2026-00127' };

/** System reference of a SIF: the known ones, else built from the file's number. */
const SYSTEM_REFS: Record<string, string> = { 'WPS109928838.SIF': 'WPS-2026-00419', 'WPS109928601.SIF': 'WPS-2026-00412' };

export const RFR_HISTORY: readonly RfrHistoryEntry[] = RFR_SEEDS.map((s, i) => {
  const [rfrFileName, rfrRef, rfrInitiatedAt, txnInitiatedAt, initiatedBy, employerName, employerId, sifFileName, originalFileName, valueDate, records, [acceptedCount, rejectedCount, pendingCount], totalRefund, totalCharges, channel, priority, status] = s;
  return {
    id: `rfr-${i + 1}`,
    rfrFileName,
    rfrRef,
    requestRef: rfrRef ?? PROVISIONAL_REFS[i] ?? `RFR-2026-${String(140 - i).padStart(5, '0')}`,
    systemRef: SYSTEM_REFS[sifFileName] ?? `WPS-2026-00${sifFileName.slice(-7, -4)}`,
    rfrInitiatedAt,
    txnInitiatedAt,
    initiatedBy,
    employerName,
    employerId,
    employerAccount: EMPLOYER_ACCOUNTS[employerId] ?? `AE${employerId.slice(-10).padStart(19, '0')}`,
    sifFileName,
    originalFileName,
    valueDate,
    records,
    acceptedCount,
    rejectedCount,
    pendingCount,
    totalRefund,
    currency: 'AED',
    totalCharges,
    chargeWaived: false,
    channel,
    priority,
    status,
  };
});

export type RfrRecordOutcome = 'Accepted' | 'Rejected' | 'Pending';

/** Tone of a record's Current Stage pill. */
export type RfrStageTone = 'amber' | 'blue' | 'green' | 'red';

/** One employee record inside an RFR — the RFR Details section under the History grid. */
export interface RfrRecord {
  sl: number;
  refundRef: string;
  systemRef: string;
  sifFileName: string;
  originalFileName: string;
  employeeId: string;
  employeeName: string;
  employerName: string;
  totalSalary: number;
  amount: number;
  refundType: 'Full' | 'Partial';
  reason: string;
  initiatedBy: string;
  initiatedAt: string;
  stage: string;
  stageTone: RfrStageTone;
  status: RfrRecordOutcome;
  /** When the record reached its status; null while pending. */
  statusDate: string | null;
}

const RFR_REASONS = ['Employee left before credit', 'Duplicate salary payment', 'Incorrect salary amount', 'Wrong beneficiary account'];

/** `iso` plus `days`, as `YYYY-MM-DDTHH:mm`. */
function addDays(iso: string, days: number): string {
  // date-format-ok-begin: mock-data arithmetic on zoneless wall-clock strings, not display
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
  // date-format-ok-end
}

/** Where a record stands, from its RFR's status and its own RSU outcome. */
function stageOf(e: RfrHistoryEntry, outcome: RfrRecordOutcome): { stage: string; tone: RfrStageTone; status: RfrRecordOutcome; decided: boolean } {
  switch (e.status) {
    case 'Pending':
      return { stage: 'Pending Checker Verification', tone: 'amber', status: 'Pending', decided: false };
    case 'CB Pending':
      return { stage: 'Sent to CB — Awaiting RSU', tone: 'blue', status: 'Pending', decided: false };
    case 'NAK':
      return { stage: 'CB NAK — File Rejected', tone: 'red', status: 'Rejected', decided: true };
    case 'Rejected':
      return { stage: 'Rejected by Checker', tone: 'red', status: 'Rejected', decided: true };
    default:
      // ACK — each record then has its own RSU outcome.
      if (outcome === 'Accepted') return { stage: 'Refund Credited to Employer', tone: 'green', status: 'Accepted', decided: true };
      if (outcome === 'Rejected') return { stage: 'RSU Rejected', tone: 'red', status: 'Rejected', decided: true };
      return { stage: 'CB ACK — Awaiting RSU', tone: 'blue', status: 'Pending', decided: false };
  }
}

/**
 * The employee records behind one RFR: its record count split by its RSU outcome counts, and its
 * total refund split across them (the last record takes any rounding remainder). Each record is
 * refunded in full, so its total salary equals its refund amount.
 */
export function rfrRecords(e: RfrHistoryEntry): RfrRecord[] {
  const outcomes: RfrRecordOutcome[] = [
    ...Array<RfrRecordOutcome>(e.acceptedCount).fill('Accepted'),
    ...Array<RfrRecordOutcome>(e.rejectedCount).fill('Rejected'),
    ...Array<RfrRecordOutcome>(e.pendingCount).fill('Pending'),
  ];
  const share = Math.floor((e.totalRefund / e.records) * 100) / 100;
  return Array.from({ length: e.records }, (_, i) => {
    const sl = i + 1;
    const amount = sl === e.records ? Math.round((e.totalRefund - share * (e.records - 1)) * 100) / 100 : share;
    const s = stageOf(e, outcomes[i] ?? 'Pending');
    return {
      sl,
      refundRef: e.requestRef,
      systemRef: e.systemRef,
      sifFileName: e.sifFileName,
      originalFileName: e.originalFileName,
      employeeId: `110000000${String(5016 + sl).padStart(4, '0')}`,
      employeeName: NAMES[(i + 3) % NAMES.length],
      employerName: e.employerName,
      totalSalary: amount,
      amount,
      refundType: 'Full',
      reason: RFR_REASONS[i % RFR_REASONS.length],
      initiatedBy: e.initiatedBy,
      initiatedAt: e.rfrInitiatedAt,
      stage: s.stage,
      stageTone: s.tone,
      status: s.status,
      statusDate: s.decided ? addDays(e.rfrInitiatedAt, 1) : null,
    };
  });
}
/** The CB's files for an RFR, derived from its RFR file name. */
export function rfrCbFiles(e: RfrHistoryEntry) {
  const base = e.rfrFileName?.replace(/\.RFR$/i, '');
  const answered = e.status === 'ACK' || e.status === 'NAK';
  const settled = e.acceptedCount + e.rejectedCount > 0;
  return {
    rfr: e.rfrFileName,
    ack: base && answered ? `${base.slice(0, -1)}61000000224.${e.status === 'NAK' ? 'NAK' : 'ACK'}` : null,
    ackDetail: base && answered ? `${base.slice(0, -1)}61000000224_DETAIL.XML` : null,
    rsu: base && settled ? `RSU_${base}.RSU` : null,
  };
}
