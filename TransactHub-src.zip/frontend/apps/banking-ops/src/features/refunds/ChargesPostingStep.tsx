import { useCallback, useState } from 'react';
import type { ReactNode } from 'react';
import { ArrowLeft } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { ConfirmDialog } from '../UserManagement/User/ConfirmDialog';
import { CHARGE_POSTING_GL, RECALL_MESSAGE, REFUND_CHARGES, balanceOf, formatAmount, reasonText } from './data';
import type { RefundRail, RefundRecord } from './data';

const CARD = 'rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 shadow-[var(--shadow-sm)]';
const CARD_TITLE = 'text-[15px] font-bold text-[var(--text-primary)]';
const TH = 'px-4 py-2.5 text-left text-xs font-bold uppercase tracking-wider text-[var(--text-primary)]';

/** "Label ........ value" line of the summary and charge cards. */
function Line({ label, value, mono }: { label: ReactNode; value: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-[var(--border)] py-2 last:border-b-0">
      <span className="text-sm text-[var(--text-muted)]">{label}</span>
      <span className={cn('text-right text-sm font-semibold text-[var(--text-primary)]', mono && 'font-mono text-xs')}>{value}</span>
    </div>
  );
}

/**
 * The charges a refund of `records` rows carries, from the configured rates. Waiving keeps each
 * line (shown struck through) and only zeroes the total the debtor pays.
 */
export function refundCharges(records: number, waived: boolean) {
  const perRecord = REFUND_CHARGES.perRecord * records;
  const cb = REFUND_CHARGES.cbPerRecord * records;
  const vat = Math.round((perRecord + cb) * REFUND_CHARGES.vatRate * 100) / 100;
  return { perRecord, cb, vat, total: waived ? 0 : perRecord + cb + vat };
}

/** A charge line's amount, struck through and muted while charges are waived. */
function ChargeValue({ amount, waived }: { amount: number; waived: boolean }) {
  return waived ? (
    <s className="text-[var(--text-muted)]">AED {formatAmount(amount)}</s>
  ) : (
    <>AED {formatAmount(amount)}</>
  );
}

/**
 * Step 2 — Charges & Posting: what will be refunded, the charges the debtor pays for it, the
 * postings those charges make, and the maker's remarks for the Checker. Submit sends the request
 * for Checker approval; Previous returns to the record selection with it intact.
 */
export function ChargesPostingStep({
  rail,
  records,
  onPrevious,
  onCancel,
  onSubmit,
}: {
  rail: RefundRail;
  records: RefundRecord[];
  onPrevious: () => void;
  onCancel: () => void;
  onSubmit: (remarks: string, totalCharges: number) => void;
}) {
  const [waived, setWaived] = useState(false);
  const [remarks, setRemarks] = useState('');
  const [confirming, setConfirming] = useState(false);
  // Stable, so the dialog's Escape listener isn't re-registered on every render.
  const cancelConfirm = useCallback(() => setConfirming(false), []);

  const refundTotal = records.reduce((sum, r) => sum + r.amount, 0);
  const charges = refundCharges(records.length, waived);
  const debtorAccounts = [...new Set(records.map((r) => r.txn.debtorAccount))];
  const debtorNames = [...new Set(records.map((r) => r.txn.debtorName))];
  const debitAccount = debtorAccounts.join(', ');

  const postings = [
    { label: 'Refund Charge per Record', credit: CHARGE_POSTING_GL.perRecord },
    { label: 'CB Charge', credit: CHARGE_POSTING_GL.cb },
    { label: 'VAT', credit: CHARGE_POSTING_GL.vat },
  ];

  return (
    <>
      {/* Refund summary */}
      <section className={CARD}>
        <div className="mb-3 flex items-center justify-between gap-2">
          <h2 className={CARD_TITLE}>Refund Summary</h2>
          <span className="rounded-md bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] px-2 py-0.5 text-xs font-bold text-[var(--accent-blue)]">{rail.label}</span>
        </div>
        <div className="grid grid-cols-1 gap-x-8 lg:grid-cols-2">
          <div>
            <Line label="Original Txn Ref." value={records.map((r) => r.txn.txnRef).join(', ')} mono />
            <Line label="Recall Message" value={RECALL_MESSAGE} />
            <Line label="Refund Amount" value={`AED ${formatAmount(refundTotal)}`} />
          </div>
          <div>
            <Line label="Debtor Name" value={debtorNames.join(', ')} />
            <Line label="No. of Records" value={records.length} />
            <Line label="Total Refund Charges" value={`AED ${formatAmount(charges.total)}`} />
          </div>
        </div>
      </section>

      {/* Selected records */}
      <section className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-[var(--shadow-sm)]">
        <h2 className={cn(CARD_TITLE, 'px-5 py-4')}>Selected Records</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-[var(--bg-secondary)]">
              <tr>
                <th className={TH}>SL</th>
                <th className={TH}>Original Txn Ref.</th>
                <th className={TH}>Creditor Name</th>
                <th className={TH}>Creditor Account</th>
                <th className={TH}>Bank Name</th>
                <th className={cn(TH, '!text-right')}>Refund Amount (AED)</th>
                <th className={TH}>Refund Type</th>
                <th className={TH}>Refund Reason</th>
              </tr>
            </thead>
            <tbody>
              {records.map((r, i) => {
                // Full when it refunds everything still left on the transaction.
                const full = r.amount >= balanceOf(r.txn);
                return (
                  <tr key={r.txn.id} className="border-t border-[var(--border)] text-[var(--text-primary)]">
                    <td className="px-4 py-3 text-[var(--text-muted)]">{i + 1}</td>
                    <td className="px-4 py-3 font-mono text-xs">{r.txn.txnRef}</td>
                    <td className="px-4 py-3">{r.txn.creditorName}</td>
                    <td className="px-4 py-3 font-mono text-xs">{r.txn.creditorAccount}</td>
                    <td className="px-4 py-3">{r.txn.creditorBank}</td>
                    <td className="px-4 py-3 text-right font-bold tabular-nums">{formatAmount(r.amount)}</td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          'inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold',
                          full
                            ? 'bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] text-[var(--accent-blue)]'
                            : 'bg-orange-500/15 text-orange-600',
                        )}
                      >
                        {full ? 'Full Refund' : 'Partial Refund'}
                      </span>
                    </td>
                    <td className="px-4 py-3">{reasonText(r.reason)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
        {/* Charges */}
        <section className={cn(CARD, 'self-start')}>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className={CARD_TITLE}>Transaction Charge Details</h2>
            <span className="rounded-md bg-[color-mix(in_srgb,var(--accent-amber)_15%,transparent)] px-2 py-0.5 text-xs font-semibold text-[var(--accent-amber)]">
              Charge Source: Charge Configuration
            </span>
          </div>
          <Line
            label={
              <>
                Refund Charge per Record{' '}
                <span className="opacity-70">
                  (AED {formatAmount(REFUND_CHARGES.perRecord)} × {records.length} records)
                </span>
              </>
            }
            value={<ChargeValue amount={charges.perRecord} waived={waived} />}
          />
          <Line
            label={
              <>
                CB Charge{' '}
                <span className="opacity-70">
                  (AED {formatAmount(REFUND_CHARGES.cbPerRecord)} × {records.length} records)
                </span>
              </>
            }
            value={<ChargeValue amount={charges.cb} waived={waived} />}
          />
          <Line label={`VAT (${REFUND_CHARGES.vatRate * 100}%)`} value={<ChargeValue amount={charges.vat} waived={waived} />} />
          <label className="mt-3 flex w-fit cursor-pointer items-center gap-2 text-sm text-[var(--text-primary)]">
            <input type="checkbox" checked={waived} onChange={(e) => setWaived(e.target.checked)} className="size-4 accent-[var(--primary-blue)]" />
            Waive charges
          </label>
          {waived && (
            <p role="status" className="mt-3 rounded-lg border border-orange-500/30 bg-orange-500/10 px-4 py-3 text-sm text-orange-700">
              Charges waived — state the reason for waiving in Remarks.
            </p>
          )}
          <div className="mt-3 flex items-center justify-between gap-3 rounded-lg border border-[color-mix(in_srgb,var(--accent-blue)_30%,transparent)] bg-[color-mix(in_srgb,var(--accent-blue)_10%,transparent)] px-4 py-3 font-bold text-[var(--accent-blue)]">
            <span>Total Refund Charges</span>
            <span className="flex items-center gap-2">
              <span className="tabular-nums">AED {formatAmount(charges.total)}</span>
              {waived && (
                <span className="rounded-full bg-[color-mix(in_srgb,var(--accent-green)_15%,transparent)] px-2.5 py-0.5 text-xs font-semibold text-[var(--accent-green)]">
                  Waived
                </span>
              )}
            </span>
          </div>
          <p className="mt-3 text-xs text-[var(--text-muted)]">Charges are debited from Debtor A/C {debitAccount}.</p>
        </section>

        <div className="flex flex-col gap-5">
          {/* Postings */}
          <section className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-[var(--shadow-sm)]">
            <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-4">
              <h2 className={CARD_TITLE}>Posting Details</h2>
              <span className="text-xs text-[var(--text-muted)]">Accounts as per GL mapping</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-[var(--bg-secondary)]">
                  <tr>
                    <th className={TH}>#</th>
                    <th className={TH}>Posting</th>
                    <th className={TH}>Debit</th>
                    <th className={TH}>Credit</th>
                    <th className={TH}>Posted On</th>
                    <th className={TH}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {postings.map((p, i) => (
                    <tr key={p.label} className="border-t border-[var(--border)] text-[var(--text-primary)]">
                      <td className="px-4 py-3 text-[var(--text-muted)]">{i + 1}</td>
                      <td className="whitespace-nowrap px-4 py-3 font-bold">{p.label}</td>
                      <td className="whitespace-nowrap px-4 py-3">Debtor A/C {debitAccount}</td>
                      <td className="whitespace-nowrap px-4 py-3">{p.credit}</td>
                      <td className="whitespace-nowrap px-4 py-3">Checker verification</td>
                      <td className="px-4 py-3">
                        <span className="inline-block whitespace-nowrap rounded-full bg-[var(--bg-3)] px-2.5 py-0.5 text-xs font-semibold text-[var(--text-2)]">
                          {waived ? 'Waived' : 'Pending'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Remarks */}
          <section className={CARD}>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <label htmlFor="rf-remarks" className={CARD_TITLE}>
                Remarks <span className="text-[var(--accent-red)]">*</span>
              </label>
              <span className="text-xs text-[var(--text-muted)]">Mandatory — visible to the Checker</span>
            </div>
            <textarea
              id="rf-remarks"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="Enter remarks for this refund request..."
              rows={3}
              maxLength={500}
              required
              className="input-cls w-full resize-y text-sm"
            />
          </section>
        </div>
      </div>

      {/* Totals and actions — the same card strip as step 1's selection strip, shadow on its top edge only. */}
      <div
        role="region"
        aria-label="Refund totals"
        className="sticky bottom-3 z-20 flex flex-wrap items-center gap-x-8 gap-y-3 rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-5 text-[var(--text-primary)] shadow-[0_-8px_24px_-6px_rgba(15,23,42,0.22)]"
      >
        <div>
          <p className="text-xs opacity-75">Records</p>
          <p className="text-base font-bold">{records.length}</p>
        </div>
        <div>
          <p className="text-xs opacity-75">Refund Amount</p>
          <p className="text-base font-bold tabular-nums">AED {formatAmount(refundTotal)}</p>
        </div>
        <div>
          <p className="text-xs opacity-75">Total Refund Charges</p>
          <p className="text-base font-bold tabular-nums">AED {formatAmount(charges.total)}</p>
        </div>
        <div className="ml-auto flex gap-3">
          <button
            type="button"
            onClick={onPrevious}
            className="btn-secondary large-btn justify-center !py-2.5 text-sm"
          >
            <ArrowLeft size={15} aria-hidden="true" />
            Previous
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="btn-tertiary large-btn justify-center !py-2.5 text-sm"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => setConfirming(true)}
            disabled={!remarks.trim()}
            title={!remarks.trim() ? 'Enter remarks for the Checker' : undefined}
            className="btn-primary large-btn justify-center !py-2.5 text-sm disabled:cursor-not-allowed disabled:opacity-50"
          >
            Submit
          </button>
        </div>
      </div>

      {confirming && (
        <ConfirmDialog
          title="Submit Refund Request"
          confirmLabel="Submit"
          cancelLabel="Cancel"
          onCancel={cancelConfirm}
          onConfirm={() => {
            setConfirming(false);
            onSubmit(remarks.trim(), charges.total);
          }}
        >
          Submit{' '}
          <strong className="text-[var(--text-primary)]">
            {records.length} {rail.label} refund request(s)
          </strong>{' '}
          totalling <strong className="text-[var(--text-primary)]">AED {formatAmount(refundTotal)}</strong> for Checker
          verification? One request is created per transaction.
        </ConfirmDialog>
      )}
    </>
  );
}
