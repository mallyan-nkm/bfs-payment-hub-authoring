/**
 * Contracts of the RRI checker API (design Inward_RRI_Checker_Release v1.0 §4.2–§4.4; task T8).
 * They mirror `PaymentHub.WpsBusiness.API.DTOs.RriChecker`. Nothing here is static data: every list comes from the endpoints.
 */

export type RriCheckerView = 'release' | 'expired';

export interface RriCheckerActions {
  release: boolean;
  reject: boolean;
}

export interface RriCheckerFile {
  transactionId: string;
  fileName: string;
  establishmentReference: string | null;
  lineCount: number;
  totalAmount: number;
  state: string | null;
  stateAt: string | null;
  verificationNo: number;
  markerCounts: Record<string, number>;
  acceptedCount: number;
  rejectedCount: number;
  actions: RriCheckerActions;
}

/** One grid line. The API carries no account, person ID or block reference (I-11). */
export interface RriCheckerLine {
  drrId: number;
  lineNo: number;
  refundAmount: number;
  refundType: string;
  marker: string;
  notEligibleReason: string | null;
  decision: string | null;
  reasonCode: string | null;
}

export interface RriCheckerLinesPage {
  transactionId: string;
  verificationNo: number;
  page: number;
  size: number;
  lineCount: number;
  lines: RriCheckerLine[];
}

export interface RriCheckerActionResponse {
  lineCount: number;
  verificationNo: number;
  replayed: boolean;
  message: string;
}

export type RriCheckerAction = 'release' | 'reject';
