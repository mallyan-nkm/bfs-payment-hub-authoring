import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiError, apiOk, grant, renderWithProviders } from '../../../test/renderWithProviders';
import { RriCheckerPage } from './RriCheckerPage';
import type { RriCheckerFile, RriCheckerLinesPage } from './types';

// Every response here is mocked; the server-side gates are proven in tests/PaymentHub.IntegrationTests (RriCheckerAuthorizationTests).
vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

const file = (id: string, release: boolean, reject: boolean): RriCheckerFile => ({
  transactionId: id,
  fileName: `${id}.RRI`,
  establishmentReference: 'EST-1',
  lineCount: 2,
  totalAmount: 200,
  state: 'RRI-Maker-Verified',
  stateAt: null,
  verificationNo: 1,
  markerCounts: { BLOCKED: 1, NOT_ELIGIBLE: 1 },
  acceptedCount: 1,
  rejectedCount: 1,
  actions: { release, reject },
});

const LINES: RriCheckerLinesPage = {
  transactionId: 'TX-A',
  verificationNo: 1,
  page: 1,
  size: 100,
  lineCount: 2,
  lines: [
    { drrId: 11, lineNo: 1, refundAmount: 100, refundType: 'DIF', marker: 'BLOCKED', notEligibleReason: null, decision: 'ACCEPTED', reasonCode: '000' },
    { drrId: 12, lineNo: 2, refundAmount: 100, refundType: 'RFA', marker: 'NOT_ELIGIBLE', notEligibleReason: 'NOT_ON_DIF', decision: 'REJECTED', reasonCode: 'X1' },
  ],
};

function serve(release: RriCheckerFile[], expired: RriCheckerFile[] = []) {
  get.mockImplementation((url: string, config?: { params?: { view?: string } }) => {
    if (url.endsWith('/files')) return Promise.resolve(apiOk(config?.params?.view === 'expired' ? expired : release));
    if (url.endsWith('/lines')) return Promise.resolve(apiOk(LINES));
    return Promise.reject(new Error(`unexpected GET ${url}`));
  });
}

async function rows(name: string) {
  const table = await screen.findByRole('table', { name });
  return within(table).getAllByRole('row').slice(1);
}

describe('RRI checker block release (design Inward_RRI_Checker_Release v1.0 §4; task T8)', () => {
  beforeEach(() => {
    grant(PERM.railWps, PERM.rriCheckerPage, PERM.rriCheckerApprove);
    get.mockReset();
    post.mockReset();
  });

  it('AC-UI-01: each row shows only the buttons its actions allow, in two tabs', async () => {
    serve([file('TX-A', true, true), file('TX-B', false, false)], [file('TX-E', true, false)]);
    renderWithProviders(<RriCheckerPage />);

    const [a, b] = await rows('RRI files forwarded by the maker');
    expect(within(a).getByRole('button', { name: 'Release' })).toBeInTheDocument();
    expect(within(a).getByRole('button', { name: 'Reject RRI' })).toBeInTheDocument();
    expect(within(b).queryByRole('button', { name: 'Release' })).toBeNull();
    expect(within(b).queryByRole('button', { name: 'Reject RRI' })).toBeNull();

    await userEvent.click(screen.getByRole('button', { name: 'Expired with holds' }));
    const [e] = await rows('Expired RRI files with holds');
    expect(within(e).getByRole('button', { name: 'Release' })).toBeInTheDocument();
    expect(within(e).queryByRole('button', { name: 'Reject RRI' })).toBeNull();
  });

  it('RRI4 AC-AUTH-03 / H-RRI5-1: the maker/checker switch grants nothing; without the approve key neither decision can be used', async () => {
    grant(PERM.railWps, PERM.rriCheckerPage);
    serve([file('TX-A', true, true)]);
    renderWithProviders(<RriCheckerPage />);

    const [a] = await rows('RRI files forwarded by the maker');
    const usable = within(a)
      .queryAllByRole('button')
      .filter((b) => ['Release', 'Reject RRI'].includes(b.textContent ?? '') && !(b as HTMLButtonElement).disabled);
    expect(usable).toEqual([]);
    expect(post).not.toHaveBeenCalled();
  });

  it('AC-UI-02: confirms, sends one request key per opened file (a retry reuses it), and refreshes', async () => {
    serve([file('TX-A', true, true)]);
    post.mockResolvedValue(apiOk({ lineCount: 1, verificationNo: 1, replayed: false, message: 'RRI Block Release Initiated by Bank Checker' }));
    renderWithProviders(<RriCheckerPage />);
    const [a] = await rows('RRI files forwarded by the maker');

    await userEvent.click(within(a).getByRole('button', { name: 'Release' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Confirm' }));
    expect(await screen.findByText('RRI Block Release Initiated by Bank Checker (1 lines).')).toBeInTheDocument();
    const filesCallsAfterFirst = get.mock.calls.filter(([url]) => url.endsWith('/files')).length;

    const [again] = await rows('RRI files forwarded by the maker');
    await userEvent.click(within(again).getByRole('button', { name: 'Release' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Confirm' }));

    expect(post).toHaveBeenCalledTimes(2);
    const [firstUrl, firstBody] = post.mock.calls[0];
    expect(firstUrl).toBe('/wps/rri/checker/files/TX-A/release');
    expect(post.mock.calls[1][1]).toEqual(firstBody);
    expect(filesCallsAfterFirst).toBeGreaterThan(1);
  });

  it('AC-UI-03: a 409 shows its message; a 500 shows the trace id', async () => {
    serve([file('TX-A', true, true)]);
    post.mockRejectedValueOnce(apiError(409, 'conflict', 'Conflict', { code: 'RRI_CHECKER_RELEASE_EXISTS' }));
    renderWithProviders(<RriCheckerPage />);
    const [a] = await rows('RRI files forwarded by the maker');

    await userEvent.click(within(a).getByRole('button', { name: 'Reject RRI' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Confirm' }));
    expect(await screen.findByText('The release of this RRI file has already been requested.')).toBeInTheDocument();

    post.mockRejectedValueOnce(apiError(500, 'fault', 'Error', { code: 'RRI_CHECKER_UNAVAILABLE', traceId: 'trace-77' }));
    const [again] = await rows('RRI files forwarded by the maker');
    await userEvent.click(within(again).getByRole('button', { name: 'Reject RRI' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Confirm' }));
    expect(await screen.findByText(/Reference: trace-77\./)).toBeInTheDocument();
  });

  it('AC-UI-04: the grid is read-only, from the endpoint, with the maker decision and no account or person ID', async () => {
    serve([file('TX-A', true, true)]);
    renderWithProviders(<RriCheckerPage />);
    const [a] = await rows('RRI files forwarded by the maker');

    await userEvent.click(within(a).getByRole('button', { name: 'TX-A.RRI' }));
    const lines = await rows('RRI lines');

    expect(lines).toHaveLength(2);
    expect(within(lines[1]).getByText('NOT_ELIGIBLE (NOT_ON_DIF)')).toBeInTheDocument();
    expect(within(lines[0]).getByText('ACCEPTED')).toBeInTheDocument();
    expect(screen.queryByRole('combobox')).toBeNull();
    expect(get).toHaveBeenCalledWith('/wps/rri/checker/files/TX-A/lines', { params: { page: 1, size: 100 } });
  });
});

// Design Inward_RRI_Checker_Release v1.1 §4.5, §8.1, S3-1; task W2.
describe('RRI checker v1.1: the 403 message and the release outcome labels (task W2)', () => {
  const OUTCOME_LINES: RriCheckerLinesPage = {
    ...LINES,
    lineCount: 4,
    lines: [
      { drrId: 21, lineNo: 1, refundAmount: 100, refundType: 'DIF', marker: 'RELEASED', notEligibleReason: null, decision: 'ACCEPTED', reasonCode: '000' },
      { drrId: 22, lineNo: 2, refundAmount: 100, refundType: 'DIF', marker: 'RELEASE_FAILED', notEligibleReason: null, decision: 'ACCEPTED', reasonCode: '000' },
      { drrId: 23, lineNo: 3, refundAmount: 100, refundType: 'DIF', marker: 'RELEASE_UNCONFIRMED', notEligibleReason: null, decision: 'ACCEPTED', reasonCode: '000' },
      { drrId: 24, lineNo: 4, refundAmount: 100, refundType: 'DIF', marker: 'RELEASE_REQUESTED', notEligibleReason: null, decision: 'ACCEPTED', reasonCode: '000' },
    ],
  };

  beforeEach(() => {
    grant(PERM.railWps, PERM.rriCheckerPage, PERM.rriCheckerApprove);
    get.mockReset();
    post.mockReset();
  });

  it('AC-UI-06: a 403 own-verification shows its own message, not the fault fallback, and refreshes the list', async () => {
    serve([file('TX-A', true, true)]);
    post.mockRejectedValueOnce(apiError(403, 'forbidden', 'Forbidden', { code: 'RRI_CHECKER_OWN_VERIFICATION' }));
    renderWithProviders(<RriCheckerPage />);
    const [a] = await rows('RRI files forwarded by the maker');
    const filesCallsBefore = get.mock.calls.filter(([url]) => url.endsWith('/files')).length;

    await userEvent.click(within(a).getByRole('button', { name: 'Release' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Confirm' }));

    expect(await screen.findByText('You cannot approve or reject your own request')).toBeInTheDocument();
    expect(screen.queryByText(/The RRI service is unavailable/)).toBeNull();
    await vi.waitFor(() =>
      expect(get.mock.calls.filter(([url]) => url.endsWith('/files')).length).toBeGreaterThan(filesCallsBefore),
    );
  });

  it('AC-UI-07: the counts and the grid show readable outcome labels, and no outcome word adds a button', async () => {
    const released: RriCheckerFile = {
      ...file('TX-R', false, false),
      lineCount: 4,
      markerCounts: { RELEASED: 1, RELEASE_FAILED: 1, RELEASE_UNCONFIRMED: 1, RELEASE_REQUESTED: 1 },
    };
    get.mockImplementation((url: string) => {
      if (url.endsWith('/files')) return Promise.resolve(apiOk([released]));
      if (url.endsWith('/lines')) return Promise.resolve(apiOk(OUTCOME_LINES));
      return Promise.reject(new Error(`unexpected GET ${url}`));
    });
    renderWithProviders(<RriCheckerPage />);

    const [r] = await rows('RRI files forwarded by the maker');
    expect(
      within(r).getByText('Released 1, Release failed 1, Release unconfirmed 1, Release requested 1'),
    ).toBeInTheDocument();
    expect(within(r).queryByRole('button', { name: 'Release' })).toBeNull();
    expect(within(r).queryByRole('button', { name: 'Reject RRI' })).toBeNull();

    await userEvent.click(within(r).getByRole('button', { name: 'TX-R.RRI' }));
    const lines = await rows('RRI lines');
    const labels = ['Released', 'Release failed', 'Release unconfirmed', 'Release requested'];
    lines.forEach((line, i) => expect(within(line).getByText(labels[i])).toBeInTheDocument());
    expect(screen.queryByText('RELEASE_FAILED')).toBeNull();
    lines.forEach((line) => expect(within(line).queryByRole('button')).toBeNull());
  });
});
