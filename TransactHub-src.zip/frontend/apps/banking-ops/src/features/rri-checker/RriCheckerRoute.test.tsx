import { render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import type { RouteObject } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { routes } from '../../router';
import { apiOk, grant } from '../../../test/renderWithProviders';

// The route guard's session check reads storage; a signed-in session is all these cases need (the approval-queue precedent).
vi.mock('@paymenthub/ui', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@paymenthub/ui')>()),
  getCurrentUserFromStorage: () => ({ id: 'u1' }),
}));
vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

function findRoute(list: RouteObject[], path: string): RouteObject | undefined {
  for (const r of list) {
    if (r.path === path) return r;
    const nested = r.children ? findRoute(r.children, path) : undefined;
    if (nested) return nested;
  }
  return undefined;
}

function mountRoute() {
  const route = findRoute(routes, 'wps/rri-checker');
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={['/wps/rri-checker']}>
        <Routes>
          <Route path="/wps/rri-checker" element={route?.element} />
          <Route path="/unauthorized" element={<p>Unauthorized</p>} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  );
}

// AC-UI-05 (design v1.1 §3.1, §9; task W2): the real route from the route tree, guarded on the checker's page key (132), not NO_BACKEND.
describe('RRI checker route guard (design Inward_RRI_Checker_Release v1.1 §9; AC-UI-05)', () => {
  beforeEach(() => {
    get.mockReset();
    get.mockResolvedValue(apiOk([]));
    localStorage.clear();
  });

  it('AC-UI-05: without the page key the page is not rendered', async () => {
    grant(PERM.railWps, PERM.rriMakerPage);
    mountRoute();

    expect(await screen.findByText('Unauthorized')).toBeInTheDocument();
    expect(screen.queryByText('RRI Checker — Block Release')).toBeNull();
  });

  it('AC-UI-05: with the page key the page renders', async () => {
    grant(PERM.railWps, PERM.rriCheckerPage);
    mountRoute();

    expect(await screen.findByText('RRI Checker — Block Release')).toBeInTheDocument();
    expect(screen.queryByText('Unauthorized')).toBeNull();
  });
});
