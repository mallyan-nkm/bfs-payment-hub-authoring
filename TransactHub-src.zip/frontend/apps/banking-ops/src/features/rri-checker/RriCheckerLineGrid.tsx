import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button, LoadingSpinner } from '@paymenthub/ui';
import { rriCheckerApi } from './api';
import { readCheckerProblem } from './errors';
import { useRriCheckerTranslation } from './i18n';
import { markerLabel } from './markerLabels';
import { rriCheckerKeys } from './queryKeys';
import type { RriCheckerFile } from './types';

const PAGE_SIZE = 100;

/**
 * The read-only lines of one file (design §4.2; AC-UI-04): composed marker, refund type and amount, and the maker's decision of
 * the forwarded verification. The API sends no account, person ID or block reference, so nothing needs masking here.
 */
export function RriCheckerLineGrid({ file }: { file: RriCheckerFile }) {
  const { t } = useRriCheckerTranslation();
  const [page, setPage] = useState(1);
  const lines = useQuery({
    queryKey: rriCheckerKeys.lines(file.transactionId, page),
    queryFn: () => rriCheckerApi.lines(file.transactionId, page, PAGE_SIZE),
  });

  if (lines.isPending) return <LoadingSpinner />;
  if (lines.isError) return <p role="alert">{readCheckerProblem(t, lines.error).message}</p>;

  const pages = Math.max(1, Math.ceil(lines.data.lineCount / PAGE_SIZE));
  return (
    <section className="mt-6 flex flex-col gap-3" aria-label={t('LINES.LINES_OF', { fileName: file.fileName })}>
      <div className="overflow-x-auto">
        <table className="w-full text-sm" aria-label={t('LINES.TABLE')}>
          <thead>
            <tr className="text-left text-[var(--text-secondary)]">
              <th className="p-2">{t('LINES.COLUMNS.LINE')}</th>
              <th className="p-2">{t('LINES.COLUMNS.REFUND_TYPE')}</th>
              <th className="p-2">{t('LINES.COLUMNS.AMOUNT')}</th>
              <th className="p-2">{t('LINES.COLUMNS.BLOCK_STATUS')}</th>
              <th className="p-2">{t('LINES.COLUMNS.MAKER_DECISION')}</th>
              <th className="p-2">{t('LINES.COLUMNS.REASON')}</th>
            </tr>
          </thead>
          <tbody>
            {lines.data.lines.map((l) => (
              <tr key={l.drrId}>
                <td className="p-2">{l.lineNo}</td>
                <td className="p-2">{l.refundType}</td>
                <td className="p-2">{l.refundAmount.toFixed(2)}</td>
                <td className="p-2" title={l.marker}>
                  {l.notEligibleReason ? `${markerLabel(t, l.marker)} (${l.notEligibleReason})` : markerLabel(t, l.marker)}
                </td>
                <td className="p-2">{l.decision ?? ''}</td>
                <td className="p-2">{l.reasonCode ?? ''}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex items-center gap-3">
        <Button variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
          {t('LINES.PREVIOUS')}
        </Button>
        <span>{t('LINES.PAGE_OF', { page, pages })}</span>
        <Button variant="outline" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
          {t('LINES.NEXT')}
        </Button>
      </div>
    </section>
  );
}
