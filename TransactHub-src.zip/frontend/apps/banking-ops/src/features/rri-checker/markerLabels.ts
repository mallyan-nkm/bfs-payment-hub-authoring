import type { RriCheckerT } from './i18n';

/**
 * Readable labels for the release words of the composed marker (design Inward_RRI_Checker_Release v1.1 §3.2, §4.5; task W2; AC-UI-07),
 * from `RRI_CHECKER.MARKERS` of the shared translations. The release request and Activity 6's three outcomes get a label; every other
 * word (the block markers) is shown as the server sends it. A label never adds an action: the buttons follow the file's `actions` only.
 */
const LABEL_KEYS: ReadonlyMap<string, string> = new Map([
  ['RELEASE_REQUESTED', 'MARKERS.RELEASE_REQUESTED'],
  ['RELEASED', 'MARKERS.RELEASED'],
  ['RELEASE_FAILED', 'MARKERS.RELEASE_FAILED'],
  ['RELEASE_UNCONFIRMED', 'MARKERS.RELEASE_UNCONFIRMED'],
]);

/** The label of a marker word in the reader's language, or the word itself when it has none. */
export function markerLabel(t: RriCheckerT, marker: string): string {
  const key = LABEL_KEYS.get(marker);
  return key ? t(key) : marker;
}
