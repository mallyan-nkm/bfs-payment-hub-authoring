import { bankingApi } from '../../shared/api/bankingApi';
import type { RriCheckerAction, RriCheckerActionResponse, RriCheckerFile, RriCheckerLinesPage, RriCheckerView } from './types';

/**
 * The RRI checker endpoints (design Inward_RRI_Checker_Release v1.1 §4.2–§4.4). `bankingApi` is scoped to `/api`.
 * WPS Business maps these routes behind the checker's page key and, for Release and Reject RRI, the approve key (design §9); the screen's
 * tests run against mocked responses.
 */
const BASE = '/wps/rri/checker';
const fileBase = (transactionId: string) => `${BASE}/files/${encodeURIComponent(transactionId)}`;

export const rriCheckerApi = {
  files: (view: RriCheckerView) => bankingApi.get<RriCheckerFile[]>(`${BASE}/files`, { params: { view } }).then((r) => r.data),

  lines: (transactionId: string, page: number, size: number) =>
    bankingApi.get<RriCheckerLinesPage>(`${fileBase(transactionId)}/lines`, { params: { page, size } }).then((r) => r.data),

  act: (transactionId: string, action: RriCheckerAction, requestKey: string) =>
    bankingApi.post<RriCheckerActionResponse>(`${fileBase(transactionId)}/${action}`, { requestKey }).then((r) => r.data),
};
