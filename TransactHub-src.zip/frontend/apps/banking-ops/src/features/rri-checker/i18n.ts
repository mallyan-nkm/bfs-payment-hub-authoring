import { useTranslation } from 'react-i18next';

/**
 * The RRI checker screen's copy: the `RRI_CHECKER` block of the shared `@paymenthub/ui` translations (`i18n/en.json`,
 * `ar.json`), the same pattern as `DEPARTMENT.*` (React UI guideline §16). Keys below are relative to that block.
 */
export function useRriCheckerTranslation() {
  return useTranslation('translation', { keyPrefix: 'RRI_CHECKER' });
}

/** The prefixed `t`, for helpers that build copy outside a component (problem messages, marker labels). */
export type RriCheckerT = ReturnType<typeof useRriCheckerTranslation>['t'];
