import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button, EmptyState, LoadingSpinner, PageBody, PageHeader, PageShell } from '@paymenthub/ui';
import { rriCheckerApi } from './api';
import { checkerNoticeMessage, readCheckerProblem, type RriCheckerNotice } from './errors';
import { useRriCheckerTranslation, type RriCheckerT } from './i18n';
import { markerLabel } from './markerLabels';
import { rriCheckerKeys } from './queryKeys';
import { RriCheckerActionButton } from './RriCheckerActionButton';
import { RriCheckerLineGrid } from './RriCheckerLineGrid';
import type { RriCheckerFile, RriCheckerView } from './types';

const newKey = () => globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;

const markerSummary = (t: RriCheckerT, counts: Record<string, number>) =>
  Object.entries(counts)
    .map(([marker, n]) => `${markerLabel(t, marker)} ${n}`)
    .join(', ');

/**
 * Bank checker's block release and reject of an RRI file (RRI Activity 5; design Inward_RRI_Checker_Release v1.1 §3.1, §4; tasks T8, W2).
 * Two tabs: files forwarded by the maker (Release, Reject RRI) and files whose block wait expired with amounts held (Release only).
 * Each row shows only the actions the server reports it would accept. The route is guarded on the checker's page key (design §9).
 * Copy comes from `RRI_CHECKER` of the shared translations (React UI guideline §16).
 */
export function RriCheckerPage() {
  const { t } = useRriCheckerTranslation();
  const [view, setView] = useState<RriCheckerView>('release');
  const [file, setFile] = useState<RriCheckerFile | null>(null);
  const [notice, setNotice] = useState<RriCheckerNotice | null>(null);
  const show = (v: RriCheckerView) => {
    setView(v);
    setFile(null);
    setNotice(null);
  };

  return (
    <PageShell>
      <PageHeader title={t('PAGE.TITLE')} subtitle={t('PAGE.SUBTITLE')} live={false} />
      <PageBody>
        <div className="mb-4 flex gap-2" role="group" aria-label={t('PAGE.VIEW_GROUP')}>
          <Button variant={view === 'release' ? 'primary' : 'outline'} aria-pressed={view === 'release'} onClick={() => show('release')}>
            {t('PAGE.VIEW_RELEASE')}
          </Button>
          <Button variant={view === 'expired' ? 'primary' : 'outline'} aria-pressed={view === 'expired'} onClick={() => show('expired')}>
            {t('PAGE.VIEW_EXPIRED')}
          </Button>
        </div>
        {notice && (
          <p role="status" className="mb-3">
            {checkerNoticeMessage(t, notice)}
          </p>
        )}
        <RriCheckerFileTable view={view} selectedId={file?.transactionId ?? null} onSelect={setFile} onMessage={setNotice} />
        {file && <RriCheckerLineGrid key={file.transactionId} file={file} />}
      </PageBody>
    </PageShell>
  );
}

function RriCheckerFileTable({
  view,
  selectedId,
  onSelect,
  onMessage,
}: {
  view: RriCheckerView;
  selectedId: string | null;
  onSelect: (file: RriCheckerFile) => void;
  onMessage: (notice: RriCheckerNotice) => void;
}) {
  const { t } = useRriCheckerTranslation();
  const files = useQuery({ queryKey: rriCheckerKeys.files(view), queryFn: () => rriCheckerApi.files(view) });
  const [keys] = useState(() => new Map<string, string>());
  const keyOf = (transactionId: string) => {
    const existing = keys.get(transactionId);
    if (existing) return existing;
    const created = newKey();
    keys.set(transactionId, created);
    return created;
  };

  if (files.isPending) return <LoadingSpinner />;
  if (files.isError) return <p role="alert">{readCheckerProblem(t, files.error).message}</p>;
  if (files.data.length === 0) return <EmptyState title={t('FILES.EMPTY_TITLE')} message={t('FILES.EMPTY_MESSAGE')} />;

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" aria-label={view === 'release' ? t('FILES.TABLE_RELEASE') : t('FILES.TABLE_EXPIRED')}>
        <thead>
          <tr className="text-left text-[var(--text-secondary)]">
            <th className="p-2">{t('FILES.COLUMNS.FILE')}</th>
            <th className="p-2">{t('FILES.COLUMNS.ESTABLISHMENT')}</th>
            <th className="p-2">{t('FILES.COLUMNS.LINES')}</th>
            <th className="p-2">{t('FILES.COLUMNS.TOTAL')}</th>
            <th className="p-2">{t('FILES.COLUMNS.ACCEPTED_REJECTED')}</th>
            <th className="p-2">{t('FILES.COLUMNS.BLOCK_STATUS')}</th>
            <th className="p-2">{t('FILES.COLUMNS.ACTIONS')}</th>
          </tr>
        </thead>
        <tbody>
          {files.data.map((f) => (
            <tr key={f.transactionId} className={f.transactionId === selectedId ? 'bg-[var(--bg-2)]' : undefined}>
              <td className="p-2">
                <Button variant="link" size="sm" onClick={() => onSelect(f)}>
                  {f.fileName}
                </Button>
              </td>
              <td className="p-2">{f.establishmentReference ?? ''}</td>
              <td className="p-2">{f.lineCount}</td>
              <td className="p-2">{f.totalAmount.toFixed(2)}</td>
              <td className="p-2">
                {f.acceptedCount} / {f.rejectedCount}
              </td>
              <td className="p-2">{markerSummary(t, f.markerCounts)}</td>
              <td className="flex gap-2 p-2">
                {f.actions.release && <RriCheckerActionButton file={f} action="release" requestKey={keyOf(f.transactionId)} onMessage={onMessage} />}
                {f.actions.reject && <RriCheckerActionButton file={f} action="reject" requestKey={keyOf(f.transactionId)} onMessage={onMessage} />}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
