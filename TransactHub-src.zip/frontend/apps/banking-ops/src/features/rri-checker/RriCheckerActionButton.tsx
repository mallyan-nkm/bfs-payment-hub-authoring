import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button, Can, Dialog } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { rriCheckerApi } from './api';
import type { RriCheckerNotice } from './errors';
import { useRriCheckerTranslation } from './i18n';
import { rriCheckerKeys } from './queryKeys';
import type { RriCheckerAction, RriCheckerFile } from './types';

/** The copy of each action, under `RRI_CHECKER.ACTION.<RELEASE|REJECT>`. */
const ACTION_KEY: Record<RriCheckerAction, string> = {
  release: 'ACTION.RELEASE',
  reject: 'ACTION.REJECT',
};

/**
 * Release or Reject RRI on one file (design §4.3–§4.5; AC-UI-02, AC-UI-03). Shown only when the file's `actions` allow it; asks
 * for confirmation; sends the screen's one `requestKey` for the opened file, so a retried click replays the first result; then
 * refreshes the list and the grid. The trigger is gated on the approve key both decision routes enforce (H-RRI5-1); the server
 * also refuses the maker of the file's verification, and the list's `actions` already exclude them.
 */
export function RriCheckerActionButton({
  file,
  action,
  requestKey,
  onMessage,
}: {
  file: RriCheckerFile;
  action: RriCheckerAction;
  requestKey: string;
  onMessage: (notice: RriCheckerNotice) => void;
}) {
  const { t } = useRriCheckerTranslation();
  const client = useQueryClient();
  const [open, setOpen] = useState(false);
  const key = ACTION_KEY[action];
  const refresh = () => void client.invalidateQueries({ queryKey: rriCheckerKeys.all });
  const act = useMutation({
    mutationFn: () => rriCheckerApi.act(file.transactionId, action, requestKey),
    onSuccess: (r) => onMessage({ kind: 'done', message: r.message, lineCount: r.lineCount }),
    onError: (e) => onMessage({ kind: 'problem', error: e }),
    onSettled: () => {
      setOpen(false);
      refresh();
    },
  });

  return (
    <>
      <Can permission={PERM.rriCheckerApprove}>
        <Button size="sm" variant={action === 'release' ? 'primary' : 'outline'} onClick={() => setOpen(true)}>
          {t(`${key}.BUTTON`)}
        </Button>
      </Can>
      <Dialog
        open={open}
        onOpenChange={setOpen}
        title={t(`${key}.TITLE`)}
        description={t(`${key}.DESCRIPTION`)}
        footer={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              {t('ACTION.CANCEL')}
            </Button>
            <Button variant="primary" loading={act.isPending} disabled={act.isPending} onClick={() => act.mutate()}>
              {t('ACTION.CONFIRM')}
            </Button>
          </div>
        }
      >
        <p>{file.fileName}</p>
      </Dialog>
    </>
  );
}
