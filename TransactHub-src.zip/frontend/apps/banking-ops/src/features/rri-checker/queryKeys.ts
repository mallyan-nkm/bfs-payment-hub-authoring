import type { RriCheckerView } from './types';

/** react-query keys of the RRI checker screen. `file(tx)` prefixes every lines page of that file. */
export const rriCheckerKeys = {
  all: ['rriChecker'] as const,
  files: (view: RriCheckerView) => [...rriCheckerKeys.all, 'files', view] as const,
  file: (transactionId: string) => [...rriCheckerKeys.all, 'file', transactionId] as const,
  lines: (transactionId: string, page: number) => [...rriCheckerKeys.file(transactionId), 'lines', page] as const,
};
