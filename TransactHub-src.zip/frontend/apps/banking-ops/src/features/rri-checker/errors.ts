import type { RriCheckerT } from './i18n';

/**
 * The checker API's problem codes (design Inward_RRI_Checker_Release v1.0 §8.1) as screen messages, from `RRI_CHECKER.ERRORS` of the
 * shared translations. A 500 shows its trace id (AC-UI-03); no message names an account, amount or person ID.
 */
const CODES: readonly string[] = [
  'RRI_CHECKER_FILE_NOT_FOUND',
  'RRI_CHECKER_STATE_CHANGED',
  'RRI_CHECKER_RELEASE_EXISTS',
  'RRI_CHECKER_NOTHING_TO_RELEASE',
  'RRI_CHECKER_REQUEST_INVALID',
  // Design v1.1 §4.5, §8.1 (S3-1, AC-UI-06): the maker of the file's verification is refused with 403; the list refreshes on settle.
  'RRI_CHECKER_OWN_VERIFICATION',
  'RRI_CHECKER_UNAVAILABLE',
];

const FALLBACK_CODE = 'RRI_CHECKER_UNAVAILABLE';

export interface RriCheckerProblem {
  code: string | null;
  message: string;
}

/**
 * Reads an axios failure into its code and the screen message; a server fault adds its trace id. Called at render time with the
 * screen's prefixed `t`, so the message follows the reader's language.
 */
export function readCheckerProblem(t: RriCheckerT, error: unknown): RriCheckerProblem {
  const response = (error as { response?: { status?: number; data?: { code?: unknown; traceId?: unknown } } } | null)?.response;
  const code = typeof response?.data?.code === 'string' ? response.data.code : null;
  const base = t(`ERRORS.${code !== null && CODES.includes(code) ? code : FALLBACK_CODE}`);
  const traceId = typeof response?.data?.traceId === 'string' ? response.data.traceId : null;
  const isFault = (response?.status ?? 500) >= 500;
  return { code, message: isFault && traceId ? t('ERRORS.WITH_REFERENCE', { message: base, traceId }) : base };
}

/**
 * What a Release or Reject RRI last reported to the page: the server's own message with its line count, or the failure. The page turns
 * it into copy at render time, so it follows the reader's language.
 */
export type RriCheckerNotice = { kind: 'done'; message: string; lineCount: number } | { kind: 'problem'; error: unknown };

/** The page message of a notice. */
export function checkerNoticeMessage(t: RriCheckerT, notice: RriCheckerNotice): string {
  return notice.kind === 'done'
    ? t('ACTION.DONE', { message: notice.message, lineCount: notice.lineCount })
    : readCheckerProblem(t, notice.error).message;
}
