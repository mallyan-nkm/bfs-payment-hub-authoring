import { useNavigate } from 'react-router-dom';
import { PageBody, PageShell } from '@paymenthub/ui';

/**
 * Honest placeholders for the ops-console menu items that exist in the Angular portal's
 * full sidebar but are **mock-only there** (no backend): the WPS/rail report screens.
 * Same pattern as `charges/ChargePlaceholderPages.tsx` —
 * the navigation is complete and it is explicit that the screen is not yet built on a
 * real backend. Wire each to a real endpoint when one exists.
 */
function Placeholder({
                       icon,
                       title,
                       breadcrumb,
                       blurb,
                       features,
                       backTo,
                       backLabel,
                     }: {
  icon: string;
  title: string;
  breadcrumb: string;
  blurb: string;
  features: string[];
  backTo?: string;
  backLabel?: string;
}) {
  const navigate = useNavigate();
  return (
      <PageShell>
        <PageBody>
          <div className="flex flex-col gap-4">
            <div>
              {backTo && (
                  <button
                      onClick={() => navigate(backTo)}
                      className="text-sm font-medium text-[var(--accent)] hover:underline"
                  >
                    ← {backLabel ?? 'Back'}
                  </button>
              )}
              <p className="mt-2 text-xs text-[var(--text-muted)]">{breadcrumb}</p>
            </div>

            <div className="mx-auto flex max-w-xl flex-col items-center rounded-lg border border-[var(--border)] bg-[var(--bg-card)] px-6 py-12 text-center shadow-[var(--shadow-sm)]">
            <span className="text-5xl" aria-hidden="true">
              {icon}
            </span>
              <h1 className="mt-6 text-2xl font-semibold text-[var(--text-primary)]">{title}</h1>
              <p className="mt-3 text-sm text-[var(--text-secondary)]">{blurb}</p>
              <ul className="mt-6 flex w-full flex-col gap-2">
                {features.map((f) => (
                    <li
                        key={f}
                        className="rounded-md border border-[var(--border)] bg-[var(--bg-secondary)] px-3 py-2 text-sm text-[var(--text-secondary)]"
                    >
                      {f}
                    </li>
                ))}
              </ul>
              <p className="mt-6 text-xs text-[var(--text-muted)]">
                Not yet implemented — this screen is a placeholder in the Angular portal too (mock data, no backend).
              </p>
            </div>
          </div>
        </PageBody>
      </PageShell>
  );
}

const REPORT_CRUMB = 'Home / Reporting / Reports';

export function SifDetailReportPage() {
  return (
      <Placeholder
          icon="📄"
          title="SIF Detail Report"
          breadcrumb={`${REPORT_CRUMB} / SIF Detail`}
          blurb="Per-record salary detail for a WPS SIF file. Today this data is available via the SIF Summary Report → 360° drawer (Record List tab)."
          features={['Employee-level record listing', 'Fixed / variable pay breakdown', 'Routing & account details', 'Export to CSV']}
          backTo="/reports/sif-summary"
          backLabel="Back to SIF Summary Report"
      />
  );
}

export function RtcReportPage() {
  return (
      <Placeholder
          icon="🔁"
          title="RTC Report"
          breadcrumb={`${REPORT_CRUMB} / RTC`}
          blurb="Return-to-corporate (RTC) reporting for WPS."
          features={['RTC file listing', 'Return reasons breakdown', 'Reconciliation status', 'Export to CSV']}
      />
  );
}

export function AckNakReportPage() {
  return (
      <Placeholder
          icon="✅"
          title="ACK / NAK Report"
          breadcrumb={`${REPORT_CRUMB} / ACKNAK`}
          blurb="Central-bank acknowledgement (ACK) and rejection (NAK) reporting for WPS."
          features={['ACK / NAK message listing', 'Rejection reason codes', 'CB response timeline', 'Export to CSV']}
      />
  );
}

function RailReport({ rail, icon }: { rail: string; icon: string }) {
  return (
      <Placeholder
          icon={icon}
          title={`${rail} Report`}
          breadcrumb={`${REPORT_CRUMB} / ${rail}`}
          blurb={`Rail-wise reporting for ${rail}.`}
          features={['Transaction listing', 'Status & value summary', 'Date-range filtering', 'Export to CSV']}
      />
  );
}

export function FtsReportPage() {
  return <RailReport rail="FTS" icon="🏦" />;
}
export function IppReportPage() {
  return <RailReport rail="IPP" icon="⚡" />;
}
export function IpiReportPage() {
  return <RailReport rail="IPI" icon="💠" />;
}
export function SwiftReportPage() {
  return <RailReport rail="SWIFT" icon="🌐" />;
}
export function MasterCardReportPage() {
  return <RailReport rail="Master Card" icon="💳" />;
}
