/**
 * Catalog-driven status tone: a status the WPS status catalog knows is drawn with its Tone, ColorHex and DisplayName; an empty
 * catalog, or a word it does not know, keeps the built-in substring heuristic.
 */
import { describe, expect, it } from 'vitest';
import { resolveSifStatus, sifStatusHeuristicTone, sifStatusTone } from './sifStatusTone';
import {
  TONE_CLASSES,
  colorOverrideStyle,
  createWpsStatusIndex,
  statusFilterOptions,
  toneClasses,
} from './wpsStatusCatalog';
import type { WpsStatusCatalogItem } from './wpsStatusCatalog';

const item = (over: Partial<WpsStatusCatalogItem> & { statusCode: string }): WpsStatusCatalogItem => ({
  statusKey: null,
  displayName: over.statusCode,
  category: 'Pending',
  isTerminal: false,
  waitsFor: null,
  tone: null,
  colorHex: null,
  sortOrder: null,
  ...over,
});

// Deliberately out of lifecycle order, and with a word the substring heuristic gets wrong: "Settled" contains none of its
// words, and "AwaitingCbAck" is amber by the heuristic but declared Info here.
const CATALOG: WpsStatusCatalogItem[] = [
  item({ statusCode: 'Settled', displayName: 'Settled', statusKey: 'SETTLED', category: 'Success', isTerminal: true, tone: 'Success', sortOrder: 90 }),
  item({ statusCode: 'Rejected', displayName: 'Rejected by CB', statusKey: 'REJECTED', category: 'Failure', isTerminal: true, tone: 'Danger', colorHex: '#B91C1C', sortOrder: 95 }),
  item({ statusCode: 'AwaitingCbAck', displayName: 'Awaiting CB Acknowledgement', statusKey: 'CB_ACK_PENDING', tone: 'Info', waitsFor: 'CentralBankAck', sortOrder: 50 }),
  item({ statusCode: 'ACKReceived', displayName: 'CB Ack Received', statusKey: 'CB_ACK_RECEIVED', tone: 'Warning', sortOrder: 60 }),
  item({ statusCode: 'Posted', displayName: 'Posted', statusKey: 'POSTED', tone: 'Neutral', sortOrder: 40 }),
  item({ statusCode: 'Uploaded', displayName: 'Uploaded', sortOrder: 10 }), // predates Tone / ColorHex
  item({ statusCode: 'NoOrder', displayName: 'No Order' }), // predates SortOrder
];
const INDEX = createWpsStatusIndex(CATALOG);

describe('resolveSifStatus — catalog hit', () => {
  it.each([
    ['Settled', 'Success', 'border-green-300 bg-green-50 text-green-700'],
    ['Rejected', 'Danger', 'border-red-300 bg-red-50 text-red-700'],
    ['ACKReceived', 'Warning', 'border-amber-300 bg-amber-50 text-amber-800'],
    ['AwaitingCbAck', 'Info', 'border-blue-300 bg-blue-50 text-blue-700'],
    ['Posted', 'Neutral', 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]'],
  ])('%s is drawn with its %s tone', (word, _tone, classes) => {
    const display = resolveSifStatus(word, INDEX);
    expect(display.fromCatalog).toBe(true);
    expect(display.tone).toBe(classes);
  });

  it('the catalog tone wins over what the word looks like', () => {
    // The heuristic says amber ("await"); the catalog says Info (blue).
    expect(sifStatusHeuristicTone('AwaitingCbAck')).toContain('amber');
    expect(sifStatusTone('AwaitingCbAck', INDEX)).toContain('blue');
    // ...and the heuristic says green ("ack"); the catalog says Warning (amber).
    expect(sifStatusHeuristicTone('ACKReceived')).toContain('green');
    expect(sifStatusTone('ACKReceived', INDEX)).toContain('amber');
  });

  it('the label is the catalog DisplayName', () => {
    expect(resolveSifStatus('Rejected', INDEX).label).toBe('Rejected by CB');
    expect(resolveSifStatus('AwaitingCbAck', INDEX).label).toBe('Awaiting CB Acknowledgement');
  });

  it('matches the status code case-insensitively', () => {
    const display = resolveSifStatus('SETTLED', INDEX);
    expect(display.fromCatalog).toBe(true);
    expect(display.label).toBe('Settled');
    expect(display.tone).toBe(TONE_CLASSES.Success);
    expect(resolveSifStatus('awaitingcback', INDEX).tone).toBe(TONE_CLASSES.Info);
  });

  it('uses the same classes for every tone as the existing pills (Neutral keeps the CSS variables, so dark mode still works)', () => {
    expect(TONE_CLASSES.Neutral).toContain('var(--border)');
    expect(TONE_CLASSES.Neutral).toContain('var(--bg-secondary)');
    expect(TONE_CLASSES.Neutral).toContain('var(--text-secondary)');
    expect(Object.keys(TONE_CLASSES).sort()).toEqual(['Danger', 'Info', 'Neutral', 'Success', 'Warning']);
  });

  it('a tone the catalog row does not carry keeps the heuristic colour but takes the catalog label', () => {
    const display = resolveSifStatus('Uploaded', INDEX);
    expect(display.fromCatalog).toBe(true);
    expect(display.label).toBe('Uploaded');
    expect(display.tone).toBe(sifStatusHeuristicTone('Uploaded'));
    expect(display.style).toBeUndefined();
  });

  it('an unrecognised tone string is ignored rather than rendered', () => {
    const index = createWpsStatusIndex([item({ statusCode: 'Odd', tone: 'Purple' })]);
    expect(resolveSifStatus('Odd', index).tone).toBe(sifStatusHeuristicTone('Odd'));
    expect(toneClasses('Purple')).toBeUndefined();
    expect(toneClasses('success')).toBe(TONE_CLASSES.Success);
  });
});

describe('resolveSifStatus — ColorHex override', () => {
  it('applies the colour as border and text with a translucent background', () => {
    const display = resolveSifStatus('Rejected', INDEX);
    expect(display.style).toEqual({
      borderColor: '#B91C1C',
      color: '#B91C1C',
      backgroundColor: 'rgba(185, 28, 28, 0.12)',
    });
    // The tone classes stay (the inline style overrides their colours), so the box and dark-mode fallbacks are unchanged.
    expect(display.tone).toBe(TONE_CLASSES.Danger);
  });

  it('carries no style when the row has no ColorHex', () => {
    expect(resolveSifStatus('Settled', INDEX).style).toBeUndefined();
  });

  it.each(['red', '#FFF', '#12345', '#GGGGGG', 'rgb(1,2,3)', '', '  '])('ignores %j (not exactly #RRGGBB)', (bad) => {
    expect(colorOverrideStyle(bad)).toBeUndefined();
  });

  it('accepts lower-case hex and surrounding whitespace', () => {
    expect(colorOverrideStyle(' #0a7f3f ')?.backgroundColor).toBe('rgba(10, 127, 63, 0.12)');
  });
});

describe('resolveSifStatus — unknown word falls back to the heuristic', () => {
  it.each(['REJECTION_NOTIFIED_X', 'CB_DISPATCHED', 'Weird', 'SOMETHING_FAILED', 'PENDING_APPROVAL'])('%s', (word) => {
    const display = resolveSifStatus(word, INDEX);
    expect(display.fromCatalog).toBe(false);
    expect(display.label).toBeUndefined();
    expect(display.style).toBeUndefined();
    expect(display.tone).toBe(sifStatusHeuristicTone(word));
  });

  it("uses the caller's own heuristic when it passes one", () => {
    const summaryGuess = (s: string) => (s === 'Weird' ? 'custom-classes' : 'other');
    expect(resolveSifStatus('Weird', INDEX, summaryGuess).tone).toBe('custom-classes');
    // ...and a catalog hit never consults it.
    expect(resolveSifStatus('Settled', INDEX, summaryGuess).tone).toBe(TONE_CLASSES.Success);
  });

  it('a null or empty status is the heuristic, not an error', () => {
    expect(resolveSifStatus(null, INDEX).tone).toBe(sifStatusHeuristicTone(''));
    expect(resolveSifStatus(undefined, INDEX).fromCatalog).toBe(false);
    expect(resolveSifStatus('', INDEX).fromCatalog).toBe(false);
  });
});

describe('resolveSifStatus — legacy UPPER_SNAKE event words resolve through the status key', () => {
  it('CB_ACK_RECEIVED reaches the status carrying that key', () => {
    const display = resolveSifStatus('CB_ACK_RECEIVED', INDEX);
    expect(display.fromCatalog).toBe(true);
    expect(display.label).toBe('CB Ack Received');
    expect(display.tone).toBe(TONE_CLASSES.Warning);
  });

  it('POSTED (equal to the key, differing in case from the code "Posted") resolves to the Neutral status', () => {
    expect(resolveSifStatus('POSTED', INDEX).tone).toBe(TONE_CLASSES.Neutral);
  });

  it('REJECTION_NOTIFIED resolves by key when a status carries it, and carries that status colour', () => {
    const index = createWpsStatusIndex([
      item({ statusCode: 'RejectionNotified', displayName: 'Rejection Notified', statusKey: 'REJECTION_NOTIFIED', tone: 'Danger', colorHex: '#AA0000' }),
    ]);
    const display = resolveSifStatus('REJECTION_NOTIFIED', index);
    expect(display.fromCatalog).toBe(true);
    expect(display.label).toBe('Rejection Notified');
    expect(display.style?.color).toBe('#AA0000');
  });

  it('matches a key case-insensitively', () => {
    expect(resolveSifStatus('cb_ack_received', INDEX).label).toBe('CB Ack Received');
  });

  it('an exact status code is preferred to a key match on another row', () => {
    const index = createWpsStatusIndex([
      item({ statusCode: 'Alpha', displayName: 'Alpha (by key)', statusKey: 'BETA', tone: 'Info' }),
      item({ statusCode: 'BETA', displayName: 'Beta (by code)', tone: 'Danger' }),
    ]);
    expect(resolveSifStatus('BETA', index).label).toBe('Beta (by code)');
  });
});

describe('resolveSifStatus — empty catalog', () => {
  it.each([
    ['an empty list', createWpsStatusIndex([])],
    ['no catalog at all', undefined],
    ['null items', createWpsStatusIndex(null)],
  ])('%s: every word is the heuristic, exactly', (_name, index) => {
    for (const word of ['Settled', 'Rejected', 'AwaitingCbAck', 'CB_ACK_RECEIVED', 'INITIATED', 'POSTING_FAILED']) {
      const display = resolveSifStatus(word, index);
      expect(display).toEqual({ tone: sifStatusHeuristicTone(word), fromCatalog: false });
    }
  });

  it('sifStatusTone with no catalog is the original substring heuristic', () => {
    expect(sifStatusTone('REJECTION_NOTIFIED')).toBe('border-red-300 bg-red-50 text-red-700');
    expect(sifStatusTone('AwaitingCbAck')).toBe('border-amber-300 bg-amber-50 text-amber-800');
    expect(sifStatusTone('CB_ACK_RECEIVED')).toBe('border-green-300 bg-green-50 text-green-700');
    expect(sifStatusTone('CB_DISPATCHED')).toBe('border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]');
  });
});

describe('statusFilterOptions', () => {
  it('lists the catalog in lifecycle order, statuses without a SortOrder last, labelled by DisplayName', () => {
    expect(statusFilterOptions(CATALOG)).toEqual([
      { value: 'Uploaded', label: 'Uploaded' },
      { value: 'Posted', label: 'Posted' },
      { value: 'AwaitingCbAck', label: 'Awaiting CB Acknowledgement' },
      { value: 'ACKReceived', label: 'CB Ack Received' },
      { value: 'Settled', label: 'Settled' },
      { value: 'Rejected', label: 'Rejected by CB' },
      { value: 'NoOrder', label: 'No Order' },
    ]);
  });

  it('is empty for an empty catalog and does not reorder its input', () => {
    expect(statusFilterOptions([])).toEqual([]);
    expect(statusFilterOptions(null)).toEqual([]);
    const before = CATALOG.map((c) => c.statusCode);
    statusFilterOptions(CATALOG);
    expect(CATALOG.map((c) => c.statusCode)).toEqual(before);
  });
});
