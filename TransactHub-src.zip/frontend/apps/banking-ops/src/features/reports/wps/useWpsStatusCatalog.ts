import { useCallback, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { sifApi } from './sifApi';
import { createWpsStatusIndex } from './wpsStatusCatalog';
import { resolveSifStatus } from './sifStatusTone';
import type { SifStatusDisplay } from './sifStatusTone';

export const WPS_STATUS_CATALOG_QUERY_KEY = ['wps-status-catalog'] as const;

/**
 * The WPS status catalog, fetched once per session and shared by every badge on every report screen (one query key, so a grid of
 * fifty rows is one request).
 *
 * It is display metadata, so it never blocks or breaks a screen: while it loads, when the request fails, or when the server answers
 * with an empty list (the catalog could not be read there), `resolve` returns what the built-in heuristic would have drawn. A
 * successful non-empty answer is kept for the session; an empty or failed one is asked again after a minute, so a catalog that comes
 * back is picked up without a reload.
 */
export function useWpsStatusCatalog() {
  const query = useQuery({
    queryKey: WPS_STATUS_CATALOG_QUERY_KEY,
    queryFn: () => sifApi.statusCatalog(),
    staleTime: (q) => (q.state.data && q.state.data.length > 0 ? Infinity : 60_000),
    gcTime: Infinity,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  const index = useMemo(() => createWpsStatusIndex(query.data), [query.data]);
  const resolve = useCallback(
    (status: string | null | undefined, heuristic?: (status: string) => string): SifStatusDisplay =>
      resolveSifStatus(status, index, heuristic),
    [index],
  );

  return { index, items: index.items, resolve, isLoading: query.isLoading };
}
