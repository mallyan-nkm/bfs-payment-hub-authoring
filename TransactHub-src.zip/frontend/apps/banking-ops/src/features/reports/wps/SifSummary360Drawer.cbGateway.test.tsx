/**
 * SIF Summary 360 -> File Summary -> Central Bank Gateway Details.
 *
 * `cbFileName` from the sif-detail API is the Central Bank's ACK/NAK response file
 * (wps.CbAcknowledgements.RemoteFileName); the original SIF is `fileName`
 * (wps.Transactions.OriginalFileName). The card must show the SIF under "CB File Name" and the
 * stored response file, verbatim, under "ACK/NAK File Name" — and "CB Response" must not change.
 *
 * Rendered in jsdom against a mocked sifApi.
 */
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SifSummary360Drawer } from './SifSummary360Drawer';
import type { SifFileDetailResponse, SifSummaryRow } from './sifApi';

const api = vi.hoisted(() => ({
  detail: vi.fn(),
  employees: vi.fn(),
  postingDetails: vi.fn(),
  channelInteractions: vi.fn(),
  logPayload: vi.fn(),
}));

vi.mock('./sifApi', () => ({ sifApi: api }));

const SIF = '0001234567890260909195120.SIF';
const ACK_FILE = '0001234567890260909195120IND000000120.ACK';
const NAK_FILE = '0001234567890260909195607126535897241.NAK';

const ROW: SifSummaryRow = {
  slNo: 1,
  fileName: SIF,
  sifFileName: SIF,
  transactionId: 'TXN-1',
  corporateName: 'Acme',
  accountNumber: '123',
  molEstablishmentId: '0001234567890',
  uploadDate: '2026-09-09T19:51:20',
  totalRecords: 10,
  totalAmount: 1000,
  currentStatus: 'CB_ACK_RECEIVED',
  uploadedBy: 'ops',
};

const detail = (over: Partial<SifFileDetailResponse>): SifFileDetailResponse => ({
  fileName: SIF,
  corporate: 'Acme',
  channel: 'UI',
  initiatedDateTime: '2026-09-09T19:51:20',
  initiatedBy: 'ops',
  currentStatus: 'CB_ACK_RECEIVED',
  totalRecords: 10,
  systemAccepted: 10,
  systemRejected: 0,
  cbResponse: null,
  cbFileName: null,
  sentToCbDateTime: null,
  totalTransactionAmount: 1000,
  totalSalaryAmount: 1000,
  chargeAmount: 0,
  vatAmount: 0,
  ...over,
});

function renderDrawer() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <SifSummary360Drawer row={ROW} onClose={() => {}} />
    </QueryClientProvider>,
  );
}

/** Every value shown next to a given label (a label can legitimately appear in more than one card). */
const valuesOf = (label: string) =>
  screen.getAllByText(`${label}:`).map((dt: HTMLElement) => dt.parentElement?.querySelector('dd')?.textContent ?? '');

/** The single value of a label that must appear exactly once. */
const valueOf = (label: string) => {
  const values = valuesOf(label);
  expect(values).toHaveLength(1);
  return values[0];
};

const loaded = () => screen.findByText('CB File Name:');

beforeEach(() => {
  vi.clearAllMocks();
});

// Explicit: automatic cleanup only runs when vitest globals are enabled.
afterEach(cleanup);

describe('Central Bank Gateway Details', () => {
  it('ACK: CB File Name is the original SIF, ACK/NAK File Name is the stored ACK file, CB Response unchanged', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: 'SIFACK', cbFileName: ACK_FILE }));
    renderDrawer();
    await loaded();

    expect(valueOf('CB File Name')).toBe(SIF);
    expect(valueOf('CB File Name')).not.toMatch(/\.(ACK|NAK)$/i);
    expect(valueOf('ACK/NAK File Name')).toBe(ACK_FILE);
    expect(valueOf('CB Response')).toBe('SIFACK');
  });

  it('NAK: CB File Name is the original SIF, ACK/NAK File Name is the stored NAK file, CB Response unchanged', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: 'SIFNAK', cbFileName: NAK_FILE, systemAccepted: 0, systemRejected: 10 }));
    renderDrawer();
    await loaded();

    expect(valueOf('CB File Name')).toBe(SIF);
    expect(valueOf('CB File Name')).not.toMatch(/\.(ACK|NAK)$/i);
    expect(valueOf('ACK/NAK File Name')).toBe(NAK_FILE);
    expect(valueOf('CB Response')).toBe('SIFNAK');
  });

  it('no response yet: the SIF stays visible, ACK/NAK File Name and CB Response are the pending dash', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: null, cbFileName: null, currentStatus: 'AwaitingCbAck' }));
    renderDrawer();
    await loaded();

    expect(valueOf('CB File Name')).toBe(SIF);
    expect(valueOf('ACK/NAK File Name')).toBe('—');
    expect(valueOf('CB Response')).toBe('—');
  });

  it('shows a legacy stored response name verbatim — it is not normalised or rebuilt from the SIF name', async () => {
    const legacy = '0001234567890260909195120_IND000000120.SIFACK';
    api.detail.mockResolvedValue(detail({ cbResponse: 'SIFACK', cbFileName: legacy }));
    renderDrawer();
    await loaded();

    expect(valueOf('ACK/NAK File Name')).toBe(legacy);
    expect(valueOf('CB File Name')).toBe(SIF);
  });

  // A zoneless value is UTC; it is shown in the session zone (the bank default, Asia/Dubai, with no provider
  // mounted), dd-MM-yyyy HH:mm:ss, whatever the machine's zone (UTC date-time design §6.7).
  const SENT_AT = '2026-09-18T12:02:32.3234276';
  const SENT_AT_SHOWN = /^18-09-2026 16:02:32$/;

  it.each([
    ['ACK', 'SIFACK', ACK_FILE],
    ['NAK', 'SIFNAK', NAK_FILE],
  ])('%s: Sent to CB DateTime shows the IntegrationMessageLog.CreatedAt from the API, formatted', async (_kind: string, cbResponse: string, cbFileName: string) => {
    api.detail.mockResolvedValue(detail({ cbResponse, cbFileName, sentToCbDateTime: SENT_AT }));
    renderDrawer();
    await loaded();

    expect(valueOf('Sent to CB DateTime')).toMatch(SENT_AT_SHOWN);
  });

  it('no matching delivery log: Sent to CB DateTime is the dash even when the file has an ACK', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: 'SIFACK', cbFileName: ACK_FILE, sentToCbDateTime: null }));
    renderDrawer();
    await loaded();

    expect(valueOf('Sent to CB DateTime')).toBe('—');
  });

  it('Sent to CB DateTime is independent of the ACK/NAK file and the CB response', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: null, cbFileName: null, sentToCbDateTime: SENT_AT }));
    renderDrawer();
    await loaded();

    expect(valueOf('Sent to CB DateTime')).toMatch(SENT_AT_SHOWN);
    expect(valueOf('ACK/NAK File Name')).toBe('—');
  });

});

/**
 * Related Messages -> SIF ACK/NAK. Both generic "File Name" fields (header grid and context strip) are the
 * original SIF; the CB's response file is only the Raw File "CB acknowledgement file" entry (and the
 * Central Bank Gateway Details "ACK/NAK File Name" above).
 */
describe('Related Messages: SIF ACK/NAK file names', () => {
  /** Value of a `<p>`-label / `<p>`-value pair (context strip, section cells) — these labels carry no colon. */
  const pairedValue = (label: string) => {
    const labels = screen.getAllByText(label);
    expect(labels).toHaveLength(1);
    return labels[0].nextElementSibling?.textContent ?? '';
  };
  /** Raw File entry: the file name is rendered in the element right before its description. */
  const rawFile = (description: string) => screen.getByText(description).previousElementSibling?.textContent ?? '';

  it.each([
    ['ACK', 'SIFACK', ACK_FILE],
    ['NAK', 'SIFNAK', NAK_FILE],
  ])('%s: both "File Name" fields are the original SIF, the response file only appears as the CB acknowledgement file', async (_kind: string, cbResponse: string, responseFile: string) => {
    api.detail.mockResolvedValue(detail({ cbResponse, cbFileName: responseFile, systemAccepted: 8, systemRejected: 2 }));
    renderDrawer();
    await loaded();

    // "File Name:" appears in File Details and in the pane's header grid — both the SIF.
    expect(valuesOf('File Name')).toEqual([SIF, SIF]);
    // Context strip "File Name".
    expect(pairedValue('File Name')).toBe(SIF);
    expect(pairedValue('Processed File Name')).toBe(SIF);
    // No generic "File Name" shows the response file anywhere on the Data Fields tab.
    expect(screen.getAllByText(responseFile)).toHaveLength(1); // only the Gateway card's "ACK/NAK File Name"

    fireEvent.click(screen.getByRole('button', { name: 'Raw File' }));
    expect(rawFile('CB acknowledgement file')).toBe(responseFile);
    expect(rawFile('Original SIF file')).toBe(SIF);

    // Central Bank Gateway Details and CB Response are unchanged.
    expect(valueOf('CB File Name')).toBe(SIF);
    expect(valueOf('ACK/NAK File Name')).toBe(responseFile);
    expect(valueOf('CB Response')).toBe(cbResponse);
  });

  it('a legacy stored response name is shown verbatim as the CB acknowledgement file, never under "File Name"', async () => {
    const legacy = '0001234567890260909195120_IND000000120.SIFACK';
    api.detail.mockResolvedValue(detail({ cbResponse: 'SIFACK', cbFileName: legacy }));
    renderDrawer();
    await loaded();

    expect(valuesOf('File Name')).toEqual([SIF, SIF]);
    expect(pairedValue('File Name')).toBe(SIF);
    fireEvent.click(screen.getByRole('button', { name: 'Raw File' }));
    expect(rawFile('CB acknowledgement file')).toBe(legacy);
  });

  it('no response yet: the pane is the pending placeholder with no File Name field of its own', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: null, cbFileName: null, currentStatus: 'AwaitingCbAck' }));
    renderDrawer();
    await loaded();

    expect(screen.getByText(/Pending processing\. No message payload available yet\./)).toBeTruthy();
    // Only File Details carries "File Name:"; the pane contributes none.
    expect(valuesOf('File Name')).toEqual([SIF]);
    expect(screen.queryByText('File Name')).toBeNull();
  });
});
