/**
 * SifStatusBadge — every status renders in the same fixed-width box (long text wraps), and the
 * caller's tone classes are applied untouched.
 *
 * Rendered to static markup (no DOM / testing-library needed): the guarantee under test is the
 * class list, which is what fixes the box.
 */
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import { CatalogSifStatusBadge, SifStatusBadge } from './SifStatusBadge';
import { sifStatusTone } from './sifStatusTone';
import { WPS_STATUS_CATALOG_QUERY_KEY } from './useWpsStatusCatalog';
import type { WpsStatusCatalogItem } from './wpsStatusCatalog';

const STATUSES = [
  'INITIATED',
  'VALIDATED',
  'CHARGES_CALCULATED',
  'BALANCE_SUFFICIENT',
  'POSTED',
  'POSTING_CONFIRMED',
  'CB_FILE_SUBMITTED',
  'CB_ACK_RECEIVED',
];

/** The classes that fix the box; none of them may vary with the status text. */
const BOX = ['min-h-6', 'w-40', 'rounded-full', 'border', 'px-2', 'text-[10px]', 'font-bold', 'justify-center'];

const classesOf = (html: string) => (/class="([^"]*)"/.exec(html)?.[1] ?? '').split(/\s+/);

describe('SifStatusBadge', () => {
  it('success: short and long statuses share identical box classes', () => {
    for (const status of STATUSES) {
      const classes = classesOf(renderToStaticMarkup(<SifStatusBadge status={status} tone={sifStatusTone(status)} />));
      expect(BOX.filter((c) => classes.includes(c))).toEqual(BOX);
    }
  });

  it('success: keeps the caller tone and shows the status text', () => {
    const html = renderToStaticMarkup(
      <SifStatusBadge status="CB_ACK_RECEIVED" tone="border-green-300 bg-green-50 text-green-700" />,
    );
    expect(html).toContain('>CB_ACK_RECEIVED</span>');
    expect(html).toContain('title="CB_ACK_RECEIVED"');
    expect(classesOf(html)).toContain('bg-green-50');
  });

  it('success: AwaitingCbAck is shown as "Awaiting CB ACK" and keeps its tone', () => {
    const html = renderToStaticMarkup(
      <SifStatusBadge status="AwaitingCbAck" tone="border-amber-300 bg-amber-50 text-amber-800" />,
    );
    expect(html).toContain('>Awaiting CB ACK</span>');
    expect(html).toContain('title="Awaiting CB ACK"');
    expect(html).not.toContain('AwaitingCbAck');
    expect(classesOf(html)).toContain('bg-amber-50');
  });

  it('an over-long status wraps inside the fixed width (grows taller) instead of being clipped', () => {
    const long = 'Insufficient balance - proceeded without exception queue';
    const html = renderToStaticMarkup(<SifStatusBadge status={long} tone="border-red-300 bg-red-50 text-red-700" />);
    const classes = classesOf(html);
    expect(classes).toContain('w-40');
    expect(classes).toContain('whitespace-normal');
    expect(classes).toContain('break-words');
    expect(classes).not.toContain('overflow-hidden');
    expect(classes).not.toContain('whitespace-nowrap');
    expect(html).toContain('class="min-w-0 break-words"');
    expect(html).not.toContain('truncate');
    expect(html).toContain(`>${long}</span>`);
    expect(html).toContain(`title="${long}"`);
  });
});

describe('SifStatusBadge — catalog label and colour', () => {
  it('shows the catalog label (text and title) in place of the built-in one, in the same box', () => {
    const html = renderToStaticMarkup(
      <SifStatusBadge status="AwaitingCbAck" tone="border-blue-300 bg-blue-50 text-blue-700" label="Awaiting CB Acknowledgement" />,
    );
    expect(html).toContain('>Awaiting CB Acknowledgement</span>');
    expect(html).toContain('title="Awaiting CB Acknowledgement"');
    expect(html).not.toContain('Awaiting CB ACK<');
    const classes = classesOf(html);
    expect(BOX.filter((c) => classes.includes(c))).toEqual(BOX);
    expect(classes).toContain('bg-blue-50');
  });

  it('applies a ColorHex override as an inline style on the pill, keeping the box classes', () => {
    const html = renderToStaticMarkup(
      <SifStatusBadge
        status="Rejected"
        tone="border-red-300 bg-red-50 text-red-700"
        style={{ borderColor: '#B91C1C', color: '#B91C1C', backgroundColor: 'rgba(185, 28, 28, 0.12)' }}
      />,
    );
    expect(html).toContain('style="border-color:#B91C1C;color:#B91C1C;background-color:rgba(185, 28, 28, 0.12)"');
    expect(BOX.filter((c) => classesOf(html).includes(c))).toEqual(BOX);
  });

  it('without label or style it is exactly what it was', () => {
    const html = renderToStaticMarkup(<SifStatusBadge status="POSTED" tone="x" />);
    expect(html).not.toContain('style=');
    expect(html).toContain('>POSTED</span>');
  });
});

const CATALOG: WpsStatusCatalogItem[] = [
  {
    statusCode: 'Rejected', statusKey: 'REJECTED', displayName: 'Rejected by CB', category: 'Failure', isTerminal: true,
    waitsFor: null, tone: 'Danger', colorHex: '#B91C1C', sortOrder: 95,
  },
  {
    statusCode: 'AwaitingCbAck', statusKey: 'CB_ACK_PENDING', displayName: 'Awaiting CB Acknowledgement', category: 'InProgress',
    isTerminal: false, waitsFor: 'CentralBankAck', tone: 'Info', colorHex: null, sortOrder: 50,
  },
];

/** Renders with the catalog already in the query cache, as it is after the session's one fetch. */
function renderWithCatalog(node: React.ReactNode, catalog?: WpsStatusCatalogItem[]) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  if (catalog) client.setQueryData(WPS_STATUS_CATALOG_QUERY_KEY, catalog);
  return renderToStaticMarkup(<QueryClientProvider client={client}>{node}</QueryClientProvider>);
}

describe('CatalogSifStatusBadge', () => {
  it('a status in the catalog takes its tone, ColorHex and DisplayName', () => {
    const html = renderWithCatalog(<CatalogSifStatusBadge status="Rejected" />, CATALOG);
    expect(html).toContain('>Rejected by CB</span>');
    expect(classesOf(html)).toContain('bg-red-50');
    expect(html).toContain('border-color:#B91C1C');
    expect(BOX.filter((c) => classesOf(html).includes(c))).toEqual(BOX);
  });

  it('a catalog tone beats the caller heuristic', () => {
    const html = renderWithCatalog(<CatalogSifStatusBadge status="AwaitingCbAck" heuristic={() => 'bg-amber-50'} />, CATALOG);
    expect(classesOf(html)).toContain('bg-blue-50');
    expect(classesOf(html)).not.toContain('bg-amber-50');
    expect(html).toContain('>Awaiting CB Acknowledgement</span>');
  });

  it('an unknown word falls back to the caller heuristic and the built-in label', () => {
    const html = renderWithCatalog(<CatalogSifStatusBadge status="CB_DISPATCHED" heuristic={() => 'bg-purple-50'} />, CATALOG);
    expect(classesOf(html)).toContain('bg-purple-50');
    expect(html).toContain('>CB_DISPATCHED</span>');
    expect(html).not.toContain('style=');
  });

  it('while the catalog has not loaded (nothing cached) the heuristic is drawn', () => {
    const html = renderWithCatalog(<CatalogSifStatusBadge status="AwaitingCbAck" />);
    expect(html).toContain('>Awaiting CB ACK</span>');
    expect(classesOf(html)).toContain('bg-amber-50');
  });

  it('an empty catalog (the server could not read it) draws the heuristic', () => {
    const html = renderWithCatalog(<CatalogSifStatusBadge status="Rejected" />, []);
    expect(html).toContain('>Rejected</span>');
    expect(classesOf(html)).toContain('bg-red-50');
    expect(html).not.toContain('style=');
  });
});
