import { useState, useEffect, useRef } from 'react';
import { PERM, CONTROL_PERM } from '../../../shared/auth/permissionKeys';
import { useQuery } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ChevronDown, ChevronLeft, ChevronRight, Filter, LayoutGrid, Search, X, Lock } from 'lucide-react';
import { Can, LoadingSpinner, PageBody, PageShell, SortIcon, cn, usePermissions, sessionInstant } from '@paymenthub/ui';
import { sifApi } from './sifApi';
import type { SifSummaryRow } from './sifApi';
import { SifSummary360Drawer } from './SifSummary360Drawer';
import { SifAuditTrailDrawer } from './SifAuditTrailDrawer';
import { CatalogSifStatusBadge } from './SifStatusBadge';
import { readInheritedUploadDates } from './sifDrillDown';
import { ReportExportDropdown } from '../../../shared/components/ReportExportDropdown';
import type { ExportFormat } from '../../../shared/components/ReportExportDropdown';

/**
 * Catalog keys guarding this screen. Mirrors `SifPermissions` on the server, where the matching
 * endpoints are gated — these decide what is rendered, those decide what is answered.
 */
const PERMISSION = {
  /** 360 drawer: file detail plus the employee records behind it. */
  detail360: CONTROL_PERM.sifSummary360View,
  /** Audit-trail drawer. */
  auditTrail: CONTROL_PERM.sifSummaryAuditTrail,
  /**
   * Export CSV / Excel / PDF. No longer advisory: the file is now built server-side by
   * `/api/reports/wps/sif-summaryReport/export/*`, which carries the same key, so re-enabling
   * the button in dev-tools earns a 403 rather than the data.
   */
  export: CONTROL_PERM.sifSummaryExport,
} as const;

/** Columns the grid can show, sort and filter. `filterKey` maps to a real query param. */
interface Column {
  key: keyof SifSummaryRow | 'actions';
  label: string;
  /** Query-param name accepted by GetSifSummaryReport; absent = not server-filterable. */
  filterKey?: string;
  /** `sortBy` value the endpoint expects. */
  sortKey?: string;
  numeric?: boolean;
  /** Renders a From/To date-range filter (maps to uploadDateFrom / uploadDateTo params). */
  dateRange?: boolean;
  /** Renders a From/To amount-range filter (maps to totalAmountFrom / totalAmountTo params). */
  amountRange?: boolean;
  visible: boolean;
}

const DEFAULT_COLUMNS: Column[] = [
  { key: 'slNo', label: 'SL No', visible: true },
  { key: 'fileName', label: 'File Name', filterKey: 'fileName', sortKey: 'fileName', visible: true },
  { key: 'transactionId', label: 'Transaction ID', filterKey: 'transactionId', sortKey: 'transactionId', visible: true },
  { key: 'corporateName', label: 'Corporate Name', filterKey: 'corporateName', sortKey: 'corporateName', visible: true },
  { key: 'accountNumber', label: 'Account Number', filterKey: 'accountNumber', sortKey: 'accountNumber', visible: true },
  { key: 'molEstablishmentId', label: 'MOL Establishment ID', filterKey: 'molEstablishmentId', sortKey: 'molEstablishmentId', visible: true },
  { key: 'uploadDate', label: 'Upload Date', sortKey: 'uploadDate', dateRange: true, visible: true },
  { key: 'totalRecords', label: 'Total Records', filterKey: 'totalRecords', sortKey: 'totalRecords', numeric: true, visible: true },
  { key: 'totalAmount', label: 'Total Amount', sortKey: 'totalAmount', numeric: true, amountRange: true, visible: true },
  { key: 'currentStatus', label: 'Status', sortKey: 'currentStatus', visible: true },
  { key: 'uploadedBy', label: 'Uploaded By', filterKey: 'uploadedBy', sortKey: 'uploadedBy', visible: true },
  { key: 'actions', label: 'Actions', visible: true },
];

const PAGE_SIZES = [10, 20, 50];

const COLS_STORAGE_KEY = 'sif-summary-columns-v1';

const money = (n: number | null | undefined) =>
  n == null ? '—' : n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Upload date-time: an instant in the session zone, `dd-MM-yyyy HH:mm:ss` (a thin delegate). */
const uploadDate = (s?: string | null) => sessionInstant(s);

// wps.TransactionState words: Settled is the only successful end state, the *-Failed / Rejected
// words are failures (as are Reversal and Blocked — end states that won't progress on their own),
// and every other word (Initiated, Posting, AwaitingCbAck, ACKReceived, …) is
// still in progress. Substring matching on 'ack'/'success' used to paint AwaitingCbAck and
// Validation-Success green even though the file was nowhere near settled.
// Only the FALLBACK now: a status the WPS status catalog (platform.RailStatusConfiguration) knows is drawn with the catalog's
// label and Tone (CatalogSifStatusBadge); this guess is used while the catalog loads, when it is empty, or for an unknown word.
const statusTone = (s: string) => {
  const str = String(s ?? '').toLowerCase();
  if (str.includes('fail') || str.includes('reject') || str.includes('error')
    || str.includes('reversal') || str.includes('blocked')) {
    return 'border-red-300 bg-red-50 text-red-700';
  }
  if (str === 'settled') {
    return 'border-green-300 bg-green-50 text-green-700';
  }
  return 'border-amber-300 bg-amber-50 text-amber-800';
};

const TH = 'px-3 py-2.5 text-left align-bottom whitespace-nowrap text-[12px] font-semibold uppercase tracking-wide text-[#4B5563]';
const TD = 'px-3 py-2.5 text-[13px] text-[var(--text-primary)] whitespace-nowrap';

export function SifSummaryReportPage() {
  const navigate = useNavigate();
  const { can } = usePermissions();

  /**
   * The account-number column is dropped for a caller without `field.account-number:view`.
   *
   * This hides chrome, not data: the API masks the value before it leaves the platform, so a caller
   * without the key receives `********` whatever this does, and one with it receives `****1234` or
   * the account number depending on `:unmask`. Rendering a column of asterisks would be honest and
   * useless — the same key that withholds the value withholds the column.
   */
  const permittedColumns = DEFAULT_COLUMNS.filter(
    (c) => c.key !== 'accountNumber' || can(PERM.viewAccountNumber),
  );

  const [columns, setColumns] = useState<Column[]>(() => {
    try {
      const raw = localStorage.getItem(COLS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Column[];
        if (Array.isArray(parsed) && parsed.every((p) => p && 'key' in p)) {
          // Saved layouts predate the grant the session holds now, so a stored `accountNumber`
          // entry is re-filtered rather than trusted — losing the key must drop the column even
          // for a browser that already persisted it.
          // Only the order and visibility are the user's; each column's definition (label, filter, sort) comes from
          // this code, so a column that gains a filter after being saved (Transaction ID, 2026-10-24) shows it.
          // Keys this build no longer knows are dropped.
          const saved = parsed
            .filter((c) => c.key !== 'accountNumber' || can(PERM.viewAccountNumber))
            .flatMap((c) => {
              const def = permittedColumns.find((p) => p.key === c.key);
              return def ? [{ ...def, visible: c.visible }] : [];
            });
          // A column added after the layout was saved (Transaction ID, 2026-10-23) would otherwise never appear for
          // that browser: slot each missing default in after the nearest default column the layout already has.
          permittedColumns.forEach((col, i) => {
            if (saved.some((s) => s.key === col.key)) return;
            const before = permittedColumns.slice(0, i).reverse().find((p) => saved.some((s) => s.key === p.key));
            saved.splice(before ? saved.findIndex((s) => s.key === before.key) + 1 : 0, 0, { ...col });
          });
          return saved;
        }
      }
    } catch (e) {
      // ignore and fall back to defaults
    }
    return permittedColumns.map((c) => ({ ...c }));
  });

  // Upload-date window handed over by Total Transactions (`?uploadDateFrom=…&uploadDateTo=…`).
  // Read once, in the state initialisers, so the very first request is already filtered — an
  // effect would let an unfiltered request go out first. BOTH draft and applied are seeded: the
  // debounce effect below copies draft over applied whenever they differ, so seeding applied alone
  // would be reverted to empty ~450 ms later.
  const [searchParams] = useSearchParams();
  const [inherited] = useState(() => {
    const { from, to } = readInheritedUploadDates(searchParams);
    return { ...(from && { uploadDateFrom: from }), ...(to && { uploadDateTo: to }) } as Record<string, string>;
  });

  const [showColumnPanel, setShowColumnPanel] = useState(false);
  // Open when a filter was inherited, so the narrowed list is visibly the result of a filter.
  const [showFilterRow, setShowFilterRow] = useState(() => Object.keys(inherited).length > 0);

  const [draft, setDraft] = useState<Record<string, string>>(() => ({ ...inherited }));
  const [applied, setApplied] = useState<Record<string, string>>(() => ({ ...inherited }));
  const [sortBy, setSortBy] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [detailRow, setDetailRow] = useState<SifSummaryRow | null>(null);
  const [auditRow, setAuditRow] = useState<SifSummaryRow | null>(null);

  const colPickerRef = useRef<HTMLDivElement | null>(null);
  const dragIndexRef = useRef<number | null>(null);

  useEffect(() => {
    if (!showColumnPanel) return;
    const onDown = (e: MouseEvent) => {
      if (colPickerRef.current && !colPickerRef.current.contains(e.target as Node)) setShowColumnPanel(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setShowColumnPanel(false);
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [showColumnPanel]);

  const persistColumns = (cols: Column[]) => {
    try {
      localStorage.setItem(COLS_STORAGE_KEY, JSON.stringify(cols));
    } catch (e) {
      // ignore storage errors
    }
  };

  const handleSaveColumns = () => {
    persistColumns(columns);
    setShowColumnPanel(false);
  };

  const handleResetDefault = () => {
    // Reset to what this session may see, not to DEFAULT_COLUMNS — otherwise the button hands
    // back the account-number column the grant withholds.
    const defaults = permittedColumns.map((c) => ({ ...c }));
    setColumns(defaults);
    try {
      localStorage.removeItem(COLS_STORAGE_KEY);
    } catch (e) { }
  };

  const listQ = useQuery({
    queryKey: ['sif-summary', applied, page, pageSize, sortBy, sortDir],
    queryFn: () => sifApi.summary({ ...applied, page, pageSize, sortBy, sortDir: sortBy ? sortDir : null }),
  });

  const rows = listQ.data?.data ?? [];
  const totalRecords = listQ.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalRecords / pageSize));
  const showingFrom = totalRecords === 0 ? 0 : (page - 1) * pageSize + 1;
  const showingTo = Math.min(page * pageSize, totalRecords);
  const visibleColumns = columns.filter((c) => c.visible);
  const activeFilterCount = Object.values(applied).filter((v) => v.trim()).length;

  const doSearch = () => {
    setPage(1);
    setApplied({ ...draft });
  };

  useEffect(() => {
    try {
      if (JSON.stringify(draft) === JSON.stringify(applied)) return;
    } catch (err) { }
    const id = window.setTimeout(() => {
      setPage(1);
      setApplied({ ...draft });
    }, 450);
    return () => window.clearTimeout(id);
  }, [draft, applied]);

  const clearAll = () => {
    setDraft({});
    setApplied({});
    setSortBy(null);
    setPage(1);
  };

  const sortColumn = (col: Column) => {
    if (!col.sortKey) return;
    if (sortBy === col.sortKey) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else {
      setSortBy(col.sortKey);
      setSortDir('asc');
    }
    setPage(1);
  };

  const handleExport = async (format: ExportFormat) => {
    // Source of truth for what gets exported is the live `columns` state — the same array that
    // drives `visibleColumns` for the grid — read fresh on every export click, not a snapshot
    // taken at mount or at the last "Save". 'slNo' is handled unconditionally by the backend
    // (always exported first, matching its locked/non-toggleable place in the grid); 'actions' is
    // a UI-only column (360 View / Audit buttons) with no backing data field, so it can never be
    // exported regardless of its visibility.
    const exportColumnKeys = columns
      .filter((c) => c.visible && c.key !== 'actions' && c.key !== 'slNo')
      .map((c) => String(c.key));

    return await sifApi.exportSifSummaryReport(
      format,
      { ...applied, sortBy, sortDir: sortBy ? sortDir : null },
      exportColumnKeys,
    );
  };

  const cell = (row: SifSummaryRow, col: Column) => {
    switch (col.key) {
      case 'fileName':
        // The filename is a second door into the 360 drawer. Disabling the row action while
        // leaving this one live would gate the control and not the capability, so it degrades
        // to plain text — the value still reads, it just stops being a link to somewhere the
        // session may not go.
        return can(PERMISSION.detail360) ? (
          <button
            onClick={() => setDetailRow(row)}
            className="font-mono text-xs font-semibold text-[var(--primary-blue)] hover:underline decoration-dotted underline-offset-2"
          >
            {row.fileName}
          </button>
        ) : (
          <span className="font-mono text-xs text-[var(--text-secondary)]">{row.fileName}</span>
        );
      case 'transactionId':
        return <span className="font-mono text-xs">{row.transactionId || '—'}</span>;
      case 'uploadDate':
        return uploadDate(row.uploadDate);
      case 'totalAmount':
        return money(row.totalAmount);
      case 'totalRecords':
        return row.totalRecords?.toLocaleString() ?? '—';
      case 'currentStatus':
        return <CatalogSifStatusBadge status={String(row.currentStatus ?? '')} heuristic={statusTone} />;
      case 'actions':
        // Disabled rather than hidden: both are part of the grid's established shape, and a
        // user seeing one greyed out learns the capability exists and can ask for it. The
        // matching endpoints refuse the call regardless of what the button does.
        return (
          <div className="flex items-center gap-1.5">
            <Can permission={PERMISSION.detail360} mode="disable">
              <button
                onClick={() => setDetailRow(row)}
                className="btn-secondary"
              >
                360 View
              </button>
            </Can>
            <Can permission={PERMISSION.auditTrail} mode="disable">
              <button
                onClick={() => setAuditRow(row)}
                className="btn-secondary"
              >
                Audit
              </button>
            </Can>
          </div>
        );
      default:
        return String(row[col.key as keyof SifSummaryRow] ?? '—');
    }
  };

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / Reports / WPS / '}
              <span className="text-[var(--text-secondary)]">SIF Summary Report</span>
            </p>
          </div>

          {/* Title and Top Actions */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                SIF Summary Report
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                WPS Salary Information File processing overview and status tracking
              </p>
            </div>


          </div>

          {/* Table Container Card */}
          <div >
            <div className="overflow-x-auto rounded-lg border border-[var(--border)] table-holder">
              {/* Header / Main Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px]">
                <div className='flex items-center gap-2'>
                  <h4 >SIF File Report</h4>
                  <span className="text-xs text-[var(--text-muted)]">({totalRecords.toLocaleString()} {totalRecords === 1 ? 'record' : 'records'})</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowFilterRow((v) => !v)}
                    className={cn(
                      'btn-tertiary h-38px',
                      showFilterRow
                        ? 'border-[var(--primary-blue)] bg-[var(--primary-blue)] text-[#ffffff]'
                        : '',
                    )}
                  >
                    <Filter size={13} />
                    Filters{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
                  </button>

                  <div className="relative" ref={colPickerRef}>
                    <button
                      onClick={() => setShowColumnPanel((v) => !v)}
                      className="btn-tertiary h-38px !py-1.5 inline-flex items-center gap-1.5"
                      aria-expanded={showColumnPanel}
                    >
                      <LayoutGrid size={13} />
                      Columns
                    </button>

                    {/* Columns Selector Dropdown */}
                    {showColumnPanel && (
                      <div className="absolute right-0 top-full z-30 mt-2 w-[270px] rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-3 shadow-2xl">
                        <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                          Show / Hide Columns
                        </div>
                        <div className="flex max-h-[300px] flex-col gap-1 overflow-y-auto pr-1">
                          {columns.map((col) => {
                            if (col.key === 'slNo' || col.key === 'actions') {
                              return (
                                <div key={String(col.key)} className="flex items-center gap-2 rounded px-2 py-1 bg-[var(--bg-secondary)]/40 opacity-70">
                                  <Lock size={13} className="text-[var(--text-muted)]" />
                                  <span className="text-xs text-[var(--text-secondary)] font-medium truncate">{col.label}</span>
                                </div>
                              );
                            }

                            return (
                              <label
                                key={String(col.key)}
                                className="flex cursor-pointer items-center gap-2 rounded px-2 py-1 hover:bg-[var(--bg-card-hover)]"
                              >
                                <input
                                  type="checkbox"
                                  checked={col.visible}
                                  onChange={() =>
                                    setColumns((cs) => cs.map((c) => (c.key === col.key ? { ...c, visible: !c.visible } : c)))
                                  }
                                  className="size-3.5 rounded accent-[var(--primary-blue)]"
                                />
                                <span className="text-xs text-[var(--text-primary)] truncate">{col.label}</span>
                              </label>
                            );
                          })}
                        </div>

                        <div className="mt-3 flex items-center justify-between border-t border-[var(--border)] pt-2.5">
                          <button
                            onClick={handleResetDefault}
                            className="btn-tertiary h-38px !px-2 !py-1 text-[11px]"
                          >
                            Reset Default
                          </button>
                          <button
                            onClick={handleSaveColumns}
                            className="btn-primary h-38px !px-3 !py-1 text-xs"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={doSearch}
                    className="btn-primary h-38px !py-1.5 !px-3 text-xs inline-flex items-center gap-1"
                  >
                    <Search size={13} />
                    Search
                  </button>

                  {activeFilterCount > 0 && (
                    <button
                      onClick={clearAll}
                      className="btn-tertiary h-38px !py-1.5 !px-3 text-xs inline-flex items-center gap-1 text-[var(--accent-red)] hover:text-[var(--accent-red)]"
                    >
                      <X size={13} />
                      Clear
                    </button>
                  )}
                  <div className="flex items-center gap-2">
                    {/* Disabled rather than hidden, now that the export endpoints exist: the control is a
                  real capability the user can be granted, and greying it out says so. The three
                  export routes carry the same key, so the refusal holds either way. */}
                    <Can permission={PERMISSION.export} mode="disable">
                      <ReportExportDropdown onExport={handleExport} reportName="sif-summary-report" />
                    </Can>
                  </div>
                </div>
              </div>



              {/* Table Area */}
              <div className="overflow-x-auto table-holder">
                <table className="w-full min-w-max text-sm">
                  <thead>
                    <tr className="border-b border-[var(--border)] bg-[var(--bg-secondary)]">
                      {visibleColumns.map((col) => {
                        const isLocked = col.key === 'slNo' || col.key === 'actions';
                        const originalIndex = columns.findIndex((c) => c.key === col.key);

                        return (
                          <th
                            key={String(col.key)}
                            className={TH}
                            draggable={!isLocked}
                            style={{ cursor: isLocked ? 'default' : 'grab' }}
                            onDragStart={(e) => {
                              if (isLocked) return;
                              dragIndexRef.current = originalIndex;
                              try {
                                e.dataTransfer?.setData('text/plain', String(originalIndex));
                                e.dataTransfer!.effectAllowed = 'move';
                              } catch (err) { }
                            }}
                            onDragOver={(e) => {
                              if (isLocked) return;
                              e.preventDefault();
                              e.dataTransfer!.dropEffect = 'move';
                            }}
                            onDrop={(e) => {
                              if (isLocked) return;
                              e.preventDefault();
                              const src = dragIndexRef.current ?? Number(e.dataTransfer?.getData('text/plain'));
                              const dest = originalIndex;
                              if (typeof src === 'number' && src !== dest && src >= 0 && dest >= 0) {
                                const next = [...columns];
                                const [moved] = next.splice(src, 1);
                                next.splice(dest, 0, moved);
                                setColumns(next);
                                persistColumns(next);
                              }
                              dragIndexRef.current = null;
                            }}
                          >
                            <span className="flex items-center gap-1.5">
                              <span>{col.label}</span>
                              {col.sortKey && (
                                <button
                                  type="button"
                                  onClick={() => sortColumn(col)}
                                  aria-label={`Sort by ${col.label}`}
                                  className="inline-flex items-center"
                                >
                                  <SortIcon direction={sortBy === col.sortKey ? sortDir : null} />
                                </button>
                              )}
                            </span>
                          </th>
                        );
                      })}
                    </tr>

                    {/* Filter Inputs Row */}
                    {showFilterRow && (
                      <tr className="border-b border-[var(--border)] bg-[var(--bg-card)]">
                        {visibleColumns.map((col) => (
                          <th key={String(col.key)} className="px-3 py-1.5 font-normal">
                            {col.dateRange ? (
                              <div className="flex min-w-[210px] items-center gap-1.5">
                                <input
                                  type="date"
                                  value={draft.uploadDateFrom ?? ''}
                                  max={draft.uploadDateTo || undefined}
                                  onChange={(e) => setDraft((d) => ({ ...d, uploadDateFrom: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') doSearch();
                                  }}
                                  aria-label="Upload date from"
                                  className="input-cls h-7 flex-1 text-[11px]"
                                />
                                <span className="text-[10px] text-[var(--text-muted)]">-</span>
                                <input
                                  type="date"
                                  value={draft.uploadDateTo ?? ''}
                                  min={draft.uploadDateFrom || undefined}
                                  onChange={(e) => setDraft((d) => ({ ...d, uploadDateTo: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') doSearch();
                                  }}
                                  aria-label="Upload date to"
                                  className="input-cls h-7 flex-1 text-[11px]"
                                />
                              </div>
                            ) : col.amountRange ? (
                              <div className="flex min-w-[210px] items-center gap-1.5">
                                <input
                                  type="number"
                                  inputMode="decimal"
                                  min={0}
                                  step="0.01"
                                  value={draft.totalAmountFrom ?? ''}
                                  max={draft.totalAmountTo || undefined}
                                  onChange={(e) => setDraft((d) => ({ ...d, totalAmountFrom: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') doSearch();
                                  }}
                                  placeholder="Min"
                                  aria-label="Total amount from"
                                  className="input-cls small-input h-7 w-[90px] flex-1 text-[11px]"
                                />
                                <span className="text-[10px] text-[var(--text-muted)]">-</span>
                                <input
                                  type="number"
                                  inputMode="decimal"
                                  min={draft.totalAmountFrom || 0}
                                  step="0.01"
                                  value={draft.totalAmountTo ?? ''}
                                  onChange={(e) => setDraft((d) => ({ ...d, totalAmountTo: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') doSearch();
                                  }}
                                  placeholder="Max"
                                  aria-label="Total amount to"
                                  className="input-cls small-input h-7 w-[90px] flex-1 text-[11px]"
                                />
                              </div>
                            ) : col.filterKey ? (
                              <input
                                value={draft[col.filterKey] ?? ''}
                                onChange={(e) => setDraft((d) => ({ ...d, [col.filterKey as string]: e.target.value }))}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') doSearch();
                                }}
                                placeholder="Filter…"
                                aria-label={`Filter ${col.label}`}
                                className="input-cls small-input h-7 w-full min-w-[90px] text-[11px]"
                              />
                            ) : null}
                          </th>
                        ))}
                      </tr>
                    )}
                  </thead>

                  <tbody className="divide-y divide-[var(--border-light)]">
                    {listQ.isLoading ? (
                      <tr>
                        <td colSpan={visibleColumns.length} className="px-3 py-10 text-center">
                          <LoadingSpinner />
                        </td>
                      </tr>
                    ) : listQ.isError ? (
                      <tr>
                        <td colSpan={visibleColumns.length} className="px-3 py-10 text-center text-xs font-semibold text-[var(--accent-red)]">
                          Could not load the SIF summary report.
                        </td>
                      </tr>
                    ) : rows.length === 0 ? (
                      <tr>
                        <td colSpan={visibleColumns.length} className="px-3 py-10 text-center text-xs text-[var(--text-muted)]">
                          No SIF files match the current filters.
                        </td>
                      </tr>
                    ) : (
                      rows.map((row, i) => (
                        <tr key={`${row.sifFileName}-${i}`} >
                          {visibleColumns.map((col) => (
                            <td key={String(col.key)} className={cn(TD, col.numeric && 'text-right tabular-nums')}>
                              {cell(row, col)}
                            </td>
                          ))}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Standard Pagination Bar */}
            <div className="pq-pagination">
              <span>
                Showing <strong>{showingFrom}–{showingTo}</strong> of <strong>{totalRecords.toLocaleString()}</strong> records
              </span>
              <div className="pq-pagination-controls">
                <div className="pq-pagesize">
                  <span>Rows per page:</span>
                  <div className="pq-pagesize-select">
                    <select
                      id="sif-page-size"
                      value={pageSize}
                      onChange={(e) => {
                        setPageSize(Number(e.target.value));
                        setPage(1);
                      }}
                    >
                      {PAGE_SIZES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <ChevronDown size={13} className="pq-pagesize-caret" />
                  </div>
                </div>
                <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1} className="btn-tertiary">
                  <ChevronLeft size={14} /> Previous
                </button>
                <span className="pq-page-badge">{page}</span>
                <button type="button" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="btn-tertiary">
                  Next <ChevronRight size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </PageBody>

      {detailRow && <SifSummary360Drawer row={detailRow} onClose={() => setDetailRow(null)} />}
      {auditRow && <SifAuditTrailDrawer row={auditRow} onClose={() => setAuditRow(null)} />}
    </PageShell>
  );
}