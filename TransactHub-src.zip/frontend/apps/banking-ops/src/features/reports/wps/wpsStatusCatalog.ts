/**
 * The WPS/SIF status vocabulary, as served by `GET /api/wps/status-catalog` (platform.RailStatusConfiguration).
 *
 * The report screens draw a status's label and colour from here instead of guessing from the word. Tone, colour and sort order are
 * display metadata only — nothing here decides anything about a transaction — and any of them may be null on rows older than the
 * columns. Everything in this file is pure; the cached fetch is `useWpsStatusCatalog`.
 */

/** The closed vocabulary of RailStatusConfiguration.Tone. */
export type WpsStatusTone = 'Success' | 'Danger' | 'Warning' | 'Info' | 'Neutral';

/** One status of the vocabulary (the endpoint's JSON, camelCase). */
export interface WpsStatusCatalogItem {
  /** The word written to the status tables. */
  statusCode: string;
  /** The stable semantic key (UPPER_SNAKE, e.g. CB_ACK_RECEIVED); null on rows that predate keys. */
  statusKey: string | null;
  displayName: string;
  /** Pending | InProgress | Success | Failure | ManualAction | Approval. */
  category: string;
  isTerminal: boolean;
  /** CentralBankAck | OperatorDecision, else null. */
  waitsFor: string | null;
  /** Success | Danger | Warning | Info | Neutral; null on rows that predate it. */
  tone: WpsStatusTone | string | null;
  /** Optional #RRGGBB override of the tone's colour. */
  colorHex: string | null;
  /** Lifecycle position, for legends and filters. */
  sortOrder: number | null;
}

/** A lookup over the catalog. Built once per fetch, so a grid of rows does not re-scan the array per cell. */
export interface WpsStatusIndex {
  readonly items: readonly WpsStatusCatalogItem[];
  /** The catalog entry for a status word, or undefined (empty catalog, or an unknown word). */
  find(word: string | null | undefined): WpsStatusCatalogItem | undefined;
}

/**
 * Tailwind classes per tone — the same palette (and the same CSS variables for Neutral) the pills have always used, so dark mode
 * behaves as before.
 */
export const TONE_CLASSES: Record<WpsStatusTone, string> = {
  Success: 'border-green-300 bg-green-50 text-green-700',
  Danger: 'border-red-300 bg-red-50 text-red-700',
  Warning: 'border-amber-300 bg-amber-50 text-amber-800',
  Info: 'border-blue-300 bg-blue-50 text-blue-700',
  Neutral: 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]',
};

/** The tone's classes, or undefined for a null / unknown tone (the caller then keeps its own heuristic). */
export function toneClasses(tone: string | null | undefined): string | undefined {
  if (!tone) return undefined;
  const wanted = tone.trim().toLowerCase();
  const match = (Object.keys(TONE_CLASSES) as WpsStatusTone[]).find((t) => t.toLowerCase() === wanted);
  return match ? TONE_CLASSES[match] : undefined;
}

const HEX = /^#[0-9a-fA-F]{6}$/;

/**
 * An inline colour override for a `#RRGGBB` value: border and text in the colour, background the same colour translucent (so it
 * reads on a light and a dark card alike). Undefined for anything that is not exactly `#RRGGBB`.
 */
export function colorOverrideStyle(colorHex: string | null | undefined): { borderColor: string; color: string; backgroundColor: string } | undefined {
  const hex = colorHex?.trim();
  if (!hex || !HEX.test(hex)) return undefined;
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return { borderColor: hex, color: hex, backgroundColor: `rgba(${r}, ${g}, ${b}, 0.12)` };
}

/**
 * Builds the lookup. A word resolves, in order, by exact status code; case-insensitive status code; exact status key; case-insensitive
 * status key. The key step is what lets the UPPER_SNAKE words workflow events carry (CB_ACK_RECEIVED, POSTED, REJECTION_NOTIFIED)
 * reach the status they are the event of. The first entry in catalog (lifecycle) order wins a tie.
 */
export function createWpsStatusIndex(items: readonly WpsStatusCatalogItem[] | null | undefined): WpsStatusIndex {
  const list = Array.isArray(items) ? items.filter((i) => i && typeof i.statusCode === 'string') : [];
  const byCode = new Map<string, WpsStatusCatalogItem>();
  const byCodeLower = new Map<string, WpsStatusCatalogItem>();
  const byKey = new Map<string, WpsStatusCatalogItem>();
  const byKeyLower = new Map<string, WpsStatusCatalogItem>();
  for (const item of list) {
    if (!byCode.has(item.statusCode)) byCode.set(item.statusCode, item);
    const lower = item.statusCode.toLowerCase();
    if (!byCodeLower.has(lower)) byCodeLower.set(lower, item);
    if (item.statusKey) {
      if (!byKey.has(item.statusKey)) byKey.set(item.statusKey, item);
      const keyLower = item.statusKey.toLowerCase();
      if (!byKeyLower.has(keyLower)) byKeyLower.set(keyLower, item);
    }
  }

  return {
    items: list,
    find(word) {
      const w = word?.trim();
      if (!w || list.length === 0) return undefined;
      const lower = w.toLowerCase();
      return byCode.get(w) ?? byCodeLower.get(lower) ?? byKey.get(w) ?? byKeyLower.get(lower);
    },
  };
}

/** A catalog with nothing in it: every lookup misses, so callers use their heuristics. */
export const EMPTY_STATUS_INDEX: WpsStatusIndex = createWpsStatusIndex([]);

/**
 * Options for a status filter, in lifecycle order: by `sortOrder` (entries without one last), then code. Built from the catalog, so a
 * renamed or added status needs no screen change. Empty when the catalog is.
 */
export function statusFilterOptions(items: readonly WpsStatusCatalogItem[] | null | undefined): { value: string; label: string }[] {
  return [...(items ?? [])]
    .sort((a, b) => (a.sortOrder ?? Number.MAX_SAFE_INTEGER) - (b.sortOrder ?? Number.MAX_SAFE_INTEGER) || a.statusCode.localeCompare(b.statusCode))
    .map((i) => ({ value: i.statusCode, label: i.displayName || i.statusCode }));
}
