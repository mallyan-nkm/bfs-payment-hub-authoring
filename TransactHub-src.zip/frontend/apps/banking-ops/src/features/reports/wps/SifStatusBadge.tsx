import type { CSSProperties } from 'react';
import { cn } from '@paymenthub/ui';
import { useWpsStatusCatalog } from './useWpsStatusCatalog';

/**
 * Status pill shared by the SIF Summary grid, its 360 drawer and the Audit Trail drawer.
 *
 * The box is a fixed width (w-40) with a one-line minimum height (min-h-6) so INITIATED and
 * CHARGES_CALCULATED render identically; a value too long for one line wraps onto further lines (the
 * pill grows taller, never wider) so the full text is always visible. `title` carries it too.
 * `tone` supplies only the semantic colours (border / background / text) — the caller keeps
 * its own tone function, so this component never decides what a status means. `label` (the status
 * catalog's DisplayName) replaces the built-in label for the word, and `style` carries the catalog's
 * optional colour override; both are optional and the box is the same either way.
 */
const STATUS_LABELS: Record<string, string> = {
  AwaitingCbAck: 'Awaiting CB ACK',
};

/** Display text only: the stored wps.TransactionState code stays as is (dashboard, SLA monitor and tones key on it). */
export const sifStatusLabel = (status: string) => STATUS_LABELS[status] ?? status;

export function SifStatusBadge({
  status,
  tone,
  className,
  label: catalogLabel,
  style,
}: {
  status: string;
  tone: string;
  className?: string;
  /** The catalog's display name for the status; the built-in label for the word when absent. */
  label?: string;
  /** Inline colour override (the catalog's ColorHex). */
  style?: CSSProperties;
}) {
  const label = catalogLabel || sifStatusLabel(status);
  return (
    <span
      title={label}
      style={style}
      className={cn(
        'inline-flex min-h-6 w-40 shrink-0 items-center justify-center rounded-full border px-2 py-1 text-center text-[10px] font-bold uppercase leading-tight whitespace-normal break-words',
        tone,
        className,
      )}
    >
      <span className="min-w-0 break-words">{label}</span>
    </span>
  );
}

/**
 * The pill for a workflow status, drawn from the status catalog (label, tone, optional colour) with the caller's heuristic as the
 * fallback while the catalog loads, when it is empty, or when it does not know the word. Needs a QueryClientProvider.
 */
export function CatalogSifStatusBadge({
  status,
  heuristic,
  className,
}: {
  status: string;
  /** Colour classes to use when the catalog does not know the word; defaults to the shared substring heuristic. */
  heuristic?: (status: string) => string;
  className?: string;
}) {
  const { resolve } = useWpsStatusCatalog();
  const display = resolve(status, heuristic);
  return <SifStatusBadge status={status} tone={display.tone} label={display.label} style={display.style} className={className} />;
}
