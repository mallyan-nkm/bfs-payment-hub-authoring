/**
 * Date hand-off between Total Transactions and the WPS SIF reports: how the applied Transaction
 * Date filter becomes `uploadDateFrom` / `uploadDateTo`, and how a SIF page reads them back.
 */
import { describe, expect, it } from 'vitest';
import type { DashboardDateFilter } from '../../dashboard/types';
import { isIsoDay, readInheritedUploadDates, resolveUploadDateRange } from './sifDrillDown';

const filter = (over: Partial<DashboardDateFilter>): DashboardDateFilter => ({
  dateType: 'transactionDate',
  dateRange: 'today',
  dateFrom: '',
  dateTo: '',
  ...over,
});

describe('resolveUploadDateRange', () => {
  // 00:30 in Dubai on 15-09 is still 14-09 in UTC — the case toISOString() would get wrong. The days are the
  // session zone's (T-22), whatever the browser's zone.
  const justAfterDubaiMidnight = Date.parse('2026-09-14T20:30:00Z');
  const DUBAI = 'Asia/Dubai';

  it('maps Today to the session-zone calendar day on both bounds', () => {
    expect(resolveUploadDateRange(filter({ dateRange: 'today' }), justAfterDubaiMidnight, DUBAI)).toEqual({
      uploadDateFrom: '2026-09-15',
      uploadDateTo: '2026-09-15',
    });
  });

  it('maps Yesterday to the previous session-zone calendar day on both bounds', () => {
    expect(resolveUploadDateRange(filter({ dateRange: 'yesterday' }), justAfterDubaiMidnight, DUBAI)).toEqual({
      uploadDateFrom: '2026-09-14',
      uploadDateTo: '2026-09-14',
    });
  });

  it('rolls Yesterday across a month and year boundary', () => {
    const newYear = Date.parse('2027-01-01T05:00:00Z'); // 09:00 Dubai
    expect(resolveUploadDateRange(filter({ dateRange: 'yesterday' }), newYear, DUBAI)).toEqual({
      uploadDateFrom: '2026-12-31',
      uploadDateTo: '2026-12-31',
    });
  });

  it('passes a Custom Range through unchanged', () => {
    expect(
      resolveUploadDateRange(filter({ dateRange: 'customRange', dateFrom: '2026-09-01', dateTo: '2026-09-07' })),
    ).toEqual({ uploadDateFrom: '2026-09-01', uploadDateTo: '2026-09-07' });
  });

  it('accepts a single-day Custom Range', () => {
    expect(
      resolveUploadDateRange(filter({ dateRange: 'customRange', dateFrom: '2026-09-03', dateTo: '2026-09-03' })),
    ).toEqual({ uploadDateFrom: '2026-09-03', uploadDateTo: '2026-09-03' });
  });

  it.each([
    ['missing bounds', '', ''],
    ['one bound missing', '2026-09-01', ''],
    ['malformed bound', '2026-9-1', '2026-09-07'],
    ['impossible date', '2026-02-31', '2026-03-05'],
    ['inverted range', '2026-09-07', '2026-09-01'],
  ])('returns null for a Custom Range with %s', (_name, dateFrom, dateTo) => {
    expect(resolveUploadDateRange(filter({ dateRange: 'customRange', dateFrom, dateTo }))).toBeNull();
  });

  it.each(['today', 'yesterday', 'customRange'] as const)(
    'returns null for Value Date (%s) — the SIF reports have no value-date filter',
    (dateRange) => {
      expect(
        resolveUploadDateRange(filter({ dateType: 'valueDate', dateRange, dateFrom: '2026-09-01', dateTo: '2026-09-07' })),
      ).toBeNull();
    },
  );
});

describe('readInheritedUploadDates', () => {
  const read = (qs: string) => readInheritedUploadDates(new URLSearchParams(qs));

  it('reads both bounds', () => {
    expect(read('uploadDateFrom=2026-09-01&uploadDateTo=2026-09-07')).toEqual({ from: '2026-09-01', to: '2026-09-07' });
  });

  it('reads a single bound', () => {
    expect(read('uploadDateFrom=2026-09-01')).toEqual({ from: '2026-09-01' });
    expect(read('uploadDateTo=2026-09-07')).toEqual({ to: '2026-09-07' });
  });

  it('returns nothing when the params are absent', () => {
    expect(read('')).toEqual({});
  });

  it('ignores a malformed bound but keeps the valid one', () => {
    expect(read('uploadDateFrom=banana&uploadDateTo=2026-09-07')).toEqual({ to: '2026-09-07' });
    expect(read('uploadDateFrom=2026-09-01&uploadDateTo=2026-13-40')).toEqual({ from: '2026-09-01' });
  });

  it('drops both bounds when they are inverted', () => {
    expect(read('uploadDateFrom=2026-09-07&uploadDateTo=2026-09-01')).toEqual({});
  });

  it('does not read the dashboard\'s own params', () => {
    expect(read('dateType=transactionDate&dateRange=today&from=2026-09-01&to=2026-09-07&rail=WPS')).toEqual({});
  });
});

describe('day helpers', () => {
  it.each(['2026-09-15', '2024-02-29'])('accepts %s', (v) => expect(isIsoDay(v)).toBe(true));
  it.each(['', null, undefined, '2026-9-15', '15-09-2026', '2026-02-29', '2026-00-10', '2026-09-15T00:00:00Z'])(
    'rejects %s',
    (v) => expect(isIsoDay(v)).toBe(false),
  );
});
