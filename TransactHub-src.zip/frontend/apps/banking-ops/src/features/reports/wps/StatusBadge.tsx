import { useWpsStatusCatalog } from './useWpsStatusCatalog';
import { colorOverrideStyle } from './wpsStatusCatalog';

/** The existing badge class a catalog tone maps to (Info and Neutral have no class of their own, so they take the plain one). */
const TONE_BADGE_CLASS: Record<string, string> = {
  success: 'badge-success',
  danger: 'badge-failed',
  warning: 'badge-pending',
  info: 'badge-edr',
  neutral: 'badge-edr',
};

/** The heuristic the 'fileStatus' badge has always used; kept as the fallback for a status the catalog does not know. */
function fileStatusHeuristicClass(v: string) {
  if (/ACK/i.test(v) || /Completed/i.test(v)) return 'badge-success';
  if (/NAK|Failed|Exception/i.test(v)) return 'badge-failed';
  return 'badge-pending';
}

/**
 * A workflow (file) status: label and tone come from the WPS status catalog (platform.RailStatusConfiguration) when it knows the
 * word, optionally recoloured by its ColorHex; otherwise the substring heuristic above.
 */
function FileStatusBadge({ value }: { value: string }) {
  const { index } = useWpsStatusCatalog();
  const entry = index.find(value);
  const toneClass = entry?.tone ? TONE_BADGE_CLASS[entry.tone.trim().toLowerCase()] : undefined;
  const cls = `badge ${toneClass ?? fileStatusHeuristicClass(value)}`;
  return (
    <span className={cls} style={colorOverrideStyle(entry?.colorHex)}>
      {entry?.displayName?.trim() || value}
    </span>
  );
}

export default function StatusBadge({ kind, value }: { kind: 'fileStatus' | 'ackNak' | 'edrStatus' | 'accountType' | 'generic'; value?: string }) {
  const v = value ?? '';
  if (kind === 'fileStatus') return <FileStatusBadge value={v} />;

  let cls = 'badge';
  switch (kind) {
    case 'ackNak':
      cls += v.toUpperCase() === 'ACK' ? ' badge-success' : ' badge-failed';
      break;
    case 'edrStatus':
      if (/Processed/i.test(v)) cls += ' badge-success';
      else if (/Returned/i.test(v)) cls += ' badge-pending';
      else if (/Rejected/i.test(v)) cls += ' badge-failed';
      else cls += ' badge-edr';
      break;
    case 'accountType':
      if (/Own/i.test(v)) cls += ' badge-own';
      else if (/Other/i.test(v)) cls += ' badge-other';
      else cls += ' badge-other';
      break;
    default:
      cls += ' badge-edr';
  }

  return <span className={cls}>{v}</span>;
}
