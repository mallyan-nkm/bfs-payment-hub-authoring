/**
 * SIF Summary -> Audit Trail drawer -> Remarks "View more".
 *
 * A short remark is shown in full in the grid. A long one is previewed (two lines, full text in the tooltip) with a
 * "View more" button that opens a modal holding the complete, unaltered text.
 *
 * Rendered in jsdom against a mocked sifApi.
 */
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SifAuditTrailDrawer } from './SifAuditTrailDrawer';
import { REMARK_PREVIEW_CHARS, isLongRemark } from './SifAuditRemarksModal';
import type { SifAuditActivityRow, SifAuditTrailResult, SifSummaryRow } from './sifApi';

const api = vi.hoisted(() => ({
  auditTrail: vi.fn(),
  auditTrailPayload: vi.fn(),
  exportAuditTrail: vi.fn(),
}));

vi.mock('./sifApi', () => ({ sifApi: api }));

const ROW: SifSummaryRow = {
  slNo: 1,
  fileName: 'F.SIF',
  sifFileName: 'F.SIF',
  transactionId: 'TXN-1',
  corporateName: 'Acme',
  accountNumber: '123',
  molEstablishmentId: '0001234567895',
  uploadDate: '2026-10-08T01:00:14',
  totalRecords: 10,
  totalAmount: 1000,
  currentStatus: 'BalanceInsufficientProceeded',
  uploadedBy: 'ops',
};

const LONG =
  'Insufficient balance: available 1000000.00 is below the required 1431079.90 (short by 431079.90). ' +
  'Not parked on the exception queue because ParkInsufficientBalanceInExceptionQueue is disabled (false) for tenant DIB; ' +
  'the file proceeds to the next step of the workflow without an operator decision.';
const SHORT = 'Available 1000000.00 below required 1431079.90';

const act = (activity: string, remarks: string): SifAuditActivityRow => ({
  activity,
  actionBy: 'svc',
  actionedDateTime: '08-10-2026 01:00:10 AM',
  occurredAtUtc: '2026-10-08T01:00:10Z',
  channel: 'IB',
  status: 'Failed',
  remarks,
  moreDetails: null,
  auditLogId: null,
});

const trail = (...activities: SifAuditActivityRow[]): SifAuditTrailResult => ({
  reference: 'F.SIF',
  transactionType: 'WPS — SIF Salary File',
  customer: 'Acme',
  status: 'BalanceInsufficientProceeded',
  channel: 'IB',
  activities,
});

function renderDrawer() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <SifAuditTrailDrawer row={ROW} onClose={() => {}} />
    </QueryClientProvider>,
  );
}

beforeEach(() => vi.clearAllMocks());
afterEach(cleanup);

describe('isLongRemark', () => {
  it('is false for empty/short and true only past the preview length', () => {
    expect(isLongRemark(null)).toBe(false);
    expect(isLongRemark('')).toBe(false);
    expect(isLongRemark('x'.repeat(REMARK_PREVIEW_CHARS))).toBe(false);
    expect(isLongRemark('x'.repeat(REMARK_PREVIEW_CHARS + 1))).toBe(true);
    expect(isLongRemark(' '.repeat(500))).toBe(false);
  });
});

describe('Audit Trail remarks "View more"', () => {
  it('a short remark is shown in full with no button', async () => {
    api.auditTrail.mockResolvedValue(trail(act('BalanceCheck', SHORT)));
    renderDrawer();
    await screen.findByText(SHORT);

    expect(screen.queryByRole('button', { name: 'View full remarks' })).toBeNull();
  });

  it('a long remark gets a View more button that opens the full text, and Close dismisses it', async () => {
    api.auditTrail.mockResolvedValue(trail(act('BalanceEnquiry', LONG)));
    renderDrawer();
    await screen.findByText('BalanceEnquiry');

    fireEvent.click(screen.getByRole('button', { name: 'View full remarks' }));

    const dialog = screen.getByRole('dialog', { name: 'Remarks' });
    expect(within(dialog).getByText(LONG)).toBeTruthy();
    expect(within(dialog).getByText('Remarks — BalanceEnquiry')).toBeTruthy();

    fireEvent.click(within(dialog).getByRole('button', { name: 'Close' }));
    expect(screen.queryByRole('dialog', { name: 'Remarks' })).toBeNull();
  });

  it('each long remark opens its own text; the preview carries the full text as a tooltip', async () => {
    const other = `${LONG} (second)`;
    api.auditTrail.mockResolvedValue(trail(act('First', LONG), act('Second', other)));
    renderDrawer();
    await screen.findByText('Second');

    fireEvent.click(screen.getAllByRole('button', { name: 'View full remarks' })[1]);
    expect(within(screen.getByRole('dialog', { name: 'Remarks' })).getByText(other)).toBeTruthy();
    expect(document.querySelector(`[title="${other}"]`)).not.toBeNull();
  });

  it('a short remark ending in a long unbroken file name stays fully in the DOM and may wrap anywhere', async () => {
    const ack = 'CB accepted file 0001234567890261110011942126000001006.ACK';
    api.auditTrail.mockResolvedValue(trail(act('CentralBankAckReceived', ack)));
    renderDrawer();

    const cell = await screen.findByText(ack);
    expect(cell.className).toContain('[overflow-wrap:anywhere]');
    expect(cell.className).toContain('whitespace-normal');
    expect(screen.queryByRole('button', { name: 'View full remarks' })).toBeNull();
  });
});
