import { bankingApi } from '../../../shared/api/bankingApi';
import type { WpsStatusCatalogItem } from './wpsStatusCatalog';
import { dayEndUtcExclusive, dayStartUtc } from '@paymenthub/ui';

export interface PaginatedResponse<T> {
  data: T[];
  totalRecords: number;
  page: number;
  pageSize: number;
}

/**
 * SIF Summary Report Row.
 * Date fields are in ISO 8601 format.
 */
export interface SifSummaryRow {
  slNo: number;
  fileName: string;
  sifFileName: string;
  transactionId?: string;
  corporateName: string;
  accountNumber: string;
  molEstablishmentId: string;
  uploadDate: string; // ISO 8601 datetime
  totalRecords: number;
  totalAmount: number;
  currentStatus: string;
  uploadedBy: string;
}

/** Maps 1:1 to the query params GetSifSummaryReport accepts (SifReportEndpoints.cs). */
export interface SifSummaryFilters {
  fileName?: string | null;
  transactionId?: string | null;
  corporateName?: string | null;
  accountNumber?: string | null;
  molEstablishmentId?: string | null;
  uploadDateFrom?: string | null;
  uploadDateTo?: string | null;
  totalRecords?: string | null;
  totalAmount?: string | null;
  /** Inclusive range on the file's total amount; either bound may be given alone. */
  totalAmountFrom?: string | null;
  totalAmountTo?: string | null;
  uploadedBy?: string | null;
  page?: number;
  pageSize?: number;
  sortBy?: string | null;
  sortDir?: 'asc' | 'desc' | null;
}

/**
 * Masked account field matching backend MaskedFieldDto.
 * Backend contract (C#):
 *   public required string MaskedValue { get; init; }  // never null, but can be empty string
 *   public string? ActualValue { get; init; }         // nullable
 * 
 * When an account number is missing or invalid, backend returns:
 *   { MaskedValue: "", ActualValue: null }
 * 
 * When an account number exists:
 *   { MaskedValue: "masked version", ActualValue: "full value" | null }
 * 
 * The actualValue is populated only when the unmask flag is true AND the user has permission.
 */
export interface SifDetailMaskedField {
  maskedValue: string;
  actualValue: string | null;
}

/** Backend response type where corporateName can be null */
interface SifDetailReportRowBackend extends Omit<SifDetailReportRow, 'corporateName'> {
  corporateName: string | null;
}

/**
 * SIF Detail Report Row - normalized for frontend consumption.
 * 
 * Date/DateTime fields (fileUploadDateTime, ackNakReceivedDateTime, payStartDate, payEndDate)
 * are expected to be in ISO 8601 format from the backend API.
 * Backend should return dates as `yyyy-MM-ddTHH:mm:ss.fffZ` or `yyyy-MM-dd`.
 */
export interface SifDetailReportRow {
  slNo: number;
  fileName: string;
  sifFileName: string;
  employerUniqueId: string;
  corporateName: string;
  debitAccountNumber: SifDetailMaskedField;
  routingCode: string;
  salaryMonth: string;
  salaryYear: number | null;
  fileUploadDateTime: string; // ISO 8601 datetime
  channel: string;
  ackNakStatus: string | null;
  ackNakReceivedDateTime: string | null; // ISO 8601 datetime when present
  totalRecordCount: number;
  totalSalaryAmount: number;
  currentStatus: string | null;
  employeeUniqueId: string;
  creditAccountNumber: SifDetailMaskedField;
  payStartDate: string | null; // ISO 8601 date when present
  payEndDate: string | null; // ISO 8601 date when present
  noOfDays: number;
  fixedAmount: number;
  variableAmount: number;
  leaveDays: number;
  mohreUpdateStatus: string;
  accountType: string;
  bankName: string;
  edrStatus: string;
  housingAllowance: number;
  conveyanceAllowance: number;
  medicalAllowance: number;
  annualPassageAllowance: number;
  overtimeAllowance: number;
  otherAllowances: number;
  leaveEncashment: number;
}

export interface SifDetailReportFilters {
  fileName?: string | null;
  sifFileName?: string | null;
  corporateName?: string | null;
  accountNumber?: string | null;
  uploadDateFrom?: string | null;
  uploadDateTo?: string | null;
  totalRecords?: string | null;
  totalAmount?: string | null;
  status?: string | null;
  uploadedBy?: string | null;
  page?: number;
  pageSize?: number;
  sortBy?: string | null;
  sortDir?: 'asc' | 'desc' | null;
}

export type SifDetailExportFormat = 'csv' | 'excel' | 'pdf';

/**
 * SIF File Detail Response.
 * Date/DateTime fields are in ISO 8601 format.
 */
export interface SifFileDetailResponse {
  fileName: string;
  corporate: string;
  channel: string;
  initiatedDateTime: string; // ISO 8601 datetime
  initiatedBy: string;
  currentStatus: string | null;
  totalRecords: number;
  systemAccepted: number;
  systemRejected: number;
  cbResponse: string | null;
  cbFileName: string | null;
  /** smartintegration.IntegrationMessageLog.CreatedAt of the successful UploadSIFFile call (ISO 8601, UTC, no zone suffix); null when none. */
  sentToCbDateTime: string | null;
  totalTransactionAmount: number | null;
  totalSalaryAmount: number;
  chargeAmount: number | null;
  vatAmount: number | null;
  /** The Central Bank's per-record NAK reasons (DER records of the latest NAK); empty for an ACK or no response. */
  nakErrors?: SifNakError[];
  /**
   * Employee records whose routing code is the bank's own configured routing code ("Own A/Cs"). Null when it cannot be
   * determined (no valid configured routing code, no persisted employee records, or a read failure); shown as "—".
   */
  ownBankAccounts?: number | null;
  /** Employee records whose routing code is any other ("Other Bank A/C"); null exactly when `ownBankAccounts` is. */
  otherBankAccounts?: number | null;
}

/** One DER record of a Central Bank NAK (UAEWPS SSM 5.6.47). */
export interface SifNakError {
  /** Line of the SIF the Central Bank rejected. */
  lineNumber: number;
  errorCode: string;
  description: string;
}

/**
 * SIF Employee Record.
 * Date fields are in ISO 8601 format (yyyy-MM-dd).
 */
export interface SifEmployeeRecord {
  employeeUniqueId: string;
  creditAccountNumber: string;
  routingCode: string;
  payStartDate: string; // ISO 8601 date
  payEndDate: string; // ISO 8601 date
  numberOfDays: number;
  fixedAmount: number;
  variableAmount: number;
  leaveDays: number;
  housingAllowance: number;
  conveyanceAllowance: number;
  medicalAllowance: number;
  annualPassageAllowance: number;
  overtimeAllowance: number;
  otherAllowance: number;
  leaveEncashment: number;
}

/**
 * The SIF file's own Salary Control Record (wps.Sif_Scr) — a file-level declared total, distinct
 * from any sum of its employee (Record List) rows. Null when the file has no matching SCR row.
 */
export interface SifControlRecord {
  establishmentId: string;
  recordCount: number;
  totalSalary: number;
  /** MMYYYY, e.g. "082026". */
  salaryMonth: string;
}

/**
 * SIF Audit Activity Row.
 */
export interface SifAuditActivityRow {
  activity: string;
  actionBy: string;
  /**
   * Display-formatted by the backend as "dd-MM-yyyy hh:mm:ss tt" (NOT ISO 8601) from
   * wps.workflow_events.OccurredAt (UTC), with no timezone conversion applied server-side. Do
   * not parse this string for filtering/sorting by date — use auditTrail()'s actionedFrom/
   * actionedTo params, which filter server-side against the raw OccurredAt column instead. Kept
   * only for the CSV/Excel/PDF exporters; the grid displays occurredAtUtc instead (see below).
   */
  actionedDateTime: string;
  /**
   * The same event's raw wps.workflow_events.OccurredAt value, UTC, as a real ISO 8601 timestamp
   * (backend tags it DateTimeKind.Utc before serializing, so it round-trips with a trailing 'Z').
   * Intended for client-side timezone-aware display — convert with `new Date(occurredAtUtc)`
   * before rendering, the same way SifSummaryReportPage's uploadDate() does, rather than showing
   * actionedDateTime's raw-UTC display string as-is.
   */
  occurredAtUtc?: string;
  channel: string;
  status: string;
  remarks: string | null;
  moreDetails: string | null;
  /**
   * The platform.AuditLog row behind this activity — set only on the upload request/reply rows, the
   * ones with a request/response body to open via sifApi.auditTrailPayload. Null/absent on every
   * workflow_events row, which has no such bodies, so the grid shows no "View more" link there.
   */
  auditLogId?: number | null;
}

/**
 * The bodies behind one upload audit row, fetched on demand (the grid never loads them). Both are the
 * raw JSON text as the channel sent / received it; either is null when that half was not audited — e.g.
 * a reply refused before the request was recorded.
 */
export interface SifAuditTrailPayload {
  auditLogId: number;
  requestBody: string | null;
  /** ISO 8601, UTC. */
  requestedAtUtc: string | null;
  responseBody: string | null;
  /** ISO 8601, UTC. */
  respondedAtUtc: string | null;
}

/**
 * Audit Trail date-range filter. actionedFrom/actionedTo are plain `YYYY-MM-DD` values straight
 * out of a native `<input type="date">` — calendar days in the session zone (UTC date-time T-22).
 * auditTrail()/exportAuditTrail() send them as UTC bounds: actionedFrom = the day's start,
 * actionedTo = the next day's start (exclusive), so a selected day holds every event on it in the
 * session zone, whatever the browser's own zone.
 */
export interface SifAuditTrailFilters {
  actionedFrom?: string | null;
  actionedTo?: string | null;
}

/**
 * A single leg within a posting attempt (Integration 360 -> CORE tab). Sourced from
 * wps.CoreBankingPostingLegs.
 */
export interface PostingLeg {
  legSequence: number;
  legType: string; // raw single character, e.g. "D" / "C"
  accountNumber: string;
  amount: number;
  currency: string;
  branchCode: string;
  /** Per-leg transaction code in the report display vocabulary (Salary/BankCharge/CBCharge/VatAmount; NakReversal on reversal legs — labels the Reporting service maps from the stored codes). Not transactionType. */
  txnTypeCode: string;
}

/**
 * One posting attempt (Integration 360 -> CORE tab) — one core-banking call and its legs, grouped
 * by Xref. transactionType is "SALARY" for the original posting or "REVERSAL" for a SIFNAK
 * reversal. status/endTime come from the single smartintegration.IntegrationMessageLog row
 * matching correlationId + operation (correlationId is the file's TransactionId, NOT the posting
 * leg's Xref — that table is never keyed by Xref; operation disambiguates the balance
 * enquiry/posting/reversal calls that can share one TransactionId) and are null when that row
 * hasn't been written yet. Pass both correlationId and operation to sifApi.logPayload.
 */
export interface PostingAttempt {
  transactionType: string;
  startTime: string; // ISO 8601 datetime
  status: string | null;
  endTime: string | null; // ISO 8601 datetime
  /** Unique per attempt (a posting and its later reversal differ) — use as the row/expand-state key. */
  xref: string;
  correlationId: string;
  operation: string;
  legs: PostingLeg[];
}

/**
 * One row of the Integration 360 -> Channel Interactions grid — a non-posting integration call
 * made for the transaction (balance enquiry, channel notification), sourced from
 * smartintegration.IntegrationMessageLog. Posting/reversal calls are not included here; those are
 * the CORE Ledger Posting tab's own grid (see PostingAttempt above).
 */
export interface ChannelInteraction {
  channel: string;
  action: string;
  startDateTime: string; // ISO 8601 datetime
  endDateTime: string | null; // ISO 8601 datetime
  status: string | null;
  direction: string;
  /** Pass both to sifApi.logPayload for the Req Log/Res Log "View" buttons. */
  correlationId: string;
  operation: string;
  retry: number;
  failureReason: string | null;
}

export type LogType = 'RequestLog' | 'ResponseLog';

/** API-facing shape for the Req/Res Log view modal: integration message log metadata + raw payload. */
export interface IntegrationLogPayloadResponse {
  correlationId: string;
  logType: LogType;
  payload: string | null;
  operation: string | null;
  statusCode: string | null;
  createdAt: string; // ISO 8601 datetime
}

export interface SifAuditTrailResult {
  reference: string;
  transactionType: string;
  customer: string;
  status: string;
  channel: string;
  activities: SifAuditActivityRow[];
}

/**
 * A file from the SIF Summary 360 Raw File tab: its bytes and the name the server saved it under
 * (null when the response carried no usable name).
 */
export interface RawFileDownload {
  blob: Blob;
  fileName: string | null;
}

/**
 * Whether the ACK/NAK Raw File can be downloaded — answered by wps-business from the same stored
 * acknowledgement (wps.CbAcknowledgements in the operational database) the download reads.
 */
export interface SifAckNakFileInfo {
  /** An acknowledgement is recorded for the transaction. */
  recorded: boolean;
  /** The ACK/NAK download would return the Central Bank's file. */
  available: boolean;
  /** The name it downloads under; only when `available` (a name without a stored file is withheld). */
  fileName: string | null;
}

/**
 * The file name in a `Content-Disposition` header — `filename*` (RFC 5987, percent-decoded) when
 * present, else `filename`. Null when there is none. The name is the server's: for the ACK/NAK file it
 * is wps.CbAcknowledgements.RemoteFileName verbatim, so nothing here normalises or re-extends it.
 */
export function fileNameFromContentDisposition(header: unknown): string | null {
  if (typeof header !== 'string') return null;

  const extended = /filename\*\s*=\s*[^']*'[^']*'([^;]+)/i.exec(header);
  if (extended) {
    try {
      const decoded = decodeURIComponent(extended[1].trim());
      if (decoded) return decoded;
    } catch {
      // Malformed percent-encoding: fall through to the plain parameter.
    }
  }

  const quoted = /filename\s*=\s*"((?:[^"\\]|\\.)*)"/i.exec(header);
  if (quoted) return quoted[1].replace(/\\(.)/g, '$1') || null;

  const plain = /filename\s*=\s*([^;]+)/i.exec(header);
  return plain ? plain[1].trim() || null : null;
}

/**
 * GET one Raw File download. The request carries the transaction id and nothing else — no file name,
 * path or tenant parameter (the tenant header is the session's, and the server verifies it). Served
 * by wps-business under /api/wps; the response is the file itself, not JSON.
 */
async function downloadRawFile(transactionId: string, file: 'original-sif' | 'ack-nak'): Promise<RawFileDownload> {
  const response = await bankingApi.get<Blob>(
    `/wps/sif-summary/${encodeURIComponent(transactionId)}/raw-file/${file}`,
    { responseType: 'blob' },
  );
  return {
    blob: response.data,
    fileName: fileNameFromContentDisposition(response.headers?.['content-disposition']),
  };
}

export const sifApi = {
  /**
   * The WPS/SIF status vocabulary (label, tone, optional colour, lifecycle order) for the session's tenant, from
   * platform.RailStatusConfiguration via wps-business `/api/wps/status-catalog`. Display metadata only: an empty array means the
   * server could not read the catalog, and the screens then fall back to their built-in status heuristics. A failed request rejects.
   */
  statusCatalog: () =>
    bankingApi
      .get<WpsStatusCatalogItem[]>('/wps/status-catalog')
      .then((r: { data: WpsStatusCatalogItem[] }) => (Array.isArray(r.data) ? r.data : [])),

  summary: (f: SifSummaryFilters) =>
    bankingApi
      .get<PaginatedResponse<SifSummaryRow>>('/reports/wps/sif-summaryReport', {
        params: {
          fileName: f.fileName || undefined,
          transactionId: f.transactionId?.trim() || undefined,
          corporateName: f.corporateName || undefined,
          accountNumber: f.accountNumber || undefined,
          molEstablishmentId: f.molEstablishmentId || undefined,
          uploadDateFrom: dayStartUtc(f.uploadDateFrom),
          uploadDateTo: dayEndUtcExclusive(f.uploadDateTo),
          totalRecords: f.totalRecords || undefined,
          totalAmount: f.totalAmount || undefined,
          totalAmountFrom: f.totalAmountFrom || undefined,
          totalAmountTo: f.totalAmountTo || undefined,
          uploadedBy: f.uploadedBy || undefined,
          page: f.page ?? 1,
          pageSize: f.pageSize ?? 10,
          sortBy: f.sortBy || undefined,
          sortDir: f.sortDir || undefined,
        },
      })
      .then((r: { data: PaginatedResponse<SifSummaryRow> }) => r.data),

  sifDetailReport: (f: SifDetailReportFilters) =>
    bankingApi
      .get<PaginatedResponse<SifDetailReportRowBackend>>('/reports/wps/sif-detailsReport', {
        params: {
          fileName: f.fileName || undefined,
          sifFileName: f.sifFileName || undefined,
          corporateName: f.corporateName || undefined,
          accountNumber: f.accountNumber || undefined,
          uploadDateFrom: dayStartUtc(f.uploadDateFrom),
          uploadDateTo: dayEndUtcExclusive(f.uploadDateTo),
          totalRecords: f.totalRecords || undefined,
          totalAmount: f.totalAmount || undefined,
          status: f.status || undefined,
          uploadedBy: f.uploadedBy || undefined,
          page: f.page ?? 1,
          pageSize: f.pageSize ?? 10,
          sortBy: f.sortBy || undefined,
          sortDir: f.sortDir || undefined,
        },
      })
      .then((response: { data: PaginatedResponse<SifDetailReportRowBackend> }): PaginatedResponse<SifDetailReportRow> => ({
        ...response.data,
        data: response.data.data.map((row: SifDetailReportRowBackend) => ({
          ...row,
          corporateName: row.corporateName ?? '',
        })),
      })),

  /**
   * @param columns Stable column keys (SifDetailExportColumns.All / mockSifDetailData COLUMNS ids)
   * currently selected+visible in the report's Columns picker, in the picker's current order.
   * Omitted/empty exports every column (matches the paginated GET's full row shape).
   */
  exportSifDetailReport: async (format: SifDetailExportFormat, f: SifDetailReportFilters, columns?: string[]): Promise<Blob> => {
    const response = await bankingApi.get<Blob>(`/reports/wps/sif-detailsReport/export/${format}`, {
      params: {
        fileName: f.fileName || undefined,
        sifFileName: f.sifFileName || undefined,
        corporateName: f.corporateName || undefined,
        accountNumber: f.accountNumber || undefined,
        uploadDateFrom: dayStartUtc(f.uploadDateFrom),
        uploadDateTo: dayEndUtcExclusive(f.uploadDateTo),
        totalRecords: f.totalRecords || undefined,
        totalAmount: f.totalAmount || undefined,
        status: f.status || undefined,
        uploadedBy: f.uploadedBy || undefined,
        sortBy: f.sortBy || undefined,
        sortDir: f.sortDir || undefined,
        columns: columns && columns.length > 0 ? columns.join(',') : undefined,
      },
      responseType: 'blob',
    });

    return response.data;
  },

  /**
   * @param columns Stable column keys (SifSummaryExportColumns.All / SifSummaryReportPage's
   * Column.key) currently selected+visible in the report's Columns picker, in the picker's
   * current order. Omitted/empty exports every column (matches pre-fix behavior).
   */
  exportSifSummaryReport: async (format: SifDetailExportFormat, f: SifSummaryFilters, columns?: string[]): Promise<Blob> => {
    const response = await bankingApi.get<Blob>(`/reports/wps/sif-summaryReport/export/${format}`, {
      params: {
        fileName: f.fileName || undefined,
        transactionId: f.transactionId?.trim() || undefined,
        corporateName: f.corporateName || undefined,
        accountNumber: f.accountNumber || undefined,
        molEstablishmentId: f.molEstablishmentId || undefined,
        uploadDateFrom: dayStartUtc(f.uploadDateFrom),
        uploadDateTo: dayEndUtcExclusive(f.uploadDateTo),
        totalRecords: f.totalRecords || undefined,
        totalAmount: f.totalAmount || undefined,
        totalAmountFrom: f.totalAmountFrom || undefined,
        totalAmountTo: f.totalAmountTo || undefined,
        uploadedBy: f.uploadedBy || undefined,
        sortBy: f.sortBy || undefined,
        sortDir: f.sortDir || undefined,
        columns: columns && columns.length > 0 ? columns.join(',') : undefined,
      },
      responseType: 'blob',
    });

    return response.data;
  },

  detail: (transactionId: string) =>
    bankingApi.get<SifFileDetailResponse>('/reports/wps/sif-detail', { params: { transactionId } }).then((r: { data: SifFileDetailResponse }) => r.data),

  employees: (transactionId: string) =>
    bankingApi
      .get<{ employees: SifEmployeeRecord[]; scr: SifControlRecord | null }>('/reports/wps/sif-employee-records', { params: { transactionId } })
      .then((r: { data: { employees: SifEmployeeRecord[]; scr: SifControlRecord | null } }) => ({
        employees: r.data.employees ?? [],
        scr: r.data.scr ?? null,
      })),

  postingDetails: (transactionId: string) =>
    bankingApi
      .get<{ postingAttempts: PostingAttempt[] }>('/reports/wps/sif-posting-details', { params: { transactionId } })
      .then((r: { data: { postingAttempts: PostingAttempt[] } }) => r.data.postingAttempts ?? []),

  channelInteractions: (transactionId: string) =>
    bankingApi
      .get<{ interactions: ChannelInteraction[] }>('/reports/wps/sif-channel-interactions', { params: { transactionId } })
      .then((r: { data: { interactions: ChannelInteraction[] } }) => r.data.interactions ?? []),

  logPayload: (correlationId: string, logType: LogType, operation?: string) =>
    bankingApi.get<IntegrationLogPayloadResponse>('/reports/wps/sif-log-payload', { params: { correlationId, logType, operation } }).then((r) => r.data),

  /** Raw File tab → Original SIF: the decrypted .SIF as stored in wps-inbound. 404 when it is not there. */
  downloadOriginalSif: (transactionId: string) => downloadRawFile(transactionId, 'original-sif'),

  /** Raw File tab → ACK/NAK: the Central Bank's file (the stored `rawContent`), named by RemoteFileName. */
  downloadAckNak: (transactionId: string) => downloadRawFile(transactionId, 'ack-nak'),

  /** Whether `downloadAckNak` would return a file, decided server-side by the download's own rules. */
  ackNakFileInfo: (transactionId: string) =>
    bankingApi
      .get<SifAckNakFileInfo>(`/wps/sif-summary/${encodeURIComponent(transactionId)}/raw-file/ack-nak/info`)
      .then((r: { data: SifAckNakFileInfo }) => r.data),

  auditTrail: (transactionId: string, filters?: SifAuditTrailFilters) =>
    bankingApi
      .get<SifAuditTrailResult>(`/wps/SIFSummaryAudit-trail/${encodeURIComponent(transactionId)}`, {
        params: {
          actionedFrom: dayStartUtc(filters?.actionedFrom),
          actionedTo: dayEndUtcExclusive(filters?.actionedTo),
        },
      })
      .then((r: { data: SifAuditTrailResult }) => r.data),

  /** Request/response bodies behind one upload audit row (`SifAuditActivityRow.auditLogId`). */
  auditTrailPayload: (transactionId: string, auditLogId: number) =>
    bankingApi
      .get<SifAuditTrailPayload>(`/wps/SIFSummaryAudit-trail/${encodeURIComponent(transactionId)}/payload/${auditLogId}`)
      .then((r: { data: SifAuditTrailPayload }) => r.data),

  exportAuditTrail: async (transactionId: string, format: 'csv' | 'excel' | 'pdf', filters?: SifAuditTrailFilters): Promise<Blob> => {
    const response = await bankingApi.get<Blob>(`/wps/SIFSummaryAudit-trail/${encodeURIComponent(transactionId)}/export/${format}`, {
      responseType: 'blob',
      params: {
        actionedFrom: dayStartUtc(filters?.actionedFrom),
        actionedTo: dayEndUtcExclusive(filters?.actionedTo),
      },
    });
    return response.data;
  },
};
