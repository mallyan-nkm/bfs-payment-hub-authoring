/**
 * The Raw File API client: each method is a GET with `responseType: 'blob'` carrying only the
 * transaction id, and the saved name comes from the response's Content-Disposition.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { fileNameFromContentDisposition, sifApi } from './sifApi';

const http = vi.hoisted(() => ({ get: vi.fn() }));
vi.mock('../../../shared/api/bankingApi', () => ({ bankingApi: http }));

beforeEach(() => {
  vi.clearAllMocks();
});

describe('sifApi.downloadOriginalSif / downloadAckNak', () => {
  it('Original SIF: one GET, blob response, the transaction id only', async () => {
    const blob = new Blob(['SCR,1']);
    http.get.mockResolvedValue({ data: blob, headers: { 'content-disposition': 'attachment; filename=0001234567890260930101500.SIF' } });

    const result = await sifApi.downloadOriginalSif('TXN-1');

    expect(http.get).toHaveBeenCalledTimes(1);
    expect(http.get).toHaveBeenCalledWith('/wps/sif-summary/TXN-1/raw-file/original-sif', { responseType: 'blob' });
    expect(result.blob).toBe(blob);
    expect(result.fileName).toBe('0001234567890260930101500.SIF');
  });

  it('ACK/NAK: one GET, blob response, the transaction id only', async () => {
    const blob = new Blob(['AHR,ACCEPTED']);
    http.get.mockResolvedValue({ data: blob, headers: { 'content-disposition': 'attachment; filename=X_N10000001.SIFNAK' } });

    const result = await sifApi.downloadAckNak('TXN-1');

    expect(http.get).toHaveBeenCalledTimes(1);
    expect(http.get).toHaveBeenCalledWith('/wps/sif-summary/TXN-1/raw-file/ack-nak', { responseType: 'blob' });
    expect(result.fileName).toBe('X_N10000001.SIFNAK');
  });

  it('sends no file name, path, tenant or correlation parameter', async () => {
    http.get.mockResolvedValue({ data: new Blob(['x']), headers: {} });

    await sifApi.downloadOriginalSif('TXN-1');
    await sifApi.downloadAckNak('TXN-1');

    for (const call of http.get.mock.calls) {
      const [url, config] = call as [string, Record<string, unknown>];
      expect(url).not.toMatch(/[?&]/);
      expect(Object.keys(config)).toEqual(['responseType']);
    }
  });

  it('encodes the transaction id into the path', async () => {
    http.get.mockResolvedValue({ data: new Blob(['x']), headers: {} });

    await sifApi.downloadOriginalSif('TXN/../1?x=y');

    expect(http.get.mock.calls[0][0]).toBe('/wps/sif-summary/TXN%2F..%2F1%3Fx%3Dy/raw-file/original-sif');
  });

  it('a response with no Content-Disposition gives a null file name (the caller decides what to do)', async () => {
    http.get.mockResolvedValue({ data: new Blob(['x']), headers: {} });

    expect((await sifApi.downloadOriginalSif('TXN-1')).fileName).toBeNull();
  });

  it('propagates a 404 so the caller can say "File not found"', async () => {
    const error = Object.assign(new Error('404'), { response: { status: 404 } });
    http.get.mockRejectedValue(error);

    await expect(sifApi.downloadOriginalSif('TXN-1')).rejects.toBe(error);
  });
});

describe('fileNameFromContentDisposition', () => {
  it.each([
    ['attachment; filename=X.SIFACK', 'X.SIFACK'],
    ['attachment; filename="X.SIFNAK"', 'X.SIFNAK'],
    ['attachment; filename="with space.SIF"', 'with space.SIF'],
    ["attachment; filename=fallback.SIF; filename*=UTF-8''X%C3%A9.SIF", 'Xé.SIF'],
    ["attachment; filename*=UTF-8''0001234567890260930010011987456378786.ACK", '0001234567890260930010011987456378786.ACK'],
    ['attachment; filename="a\\"b.SIF"', 'a"b.SIF'],
    ['ATTACHMENT; FILENAME=Upper.SIF', 'Upper.SIF'],
  ])('%s -> %s', (header, expected) => {
    expect(fileNameFromContentDisposition(header)).toBe(expected);
  });

  it.each([[undefined], [null], [''], ['attachment'], ['inline'], [42], ['attachment; filename=']])('%j -> null', (header) => {
    expect(fileNameFromContentDisposition(header)).toBeNull();
  });

  it('does not alter or normalise the extension', () => {
    expect(fileNameFromContentDisposition('attachment; filename=THING.SIFACK')).toBe('THING.SIFACK');
    expect(fileNameFromContentDisposition('attachment; filename=THING.sifnak')).toBe('THING.sifnak');
  });
});
