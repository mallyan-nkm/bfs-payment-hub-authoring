import { X } from 'lucide-react';

/** Remarks longer than this are shown as a two-line preview with a "View more" button. */
export const REMARK_PREVIEW_CHARS = 80;

/** True when a remark is too long for the grid cell and should be previewed instead of shown in full. */
export const isLongRemark = (remark?: string | null): boolean => (remark?.trim().length ?? 0) > REMARK_PREVIEW_CHARS;

/**
 * "View more" modal for an Audit Trail remark: the full text of a remark the grid only previews.
 * The text is rendered as-is (wrapped, selectable) — nothing is trimmed or reformatted.
 */
export function SifAuditRemarksModal({
  activity,
  remarks,
  onClose,
}: {
  activity: string;
  remarks: string;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-[10003] flex items-center justify-center bg-black/50"
      role="dialog"
      aria-modal="true"
      aria-label="Remarks"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-lg flex-col overflow-hidden rounded-xl bg-[var(--bg-card)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3 bg-[var(--primary-blue)] px-5 py-3">
          <h3 className="min-w-0 truncate text-sm font-bold text-white">Remarks{activity ? ` — ${activity}` : ''}</h3>
          <button type="button" onClick={onClose} aria-label="Close" className="grid size-7 place-items-center rounded-md text-white hover:bg-white/15">
            <X size={16} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4">
          <p className="whitespace-pre-wrap break-words [overflow-wrap:anywhere] text-xs leading-relaxed text-[var(--text-primary)]">{remarks}</p>
        </div>
      </div>
    </div>
  );
}
