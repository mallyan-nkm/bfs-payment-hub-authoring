import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronDown, ChevronLeft, ChevronRight, Filter, LayoutGrid, Search, X } from 'lucide-react';
import { LoadingSpinner, cn, sessionInstant } from '@paymenthub/ui';
import { sifApi } from './sifApi';
import type { SifAuditActivityRow, SifSummaryRow } from './sifApi';
import { sifStatusHeuristicTone } from './sifStatusTone';
import { CatalogSifStatusBadge } from './SifStatusBadge';
import { SifAuditPayloadModal } from './SifAuditPayloadModal';
import { SifAuditRemarksModal, isLongRemark } from './SifAuditRemarksModal';
import { ReportExportDropdown } from '../../../shared/components/ReportExportDropdown';
import type { ExportFormat } from '../../../shared/components/ReportExportDropdown';

/** Column configuration for the audit trail grid */
interface Column {
  key: keyof SifAuditActivityRow;
  label: string;
  filterKey?: string;
  sortKey?: string;
  visible: boolean;
  /** Renders a From/To calendar-day pair instead of a text filter; filtered server-side. */
  dateRange?: boolean;
}

const DEFAULT_COLUMNS: Column[] = [
  { key: 'activity', label: 'Activity', filterKey: 'activity', sortKey: 'activity', visible: true },
  { key: 'actionBy', label: 'Action By', filterKey: 'actionBy', sortKey: 'actionBy', visible: true },
  { key: 'actionedDateTime', label: 'Actioned Date Time', sortKey: 'actionedDateTime', dateRange: true, visible: true },
  { key: 'channel', label: 'Channel', filterKey: 'channel', sortKey: 'channel', visible: true },
  { key: 'status', label: 'Status', filterKey: 'status', sortKey: 'status', visible: true },
  { key: 'remarks', label: 'Remarks', filterKey: 'remarks', sortKey: 'remarks', visible: true },
  { key: 'moreDetails', label: 'More Details', visible: true },
];

const PAGE_SIZE_OPTIONS = [10, 20, 50];
// v2: actionedDateTime moved from filterKey to dateRange — bumped so a stale v1 layout saved
// before this change doesn't mask the new From/To inputs behind the old single text filter.
const COLS_STORAGE_KEY = 'sif-audit-trail-columns-v2';
// const TH = 'px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wide text-[var(--text-muted)] whitespace-nowrap';
// const TD = 'px-3 py-2.5 text-[var(--text-secondary)] whitespace-nowrap text-xs';
const SECTION = 'input-label text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]';

/** `occurredAtUtc` in the session zone, `dd-MM-yyyy HH:mm:ss` (a thin delegate to the date-time module). */
function formatActionedDateTime(occurredAtUtc?: string | null): string {
  return sessionInstant(occurredAtUtc);
}

const statusTone = sifStatusHeuristicTone;

export function SifAuditTrailDrawer({ row, onClose }: { row: SifSummaryRow; onClose: () => void }) {
  const transactionId = row.transactionId ?? '';

  const [columns, setColumns] = useState<Column[]>(() => {
    try {
      const raw = localStorage.getItem(COLS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Column[];
        if (Array.isArray(parsed) && parsed.every((p) => p && 'key' in p)) return parsed;
      }
    } catch (e) {}
    return DEFAULT_COLUMNS.map((c) => ({ ...c }));
  });
  const [showColumnPanel, setShowColumnPanel] = useState(false);

  const [showFilterRow, setShowFilterRow] = useState(false);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [applied, setApplied] = useState<Record<string, string>>({});

  const [sortBy, setSortBy] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // The upload audit row whose request/response bodies are open in the "View more" modal.
  const [payloadAuditId, setPayloadAuditId] = useState<number | null>(null);

  // The remark open in the "View more" modal (long remarks are only previewed in the grid).
  const [remarksView, setRemarksView] = useState<{ activity: string; remarks: string } | null>(null);

  const colPickerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!showColumnPanel) return;
    const onDown = (e: MouseEvent) => {
      if (colPickerRef.current && !colPickerRef.current.contains(e.target as Node)) setShowColumnPanel(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setShowColumnPanel(false);
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [showColumnPanel]);

  useEffect(() => {
    try {
      if (JSON.stringify(draft) === JSON.stringify(applied)) return;
    } catch (err) {}
    const id = window.setTimeout(() => {
      setPage(1);
      setApplied({ ...draft });
    }, 450);
    return () => window.clearTimeout(id);
  }, [draft, applied]);

  // Actioned Date Time is filtered server-side against the raw OccurredAt column (see sifApi's
  // SifAuditTrailFilters doc) rather than as a generic client-side substring match — the
  // displayed actionedDateTime string is a formatted display value, not something safe to parse.
  const actionedFrom = applied.actionedFrom || undefined;
  const actionedTo = applied.actionedTo || undefined;

  const auditQ = useQuery({
    queryKey: ['sif-audit', transactionId, actionedFrom, actionedTo],
    enabled: !!transactionId,
    queryFn: () => sifApi.auditTrail(transactionId, { actionedFrom, actionedTo }),
  });

  const audit = auditQ.data;

  // Only columns with a real text filterKey participate in the generic substring match below —
  // 'actionedFrom'/'actionedTo' live in the same `applied` map (for the shared debounce) but
  // aren't SifAuditActivityRow fields, so they must be excluded here rather than matched against
  // String(activity['actionedFrom']), which would filter out every row.
  const textFilterKeys = new Set(columns.filter((c) => c.filterKey).map((c) => c.filterKey as string));

  const filteredAndSortedActivities = audit?.activities
    ? (() => {
        let result = [...audit.activities];

        Object.entries(applied).forEach(([key, value]) => {
          if (textFilterKeys.has(key) && value.trim()) {
            result = result.filter((activity) => {
              const fieldValue = String(activity[key as keyof SifAuditActivityRow] ?? '').toLowerCase();
              return fieldValue.includes(value.toLowerCase());
            });
          }
        });

        if (sortBy) {
          result.sort((a, b) => {
            const aVal = String(a[sortBy as keyof SifAuditActivityRow] ?? '');
            const bVal = String(b[sortBy as keyof SifAuditActivityRow] ?? '');
            const comparison = aVal.localeCompare(bVal);
            return sortDir === 'asc' ? comparison : -comparison;
          });
        }

        return result;
      })()
    : [];

  const totalRecords = filteredAndSortedActivities.length;
  const totalPages = Math.max(1, Math.ceil(totalRecords / pageSize));
  const safePage = Math.min(page, totalPages);
  const showingFrom = totalRecords === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const showingTo = Math.min(safePage * pageSize, totalRecords);
  const paginatedActivities = filteredAndSortedActivities.slice((safePage - 1) * pageSize, safePage * pageSize);

  const visibleColumns = columns.filter((c) => c.visible);
  const activeFilterCount = Object.values(applied).filter((v) => v.trim()).length;

  const persistColumns = (cols: Column[]) => {
    try {
      localStorage.setItem(COLS_STORAGE_KEY, JSON.stringify(cols));
    } catch (e) {}
  };

  const handleSaveColumns = () => {
    persistColumns(columns);
    setShowColumnPanel(false);
  };

  const handleResetDefault = () => {
    const defaults = DEFAULT_COLUMNS.map((c) => ({ ...c }));
    setColumns(defaults);
    try {
      localStorage.removeItem(COLS_STORAGE_KEY);
    } catch (e) {}
  };

  const doSearch = () => {
    setPage(1);
    setApplied({ ...draft });
  };

  const clearAll = () => {
    setDraft({});
    setApplied({});
    setSortBy(null);
    setPage(1);
  };

  const sortColumn = (col: Column) => {
    if (!col.sortKey) return;
    if (sortBy === col.sortKey) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else {
      setSortBy(col.sortKey);
      setSortDir('asc');
    }
    setPage(1);
  };

  const sortIndicator = (col: Column) => (sortBy !== col.sortKey ? '↕' : sortDir === 'asc' ? '▲' : '▼');

  const handleExport = async (format: ExportFormat) => {
    // Exports the currently applied range, not the full trail, so a filtered export matches
    // what's on screen.
    return await sifApi.exportAuditTrail(transactionId, format, { actionedFrom, actionedTo });
  };

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label="SIF audit trail"
      onClick={onClose}
    >
      <aside
        className="flex h-full w-full max-w-4xl sm:max-w-5xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div className="min-w-0">
            <h2 className="text-xl font-bold text-[var(--text-primary)]">Audit Trail</h2>
            <p className="mt-1 truncate font-mono text-xs text-[var(--text-muted)]">{row.sifFileName || row.fileName}</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {!transactionId ? (
            <div className="flex h-48 flex-col items-center justify-center gap-2 text-center text-xs text-[var(--text-muted)]">
              <span>This row has no transaction ID, so its audit trail cannot be loaded.</span>
            </div>
          ) : auditQ.isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <LoadingSpinner />
            </div>
          ) : auditQ.isError || !audit ? (
            <p className="py-10 text-center text-xs font-semibold text-[var(--accent-red)]">
              Could not load the audit trail for this submission.
            </p>
          ) : (
            <div className="flex flex-col gap-6">
              {/* Header metadata */}
              <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm">
                <div className="border-b border-[var(--border)] bg-[var(--bg-secondary)]/40 px-5 py-3">
                  <p className={SECTION}>Submission Summary</p>
                </div>
                <div className="p-5">
                  <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
                    <Row label="Reference" value={audit.reference} mono />
                    <Row label="Transaction Type" value={audit.transactionType} />
                    <Row label="Customer" value={audit.customer} />
                    <Row
                      label="Status"
                      value={<CatalogSifStatusBadge status={audit.status} heuristic={statusTone} />}
                    />
                    <Row label="Channel" value={audit.channel} />
                  </dl>
                </div>
              </div>

              {/* Grid Container */}
              <div>
              <div className="overflow-hidden rounded-xl border border-[var(--border)] table-holder">
                {/* Header & Action Toolbar in one line */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px] mb-2">
                     <div className='flex gap-1 items-center'>
                      <h4 >Activities</h4>
                      <span className="text-xs text-[var(--text-muted)]">({totalRecords.toLocaleString()})</span>
                      </div>
                       <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowFilterRow((v) => !v)}
                      className={cn(
                        'btn-tertiary h-38px',
                        showFilterRow
                          ? 'border-[var(--primary-blue)] bg-[var(--primary-blue)] text-[#ffffff]'
                          : '',
                      )}
                    >
                      <Filter size={13} />
                      Filters{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
                    </button>

                    <div className="relative" ref={colPickerRef}>
                      <button
                        onClick={() => setShowColumnPanel((v) => !v)}
                        className="btn-tertiary h-38px !py-1.5 inline-flex items-center gap-1.5"
                        aria-expanded={showColumnPanel}
                      >
                        <LayoutGrid size={13} />
                        Columns
                      </button>

                      {showColumnPanel && (
                        <div className="absolute right-0 top-full z-30 mt-2 w-[270px] rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-3 shadow-2xl">
                          <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                            Show / Hide Columns
                          </div>
                          <div className="flex max-h-[300px] flex-col gap-1 overflow-y-auto pr-1">
                            {columns.map((col) => (
                              <label
                                key={String(col.key)}
                                className="flex cursor-pointer items-center gap-2 rounded px-2 py-1 hover:bg-[var(--bg-card-hover)]"
                              >
                                <input
                                  type="checkbox"
                                  checked={col.visible}
                                  onChange={() =>
                                    setColumns((cs) => cs.map((c) => (c.key === col.key ? { ...c, visible: !c.visible } : c)))
                                  }
                                  className="size-3.5 rounded accent-[var(--primary-blue)]"
                                />
                                <span className="text-xs text-[var(--text-primary)] truncate">{col.label}</span>
                              </label>
                            ))}
                          </div>

                          <div className="mt-3 flex items-center justify-between border-t border-[var(--border)] pt-2.5">
                            <button onClick={handleResetDefault} className="btn-tertiary h-38px !px-2 !py-1 text-[11px]">
                              Reset Default
                            </button>
                            <button onClick={handleSaveColumns} className="btn-primary h-38px !px-3 !py-1 text-xs">
                              Save
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    <button
                      onClick={doSearch}
                      className="btn-primary h-38px !py-1.5 !px-3 text-xs inline-flex items-center gap-1"
                    >
                      <Search size={13} />
                      Search
                    </button>

                    {activeFilterCount > 0 && (
                      <button
                        onClick={clearAll}
                        className="btn-tertiary h-38px !py-1.5 !px-3 text-xs inline-flex items-center gap-1 text-[var(--accent-red)] hover:text-[var(--accent-red)]"
                      >
                        <X size={13} />
                        Clear
                      </button>
                    )}

                    <ReportExportDropdown
                      onExport={handleExport}
                      reportName={`sif-audit-trail-${audit.reference || transactionId}`}
                    />
                  </div>
                    </div>
            

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="w-full min-w-max text-sm">
                    <thead>
                      <tr>
                        {visibleColumns.map((col) => (
                          <th key={String(col.key)} >
                            <span className="flex items-center gap-1.5">
                              <span>{col.label}</span>
                              {col.sortKey && (
                                <button
                                  onClick={() => sortColumn(col)}
                                  aria-label={`Sort by ${col.label}`}
                                  className={cn(
                                    'text-[10px] transition-colors',
                                    sortBy === col.sortKey
                                      ? 'text-[var(--primary-blue)]'
                                      : 'text-[var(--text-muted)] hover:text-[var(--text-secondary)]',
                                  )}
                                >
                                  {sortIndicator(col)}
                                </button>
                              )}
                            </span>
                          </th>
                        ))}
                      </tr>

                      {showFilterRow && (
                        <tr >
                          {visibleColumns.map((col) => (
                            <th key={String(col.key)} >
                              {col.dateRange ? (
                                <div className="flex min-w-[210px] items-center gap-1.5">
                                  <input
                                    type="date"
                                    value={draft.actionedFrom ?? ''}
                                    max={draft.actionedTo || undefined}
                                    onChange={(e) => setDraft((d) => ({ ...d, actionedFrom: e.target.value }))}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') doSearch();
                                    }}
                                    aria-label="Actioned date from"
                                    className="input-cls h-7 flex-1 text-[11px]"
                                  />
                                  <span className="text-[10px] text-[var(--text-muted)]">-</span>
                                  <input
                                    type="date"
                                    value={draft.actionedTo ?? ''}
                                    min={draft.actionedFrom || undefined}
                                    onChange={(e) => setDraft((d) => ({ ...d, actionedTo: e.target.value }))}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') doSearch();
                                    }}
                                    aria-label="Actioned date to"
                                    className="input-cls h-7 flex-1 text-[11px]"
                                  />
                                </div>
                              ) : col.filterKey ? (
                                <input
                                  value={draft[col.filterKey] ?? ''}
                                  onChange={(e) => setDraft((d) => ({ ...d, [col.filterKey as string]: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') doSearch();
                                  }}
                                  placeholder="Filter…"
                                  aria-label={`Filter ${col.label}`}
                                  className="input-cls h-7 w-full min-w-[90px] text-[11px]"
                                />
                              ) : null}
                            </th>
                          ))}
                        </tr>
                      )}
                    </thead>

                    <tbody >
                      {paginatedActivities.length === 0 ? (
                        <tr>
                          <td colSpan={visibleColumns.length} className="px-3 py-10 text-center text-xs text-[var(--text-muted)]">
                            No activities match the current filters.
                          </td>
                        </tr>
                      ) : (
                        paginatedActivities.map((activity, i) => (
                          <tr key={`${activity.activity}-${i}`} >
                            {visibleColumns.map((col) => {
                              const value = activity[col.key];
                              return (
                                <td key={String(col.key)} className={cn(col.key === 'activity' && 'whitespace-nowrap')}>
                                  {col.key === 'status' ? (
                                    <CatalogSifStatusBadge status={String(value)} heuristic={statusTone} />
                                  ) : col.key === 'moreDetails' ? (
                                    <div className="max-w-[240px] whitespace-normal break-words [overflow-wrap:anywhere]">
                                      {value || (activity.auditLogId == null ? '—' : null)}
                                      {activity.auditLogId != null && (
                                        <button
                                          type="button"
                                          onClick={() => setPayloadAuditId(activity.auditLogId ?? null)}
                                          className={cn(
                                            'text-[11px] font-semibold text-[var(--primary-blue)] underline-offset-2 hover:underline',
                                            value && 'ml-2',
                                          )}
                                        >
                                          View more
                                        </button>
                                      )}
                                    </div>
                                  ) : col.key === 'remarks' ? (
                                    isLongRemark(String(value ?? '')) ? (
                                      <div className="max-w-[240px] whitespace-normal break-words [overflow-wrap:anywhere]">
                                        <div
                                          title={String(value)}
                                          style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}
                                        >
                                          {value}
                                        </div>
                                        <button
                                          type="button"
                                          onClick={() => setRemarksView({ activity: activity.activity, remarks: String(value) })}
                                          aria-label="View full remarks"
                                          className="text-[11px] font-semibold text-[var(--primary-blue)] underline-offset-2 hover:underline"
                                        >
                                          View more
                                        </button>
                                      </div>
                                    ) : (
                                      <div className="max-w-[240px] whitespace-normal break-words [overflow-wrap:anywhere]">{value || '—'}</div>
                                    )
                                  ) : col.key === 'actionedDateTime' ? (
                                    formatActionedDateTime(activity.occurredAtUtc)
                                  ) : (
                                    String(value || '—')
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

               
              </div>
                    </div>
                     {/* Standard Pagination Bar */}
                <div className="pq-pagination">
                  <span>
                    Showing <strong>{showingFrom}–{showingTo}</strong> of <strong>{totalRecords.toLocaleString()}</strong> records
                  </span>
                  <div className="pq-pagination-controls">
                    <div className="pq-pagesize">
                      <span>Rows per page:</span>
                      <div className="pq-pagesize-select">
                        <select value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}>
                          {PAGE_SIZE_OPTIONS.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                        <ChevronDown size={13} className="pq-pagesize-caret" />
                      </div>
                    </div>
                    <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={safePage <= 1} className="btn-tertiary">
                      <ChevronLeft size={14} /> Previous
                    </button>
                    <span className="pq-page-badge">{safePage}</span>
                    <button type="button" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={safePage >= totalPages} className="btn-tertiary">
                      Next <ChevronRight size={14} />
                    </button>
                  </div>
                </div>

            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <button onClick={onClose} className="btn-secondary large-btn !w-32 justify-center">
            Close
          </button>
        </div>
      </aside>

      {remarksView && (
        <SifAuditRemarksModal activity={remarksView.activity} remarks={remarksView.remarks} onClose={() => setRemarksView(null)} />
      )}

      {payloadAuditId != null && (
        <SifAuditPayloadModal transactionId={transactionId} auditLogId={payloadAuditId} onClose={() => setPayloadAuditId(null)} />
      )}
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
      <dt className="min-w-[150px] text-[11px] font-semibold text-[var(--text-muted)]">{label}:</dt>
      <dd className={cn('min-w-0 break-all text-xs text-[var(--text-primary)] font-medium', mono && 'font-mono text-[11px]')}>
        {value}
      </dd>
    </div>
  );
}