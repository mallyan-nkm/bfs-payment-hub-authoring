/**
 * Date hand-off between Total Transactions and the WPS SIF reports.
 *
 * Total Transactions resolves its applied Transaction Date filter into concrete local days and
 * sends them as `uploadDateFrom` / `uploadDateTo`; the SIF pages read the same two params. Keeping
 * both ends here means the producer and the consumer cannot disagree on the format.
 *
 * Days are `yyyy-MM-dd` in the session zone (the token's `tz`, UTC date-time design §6.5, T-22),
 * never the browser's zone or UTC; the SIF report API turns them into UTC bounds when it sends them.
 */
import type { DashboardDateFilter } from '../../dashboard/types';
import { sessionToday, sessionZone, shiftDay } from '@paymenthub/ui';

export const UPLOAD_DATE_FROM_PARAM = 'uploadDateFrom';
export const UPLOAD_DATE_TO_PARAM = 'uploadDateTo';

const ISO_DAY = /^(\d{4})-(\d{2})-(\d{2})$/;

/** True for a real calendar day in `yyyy-MM-dd` form (rejects `2026-02-31`, `26-1-1`, `''`). */
export function isIsoDay(value: string | null | undefined): value is string {
  const match = value ? ISO_DAY.exec(value) : null;
  if (!match) return false;
  const [year, month, day] = [Number(match[1]), Number(match[2]), Number(match[3])];
  const d = new Date(year, month - 1, day);
  return d.getFullYear() === year && d.getMonth() === month - 1 && d.getDate() === day;
}

/**
 * The applied Transaction Date filter as the SIF reports' own upload-date params, or `null` when
 * it cannot be expressed that way: a Value Date filter (the SIF reports have no value-date
 * predicate) or a custom range whose bounds are missing, malformed or inverted.
 *
 * `now` and `timeZone` are injectable so the relative ranges can be tested without faking the clock.
 */
export function resolveUploadDateRange(
  filter: DashboardDateFilter,
  now: Date | number = Date.now(),
  timeZone: string = sessionZone(),
): Record<string, string> | null {
  if (filter.dateType !== 'transactionDate') return null;

  let from: string;
  let to: string;
  switch (filter.dateRange) {
    case 'today':
      from = to = sessionToday(now, timeZone);
      break;
    case 'yesterday':
      from = to = shiftDay(sessionToday(now, timeZone), -1);
      break;
    case 'customRange':
      if (!isIsoDay(filter.dateFrom) || !isIsoDay(filter.dateTo) || filter.dateFrom > filter.dateTo) return null;
      from = filter.dateFrom;
      to = filter.dateTo;
      break;
    default:
      return null;
  }
  return { [UPLOAD_DATE_FROM_PARAM]: from, [UPLOAD_DATE_TO_PARAM]: to };
}

/**
 * The upload-date window a SIF page inherited from its URL. Each bound is validated on its own and
 * a malformed one is dropped; if both survive but are inverted, both are dropped, since an empty
 * report from a window nobody chose is worse than an unfiltered one the user can see and narrow.
 */
export function readInheritedUploadDates(params: URLSearchParams): { from?: string; to?: string } {
  const rawFrom = params.get(UPLOAD_DATE_FROM_PARAM);
  const rawTo = params.get(UPLOAD_DATE_TO_PARAM);
  const from = isIsoDay(rawFrom) ? rawFrom : undefined;
  const to = isIsoDay(rawTo) ? rawTo : undefined;
  if (from && to && from > to) return {};
  return { ...(from && { from }), ...(to && { to }) };
}
