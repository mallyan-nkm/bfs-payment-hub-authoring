export type ColumnGroup = 'file' | 'edr' | 'evp' | 'meta';
export type ColumnType = 'text' | 'mono' | 'amount' | 'number' | 'badge' | 'date' | 'maskable';

export type ColumnDef = {
  id: string;
  label: string;
  group: ColumnGroup;
  minWidth?: number;
  type?: ColumnType;
};

export const COLUMNS: ColumnDef[] = [
  // File Information group (15)
  { id: 'fileName', label: 'File Name', group: 'file', type: 'mono', minWidth: 180 },
  { id: 'sifFileName', label: 'SIF File Name', group: 'file', type: 'mono', minWidth: 150 },
  { id: 'employerUniqueId', label: 'Employer Unique ID', group: 'file', type: 'mono', minWidth: 140 },
  { id: 'corporateName', label: 'Corporate Name', group: 'file', type: 'text', minWidth: 160 },
  { id: 'debitAccountNumber', label: 'Debit Account No.', group: 'file', type: 'maskable', minWidth: 160 },
  { id: 'routingCode', label: 'Routing Code', group: 'file', type: 'mono', minWidth: 110 },
  { id: 'salaryMonth', label: 'Salary Month', group: 'file', type: 'text', minWidth: 90 },
  { id: 'salaryYear', label: 'Salary Year', group: 'file', type: 'number', minWidth: 90 },
  { id: 'fileUploadDateTime', label: 'File Upload Date & Time', group: 'file', type: 'date', minWidth: 170 },
  { id: 'channel', label: 'Channel', group: 'file', type: 'text', minWidth: 90 },
  { id: 'ackNakStatus', label: 'ACK/NAK Status', group: 'file', type: 'badge', minWidth: 120 },
  { id: 'ackNakReceivedDateTime', label: 'ACK/NAK Received Date & Time', group: 'file', type: 'date', minWidth: 200 },
  { id: 'totalRecordCount', label: 'Total Record Count (EDR)', group: 'file', type: 'number', minWidth: 150 },
  { id: 'totalSalaryAmount', label: 'Total Salary Amount', group: 'file', type: 'amount', minWidth: 140 },
  { id: 'currentStatus', label: 'Current Status', group: 'file', type: 'badge', minWidth: 120 },

  // EDR group (12)
  { id: 'employeeUniqueId', label: 'Employee Unique ID', group: 'edr', type: 'mono', minWidth: 140 },
  { id: 'creditAccountNumber', label: 'Credit Account No.', group: 'edr', type: 'maskable', minWidth: 160 },
  { id: 'payStartDate', label: 'Pay Start Date', group: 'edr', type: 'date', minWidth: 110 },
  { id: 'payEndDate', label: 'Pay End Date', group: 'edr', type: 'date', minWidth: 110 },
  { id: 'noOfDays', label: 'No of Days', group: 'edr', type: 'number', minWidth: 80 },
  { id: 'fixedAmount', label: 'Fixed Amount', group: 'edr', type: 'amount', minWidth: 110 },
  { id: 'variableAmount', label: 'Variable Amount', group: 'edr', type: 'amount', minWidth: 120 },
  { id: 'leaveDays', label: 'Leave Days', group: 'edr', type: 'number', minWidth: 80 },
  { id: 'mohreUpdateStatus', label: 'MOHRE Update Status', group: 'edr', type: 'text', minWidth: 140 },
  { id: 'accountType', label: 'Account Type', group: 'edr', type: 'badge', minWidth: 130 },
  { id: 'bankName', label: 'Bank name', group: 'edr', type: 'text', minWidth: 120 },
  { id: 'edrStatus', label: 'Status', group: 'edr', type: 'badge', minWidth: 130 },

  // EVP group (7)
  { id: 'housingAllowance', label: 'Housing Allow.', group: 'evp', type: 'amount', minWidth: 110 },
  { id: 'conveyanceAllowance', label: 'Conveyance Allow.', group: 'evp', type: 'amount', minWidth: 130 },
  { id: 'medicalAllowance', label: 'Medical Allow.', group: 'evp', type: 'amount', minWidth: 110 },
  { id: 'annualPassageAllowance', label: 'Annual Passage', group: 'evp', type: 'amount', minWidth: 110 },
  { id: 'overtimeAllowance', label: 'Overtime Allow.', group: 'evp', type: 'amount', minWidth: 110 },
  { id: 'otherAllowances', label: 'Other Allow.', group: 'evp', type: 'amount', minWidth: 90 },
  { id: 'leaveEncashment', label: 'Leave Encashment', group: 'evp', type: 'amount', minWidth: 120 },
];

export type SifRow = {
  // file-level
  fileName: string;
  sifFileName: string;
  employerUniqueId: string;
  corporateName: string;
  debitAccountNumber: { maskedValue: string; actualValue: string | null };
  routingCode: string;
  salaryMonth: string;
  salaryYear: number;
  fileUploadDateTime: string;
  channel: string;
  ackNakStatus: 'ACK' | 'NAK' | 'NONE';
  ackNakReceivedDateTime?: string;
  totalRecordCount: number;
  totalSalaryAmount: number;
  currentStatus: string;

  // edr
  employeeUniqueId: string;
  creditAccountNumber: { maskedValue: string; actualValue: string | null };
  payStartDate: string;
  payEndDate: string;
  noOfDays: number;
  fixedAmount: number;
  variableAmount: number;
  leaveDays: number;
  mohreUpdateStatus: string;
  accountType: 'Own bank account' | 'Other Bank account' | 'card';
  bankName: string;
  edrStatus: 'Processed' | 'Returned (RTC)' | 'Rejected (UAECB/System)';

  // evp
  housingAllowance: number;
  conveyanceAllowance: number;
  medicalAllowance: number;
  annualPassageAllowance: number;
  overtimeAllowance: number;
  otherAllowances: number;
  leaveEncashment: number;
};

export const MOCK_ROWS: SifRow[] = [
  // File 1 — Al Noor Trading LLC (2 employees)
  {
    fileName: 'ORIG_WPS_20260522_001.SIF',
    sifFileName: 'WPS109928838.SIF',
    employerUniqueId: 'EMP-AN-0001',
    corporateName: 'Al Noor Trading LLC',
    debitAccountNumber: { maskedValue: 'AE02••••••••0011', actualValue: 'AE020260000820011' },
    routingCode: '026000082',
    salaryMonth: '05',
    salaryYear: 2026,
    fileUploadDateTime: '22-05-2026 09:12:05',
    channel: 'SFTP',
    ackNakStatus: 'ACK',
    ackNakReceivedDateTime: '22-05-2026 10:00:00',
    totalRecordCount: 2,
    totalSalaryAmount: 12500.5,
    currentStatus: 'ACK Received',

    employeeUniqueId: 'E-AN-1001',
    creditAccountNumber: { maskedValue: 'AE11••••••••1001', actualValue: 'AE1102600008201001' },
    payStartDate: '01-05-2026',
    payEndDate: '31-05-2026',
    noOfDays: 31,
    fixedAmount: 5000,
    variableAmount: 250,
    leaveDays: 0,
    mohreUpdateStatus: 'Updated',
    accountType: 'Own bank account',
    bankName: 'Al Noor Bank',
    edrStatus: 'Processed',

    housingAllowance: 1000,
    conveyanceAllowance: 200,
    medicalAllowance: 150,
    annualPassageAllowance: 0,
    overtimeAllowance: 0,
    otherAllowances: 0,
    leaveEncashment: 0,
  },
  {
    fileName: 'ORIG_WPS_20260522_001.SIF',
    sifFileName: 'WPS109928838.SIF',
    employerUniqueId: 'EMP-AN-0001',
    corporateName: 'Al Noor Trading LLC',
    debitAccountNumber: { maskedValue: 'AE02••••••••0011', actualValue: 'AE020260000820011' },
    routingCode: '026000082',
    salaryMonth: '05',
    salaryYear: 2026,
    fileUploadDateTime: '22-05-2026 09:12:05',
    channel: 'SFTP',
    ackNakStatus: 'ACK',
    ackNakReceivedDateTime: '22-05-2026 10:00:00',
    totalRecordCount: 2,
    totalSalaryAmount: 12500.5,
    currentStatus: 'ACK Received',

    employeeUniqueId: 'E-AN-1002',
    creditAccountNumber: { maskedValue: 'AE11••••••••1002', actualValue: 'AE1102600008201002' },
    payStartDate: '01-05-2026',
    payEndDate: '31-05-2026',
    noOfDays: 31,
    fixedAmount: 7000.5,
    variableAmount: 0,
    leaveDays: 0,
    mohreUpdateStatus: 'Updated',
    accountType: 'Other Bank account',
    bankName: 'Sunrise Bank',
    edrStatus: 'Processed',

    housingAllowance: 1200,
    conveyanceAllowance: 300,
    medicalAllowance: 200,
    annualPassageAllowance: 0,
    overtimeAllowance: 0,
    otherAllowances: 0,
    leaveEncashment: 0,
  },

  // File 2 — Sunrise Tech LLC (2 employees, including a Returned and a Rejected)
  {
    fileName: 'sunrise_upload_20260601.SIF',
    sifFileName: 'WPS109928839.SIF',
    employerUniqueId: 'EMP-ST-0002',
    corporateName: 'Sunrise Tech LLC',
    debitAccountNumber: { maskedValue: 'AE03••••••••2002', actualValue: 'AE0302600008202002' },
    routingCode: '030000200',
    salaryMonth: '06',
    salaryYear: 2026,
    fileUploadDateTime: '01-06-2026 08:00:00',
    channel: 'API',
    ackNakStatus: 'NAK',
    ackNakReceivedDateTime: '01-06-2026 08:20:00',
    totalRecordCount: 2,
    totalSalaryAmount: 9000,
    currentStatus: 'NAK Received',

    employeeUniqueId: 'E-ST-2001',
    creditAccountNumber: { maskedValue: 'AE22••••••••2001', actualValue: 'AE2202600008202001' },
    payStartDate: '01-06-2026',
    payEndDate: '30-06-2026',
    noOfDays: 30,
    fixedAmount: 4000,
    variableAmount: 500,
    leaveDays: 0,
    mohreUpdateStatus: 'Pending',
    accountType: 'card',
    bankName: 'Central Bank Card',
    edrStatus: 'Returned (RTC)',

    housingAllowance: 800,
    conveyanceAllowance: 150,
    medicalAllowance: 100,
    annualPassageAllowance: 0,
    overtimeAllowance: 0,
    otherAllowances: 0,
    leaveEncashment: 0,
  },
  {
    fileName: 'sunrise_upload_20260601.SIF',
    sifFileName: 'WPS109928839.SIF',
    employerUniqueId: 'EMP-ST-0002',
    corporateName: 'Sunrise Tech LLC',
    debitAccountNumber: { maskedValue: 'AE03••••••••2002', actualValue: 'AE0302600008202002' },
    routingCode: '030000200',
    salaryMonth: '06',
    salaryYear: 2026,
    fileUploadDateTime: '01-06-2026 08:00:00',
    channel: 'API',
    ackNakStatus: 'NAK',
    ackNakReceivedDateTime: '01-06-2026 08:20:00',
    totalRecordCount: 2,
    totalSalaryAmount: 9000,
    currentStatus: 'NAK Received',

    employeeUniqueId: 'E-ST-2002',
    creditAccountNumber: { maskedValue: 'AE22••••••••2002', actualValue: 'AE2202600008202002' },
    payStartDate: '01-06-2026',
    payEndDate: '30-06-2026',
    noOfDays: 30,
    fixedAmount: 4500,
    variableAmount: 0,
    leaveDays: 2,
    mohreUpdateStatus: 'Failed',
    accountType: 'Own bank account',
    bankName: 'Sunrise Bank',
    edrStatus: 'Rejected (UAECB/System)',

    housingAllowance: 900,
    conveyanceAllowance: 200,
    medicalAllowance: 150,
    annualPassageAllowance: 0,
    overtimeAllowance: 0,
    otherAllowances: 0,
    leaveEncashment: 0,
  },
];

export const FILE_GROUP_COUNT = 15;
export const EDR_GROUP_COUNT = 12;
export const EVP_GROUP_COUNT = 7;
