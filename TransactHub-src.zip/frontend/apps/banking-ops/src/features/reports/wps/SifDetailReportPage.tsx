import { useState, useMemo, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Can, PageBody, PageShell, SortIcon, cn, useSessionDateTime } from '@paymenthub/ui';
import { CONTROL_PERM } from '../../../shared/auth/permissionKeys';
import { ChevronDown, ChevronLeft, ChevronRight, Filter, LayoutGrid, Search, X } from 'lucide-react';
import { COLUMNS as MASTER_COLUMNS } from './mockSifDetailData';
import { sifApi } from './sifApi';
import type { SifDetailReportRow } from './sifApi';
import MaskedCell from './MaskedCell';
import StatusBadge from './StatusBadge';
import { readInheritedUploadDates } from './sifDrillDown';
import { ReportExportDropdown } from '../../../shared/components/ReportExportDropdown';
import type { ExportFormat } from '../../../shared/components/ReportExportDropdown';
import './SifDetailReport.css';

const COLS_STORAGE_KEY = 'sif-detail-report-cols-v1';

/**
 * The `date` columns that are instants (UTC from the API, stored in StorageTimeZone and converted by the backend):
 * shown in the session zone. The other `date` columns — pay start/end — are calendar dates, never converted (INV-02).
 */
const INSTANT_COLUMNS = new Set(['fileUploadDateTime', 'ackNakReceivedDateTime']);
const PAGE_SIZES = [10, 20, 50];

const SORT_BY_MAP: Record<string, string> = {
  fileName: 'fileName',
  sifFileName: 'sifFileName',
  corporateName: 'corporateName',
  fileUploadDateTime: 'uploadDate',
  totalRecordCount: 'totalRecords',
  totalSalaryAmount: 'totalAmount',
  currentStatus: 'status',
};

const TH_BASE = 'px-3 py-2 text-left align-bottom whitespace-nowrap text-[13px] font-semibold uppercase tracking-wide text-[#4B5563]';
const TD_BASE = 'px-3 py-2 text-[13px] text-[var(--text-primary)] whitespace-nowrap';

export default function SifDetailReportPage() {
  const navigate = useNavigate();
  const { formatInstant, formatCalendarDate } = useSessionDateTime();

  const [columns, setColumns] = useState(() => {
    const defaults = MASTER_COLUMNS.map((c) => ({ ...c, visible: true }));
    try {
      const raw = localStorage.getItem(COLS_STORAGE_KEY);
      if (!raw) return defaults;
      const saved = JSON.parse(raw) as Array<{ id: string; visible: boolean }>;
      const visMap = new Map(saved.map((s) => [s.id, !!s.visible]));

      return defaults.map((c) => ({ ...c, visible: visMap.has(c.id) ? !!visMap.get(c.id) : true }));
    } catch {
      return defaults;
    }
  });
  const [showColumnPanel, setShowColumnPanel] = useState(false);

  // Upload-date window handed over by Total Transactions (`?uploadDateFrom=…&uploadDateTo=…`).
  // Read once, in the state initialisers, so the very first request is already filtered — an
  // effect would let an unfiltered request go out first. BOTH draft and applied are seeded: the
  // debounce effect below copies draft over applied whenever they differ, so seeding applied alone
  // would be reverted to empty ~350 ms later. The keys are this grid's own for the upload column
  // (`<columnId>From` / `<columnId>To`); buildReportParams maps them back to uploadDateFrom/To.
  const [searchParams] = useSearchParams();
  const [inherited] = useState(() => {
    const { from, to } = readInheritedUploadDates(searchParams);
    return {
      ...(from && { fileUploadDateTimeFrom: from }),
      ...(to && { fileUploadDateTimeTo: to }),
    } as Record<string, string>;
  });

  const [draftFilters, setDraftFilters] = useState<Record<string, string>>(() => ({ ...inherited }));
  const [appliedFilters, setAppliedFilters] = useState<Record<string, string>>(() => ({ ...inherited }));
  // Open when a filter was inherited, so the narrowed list is visibly the result of a filter.
  const [showFilterRow, setShowFilterRow] = useState(() => Object.keys(inherited).length > 0);

  const activeFilterCount = Object.values(appliedFilters).filter((v) => v.trim()).length;

  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc' | null>(null);

  const [isUnmasked, setIsUnmasked] = useState(false);
  const mockUser = useMemo(() => ({ hasUnmaskAccess: true }), []);
  const [unmaskPending, setUnmaskPending] = useState(false);
  const [unmaskNotice, setUnmaskNotice] = useState<string | null>(null);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const colPickerRef = useRef<HTMLDivElement | null>(null);

  const [dragSrcId, setDragSrcId] = useState<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);

  useEffect(() => {
    if (!showColumnPanel) return;
    const onDown = (e: MouseEvent) => {
      if (colPickerRef.current && !colPickerRef.current.contains(e.target as Node)) setShowColumnPanel(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setShowColumnPanel(false);
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [showColumnPanel]);

  useEffect(() => {
    try {
      if (JSON.stringify(draftFilters) === JSON.stringify(appliedFilters)) return;
    } catch { }
    const id = window.setTimeout(() => setAppliedFilters({ ...draftFilters }), 350);
    return () => window.clearTimeout(id);
  }, [draftFilters, appliedFilters]);

  const visibleColumns = useMemo(() => columns.filter((c) => c.visible), [columns]);

  const persistColumns = (cols: typeof columns) => {
    try {
      localStorage.setItem(COLS_STORAGE_KEY, JSON.stringify(cols.map((c) => ({ id: c.id, visible: !!c.visible }))));
    } catch { }
  };

  const handleSaveColumns = () => {
    persistColumns(columns);
    setShowColumnPanel(false);
  };

  const handleResetDefault = () => {
    const reset = MASTER_COLUMNS.map((c) => ({ ...c, visible: true }));
    setColumns(reset);
    try {
      localStorage.removeItem(COLS_STORAGE_KEY);
    } catch { }
  };

  const fileGroupCount = useMemo(() => visibleColumns.filter((c) => c.group === 'file').length, [visibleColumns]);
  const edrGroupCount = useMemo(() => visibleColumns.filter((c) => c.group === 'edr').length, [visibleColumns]);
  const evpGroupCount = useMemo(() => visibleColumns.filter((c) => c.group === 'evp').length, [visibleColumns]);

  const onColDragStart = (e: React.DragEvent, colId: string) => {
    e.dataTransfer.setData('text/plain', colId);
    e.dataTransfer.effectAllowed = 'move';
    setDragSrcId(colId);
  };

  const onColDragOver = (e: React.DragEvent, colId: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverId !== colId) setDragOverId(colId);
  };

  const onColDrop = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    const srcId = e.dataTransfer.getData('text/plain') || dragSrcId;
    if (!srcId || srcId === targetId) {
      setDragSrcId(null);
      setDragOverId(null);
      return;
    }
    const srcIndex = columns.findIndex((c) => c.id === srcId);
    const targetIndex = columns.findIndex((c) => c.id === targetId);
    if (srcIndex === -1 || targetIndex === -1) return setDragSrcId(null);

    if (columns[srcIndex].group !== columns[targetIndex].group) {
      setDragSrcId(null);
      setDragOverId(null);
      return;
    }
    const next = [...columns];
    const [moved] = next.splice(srcIndex, 1);
    next.splice(targetIndex, 0, moved);
    setColumns(next);
    persistColumns(next);
    setDragSrcId(null);
    setDragOverId(null);
  };

  const onColDragEnd = () => {
    setDragSrcId(null);
    setDragOverId(null);
  };

  const buildReportParams = () => ({
    fileName: appliedFilters.fileName || null,
    sifFileName: appliedFilters.sifFileName || null,
    employerUniqueId: appliedFilters.employerUniqueId || null,
    corporateName: appliedFilters.corporateName || null,
    debitAccountNumber: appliedFilters.debitAccountNumber || null,
    routingCode: appliedFilters.routingCode || null,
    salaryMonth: appliedFilters.salaryMonth || null,
    salaryYear: appliedFilters.salaryYear || null,
    uploadDateFrom: appliedFilters.fileUploadDateTimeFrom || null,
    uploadDateTo: appliedFilters.fileUploadDateTimeTo || null,
    channel: appliedFilters.channel || null,
    ackNakStatus: appliedFilters.ackNakStatus || null,
    ackNakReceivedDateTimeFrom: appliedFilters.ackNakReceivedDateTimeFrom || null,
    ackNakReceivedDateTimeTo: appliedFilters.ackNakReceivedDateTimeTo || null,
    totalRecordCount: appliedFilters.totalRecordCount || null,
    totalSalaryAmount: appliedFilters.totalSalaryAmount || null,
    currentStatus: appliedFilters.currentStatus || null,
    employeeUniqueId: appliedFilters.employeeUniqueId || null,
    creditAccountNumber: appliedFilters.creditAccountNumber || null,
    payStartDateFrom: appliedFilters.payStartDateFrom || null,
    payStartDateTo: appliedFilters.payStartDateTo || null,
    payEndDateFrom: appliedFilters.payEndDateFrom || null,
    payEndDateTo: appliedFilters.payEndDateTo || null,
    noOfDays: appliedFilters.noOfDays || null,
    fixedAmount: appliedFilters.fixedAmount || null,
    variableAmount: appliedFilters.variableAmount || null,
    leaveDays: appliedFilters.leaveDays || null,
    mohreUpdateStatus: appliedFilters.mohreUpdateStatus || null,
    accountType: appliedFilters.accountType || null,
    bankName: appliedFilters.bankName || null,
    edrStatus: appliedFilters.edrStatus || null,
    housingAllowance: appliedFilters.housingAllowance || null,
    conveyanceAllowance: appliedFilters.conveyanceAllowance || null,
    medicalAllowance: appliedFilters.medicalAllowance || null,
    annualPassageAllowance: appliedFilters.annualPassageAllowance || null,
    overtimeAllowance: appliedFilters.overtimeAllowance || null,
    otherAllowances: appliedFilters.otherAllowances || null,
    leaveEncashment: appliedFilters.leaveEncashment || null,
    sortBy: sortKey ? SORT_BY_MAP[sortKey] ?? null : null,
    sortDir: sortKey && sortDir ? sortDir : null,
  });

  const listQ = useQuery({
    queryKey: ['sif-detail-report', appliedFilters, page, pageSize, sortKey, sortDir],
    queryFn: () =>
      sifApi.sifDetailReport({
        ...buildReportParams(),
        page,
        pageSize,
      }),
    placeholderData: (prev) => prev,
  });

  const toggleSort = (colId: string) => {
    if (sortKey !== colId) {
      setSortKey(colId);
      setSortDir('asc');
      return;
    }
    if (sortDir === 'asc') setSortDir('desc');
    else if (sortDir === 'desc') {
      setSortKey(null);
      setSortDir(null);
    } else setSortDir('asc');
  };

  const clearAll = () => {
    setDraftFilters({});
    setAppliedFilters({});
    setSortKey(null);
    setSortDir(null);
    setPage(1);
  };

  const handleSearch = () => {
    setPage(1);
    setAppliedFilters({ ...draftFilters });
  };

  const pageRows = listQ.data?.data ?? [];
  const totalRecords = listQ.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalRecords / pageSize));

  useEffect(() => {
    if (page > totalPages) setPage(1);
  }, [page, totalPages]);

  const pageStart = totalRecords === 0 ? 0 : (page - 1) * pageSize + 1;
  const pageEnd = Math.min(totalRecords, page * pageSize);

  const handleExport = async (format: ExportFormat) => {
    // Source of truth for what gets exported is `visibleColumns` — the same derived list the grid
    // itself renders — read fresh on every export click. Every entry here is a real data column
    // (there is no UI-only column in this report); 'Sl No' is handled unconditionally by the
    // backend (always exported first, matching its locked/non-toggleable first column in the grid).
    const exportColumnKeys = visibleColumns.map((c) => c.id);
    return await sifApi.exportSifDetailReport(format, buildReportParams(), exportColumnKeys);
  };

  const applyUnmask = () => {
    if (!mockUser.hasUnmaskAccess) return alert('You do not have permission to unmask PII');
    setUnmaskPending(true);
    setUnmaskNotice(null);
    setTimeout(() => {
      setUnmaskPending(false);
      setIsUnmasked(true);
      setUnmaskNotice('Unmasked successfully');
      setTimeout(() => setUnmaskNotice(null), 3000);
    }, 700);
  };

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4">
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / Reports / WPS / '}
              <span className="text-[var(--text-secondary)]">SIF Detail Report</span>
            </p>
          </div>

          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                SIF Detail Report
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Comprehensive file-level, employee detail (EDR), and variable pay (EVP) records
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* The CSV/Excel/PDF routes behind this enforce catalog index 11 server-side — the same
                  export key the SIF Summary report uses. Ungated in the UI until 01-10-2026. */}
              <Can permission={CONTROL_PERM.sifSummaryExport} mode="disable">
                <ReportExportDropdown onExport={handleExport} reportName="sif-detail-report" />
              </Can>
            </div>
          </div>
          <div>
            <div className="overflow-hidden rounded-xl border border-[var(--border)] table-holder">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px]">
                <div className="flex items-center gap-2">
                  <h4 >SIF Detail Report</h4>
                  <span className="text-xs text-[var(--text-muted)]">  ({totalRecords.toLocaleString()} {totalRecords === 1 ? 'record' : 'records'})</span>
                </div>

                <div className="flex items-center gap-2">
                  {mockUser.hasUnmaskAccess && (
                    <label className="pq-pii-toggle">
                      <input type="checkbox"
                        checked={isUnmasked}
                        onChange={(e) => setIsUnmasked(e.target.checked)}
                        disabled={unmaskPending} />
                      Unmask PII
                      <button
                        type="button"
                        onClick={applyUnmask}
                        disabled={unmaskPending}
                        className="btn-tertiary !py-1 !px-2.5 text-[11px]"
                      >
                        Apply
                      </button>
                      {unmaskPending && <span className="text-xs text-[var(--text-muted)]">Applying…</span>}
                      {unmaskNotice && <span className="text-xs font-semibold text-green-600">{unmaskNotice}</span>}
                    </label>
                  )}

                  <button
                    type="button"
                    onClick={() => setShowFilterRow((v) => !v)}
                    className={cn(
                      'btn-tertiary h-38px',
                      showFilterRow
                        ? 'border-[var(--primary-blue)] bg-[var(--primary-blue)] text-[#ffffff]'
                        : '',
                    )}
                  >
                    <Filter size={13} />
                    Filters{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
                  </button>
                  <div className="relative" ref={colPickerRef}>
                    <button
                      type="button"
                      onClick={() => setShowColumnPanel((v) => !v)}
                      className="btn-tertiary h-38px"
                      aria-expanded={showColumnPanel}
                    >
                      <LayoutGrid size={13} />
                      Columns
                    </button>

                    {showColumnPanel && (
                      <div className="absolute right-0 top-full z-30 mt-2 w-[340px] max-h-[70vh] rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-2xl flex flex-col p-3">
                        <div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                          Show / Hide Columns
                        </div>

                        <div className="flex-1 overflow-y-auto pr-1" style={{ maxHeight: 'calc(70vh - 120px)' }}>
                          {['file', 'edr', 'evp'].map((grp) => (
                            <div key={grp} className="mb-3">
                              <div className="sticky top-0 bg-[var(--bg-card)] z-10 py-1 text-[10px] font-bold uppercase tracking-wider text-[var(--primary-blue)] border-b border-[var(--border)]">
                                {grp === 'file' ? 'File Information' : grp === 'edr' ? 'EDR Details' : 'EVP Details'}
                              </div>
                              <div className="flex flex-col gap-1 py-1">
                                {columns
                                  .filter((c) => c.group === grp)
                                  .map((col) => (
                                    <label
                                      key={col.id}
                                      className="flex cursor-pointer items-center gap-2 rounded px-2 py-1 hover:bg-[var(--bg-card-hover)]"
                                    >
                                      <input
                                        type="checkbox"
                                        checked={!!col.visible}
                                        onChange={() =>
                                          setColumns((cs) => cs.map((cc) => (cc.id === col.id ? { ...cc, visible: !cc.visible } : cc)))
                                        }
                                        className="size-3.5 rounded accent-[var(--primary-blue)]"
                                      />
                                      <span className="text-xs text-[var(--text-primary)] truncate">{col.label}</span>
                                    </label>
                                  ))}
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="mt-3 flex items-center justify-between border-t border-[var(--border)] pt-2.5">
                          <button
                            type="button"
                            onClick={handleResetDefault}
                            className="btn-tertiary !px-2 !py-1 text-[11px]"
                          >
                            Reset Default
                          </button>
                          <button
                            type="button"
                            onClick={handleSaveColumns}
                            className="btn-primary !px-3 !py-1 text-xs"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleSearch}
                    className="btn-primary h-38px !py-1.5 !px-3 text-xs inline-flex items-center gap-1"
                  >
                    <Search size={13} />
                    Search
                  </button>

                  {activeFilterCount > 0 && (
                    <button
                      type="button"
                      onClick={clearAll}
                      className="btn-tertiary h-38px !py-1.5 !px-3 text-xs inline-flex items-center gap-1 text-[var(--accent-red)] hover:text-[var(--accent-red)]"
                    >
                      <X size={13} />
                      Clear
                    </button>
                  )}
                </div>
              </div>


              <div className="overflow-x-auto ">
                <table >
                  <thead>
                    {/* High-contrast grouped headers */}
                    <tr >
                      <th rowSpan={2} className={cn(TH_BASE, 'border-r border-[var(--border)] text-[#374151] font-bold')}>
                        Sl No
                      </th>
                      {fileGroupCount > 0 && (
                        <th
                          colSpan={fileGroupCount}
                          className="border-b border-r border-[#cbd5e1] px-3 py-2.5 text-center text-[12px] font-bold uppercase tracking-wider text-[#1e293b]"
                        >
                          File Information
                        </th>
                      )}
                      {edrGroupCount > 0 && (
                        <th
                          colSpan={edrGroupCount}
                          className="spl-th-1"
                        >
                          EDR — Employee Detail Record
                        </th>
                      )}
                      {evpGroupCount > 0 && (
                        <th
                          colSpan={evpGroupCount}
                          className="spl-th-2"
                        >
                          EVP — Employee Variable Pay
                        </th>
                      )}
                    </tr>

                    {/* Matching background colors carried down to individual column headers */}
                    <tr >
                      {visibleColumns.map((c) => {
                        const colHeaderStyle =
                          c.group === 'edr'
                            ? 'sub-th-1'
                            : c.group === 'evp'
                              ? 'sub-th-2'
                              : ' text-[#334155] border-[#cbd5e1]';

                        return (
                          <th
                            key={c.id}
                            draggable={true}
                            onDragStart={(e) => onColDragStart(e, c.id)}
                            onDragOver={(e) => onColDragOver(e, c.id)}
                            onDrop={(e) => onColDrop(e, c.id)}
                            onDragEnd={onColDragEnd}
                            style={{ minWidth: c.minWidth ? `${c.minWidth}px` : undefined }}
                            className={cn(
                              TH_BASE,
                              colHeaderStyle,
                              'cursor-grab active:cursor-grabbing border-r last:border-r-0',
                              dragSrcId === c.id ? 'opacity-40' : '',
                              dragOverId === c.id ? 'brightness-95' : '',
                            )}
                          >
                            <div className="flex items-center justify-between gap-1.5">
                              <span className="font-bold">{c.label}</span>
                              <button
                                type="button"
                                onClick={() => toggleSort(c.id)}
                                aria-label={`Sort by ${c.label}`}
                                className="inline-flex items-center"
                              >
                                <SortIcon direction={sortKey === c.id ? sortDir : null} />
                              </button>
                            </div>
                          </th>
                        );
                      })}
                    </tr>

                    {/* Filter row retaining matching section tint */}
                    {showFilterRow && (
                      <tr >
                        <th >
                          —
                        </th>
                        {visibleColumns.map((c) => {
                          const isDateColumn = c.type === 'date';
                          const filterBgStyle =
                            c.group === 'edr'
                              ? ''
                              : c.group === 'evp'
                                ? ''
                                : '';

                          return (
                            <th key={c.id} className={cn('px-3 py-1.5 border-r last:border-r-0 font-normal', filterBgStyle)}>
                              {isDateColumn ? (
                                <div className="flex min-w-[210px] items-center gap-1.5">
                                  <input
                                    type="date"
                                    value={draftFilters[`${c.id}From`] ?? ''}
                                    max={draftFilters[`${c.id}To`] || undefined}
                                    onChange={(e) => setDraftFilters((d) => ({ ...d, [`${c.id}From`]: e.target.value }))}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                                    aria-label={`${c.label} from`}
                                    className="input-cls small-input h-7 flex-1 text-[11px] bg-white"
                                  />
                                  <span className="text-[10px] text-[var(--text-muted)]">-</span>
                                  <input
                                    type="date"
                                    value={draftFilters[`${c.id}To`] ?? ''}
                                    min={draftFilters[`${c.id}From`] || undefined}
                                    onChange={(e) => setDraftFilters((d) => ({ ...d, [`${c.id}To`]: e.target.value }))}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                                    aria-label={`${c.label} to`}
                                    className="input-cls small-input h-7 flex-1 text-[11px] bg-white"
                                  />
                                </div>
                              ) : (
                                <input
                                  value={draftFilters[c.id] ?? ''}
                                  onChange={(e) => setDraftFilters((d) => ({ ...d, [c.id]: e.target.value }))}
                                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                                  placeholder="Filter…"
                                  aria-label={`Filter ${c.label}`}
                                  className="input-cls small-input h-7 w-full min-w-[100px] text-[11px] bg-white"
                                />
                              )}
                            </th>
                          );
                        })}
                      </tr>
                    )}
                  </thead>

                  <tbody className="divide-y divide-[var(--border-light)]">
                    {listQ.isLoading ? (
                      <tr>
                        <td colSpan={visibleColumns.length + 1} className="px-3 py-10 text-center text-xs text-[var(--text-muted)]">
                          Loading SIF detail data…
                        </td>
                      </tr>
                    ) : listQ.isError ? (
                      <tr>
                        <td colSpan={visibleColumns.length + 1} className="px-3 py-10 text-center text-xs font-semibold text-[var(--accent-red)]">
                          Failed to load SIF detail report data.
                        </td>
                      </tr>
                    ) : pageRows.length === 0 ? (
                      <tr>
                        <td colSpan={visibleColumns.length + 1} className="px-3 py-10 text-center text-xs text-[var(--text-muted)]">
                          No records match the current filters.
                        </td>
                      </tr>
                    ) : (
                      pageRows.map((r: SifDetailReportRow, idx: number) => (
                        <tr key={`${r.employeeUniqueId}-${idx}`} >
                          <td className={cn(TD_BASE, 'border-r border-[var(--border-light)] font-mono text-center text-xs tabular-nums text-[var(--text-muted)] bg-[var(--bg-secondary)]/40')}>
                            {(page - 1) * pageSize + idx + 1}
                          </td>
                          {visibleColumns.map((c) => {
                            const v: any = (r as any)[c.id];
                            let renderedCell: React.ReactNode = null;

                            const cellStyle =
                              c.group === 'edr'
                                ? ''
                                : c.group === 'evp'
                                  ? ''
                                  : '';

                            if (c.type === 'maskable') {
                              renderedCell = <MaskedCell value={v} isUnmasked={isUnmasked} className="font-mono text-xs" />;
                            } else if (c.type === 'mono') {
                              renderedCell = <span className="font-mono text-xs">{v || '—'}</span>;
                            } else if (c.type === 'amount') {
                              renderedCell = (
                                <div className="tabular-nums font-semibold text-right">
                                  {typeof v === 'number' ? `AED ${v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : v || '—'}
                                </div>
                              );
                            } else if (c.type === 'date') {
                              renderedCell = INSTANT_COLUMNS.has(c.id) ? formatInstant(v) : formatCalendarDate(v);
                            } else if (c.type === 'badge') {
                              const kind = c.id === 'ackNakStatus' ? 'ackNak' : c.id === 'currentStatus' ? 'fileStatus' : c.id === 'edrStatus' ? 'edrStatus' : c.id === 'accountType' ? 'accountType' : 'generic';
                              renderedCell = <StatusBadge kind={kind as any} value={v} />;
                            } else {
                              renderedCell = v || '—';
                            }

                            return (
                              <td key={c.id} className={cn(TD_BASE, cellStyle, 'border-r last:border-r-0')}>
                                {renderedCell}
                              </td>
                            );
                          })}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            {/* Standard Pagination Bar */}
            <div className="pq-pagination">
              <span>
                Showing <strong>{totalRecords === 0 ? 0 : pageStart}–{pageEnd}</strong> of{' '}
                <strong>{totalRecords.toLocaleString()}</strong> records
              </span>
              <div className="pq-pagination-controls">
                <div className="pq-pagesize">
                  <span>Rows per page:</span>
                  <div className="pq-pagesize-select">
                    <select
                      value={pageSize}
                      onChange={(e) => {
                        setPageSize(Number(e.target.value));
                        setPage(1);
                      }}
                    >
                      {PAGE_SIZES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <ChevronDown size={13} className="pq-pagesize-caret" />
                  </div>
                </div>
                <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1} className="btn-tertiary">
                  <ChevronLeft size={14} /> Previous
                </button>
                <span className="pq-page-badge">{page}</span>
                <button type="button" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="btn-tertiary">
                  Next <ChevronRight size={14} />
                </button>
              </div>
            </div>

          </div>
        </div>
      </PageBody>
    </PageShell>
  );
}