import { Fragment, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import { X, Download, AlertCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { LoadingSpinner, SmartGrid, cn, sessionInstant } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { downloadBlob } from '../../../shared/utils/downloadBlob';
import { sifApi } from './sifApi';
import { sifStatusHeuristicTone } from './sifStatusTone';
import { CatalogSifStatusBadge } from './SifStatusBadge';
import type { SifAckNakFileInfo, SifFileDetailResponse, SifEmployeeRecord, SifSummaryRow, PostingAttempt, PostingLeg, ChannelInteraction, LogType } from './sifApi';

type Tab = 'file' | 'integration' | 'records';
type IntegrationTab = 'core' | 'channel';

const money = (n: number | null | undefined) =>
  n == null ? '—' : `AED ${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const dash = (v: string | number | null | undefined) => (v === null || v === undefined || v === '' ? '—' : String(v));

/** An instant in the session zone, `dd-MM-yyyy HH:mm:ss`; a zoneless value is UTC (a thin delegate). */
const formatDateTime = (s: string | null | undefined): string => sessionInstant(s);

/**
 * Distinct per-leg Type Codes of one posting attempt, in first-seen (leg) order, e.g. "Salary, BankCharge, VatAmount"
 * (the API already returns the report display codes).
 * Type Code is stored per leg, so a salary attempt can legitimately carry several; no single one is picked.
 */
const distinctTxnTypeCodes = (legs: PostingLeg[]): string => {
  const codes = [...new Set(legs.map((l) => l.txnTypeCode).filter((c): c is string => !!c))];
  return codes.length > 0 ? codes.join(', ') : '—';
};

interface MsgField {
  label: string;
  value: string;
  mono?: boolean;
  badge?: 'green' | 'red';
}
interface MsgContext {
  label: string;
  value: string;
  mono?: boolean;
}
interface MsgSection {
  title: string;
  tone: 'success' | 'error';
  processedFileName: string;
  numberOfRecords: string;
  status: string;
}
/** The two independent Raw File downloads; each maps to exactly one API call. */
type RawFileKind = 'ack-nak' | 'original-sif';

interface MsgRawFile {
  /** Label shown on the card; a dash when unknown. Never used as the name a file is saved under. */
  fileName: string;
  description: string;
  kind: RawFileKind;
  /** False when there is nothing to download (no stored ACK/NAK file): the button is disabled. */
  available: boolean;
  /** Why an unavailable file is unavailable, when that is known and is not simply "no response yet". */
  note?: string;
}
interface MsgError {
  lineNo: string;
  errorCode: string;
  employeeRefId: string;
  description: string;
}
interface RelatedMessageDetail {
  receivedDateTime: string;
  processedDateTime: string;
  fields: MsgField[];
  context: MsgContext[];
  sections: MsgSection[];
  rawFiles: MsgRawFile[];
  errors: MsgError[];
}
interface RelatedMessage {
  id: string;
  label: string;
  receivedText: string;
  statusText?: string;
  statusClass?: 'green' | 'red';
  pending?: boolean;
  /** The pane's text while there is no `detail`. */
  pendingText?: string;
  detail?: RelatedMessageDetail;
  /**
   * The Raw File entries to offer when there is no `detail` (the CB has not answered yet): the original
   * SIF is downloadable from submission time, so it must not wait for an ACK/NAK. Absent once `detail`
   * exists — then the entries live in `detail.rawFiles`.
   */
  rawFiles?: MsgRawFile[];
}

type SifAckKind = 'ACK' | 'NAK';

/**
 * Classifies the Central Bank's answer to the SIF file from `cbResponse`, which the API sources from
 * wps.CbAcknowledgements.AckType — stored as "SIFACK" / "SIFNAK" (WpsTransactionCodes), with plain
 * "ACK" / "NAK" / "NACK" tolerated. Returns null when there is no response yet (or an unrecognised one),
 * so the caller falls back to the pending state instead of guessing ACK.
 */
export function sifAckKind(cbResponse: string | null | undefined): SifAckKind | null {
  const v = (cbResponse ?? '').trim().toUpperCase().replace(/^SIF/, '');
  if (v === 'ACK') return 'ACK';
  if (v === 'NAK' || v === 'NACK') return 'NAK';
  return null;
}

const NO_FILE_NAME = '—';

/** No acknowledgement at all. Deliberately not "pending": a file that failed validation will never get one. */
const NOT_RECEIVED_TEXT = 'No ACK/NAK has been received from the Central Bank for this file.';
/** Recorded server-side, but the report data that fills this pane has not caught up yet. */
const RECORDED_NOT_PROCESSED_TEXT = 'A Central Bank response is recorded and is still being processed.';
const ACK_NAK_NOT_STORED_NOTE = 'No file was stored for this Central Bank response.';
const ACK_NAK_UNCHECKED_NOTE = 'Availability could not be checked. Please try again later.';

/**
 * What wps-business says about the ACK/NAK download (sifApi.ackNakFileInfo): undefined while it is being
 * asked, 'error' when it could not be asked. It is the only source of ACK/NAK download availability — the
 * report data (`cbFileName` / `cbResponse`) says a response was recorded, not that its file was stored.
 */
export type AckNakFileState = SifAckNakFileInfo | 'error' | undefined;

/** The ACK/NAK file name to show and download under: only when the file is actually downloadable. */
export function availableAckNakFileName(ackFile: AckNakFileState): string | null {
  if (typeof ackFile !== 'object' || !ackFile.available) return null;
  const name = ackFile.fileName?.trim();
  return name ? ackFile.fileName : null;
}

/**
 * File Summary -> Error tab's Employee Reference ID column. Hidden for the demo (2026-10-24): a NAK's DER records name
 * the SIF line, not the employee, so the column only ever showed a dash. Set to true to bring it back.
 */
const SHOW_EMPLOYEE_REF_COLUMN = false;

/**
 * The two Raw File entries. They are independent: the ACK/NAK file is offered only when wps-business says
 * the Central Bank's file is stored (`ackFile`; its name is wps.CbAcknowledgements.RemoteFileName, shown
 * verbatim and never falling back to the SIF name) — a recorded response without a stored file, e.g. one
 * relayed by hand whose name was synthesised, shows no name and a disabled button. The original SIF
 * (`fileName` = wps.Transactions.OriginalFileName) is always offered — the server looks the file up by
 * transaction, so a label that is still a dash does not make it unavailable.
 */
function buildRawFiles(detail: SifFileDetailResponse | undefined, row: SifSummaryRow, ackFile: AckNakFileState): MsgRawFile[] {
  const ackNakFileName = availableAckNakFileName(ackFile);
  const originalSifFileName = detail?.fileName || row.sifFileName || NO_FILE_NAME;
  const ackNakNote =
    ackFile === 'error'
      ? ACK_NAK_UNCHECKED_NOTE
      : ackFile?.recorded && !ackNakFileName
        ? ACK_NAK_NOT_STORED_NOTE
        : undefined;
  return [
    {
      kind: 'ack-nak',
      fileName: ackNakFileName ?? NO_FILE_NAME,
      description: 'CB acknowledgement file',
      available: ackNakFileName !== null,
      note: ackNakNote,
    },
    { kind: 'original-sif', fileName: originalSifFileName, description: 'Original SIF file', available: true },
  ];
}

/** The File Summary tab only surfaces the SIF ACK/NAK exchange; the other CB message types are not shown. */
export function buildRelatedMessages(
  detail: SifFileDetailResponse | undefined,
  row: SifSummaryRow,
  ackFile: AckNakFileState = undefined,
): RelatedMessage[] {
  const recordedAhead = typeof ackFile === 'object' && ackFile.recorded;
  const pending: RelatedMessage = {
    id: 'sif-ack',
    label: 'SIF ACK/NAK',
    receivedText: recordedAhead ? 'Processing' : 'Not received',
    pending: true,
    pendingText: recordedAhead ? RECORDED_NOT_PROCESSED_TEXT : NOT_RECEIVED_TEXT,
    // The original SIF does not depend on the CB's answer, so it is offered even while there is no
    // response; the ACK/NAK entry is shown but disabled until its file is stored.
    rawFiles: buildRawFiles(detail, row, ackFile),
  };
  const kind = sifAckKind(detail?.cbResponse);
  if (!detail || !kind) return [pending];

  const ackDate = formatDateTime(detail.initiatedDateTime);
  // Two different files: the original SIF (wps.Transactions.OriginalFileName, `fileName`) and the Central Bank's
  // ACK/NAK response (wps.CbAcknowledgements.RemoteFileName, `cbFileName`). The response name never falls back to
  // the SIF name and is shown verbatim (legacy .SIFACK/.SIFNAK included).
  const originalSifFileName = detail.fileName || row.sifFileName || '—';
  const accepted = detail.systemAccepted ?? 0;
  const rejected = detail.systemRejected ?? 0;
  const totalAmount = detail.totalSalaryAmount ?? row.totalAmount ?? 0;

  const section: MsgSection =
    kind === 'ACK'
      ? { title: 'ACK — File Accepted', tone: 'success', processedFileName: originalSifFileName, numberOfRecords: String(accepted), status: 'ACCEPTED' }
      : { title: 'NAK — File Rejected', tone: 'error', processedFileName: rejected > 0 ? originalSifFileName : '-', numberOfRecords: String(rejected), status: '-' };

  return [{
    id: 'sif-ack',
    label: 'SIF ACK/NAK',
    receivedText: `↓ From CB · ${ackDate}`,
    statusText: (detail.cbResponse ?? '').trim().toUpperCase(),
    statusClass: kind === 'NAK' ? 'red' : 'green',
    pending: false,
    detail: {
      receivedDateTime: ackDate,
      processedDateTime: ackDate,
      fields: [
        { label: 'File Name', value: originalSifFileName, mono: true },
        { label: 'Direction', value: '↓ Received from CB', badge: 'green' },
        { label: 'Initiated By', value: detail.initiatedBy || '—' },
        { label: 'Approved By', value: '—' },
        { label: 'Initiated DateTime', value: ackDate, mono: true },
        { label: 'Approved DateTime', value: '—' },
        { label: 'Total Records', value: String(detail.totalRecords ?? 0) },
        { label: 'Total Amount', value: money(totalAmount), mono: true },
      ],
      context: [
        { label: 'File Name', value: originalSifFileName, mono: true },
        { label: 'MOL ID', value: row.molEstablishmentId || '—' },
        { label: 'Corporate Name', value: detail.corporate || row.corporateName || '—' },
      ],
      sections: [section],
      rawFiles: buildRawFiles(detail, row, ackFile),
      // The DER records of a NAK. A DER names the SIF line, not the employee, so the reference column stays a dash.
      errors: (detail.nakErrors ?? []).map((e) => ({
        lineNo: e.lineNumber > 0 ? String(e.lineNumber) : '—',
        errorCode: e.errorCode || '—',
        employeeRefId: '—',
        description: e.description || '—',
      })),
    },
  }];
}

/**
 * "082026" (MMYYYY, as wps.Sif_Scr actually stores it) -> " | Salary Month: 08/2026". Not derived
 * from any employee row's pay dates — those can legitimately differ from the file's own declared
 * salary period, which is the whole point of the SCR being a control record.
 */
function scrSalaryMonthLabel(salaryMonth: string): string {
  if (!/^\d{6}$/.test(salaryMonth)) return '';
  return ` | Salary Month: ${salaryMonth.slice(0, 2)}/${salaryMonth.slice(2)}`;
}

/** Employee record + a row id derived from index, since `employeeUniqueId` alone isn't guaranteed unique
 * across rows (e.g. the same employee across pay periods) — matches the old table's `${id}-${i}` key. */
interface EmployeeRecordRow extends SifEmployeeRecord {
  rowId: string;
}

const money0 = (n: number) => n.toLocaleString();

const EMPLOYEE_RECORD_COLUMNS: SmartGridColumn<EmployeeRecordRow>[] = [
  {
    key: 'employeeUniqueId',
    label: 'Employee ID',
    filterKey: 'employeeUniqueId',
    sortKey: 'employeeUniqueId',
    render: (r) => <span className="font-mono font-medium text-[var(--text-primary)]">{r.employeeUniqueId}</span>,
  },
  {
    key: 'creditAccountNumber',
    label: 'Credit Account',
    filterKey: 'creditAccountNumber',
    sortKey: 'creditAccountNumber',
    render: (r) => <span className="font-mono">{r.creditAccountNumber}</span>,
  },
  { key: 'routingCode', label: 'Routing Code', filterKey: 'routingCode', sortKey: 'routingCode' },
  { key: 'payStartDate', label: 'Pay Start', sortKey: 'payStartDate' },
  { key: 'payEndDate', label: 'Pay End', sortKey: 'payEndDate' },
  { key: 'numberOfDays', label: 'Days', numeric: true, sortKey: 'numberOfDays', getSortValue: (r) => r.numberOfDays },
  { key: 'fixedAmount', label: 'Fixed', numeric: true, sortKey: 'fixedAmount', getSortValue: (r) => r.fixedAmount, render: (r) => money0(r.fixedAmount) },
  { key: 'variableAmount', label: 'Variable', numeric: true, sortKey: 'variableAmount', getSortValue: (r) => r.variableAmount, render: (r) => money0(r.variableAmount) },
  { key: 'leaveDays', label: 'Leave Days', numeric: true, sortKey: 'leaveDays', getSortValue: (r) => r.leaveDays },
  { key: 'housingAllowance', label: 'Housing', numeric: true, sortKey: 'housingAllowance', getSortValue: (r) => r.housingAllowance, render: (r) => money0(r.housingAllowance) },
  { key: 'conveyanceAllowance', label: 'Conveyance', numeric: true, sortKey: 'conveyanceAllowance', getSortValue: (r) => r.conveyanceAllowance, render: (r) => money0(r.conveyanceAllowance) },
  { key: 'medicalAllowance', label: 'Medical', numeric: true, sortKey: 'medicalAllowance', getSortValue: (r) => r.medicalAllowance, render: (r) => money0(r.medicalAllowance) },
  { key: 'annualPassageAllowance', label: 'Passage', numeric: true, sortKey: 'annualPassageAllowance', getSortValue: (r) => r.annualPassageAllowance, render: (r) => money0(r.annualPassageAllowance) },
  { key: 'overtimeAllowance', label: 'Overtime', numeric: true, sortKey: 'overtimeAllowance', getSortValue: (r) => r.overtimeAllowance, render: (r) => money0(r.overtimeAllowance) },
  { key: 'otherAllowance', label: 'Other', numeric: true, sortKey: 'otherAllowance', getSortValue: (r) => r.otherAllowance, render: (r) => money0(r.otherAllowance) },
  { key: 'leaveEncashment', label: 'Leave Encash', numeric: true, sortKey: 'leaveEncashment', getSortValue: (r) => r.leaveEncashment, render: (r) => money0(r.leaveEncashment) },
];

const directionArrow = (direction: string) => (direction === 'Outgoing' ? '↑ OutGoing' : direction === 'Incoming' ? '↓ InComing' : direction);

const statusTone = (status: string) =>
  status === 'Success' || status === 'COMPLETED' || status === 'ACCEPTED'
    ? 'border-green-300 bg-green-50 text-green-700'
    : status === 'Pending'
      ? 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-muted)]'
      : 'border-red-300 bg-red-50 text-red-700';

/** StatusCode is a raw HTTP-style code (e.g. "200"), not the word "Success" — normalize for the pill. */
const isSuccessStatus = (statusCode: string | null | undefined) => {
  if (!statusCode) return false;
  const s = statusCode.trim().toLowerCase();
  return s.startsWith('2') || s === 'success' || s === 'ok';
};

const TH ='px-3 py-2 text-left text-[10px] font-semibold uppercase tracking-wide text-[var(--text-muted)] whitespace-nowrap';
const TD = 'px-3 py-2 text-[var(--text-secondary)] whitespace-nowrap text-xs';
const SECTION = 'input-label text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]';

export function SifSummary360Drawer({ row, onClose }: { row: SifSummaryRow; onClose: () => void }) {
  const [tab, setTab] = useState<Tab>('file');
  const [integrationTab, setIntegrationTab] = useState<IntegrationTab>('core');
  const [logModal, setLogModal] = useState<{ correlationId: string; logType: LogType; operation?: string } | null>(null);
  const [expandedPostingAttempts, setExpandedPostingAttempts] = useState<Set<string>>(new Set());
  const togglePostingAttempt = (correlationId: string) =>
    setExpandedPostingAttempts((prev) => {
      const next = new Set(prev);
      if (next.has(correlationId)) next.delete(correlationId);
      else next.add(correlationId);
      return next;
    });
  const transactionId = row.transactionId ?? '';

  const detailQ = useQuery({
    queryKey: ['sif-detail', transactionId],
    enabled: !!transactionId,
    queryFn: () => sifApi.detail(transactionId),
  });
  const employeesQ = useQuery({
    queryKey: ['sif-employees', transactionId],
    enabled: !!transactionId && tab === 'records',
    queryFn: () => sifApi.employees(transactionId),
  });
  const postingDetailsQ = useQuery({
    queryKey: ['sif-posting-details', transactionId],
    enabled: !!transactionId && tab === 'integration' && integrationTab === 'core',
    queryFn: () => sifApi.postingDetails(transactionId),
  });
  const channelInteractionsQ = useQuery({
    queryKey: ['sif-channel-interactions', transactionId],
    enabled: !!transactionId && tab === 'integration' && integrationTab === 'channel',
    queryFn: () => sifApi.channelInteractions(transactionId),
  });

  // Asked of the service that serves the download, from the same stored acknowledgement, so the button
  // and the download can never disagree (the report data above can lag it, or lack the stored file).
  const ackNakFileQ = useQuery({
    queryKey: ['sif-ack-nak-file', transactionId],
    enabled: !!transactionId && tab === 'file',
    queryFn: () => sifApi.ackNakFileInfo(transactionId),
    retry: false,
  });

  const detail = detailQ.data;
  const ackNakFile: AckNakFileState = ackNakFileQ.isError ? 'error' : ackNakFileQ.data;
  const relatedMessages = buildRelatedMessages(detail, row, ackNakFile);

  const employeeRows: EmployeeRecordRow[] = useMemo(
    () => (employeesQ.data?.employees ?? []).map((r, i) => ({ ...r, rowId: `${r.employeeUniqueId}-${i}` })),
    [employeesQ.data],
  );
  const scr = employeesQ.data?.scr ?? null;

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label="SIF Summary 360"
      onClick={onClose}
    >
      <aside
        className="flex h-full w-full max-w-4xl sm:max-w-5xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div className="min-w-0">
            <h2 className="text-xl font-bold text-[var(--text-primary)]">SIF Summary 360</h2>
            <p className="mt-1 truncate font-mono text-xs text-[var(--text-muted)]">
              {row.sifFileName || row.fileName}
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Primary Navigation Tabs */}
        <div className="flex items-center gap-1 border-b border-[var(--border)] bg-[var(--bg-secondary)]/30 px-6 pt-2">
          {([
            { key: 'file', label: 'File Summary' },
            { key: 'integration', label: 'Integration 360' },
            { key: 'records', label: 'Record List' },
          ] as const).map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                'border-b-2 px-4 py-2.5 text-xs font-bold transition-colors whitespace-nowrap',
                tab === t.key
                  ? 'border-[var(--primary-blue)] text-[var(--primary-blue)] bg-[var(--bg-card)] rounded-t-md'
                  : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]',
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {!transactionId ? (
            <div className="flex h-48 flex-col items-center justify-center gap-2 text-center text-xs text-[var(--text-muted)]">
              <AlertCircle size={24} className="text-amber-500" />
              <span>This row has no transaction ID, so its 360 overview cannot be loaded.</span>
            </div>
          ) : detailQ.isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <LoadingSpinner />
            </div>
          ) : (
            <>
              {/* ═══ File Summary ═══ */}
              {tab === 'file' && (
                <div className="flex flex-col gap-6">
                  {/* File Details Card */}
                  <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm">
                    <div className="border-b border-[var(--border)] bg-[var(--bg-secondary)]/40 px-5 py-3">
                      <p className={SECTION}>File Details</p>
                    </div>
                    <div className="p-5">
                      <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
                        <Row label="File Name" value={dash(detail?.fileName ?? row.sifFileName)} mono />
                        <Row label="Corporate" value={dash(detail?.corporate ?? row.corporateName)} />
                        <Row label="Channel" value={dash(detail?.channel)} />
                        <Row
                          label="Current Status"
                          value={
                            <CatalogSifStatusBadge
                              status={dash(detail?.currentStatus ?? row.currentStatus)}
                              heuristic={sifStatusHeuristicTone}
                            />
                          }
                        />
                        <Row label="Initiated By" value={dash(detail?.initiatedBy ?? row.uploadedBy)} />
                        <Row label="Approved By" value="—" />
                        <Row label="Initiated DateTime" value={dash(detail?.initiatedDateTime)} mono />
                        <Row label="Approved DateTime" value="—" />
                      </dl>
                    </div>
                  </div>

                  {/* Processing Metric Tiles */}
                  <div>
                    <div className="mb-2">
                      <p className={SECTION}>Processing Metrics</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                      <Tile label="Total Records" value={detail?.totalRecords ?? row.totalRecords} />
                      <Tile label="System Accepted" value={detail?.systemAccepted ?? 0} tone="#16a34a" />
                      <Tile label="System Rejected" value={detail?.systemRejected ?? 0} tone="#dc2626" />
                      <Tile label="Own A/Cs" value={detail?.ownBankAccounts ?? null} />
                      <Tile label="Other Bank A/C" value={detail?.otherBankAccounts ?? null} />
                    </div>
                  </div>

                  {/* Central Bank Info */}
                  <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm">
                    <div className="border-b border-[var(--border)] bg-[var(--bg-secondary)]/40 px-5 py-3">
                      <p className={SECTION}>Central Bank Gateway Details</p>
                    </div>
                    <div className="p-5">
                      <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
                        <Row label="Sent to CB DateTime" value={formatDateTime(detail?.sentToCbDateTime)} />
                        {/* CB File Name is the original SIF sent to the CB (wps.Transactions.OriginalFileName, exposed as
                            `fileName`). The CB's ACK/NAK response file (CbAcknowledgements.RemoteFileName) belongs under
                            ACK/NAK File Name below, shown verbatim — and only when that file is actually stored: a response
                            recorded without one carries a synthesised name that no Central Bank file ever had. */}
                        <Row label="CB File Name" value={dash(detail?.fileName ?? row.sifFileName)} mono />
                        <Row label="CB Response" value={dash(detail?.cbResponse)} />
                        <Row label="ACK/NAK File Name" value={dash(availableAckNakFileName(ackNakFile))} mono />
                      </dl>
                    </div>
                  </div>

                  {/* Related Messages Split Timeline */}
                  <div>
                    <p className={SECTION}>Related Messages</p>
                    <RelatedMessages messages={relatedMessages} transactionId={transactionId} />
                  </div>
                </div>
              )}

              {/* ═══ Integration 360 ═══ */}
              {tab === 'integration' && (
                <div className="flex flex-col gap-6">
                  {/* Pills Tab Navigation */}
                  <div className="flex flex-wrap items-center gap-2">
                    {([
                      { key: 'core', label: 'CORE Ledger Posting' },
                      { key: 'channel', label: 'Channel Interactions' },
                    ] as const).map((t) => (
                      <button
                        key={t.key}
                        type="button"
                        onClick={() => setIntegrationTab(t.key)}
                        className={cn(
                          'rounded-full px-4 py-1.5 text-xs font-semibold transition-colors',
                          integrationTab === t.key
                            ? 'bg-[var(--primary-blue)] text-white shadow-sm'
                            : 'border border-[var(--border)] bg-white text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
                        )}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>

                  {integrationTab === 'core' ? (
                    <>
                      <div>
                        <p className={SECTION}>Summary Amounts</p>
                        <div className="mt-2.5 overflow-hidden rounded-xl border border-[var(--border)]">
                          {[
                            ['Total Transaction Amount', detail?.totalTransactionAmount],
                            ['Total Salary Amount', detail?.totalSalaryAmount],
                            ['Charge Amount', detail?.chargeAmount],
                            ['VAT', detail?.vatAmount],
                          ].map(([label, value], i) => (
                            <div
                              key={label as string}
                              className={cn(
                                'flex items-center justify-between gap-4 px-4 py-3 text-xs',
                                i % 2 === 0 ? 'bg-[var(--bg-card)]' : 'bg-[var(--bg-secondary)]/40',
                              )}
                            >
                              <span className="font-medium text-[var(--text-secondary)]">{label as string}</span>
                              <span className="font-mono text-xs font-bold tabular-nums text-[var(--text-primary)]">
                                {money(value as number | null | undefined)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <p className={SECTION}>Posting Details</p>
                        {postingDetailsQ.isLoading ? (
                          <div className="flex h-32 items-center justify-center"><LoadingSpinner /></div>
                        ) : (postingDetailsQ.data ?? []).length === 0 ? (
                          <div className="mt-2.5 rounded-xl border border-[var(--border)] p-8 text-center text-xs italic text-[var(--text-muted)]">
                            No posting legs found for this file.
                          </div>
                        ) : (
                          <div className="mt-2.5 overflow-x-auto rounded-xl border border-[var(--border)]">
                            <table className="w-full min-w-max text-xs">
                              <thead className="bg-[var(--bg-secondary)]/60">
                                <tr className="border-b border-[var(--border)]">
                                  {['', 'Type', 'Type Code', 'Legs', 'Status', 'Start Time', 'End Time', 'Req Log', 'Res Log', 'Failure Reason'].map((h) => (
                                    <th key={h} className={TH}>{h}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-[var(--border-light)]">
                                {(postingDetailsQ.data ?? []).map((attempt: PostingAttempt, i: number) => {
                                  const isOpen = expandedPostingAttempts.has(attempt.xref);
                                  return (
                                    <Fragment key={`${attempt.xref}-${i}`}>
                                      <tr className="odd:bg-[var(--bg-secondary)]/20">
                                        <td className={TD}>
                                          <button
                                            type="button"
                                            aria-label={isOpen ? 'Collapse legs' : 'Expand legs'}
                                            onClick={() => togglePostingAttempt(attempt.xref)}
                                            className="grid size-5 place-items-center rounded text-[var(--text-muted)] hover:bg-[var(--bg-card-hover)] hover:text-[var(--text-primary)]"
                                          >
                                            {isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                                          </button>
                                        </td>
                                        <td className={cn(TD, 'font-bold text-[var(--text-primary)]')}>
                                          {attempt.transactionType === 'REVERSAL' ? 'Reversal' : 'Posting'}
                                        </td>
                                        <td className={cn(TD, 'font-mono text-[11px]')}>{distinctTxnTypeCodes(attempt.legs)}</td>
                                        <td className={cn(TD, 'tabular-nums')}>{attempt.legs.length}</td>
                                        <td className={TD}>
                                          {attempt.status ? (
                                            <span className={cn('inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-bold', statusTone(isSuccessStatus(attempt.status) ? 'Success' : 'Failed'))}>
                                              {isSuccessStatus(attempt.status) ? 'Success' : 'Failed'}
                                            </span>
                                          ) : (
                                            <span className="text-[var(--text-muted)]">—</span>
                                          )}
                                        </td>
                                        <td className={cn(TD, 'font-mono text-[11px]')}>{formatDateTime(attempt.startTime)}</td>
                                        <td className={cn(TD, 'font-mono text-[11px]')}>{attempt.endTime ? formatDateTime(attempt.endTime) : <span className="text-[var(--text-muted)]">—</span>}</td>
                                        <td className={TD}>
                                          <button
                                            type="button"
                                            className="font-semibold text-[var(--primary-blue)] hover:underline cursor-pointer"
                                            onClick={() => setLogModal({ correlationId: attempt.correlationId, logType: 'RequestLog', operation: attempt.operation })}
                                          >
                                            View
                                          </button>
                                        </td>
                                        <td className={TD}>
                                          <button
                                            type="button"
                                            className="font-semibold text-[var(--primary-blue)] hover:underline cursor-pointer"
                                            onClick={() => setLogModal({ correlationId: attempt.correlationId, logType: 'ResponseLog', operation: attempt.operation })}
                                          >
                                            View
                                          </button>
                                        </td>
                                        <td className={cn(TD, 'text-[var(--text-muted)]')}>—</td>
                                      </tr>
                                      {isOpen && (
                                        <tr>
                                          <td colSpan={10} className="bg-[var(--bg-secondary)]/30 p-0">
                                            <table className="w-full min-w-max text-xs">
                                              <thead>
                                                <tr className="border-b border-[var(--border-light)]">
                                                  {['Leg', 'D/C', 'Type Code', 'Account', 'Amount', 'Currency', 'Branch'].map((h) => (
                                                    <th key={h} className={cn(TH, 'pl-10')}>{h}</th>
                                                  ))}
                                                </tr>
                                              </thead>
                                              <tbody className="divide-y divide-[var(--border-light)]">
                                                {attempt.legs.map((leg: PostingLeg) => (
                                                  <tr key={leg.legSequence}>
                                                    <td className={cn(TD, 'pl-10')}>{leg.legSequence}</td>
                                                    <td className={TD}>{leg.legType}</td>
                                                    <td className={cn(TD, 'font-mono text-[11px]')}>{dash(leg.txnTypeCode)}</td>
                                                    <td className={cn(TD, 'font-mono text-[11px]')}>{dash(leg.accountNumber)}</td>
                                                    <td className={cn(TD, 'tabular-nums')}>{money(leg.amount)}</td>
                                                    <td className={TD}>{dash(leg.currency)}</td>
                                                    <td className={TD}>{dash(leg.branchCode)}</td>
                                                  </tr>
                                                ))}
                                              </tbody>
                                            </table>
                                          </td>
                                        </tr>
                                      )}
                                    </Fragment>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    </>
                  ) : (
                    <div>
                      <p className={SECTION}>Channel Interactions</p>
                      {channelInteractionsQ.isLoading ? (
                        <div className="flex h-32 items-center justify-center"><LoadingSpinner /></div>
                      ) : (channelInteractionsQ.data ?? []).length === 0 ? (
                        <div className="mt-2.5 rounded-xl border border-[var(--border)] p-8 text-center text-xs italic text-[var(--text-muted)]">
                          No channel interactions found for this file.
                        </div>
                      ) : (
                        <div className="mt-2.5 overflow-x-auto rounded-xl border border-[var(--border)]">
                          <table className="w-full min-w-max text-xs">
                            <thead className="bg-[var(--bg-secondary)]/60">
                              <tr className="border-b border-[var(--border)]">
                                {['Channel', 'Action', 'Start DateTime', 'End DateTime', 'Status', 'Direction', 'Req Log', 'Res Log', 'Failure Reason', 'Retry'].map((h) => (
                                  <th key={h} className={TH}>{h}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-[var(--border-light)]">
                              {(channelInteractionsQ.data ?? []).map((c: ChannelInteraction, i: number) => (
                                <tr key={`${c.operation}-${c.startDateTime}-${i}`} className="odd:bg-[var(--bg-secondary)]/20">
                                  <td className={cn(TD, 'font-bold text-[var(--text-primary)]')}>{c.channel}</td>
                                  <td className={TD}>{c.action}</td>
                                  <td className={cn(TD, 'font-mono text-[11px]')}>{formatDateTime(c.startDateTime)}</td>
                                  <td className={cn(TD, 'font-mono text-[11px]')}>{c.endDateTime ? formatDateTime(c.endDateTime) : <span className="text-[var(--text-muted)]">—</span>}</td>
                                  <td className={TD}>
                                    {c.status ? (
                                      <span className={cn('inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-bold', statusTone(isSuccessStatus(c.status) ? 'Success' : 'Failed'))}>
                                        {isSuccessStatus(c.status) ? 'Success' : 'Failed'}
                                      </span>
                                    ) : (
                                      <span className="text-[var(--text-muted)]">—</span>
                                    )}
                                  </td>
                                  <td className={TD}>{directionArrow(c.direction)}</td>
                                  <td className={TD}>
                                    <button
                                      type="button"
                                      className="font-semibold text-[var(--primary-blue)] hover:underline cursor-pointer"
                                      onClick={() => setLogModal({ correlationId: c.correlationId, logType: 'RequestLog', operation: c.operation })}
                                    >
                                      View
                                    </button>
                                  </td>
                                  <td className={TD}>
                                    <button
                                      type="button"
                                      className="font-semibold text-[var(--primary-blue)] hover:underline cursor-pointer"
                                      onClick={() => setLogModal({ correlationId: c.correlationId, logType: 'ResponseLog', operation: c.operation })}
                                    >
                                      View
                                    </button>
                                  </td>
                                  <td className={cn(TD, 'text-[var(--text-muted)]')}>{dash(c.failureReason)}</td>
                                  <td className={cn(TD, 'tabular-nums font-semibold')}>{c.retry}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* ═══ Record List ═══ */}
              {tab === 'records' && (
                <div className="flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <p className={SECTION}>Employee Salary Records</p>
                    <span className="text-xs text-[var(--text-muted)]">
                      {employeeRows.length} records found
                    </span>
                  </div>

                  <SmartGrid
                    columns={EMPLOYEE_RECORD_COLUMNS}
                    rows={employeeRows}
                    getRowId={(r) => r.rowId}
                    storageKey="sif-employee-records-columns-v1"
                    loading={employeesQ.isLoading}
                    emptyTitle="No employee records"
                    emptyMessage="No employee records returned for this file."
                    exportFormats={['csv']}
                    exportFilename="sif-employee-records"
                  />

                  {scr && (
                    <div className="overflow-hidden rounded-xl border border-amber-300 bg-amber-50/70">
                      <div className="border-b border-amber-300 bg-amber-100/60 px-4 py-2">
                        <p className="font-mono text-[11px] font-bold uppercase tracking-wider text-amber-800">
                          SCR - Salary Control Record{scrSalaryMonthLabel(scr.salaryMonth)}
                        </p>
                      </div>
                      {/*
                        Sourced from wps.Sif_Scr directly (fixed 2026-09-16) — this is the file's own
                        declared control total, not a client-side sum of the Record List rows above.
                        Sif_Scr has no per-allowance breakdown (that concept only exists at the
                        EDR/EVP level), so this shows what the SCR actually carries: Establishment
                        Id, Record Count and Total Salary — not Fixed/Variable/Housing/etc.
                      */}
                      <dl className="grid grid-cols-2 gap-x-6 gap-y-2.5 p-4 sm:grid-cols-3">
                        <div>
                          <dt className="text-[10px] font-semibold uppercase tracking-wide text-amber-700">Establishment Id</dt>
                          <dd className="font-mono text-xs font-bold text-amber-900">{dash(scr.establishmentId)}</dd>
                        </div>
                        <div>
                          <dt className="text-[10px] font-semibold uppercase tracking-wide text-amber-700">Record Count</dt>
                          <dd className="font-mono text-xs font-bold tabular-nums text-amber-900">{scr.recordCount.toLocaleString()}</dd>
                        </div>
                        <div>
                          <dt className="text-[10px] font-semibold uppercase tracking-wide text-amber-700">Total Salary</dt>
                          <dd className="font-mono text-xs font-bold tabular-nums text-amber-900">{money(scr.totalSalary)}</dd>
                        </div>
                      </dl>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Drawer Fixed Footer */}
        <div className="flex justify-end border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <button onClick={onClose} className="btn-secondary large-btn !w-32 justify-center">
            Close
          </button>
        </div>
      </aside>

      {logModal && (
        <IntegrationLogModal
          correlationId={logModal.correlationId}
          logType={logModal.logType}
          operation={logModal.operation}
          onClose={() => setLogModal(null)}
        />
      )}
    </div>
  );
}

/**
 * Req Log / Res Log "View" modal (Integration 360 -> CORE -> Posting Details). Fetches the
 * matching smartintegration.IntegrationMessageLog row via sifApi.logPayload, keyed by the file's
 * TransactionId (surfaced as correlationId — see PostingAttempt.correlationId) plus operation.
 * Confirmed live 2026-09-15: this table is never keyed by a posting leg's Xref, and a posting +
 * a later reversal share one TransactionId, so operation ("cbs.acctxn.post" vs
 * "cbs.acctxn.reversal") is what picks the right one of the two.
 */
function IntegrationLogModal({ correlationId, logType, operation, onClose }: { correlationId: string; logType: LogType; operation?: string; onClose: () => void }) {
  const logQ = useQuery({
    queryKey: ['integration-log', correlationId, logType, operation],
    queryFn: () => sifApi.logPayload(correlationId, logType, operation),
    enabled: !!correlationId,
    retry: false,
  });

  const title = logType === 'RequestLog' ? 'Request log' : 'Response log';
  const downloadLabel = logType === 'RequestLog' ? 'Download request log as .txt' : 'Download response log as .txt';
  const data = logQ.data;
  const hasPayload = !!data?.payload;

  const handleDownload = () => {
    if (!data?.payload) return;
    const blob = new Blob([data.payload], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${correlationId}-${logType}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="fixed inset-0 z-[10003] flex items-center justify-center bg-black/50"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={(e) => { e.stopPropagation(); onClose(); }}
    >
      <div className="flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl bg-[var(--bg-card)] shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-3 bg-[var(--primary-blue)] px-5 py-3">
          <h3 className="text-sm font-bold text-white">{title}</h3>
          <div className="flex shrink-0 items-center gap-1">
            <button
              type="button"
              onClick={handleDownload}
              disabled={!hasPayload}
              aria-label={downloadLabel}
              title={downloadLabel}
              className="grid size-7 place-items-center rounded-md text-white hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Download size={15} />
            </button>
            <button type="button" onClick={onClose} aria-label="Close" className="grid size-7 place-items-center rounded-md text-white hover:bg-white/15">
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {logQ.isLoading ? (
            <div className="flex h-28 items-center justify-center"><LoadingSpinner /></div>
          ) : logQ.isError || !hasPayload ? (
            <p className="py-6 text-center text-xs text-[var(--text-muted)]">No log available for this leg.</p>
          ) : (
            <>
              <dl className="divide-y divide-[var(--border-light)]">
                <div className="flex items-center justify-between gap-4 py-2.5">
                  <dt className="text-xs font-semibold text-[var(--text-muted)]">Operation</dt>
                  <dd className="text-right text-sm font-bold text-[var(--text-primary)]">{dash(data?.operation)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 py-2.5">
                  <dt className="text-xs font-semibold text-[var(--text-muted)]">Status code</dt>
                  <dd>
                    <span className={cn('rounded px-2 py-0.5 text-[11px] font-semibold', statusTone(isSuccessStatus(data?.statusCode) ? 'Success' : 'Failed'))}>
                      {isSuccessStatus(data?.statusCode) ? 'Success' : 'Failed'}
                    </span>
                  </dd>
                </div>
                <div className="flex items-center justify-between gap-4 py-2.5">
                  <dt className="text-xs font-semibold text-[var(--text-muted)]">Date</dt>
                  <dd className="text-sm font-bold text-[var(--text-primary)]">{formatDateTime(data?.createdAt)}</dd>
                </div>
              </dl>

              <p className="mb-1.5 mt-4 text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">Payload</p>
              <pre className="max-h-80 overflow-auto whitespace-pre-wrap break-words rounded-lg border border-[var(--border-light)] bg-[var(--bg-secondary)]/40 p-3 font-mono text-[11px] text-[var(--text-primary)]">
                {data?.payload}
              </pre>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/** Shown when the server answers 404 (no such file in wps-inbound / no ACK/NAK content) — exactly this text. */
const FILE_NOT_FOUND_MESSAGE = 'File not found';
const DOWNLOAD_FAILED_MESSAGE = 'Download failed. Please try again.';

const isNotFoundError = (error: unknown): boolean =>
  typeof error === 'object' && error !== null && (error as { response?: { status?: number } }).response?.status === 404;

/** A usable name for a file about to be saved: not empty and never the dash placeholder. */
const usableFileName = (name: string | null | undefined): string | null => {
  const trimmed = name?.trim();
  return trimmed && trimmed !== NO_FILE_NAME ? trimmed : null;
};

/**
 * The name a Raw File is saved under: the server's (Content-Disposition), else the card's own label.
 * For the original SIF the label of an encrypted submission is "<name>.SIF.gpg" while the file served is
 * the decrypted "<name>.SIF", so a wrapper extension is dropped from the fallback — ciphertext is never
 * what this saves. Null when neither exists; the caller then reports a failure instead of saving "—".
 */
const savedFileName = (file: MsgRawFile, serverName: string | null): string | null => {
  const fromServer = usableFileName(serverName);
  if (fromServer) return fromServer;

  const label = usableFileName(file.fileName);
  if (!label) return null;
  return file.kind === 'original-sif' ? label.replace(/\.(gpg|pgp|asc)$/i, '') || null : label;
};

/**
 * The Raw File cards. Each Download button is independent: the ACK/NAK button calls only the ACK/NAK
 * endpoint and the Original SIF button only the Original SIF endpoint, and each sends only the
 * transaction id. A failed download saves nothing and says why next to its own button.
 */
function RawFileList({ files, transactionId }: { files: MsgRawFile[]; transactionId: string }) {
  const [busy, setBusy] = useState<Partial<Record<RawFileKind, boolean>>>({});
  const [errors, setErrors] = useState<Partial<Record<RawFileKind, string>>>({});

  const setError = (kind: RawFileKind, message: string | undefined) => setErrors((prev) => ({ ...prev, [kind]: message }));

  const download = async (file: MsgRawFile) => {
    const { kind } = file;
    if (!file.available || !transactionId || busy[kind]) return;

    setError(kind, undefined);
    setBusy((prev) => ({ ...prev, [kind]: true }));
    try {
      const result = kind === 'original-sif' ? await sifApi.downloadOriginalSif(transactionId) : await sifApi.downloadAckNak(transactionId);

      // An empty body is never saved as a file.
      if (!result?.blob || result.blob.size === 0) {
        setError(kind, FILE_NOT_FOUND_MESSAGE);
        return;
      }

      const name = savedFileName(file, result.fileName);
      if (!name) {
        setError(kind, DOWNLOAD_FAILED_MESSAGE);
        return;
      }

      downloadBlob(result.blob, name);
    } catch (error) {
      setError(kind, isNotFoundError(error) ? FILE_NOT_FOUND_MESSAGE : DOWNLOAD_FAILED_MESSAGE);
    } finally {
      setBusy((prev) => ({ ...prev, [kind]: false }));
    }
  };

  return (
    <div className="flex flex-col gap-2.5 pt-1">
      {files.map((f) => (
        <div key={f.kind}>
          <div className="flex items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--bg-secondary)]/30 px-4 py-3">
            <div className="min-w-0">
              <p className="truncate font-mono text-xs font-semibold text-[var(--text-primary)]">{f.fileName}</p>
              <p className="text-[11px] text-[var(--text-muted)]">{f.description}</p>
              {!f.available && f.note && <p className="text-[11px] italic text-[var(--text-muted)]">{f.note}</p>}
            </div>
            <button
              type="button"
              onClick={() => void download(f)}
              disabled={!f.available || !transactionId || !!busy[f.kind]}
              aria-label={`Download ${f.description}`}
              title={f.available ? undefined : (f.note ?? 'Available once the Central Bank has sent an acknowledgement file')}
              className="btn-tertiary !px-2.5 !py-1 text-xs inline-flex items-center gap-1 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Download size={12} /> Download
            </button>
          </div>
          {errors[f.kind] && (
            <p role="alert" className="mt-1 px-1 text-xs font-semibold text-red-600">
              {errors[f.kind]}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}

export function RelatedMessages({ messages, transactionId = '' }: { messages: RelatedMessage[]; transactionId?: string }) {
  const [selectedId, setSelectedId] = useState(messages[0]?.id ?? '');
  const [subTab, setSubTab] = useState(0);
  const selected = messages.find((m) => m.id === selectedId) ?? messages[0];
  const detail = selected?.detail;

  return (
    <div className="mt-2.5 flex min-h-[360px] flex-col overflow-hidden rounded-xl border border-[var(--border)] md:flex-row">
      {/* Messages List Sidebar */}
      <div className="w-full shrink-0 overflow-y-auto border-b border-[var(--border)] bg-[var(--bg-secondary)]/40 md:max-h-[460px] md:w-[230px] md:border-b-0 md:border-r">
        {messages.map((m) => (
          <button
            key={m.id}
            onClick={() => {
              setSelectedId(m.id);
              setSubTab(0);
            }}
            className={cn(
              'flex w-full items-center justify-between gap-2 border-b border-[var(--border)] px-4 py-3 text-left transition-colors last:border-b-0',
              selected?.id === m.id
                ? 'border-l-4 border-l-[var(--primary-blue)] bg-[var(--bg-card)] font-bold shadow-sm'
                : 'hover:bg-[var(--bg-card-hover)]',
            )}
          >
            <span className="min-w-0">
              <span className="block text-xs text-[var(--text-primary)]">{m.label}</span>
              <span className="mt-0.5 block text-[10px] text-[var(--text-muted)] font-normal">{m.receivedText}</span>
            </span>
            {m.statusText && (
              <span
                className={cn(
                  'shrink-0 rounded-full border px-2 py-0.5 text-[9px] font-bold',
                  m.statusClass === 'red' ? 'border-red-300 bg-red-50 text-red-700' : 'border-green-300 bg-green-50 text-green-700',
                )}
              >
                {m.statusText}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Message Drill-Down Details Panel */}
      <div className="min-w-0 flex-1 overflow-y-auto p-5 space-y-4">
        {!detail ? (
          <div className="flex h-full flex-col gap-4">
            <div className="flex flex-1 items-center justify-center text-xs italic text-[var(--text-muted)]">
              {selected?.label ?? 'Message'} — {selected?.pendingText ?? NOT_RECEIVED_TEXT}
            </div>
            {/* The original SIF exists from submission, so it is downloadable before any ACK/NAK. */}
            {selected?.rawFiles && selected.rawFiles.length > 0 && (
              <div>
                <p className={SECTION}>Raw Files</p>
                <RawFileList files={selected.rawFiles} transactionId={transactionId} />
              </div>
            )}
          </div>
        ) : (
          <>
            <div className="flex gap-8 border-b border-[var(--border)] pb-3 text-xs">
              <div>
                <p className="input-label mb-0.5 text-[10px]">Received DateTime</p>
                <p className="font-mono font-bold text-[var(--text-primary)]">{detail.receivedDateTime}</p>
              </div>
              <div>
                <p className="input-label mb-0.5 text-[10px]">Processed DateTime</p>
                <p className="font-mono font-bold text-[var(--text-primary)]">{detail.processedDateTime}</p>
              </div>
            </div>

            <dl className="grid grid-cols-1 gap-x-8 gap-y-2.5 sm:grid-cols-2">
              {detail.fields.map((f) => (
                <Row
                  key={f.label}
                  label={f.label}
                  mono={f.mono}
                  value={
                    f.badge ? (
                      <span className={cn('inline-flex rounded-full border px-2 py-0.5 text-[10px] font-bold', f.badge === 'red' ? 'border-red-300 bg-red-50 text-red-700' : 'border-green-300 bg-green-50 text-green-700')}>
                        {f.value}
                      </span>
                    ) : (
                      f.value
                    )
                  }
                />
              ))}
            </dl>

            {/* Sub-Tabs: Rounded Pills */}
            <div className="flex items-center gap-2 border-t border-[var(--border)] pt-3">
              {['Data Fields', 'Raw File', 'Error'].map((t, i) => (
                <button
                  key={t}
                  onClick={() => setSubTab(i)}
                  className={cn(
                    'rounded-full px-3.5 py-1 text-xs font-semibold transition-colors',
                    subTab === i
                      ? 'bg-[var(--primary-blue)] text-white shadow-sm'
                      : 'border border-[var(--border)] bg-white text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
                  )}
                >
                  {t}
                </button>
              ))}
            </div>

            {subTab === 0 && (
              <div className="space-y-4 pt-1">
                <div className="flex flex-col overflow-hidden rounded-xl border border-[var(--border)] sm:flex-row bg-[var(--bg-secondary)]/30">
                  {detail.context.map((c, i) => (
                    <div key={c.label} className={cn('flex-1 border-b border-[var(--border)] px-4 py-2.5 last:border-b-0 sm:border-b-0 sm:border-r sm:last:border-r-0', i === 2 && 'sm:flex-[1.6]')}>
                      <p className="input-label mb-0.5 text-[10px]">{c.label}</p>
                      <p className={cn('text-xs font-bold text-[var(--text-primary)]', c.mono && 'font-mono')}>{c.value}</p>
                    </div>
                  ))}
                </div>

                {detail.sections.map((s) => (
                  <div key={s.title}>
                    <p className="mb-1.5 text-xs font-bold text-[var(--text-primary)]">{s.title}</p>
                    <div
                      className={cn(
                        'flex flex-col overflow-hidden rounded-xl border sm:flex-row shadow-sm',
                        s.tone === 'success' ? 'border-green-300 bg-green-50/40' : 'border-red-300 bg-red-50/40',
                      )}
                    >
                      <div className="flex-[2] border-b border-[var(--border)] px-4 py-3 sm:border-b-0 sm:border-r">
                        <p className="input-label mb-0.5 text-[10px]">Processed File Name</p>
                        <p className="break-all font-mono text-xs font-bold text-[var(--text-primary)]">{s.processedFileName}</p>
                      </div>
                      <div className="flex-1 border-b border-[var(--border)] px-4 py-3 sm:border-b-0 sm:border-r">
                        <p className="input-label mb-0.5 text-[10px]">Number of Records</p>
                        <p className="mt-0.5 text-xl font-bold tabular-nums text-[var(--text-primary)]">{s.numberOfRecords}</p>
                      </div>
                      <div className="flex-1 px-4 py-3">
                        <p className="input-label mb-0.5 text-[10px]">Status</p>
                        <span className={cn('mt-1 inline-block rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase', s.tone === 'success' ? 'border-green-300 bg-green-100 text-green-700' : 'border-red-300 bg-red-100 text-red-700')}>
                          {s.status}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {subTab === 1 && <RawFileList files={detail.rawFiles} transactionId={transactionId} />}

            {subTab === 2 && (
              <div className="pt-1">
                <div className="overflow-hidden rounded-xl border border-red-200">
                  <p className="border-b border-red-200 bg-red-100/70 px-4 py-2 text-[10px] font-bold uppercase tracking-wider text-red-700">
                    DER — Detailed Error Records{detail.errors.length > 0 && ` (${detail.errors.length})`}
                  </p>
                  {/* A NAK can carry any number of DER records: the list scrolls under a fixed header rather than
                      stretching the drawer. */}
                  <div className="max-h-[420px] overflow-auto">
                    <table className="w-full min-w-max text-xs">
                      <thead className="sticky top-0 z-10 bg-[var(--bg-secondary)]">
                        <tr>
                          {['Line No.', 'Error Code', ...(SHOW_EMPLOYEE_REF_COLUMN ? ['Employee Reference ID'] : []), 'Error Description'].map((h) => (
                            <th key={h} className={TH}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[var(--border-light)]">
                        {detail.errors.length === 0 ? (
                          <tr>
                            <td colSpan={SHOW_EMPLOYEE_REF_COLUMN ? 4 : 3} className="px-4 py-8 text-center text-xs italic text-[var(--text-muted)]">
                              No error records identified.
                            </td>
                          </tr>
                        ) : (
                          detail.errors.map((err, i) => (
                            <tr key={`${err.lineNo}-${err.errorCode}-${i}`}>
                              <td className={cn(TD, 'text-center font-mono font-medium')}>{err.lineNo}</td>
                              <td className={cn(TD, 'font-mono font-bold text-red-600')}>{err.errorCode}</td>
                              {SHOW_EMPLOYEE_REF_COLUMN && <td className={cn(TD, 'font-mono')}>{err.employeeRefId}</td>}
                              <td className={TD}>{err.description}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: ReactNode; mono?: boolean }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
      <dt className="min-w-[180px] text-[11px] font-semibold text-[var(--text-muted)]">{label}:</dt>
      <dd className={cn('min-w-0 break-all text-xs text-[var(--text-primary)] font-medium', mono && 'font-mono text-[11px]')}>
        {value}
      </dd>
    </div>
  );
}

function Tile({ label, value, tone }: { label: string; value: number | null; tone?: string }) {
  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 text-center shadow-sm">
      <p className="text-2xl font-bold tabular-nums" style={{ color: tone ?? 'var(--text-primary)' }}>
        {value == null ? '—' : value.toLocaleString()}
      </p>
      <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{label}</p>
    </div>
  );
}