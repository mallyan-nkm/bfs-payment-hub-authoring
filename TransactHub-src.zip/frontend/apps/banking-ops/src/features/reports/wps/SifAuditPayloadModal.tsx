import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Check, Copy, X } from 'lucide-react';
import { LoadingSpinner, useDateTime } from '@paymenthub/ui';
import { sifApi } from './sifApi';

/** Pretty-prints a JSON body for reading; anything that is not valid JSON is shown exactly as stored. */
function prettyBody(body: string): string {
  try {
    return JSON.stringify(JSON.parse(body), null, 2);
  } catch {
    return body;
  }
}

function BodySection({ title, body, when }: { title: string; body: string | null; when: string | null }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    if (!body) return;
    try {
      await navigator.clipboard.writeText(prettyBody(body));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard can be blocked (insecure context / permissions); the text stays selectable in the box.
    }
  };

  return (
    <section>
      <div className="mb-1.5 flex items-center justify-between gap-3">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">
          {title}
          {when && <span className="ml-2 font-normal normal-case tracking-normal">{when}</span>}
        </p>
        {body && (
          <button
            type="button"
            onClick={copy}
            aria-label={`Copy ${title.toLowerCase()}`}
            className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] text-[var(--text-muted)] hover:bg-[var(--bg-secondary)] hover:text-[var(--text-primary)]"
          >
            {copied ? <Check size={12} /> : <Copy size={12} />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        )}
      </div>
      {body ? (
        <pre className="max-h-64 overflow-auto whitespace-pre-wrap break-words rounded-lg border border-[var(--border-light)] bg-[var(--bg-secondary)]/40 p-3 font-mono text-[11px] text-[var(--text-primary)]">
          {prettyBody(body)}
        </pre>
      ) : (
        <p className="rounded-lg border border-dashed border-[var(--border-light)] px-3 py-4 text-center text-xs text-[var(--text-muted)]">
          Not recorded for this upload.
        </p>
      )}
    </section>
  );
}

/**
 * "View more" modal for an Audit Trail upload row: the request body the channel sent and the response body
 * it received, read from platform.AuditLog on open (not with the grid). Opening either of the two rows
 * shows both halves of the exchange.
 */
export function SifAuditPayloadModal({
  transactionId,
  auditLogId,
  onClose,
}: {
  transactionId: string;
  auditLogId: number;
  onClose: () => void;
}) {
  const { formatInstant } = useDateTime();
  // A UTC instant -> the session zone; null when absent so the section hides its timestamp.
  const formatWhen = (utc?: string | null): string | null => (utc ? formatInstant(utc) : null);
  const payloadQ = useQuery({
    queryKey: ['sif-audit-payload', transactionId, auditLogId],
    queryFn: () => sifApi.auditTrailPayload(transactionId, auditLogId),
    retry: false,
  });
  const data = payloadQ.data;

  return (
    <div
      className="fixed inset-0 z-[10003] flex items-center justify-center bg-black/50"
      role="dialog"
      aria-modal="true"
      aria-label="Request and response details"
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl bg-[var(--bg-card)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3 bg-[var(--primary-blue)] px-5 py-3">
          <h3 className="text-sm font-bold text-white">Request &amp; Response</h3>
          <button type="button" onClick={onClose} aria-label="Close" className="grid size-7 place-items-center rounded-md text-white hover:bg-white/15">
            <X size={16} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {payloadQ.isLoading ? (
            <div className="flex h-28 items-center justify-center">
              <LoadingSpinner />
            </div>
          ) : payloadQ.isError || !data ? (
            <p className="py-6 text-center text-xs font-semibold text-[var(--accent-red)]">Could not load the request and response for this activity.</p>
          ) : (
            <div className="flex flex-col gap-5">
              <BodySection title="Request body" body={data.requestBody} when={formatWhen(data.requestedAtUtc)} />
              <BodySection title="Response body" body={data.responseBody} when={formatWhen(data.respondedAtUtc)} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
