/**
 * SIF Summary 360 -> File Summary -> Related Messages.
 *
 * Two guarantees: the left pane lists only "SIF ACK/NAK", and the detail pane renders only the
 * section matching the Central Bank's actual response (wps.CbAcknowledgements.AckType, surfaced as
 * `cbResponse` — "SIFACK" / "SIFNAK"), never both. Rendered to static markup like the sibling tests.
 */
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import { RelatedMessages, buildRelatedMessages, sifAckKind } from './SifSummary360Drawer';
import type { SifFileDetailResponse, SifSummaryRow } from './sifApi';

const ROW: SifSummaryRow = {
  slNo: 1,
  fileName: 'file.csv',
  sifFileName: 'SIF_001.SIF',
  transactionId: 'TX-1',
  corporateName: 'Acme',
  accountNumber: '123',
  molEstablishmentId: 'MOL-9',
  uploadDate: '2026-09-01T10:00:00',
  totalRecords: 10,
  totalAmount: 1000,
  currentStatus: 'CB_ACK_RECEIVED',
  uploadedBy: 'ops',
};

const detail = (cbResponse: string | null): SifFileDetailResponse => ({
  fileName: 'file.csv',
  corporate: 'Acme',
  channel: 'UI',
  initiatedDateTime: '2026-09-01T10:00:00',
  initiatedBy: 'ops',
  currentStatus: 'CB_ACK_RECEIVED',
  totalRecords: 10,
  systemAccepted: 8,
  systemRejected: 2,
  cbResponse,
  cbFileName: 'SIFACK_000000000001',
  sentToCbDateTime: null,
  totalTransactionAmount: 1000,
  totalSalaryAmount: 1000,
  chargeAmount: 5,
  vatAmount: 0.25,
});

const render = (d: SifFileDetailResponse | undefined) =>
  renderToStaticMarkup(<RelatedMessages messages={buildRelatedMessages(d, ROW)} />);

const ACK_TITLE = 'ACK — File Accepted';
const NAK_TITLE = 'NAK — File Rejected';

describe('sifAckKind', () => {
  it.each([
    ['SIFACK', 'ACK'],
    ['sifack', 'ACK'],
    ['ACK', 'ACK'],
    ['SIFNAK', 'NAK'],
    [' sifnak ', 'NAK'],
    ['NAK', 'NAK'],
    ['NACK', 'NAK'],
  ])('%s -> %s', (input, expected) => {
    expect(sifAckKind(input)).toBe(expected);
  });

  it.each([null, undefined, '', '   ', 'WHATEVER'])('%j -> null (no recognised response)', (input) => {
    expect(sifAckKind(input)).toBeNull();
  });
});

describe('left pane', () => {
  it.each([['SIFACK'], ['SIFNAK'], [null]])('lists only SIF ACK/NAK (cbResponse=%s)', (cb) => {
    expect(buildRelatedMessages(detail(cb), ROW).map((m) => m.label)).toEqual(['SIF ACK/NAK']);
  });

  it('lists only SIF ACK/NAK while the detail is still loading', () => {
    expect(buildRelatedMessages(undefined, ROW).map((m) => m.label)).toEqual(['SIF ACK/NAK']);
  });

  it('renders SIF ACK/NAK and none of the other message types', () => {
    const html = render(detail('SIFACK'));
    expect(html).toContain('>SIF ACK/NAK<');
    for (const label of ['RTC', 'PAF', 'PRC', 'PRCACK/NAK', 'PRC ACK/NAK', 'DIF', 'DIF ACK/NAK', 'RFA', 'RFA ACK/NAK', 'RFR', 'RFR ACK/NAK']) {
      expect(html).not.toContain(`>${label}<`);
    }
  });
});

describe('detail pane', () => {
  it('ACK response: renders only the ACK section', () => {
    const html = render(detail('SIFACK'));
    expect(html).toContain(ACK_TITLE);
    expect(html).not.toContain(NAK_TITLE);
    expect(html).toContain('>ACCEPTED<');
  });

  it('NAK response: renders only the NAK section (SIFNAK is recognised)', () => {
    const html = render(detail('SIFNAK'));
    expect(html).toContain(NAK_TITLE);
    expect(html).not.toContain(ACK_TITLE);
    expect(html).not.toContain('>ACCEPTED<');
  });

  it('keeps the response styling: green for ACK, red for NAK', () => {
    expect(render(detail('SIFACK'))).toContain('border-green-300');
    const nak = render(detail('SIFNAK'));
    expect(nak).toContain('border-red-300');
    expect(nak).toContain('>SIFNAK<');
  });

  it('keeps the data fields of the applicable section', () => {
    const ack = render(detail('SIFACK'));
    expect(ack).toContain('file.csv');
    expect(ack).toContain('>8<');
    const nak = render(detail('SIFNAK'));
    expect(nak).toContain('file.csv');
    expect(nak).toContain('>2<');
  });

  it.each([[null], [''], [undefined]])('no response yet (cbResponse=%j): shows the pending state, neither section', (cb) => {
    const html = render(detail(cb as string | null));
    expect(html).toContain('Pending processing. No message payload available yet.');
    expect(html).not.toContain(ACK_TITLE);
    expect(html).not.toContain(NAK_TITLE);
  });

  it('detail not loaded yet: shows the pending state', () => {
    const html = render(undefined);
    expect(html).toContain('Pending processing. No message payload available yet.');
    expect(html).not.toContain(ACK_TITLE);
    expect(html).not.toContain(NAK_TITLE);
  });

  it('switching from ACK data to NAK data switches the rendered section', () => {
    const ack = render(detail('SIFACK'));
    const nak = render(detail('SIFNAK'));
    expect([ack.includes(ACK_TITLE), ack.includes(NAK_TITLE)]).toEqual([true, false]);
    expect([nak.includes(ACK_TITLE), nak.includes(NAK_TITLE)]).toEqual([false, true]);
  });
});

/**
 * File names. The original SIF (`fileName`, wps.Transactions.OriginalFileName) and the CB's ACK/NAK response
 * (`cbFileName`, wps.CbAcknowledgements.RemoteFileName) are different files: both generic "File Name" fields are
 * the SIF; the response file is only the "CB acknowledgement file" raw-file entry.
 */
describe('file names', () => {
  const SIF = '0001234567890260909195055.SIF';
  const ACK = '0001234567890260909195055123454585457.ACK';
  const NAK = '0001234567890260909195055123454585457.NAK';

  const withNames = (over: Partial<SifFileDetailResponse>): SifFileDetailResponse => ({
    ...detail('SIFACK'),
    fileName: SIF,
    cbFileName: ACK,
    ...over,
  });
  const paneOf = (d: SifFileDetailResponse, row: SifSummaryRow = ROW) => {
    const pane = buildRelatedMessages(d, row)[0].detail;
    if (!pane) throw new Error('expected an ACK/NAK pane');
    return pane;
  };
  const headerFileName = (d: SifFileDetailResponse, row?: SifSummaryRow) => paneOf(d, row).fields.find((f) => f.label === 'File Name')?.value;
  const contextFileName = (d: SifFileDetailResponse, row?: SifSummaryRow) => paneOf(d, row).context.find((c) => c.label === 'File Name')?.value;
  const rawFile = (d: SifFileDetailResponse, description: string, row?: SifSummaryRow) =>
    paneOf(d, row).rawFiles.find((f) => f.description === description)?.fileName;

  it.each([
    ['ACK', 'SIFACK', ACK],
    ['NAK', 'SIFNAK', NAK],
  ])('%s: header and context "File Name" are the original SIF, never the response file', (_kind, cbResponse, responseFile) => {
    const d = withNames({ cbResponse, cbFileName: responseFile });
    expect(headerFileName(d)).toBe(SIF);
    expect(contextFileName(d)).toBe(SIF);
    expect(headerFileName(d)).not.toBe(responseFile);
    expect(contextFileName(d)).not.toBe(responseFile);
  });

  it.each([
    ['ACK', 'SIFACK', ACK],
    ['NAK', 'SIFNAK', NAK],
  ])('%s: raw files keep the response file and the original SIF apart', (_kind, cbResponse, responseFile) => {
    const d = withNames({ cbResponse, cbFileName: responseFile });
    expect(rawFile(d, 'CB acknowledgement file')).toBe(responseFile);
    expect(rawFile(d, 'Original SIF file')).toBe(SIF);
  });

  it('ACK: Processed File Name is the original SIF and the status stays SIFACK', () => {
    const m = buildRelatedMessages(withNames({}), ROW)[0];
    expect(m.detail?.sections[0].processedFileName).toBe(SIF);
    expect(m.statusText).toBe('SIFACK');
  });

  it('NAK: Processed File Name keeps its existing behaviour (SIF when rows were rejected, "-" otherwise)', () => {
    const rejected = buildRelatedMessages(withNames({ cbResponse: 'SIFNAK', cbFileName: NAK, systemRejected: 2 }), ROW)[0];
    expect(rejected.detail?.sections[0].processedFileName).toBe(SIF);
    expect(rejected.statusText).toBe('SIFNAK');
    const none = buildRelatedMessages(withNames({ cbResponse: 'SIFNAK', cbFileName: NAK, systemRejected: 0 }), ROW)[0];
    expect(none.detail?.sections[0].processedFileName).toBe('-');
  });

  it('the response file is not in the rendered Data Fields tab at all', () => {
    const html = render(withNames({}));
    expect(html).toContain(SIF);
    expect(html).not.toContain(ACK);
  });

  it('no response: the pending message carries no detail and so no File Name field', () => {
    for (const cb of [null, '']) {
      const [m] = buildRelatedMessages(withNames({ cbResponse: cb }), ROW);
      expect(m.pending).toBe(true);
      expect(m.detail).toBeUndefined();
    }
  });

  it('original SIF falls back to row.sifFileName when detail.fileName is empty, then to a dash', () => {
    const row = { ...ROW, sifFileName: 'fallback.SIF' };
    const d = withNames({ fileName: '' });
    expect(headerFileName(d, row)).toBe('fallback.SIF');
    expect(contextFileName(d, row)).toBe('fallback.SIF');
    expect(rawFile(d, 'Original SIF file', row)).toBe('fallback.SIF');

    const bare = { ...ROW, sifFileName: '' };
    expect(headerFileName(d, bare)).toBe('—');
    expect(contextFileName(d, bare)).toBe('—');
  });

  it('the ACK/NAK file never falls back to the SIF name', () => {
    const d = withNames({ cbFileName: '' });
    expect(rawFile(d, 'CB acknowledgement file')).toBe('—');
    expect(rawFile(d, 'CB acknowledgement file')).not.toBe(SIF);
    expect(headerFileName(d)).toBe(SIF);
    const nul = withNames({ cbFileName: null });
    expect(rawFile(nul, 'CB acknowledgement file')).toBe('—');
  });

  it('a legacy stored response name is shown verbatim, not normalised', () => {
    const legacy = '0001234567890260909195055_123454585457.SIFACK';
    expect(rawFile(withNames({ cbFileName: legacy }), 'CB acknowledgement file')).toBe(legacy);
    expect(rawFile(withNames({ cbResponse: 'SIFNAK', cbFileName: legacy.replace('SIFACK', 'SIFNAK') }), 'CB acknowledgement file')).toBe(
      legacy.replace('SIFACK', 'SIFNAK'),
    );
  });
});

describe('File Summary -> Error tab: the NAK detail errors', () => {
  it('maps each DER record of the NAK to an error row', () => {
    const d: SifFileDetailResponse = {
      ...detail('SIFNAK'),
      nakErrors: [
        { lineNumber: 3, errorCode: 'E012', description: 'Invalid routing code' },
        { lineNumber: 0, errorCode: '', description: '' },
      ],
    };
    expect(buildRelatedMessages(d, ROW)[0].detail?.errors).toEqual([
      { lineNo: '3', errorCode: 'E012', employeeRefId: '—', description: 'Invalid routing code' },
      { lineNo: '—', errorCode: '—', employeeRefId: '—', description: '—' },
    ]);
  });

  it('a NAK with many DER records shows every one, duplicates included, in order', () => {
    const many = Array.from({ length: 40 }, (_, i) => ({ lineNumber: i + 1, errorCode: `E${i + 1}`, description: `Reason ${i + 1}` }));
    const d: SifFileDetailResponse = { ...detail('SIFNAK'), nakErrors: [...many, many[39]] };
    const errors = buildRelatedMessages(d, ROW)[0].detail?.errors ?? [];
    expect(errors).toHaveLength(41);
    expect(errors.map((e) => e.lineNo)).toEqual([...many.map((m) => String(m.lineNumber)), '40']);
  });

  it('an ACK, or a response without nakErrors, has no error rows', () => {
    expect(buildRelatedMessages(detail('SIFACK'), ROW)[0].detail?.errors).toEqual([]);
    expect(buildRelatedMessages({ ...detail('SIFNAK'), nakErrors: undefined }, ROW)[0].detail?.errors).toEqual([]);
  });
});
