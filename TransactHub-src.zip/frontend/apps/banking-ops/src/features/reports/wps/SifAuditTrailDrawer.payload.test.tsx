/**
 * SIF Summary -> Audit Trail drawer -> More Details "View more".
 *
 * Only the upload request/reply rows carry an auditLogId, so only they get the link; it opens a modal with the
 * request and response bodies fetched on demand. Workflow rows keep their plain More Details text and no link.
 *
 * Rendered in jsdom against a mocked sifApi.
 */
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SifAuditTrailDrawer } from './SifAuditTrailDrawer';
import type { SifAuditTrailPayload, SifAuditTrailResult, SifSummaryRow } from './sifApi';

const api = vi.hoisted(() => ({
  auditTrail: vi.fn(),
  auditTrailPayload: vi.fn(),
  exportAuditTrail: vi.fn(),
}));

vi.mock('./sifApi', () => ({ sifApi: api }));

const SIF = '0001234567895261008010014.SIF';

const ROW: SifSummaryRow = {
  slNo: 1,
  fileName: SIF,
  sifFileName: SIF,
  transactionId: 'TXN-1',
  corporateName: 'Acme',
  accountNumber: '123',
  molEstablishmentId: '0001234567895',
  uploadDate: '2026-10-08T01:00:14',
  totalRecords: 10,
  totalAmount: 1000,
  currentStatus: 'CB_FILE_SUBMITTED',
  uploadedBy: 'ops',
};

const TRAIL: SifAuditTrailResult = {
  reference: SIF,
  transactionType: 'WPS — SIF Salary File',
  customer: 'Acme',
  status: 'CB_FILE_SUBMITTED',
  channel: 'IB',
  activities: [
    {
      activity: 'Request Received',
      actionBy: 'IB',
      actionedDateTime: '08-10-2026 01:00:10 AM',
      occurredAtUtc: '2026-10-08T01:00:10Z',
      channel: 'IB',
      status: 'Received',
      remarks: SIF,
      moreDetails: null,
      auditLogId: 101,
    },
    {
      activity: 'Channel Response Sent',
      actionBy: 'svc',
      actionedDateTime: '08-10-2026 01:00:11 AM',
      occurredAtUtc: '2026-10-08T01:00:11Z',
      channel: 'IB',
      status: 'Rejected',
      remarks: 'HTTP 400',
      moreDetails: '006',
      auditLogId: 102,
    },
    {
      activity: 'wps.SubmitSifToCb',
      actionBy: 'svc',
      actionedDateTime: '08-10-2026 01:00:14 AM',
      occurredAtUtc: '2026-10-08T01:00:14Z',
      channel: 'IB',
      status: 'Failed',
      remarks: '',
      moreDetails: 'CB-01: gateway timeout',
      auditLogId: null,
    },
  ],
};

const PAYLOAD: SifAuditTrailPayload = {
  auditLogId: 101,
  requestBody: '{"channel":"IB","filename":"0001234567895261008010014.SIF"}',
  requestedAtUtc: '2026-10-08T01:00:10Z',
  responseBody: '{"status":"accepted"}',
  respondedAtUtc: '2026-10-08T01:00:11Z',
};

function renderDrawer() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <SifAuditTrailDrawer row={ROW} onClose={() => {}} />
    </QueryClientProvider>,
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  api.auditTrail.mockResolvedValue(TRAIL);
});

// Explicit: automatic cleanup only runs when vitest globals are enabled.
afterEach(cleanup);

describe('Audit Trail "View more"', () => {
  it('shows the link only on the upload request/reply rows, not on workflow rows', async () => {
    renderDrawer();
    await screen.findByText('Request Received');

    expect(screen.getAllByRole('button', { name: 'View more' })).toHaveLength(2);
    // The workflow row keeps its plain error text and gets no link.
    expect(screen.getByText('CB-01: gateway timeout')).toBeTruthy();
  });

  it('keeps the existing More Details text beside the link on a rejected reply', async () => {
    renderDrawer();
    await screen.findByText('Channel Response Sent');

    expect(screen.getByText('006')).toBeTruthy();
  });

  it('does not fetch any body until the link is pressed', async () => {
    renderDrawer();
    await screen.findByText('Request Received');

    expect(api.auditTrailPayload).not.toHaveBeenCalled();
  });

  it('opens the modal for that row and shows the request and response bodies pretty-printed', async () => {
    api.auditTrailPayload.mockResolvedValue(PAYLOAD);
    renderDrawer();
    await screen.findByText('Request Received');

    fireEvent.click(screen.getAllByRole('button', { name: 'View more' })[0]);

    expect(api.auditTrailPayload).toHaveBeenCalledWith('TXN-1', 101);
    await screen.findByText('Request body', { exact: false });
    expect(screen.getByText('Response body', { exact: false })).toBeTruthy();
    // Pretty-printed: each JSON field on its own line.
    expect(screen.getByText(/"filename": "0001234567895261008010014\.SIF"/)).toBeTruthy();
    expect(screen.getByText(/"status": "accepted"/)).toBeTruthy();
  });

  it('says a half of the exchange was not recorded when its body is null', async () => {
    api.auditTrailPayload.mockResolvedValue({ ...PAYLOAD, requestBody: null, requestedAtUtc: null });
    renderDrawer();
    await screen.findByText('Request Received');

    fireEvent.click(screen.getAllByRole('button', { name: 'View more' })[1]);

    await screen.findByText('Not recorded for this upload.');
    expect(screen.getByText(/"status": "accepted"/)).toBeTruthy();
  });

  it('shows an error when the bodies cannot be loaded, and the modal closes without closing the drawer', async () => {
    api.auditTrailPayload.mockRejectedValue(new Error('boom'));
    renderDrawer();
    await screen.findByText('Request Received');

    fireEvent.click(screen.getAllByRole('button', { name: 'View more' })[0]);
    await screen.findByText('Could not load the request and response for this activity.');

    const modal = screen.getByRole('dialog', { name: 'Request and response details' });
    fireEvent.click(within(modal).getByRole('button', { name: 'Close' }));
    await waitFor(() => expect(screen.queryByText('Could not load the request and response for this activity.')).toBeNull());
    // The Audit Trail itself is still showing.
    expect(screen.getByText('Request Received')).toBeTruthy();
  });
});
