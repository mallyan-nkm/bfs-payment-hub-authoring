/**
 * MaskedValue type matching the backend MaskedFieldDto contract:
 * - maskedValue is always present (required string, may be empty)
 * - actualValue is optional (nullable string)
 * Backend: public required string MaskedValue { get; init; } / public string? ActualValue { get; init; }
 */
export interface MaskedValue {
  maskedValue: string;
  actualValue: string | null;
}

export default function MaskedCell({ value, isUnmasked, className }: { value: MaskedValue | null | undefined; isUnmasked: boolean; className?: string }) {
  // Handle null/undefined at the field level (defensive - API should always provide the object)
  if (!value) return <span className={`na ${className ?? ''}`}>—</span>;
  
  // Display logic: show actualValue if unmasked and present, otherwise show maskedValue
  // maskedValue is guaranteed to be a string (may be empty for missing account numbers)
  const display = (isUnmasked && value.actualValue) ? value.actualValue : (value.maskedValue || '—');
  
  return <span className={`${className ?? ''}`}>{display}</span>;
}
