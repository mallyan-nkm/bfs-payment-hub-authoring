/**
 * SIF Summary / SIF Detail — the upload-date window inherited from Total Transactions
 * (`?uploadDateFrom=…&uploadDateTo=…`).
 *
 * What these guard, beyond "the filter arrives":
 *  - the FIRST request already carries the dates, and no request ever goes out without them;
 *  - the draft→applied debounce does not wipe the inherited values;
 *  - a direct visit (sidebar link, no params) is unfiltered and leaves the filter row closed.
 *
 * Rendered in jsdom against a mocked sifApi.
 */
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { SifSummaryReportPage } from './SifSummaryReportPage';
import SifDetailReportPage from './SifDetailReportPage';

const api = vi.hoisted(() => ({
  summary: vi.fn(),
  sifDetailReport: vi.fn(),
  exportSifSummaryReport: vi.fn(),
  exportSifDetailReport: vi.fn(),
}));

vi.mock('./sifApi', () => ({ sifApi: api }));

// The pages only need "everything allowed"; the real hook wants the app's permission provider.
vi.mock('@paymenthub/ui', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@paymenthub/ui')>()),
  usePermissions: () => ({ can: () => true }),
  Can: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

/** Longer than both pages' draft→applied debounce (450 ms Summary, 350 ms Detail). */
const PAST_DEBOUNCE_MS = 700;
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function renderAt(url: string, page: 'summary' | 'detail') {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[url]}>{page === 'summary' ? <SifSummaryReportPage /> : <SifDetailReportPage />}</MemoryRouter>
    </QueryClientProvider>,
  );
}

const emptyPage = { data: [], totalRecords: 0, page: 1, pageSize: 10 };

beforeEach(() => {
  vi.clearAllMocks();
  // A saved column layout from another test must not hide the date column; the pages themselves
  // tolerate storage being absent, so do the same here.
  try {
    localStorage.clear();
  } catch {
    /* no storage in this environment */
  }
  api.summary.mockResolvedValue(emptyPage);
  api.sifDetailReport.mockResolvedValue(emptyPage);
});

const sentFilters = (mock: ReturnType<typeof vi.fn>) => mock.mock.calls.map(([f]) => f as Record<string, unknown>);

describe.each([
  {
    name: 'SIF Summary',
    page: 'summary' as const,
    path: '/reports/sif-summary',
    call: api.summary,
    fromLabel: 'Upload date from',
    toLabel: 'Upload date to',
  },
  {
    name: 'SIF Detail',
    page: 'detail' as const,
    path: '/reports/wps/sif-detail',
    call: api.sifDetailReport,
    fromLabel: 'File Upload Date & Time from',
    toLabel: 'File Upload Date & Time to',
  },
])('$name — inherited upload-date window', ({ page, path, call, fromLabel, toLabel }) => {
  it.each([
    ['Today', '2026-09-15', '2026-09-15'],
    ['Yesterday', '2026-09-14', '2026-09-14'],
    ['Custom Range', '2026-09-01', '2026-09-07'],
  ])('%s: the first request already carries the dates, and none goes out without them', async (_label, from, to) => {
    renderAt(`${path}?uploadDateFrom=${from}&uploadDateTo=${to}`, page);

    await waitFor(() => expect(call).toHaveBeenCalled());

    expect(sentFilters(call)[0]).toMatchObject({ uploadDateFrom: from, uploadDateTo: to });
    for (const sent of sentFilters(call)) {
      expect(sent).toMatchObject({ uploadDateFrom: from, uploadDateTo: to });
    }
  });

  it('shows the inherited dates in an open filter row', async () => {
    renderAt(`${path}?uploadDateFrom=2026-09-01&uploadDateTo=2026-09-07`, page);

    expect(await screen.findByLabelText(fromLabel)).toHaveValue('2026-09-01');
    expect(screen.getByLabelText(toLabel)).toHaveValue('2026-09-07');
    expect(screen.getByRole('button', { name: /Filters \(2\)/ })).toBeInTheDocument();
  });

  it('keeps the inherited dates after the debounce has run', async () => {
    renderAt(`${path}?uploadDateFrom=2026-09-01&uploadDateTo=2026-09-07`, page);
    await waitFor(() => expect(call).toHaveBeenCalled());

    await wait(PAST_DEBOUNCE_MS);

    expect(screen.getByLabelText(fromLabel)).toHaveValue('2026-09-01');
    expect(screen.getByLabelText(toLabel)).toHaveValue('2026-09-07');
    expect(screen.getByRole('button', { name: /Filters \(2\)/ })).toBeInTheDocument();
    // Nothing cleared the filter, so nothing re-requested without it either.
    for (const sent of sentFilters(call)) {
      expect(sent).toMatchObject({ uploadDateFrom: '2026-09-01', uploadDateTo: '2026-09-07' });
    }
  });

  it('is unfiltered, with the filter row closed, when opened directly without params', async () => {
    renderAt(path, page);
    await waitFor(() => expect(call).toHaveBeenCalled());

    await wait(PAST_DEBOUNCE_MS);

    for (const sent of sentFilters(call)) {
      expect(sent.uploadDateFrom ?? null).toBeNull();
      expect(sent.uploadDateTo ?? null).toBeNull();
    }
    expect(screen.queryByLabelText(fromLabel)).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: /^Filters$/ })).toBeInTheDocument();
  });

  it('ignores a malformed date param rather than sending it', async () => {
    renderAt(`${path}?uploadDateFrom=banana&uploadDateTo=2026-09-07`, page);
    await waitFor(() => expect(call).toHaveBeenCalled());

    for (const sent of sentFilters(call)) {
      expect(sent.uploadDateFrom ?? null).toBeNull();
      expect(sent).toMatchObject({ uploadDateTo: '2026-09-07' });
    }
  });

  it('ignores the dashboard-vocabulary params the page does not own', async () => {
    renderAt(`${path}?rail=WPS&direction=Outward&dateType=transactionDate&dateRange=today`, page);
    await waitFor(() => expect(call).toHaveBeenCalled());

    for (const sent of sentFilters(call)) {
      expect(sent.uploadDateFrom ?? null).toBeNull();
      expect(sent.uploadDateTo ?? null).toBeNull();
    }
  });
});
