/**
 * SIF Summary 360 -> File Summary -> Related Messages -> Raw File: the two Download buttons.
 *
 * The ACK/NAK button calls only the ACK/NAK endpoint, the Original SIF button only the Original SIF
 * endpoint, each with just the transaction id. The original SIF is downloadable before the Central Bank has
 * answered; the ACK/NAK file is not. A 404 shows exactly "File not found", and nothing is saved on any
 * failure. The Integration 360 Req/Res log download is a separate, unchanged `.txt` download.
 *
 * Rendered in jsdom against a mocked sifApi and a mocked file saver.
 */
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SifSummary360Drawer } from './SifSummary360Drawer';
import type { SifFileDetailResponse, SifSummaryRow } from './sifApi';

const api = vi.hoisted(() => ({
  detail: vi.fn(),
  employees: vi.fn(),
  postingDetails: vi.fn(),
  channelInteractions: vi.fn(),
  logPayload: vi.fn(),
  downloadOriginalSif: vi.fn(),
  downloadAckNak: vi.fn(),
}));
const saver = vi.hoisted(() => ({ downloadBlob: vi.fn() }));

vi.mock('./sifApi', () => ({ sifApi: api }));
vi.mock('../../../shared/utils/downloadBlob', () => saver);

const SIF = '0001234567890260909195120.SIF';
const ACK_FILE = '0001234567890260909195120_N10000001.SIFACK';
const NAK_FILE = '0001234567890260909195120_N10000001.SIFNAK';

const ROW: SifSummaryRow = {
  slNo: 1,
  fileName: SIF,
  sifFileName: SIF,
  transactionId: 'TXN-1',
  corporateName: 'Acme',
  accountNumber: '123',
  molEstablishmentId: '0001234567890',
  uploadDate: '2026-09-09T19:51:20',
  totalRecords: 10,
  totalAmount: 1000,
  currentStatus: 'CB_ACK_RECEIVED',
  uploadedBy: 'ops',
};

const detail = (over: Partial<SifFileDetailResponse>): SifFileDetailResponse => ({
  fileName: SIF,
  corporate: 'Acme',
  channel: 'UI',
  initiatedDateTime: '2026-09-09T19:51:20',
  initiatedBy: 'ops',
  currentStatus: 'CB_ACK_RECEIVED',
  totalRecords: 10,
  systemAccepted: 10,
  systemRejected: 0,
  cbResponse: null,
  cbFileName: null,
  sentToCbDateTime: null,
  totalTransactionAmount: 1000,
  totalSalaryAmount: 1000,
  chargeAmount: 0,
  vatAmount: 0,
  ...over,
});

function renderDrawer(row: SifSummaryRow = ROW) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <SifSummary360Drawer row={row} onClose={() => {}} />
    </QueryClientProvider>,
  );
}

const loaded = () => screen.findByText('CB File Name:');
const openRawFileTab = () => fireEvent.click(screen.getByRole('button', { name: 'Raw File' }));
const sifButton = () => screen.getByRole('button', { name: 'Download Original SIF file' }) as HTMLButtonElement;
const ackButton = () => screen.getByRole('button', { name: 'Download CB acknowledgement file' }) as HTMLButtonElement;

const blobOf = (text: string) => new Blob([text]);
const axiosError = (status: number) => Object.assign(new Error(`Request failed with status code ${status}`), { response: { status } });

/** A drawer for a file the CB has answered, on its Raw File tab. */
async function withAck(cbResponse = 'SIFACK', cbFileName = ACK_FILE) {
  api.detail.mockResolvedValue(detail({ cbResponse, cbFileName }));
  renderDrawer();
  await loaded();
  openRawFileTab();
}

/** A drawer for a file still waiting for the CB — no ACK/NAK, so no Raw File tab, only the pending pane. */
async function withoutAck(over: Partial<SifFileDetailResponse> = {}) {
  api.detail.mockResolvedValue(detail({ cbResponse: null, cbFileName: null, currentStatus: 'AwaitingCbAck', ...over }));
  renderDrawer();
  await loaded();
}

beforeEach(() => {
  vi.clearAllMocks();
});

// Explicit: automatic cleanup only runs when vitest globals are enabled.
afterEach(cleanup);

describe('Raw File downloads are wired and independent', () => {
  it('Original SIF: invokes only the Original SIF endpoint, with only the transaction id', async () => {
    api.downloadOriginalSif.mockResolvedValue({ blob: blobOf('SCR,1'), fileName: SIF });
    await withAck();

    fireEvent.click(sifButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledTimes(1));
    expect(api.downloadOriginalSif).toHaveBeenCalledTimes(1);
    expect(api.downloadOriginalSif).toHaveBeenCalledWith('TXN-1');
    expect(api.downloadAckNak).not.toHaveBeenCalled();
  });

  it.each([
    ['ACK', 'SIFACK', ACK_FILE],
    ['NAK', 'SIFNAK', NAK_FILE],
  ])('%s: invokes only the ACK/NAK endpoint, with only the transaction id', async (_kind, cbResponse, cbFileName) => {
    api.downloadAckNak.mockResolvedValue({ blob: blobOf('AHR,ACCEPTED'), fileName: cbFileName });
    await withAck(cbResponse, cbFileName);

    fireEvent.click(ackButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledTimes(1));
    expect(api.downloadAckNak).toHaveBeenCalledTimes(1);
    expect(api.downloadAckNak).toHaveBeenCalledWith('TXN-1');
    expect(api.downloadOriginalSif).not.toHaveBeenCalled();
  });

  it('the two buttons can each be used, one after the other, without affecting each other', async () => {
    api.downloadOriginalSif.mockResolvedValue({ blob: blobOf('SIF'), fileName: SIF });
    api.downloadAckNak.mockResolvedValue({ blob: blobOf('ACK'), fileName: ACK_FILE });
    await withAck();

    fireEvent.click(ackButton());
    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledTimes(1));
    fireEvent.click(sifButton());
    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledTimes(2));

    expect(api.downloadAckNak).toHaveBeenCalledTimes(1);
    expect(api.downloadOriginalSif).toHaveBeenCalledTimes(1);
  });
});

describe('availability', () => {
  it('the Original SIF stays available before ACK/NAK exists, and downloads', async () => {
    api.downloadOriginalSif.mockResolvedValue({ blob: blobOf('SIF'), fileName: SIF });
    await withoutAck();

    // No acknowledgement: the message is pending and there is no Raw File sub-tab...
    expect(screen.getByText(/Pending processing\. No message payload available yet\./)).toBeTruthy();
    expect(screen.queryByRole('button', { name: 'Raw File' })).toBeNull();
    // ...but the original SIF is offered, enabled.
    expect(sifButton().disabled).toBe(false);

    fireEvent.click(sifButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledWith(expect.any(Blob), SIF));
    expect(api.downloadOriginalSif).toHaveBeenCalledWith('TXN-1');
    expect(api.downloadAckNak).not.toHaveBeenCalled();
  });

  it('ACK/NAK is unavailable while there is no ACK/NAK file: disabled, and a click calls nothing', async () => {
    await withoutAck();

    expect(ackButton().disabled).toBe(true);
    fireEvent.click(ackButton());

    expect(api.downloadAckNak).not.toHaveBeenCalled();
    expect(saver.downloadBlob).not.toHaveBeenCalled();
  });

  it('ACK/NAK is unavailable when the response exists but no ACK/NAK file name is stored', async () => {
    await withAck('SIFACK', '');

    expect(ackButton().disabled).toBe(true);
    expect(sifButton().disabled).toBe(false);
    fireEvent.click(ackButton());
    expect(api.downloadAckNak).not.toHaveBeenCalled();
  });
});

describe('missing file and failures', () => {
  it('404 from the Original SIF endpoint shows exactly "File not found"', async () => {
    api.downloadOriginalSif.mockRejectedValue(axiosError(404));
    await withoutAck();

    fireEvent.click(sifButton());

    const alert = await screen.findByRole('alert');
    expect(alert.textContent).toBe('File not found');
    expect(alert.textContent).not.toMatch(/[\\/]/); // no file system path
  });

  it('404 from the Original SIF endpoint also shows it on the Raw File tab, next to that button only', async () => {
    api.downloadOriginalSif.mockRejectedValue(axiosError(404));
    await withAck();

    fireEvent.click(sifButton());

    const alert = await screen.findByRole('alert');
    expect(alert.textContent).toBe('File not found');
    expect(screen.getAllByRole('alert')).toHaveLength(1);
    expect(alert.previousElementSibling?.textContent).toContain('Original SIF file');
  });

  it('404 from the ACK/NAK endpoint shows "File not found" too', async () => {
    api.downloadAckNak.mockRejectedValue(axiosError(404));
    await withAck();

    fireEvent.click(ackButton());

    expect((await screen.findByRole('alert')).textContent).toBe('File not found');
  });

  it('a 404 never falls back to another source', async () => {
    api.downloadOriginalSif.mockRejectedValue(axiosError(404));
    await withAck();

    fireEvent.click(sifButton());
    await screen.findByRole('alert');

    expect(api.downloadAckNak).not.toHaveBeenCalled();
    expect(api.logPayload).not.toHaveBeenCalled();
    expect(saver.downloadBlob).not.toHaveBeenCalled();
  });

  it.each([
    ['a 404', () => axiosError(404)],
    ['a 500', () => axiosError(500)],
    ['a network failure', () => new Error('Network Error')],
  ])('%s saves no file', async (_label, makeError) => {
    api.downloadOriginalSif.mockRejectedValue(makeError());
    await withoutAck();

    fireEvent.click(sifButton());

    await screen.findByRole('alert');
    expect(saver.downloadBlob).not.toHaveBeenCalled();
  });

  it('a server error is not reported as "File not found"', async () => {
    api.downloadOriginalSif.mockRejectedValue(axiosError(500));
    await withoutAck();

    fireEvent.click(sifButton());

    const alert = await screen.findByRole('alert');
    expect(alert.textContent).not.toBe('File not found');
    expect(alert.textContent).toBe('Download failed. Please try again.');
  });

  it('an empty response body is never saved as a file', async () => {
    api.downloadOriginalSif.mockResolvedValue({ blob: new Blob([]), fileName: SIF });
    await withoutAck();

    fireEvent.click(sifButton());

    expect((await screen.findByRole('alert')).textContent).toBe('File not found');
    expect(saver.downloadBlob).not.toHaveBeenCalled();
  });

  it('a later successful download clears the earlier error', async () => {
    api.downloadOriginalSif.mockRejectedValueOnce(axiosError(404)).mockResolvedValueOnce({ blob: blobOf('SIF'), fileName: SIF });
    await withoutAck();

    fireEvent.click(sifButton());
    await screen.findByRole('alert');
    fireEvent.click(sifButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(screen.queryByRole('alert')).toBeNull());
  });
});

describe('file names', () => {
  it('saves the Original SIF under the server-provided name, not the card label', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: null, fileName: `${SIF}.gpg` }));
    api.downloadOriginalSif.mockResolvedValue({ blob: blobOf('SIF'), fileName: SIF });
    renderDrawer();
    await loaded();

    fireEvent.click(sifButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledWith(expect.any(Blob), SIF));
  });

  it.each([
    ['SIFACK', ACK_FILE],
    ['SIFNAK', NAK_FILE],
    ['ACK', '0001234567890260930010011987456378786.ACK'],
  ])('saves the ACK/NAK file under the server-provided name verbatim (%s)', async (cbResponse, serverName) => {
    api.downloadAckNak.mockResolvedValue({ blob: blobOf('AHR,x'), fileName: serverName });
    await withAck(cbResponse, serverName);

    fireEvent.click(ackButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledWith(expect.any(Blob), serverName));
  });

  it('passes the very blob the server returned to the saver, untouched', async () => {
    const blob = blobOf('SCR,0001234567890,2\r\nEDR,E1\r\n');
    api.downloadOriginalSif.mockResolvedValue({ blob, fileName: SIF });
    await withoutAck();

    fireEvent.click(sifButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledTimes(1));
    expect(saver.downloadBlob.mock.calls[0][0]).toBe(blob);
  });

  it('without a server name, falls back to the card label — dropping an encryption wrapper, never saving ciphertext', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: null, fileName: `${SIF}.gpg` }));
    api.downloadOriginalSif.mockResolvedValue({ blob: blobOf('SIF'), fileName: null });
    renderDrawer();
    await loaded();

    fireEvent.click(sifButton());

    await waitFor(() => expect(saver.downloadBlob).toHaveBeenCalledWith(expect.any(Blob), SIF));
  });

  it('the dash placeholder is never used as a download file name', async () => {
    api.detail.mockResolvedValue(detail({ cbResponse: null, fileName: '' }));
    api.downloadOriginalSif.mockResolvedValue({ blob: blobOf('SIF'), fileName: null });
    renderDrawer({ ...ROW, sifFileName: '', fileName: '' });
    await loaded();

    fireEvent.click(sifButton());

    // No server name and no real label: a failure is reported, and nothing is saved as "—".
    expect((await screen.findByRole('alert')).textContent).toBe('Download failed. Please try again.');
    expect(saver.downloadBlob).not.toHaveBeenCalled();
  });

  it.each(['—', '  —  ', ' '])('a server name of %j is not used as a file name', async (serverName) => {
    api.detail.mockResolvedValue(detail({ cbResponse: null, fileName: '' }));
    api.downloadOriginalSif.mockResolvedValue({ blob: blobOf('SIF'), fileName: serverName });
    renderDrawer({ ...ROW, sifFileName: '', fileName: '' });
    await loaded();

    fireEvent.click(sifButton());

    await screen.findByRole('alert');
    expect(saver.downloadBlob).not.toHaveBeenCalledWith(expect.anything(), expect.stringMatching(/^\s*—\s*$/));
    expect(saver.downloadBlob).not.toHaveBeenCalled();
  });

  it('the ACK/NAK card shows the stored name verbatim and the SIF card the original SIF name', async () => {
    await withAck('SIFACK', ACK_FILE);

    expect(screen.getByText('CB acknowledgement file').previousElementSibling?.textContent).toBe(ACK_FILE);
    expect(screen.getByText('Original SIF file').previousElementSibling?.textContent).toBe(SIF);
  });
});

describe('the Integration 360 log download is unchanged', () => {
  it('still saves "<correlationId>-RequestLog.txt" as text/plain, without touching the Raw File downloads', async () => {
    const createObjectURL = vi.fn(() => 'blob:log');
    const revokeObjectURL = vi.fn();
    const originals = { create: URL.createObjectURL, revoke: URL.revokeObjectURL };
    URL.createObjectURL = createObjectURL;
    URL.revokeObjectURL = revokeObjectURL;

    const clicked: string[] = [];
    const click = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(function (this: HTMLAnchorElement) {
      clicked.push(this.download);
    });

    try {
      api.detail.mockResolvedValue(detail({ cbResponse: 'SIFACK', cbFileName: ACK_FILE }));
      api.channelInteractions.mockResolvedValue([
        {
          channel: 'SMS',
          action: 'Notify',
          startDateTime: '2026-09-09T19:52:00',
          endDateTime: '2026-09-09T19:52:01',
          status: '200',
          direction: 'Outgoing',
          correlationId: 'TXN-1',
          operation: 'channel.notify.filestatus',
          retry: 0,
          failureReason: null,
        },
      ]);
      api.logPayload.mockResolvedValue({
        correlationId: 'TXN-1',
        logType: 'RequestLog',
        payload: '{"fileName":"x"}',
        operation: 'channel.notify.filestatus',
        statusCode: '200',
        createdAt: '2026-09-09T19:52:01',
      });
      renderDrawer();
      await loaded();

      fireEvent.click(screen.getByRole('button', { name: 'Integration 360' }));
      fireEvent.click(screen.getByRole('button', { name: 'Channel Interactions' }));
      fireEvent.click((await screen.findAllByRole('button', { name: 'View' }))[0]);
      const download = await screen.findByRole('button', { name: 'Download request log as .txt' });
      await waitFor(() => expect((download as HTMLButtonElement).disabled).toBe(false));

      fireEvent.click(download);

      expect(clicked).toEqual(['TXN-1-RequestLog.txt']);
      const blob = (createObjectURL.mock.calls[0] as unknown as [Blob])[0];
      expect(blob.type).toBe('text/plain');
      expect(api.logPayload).toHaveBeenCalledWith('TXN-1', 'RequestLog', 'channel.notify.filestatus');
      // It is its own code path: neither Raw File endpoint nor the Raw File saver is involved.
      expect(saver.downloadBlob).not.toHaveBeenCalled();
      expect(api.downloadOriginalSif).not.toHaveBeenCalled();
      expect(api.downloadAckNak).not.toHaveBeenCalled();
    } finally {
      click.mockRestore();
      URL.createObjectURL = originals.create;
      URL.revokeObjectURL = originals.revoke;
    }
  });
});
