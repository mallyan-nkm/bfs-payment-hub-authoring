import type { CSSProperties } from 'react';
import { EMPTY_STATUS_INDEX, colorOverrideStyle, toneClasses } from './wpsStatusCatalog';
import type { WpsStatusIndex } from './wpsStatusCatalog';

/**
 * The built-in guess at a pill colour from the status WORD (e.g. REJECTION_NOTIFIED, CB_DISPATCHED, SETTLED). It is the fallback
 * for when the status catalog (platform.RailStatusConfiguration, served by /api/wps/status-catalog) is empty, still loading, or
 * does not know the word — the catalog is what says what a status means; this only guesses.
 * Failure words win over everything else, so REJECTION_NOTIFIED is red even though it "completed".
 */
export function sifStatusHeuristicTone(status: string | null | undefined): string {
  const s = (status || '').toLowerCase();
  if (s.includes('fail') || s.includes('reject') || s.includes('error')) return 'border-red-300 bg-red-50 text-red-700';
  if (s.includes('pending') || s.includes('await') || s.includes('nak')) return 'border-amber-300 bg-amber-50 text-amber-800';
  if (s.includes('success') || s.includes('complete') || s.includes('ack')) return 'border-green-300 bg-green-50 text-green-700';
  return 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]';
}

/** What a status pill is drawn with. */
export interface SifStatusDisplay {
  /** Tailwind border / background / text classes: the catalog tone's, else the heuristic's. */
  tone: string;
  /** The catalog DisplayName; undefined when the catalog does not supply one (the badge then shows its own label for the word). */
  label?: string;
  /** Inline colour override from the catalog's ColorHex (border and text in the colour, translucent background). */
  style?: CSSProperties;
  /** Whether the catalog knew the word. */
  fromCatalog: boolean;
}

/**
 * Resolves a status word to what its pill shows. A word the catalog knows (by code, case-insensitively, or by the semantic key
 * workflow events carry — CB_ACK_RECEIVED, POSTED, REJECTION_NOTIFIED) takes the catalog's DisplayName, its Tone's classes and its
 * optional ColorHex. A tone the entry does not carry (rows older than the column) keeps the heuristic's colour while the label still
 * comes from the catalog. An empty catalog or an unknown word is the heuristic, entirely.
 *
 * @param heuristic The caller's own fallback (the Summary grid and the drawers have always guessed slightly differently).
 */
export function resolveSifStatus(
  status: string | null | undefined,
  index: WpsStatusIndex = EMPTY_STATUS_INDEX,
  heuristic: (status: string) => string = sifStatusHeuristicTone,
): SifStatusDisplay {
  const word = status ?? '';
  const entry = index.find(word);
  if (!entry) return { tone: heuristic(word), fromCatalog: false };

  return {
    tone: toneClasses(entry.tone) ?? heuristic(word),
    label: entry.displayName?.trim() || undefined,
    style: colorOverrideStyle(entry.colorHex),
    fromCatalog: true,
  };
}

/**
 * Pill colour classes for a status. With no catalog it is exactly the substring heuristic (what every caller had before the catalog);
 * with one, a status it knows is coloured by its Tone.
 */
export function sifStatusTone(status: string | null | undefined, index?: WpsStatusIndex): string {
  return resolveSifStatus(status, index, sifStatusHeuristicTone).tone;
}
