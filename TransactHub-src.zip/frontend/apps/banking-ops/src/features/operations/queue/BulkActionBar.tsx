import { Button } from '@paymenthub/ui';

interface BulkActionBarProps {
  count: number;
  onApprove: () => void;
  onReject: () => void;
  onExport: () => void;
  onClear: () => void;
  busy?: boolean;
}

export function BulkActionBar({ count, onApprove, onReject, onExport, onClear, busy }: BulkActionBarProps) {
  if (count === 0) return null;

  return (
    <div className="flex items-center justify-between gap-3 rounded-md border border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-2">
      <span className="text-sm text-[var(--text-primary)]">{count} selected</span>
      <div className="flex items-center gap-2">
        <Button variant="primary" size="sm" onClick={onApprove} disabled={busy}>
          Bulk Approve
        </Button>
        <Button variant="danger" size="sm" onClick={onReject} disabled={busy}>
          Bulk Reject
        </Button>
        <Button variant="ghost" size="sm" onClick={onExport} disabled={busy}>
          Export
        </Button>
        <Button variant="ghost" size="sm" onClick={onClear}>
          Clear
        </Button>
      </div>
    </div>
  );
}
