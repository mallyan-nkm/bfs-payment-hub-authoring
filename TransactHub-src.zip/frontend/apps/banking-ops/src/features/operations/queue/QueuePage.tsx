import { useEffect, useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { RefreshCw } from 'lucide-react';
import {
  Button,
  PaginationBar,
  Paginator,
  useRealtimeChannel,
  cn,
  PageShell,
  PageHeader,
  PageToolbar,
  PageBody,
} from '@paymenthub/ui';
import type { DataTableSort, DateRange, Payment, PaymentRail, PaymentStatus } from '@paymenthub/ui';
import { queueApi } from './api';
import type { QueueListParams } from './types';
import { queueKeys } from './queryKeys';
import { QueueTable } from './QueueTable';
import { QueueFilterPanel } from './QueueFilterPanel';
import { QuickFilterBar } from './QuickFilterBar';
import type { QuickFilterKey } from './QuickFilterBar';
import { BulkActionBar } from './BulkActionBar';
import { TransactionDetail } from './TransactionDetail';
import { RefundRequestModal } from './RefundRequestModal';
import { useOfflineAwareAction, useCurrentUsername, useActiveTenantId } from '../../../shared/hooks/useOfflineAwareAction';

export function QueuePage() {
  const [rail, setRail] = useState<PaymentRail[]>([]);
  const [status, setStatus] = useState<PaymentStatus[]>([]);
  const [dateRange, setDateRange] = useState<DateRange>({});
  const [quickFilters, setQuickFilters] = useState<Set<QuickFilterKey>>(new Set());
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<DataTableSort | undefined>(undefined);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [activePayment, setActivePayment] = useState<Payment | null>(null);
  const [refundTarget, setRefundTarget] = useState<Payment | null>(null);
  const [bulkMessage, setBulkMessage] = useState<string | null>(null);

  const pageSize = 20;
  const queryClient = useQueryClient();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();

  const params: QueueListParams = useMemo(
    () => ({
      page,
      pageSize,
      rail: rail.length ? rail : undefined,
      status: status.length ? status : undefined,
      submittedFrom: dateRange.from,
      submittedTo: dateRange.to,
    }),
    [page, rail, status, dateRange],
  );

  const { data, isFetching, refetch } = useQuery({
    queryKey: queueKeys.list(params),
    queryFn: () => queueApi.list(params).then((r) => r.data),
  });

  const { messages: liveMessages } = useRealtimeChannel<{ id: string }>('queue');

  useEffect(() => {
    if (liveMessages.length > 0) {
      queryClient.invalidateQueries({ queryKey: queueKeys.all });
    }
  }, [liveMessages, queryClient]);

  const allPayments = data?.items ?? [];
  const total = data?.total ?? 0;

  const visiblePayments = useMemo(() => {
    let result = allPayments;
    if (quickFilters.has('pendingMyApproval')) {
      result = result.filter((p) => p.status === 'PENDING_APPROVAL' && p.checkerUserId === username);
    }
    if (quickFilters.has('highValue')) {
      result = result.filter((p) => p.amount > 100_000);
    }
    if (quickFilters.has('failedToday')) {
      const today = new Date().toDateString();
      result = result.filter((p) => p.status === 'FAILED' && new Date(p.submittedAt).toDateString() === today);
    }
    return result;
  }, [allPayments, quickFilters, username]);

  function toggleQuickFilter(key: QuickFilterKey) {
    setQuickFilters((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const bulkApproveMutation = useMutation({
    mutationFn: async () => {
      const ids = Array.from(selectedIds);
      return offlineAwareAction({
        endpoint: '/payments/queue/bulk-approve',
        method: 'POST',
        payload: { ids },
        auditEntry: {
          eventType: 'BULK_APPROVE',
          resourceType: 'Payment',
          resourceId: ids.join(','),
          user: username,
          tenantId,
          details: { ids },
          action: 'BULK_APPROVE',
        },
      });
    },
    onSuccess: (result) => {
      setBulkMessage(result.queued ? 'Queued — will sync when back online' : null);
      setSelectedIds(new Set());
      queryClient.invalidateQueries({ queryKey: queueKeys.all });
    },
  });

  const bulkRejectMutation = useMutation({
    mutationFn: async () => {
      const ids = Array.from(selectedIds);
      return offlineAwareAction({
        endpoint: '/payments/queue/bulk-reject',
        method: 'POST',
        payload: { ids, reason: 'Bulk rejected from queue' },
        auditEntry: {
          eventType: 'BULK_REJECT',
          resourceType: 'Payment',
          resourceId: ids.join(','),
          user: username,
          tenantId,
          details: { ids },
          action: 'BULK_REJECT',
        },
      });
    },
    onSuccess: (result) => {
      setBulkMessage(result.queued ? 'Queued — will sync when back online' : null);
      setSelectedIds(new Set());
      queryClient.invalidateQueries({ queryKey: queueKeys.all });
    },
  });

  function handleExport() {
    const rows = visiblePayments.filter((p) => selectedIds.has(p.id));
    const csv = [
      ['Reference', 'Rail', 'Amount', 'Currency', 'Status', 'Submitted'].join(','),
      ...rows.map((r) => [r.referenceNumber, r.rail, r.amount, r.currency, r.status, r.submittedAt].join(',')),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'queue-export.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  const pag = new Paginator(total, pageSize, page);

  return (
    <PageShell>
      <PageHeader
        title="Payment Queue"
        subtitle={`${total} payment${total !== 1 ? 's' : ''}`}
        actions={
          <Button variant="ghost" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
          </Button>
        }
      />

      <PageToolbar>
        <div className="flex w-full flex-col gap-3">
          <QueueFilterPanel
            rail={rail}
            onRailChange={(v) => {
              setRail(v);
              setPage(1);
            }}
            status={status}
            onStatusChange={(v) => {
              setStatus(v);
              setPage(1);
            }}
            dateRange={dateRange}
            onDateRangeChange={(v) => {
              setDateRange(v);
              setPage(1);
            }}
          />
          <QuickFilterBar active={quickFilters} onToggle={toggleQuickFilter} />
        </div>
      </PageToolbar>

      {selectedIds.size > 0 && (
        <div className="px-6 py-2 shrink-0">
          <BulkActionBar
            count={selectedIds.size}
            onApprove={() => bulkApproveMutation.mutate()}
            onReject={() => bulkRejectMutation.mutate()}
            onExport={handleExport}
            onClear={() => setSelectedIds(new Set())}
            busy={bulkApproveMutation.isPending || bulkRejectMutation.isPending}
          />
        </div>
      )}
      {bulkMessage && <p className="px-6 pb-2 text-sm text-[var(--accent-amber)] shrink-0">{bulkMessage}</p>}

      <PageBody>
        <QueueTable
          data={visiblePayments}
          loading={isFetching}
          sort={sort}
          onSortChange={setSort}
          onRowClick={setActivePayment}
          selectedIds={selectedIds}
          onToggleSelect={toggleSelect}
        />
      </PageBody>

      {total > pageSize && (
        <div className="border-t border-[var(--border)] px-6 py-3 shrink-0">
          <PaginationBar paginator={pag} onPageChange={setPage} />
        </div>
      )}

      <TransactionDetail
        payment={activePayment}
        onOpenChange={(open) => !open && setActivePayment(null)}
        onRefund={() => {
          setRefundTarget(activePayment);
        }}
      />
      <RefundRequestModal payment={refundTarget} onOpenChange={(open) => !open && setRefundTarget(null)} />
    </PageShell>
  );
}
