import { Badge, cn } from '@paymenthub/ui';

export type QuickFilterKey = 'pendingMyApproval' | 'highValue' | 'failedToday';

interface QuickFilter {
  key: QuickFilterKey;
  label: string;
}

const QUICK_FILTERS: QuickFilter[] = [
  { key: 'pendingMyApproval', label: 'Pending my approval' },
  { key: 'highValue', label: 'High value > 100k' },
  { key: 'failedToday', label: 'Failed today' },
];

interface QuickFilterBarProps {
  active: Set<QuickFilterKey>;
  onToggle: (key: QuickFilterKey) => void;
}

export function QuickFilterBar({ active, onToggle }: QuickFilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {QUICK_FILTERS.map((filter) => {
        const isActive = active.has(filter.key);
        return (
          <button key={filter.key} type="button" onClick={() => onToggle(filter.key)}>
            <Badge
              variant={isActive ? 'blue' : 'outline'}
              className={cn('cursor-pointer select-none', isActive && 'ring-1 ring-[var(--accent-blue)]')}
            >
              {filter.label}
            </Badge>
          </button>
        );
      })}
    </div>
  );
}
