import type { QueueListParams } from './types';

export const queueKeys = {
  all: ['queue'] as const,
  list: (params: QueueListParams) => ['queue', params] as const,
};
