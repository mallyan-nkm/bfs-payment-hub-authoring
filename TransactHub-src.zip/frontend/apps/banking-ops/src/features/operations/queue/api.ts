import { bankingApi } from '../../../shared/api/bankingApi';
import type { PaginatedResponse, Payment } from '@paymenthub/ui';
import type { QueueListParams, RefundRequest, TransactionHistoryEntry } from './types';

export const queueApi = {
  list: (params: QueueListParams) =>
    bankingApi.get<PaginatedResponse<Payment>>('/payments/queue', { params }),

  get: (id: string) => bankingApi.get<Payment>(`/payments/queue/${id}`),

  getHistory: (id: string) =>
    bankingApi.get<TransactionHistoryEntry[]>(`/payments/queue/${id}/history`),

  refund: (id: string, body: RefundRequest) =>
    bankingApi.post(`/payments/queue/${id}/refund`, body),

  bulkApprove: (ids: string[]) => bankingApi.post('/payments/queue/bulk-approve', { ids }),

  bulkReject: (ids: string[], reason: string) =>
    bankingApi.post('/payments/queue/bulk-reject', { ids, reason }),
};
