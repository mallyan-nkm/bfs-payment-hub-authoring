import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, Button, Textarea, Input } from '@paymenthub/ui';
import type { Payment } from '@paymenthub/ui';
import { useOfflineAwareAction, useCurrentUsername, useActiveTenantId } from '../../../shared/hooks/useOfflineAwareAction';

interface RefundRequestModalProps {
  payment: Payment | null;
  onOpenChange: (open: boolean) => void;
}

export function RefundRequestModal({ payment, onOpenChange }: RefundRequestModalProps) {
  const [reason, setReason] = useState('');
  const [amount, setAmount] = useState('');
  const [queuedMessage, setQueuedMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();

  const mutation = useMutation({
    mutationFn: async () => {
      if (!payment) throw new Error('No payment selected');
      const refundAmount = Number(amount);
      const result = await offlineAwareAction({
        endpoint: `/payments/queue/${payment.id}/refund`,
        method: 'POST',
        payload: { reason, amount: refundAmount },
        auditEntry: {
          eventType: 'REFUND_REQUESTED',
          resourceType: 'Payment',
          resourceId: payment.id,
          user: username,
          tenantId,
          details: { reason, amount: refundAmount },
          action: 'REFUND_REQUEST',
        },
      });
      return result;
    },
    onSuccess: (result) => {
      if (result.queued) {
        setQueuedMessage('Queued — will sync when back online');
      } else {
        setQueuedMessage(null);
        queryClient.invalidateQueries({ queryKey: ['queue'] });
        handleClose();
      }
    },
  });

  function handleClose() {
    setReason('');
    setAmount('');
    setQueuedMessage(null);
    onOpenChange(false);
  }

  return (
    <Dialog
      open={!!payment}
      onOpenChange={(open) => (open ? undefined : handleClose())}
      title="Request Refund"
      description={payment ? `Reference ${payment.referenceNumber}` : undefined}
      footer={
        <>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => mutation.mutate()}
            loading={mutation.isPending}
            disabled={!reason || !amount}
          >
            Submit
          </Button>
        </>
      }
    >
      <div className="flex flex-col gap-3">
        <Input
          label="Refund amount"
          type="number"
          min={0}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <Textarea
          label="Reason"
          rows={3}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Explain why this refund is being requested…"
        />
        {queuedMessage && <p className="text-sm text-[var(--accent-amber)]">{queuedMessage}</p>}
        {mutation.isError && (
          <p className="text-sm text-[var(--accent-red)]">Failed to submit refund request.</p>
        )}
      </div>
    </Dialog>
  );
}
