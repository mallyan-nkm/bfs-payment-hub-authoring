import type { PaymentRail, PaymentStatus } from '@paymenthub/ui';

export interface QueueListParams {
  page?: number;
  pageSize?: number;
  rail?: PaymentRail[];
  status?: PaymentStatus[];
  submittedFrom?: string;
  submittedTo?: string;
  search?: string;
}

export interface TransactionHistoryEntry {
  id: string;
  timestamp: string;
  status: PaymentStatus;
  actor: string;
  note?: string;
}

export interface RefundRequest {
  reason: string;
  amount: number;
}
