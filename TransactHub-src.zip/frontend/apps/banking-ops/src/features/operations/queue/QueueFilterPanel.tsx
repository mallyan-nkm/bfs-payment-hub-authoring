import { RichSelect, DateRangePicker } from '@paymenthub/ui';
import type { DateRange, PaymentRail, PaymentStatus } from '@paymenthub/ui';
import { useRailAccess } from '../../../shared/auth/rails';

const RAIL_OPTIONS: { label: string; value: PaymentRail }[] = [
  { label: 'UAEFTS', value: 'UAEFTS' },
  { label: 'IPI', value: 'IPI' },
  { label: 'IPP', value: 'IPP' },
  { label: 'WPS', value: 'WPS' },
  { label: 'SWIFT', value: 'SWIFT' },
];

const STATUS_OPTIONS: { label: string; value: PaymentStatus }[] = [
  { label: 'Draft', value: 'DRAFT' },
  { label: 'Pending Approval', value: 'PENDING_APPROVAL' },
  { label: 'Approved', value: 'APPROVED' },
  { label: 'Processing', value: 'PROCESSING' },
  { label: 'Completed', value: 'COMPLETED' },
  { label: 'Rejected', value: 'REJECTED' },
  { label: 'Cancelled', value: 'CANCELLED' },
  { label: 'Failed', value: 'FAILED' },
  { label: 'Reversed', value: 'REVERSED' },
];

interface QueueFilterPanelProps {
  rail: PaymentRail[];
  onRailChange: (rail: PaymentRail[]) => void;
  status: PaymentStatus[];
  onStatusChange: (status: PaymentStatus[]) => void;
  dateRange: DateRange;
  onDateRangeChange: (range: DateRange) => void;
}

export function QueueFilterPanel({
  rail,
  onRailChange,
  status,
  onStatusChange,
  dateRange,
  onDateRangeChange,
}: QueueFilterPanelProps) {
  const { allows: allowsRail } = useRailAccess();
  return (
    <div className="flex flex-wrap items-end gap-3">
      <RichSelect
        label="Rail"
        options={RAIL_OPTIONS.filter((o) => allowsRail(o.value))}
        value={rail}
        onChange={(v) => onRailChange(v as PaymentRail[])}
        placeholder="All rails"
        className="w-48"
      />
      <RichSelect
        label="Status"
        options={STATUS_OPTIONS}
        value={status}
        onChange={(v) => onStatusChange(v as PaymentStatus[])}
        placeholder="All statuses"
        className="w-56"
      />
      <DateRangePicker label="Submitted" value={dateRange} onChange={onDateRangeChange} className="w-72" />
    </div>
  );
}
