import { useQuery } from '@tanstack/react-query';
import { Sheet, StatusBadge, Badge, Timeline, Button, LoadingSpinner, useSessionDateTime } from '@paymenthub/ui';
import type { Payment, TimelineEvent } from '@paymenthub/ui';
import { queueApi } from './api';

interface TransactionDetailProps {
  payment: Payment | null;
  onOpenChange: (open: boolean) => void;
  onRefund: () => void;
}

const SEVERITY_VARIANT: Record<string, TimelineEvent['variant']> = {
  COMPLETED: 'success',
  APPROVED: 'success',
  REJECTED: 'danger',
  FAILED: 'danger',
  CANCELLED: 'warning',
};

export function TransactionDetail({ payment, onOpenChange, onRefund }: TransactionDetailProps) {
  const { formatInstant } = useSessionDateTime();
  const { data: history = [], isLoading } = useQuery({
    queryKey: ['queue-history', payment?.id],
    queryFn: () => queueApi.getHistory(payment!.id).then((r) => r.data),
    enabled: !!payment,
  });

  const events: TimelineEvent[] = history.map((h) => ({
    id: h.id,
    timestamp: h.timestamp,
    title: h.status.replace(/_/g, ' '),
    description: h.note ? `${h.actor} — ${h.note}` : h.actor,
    variant: SEVERITY_VARIANT[h.status] ?? 'default',
  }));

  return (
    <Sheet
      open={!!payment}
      onOpenChange={onOpenChange}
      title={payment ? payment.referenceNumber : 'Transaction'}
      description={payment ? `${payment.rail} payment` : undefined}
    >
      {payment && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <StatusBadge status={payment.status} />
            <Badge variant="outline">{payment.rail}</Badge>
          </div>

          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Amount</dt>
              <dd className="font-medium text-[var(--text-primary)]">
                {payment.amount.toLocaleString()} {payment.currency}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Submitted</dt>
              <dd className="text-[var(--text-secondary)]">{formatInstant(payment.submittedAt)}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Debtor account</dt>
              <dd className="text-[var(--text-secondary)]">{payment.debtorAccount}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Creditor account</dt>
              <dd className="text-[var(--text-secondary)]">{payment.creditorAccount}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Maker</dt>
              <dd className="text-[var(--text-secondary)]">{payment.makerUserId}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Checker</dt>
              <dd className="text-[var(--text-secondary)]">{payment.checkerUserId ?? '—'}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Tenant</dt>
              <dd className="text-[var(--text-secondary)]">{payment.tenantId}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Correlation ID</dt>
              <dd className="font-mono text-xs text-[var(--text-secondary)]">{payment.correlationId}</dd>
            </div>
          </dl>

          <div>
            <h3 className="mb-2 text-sm font-medium text-[var(--text-primary)]">History</h3>
            {isLoading ? (
              <div className="flex justify-center py-6">
                <LoadingSpinner />
              </div>
            ) : (
              <Timeline events={events} emptyMessage="No history recorded yet." />
            )}
          </div>

          <div className="flex justify-end border-t border-[var(--border)] pt-4">
            <Button variant="secondary" size="sm" onClick={onRefund}>
              Request Refund
            </Button>
          </div>
        </div>
      )}
    </Sheet>
  );
}
