import { DataTable, Badge, StatusBadge, Checkbox } from '@paymenthub/ui';
import type { DataTableColumn, DataTableSort, Payment } from '@paymenthub/ui';

interface QueueTableProps {
  data: Payment[];
  loading?: boolean;
  sort?: DataTableSort;
  onSortChange?: (sort: DataTableSort) => void;
  onRowClick: (row: Payment) => void;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
}

export function QueueTable({
  data,
  loading,
  sort,
  onSortChange,
  onRowClick,
  selectedIds,
  onToggleSelect,
}: QueueTableProps) {
  const columns: DataTableColumn<Payment>[] = [
    {
      key: 'select',
      header: '',
      render: (row) => (
        <Checkbox
          checked={selectedIds.has(row.id)}
          onCheckedChange={() => onToggleSelect(row.id)}
        />
      ),
      className: 'w-10',
    },
    { key: 'referenceNumber', header: 'Reference', sortable: true },
    {
      key: 'rail',
      header: 'Rail',
      sortable: true,
      render: (row) => <Badge variant="outline">{row.rail}</Badge>,
    },
    {
      key: 'amount',
      header: 'Amount',
      sortable: true,
      align: 'right',
      render: (row) => `${row.amount.toLocaleString()} ${row.currency}`,
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      render: (row) => <StatusBadge status={row.status} />,
    },
    {
      key: 'submittedAt',
      header: 'Submitted',
      sortable: true,
      kind: 'instant',
    },
    { key: 'makerUserId', header: 'Maker' },
    {
      key: 'checkerUserId',
      header: 'Checker',
      render: (row) => row.checkerUserId ?? '—',
    },
  ];

  return (
    <DataTable<Payment>
      columns={columns}
      data={data}
      rowKey={(row) => row.id}
      onRowClick={onRowClick}
      loading={loading}
      sort={sort}
      onSortChange={onSortChange}
      emptyTitle="No payments in queue"
      emptyMessage="No payments match the current filters."
    />
  );
}
