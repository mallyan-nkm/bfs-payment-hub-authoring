import type { OverrideDraft, Rail, RouteOverride, RuleDraft, RuleHistoryEntry, RoutingRule } from './types';

export const MOCK_RULES: RoutingRule[] = [
  {
    id: 1,
    name: 'High Amount SWIFT Fallback',
    channel: 'Corporate Direct',
    conditions: 'Amount > 1,000,000 AND Currency = USD',
    routeTo: 'SWIFT',
    effective: 'Always',
    createdAt: '2026-08-18T05:25:00.000Z',
    modifiedAt: '2026-08-22T10:05:00.000Z',
    approvedBy: 'OPS-CHECKER-02',
    status: 'Active',
  },
  {
    id: 2,
    name: 'Retail Mobile Priority',
    channel: 'Mobile Banking',
    conditions: 'Amount <= 25,000 AND Purpose = SALARY',
    routeTo: 'IPI',
    effective: 'Weekdays 06:00-22:00',
    createdAt: '2026-08-11T06:11:00.000Z',
    modifiedAt: '2026-08-19T08:45:00.000Z',
    approvedBy: 'OPS-CHECKER-04',
    status: 'Active',
  },
  {
    id: 3,
    name: 'Weekend Bulk Payroll',
    channel: 'File Upload',
    conditions: 'Category = Payroll AND Day IN (SAT,SUN)',
    routeTo: 'WPS',
    effective: 'Sat-Sun Full Day',
    createdAt: '2026-08-02T04:40:00.000Z',
    modifiedAt: '2026-08-15T12:22:00.000Z',
    approvedBy: 'OPS-CHECKER-01',
    status: 'Inactive',
  },
];

export const MOCK_OVERRIDES: RouteOverride[] = [
  {
    id: 1,
    channel: 'Internet Banking',
    routeAllTo: 'UAEFTS',
    period: '28 Aug 2026 09:00 to 28 Aug 2026 17:30',
    reason: 'IPI participant maintenance window',
    status: 'Active',
  },
  {
    id: 2,
    channel: 'Direct Entry',
    routeAllTo: 'SWIFT',
    period: '27 Aug 2026 13:00 to 27 Aug 2026 16:00',
    reason: 'Temporary correspondent route test',
    status: 'Inactive',
  },
];

export const RULE_HISTORY: Record<number, RuleHistoryEntry[]> = {
  1: [
    {
      at: '2026-08-22T10:05:00.000Z',
      actor: 'OPS-CHECKER-02',
      action: 'Rule Updated',
      details: 'Fallback order aligned to SWIFT primary for high-value USD transfers.',
    },
    {
      at: '2026-08-18T05:25:00.000Z',
      actor: 'OPS-MAKER-04',
      action: 'Rule Created',
      details: 'Initial routing rule onboarding for high amount cross-border transactions.',
    },
  ],
  2: [
    {
      at: '2026-08-19T08:45:00.000Z',
      actor: 'OPS-CHECKER-04',
      action: 'Rule Approved',
      details: 'Approved for mobile salary traffic in business hours.',
    },
    {
      at: '2026-08-11T06:11:00.000Z',
      actor: 'OPS-MAKER-09',
      action: 'Rule Created',
      details: 'Priority path to IPI for low-value salary transfers.',
    },
  ],
  3: [
    {
      at: '2026-08-15T12:22:00.000Z',
      actor: 'OPS-CHECKER-01',
      action: 'Rule Deactivated',
      details: 'Weekend payroll route paused pending corridor review.',
    },
    {
      at: '2026-08-02T04:40:00.000Z',
      actor: 'OPS-MAKER-03',
      action: 'Rule Created',
      details: 'Bulk payroll routing behavior seeded for weekend windows.',
    },
  ],
};

export const EMPTY_RULE_DRAFT: RuleDraft = {
  id: null,
  name: '',
  channel: '',
  conditions: '',
  routeTo: 'IPI',
  effective: 'Always',
  approvedBy: 'OPS-CHECKER-01',
  status: 'Active',
};

export const EMPTY_OVERRIDE_DRAFT: OverrideDraft = {
  id: null,
  channel: '',
  routeAllTo: 'IPI',
  period: '',
  reason: '',
  status: 'Active',
};

export const RAILS: Rail[] = ['IPI', 'UAEFTS', 'WPS', 'SWIFT', 'IPP'];

/**
 * Now, as a UTC instant (ISO-8601 with `Z`) — what the API will send. Stored as an instant, never as display text,
 * so the grid and history format it in the session zone at render time and follow a zone switch (UTC date-time
 * design §4, §6.1).
 */
export function nowStamp(): string {
  return new Date().toISOString();
}
