import { AlertTriangle } from 'lucide-react';
import { Button, SmartGrid, cn } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { RailPill } from './RailPill';
import { RAILS } from './mockData';
import type { RouteOverride } from './types';

interface RouteOverridesTableProps {
  overrides: RouteOverride[];
  onModify: (override: RouteOverride) => void;
  onToggleStatus: (id: number) => void;
}

/**
 * Route Overrides grid — same shared `SmartGrid` primitive as `RoutingRulesTable`, over the
 * page's local mock `overrides` array.
 */
export function RouteOverridesTable({ overrides, onModify, onToggleStatus }: RouteOverridesTableProps) {
  const columns: SmartGridColumn<RouteOverride>[] = [
    { key: 'id', label: 'ID', sortKey: 'id', getSortValue: (r) => r.id },
    {
      key: 'channel',
      label: 'Channel',
      filterKey: 'channel',
      sortKey: 'channel',
      render: (r) => <span className="font-medium text-[var(--text-primary)]">{r.channel}</span>,
    },
    {
      key: 'routeAllTo',
      label: 'Route All To',
      filterKey: 'routeAllTo',
      filterType: 'select',
      filterOptions: RAILS,
      sortKey: 'routeAllTo',
      render: (r) => <RailPill rail={r.routeAllTo} />,
    },
    { key: 'period', label: 'Period', filterKey: 'period', sortKey: 'period' },
    { key: 'reason', label: 'Reason', filterKey: 'reason', sortKey: 'reason' },
    {
      key: 'status',
      label: 'Status',
      filterKey: 'status',
      filterType: 'select',
      filterOptions: ['Active', 'Inactive'],
      sortKey: 'status',
      render: (r) => (
        <span
          className={cn(
            'inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase',
            r.status === 'Active'
              ? 'border-green-300 bg-green-50 text-green-700'
              : 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]',
          )}
        >
          {r.status}
        </span>
      ),
    },
    {
      key: 'actions',
      label: 'Actions',
      locked: true,
      render: (r) => (
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => onModify(r)}
            className="btn-tertiary h-38px"
          >
            Modify
          </button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onToggleStatus(r.id)}
            className={cn(
              'text-xs font-semibold h-[38px]',
              r.status === 'Active'
                ? 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100'
                : 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100',
            )}
          >
            {r.status === 'Active' ? 'Deactivate' : 'Activate'}
          </Button>
        </div>
      ),
    },
  ];

  return (
    <SmartGrid
      columns={columns}
      rows={overrides}
      getRowId={(r) => String(r.id)}
      storageKey="route-overrides-columns-v1"
      emptyTitle="No route overrides"
      emptyMessage="No route overrides match the current filters."
      exportFilename="route-overrides"
      banner={
        <div className="flex items-start gap-2 border-b border-[color-mix(in_srgb,var(--warning)_45%,var(--border))] bg-[color-mix(in_srgb,var(--warning)_12%,var(--bg-card))] px-4 py-3">
          <AlertTriangle size={16} className="mt-0.5 text-[var(--warning)]" />
          <p className="text-xs leading-5 text-[var(--text-secondary)]">
            <span className="font-semibold text-[var(--text-primary)]">Temporary Override - Use with caution.</span>{' '}
            When active, all outward messages for the selected channel are routed to the override rail and bypass rule
            matching.
          </p>
        </div>
      }
    />
  );
}
