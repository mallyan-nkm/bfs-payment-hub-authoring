import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRightLeft, Plus } from 'lucide-react';
import { Badge, PageBody, PageShell } from '@paymenthub/ui';
import { EMPTY_OVERRIDE_DRAFT, EMPTY_RULE_DRAFT, MOCK_OVERRIDES, MOCK_RULES, RULE_HISTORY, nowStamp } from './mockData';
import { OverrideFormDialog } from './OverrideFormDialog';
import { RouteOverridesTable } from './RouteOverridesTable';
import { RuleFormDialog } from './RuleFormDialog';
import { RuleHistoryDialog } from './RuleHistoryDialog';
import { RoutingRulesTable } from './RoutingRulesTable';
import type { OverrideDraft, RouteOverride, RuleDraft, RuleHistoryEntry, RoutingRule } from './types';

type RuleValidationErrors = Partial<Record<'name' | 'channel' | 'conditions', string>>;
type OverrideValidationErrors = Partial<Record<'channel' | 'period' | 'reason', string>>;

export function RoutingConfigurationsPage() {
  const navigate = useNavigate();

  const [rules, setRules] = useState<RoutingRule[]>(MOCK_RULES);
  const [overrides, setOverrides] = useState<RouteOverride[]>(MOCK_OVERRIDES);
  const [ruleHistory, setRuleHistory] = useState<Record<number, RuleHistoryEntry[]>>(RULE_HISTORY);
  const [ruleDraft, setRuleDraft] = useState<RuleDraft | null>(null);
  const [overrideDraft, setOverrideDraft] = useState<OverrideDraft | null>(null);
  const [ruleErrors, setRuleErrors] = useState<RuleValidationErrors>({});
  const [overrideErrors, setOverrideErrors] = useState<OverrideValidationErrors>({});
  const [historyRuleId, setHistoryRuleId] = useState<number | null>(null);

  const counts = useMemo(() => {
    const activeRules = rules.filter((r) => r.status === 'Active').length;
    const activeOverrides = overrides.filter((o) => o.status === 'Active').length;
    return {
      totalRules: rules.length,
      activeRules,
      totalOverrides: overrides.length,
      activeOverrides,
    };
  }, [rules, overrides]);

  const activeHistory = historyRuleId ? ruleHistory[historyRuleId] ?? [] : [];

  const isRuleSaveDisabled =
    !ruleDraft ||
    !ruleDraft.name.trim() ||
    !ruleDraft.channel.trim() ||
    !ruleDraft.conditions.trim();

  const isOverrideSaveDisabled =
    !overrideDraft ||
    !overrideDraft.channel.trim() ||
    !overrideDraft.period.trim() ||
    !overrideDraft.reason.trim();

  function appendRuleHistory(ruleId: number, entry: RuleHistoryEntry) {
    setRuleHistory((prev) => ({
      ...prev,
      [ruleId]: [entry, ...(prev[ruleId] ?? [])],
    }));
  }

  function validateRuleDraft(draft: RuleDraft): RuleValidationErrors {
    const errors: RuleValidationErrors = {};
    if (!draft.name.trim()) errors.name = 'Rule Name is required.';
    if (!draft.channel.trim()) errors.channel = 'Channel is required.';
    if (!draft.conditions.trim()) errors.conditions = 'Conditions are required.';
    return errors;
  }

  function validateOverrideDraft(draft: OverrideDraft): OverrideValidationErrors {
    const errors: OverrideValidationErrors = {};
    if (!draft.channel.trim()) errors.channel = 'Channel is required.';
    if (!draft.period.trim()) errors.period = 'Period is required.';
    if (!draft.reason.trim()) errors.reason = 'Reason is required.';
    return errors;
  }

  function handleRuleDraftChange(next: RuleDraft) {
    setRuleDraft(next);
    setRuleErrors({});
  }

  function handleOverrideDraftChange(next: OverrideDraft) {
    setOverrideDraft(next);
    setOverrideErrors({});
  }

  function openNewRule() {
    setRuleErrors({});
    setRuleDraft({ ...EMPTY_RULE_DRAFT });
  }

  function openEditRule(rule: RoutingRule) {
    setRuleErrors({});
    setRuleDraft({
      id: rule.id,
      name: rule.name,
      channel: rule.channel,
      conditions: rule.conditions,
      routeTo: rule.routeTo,
      effective: rule.effective,
      approvedBy: rule.approvedBy,
      status: rule.status,
    });
  }

  function saveRule() {
    if (!ruleDraft) return;
    const validationErrors = validateRuleDraft(ruleDraft);
    if (Object.keys(validationErrors).length > 0) {
      setRuleErrors(validationErrors);
      return;
    }

    if (ruleDraft.id === null) {
      const nextId = rules.length > 0 ? Math.max(...rules.map((r) => r.id)) + 1 : 1;
      const createdAt = nowStamp();
      const created: RoutingRule = {
        id: nextId,
        name: ruleDraft.name.trim(),
        channel: ruleDraft.channel.trim(),
        conditions: ruleDraft.conditions.trim(),
        routeTo: ruleDraft.routeTo,
        effective: ruleDraft.effective.trim() || 'Always',
        createdAt,
        modifiedAt: createdAt,
        approvedBy: ruleDraft.approvedBy.trim() || 'OPS-CHECKER-01',
        status: ruleDraft.status,
      };
      setRules((prev) => [...prev, created]);
      appendRuleHistory(nextId, {
        at: createdAt,
        actor: created.approvedBy,
        action: 'Rule Created',
        details: `Routing rule ${created.name} created for ${created.channel}.`,
      });
    } else {
      const modifiedAt = nowStamp();
      setRules((prev) =>
        prev.map((r) =>
          r.id === ruleDraft.id
            ? {
              ...r,
              name: ruleDraft.name.trim(),
              channel: ruleDraft.channel.trim(),
              conditions: ruleDraft.conditions.trim(),
              routeTo: ruleDraft.routeTo,
              effective: ruleDraft.effective.trim() || 'Always',
              approvedBy: ruleDraft.approvedBy.trim() || r.approvedBy,
              status: ruleDraft.status,
              modifiedAt,
            }
            : r,
        ),
      );
      appendRuleHistory(ruleDraft.id, {
        at: modifiedAt,
        actor: ruleDraft.approvedBy.trim() || 'OPS-CHECKER-01',
        action: 'Rule Updated',
        details: `Routing rule ${ruleDraft.name.trim()} was modified.`,
      });
    }

    setRuleErrors({});
    setRuleDraft(null);
  }

  function toggleRuleStatus(id: number) {
    const targetRule = rules.find((r) => r.id === id);
    if (!targetRule) return;

    const nextStatus = targetRule.status === 'Active' ? 'Inactive' : 'Active';
    const confirmed = window.confirm(
      `Confirm ${nextStatus.toLowerCase()} for rule "${targetRule.name}" (${targetRule.channel})?`,
    );
    if (!confirmed) return;

    const changedAt = nowStamp();
    setRules((prev) =>
      prev.map((r) =>
        r.id === id
          ? {
            ...r,
            status: nextStatus,
            modifiedAt: changedAt,
          }
          : r,
      ),
    );
    appendRuleHistory(id, {
      at: changedAt,
      actor: 'OPS-CHECKER-01',
      action: nextStatus === 'Active' ? 'Rule Activated' : 'Rule Deactivated',
      details: `Status changed to ${nextStatus}.`,
    });
  }

  function openNewOverride() {
    setOverrideErrors({});
    setOverrideDraft({ ...EMPTY_OVERRIDE_DRAFT });
  }

  function openEditOverride(override: RouteOverride) {
    setOverrideErrors({});
    setOverrideDraft({
      id: override.id,
      channel: override.channel,
      routeAllTo: override.routeAllTo,
      period: override.period,
      reason: override.reason,
      status: override.status,
    });
  }

  function saveOverride() {
    if (!overrideDraft) return;
    const validationErrors = validateOverrideDraft(overrideDraft);
    if (Object.keys(validationErrors).length > 0) {
      setOverrideErrors(validationErrors);
      return;
    }

    if (overrideDraft.id === null) {
      const nextId = overrides.length > 0 ? Math.max(...overrides.map((o) => o.id)) + 1 : 1;
      const created: RouteOverride = {
        id: nextId,
        channel: overrideDraft.channel.trim(),
        routeAllTo: overrideDraft.routeAllTo,
        period: overrideDraft.period.trim(),
        reason: overrideDraft.reason.trim(),
        status: overrideDraft.status,
      };
      setOverrides((prev) => [...prev, created]);
    } else {
      setOverrides((prev) =>
        prev.map((o) =>
          o.id === overrideDraft.id
            ? {
              ...o,
              channel: overrideDraft.channel.trim(),
              routeAllTo: overrideDraft.routeAllTo,
              period: overrideDraft.period.trim(),
              reason: overrideDraft.reason.trim(),
              status: overrideDraft.status,
            }
            : o,
        ),
      );
    }

    setOverrideErrors({});
    setOverrideDraft(null);
  }

  function toggleOverrideStatus(id: number) {
    const targetOverride = overrides.find((o) => o.id === id);
    if (!targetOverride) return;

    const nextStatus = targetOverride.status === 'Active' ? 'Inactive' : 'Active';
    const confirmed = window.confirm(
      `Confirm ${nextStatus.toLowerCase()} for override #${targetOverride.id} (${targetOverride.channel})?`,
    );
    if (!confirmed) return;

    setOverrides((prev) =>
      prev.map((o) =>
        o.id === id
          ? {
            ...o,
            status: nextStatus,
          }
          : o,
      ),
    );
  }

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / Admin / Routing Management / '}
              <span className="text-[var(--text-secondary)]">Routing Configurations</span>
            </p>
          </div>

          {/* Title Header & Actions */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                Routing Configurations
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Manage payment routing rules and temporary route overrides
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="common-pill active-pill">IPI - Phase 1</Badge>
              <button
                type="button"
                onClick={openNewOverride}
                className="btn-secondary h-38px inline-flex items-center gap-1.5"
              >
                <ArrowRightLeft size={14} /> New Route Override
              </button>
              <button
                type="button"
                onClick={openNewRule}
                className="btn-primary h-38px inline-flex items-center gap-1.5"
              >
                <Plus size={14} /> New Routing
              </button>
            </div>
          </div>

          {/* KPI Metric Cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div
              className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]"
              style={{ borderTop: '3px solid var(--primary-blue)' }}
            >
              <p className="input-label text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                Total Rules
              </p>
              <p className="mt-1 text-2xl sm:text-3xl font-bold leading-none tabular-nums text-[var(--primary-blue)]">
                {counts.totalRules}
              </p>
            </div>

            <div
              className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]"
              style={{ borderTop: '3px solid #16a34a' }}
            >
              <p className="input-label text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                Active Rules
              </p>
              <p className="mt-1 text-2xl sm:text-3xl font-bold leading-none tabular-nums text-green-600">
                {counts.activeRules}
              </p>
            </div>

            <div
              className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]"
              style={{ borderTop: '3px solid var(--primary-blue)' }}
            >
              <p className="input-label text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                Total Overrides
              </p>
              <p className="mt-1 text-2xl sm:text-3xl font-bold leading-none tabular-nums text-[var(--text-primary)]">
                {counts.totalOverrides}
              </p>
            </div>

            <div
              className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]"
              style={{ borderTop: '3px solid #d97706' }}
            >
              <p className="input-label text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                Active Overrides
              </p>
              <p className="mt-1 text-2xl sm:text-3xl font-bold leading-none tabular-nums text-amber-600">
                {counts.activeOverrides}
              </p>
            </div>
          </div>

          {/* Tables Section */}
          <div className="space-y-4">
            <RoutingRulesTable
              rules={rules}
              onEdit={openEditRule}
              onHistory={setHistoryRuleId}
              onToggleStatus={toggleRuleStatus}
            />

            <RouteOverridesTable
              overrides={overrides}
              onModify={openEditOverride}
              onToggleStatus={toggleOverrideStatus}
            />
          </div>
        </div>
      </PageBody>

      {/* Dialogs / Slide-overs */}
      <RuleFormDialog
        draft={ruleDraft}
        errors={ruleErrors}
        isSaveDisabled={isRuleSaveDisabled}
        onClose={() => setRuleDraft(null)}
        onChange={handleRuleDraftChange}
        onSave={saveRule}
      />

      <OverrideFormDialog
        draft={overrideDraft}
        errors={overrideErrors}
        isSaveDisabled={isOverrideSaveDisabled}
        onClose={() => setOverrideDraft(null)}
        onChange={handleOverrideDraftChange}
        onSave={saveOverride}
      />

      <RuleHistoryDialog
        ruleId={historyRuleId}
        entries={activeHistory}
        onClose={() => setHistoryRuleId(null)}
      />
    </PageShell>
  );
}