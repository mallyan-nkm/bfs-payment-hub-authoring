import type { Rail } from './types';

export function RailPill({ rail }: { rail: Rail }) {
  const tone =
    rail === 'IPI'
      ? 'bg-[var(--accent-dim)] text-[var(--accent)]'
      : rail === 'UAEFTS'
        ? 'bg-[color-mix(in_srgb,var(--success)_18%,transparent)] text-[var(--success)]'
        : rail === 'WPS'
          ? 'bg-[color-mix(in_srgb,var(--warning)_18%,transparent)] text-[var(--warning)]'
          : rail === 'SWIFT'
            ? 'bg-[color-mix(in_srgb,var(--danger)_18%,transparent)] text-[var(--danger)]'
            : 'bg-[color-mix(in_srgb,var(--purple)_18%,transparent)] text-[var(--purple)]';

  return <span className={`inline-flex rounded-md px-2 py-1 text-[11px] font-semibold ${tone}`}>{rail}</span>;
}
