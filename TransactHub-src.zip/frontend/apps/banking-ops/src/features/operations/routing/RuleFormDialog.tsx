import { ChevronDown, X } from 'lucide-react';
import { RAILS } from './mockData';
import type { Rail, RuleDraft, RuleStatus } from './types';

interface RuleFormDialogProps {
  draft: RuleDraft | null;
  errors: Partial<Record<'name' | 'channel' | 'conditions', string>>;
  isSaveDisabled: boolean;
  onClose: () => void;
  onChange: (next: RuleDraft) => void;
  onSave: () => void;
}

export function RuleFormDialog({
  draft,
  errors,
  isSaveDisabled,
  onClose,
  onChange,
  onSave,
}: RuleFormDialogProps) {
  if (!draft) return null;

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={draft.id === null ? 'New Routing Configuration' : 'Modify Routing Configuration'}
      onClick={onClose}
    >
      <div
        className="flex h-full w-full max-w-lg sm:max-w-xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div>
            <h2 className="text-xl font-bold text-[var(--text-primary)]">
              {draft.id === null ? 'New Routing Configuration' : 'Modify Routing Configuration'}
            </h2>
            <p className="mt-1 text-xs text-[var(--text-muted)]">
              Configure payment routing parameters, channel mapping, and execution rules
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Informational Hint Banner */}
        <div className="flex items-center gap-2.5 border-b border-[var(--border)] bg-[#eff6ff] px-6 py-3 text-xs text-[#1e40af]">
          <span className="font-bold">ℹ</span>
          <span>Define routing rule criteria. The rule will be matched against inbound transaction attributes.</span>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 space-y-4 overflow-y-auto p-6">
          <div>
            <label className="input-label mb-1.5 block">
              Rule Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={draft.name}
              placeholder="e.g. High Value Salary Corporate Routing"
              onChange={(e) => onChange({ ...draft, name: e.target.value })}
              className="input-cls h-10 w-full text-xs"
            />
            {errors.name && (
              <p role="alert" className="mt-1 text-xs text-[var(--accent-red)]">
                {errors.name}
              </p>
            )}
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Channel <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={draft.channel}
              placeholder="e.g. NestPayHub, Mobile Banking, API"
              onChange={(e) => onChange({ ...draft, channel: e.target.value })}
              className="input-cls h-10 w-full text-xs"
            />
            {errors.channel && (
              <p role="alert" className="mt-1 text-xs text-[var(--accent-red)]">
                {errors.channel}
              </p>
            )}
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Conditions <span className="text-red-500">*</span>
            </label>
            <textarea
              value={draft.conditions}
              rows={3}
              placeholder="e.g. Amount >= 50000; Currency = AED; Direction = Outward"
              aria-invalid={errors.conditions ? true : undefined}
              aria-describedby={errors.conditions ? 'routing-rule-conditions-error' : undefined}
              onChange={(e) => onChange({ ...draft, conditions: e.target.value })}
              className="input-cls w-full text-xs"
            />
            {errors.conditions && (
              <p id="routing-rule-conditions-error" role="alert" className="mt-1 text-xs text-[var(--accent-red)]">
                {errors.conditions}
              </p>
            )}
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Route To <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <select
                value={draft.routeTo}
                onChange={(e) => onChange({ ...draft, routeTo: e.target.value as Rail })}
                className="input-cls h-10 w-full appearance-none pr-9 text-xs"
              >
                {RAILS.map((rail) => (
                  <option key={rail} value={rail}>
                    {rail}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
            </div>
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Effective Window
            </label>
            <input
              type="text"
              value={draft.effective}
              placeholder="e.g. Always, 24x7, Business Hours"
              onChange={(e) => onChange({ ...draft, effective: e.target.value })}
              className="input-cls h-10 w-full text-xs"
            />
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Approved By
            </label>
            <input
              type="text"
              value={draft.approvedBy}
              placeholder="e.g. OPS-CHECKER-01"
              onChange={(e) => onChange({ ...draft, approvedBy: e.target.value })}
              className="input-cls h-10 w-full text-xs"
            />
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Status <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <select
                value={draft.status}
                onChange={(e) => onChange({ ...draft, status: e.target.value as RuleStatus })}
                className="input-cls h-10 w-full appearance-none pr-9 text-xs"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
              <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="grid grid-cols-2 gap-3 border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <button
            type="button"
            onClick={onSave}
            disabled={isSaveDisabled}
            className="btn-primary large-btn !w-full justify-center !py-2.5 text-sm disabled:cursor-not-allowed disabled:opacity-50"
          >
            Save Rule
          </button>
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary large-btn !w-full justify-center !py-2.5 text-sm"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}