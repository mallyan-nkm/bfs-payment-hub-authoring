import { X } from 'lucide-react';
import { useSessionDateTime } from '@paymenthub/ui';
import type { RuleHistoryEntry } from './types';

interface RuleHistoryDialogProps {
  ruleId: number | null;
  entries: RuleHistoryEntry[];
  onClose: () => void;
}

export function RuleHistoryDialog({ ruleId, entries, onClose }: RuleHistoryDialogProps) {
  const { formatInstant } = useSessionDateTime();
  if (ruleId === null) return null;

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={`Routing Rule History #${ruleId}`}
      onClick={onClose}
    >
      <div
        className="flex h-full w-full max-w-lg sm:max-w-xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div>
            <h2 className="text-xl font-bold text-[var(--text-primary)]">
              Routing Rule History #{ruleId}
            </h2>
            <p className="mt-1 text-xs text-[var(--text-muted)]">
              Audit log and historical timeline of configuration changes
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 space-y-3 overflow-y-auto p-6">
          {entries.length === 0 ? (
            <div className="rounded-xl border border-[var(--border)] p-12 text-center text-xs italic text-[var(--text-muted)]">
              No history is available for this rule yet.
            </div>
          ) : (
            entries.map((entry, idx) => (
              <article
                key={`${entry.at}-${idx}`}
                className="rounded-xl border border-[var(--border)] bg-[var(--bg-secondary)]/30 p-4 shadow-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border)] pb-2.5">
                  <span className="text-sm font-bold text-[var(--text-primary)]">
                    {entry.action}
                  </span>
                  <span className="font-mono text-xs text-[var(--text-muted)]">
                    {formatInstant(entry.at)}
                  </span>
                </div>
                <p className="mt-2 text-xs font-semibold text-[var(--text-secondary)]">
                  Actioned by <span className="text-[var(--primary-blue)] font-bold">{entry.actor}</span>
                </p>
                <p className="mt-1 text-xs text-[var(--text-secondary)] leading-relaxed">
                  {entry.details}
                </p>
              </article>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary large-btn !w-32 justify-center"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}