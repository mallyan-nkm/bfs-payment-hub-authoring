import { SmartGrid } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { cn } from '@paymenthub/ui';
import { RailPill } from './RailPill';
import { RAILS } from './mockData';
import type { RoutingRule } from './types';

interface RoutingRulesTableProps {
  rules: RoutingRule[];
  onEdit: (rule: RoutingRule) => void;
  onHistory: (id: number) => void;
  onToggleStatus: (id: number) => void;
}

/**
 * Routing Rules grid — built on the shared `SmartGrid` primitive with custom card wrapper 
 * and matching report table styling.
 */
export function RoutingRulesTable({ rules, onEdit, onHistory, onToggleStatus }: RoutingRulesTableProps) {
  const columns: SmartGridColumn<RoutingRule>[] = [
    { key: 'id', label: 'ID', sortKey: 'id', getSortValue: (r) => r.id },
    {
      key: 'name',
      label: 'Rule Name',
      filterKey: 'name',
      sortKey: 'name',
      render: (r) => <span className="font-semibold text-[var(--text-primary)]">{r.name}</span>,
    },
    { key: 'channel', label: 'Channel', filterKey: 'channel', sortKey: 'channel' },
    {
      key: 'conditions',
      label: 'Conditions',
      filterKey: 'conditions',
      sortKey: 'conditions',
      render: (r) => <span className="font-mono text-xs">{r.conditions}</span>,
    },
    {
      key: 'routeTo',
      label: 'Route To',
      filterKey: 'routeTo',
      filterType: 'select',
      filterOptions: RAILS,
      sortKey: 'routeTo',
      render: (r) => <RailPill rail={r.routeTo} />,
    },
    { key: 'effective', label: 'Effective', filterKey: 'effective', sortKey: 'effective' },
    // Instants: shown in the session zone, sorted on the instant, filtered on its session-zone day (SmartGrid `kind`).
    { key: 'createdAt', label: 'Created', filterKey: 'createdAt', sortKey: 'createdAt', kind: 'instant' },
    { key: 'modifiedAt', label: 'Last Modified', filterKey: 'modifiedAt', sortKey: 'modifiedAt', kind: 'instant' },
    { key: 'approvedBy', label: 'Approved', filterKey: 'approvedBy', sortKey: 'approvedBy' },
    {
      key: 'status',
      label: 'Status',
      filterKey: 'status',
      filterType: 'select',
      filterOptions: ['Active', 'Inactive'],
      sortKey: 'status',
      render: (r) => (
        <span
          className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase ${
            r.status === 'Active'
              ? 'border-green-300 bg-green-50 text-green-700'
              : 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]'
          }`}
        >
          {r.status}
        </span>
      ),
    },
    {
      key: 'actions',
      label: 'Actions',
      locked: true,
      render: (r) => (
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onEdit(r)}
            className="btn-tertiary h-38px"
            title="Edit"
          >
            <span className="text-[11px] font-semibold">Edit</span>
          </button>
          <button
            type="button"
            onClick={() => onHistory(r.id)}
            className="btn-tertiary h-38px"
            title="History"
          >
            <span className="text-[11px] font-semibold">History</span>
          </button>
          <button
            type="button"
            onClick={() => onToggleStatus(r.id)}
            className={cn(
              'rounded border px-2.5 py-1 text-[11px] font-semibold h-[38px]',
              r.status === 'Active'
                ? 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100'
                : 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100',
            )}
          >
            {r.status === 'Active' ? 'Deactivate' : 'Activate'}
          </button>
        </div>
      ),
    },
  ];

  return (
    <SmartGrid
      columns={columns}
      rows={rules}
      getRowId={(r) => String(r.id)}
      storageKey="routing-rules-columns-v1"
      emptyTitle="No routing rules"
      emptyMessage="No routing rules match the current filters."
      exportFilename="routing-rules"
    />
  );
}