import { ChevronDown, X } from 'lucide-react';
import { RAILS } from './mockData';
import type { OverrideDraft, OverrideStatus, Rail } from './types';

interface OverrideFormDialogProps {
  draft: OverrideDraft | null;
  errors: Partial<Record<'channel' | 'period' | 'reason', string>>;
  isSaveDisabled: boolean;
  onClose: () => void;
  onChange: (next: OverrideDraft) => void;
  onSave: () => void;
}

export function OverrideFormDialog({
  draft,
  errors,
  isSaveDisabled,
  onClose,
  onChange,
  onSave,
}: OverrideFormDialogProps) {
  if (!draft) return null;

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={draft.id === null ? 'New Route Override' : 'Modify Route Override'}
      onClick={onClose}
    >
      <div
        className="flex h-full w-full max-w-lg sm:max-w-xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div>
            <h2 className="text-xl font-bold text-[var(--text-primary)]">
              {draft.id === null ? 'New Route Override' : 'Modify Route Override'}
            </h2>
            <p className="mt-1 text-xs text-[var(--text-muted)]">
              Configure route override parameters, active target rails, and schedule window
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Informational Hint Banner */}
        <div className="flex items-center gap-2.5 border-b border-[var(--border)] bg-[#eff6ff] px-6 py-3 text-xs text-[#1e40af]">
          <span className="font-bold">ℹ</span>
          <span>Temporary route overrides bypass default routing execution logic during the defined period.</span>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 space-y-4 overflow-y-auto p-6">
          <div>
            <label className="input-label mb-1.5 block">
              Channel <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={draft.channel}
              placeholder="e.g. Mobile Banking, NestPayHub"
              onChange={(e) => onChange({ ...draft, channel: e.target.value })}
              className="input-cls h-10 w-full text-xs"
            />
            {errors.channel && (
              <p role="alert" className="mt-1 text-xs text-[var(--accent-red)]">
                {errors.channel}
              </p>
            )}
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Route All To <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <select
                value={draft.routeAllTo}
                onChange={(e) => onChange({ ...draft, routeAllTo: e.target.value as Rail })}
                className="input-cls h-10 w-full appearance-none pr-9 text-xs"
              >
                {RAILS.map((rail) => (
                  <option key={rail} value={rail}>
                    {rail}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
            </div>
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Period <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={draft.period}
              placeholder="e.g. 2026-09-01 to 2026-09-30, Maintenance Window"
              onChange={(e) => onChange({ ...draft, period: e.target.value })}
              className="input-cls h-10 w-full text-xs"
            />
            {errors.period && (
              <p role="alert" className="mt-1 text-xs text-[var(--accent-red)]">
                {errors.period}
              </p>
            )}
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Reason <span className="text-red-500">*</span>
            </label>
            <textarea
              value={draft.reason}
              rows={3}
              placeholder="Provide justification or operational remark for this route override..."
              aria-invalid={errors.reason ? true : undefined}
              aria-describedby={errors.reason ? 'routing-override-reason-error' : undefined}
              onChange={(e) => onChange({ ...draft, reason: e.target.value })}
              className="input-cls w-full text-xs"
            />
            {errors.reason && (
              <p id="routing-override-reason-error" role="alert" className="mt-1 text-xs text-[var(--accent-red)]">
                {errors.reason}
              </p>
            )}
          </div>

          <div>
            <label className="input-label mb-1.5 block">
              Status <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <select
                value={draft.status}
                onChange={(e) => onChange({ ...draft, status: e.target.value as OverrideStatus })}
                className="input-cls h-10 w-full appearance-none pr-9 text-xs"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
              <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-[var(--text-muted)]" />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="grid grid-cols-2 gap-3 border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <button
            type="button"
            onClick={onSave}
            disabled={isSaveDisabled}
            className="btn-primary large-btn !w-full justify-center !py-2.5 text-sm disabled:cursor-not-allowed disabled:opacity-50"
          >
            Save Override
          </button>
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary large-btn !w-full justify-center !py-2.5 text-sm"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}