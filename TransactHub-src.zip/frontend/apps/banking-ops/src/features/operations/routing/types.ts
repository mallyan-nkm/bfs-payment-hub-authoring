export type Rail = 'IPI' | 'UAEFTS' | 'WPS' | 'SWIFT' | 'IPP';
export type RuleStatus = 'Active' | 'Inactive';
export type OverrideStatus = 'Active' | 'Inactive';

export interface RoutingRule {
  id: number;
  name: string;
  channel: string;
  conditions: string;
  routeTo: Rail;
  effective: string;
  /** UTC instant (ISO-8601 with `Z`); formatted in the session zone when shown. */
  createdAt: string;
  /** UTC instant (ISO-8601 with `Z`); formatted in the session zone when shown. */
  modifiedAt: string;
  approvedBy: string;
  status: RuleStatus;
}

export interface RouteOverride {
  id: number;
  channel: string;
  routeAllTo: Rail;
  period: string;
  reason: string;
  status: OverrideStatus;
}

export interface RuleHistoryEntry {
  /** UTC instant (ISO-8601 with `Z`); formatted in the session zone when shown. */
  at: string;
  actor: string;
  action: string;
  details: string;
}

export interface RuleDraft {
  id: number | null;
  name: string;
  channel: string;
  conditions: string;
  routeTo: Rail;
  effective: string;
  approvedBy: string;
  status: RuleStatus;
}

export interface OverrideDraft {
  id: number | null;
  channel: string;
  routeAllTo: Rail;
  period: string;
  reason: string;
  status: OverrideStatus;
}
