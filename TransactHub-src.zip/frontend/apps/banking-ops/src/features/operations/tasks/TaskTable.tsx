import { DataTable, Badge, Checkbox, cn, useSessionDateTime } from '@paymenthub/ui';
import type { DataTableColumn, DataTableSort, BadgeVariant } from '@paymenthub/ui';
import type { Task, TaskPriority, TaskStatus } from './types';

const PRIORITY_VARIANT: Record<TaskPriority, BadgeVariant> = {
  URGENT: 'red',
  HIGH: 'amber',
  NORMAL: 'blue',
  LOW: 'outline',
};

const STATUS_VARIANT: Record<TaskStatus, BadgeVariant> = {
  OPEN: 'amber',
  IN_PROGRESS: 'blue',
  BLOCKED: 'red',
  COMPLETED: 'green',
};

function humanize(value: string): string {
  return value.replace(/_/g, ' ');
}

function slaClass(percent: number): string {
  if (percent >= 100) return 'text-danger';
  if (percent >= 80) return 'text-warning';
  return 'text-text-muted';
}

interface TaskTableProps {
  data: Task[];
  loading?: boolean;
  sort?: DataTableSort;
  onSortChange?: (sort: DataTableSort) => void;
  onRowClick: (row: Task) => void;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  visibleColumns: Set<string>;
}

export function TaskTable({
  data,
  loading,
  sort,
  onSortChange,
  onRowClick,
  selectedIds,
  onToggleSelect,
  visibleColumns,
}: TaskTableProps) {
  const { formatInstant } = useSessionDateTime();
  const allColumns: DataTableColumn<Task>[] = [
    {
      key: 'select',
      header: '',
      className: 'w-10',
      render: (row) => (
        <span onClick={(e) => e.stopPropagation()}>
          <Checkbox
            checked={selectedIds.has(row.id)}
            onCheckedChange={() => onToggleSelect(row.id)}
          />
        </span>
      ),
    },
    {
      key: 'id',
      header: 'Task ID',
      sortable: true,
      render: (row) => <span className="font-mono text-xs text-text-secondary">{row.id}</span>,
    },
    {
      key: 'type',
      header: 'Type',
      sortable: true,
      render: (row) => <Badge variant="outline">{humanize(row.type)}</Badge>,
    },
    {
      key: 'title',
      header: 'Title',
      sortable: true,
      render: (row) => <span className="text-text-primary">{row.title}</span>,
    },
    {
      key: 'priority',
      header: 'Priority',
      sortable: true,
      render: (row) => <Badge variant={PRIORITY_VARIANT[row.priority]}>{humanize(row.priority)}</Badge>,
    },
    {
      key: 'status',
      header: 'Status',
      sortable: true,
      render: (row) => <Badge variant={STATUS_VARIANT[row.status]}>{humanize(row.status)}</Badge>,
    },
    { key: 'assignedBy', header: 'Assigned By', sortable: true },
    {
      key: 'dueDate',
      header: 'Due Date',
      sortable: true,
      render: (row) => formatInstant(row.dueDate, 'date'),
    },
    {
      key: 'slaPercentUsed',
      header: 'SLA',
      sortable: true,
      align: 'right',
      render: (row) => (
        <span className={cn('font-medium', slaClass(row.slaPercentUsed))}>{row.slaPercentUsed}%</span>
      ),
    },
    {
      key: 'linkedEntityType',
      header: 'Linked To',
      render: (row) =>
        row.linkedEntityType ? <Badge variant="cyan">{humanize(row.linkedEntityType)}</Badge> : '—',
    },
    {
      key: 'createdAt',
      header: 'Created',
      sortable: true,
      render: (row) => formatInstant(row.createdAt, 'date'),
    },
  ];

  const columns = allColumns.filter((c) => c.key === 'select' || visibleColumns.has(c.key));

  return (
    <DataTable<Task>
      columns={columns}
      data={data}
      rowKey={(row) => row.id}
      onRowClick={onRowClick}
      loading={loading}
      sort={sort}
      onSortChange={onSortChange}
      emptyTitle="No tasks"
      emptyMessage="You have no tasks matching the current filters. Check back later."
    />
  );
}
