import { bankingApi } from '../../../shared/api/bankingApi';
import type { Task } from './types';
import type {
  TaskBlockRequest,
  TaskBulkActionRequest,
  TaskListParams,
  TaskListResponse,
  TaskReassignRequest,
  TaskSavedFilter,
} from './types';

export const tasksApi = {
  list: (params: TaskListParams) =>
    bankingApi.get<TaskListResponse>('/tasks', { params }),

  get: (id: string) => bankingApi.get<Task>(`/tasks/${id}`),

  start: (id: string) => bankingApi.post<Task>(`/tasks/${id}/start`, {}),

  complete: (id: string) => bankingApi.post<Task>(`/tasks/${id}/complete`, {}),

  block: (id: string, body: TaskBlockRequest) =>
    bankingApi.post<Task>(`/tasks/${id}/block`, body),

  unblock: (id: string) => bankingApi.post<Task>(`/tasks/${id}/unblock`, {}),

  reassign: (id: string, body: TaskReassignRequest) =>
    bankingApi.post<Task>(`/tasks/${id}/reassign`, body),

  bulkAction: (body: TaskBulkActionRequest) =>
    bankingApi.post('/tasks/bulk-action', body),

  savedFilters: () => bankingApi.get<TaskSavedFilter[]>('/tasks/saved-filters'),
};
