import type { TaskListParams } from './types';

export const taskKeys = {
  all: ['tasks'] as const,
  list: (params: TaskListParams) => ['tasks', 'list', params] as const,
  detail: (id: string) => ['tasks', 'detail', id] as const,
  savedFilters: () => ['tasks', 'saved-filters'] as const,
};
