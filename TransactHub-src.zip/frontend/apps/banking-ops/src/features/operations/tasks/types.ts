import type { PaginatedResponse } from '@paymenthub/ui';

export type TaskType =
  | 'INVESTIGATION'
  | 'REVIEW'
  | 'RECONCILIATION'
  | 'FOLLOW_UP'
  | 'CONFIGURATION'
  | 'DOCUMENTATION';

export type TaskStatus = 'OPEN' | 'IN_PROGRESS' | 'BLOCKED' | 'COMPLETED';

export type TaskPriority = 'URGENT' | 'HIGH' | 'NORMAL' | 'LOW';

export type TaskLinkedEntityType = 'EXCEPTION' | 'TRANSACTION' | 'APPROVAL';

/** A single work item assigned to the operator. Mirrors the ops-console TaskItem. */
export interface Task {
  id: string;
  type: TaskType;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  assignedTo: string;
  assignedBy: string;
  linkedEntityType?: TaskLinkedEntityType;
  linkedEntityId?: string;
  dueDate: string;
  slaPercentUsed: number;
  createdAt: string;
  updatedAt: string;
  tags: string[];
}

/** The status tab that is currently active (`all` shows every status). */
export type TaskTab = 'all' | TaskStatus;

/** Server-side aggregation counts keyed by status, used for tab / stat badges. */
export type TaskStatusCounts = Record<TaskStatus, number>;

export interface TaskListResponse extends PaginatedResponse<Task> {
  aggregations?: {
    byStatus: TaskStatusCounts;
  };
}

export type TaskQuickFilterKey =
  | 'overdue'
  | 'dueToday'
  | 'highPriority'
  | 'investigation'
  | 'review';

export interface TaskListParams {
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
  /** Omitted when the active tab is `all`. */
  status?: TaskStatus;
  search?: string;
  type?: TaskType[];
  priority?: TaskPriority[];
  quickFilters?: TaskQuickFilterKey[];
  dueFrom?: string;
  dueTo?: string;
}

export type TaskBulkActionType = 'start' | 'complete' | 'reassign' | 'export';

export interface TaskBulkActionRequest {
  action: TaskBulkActionType;
  ids: string[];
  /** Required when action is `reassign`. */
  assignTo?: string;
  /** Rationale captured for regulated bulk actions. */
  rationale?: string;
}

export interface TaskReassignRequest {
  assignTo: string;
  rationale?: string;
}

export interface TaskBlockRequest {
  reason: string;
}

/** A persisted filter preset the operator can re-apply from the toolbar. */
export interface TaskSavedFilter {
  id: string;
  name: string;
  status?: TaskStatus;
  search?: string;
  type?: TaskType[];
  priority?: TaskPriority[];
  quickFilters?: TaskQuickFilterKey[];
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
}

/** Column visibility descriptor driving the column-toggle control. */
export interface TaskColumnDef {
  key: string;
  label: string;
  defaultVisible: boolean;
}
