import { useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { RefreshCw } from 'lucide-react';
import {
  Button,
  Badge,
  Input,
  RichSelect,
  PaginationBar,
  Paginator,
  Tabs,
  TabsList,
  TabsTrigger,
  useDebounce,
  cn,
  PageShell,
  PageHeader,
  PageToolbar,
  PageBody,
} from '@paymenthub/ui';
import type { DataTableSort, RichSelectOption, BadgeVariant } from '@paymenthub/ui';
import { tasksApi } from './api';
import { taskKeys } from './queryKeys';
import { TaskTable } from './TaskTable';
import { TaskBulkBar } from './TaskBulkBar';
import { TaskDetailSheet } from './TaskDetailSheet';
import type {
  Task,
  TaskBulkActionType,
  TaskColumnDef,
  TaskListParams,
  TaskPriority,
  TaskQuickFilterKey,
  TaskSavedFilter,
  TaskTab,
  TaskType,
} from './types';
import {
  useOfflineAwareAction,
  useCurrentUsername,
  useActiveTenantId,
} from '../../../shared/hooks/useOfflineAwareAction';

const PAGE_SIZE = 25;

const COLUMN_DEFS: TaskColumnDef[] = [
  { key: 'id', label: 'Task ID', defaultVisible: true },
  { key: 'type', label: 'Type', defaultVisible: true },
  { key: 'title', label: 'Title', defaultVisible: true },
  { key: 'priority', label: 'Priority', defaultVisible: true },
  { key: 'status', label: 'Status', defaultVisible: true },
  { key: 'assignedBy', label: 'Assigned By', defaultVisible: true },
  { key: 'dueDate', label: 'Due Date', defaultVisible: true },
  { key: 'slaPercentUsed', label: 'SLA', defaultVisible: true },
  { key: 'linkedEntityType', label: 'Linked To', defaultVisible: true },
  { key: 'createdAt', label: 'Created', defaultVisible: false },
];

const TABS: { key: TaskTab; label: string; badge: BadgeVariant }[] = [
  { key: 'all', label: 'All', badge: 'blue' },
  { key: 'OPEN', label: 'Open', badge: 'amber' },
  { key: 'IN_PROGRESS', label: 'In Progress', badge: 'blue' },
  { key: 'BLOCKED', label: 'Blocked', badge: 'red' },
  { key: 'COMPLETED', label: 'Completed', badge: 'green' },
];

const TYPE_OPTIONS: RichSelectOption[] = [
  { value: 'INVESTIGATION', label: 'Investigation' },
  { value: 'REVIEW', label: 'Review' },
  { value: 'RECONCILIATION', label: 'Reconciliation' },
  { value: 'FOLLOW_UP', label: 'Follow up' },
  { value: 'CONFIGURATION', label: 'Configuration' },
  { value: 'DOCUMENTATION', label: 'Documentation' },
];

const PRIORITY_OPTIONS: RichSelectOption[] = [
  { value: 'URGENT', label: 'Urgent' },
  { value: 'HIGH', label: 'High' },
  { value: 'NORMAL', label: 'Normal' },
  { value: 'LOW', label: 'Low' },
];

const QUICK_FILTERS: { key: TaskQuickFilterKey; label: string }[] = [
  { key: 'overdue', label: 'Overdue' },
  { key: 'dueToday', label: 'Due today' },
  { key: 'highPriority', label: 'High priority' },
  { key: 'investigation', label: 'Investigation' },
  { key: 'review', label: 'Review' },
];

type LifecycleAction = 'START' | 'COMPLETE' | 'BLOCK' | 'UNBLOCK' | 'REASSIGN';

interface LifecycleVars {
  task: Task;
  action: LifecycleAction;
  endpoint: string;
  payload: Record<string, unknown>;
}

interface BulkVars {
  action: Exclude<TaskBulkActionType, 'export'>;
  ids: string[];
  assignTo?: string;
}

export function MyTasksPage() {
  const [activeTab, setActiveTab] = useState<TaskTab>('all');
  const [search, setSearch] = useState('');
  const [quickFilters, setQuickFilters] = useState<Set<TaskQuickFilterKey>>(new Set());
  const [typeFilter, setTypeFilter] = useState<TaskType[]>([]);
  const [priorityFilter, setPriorityFilter] = useState<TaskPriority[]>([]);
  const [savedFilterId, setSavedFilterId] = useState<string>('');
  const [visibleColumns, setVisibleColumns] = useState<Set<string>>(
    () => new Set(COLUMN_DEFS.filter((c) => c.defaultVisible).map((c) => c.key)),
  );
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<DataTableSort | undefined>(undefined);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [bulkMessage, setBulkMessage] = useState<string | null>(null);

  const queryClient = useQueryClient();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();

  const debouncedSearch = useDebounce(search, 300);

  const params: TaskListParams = useMemo(
    () => ({
      page,
      pageSize: PAGE_SIZE,
      sortBy: sort?.key ?? 'dueDate',
      sortDir: sort?.direction ?? 'asc',
      status: activeTab === 'all' ? undefined : activeTab,
      search: debouncedSearch || undefined,
      type: typeFilter.length ? typeFilter : undefined,
      priority: priorityFilter.length ? priorityFilter : undefined,
      quickFilters: quickFilters.size ? Array.from(quickFilters) : undefined,
    }),
    [page, sort, activeTab, debouncedSearch, typeFilter, priorityFilter, quickFilters],
  );

  const { data, isFetching, refetch } = useQuery({
    queryKey: taskKeys.list(params),
    queryFn: () => tasksApi.list(params).then((r) => r.data),
  });

  const { data: savedFilters = [] } = useQuery({
    queryKey: taskKeys.savedFilters(),
    queryFn: () => tasksApi.savedFilters().then((r) => r.data),
  });

  const tasks = data?.items ?? [];
  const total = data?.total ?? 0;
  const counts = data?.aggregations?.byStatus;

  function tabCount(tab: TaskTab): number | undefined {
    if (!counts) return undefined;
    if (tab === 'all') return (Object.values(counts) as number[]).reduce((a, b) => a + b, 0);
    return counts[tab];
  }

  const lifecycleMutation = useMutation({
    mutationFn: ({ task, action, endpoint, payload }: LifecycleVars) =>
      offlineAwareAction({
        endpoint,
        method: 'POST',
        payload,
        auditEntry: {
          eventType: `TASK_${action}`,
          resourceType: 'Task',
          resourceId: task.id,
          user: username,
          tenantId,
          details: { taskId: task.id, ...payload },
          action: `TASK_${action}`,
        },
      }),
    onSuccess: (result) => {
      setBulkMessage(result.queued ? 'Queued — will sync when back online' : null);
      setActiveTask(null);
      queryClient.invalidateQueries({ queryKey: taskKeys.all });
    },
  });

  const bulkMutation = useMutation({
    mutationFn: ({ action, ids, assignTo }: BulkVars) =>
      offlineAwareAction({
        endpoint: '/tasks/bulk-action',
        method: 'POST',
        payload: { action, ids, assignTo },
        auditEntry: {
          eventType: `TASK_BULK_${action.toUpperCase()}`,
          resourceType: 'Task',
          resourceId: ids.join(','),
          user: username,
          tenantId,
          details: { ids, assignTo },
          action: `TASK_BULK_${action.toUpperCase()}`,
        },
      }),
    onSuccess: (result) => {
      setBulkMessage(result.queued ? 'Queued — will sync when back online' : null);
      setSelectedIds(new Set());
      queryClient.invalidateQueries({ queryKey: taskKeys.all });
    },
  });

  const busy = lifecycleMutation.isPending || bulkMutation.isPending;

  function switchTab(tab: TaskTab): void {
    setActiveTab(tab);
    setPage(1);
  }

  function toggleQuickFilter(key: TaskQuickFilterKey): void {
    setQuickFilters((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
    setPage(1);
  }

  function toggleSelect(id: string): void {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function applySavedFilter(id: string): void {
    setSavedFilterId(id);
    const preset: TaskSavedFilter | undefined = savedFilters.find((f) => f.id === id);
    if (!preset) return;
    setActiveTab(preset.status ?? 'all');
    setSearch(preset.search ?? '');
    setTypeFilter(preset.type ?? []);
    setPriorityFilter(preset.priority ?? []);
    setQuickFilters(new Set(preset.quickFilters ?? []));
    if (preset.sortBy) setSort({ key: preset.sortBy, direction: preset.sortDir ?? 'asc' });
    setPage(1);
  }

  function clearFilters(): void {
    setSearch('');
    setTypeFilter([]);
    setPriorityFilter([]);
    setQuickFilters(new Set());
    setSavedFilterId('');
    setActiveTab('all');
    setPage(1);
  }

  function handleExport(): void {
    const rows = tasks.filter((t) => selectedIds.has(t.id));
    const csv = [
      ['Task ID', 'Type', 'Title', 'Priority', 'Status', 'Assigned By', 'Due Date', 'SLA %'].join(','),
      ...rows.map((r) =>
        [r.id, r.type, `"${r.title}"`, r.priority, r.status, r.assignedBy, r.dueDate, r.slaPercentUsed].join(','),
      ),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'my-tasks-export.csv';
    a.click();
    URL.revokeObjectURL(url);
  }

  const hasActiveFilters =
    !!search || typeFilter.length > 0 || priorityFilter.length > 0 || quickFilters.size > 0;

  const pag = new Paginator(total, PAGE_SIZE, page);

  return (
    <PageShell>
      <PageHeader
        title="My Tasks"
        subtitle={
          <span className="mt-1 flex flex-wrap gap-4 text-xs text-text-muted">
            <span>
              Open: <strong className="text-warning">{tabCount('OPEN') ?? '—'}</strong>
            </span>
            <span>
              In Progress: <strong className="text-accent">{tabCount('IN_PROGRESS') ?? '—'}</strong>
            </span>
            <span>
              Blocked: <strong className="text-danger">{tabCount('BLOCKED') ?? '—'}</strong>
            </span>
            <span>
              Completed: <strong className="text-success">{tabCount('COMPLETED') ?? '—'}</strong>
            </span>
          </span>
        }
        actions={
          <Button variant="ghost" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
          </Button>
        }
      />

      {/* Status tabs with server aggregation counts */}
      <div className="shrink-0 border-b border-border-default px-6 pt-3">
        <Tabs value={activeTab} onValueChange={(v) => switchTab(v as TaskTab)}>
          <TabsList>
            {TABS.map((tab) => {
              const count = tabCount(tab.key);
              return (
                <TabsTrigger key={tab.key} value={tab.key}>
                  <span className="flex items-center gap-2">
                    {tab.label}
                    {count != null && (
                      <Badge variant={tab.badge} size="sm">
                        {count}
                      </Badge>
                    )}
                  </span>
                </TabsTrigger>
              );
            })}
          </TabsList>
        </Tabs>
      </div>

      {/* Toolbar: search, quick filters, saved filters, column toggle */}
      <PageToolbar>
        <div className="flex w-full flex-col gap-3">
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-[240px] flex-1">
            <Input
              label="Search"
              placeholder="Search tasks by ID, title, or linked entity…"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
            />
          </div>
          <RichSelect
            label="Type"
            placeholder="All types"
            options={TYPE_OPTIONS}
            value={typeFilter}
            onChange={(v) => {
              setTypeFilter(v as TaskType[]);
              setPage(1);
            }}
            className="w-44"
          />
          <RichSelect
            label="Priority"
            placeholder="All priorities"
            options={PRIORITY_OPTIONS}
            value={priorityFilter}
            onChange={(v) => {
              setPriorityFilter(v as TaskPriority[]);
              setPage(1);
            }}
            className="w-44"
          />
          <RichSelect
            label="Saved filters"
            placeholder="Select preset"
            multiple={false}
            options={savedFilters.map((f) => ({ value: f.id, label: f.name }))}
            value={savedFilterId ? [savedFilterId] : []}
            onChange={(v) => applySavedFilter(v[0] ?? '')}
            className="w-44"
          />
          <RichSelect
            label="Columns"
            placeholder="Columns"
            options={COLUMN_DEFS.map((c) => ({ value: c.key, label: c.label }))}
            value={Array.from(visibleColumns)}
            onChange={(v) => setVisibleColumns(new Set(v))}
            className="w-44"
          />
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              Clear
            </Button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {QUICK_FILTERS.map((filter) => {
            const isActive = quickFilters.has(filter.key);
            return (
              <button key={filter.key} type="button" onClick={() => toggleQuickFilter(filter.key)}>
                <Badge
                  variant={isActive ? 'blue' : 'outline'}
                  className={cn('cursor-pointer select-none', isActive && 'ring-1 ring-accent')}
                >
                  {filter.label}
                </Badge>
              </button>
            );
          })}
        </div>
        </div>
      </PageToolbar>

      {/* Bulk actions */}
      {selectedIds.size > 0 && (
        <div className="shrink-0 px-6 py-2">
          <TaskBulkBar
            count={selectedIds.size}
            busy={busy}
            onStart={() => bulkMutation.mutate({ action: 'start', ids: Array.from(selectedIds) })}
            onComplete={() => bulkMutation.mutate({ action: 'complete', ids: Array.from(selectedIds) })}
            onReassign={(assignTo) =>
              bulkMutation.mutate({ action: 'reassign', ids: Array.from(selectedIds), assignTo })
            }
            onExport={handleExport}
            onClear={() => setSelectedIds(new Set())}
          />
        </div>
      )}
      {bulkMessage && <p className="shrink-0 px-6 pb-2 text-sm text-accent-amber">{bulkMessage}</p>}

      {/* Table */}
      <PageBody>
        <TaskTable
          data={tasks}
          loading={isFetching}
          sort={sort}
          onSortChange={setSort}
          onRowClick={setActiveTask}
          selectedIds={selectedIds}
          onToggleSelect={toggleSelect}
          visibleColumns={visibleColumns}
        />
      </PageBody>

      {total > PAGE_SIZE && (
        <div className="shrink-0 border-t border-border-default px-6 py-3">
          <PaginationBar paginator={pag} onPageChange={setPage} />
        </div>
      )}

      <TaskDetailSheet
        task={activeTask}
        onOpenChange={(open) => !open && setActiveTask(null)}
        busy={busy}
        onStart={(t) =>
          lifecycleMutation.mutate({ task: t, action: 'START', endpoint: `/tasks/${t.id}/start`, payload: {} })
        }
        onComplete={(t) =>
          lifecycleMutation.mutate({
            task: t,
            action: 'COMPLETE',
            endpoint: `/tasks/${t.id}/complete`,
            payload: {},
          })
        }
        onBlock={(t, reason) =>
          lifecycleMutation.mutate({
            task: t,
            action: 'BLOCK',
            endpoint: `/tasks/${t.id}/block`,
            payload: { reason },
          })
        }
        onUnblock={(t) =>
          lifecycleMutation.mutate({
            task: t,
            action: 'UNBLOCK',
            endpoint: `/tasks/${t.id}/unblock`,
            payload: {},
          })
        }
        onReassign={(t, assignTo) =>
          lifecycleMutation.mutate({
            task: t,
            action: 'REASSIGN',
            endpoint: `/tasks/${t.id}/reassign`,
            payload: { assignTo },
          })
        }
      />
    </PageShell>
  );
}
