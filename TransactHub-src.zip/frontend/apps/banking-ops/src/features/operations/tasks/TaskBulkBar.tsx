import { useState } from 'react';
import { Button, Input } from '@paymenthub/ui';

interface TaskBulkBarProps {
  count: number;
  onStart: () => void;
  onComplete: () => void;
  onReassign: (assignTo: string) => void;
  onExport: () => void;
  onClear: () => void;
  busy?: boolean;
}

export function TaskBulkBar({
  count,
  onStart,
  onComplete,
  onReassign,
  onExport,
  onClear,
  busy,
}: TaskBulkBarProps) {
  const [reassignOpen, setReassignOpen] = useState(false);
  const [assignTo, setAssignTo] = useState('');

  if (count === 0) return null;

  return (
    <div className="flex flex-col gap-2 rounded-md border border-border-default bg-bg-secondary px-4 py-2">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span className="text-sm text-text-primary">{count} selected</span>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="primary" size="sm" disabled={busy} onClick={onStart}>
            Start
          </Button>
          <Button variant="primary" size="sm" disabled={busy} onClick={onComplete}>
            Complete
          </Button>
          <Button
            variant="secondary"
            size="sm"
            disabled={busy}
            onClick={() => setReassignOpen((v) => !v)}
          >
            Reassign
          </Button>
          <Button variant="ghost" size="sm" disabled={busy} onClick={onExport}>
            Export
          </Button>
          <Button variant="ghost" size="sm" onClick={onClear}>
            Clear
          </Button>
        </div>
      </div>

      {reassignOpen && (
        <div className="flex items-end gap-2 border-t border-border-default pt-2">
          <div className="flex-1">
            <Input
              label="Reassign selected to"
              placeholder="Operator username"
              value={assignTo}
              onChange={(e) => setAssignTo(e.target.value)}
            />
          </div>
          <Button
            variant="primary"
            size="sm"
            disabled={busy || !assignTo.trim()}
            onClick={() => {
              onReassign(assignTo.trim());
              setAssignTo('');
              setReassignOpen(false);
            }}
          >
            Apply
          </Button>
        </div>
      )}
    </div>
  );
}
