import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sheet, Badge, Button, Input, cn, useSessionDateTime } from '@paymenthub/ui';
import type { BadgeVariant } from '@paymenthub/ui';
import { CheckCircle2, Play, Ban, RotateCcw, UserPlus, ExternalLink } from 'lucide-react';
import type { Task, TaskLinkedEntityType, TaskPriority, TaskStatus } from './types';

const PRIORITY_VARIANT: Record<TaskPriority, BadgeVariant> = {
  URGENT: 'red',
  HIGH: 'amber',
  NORMAL: 'blue',
  LOW: 'outline',
};

const STATUS_VARIANT: Record<TaskStatus, BadgeVariant> = {
  OPEN: 'amber',
  IN_PROGRESS: 'blue',
  BLOCKED: 'red',
  COMPLETED: 'green',
};

const LINKED_ENTITY_LABEL: Record<TaskLinkedEntityType, string> = {
  EXCEPTION: 'Open exception',
  TRANSACTION: 'Open transaction 360',
  APPROVAL: 'Open approval',
};

function humanize(value: string): string {
  return value.replace(/_/g, ' ');
}

interface TaskDetailSheetProps {
  task: Task | null;
  onOpenChange: (open: boolean) => void;
  onStart: (task: Task) => void;
  onComplete: (task: Task) => void;
  onBlock: (task: Task, reason: string) => void;
  onUnblock: (task: Task) => void;
  onReassign: (task: Task, assignTo: string) => void;
  busy?: boolean;
}

export function TaskDetailSheet({
  task,
  onOpenChange,
  onStart,
  onComplete,
  onBlock,
  onUnblock,
  onReassign,
  busy,
}: TaskDetailSheetProps) {
  const navigate = useNavigate();
  const { formatInstant } = useSessionDateTime();
  const [mode, setMode] = useState<'none' | 'block' | 'reassign'>('none');
  const [blockReason, setBlockReason] = useState('');
  const [assignTo, setAssignTo] = useState('');

  // Reset the inline forms whenever a different task is opened.
  useEffect(() => {
    setMode('none');
    setBlockReason('');
    setAssignTo('');
  }, [task?.id]);

  function crossLink(t: Task): void {
    if (!t.linkedEntityType || !t.linkedEntityId) return;
    switch (t.linkedEntityType) {
      case 'EXCEPTION':
        navigate('/exceptions');
        break;
      case 'TRANSACTION':
        navigate(`/operations/transactions/${t.linkedEntityId}/360`);
        break;
      case 'APPROVAL':
        navigate('/operations/approvals');
        break;
    }
  }

  return (
    <Sheet
      open={!!task}
      onOpenChange={onOpenChange}
      title={task ? `Task ${task.id}` : 'Task'}
      description={task ? humanize(task.type) : undefined}
    >
      {task && (
        <div className="flex flex-col gap-4">
          <div>
            <div className="text-sm font-semibold text-text-primary">{task.title}</div>
            <p className="mt-1 text-xs leading-relaxed text-text-muted">{task.description}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Badge variant={STATUS_VARIANT[task.status]}>{humanize(task.status)}</Badge>
            <Badge variant={PRIORITY_VARIANT[task.priority]}>{humanize(task.priority)}</Badge>
            <Badge variant="outline">{humanize(task.type)}</Badge>
          </div>

          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-xs text-text-muted">Assigned by</dt>
              <dd className="text-text-secondary">{task.assignedBy}</dd>
            </div>
            <div>
              <dt className="text-xs text-text-muted">Assigned to</dt>
              <dd className="text-text-secondary">{task.assignedTo}</dd>
            </div>
            <div>
              <dt className="text-xs text-text-muted">Due date</dt>
              <dd className="text-text-secondary">{formatInstant(task.dueDate)}</dd>
            </div>
            <div>
              <dt className="text-xs text-text-muted">SLA used</dt>
              <dd
                className={cn(
                  'font-medium',
                  task.slaPercentUsed >= 100
                    ? 'text-danger'
                    : task.slaPercentUsed >= 80
                      ? 'text-warning'
                      : 'text-text-secondary',
                )}
              >
                {task.slaPercentUsed}%
              </dd>
            </div>
            {task.linkedEntityType && task.linkedEntityId && (
              <div className="col-span-2">
                <dt className="text-xs text-text-muted">Linked to</dt>
                <dd className="font-mono text-xs text-text-secondary">
                  {task.linkedEntityType}: {task.linkedEntityId}
                </dd>
              </div>
            )}
          </dl>

          {task.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {task.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded bg-accent-dim px-2 py-0.5 text-[10px] font-semibold text-accent"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Cross-links to related surfaces */}
          {task.linkedEntityType && task.linkedEntityId && (
            <Button variant="secondary" size="sm" onClick={() => crossLink(task)}>
              <ExternalLink size={14} /> {LINKED_ENTITY_LABEL[task.linkedEntityType]}
            </Button>
          )}

          {/* Inline reason / assignee forms */}
          {mode === 'block' && (
            <div className="flex flex-col gap-2 rounded-md border border-border-default bg-bg-secondary p-3">
              <Input
                label="Reason for blocking"
                placeholder="Why is this task blocked?"
                value={blockReason}
                onChange={(e) => setBlockReason(e.target.value)}
              />
              <div className="flex justify-end gap-2">
                <Button variant="ghost" size="sm" onClick={() => setMode('none')}>
                  Cancel
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  disabled={busy || !blockReason.trim()}
                  onClick={() => onBlock(task, blockReason.trim())}
                >
                  Confirm block
                </Button>
              </div>
            </div>
          )}

          {mode === 'reassign' && (
            <div className="flex flex-col gap-2 rounded-md border border-border-default bg-bg-secondary p-3">
              <Input
                label="Reassign to"
                placeholder="Operator username"
                value={assignTo}
                onChange={(e) => setAssignTo(e.target.value)}
              />
              <div className="flex justify-end gap-2">
                <Button variant="ghost" size="sm" onClick={() => setMode('none')}>
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  disabled={busy || !assignTo.trim()}
                  onClick={() => onReassign(task, assignTo.trim())}
                >
                  Confirm reassign
                </Button>
              </div>
            </div>
          )}

          {/* Lifecycle actions */}
          <div className="flex flex-wrap gap-2 border-t border-border-default pt-4">
            {task.status === 'OPEN' && (
              <Button variant="primary" size="sm" disabled={busy} onClick={() => onStart(task)}>
                <Play size={14} /> Start task
              </Button>
            )}
            {task.status === 'IN_PROGRESS' && (
              <>
                <Button variant="primary" size="sm" disabled={busy} onClick={() => onComplete(task)}>
                  <CheckCircle2 size={14} /> Complete
                </Button>
                <Button variant="secondary" size="sm" disabled={busy} onClick={() => setMode('block')}>
                  <Ban size={14} /> Mark blocked
                </Button>
              </>
            )}
            {task.status === 'BLOCKED' && (
              <Button variant="primary" size="sm" disabled={busy} onClick={() => onUnblock(task)}>
                <RotateCcw size={14} /> Unblock
              </Button>
            )}
            {task.status !== 'COMPLETED' && (
              <Button variant="ghost" size="sm" disabled={busy} onClick={() => setMode('reassign')}>
                <UserPlus size={14} /> Reassign
              </Button>
            )}
          </div>
        </div>
      )}
    </Sheet>
  );
}
