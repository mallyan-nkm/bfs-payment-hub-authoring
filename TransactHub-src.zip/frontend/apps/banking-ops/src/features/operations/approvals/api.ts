import { bankingApi } from '../../../shared/api/bankingApi';
import type { PaginatedResponse, Payment } from '@paymenthub/ui';
import type { ApprovalListParams, EscalationRequest } from './types';

export const approvalsApi = {
  list: (params: ApprovalListParams) =>
    bankingApi.get<PaginatedResponse<Payment>>('/payments/approvals', { params }),

  approve: (id: string, comment?: string) =>
    bankingApi.post(`/payments/approvals/${id}/approve`, { comment }),

  reject: (id: string, reason: string) =>
    bankingApi.post(`/payments/approvals/${id}/reject`, { reason }),

  escalate: (id: string, body: EscalationRequest) =>
    bankingApi.post(`/payments/approvals/${id}/escalate`, body),
};
