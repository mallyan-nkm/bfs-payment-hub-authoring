import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Sheet, StatusBadge, Badge, Button, Textarea, useSessionDateTime } from '@paymenthub/ui';
import type { Payment } from '@paymenthub/ui';
import { useOfflineAwareAction, useCurrentUsername, useActiveTenantId } from '../../../shared/hooks/useOfflineAwareAction';

interface ApprovalDetailProps {
  payment: Payment | null;
  onOpenChange: (open: boolean) => void;
}

export function ApprovalDetail({ payment, onOpenChange }: ApprovalDetailProps) {
  const { formatInstant } = useSessionDateTime();
  const [comment, setComment] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();

  const approveMutation = useMutation({
    mutationFn: async () => {
      if (!payment) throw new Error('No payment selected');
      return offlineAwareAction({
        endpoint: `/payments/approvals/${payment.id}/approve`,
        method: 'POST',
        payload: { comment },
        auditEntry: {
          eventType: 'PAYMENT_APPROVED',
          resourceType: 'Payment',
          resourceId: payment.id,
          user: username,
          tenantId,
          details: { comment },
          action: 'APPROVE',
        },
      });
    },
    onSuccess: (result) => {
      setMessage(result.queued ? 'Queued — will sync when back online' : null);
      queryClient.invalidateQueries({ queryKey: ['approvals'] });
      if (!result.queued) onOpenChange(false);
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async () => {
      if (!payment) throw new Error('No payment selected');
      return offlineAwareAction({
        endpoint: `/payments/approvals/${payment.id}/reject`,
        method: 'POST',
        payload: { reason: comment },
        auditEntry: {
          eventType: 'PAYMENT_REJECTED',
          resourceType: 'Payment',
          resourceId: payment.id,
          user: username,
          tenantId,
          details: { reason: comment },
          action: 'REJECT',
        },
      });
    },
    onSuccess: (result) => {
      setMessage(result.queued ? 'Queued — will sync when back online' : null);
      queryClient.invalidateQueries({ queryKey: ['approvals'] });
      if (!result.queued) onOpenChange(false);
    },
  });

  return (
    <Sheet
      open={!!payment}
      onOpenChange={onOpenChange}
      title={payment ? payment.referenceNumber : 'Approval'}
      description={payment ? `${payment.rail} payment pending approval` : undefined}
    >
      {payment && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <StatusBadge status={payment.status} />
            <Badge variant="outline">{payment.rail}</Badge>
          </div>

          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Amount</dt>
              <dd className="font-medium text-[var(--text-primary)]">
                {payment.amount.toLocaleString()} {payment.currency}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Submitted</dt>
              <dd className="text-[var(--text-secondary)]">{formatInstant(payment.submittedAt)}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Debtor account</dt>
              <dd className="text-[var(--text-secondary)]">{payment.debtorAccount}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Creditor account</dt>
              <dd className="text-[var(--text-secondary)]">{payment.creditorAccount}</dd>
            </div>
            <div>
              <dt className="text-xs text-[var(--text-muted)]">Maker</dt>
              <dd className="text-[var(--text-secondary)]">{payment.makerUserId}</dd>
            </div>
          </dl>

          <Textarea
            label="Comment"
            rows={3}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Optional comment for approval / required reason for rejection…"
          />

          {message && <p className="text-sm text-[var(--accent-amber)]">{message}</p>}

          <div className="flex justify-end gap-2 border-t border-[var(--border)] pt-4">
            <Button
              variant="danger"
              size="sm"
              onClick={() => rejectMutation.mutate()}
              loading={rejectMutation.isPending}
              disabled={!comment}
            >
              Reject
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => approveMutation.mutate()}
              loading={approveMutation.isPending}
            >
              Approve
            </Button>
          </div>
        </div>
      )}
    </Sheet>
  );
}
