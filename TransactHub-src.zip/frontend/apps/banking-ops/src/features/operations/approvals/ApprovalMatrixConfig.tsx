import { Sheet, Switch, Input, Button } from '@paymenthub/ui';
import type { ApprovalMatrix, ApprovalThreshold, PaymentRail } from '@paymenthub/ui';
import { UserRole } from '@paymenthub/ui';
import { useApprovalMatrixStore } from '../../../stores/approvalMatrixStore';

interface ApprovalMatrixConfigProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const RAILS: PaymentRail[] = ['UAEFTS', 'IPI', 'IPP', 'WPS', 'SWIFT'];

function emptyMatrix(rail: PaymentRail): ApprovalMatrix {
  return {
    rail,
    requireDualApproval: false,
    amountThresholds: [{ minAmount: 0, requiredApprovers: 1, requiredRoles: [UserRole.BankingOpsApprover] }],
  };
}

export function ApprovalMatrixConfig({ open, onOpenChange }: ApprovalMatrixConfigProps) {
  const { matrices, setMatrices, updateMatrix } = useApprovalMatrixStore();

  function getMatrix(rail: PaymentRail): ApprovalMatrix {
    return matrices.find((m) => m.rail === rail) ?? emptyMatrix(rail);
  }

  function ensureMatrix(rail: PaymentRail): ApprovalMatrix {
    const existing = matrices.find((m) => m.rail === rail);
    if (existing) return existing;
    const created = emptyMatrix(rail);
    setMatrices([...matrices, created]);
    return created;
  }

  function updateThreshold(rail: PaymentRail, index: number, patch: Partial<ApprovalThreshold>) {
    const matrix = ensureMatrix(rail);
    const thresholds = matrix.amountThresholds.map((t, i) => (i === index ? { ...t, ...patch } : t));
    updateMatrix({ ...matrix, amountThresholds: thresholds });
  }

  function addThreshold(rail: PaymentRail) {
    const matrix = ensureMatrix(rail);
    updateMatrix({
      ...matrix,
      amountThresholds: [
        ...matrix.amountThresholds,
        { minAmount: 0, requiredApprovers: 1, requiredRoles: [UserRole.BankingOpsApprover] },
      ],
    });
  }

  function removeThreshold(rail: PaymentRail, index: number) {
    const matrix = ensureMatrix(rail);
    updateMatrix({
      ...matrix,
      amountThresholds: matrix.amountThresholds.filter((_, i) => i !== index),
    });
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="Approval Matrix" description="Per-rail dual approval and amount thresholds">
      <div className="flex flex-col gap-6">
        {RAILS.map((rail) => {
          const matrix = getMatrix(rail);
          return (
            <div key={rail} className="flex flex-col gap-3 rounded-md border border-[var(--border)] p-3">
              <div className="flex items-center justify-between">
                <span className="font-medium text-[var(--text-primary)]">{rail}</span>
                <Switch
                  label="Require dual approval"
                  checked={matrix.requireDualApproval}
                  onCheckedChange={(checked) => updateMatrix({ ...ensureMatrix(rail), requireDualApproval: checked })}
                />
              </div>

              <div className="flex flex-col gap-2">
                {matrix.amountThresholds.map((threshold, idx) => (
                  <div key={idx} className="flex items-end gap-2">
                    <Input
                      label="Min amount"
                      type="number"
                      size="sm"
                      value={threshold.minAmount}
                      onChange={(e) => updateThreshold(rail, idx, { minAmount: Number(e.target.value) })}
                    />
                    <Input
                      label="Max amount"
                      type="number"
                      size="sm"
                      value={threshold.maxAmount ?? ''}
                      onChange={(e) =>
                        updateThreshold(rail, idx, {
                          maxAmount: e.target.value === '' ? undefined : Number(e.target.value),
                        })
                      }
                    />
                    <Input
                      label="Approvers"
                      type="number"
                      size="sm"
                      min={1}
                      value={threshold.requiredApprovers}
                      onChange={(e) => updateThreshold(rail, idx, { requiredApprovers: Number(e.target.value) })}
                    />
                    <Button variant="ghost" size="sm" onClick={() => removeThreshold(rail, idx)}>
                      Remove
                    </Button>
                  </div>
                ))}
                <Button variant="secondary" size="sm" onClick={() => addThreshold(rail)} className="self-start">
                  Add threshold
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </Sheet>
  );
}
