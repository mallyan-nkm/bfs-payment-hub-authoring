import { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { RefreshCw, Settings, ArrowUpCircle } from 'lucide-react';
import {
  Button,
  DataTable,
  Badge,
  StatusBadge,
  PaginationBar,
  Paginator,
  useRealtimeChannel,
  cn,
  PageShell,
  PageHeader,
  PageBody,
} from '@paymenthub/ui';
import type { DataTableColumn, Payment } from '@paymenthub/ui';
import { approvalsApi } from './api';
import { approvalKeys } from './queryKeys';
import { ApprovalDetail } from './ApprovalDetail';
import { ApprovalMatrixConfig } from './ApprovalMatrixConfig';
import { EscalationModal } from './EscalationModal';

export function ApprovalQueuePage() {
  const [page, setPage] = useState(1);
  const [activePayment, setActivePayment] = useState<Payment | null>(null);
  const [escalateTarget, setEscalateTarget] = useState<Payment | null>(null);
  const [matrixOpen, setMatrixOpen] = useState(false);
  const queryClient = useQueryClient();
  const pageSize = 20;

  const { data, isFetching, refetch } = useQuery({
    queryKey: approvalKeys.list({ page, pageSize }),
    queryFn: () => approvalsApi.list({ page, pageSize }).then((r) => r.data),
  });

  const { messages: liveMessages } = useRealtimeChannel<{ id: string }>('approvals');

  useEffect(() => {
    if (liveMessages.length > 0) {
      queryClient.invalidateQueries({ queryKey: approvalKeys.all });
    }
  }, [liveMessages, queryClient]);

  const pending = (data?.items ?? []).filter((p) => p.status === 'PENDING_APPROVAL');
  const total = data?.total ?? 0;
  const pag = new Paginator(total, pageSize, page);

  const columns: DataTableColumn<Payment>[] = [
    { key: 'referenceNumber', header: 'Reference', sortable: true },
    { key: 'rail', header: 'Rail', render: (row) => <Badge variant="outline">{row.rail}</Badge> },
    {
      key: 'amount',
      header: 'Amount',
      align: 'right',
      render: (row) => `${row.amount.toLocaleString()} ${row.currency}`,
    },
    { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
    {
      key: 'submittedAt',
      header: 'Submitted',
      kind: 'instant',
    },
    { key: 'makerUserId', header: 'Maker' },
    {
      key: 'escalate',
      header: '',
      render: (row) => (
        <Button
          variant="ghost"
          size="sm"
          onClick={(e) => {
            e.stopPropagation();
            setEscalateTarget(row);
          }}
        >
          <ArrowUpCircle size={14} /> Escalate
        </Button>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Approvals"
        subtitle={`${pending.length} pending approval${pending.length !== 1 ? 's' : ''}`}
        actions={
          <>
            <Button variant="secondary" size="sm" onClick={() => setMatrixOpen(true)}>
              <Settings size={14} /> Approval Matrix
            </Button>
            <Button variant="ghost" size="sm" onClick={() => refetch()} disabled={isFetching}>
              <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
            </Button>
          </>
        }
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable<Payment>
            columns={columns}
            data={pending}
            rowKey={(row) => row.id}
            onRowClick={setActivePayment}
            loading={isFetching}
            emptyTitle="No pending approvals"
            emptyMessage="There are no payments waiting for approval right now."
          />
        </div>
      </PageBody>

      {total > pageSize && (
        <div className="border-t border-[var(--border)] px-6 py-3 shrink-0">
          <PaginationBar paginator={pag} onPageChange={setPage} />
        </div>
      )}

      <ApprovalDetail payment={activePayment} onOpenChange={(open) => !open && setActivePayment(null)} />
      <ApprovalMatrixConfig open={matrixOpen} onOpenChange={setMatrixOpen} />
      <EscalationModal payment={escalateTarget} onOpenChange={(open) => !open && setEscalateTarget(null)} />
    </PageShell>
  );
}
