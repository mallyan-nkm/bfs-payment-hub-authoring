import type { ApprovalListParams } from './types';

export const approvalKeys = {
  all: ['approvals'] as const,
  list: (params: ApprovalListParams) => ['approvals', params] as const,
};
