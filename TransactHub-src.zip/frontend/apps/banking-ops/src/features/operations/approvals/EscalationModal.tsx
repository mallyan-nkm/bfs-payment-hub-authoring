import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, Button, Textarea, Select } from '@paymenthub/ui';
import type { Payment } from '@paymenthub/ui';
import { useOfflineAwareAction, useCurrentUsername, useActiveTenantId } from '../../../shared/hooks/useOfflineAwareAction';

interface EscalationModalProps {
  payment: Payment | null;
  onOpenChange: (open: boolean) => void;
}

const ESCALATE_TO_OPTIONS = [
  { label: 'Banking Ops Manager', value: 'BankingOpsManager' },
  { label: 'Compliance Officer', value: 'ComplianceOfficer' },
  { label: 'Risk Officer', value: 'RiskOfficer' },
];

export function EscalationModal({ payment, onOpenChange }: EscalationModalProps) {
  const [reason, setReason] = useState('');
  const [escalateTo, setEscalateTo] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();

  const mutation = useMutation({
    mutationFn: async () => {
      if (!payment) throw new Error('No payment selected');
      return offlineAwareAction({
        endpoint: `/payments/approvals/${payment.id}/escalate`,
        method: 'POST',
        payload: { reason, escalateTo },
        auditEntry: {
          eventType: 'PAYMENT_ESCALATED',
          resourceType: 'Payment',
          resourceId: payment.id,
          user: username,
          tenantId,
          details: { reason, escalateTo },
          action: 'ESCALATE',
        },
      });
    },
    onSuccess: (result) => {
      if (result.queued) {
        setMessage('Queued — will sync when back online');
      } else {
        queryClient.invalidateQueries({ queryKey: ['approvals'] });
        handleClose();
      }
    },
  });

  function handleClose() {
    setReason('');
    setEscalateTo('');
    setMessage(null);
    onOpenChange(false);
  }

  return (
    <Dialog
      open={!!payment}
      onOpenChange={(open) => (open ? undefined : handleClose())}
      title="Escalate Approval"
      description={payment ? `Reference ${payment.referenceNumber}` : undefined}
      footer={
        <>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => mutation.mutate()}
            loading={mutation.isPending}
            disabled={!reason || !escalateTo}
          >
            Escalate
          </Button>
        </>
      }
    >
      <div className="flex flex-col gap-3">
        <Select
          label="Escalate to"
          options={ESCALATE_TO_OPTIONS}
          value={escalateTo}
          onValueChange={setEscalateTo}
          placeholder="Select role"
        />
        <Textarea
          label="Reason"
          rows={3}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Explain why this approval is being escalated…"
        />
        {message && <p className="text-sm text-[var(--accent-amber)]">{message}</p>}
        {mutation.isError && <p className="text-sm text-[var(--accent-red)]">Failed to escalate.</p>}
      </div>
    </Dialog>
  );
}
