export interface ApprovalListParams {
  page?: number;
  pageSize?: number;
}

export interface EscalationRequest {
  reason: string;
  escalateTo: string;
}
