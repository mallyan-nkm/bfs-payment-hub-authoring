import { useMemo, useState } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import type { Payment } from '@paymenthub/ui';
import {
  AlertCircle,
  AlertOctagon,
  ArrowDown,
  ArrowUp,
  BellRing,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  Eye,
  EyeOff,
  GitBranch,
  Landmark,
  RefreshCw,
  Route,
  ShieldCheck,
  SkipForward,
  Undo2,
  Users,
  X,
} from 'lucide-react';
import {
  Badge,
  Card,
  EmptyState,
  KpiCard,
  LoadingSpinner,
  Separator,
  StatusBadge,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  Timeline,
  Tooltip,
  PageShell,
  PageHeader,
  PageBody,
} from '@paymenthub/ui';
import type { BadgeVariant, TimelineEvent, TimelineVariant } from '@paymenthub/ui';
import { sessionCalendarDate, sessionInstant } from '@paymenthub/ui';
import { transactionsApi } from './api';
import type {
  Txn360AuditEntry,
  Txn360Check,
  Txn360Exception,
  Txn360FinancialPosting,
  Txn360GpiEvent,
  Txn360Message,
  Txn360Notification,
  Txn360Party,
  Txn360SettlementEntry,
  Txn360TimelineEvent,
  Txn360View,
  Txn360WorkflowStep,
  WorkflowEngineResult,
} from './types';

// ─── Formatters ────────────────────────────────────────────────────────────────

function formatDuration(ms: number | null | undefined): string {
  if (ms === null || ms === undefined) return '—';
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`;
}

/** The value date is a calendar date: `dd-MM-yyyy`, never converted (INV-02). */
function formatDate(date: string | null | undefined): string {
  return sessionCalendarDate(date);
}

/** An instant in the session zone, `dd-MM-yyyy HH:mm:ss`. */
function formatDateTime(date: string | null | undefined): string {
  return sessionInstant(date);
}

/** The time of an instant in the session zone, `HH:mm:ss`. */
function formatTime(time: string | null | undefined): string {
  return sessionInstant(time, 'time');
}

function formatAmount(amount: number | null | undefined): string {
  return (amount ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatEventType(eventType: string | null | undefined): string {
  return (eventType ?? '')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/EVENT_TYPE_/gi, '')
    .replace(/_/g, ' ')
    .trim();
}

// ─── Workflow-engine fallback mapping (mirrors the Angular component) ───────────

function extractWorkflowState(raw: WorkflowEngineResult['workflowState']): Record<string, string> {
  if (!raw || typeof raw !== 'object') return {};
  const nested = (raw as { state?: Record<string, string> }).state;
  if (nested && typeof nested === 'object') return nested;
  return raw as Record<string, string>;
}

function mapWorkflowSteps(result: WorkflowEngineResult): Txn360WorkflowStep[] {
  const state = extractWorkflowState(result.workflowState);

  const stepIds = new Set<string>();
  for (const key of Object.keys(state)) {
    const match = key.match(/^step_(.+?)_(status|success|result|error|output)$/);
    if (match) stepIds.add(match[1]);
  }

  return Array.from(stepIds).map((stepId) => {
    const rawStatus = state[`step_${stepId}_status`] ?? state[`step_${stepId}_success`] ?? 'UNKNOWN';
    let status = String(rawStatus).toUpperCase();
    if (status === 'TRUE' || status === 'OK') status = 'COMPLETED';
    if (status === 'FALSE') status = 'FAILED';

    return {
      stepId,
      stepName: stepId.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
      stepType: 'PROCESSING',
      status,
      durationMs: null,
      retryCount: 0,
      errorMessage: state[`step_${stepId}_error`] ?? null,
      compensationStatus: null,
    };
  });
}

function buildTimelineFromWorkflow(result: WorkflowEngineResult): Txn360TimelineEvent[] {
  const events: Txn360TimelineEvent[] = [];
  for (const evt of result.temporalHistory ?? []) {
    events.push({
      timestamp: evt.timestamp,
      source: 'WORKFLOW',
      eventType: formatEventType(evt.eventType),
      description: `Event #${evt.eventId ?? ''}`.trim(),
      severity: (evt.eventType ?? '').includes('Failed') ? 'ERROR' : 'INFO',
    });
  }
  return events.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
}

function mapWorkflowResult(result: WorkflowEngineResult, fallbackId: string): Txn360View {
  const p = result.payload ?? {};
  const wf = result.workflow ?? {};
  return {
    transactionId: result.transactionId ?? fallbackId,
    paymentScheme: p.payment_scheme ?? p.scheme ?? '',
    status: wf.status ?? 'UNKNOWN',
    direction: p.direction ?? '',
    amount: p.amount ?? 0,
    currency: p.currency ?? 'AED',
    senderIban: p.sender_iban ?? p.debtor_iban ?? '',
    beneficiaryIban: p.beneficiary_iban ?? p.creditor_iban ?? '',
    initiatedAt: wf.startTime ?? null,
    completedAt: wf.closeTime ?? null,
    processingDurationMs: wf.executionDurationMs ?? null,
    workflowJourney: mapWorkflowSteps(result),
    auditTrail: result.auditTrail ?? [],
    settlementEntries: result.settlements ?? [],
    notifications: result.notifications ?? [],
    exceptions: result.exceptions ?? [],
    timeline: buildTimelineFromWorkflow(result),
    traceId: result.traceId ?? null,
    traceViewUrl: result.traceViewUrl ?? null,
  };
}

/** Build a lightweight Txn360View from the clicked search-list row so the Hero paints instantly. */
function summaryToPlaceholder(p: Payment): Txn360View {
  return {
    transactionId: p.id,
    status: p.status,
    amount: p.amount,
    currency: p.currency,
    paymentScheme: p.rail,
    tenantId: p.tenantId,
    initiatedAt: p.submittedAt,
  };
}

async function fetchTransaction360(id: string): Promise<Txn360View> {
  try {
    const res = await transactionsApi.getTransaction360View(id);
    return res.data;
  } catch (err) {
    // Only fall back to the gateway workflow-engine view on a transport/5xx error.
    // A 4xx means the primary answered authoritatively (e.g. not found), so the
    // fallback would just repeat the failure and add a wasted round-trip.
    const status = (err as { response?: { status?: number } })?.response?.status;
    if (typeof status === 'number' && status < 500) throw err;
    const res = await transactionsApi.getTransaction360(id);
    return mapWorkflowResult(res.data, id);
  }
}

// ─── Small primitives ──────────────────────────────────────────────────────────

function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    void navigator.clipboard.writeText(value).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    });
  };
  return (
    <Tooltip content={copied ? 'Copied' : `Copy ${label}`}>
      <button
        type="button"
        onClick={copy}
        aria-label={`Copy ${label}`}
        className="inline-flex size-6 items-center justify-center rounded border border-border-default text-text-muted transition-colors hover:text-accent-cyan"
      >
        {copied ? <Check size={13} /> : <Copy size={13} />}
      </button>
    </Tooltip>
  );
}

function DirectionBadge({ direction }: { direction: string | null | undefined }) {
  if (!direction) return <span className="text-text-muted">—</span>;
  const outward = direction.toUpperCase() === 'OUTWARD';
  return (
    <span
      className={`inline-flex items-center gap-1 text-sm font-medium ${
        outward ? 'text-accent-amber' : 'text-accent-green'
      }`}
    >
      {outward ? <ArrowUp size={13} /> : <ArrowDown size={13} />}
      {direction}
    </span>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-text-muted">{label}</div>
      <div className="text-sm text-text-primary">{children}</div>
    </div>
  );
}

// ─── Hero ──────────────────────────────────────────────────────────────────────

function Hero({ detail }: { detail: Txn360View }) {
  const status = detail.status ?? 'UNKNOWN';
  const journey = detail.workflowJourney ?? [];
  const executed = journey.filter((s) => (s.status ?? '').toUpperCase() !== 'PENDING').length;
  const slaLabel =
    detail.slaStatus ?? (status.toUpperCase() === 'COMPLETED' ? 'Within SLA' : 'In Progress');
  const riskLabel =
    detail.riskLevel ?? (detail.riskScore !== null && detail.riskScore !== undefined ? `${detail.riskScore}` : '—');

  return (
    <Card className="flex flex-col gap-5 p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wider text-text-muted">
            Transaction
          </div>
          <div className="flex items-center gap-2">
            <span className="break-all font-mono text-base text-accent-cyan">{detail.transactionId}</span>
            <CopyButton value={detail.transactionId} label="Transaction ID" />
          </div>
          <div className="mt-1 text-xs text-text-muted">
            {[detail.paymentScheme, detail.channel ? `via ${detail.channel}` : null].filter(Boolean).join(' · ') ||
              'Payment'}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={status} />
          {detail.traceViewUrl && (
            <a
              href={detail.traceViewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-md border border-border-default px-3 py-1.5 text-xs font-medium text-accent-cyan transition-colors hover:bg-bg-secondary"
            >
              <ExternalLink size={13} /> View Trace
            </a>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        <Field label="Payment Type">
          <Badge variant="blue">{detail.paymentScheme || '—'}</Badge>
        </Field>
        <Field label="Direction">
          <DirectionBadge direction={detail.direction} />
        </Field>
        <Field label="Amount">
          <span className="font-mono text-base font-semibold text-accent-cyan">
            {formatAmount(detail.amount)} <span className="text-xs text-text-muted">{detail.currency}</span>
          </span>
        </Field>
        <Field label="Duration">
          <span className="font-semibold text-accent-green">{formatDuration(detail.processingDurationMs)}</span>
        </Field>
        <Field label="Sender IBAN">
          <span className="font-mono text-xs">{detail.senderIban || '—'}</span>
        </Field>
        <Field label="Beneficiary IBAN">
          <span className="font-mono text-xs">{detail.beneficiaryIban || '—'}</span>
        </Field>
        <Field label="Initiated At">{formatDateTime(detail.initiatedAt)}</Field>
        <Field label="Completed At">{formatDateTime(detail.completedAt)}</Field>
      </div>

      <Separator />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <KpiCard label="SLA" value={slaLabel} />
        <KpiCard label="Risk Score" value={riskLabel} />
        <KpiCard label="Steps" value={`${executed} / ${journey.length}`} subtext="executed / total" />
        <KpiCard label="Tenant" value={detail.tenantId || '—'} />
      </div>
    </Card>
  );
}

// ─── Timeline tab ──────────────────────────────────────────────────────────────

type TimelineSource = 'workflow' | 'audit' | 'settlement' | 'notification' | 'exception';

const TIMELINE_SOURCES: { key: TimelineSource; label: string }[] = [
  { key: 'workflow', label: 'Workflow' },
  { key: 'audit', label: 'Audit' },
  { key: 'settlement', label: 'Settlement' },
  { key: 'notification', label: 'Notification' },
  { key: 'exception', label: 'Exception' },
];

const SOURCE_VARIANT: Record<string, BadgeVariant> = {
  WORKFLOW: 'purple',
  AUDIT: 'cyan',
  SETTLEMENT: 'green',
  NOTIFICATION: 'amber',
  EXCEPTION: 'red',
};

function severityToVariant(severity: string | null | undefined): TimelineVariant {
  switch ((severity ?? '').toUpperCase()) {
    case 'ERROR':
      return 'danger';
    case 'WARNING':
      return 'warning';
    case 'INFO':
      return 'success';
    default:
      return 'default';
  }
}

function TimelineTab({ events, traceViewUrl }: { events: Txn360TimelineEvent[]; traceViewUrl: string | null | undefined }) {
  const [filters, setFilters] = useState<Record<TimelineSource, boolean>>({
    workflow: true,
    audit: true,
    settlement: true,
    notification: true,
    exception: true,
  });

  const filtered = useMemo(
    () =>
      events.filter((e) => {
        const src = (e.source ?? '').toLowerCase() as TimelineSource;
        if (src in filters) return filters[src];
        return true;
      }),
    [events, filters],
  );

  const timelineEvents: TimelineEvent[] = filtered.map((e, idx) => {
    const source = (e.source ?? '').toUpperCase();
    return {
      id: `${e.timestamp}-${idx}`,
      timestamp: e.timestamp,
      title: e.eventType ?? source ?? 'Event',
      description: e.description ?? undefined,
      variant: severityToVariant(e.severity),
      meta: (
        <div className="flex items-center gap-2">
          {source && (
            <Badge variant={SOURCE_VARIANT[source] ?? 'default'} size="sm">
              {source}
            </Badge>
          )}
          {e.spanId && traceViewUrl && (
            <a
              href={traceViewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-xs text-accent-cyan"
            >
              <ExternalLink size={11} /> Span
            </a>
          )}
        </div>
      ),
    };
  });

  return (
    <Card className="p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-text-primary">
          <Clock size={15} /> Unified Timeline
        </h3>
        <div className="flex flex-wrap gap-3">
          {TIMELINE_SOURCES.map((s) => (
            <label key={s.key} className="flex cursor-pointer items-center gap-1.5 text-xs text-text-secondary">
              <input
                type="checkbox"
                checked={filters[s.key]}
                onChange={(e) => setFilters((f) => ({ ...f, [s.key]: e.target.checked }))}
              />
              {s.label}
            </label>
          ))}
        </div>
      </div>
      {timelineEvents.length === 0 ? (
        <EmptyState title="No timeline events" message="No lifecycle events match the current filters." />
      ) : (
        <Timeline events={timelineEvents} />
      )}
    </Card>
  );
}

// ─── Workflow journey tab ──────────────────────────────────────────────────────

const WF_STATUS_VARIANT: Record<string, BadgeVariant> = {
  COMPLETED: 'green',
  EVALUATED: 'blue',
  FAILED: 'red',
  SKIPPED: 'default',
  COMPENSATED: 'purple',
  PENDING: 'default',
  RUNNING: 'cyan',
  IN_PROGRESS: 'cyan',
};

function stepIcon(status: string): React.ReactNode {
  switch (status.toUpperCase()) {
    case 'COMPLETED':
      return <Check size={15} />;
    case 'EVALUATED':
      return <GitBranch size={15} />;
    case 'FAILED':
      return <X size={15} />;
    case 'SKIPPED':
      return <SkipForward size={15} />;
    case 'COMPENSATED':
      return <Undo2 size={15} />;
    default:
      return <Clock size={15} />;
  }
}

function stepRingClass(status: string): string {
  switch (status.toUpperCase()) {
    case 'COMPLETED':
    case 'EVALUATED':
      return 'border-accent-green text-accent-green';
    case 'FAILED':
      return 'border-accent-red text-accent-red';
    case 'COMPENSATED':
      return 'border-accent-purple text-accent-purple';
    case 'RUNNING':
    case 'IN_PROGRESS':
      return 'border-accent-cyan text-accent-cyan';
    case 'PENDING':
      return 'border-dashed border-border-default text-text-muted';
    default:
      return 'border-border-default text-text-muted';
  }
}

type JourneyRow =
  | { kind: 'step'; step: Txn360WorkflowStep; last: boolean }
  | { kind: 'separator'; count: number };

function WorkflowTab({ journey }: { journey: Txn360WorkflowStep[] }) {
  const [showPending, setShowPending] = useState(false);

  const executed = journey.filter((s) => (s.status ?? '').toUpperCase() !== 'PENDING');
  const pending = journey.filter((s) => (s.status ?? '').toUpperCase() === 'PENDING');

  const rows: JourneyRow[] = useMemo(() => {
    const out: JourneyRow[] = [];
    executed.forEach((step, i) => {
      const last = i === executed.length - 1 && pending.length === 0;
      out.push({ kind: 'step', step, last });
    });
    if (pending.length > 0) {
      out.push({ kind: 'separator', count: pending.length });
      if (showPending) {
        pending.forEach((step, i) => out.push({ kind: 'step', step, last: i === pending.length - 1 }));
      }
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [journey, showPending]);

  if (journey.length === 0) {
    return (
      <Card className="p-5">
        <EmptyState title="No workflow steps" message="No workflow step data is available for this transaction." />
      </Card>
    );
  }

  return (
    <Card className="p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-text-primary">
          <Route size={15} /> Workflow Journey
        </h3>
        <div className="flex items-center gap-3">
          <span className="text-xs text-text-muted">
            {executed.length} executed / {journey.length} total steps
          </span>
          {pending.length > 0 && (
            <button
              type="button"
              onClick={() => setShowPending((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-md border border-border-default px-2.5 py-1 text-xs text-text-secondary transition-colors hover:text-text-primary"
            >
              {showPending ? <EyeOff size={13} /> : <Eye size={13} />}
              {showPending ? 'Hide' : 'Show'} pending
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-col">
        {rows.map((row, idx) => {
          if (row.kind === 'separator') {
            return (
              <div key={`sep-${idx}`} className="my-2 ml-[52px] flex items-center gap-3 text-xs italic text-text-muted">
                <div className="h-px flex-1 border-t border-dashed border-border-default" />
                <span>{row.count} steps not reached</span>
                <div className="h-px flex-1 border-t border-dashed border-border-default" />
              </div>
            );
          }
          const { step, last } = row;
          const status = (step.status ?? 'UNKNOWN').toUpperCase();
          return (
            <div key={step.stepId} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div
                  className={`flex size-9 shrink-0 items-center justify-center rounded-full border-2 bg-bg-secondary ${stepRingClass(
                    status,
                  )}`}
                >
                  {stepIcon(status)}
                </div>
                {!last && <div className="my-1 w-0.5 flex-1 bg-border-default" style={{ minHeight: 20 }} />}
              </div>
              <div className="flex-1 pb-5">
                <div className="mb-1.5 flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-text-primary">{step.stepName || step.stepId}</span>
                  {step.stepType && step.stepType !== 'Activity' && step.stepType !== 'PROCESSING' && (
                    <Badge variant="purple" size="sm">
                      {step.stepType}
                    </Badge>
                  )}
                  {step.durationMs !== null && step.durationMs !== undefined && (
                    <Badge variant="cyan" size="sm">
                      {formatDuration(step.durationMs)}
                    </Badge>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant={WF_STATUS_VARIANT[status] ?? 'default'} size="sm">
                    {status}
                  </Badge>
                  {step.compensationStatus && step.compensationStatus !== step.status && (
                    <span className="font-mono text-[11px] text-accent-cyan">{step.compensationStatus}</span>
                  )}
                  {step.retryCount !== null && step.retryCount !== undefined && step.retryCount > 0 && (
                    <span className="inline-flex items-center gap-1 text-[11px] text-accent-amber">
                      <RefreshCw size={11} /> {step.retryCount} retries
                    </span>
                  )}
                </div>
                {step.errorMessage && (
                  <div className="mt-2 flex items-start gap-2 rounded-md border-l-2 border-accent-red bg-bg-secondary px-3 py-2 text-xs text-accent-red">
                    <AlertCircle size={13} className="mt-0.5 shrink-0" />
                    <span>{step.errorMessage}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ─── Simple collection tabs ────────────────────────────────────────────────────

function SectionCard({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <Card className="p-5">
      <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-text-primary">
        {icon} {title}
      </h3>
      {children}
    </Card>
  );
}

function AuditTab({ rows }: { rows: Txn360AuditEntry[] }) {
  return (
    <SectionCard icon={<ShieldCheck size={15} />} title="Audit Trail">
      {rows.length === 0 ? (
        <EmptyState title="No audit events" message="No audit events were recorded for this transaction." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-border-default text-[10px] uppercase tracking-wider text-text-muted">
                <th className="px-3 py-2">Timestamp</th>
                <th className="px-3 py-2">Event Type</th>
                <th className="px-3 py-2">Source</th>
                <th className="px-3 py-2">Action</th>
                <th className="px-3 py-2">User</th>
                <th className="px-3 py-2">Details</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((a, i) => (
                <tr key={i} className="border-b border-border-default">
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-text-muted">{formatTime(a.timestamp)}</td>
                  <td className="px-3 py-2">
                    <Badge variant="cyan" size="sm">
                      {a.eventType ?? '—'}
                    </Badge>
                  </td>
                  <td className="px-3 py-2 font-mono">{a.eventSource ?? '—'}</td>
                  <td className="px-3 py-2 text-text-secondary">{a.action ?? '—'}</td>
                  <td className="px-3 py-2 text-text-secondary">{a.userId || '—'}</td>
                  <td className="max-w-[200px] truncate px-3 py-2 text-text-secondary">{a.newValue || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </SectionCard>
  );
}

function SettlementTab({ rows }: { rows: Txn360SettlementEntry[] }) {
  return (
    <SectionCard icon={<Landmark size={15} />} title="Settlement Entries">
      {rows.length === 0 ? (
        <EmptyState title="No settlement entries" message="No settlement entries exist for this transaction." />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((s, i) => {
            const debit = (s.entryType ?? '').toUpperCase() === 'DEBIT';
            return (
              <div
                key={i}
                className={`rounded-lg border border-border-default bg-bg-secondary p-4 border-l-4 ${
                  debit ? 'border-l-accent-red' : 'border-l-accent-green'
                }`}
              >
                <div
                  className={`mb-1 flex items-center gap-1.5 text-xs font-bold uppercase ${
                    debit ? 'text-accent-red' : 'text-accent-green'
                  }`}
                >
                  {debit ? <ArrowUp size={13} /> : <ArrowDown size={13} />}
                  {s.entryType ?? '—'}
                </div>
                <div className="mb-2 font-mono text-lg font-bold text-text-primary">
                  {formatAmount(s.amount)} {s.currency}
                </div>
                <div className="flex flex-col gap-0.5 text-[11px] text-text-muted">
                  <span>ID: {s.settlementId ?? '—'}</span>
                  <span>
                    Status: <strong className="text-text-secondary">{s.status ?? '—'}</strong>
                  </span>
                  {s.valueDate && <span>Value Date: {formatDate(s.valueDate)}</span>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </SectionCard>
  );
}

function NotificationsTab({ rows }: { rows: Txn360Notification[] }) {
  return (
    <SectionCard icon={<BellRing size={15} />} title="Notifications">
      {rows.length === 0 ? (
        <EmptyState title="No notifications" message="No notifications were sent for this transaction." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-border-default text-[10px] uppercase tracking-wider text-text-muted">
                <th className="px-3 py-2">Type</th>
                <th className="px-3 py-2">Recipient</th>
                <th className="px-3 py-2">Template</th>
                <th className="px-3 py-2">Status</th>
                <th className="px-3 py-2">Sent At</th>
                <th className="px-3 py-2">Retries</th>
                <th className="px-3 py-2">Failure</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((n, i) => (
                <tr key={i} className="border-b border-border-default">
                  <td className="px-3 py-2">
                    <Badge variant="cyan" size="sm">
                      {n.notificationType ?? '—'}
                    </Badge>
                  </td>
                  <td className="px-3 py-2 font-mono">{n.recipient ?? '—'}</td>
                  <td className="px-3 py-2 text-text-secondary">{n.templateKey || '—'}</td>
                  <td className="px-3 py-2">
                    <StatusBadge status={n.status ?? 'UNKNOWN'} />
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-text-muted">{formatTime(n.sentAt)}</td>
                  <td className="px-3 py-2 text-text-secondary">{n.retryCount ?? 0}</td>
                  <td className="max-w-[180px] truncate px-3 py-2 text-text-secondary">{n.failureReason || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </SectionCard>
  );
}

function ExceptionsTab({ rows }: { rows: Txn360Exception[] }) {
  return (
    <SectionCard icon={<AlertOctagon size={15} />} title="Exceptions">
      {rows.length === 0 ? (
        <EmptyState
          icon={<CheckCircle2 className="size-6 text-accent-green" />}
          title="No exceptions"
          message="Transaction processed cleanly — no exceptions were raised."
        />
      ) : (
        <div className="flex flex-col gap-3">
          {rows.map((ex, i) => (
            <div key={i} className="rounded-lg border border-accent-red/40 bg-bg-secondary p-4">
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="text-sm font-semibold text-accent-red">{ex.exceptionType ?? 'Exception'}</span>
                <Badge variant={(ex.status ?? '').toUpperCase() === 'RESOLVED' ? 'green' : 'red'} size="sm">
                  {ex.status ?? '—'}
                </Badge>
              </div>
              <div className="flex flex-wrap gap-4 text-xs text-text-muted">
                <span className="inline-flex items-center gap-1">
                  <Clock size={12} /> {formatTime(ex.raisedAt)}
                </span>
                {ex.assignedTo && (
                  <span className="inline-flex items-center gap-1">
                    <Users size={12} /> {ex.assignedTo}
                  </span>
                )}
              </div>
              {ex.resolution && (
                <div className="mt-2 flex items-center gap-1.5 border-t border-border-default pt-2 text-xs text-accent-green">
                  <CheckCircle2 size={13} /> {ex.resolution}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </SectionCard>
  );
}

function GpiTab({ rows }: { rows: Txn360GpiEvent[] }) {
  return (
    <SectionCard icon={<Route size={15} />} title="GPI Tracker">
      {rows.length === 0 ? (
        <EmptyState title="No GPI tracking" message="No SWIFT GPI tracking data is available for this transaction." />
      ) : (
        <Timeline
          events={rows.map((g, i) => ({
            id: `gpi-${i}`,
            timestamp: g.timestamp ?? new Date().toISOString(),
            title: g.status ?? 'GPI event',
            description: [g.agent, g.detail].filter(Boolean).join(' · ') || undefined,
            variant: 'default' as TimelineVariant,
            meta:
              g.amount !== null && g.amount !== undefined ? (
                <span className="font-mono text-xs text-text-secondary">
                  {formatAmount(g.amount)} {g.currency}
                </span>
              ) : undefined,
          }))}
        />
      )}
    </SectionCard>
  );
}

function PartiesTab({ rows }: { rows: Txn360Party[] }) {
  return (
    <SectionCard icon={<Users size={15} />} title="Parties">
      {rows.length === 0 ? (
        <EmptyState title="No party data" message="No party information is available for this transaction." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {rows.map((p, i) => (
            <div
              key={i}
              className={`rounded-lg border bg-bg-secondary p-4 ${
                p.verified ? 'border-accent-green/40' : 'border-border-default'
              }`}
            >
              <div className="text-[10px] font-semibold uppercase tracking-wider text-text-muted">{p.role ?? '—'}</div>
              <div className="my-1 text-sm font-semibold text-text-primary">{p.name ?? '—'}</div>
              {p.meta && <div className="mb-3 text-xs text-text-muted">{p.meta}</div>}
              {p.details && p.details.length > 0 && (
                <div className="grid grid-cols-2 gap-2">
                  {p.details.map((d, j) => (
                    <div key={j}>
                      <div className="text-[10px] text-text-muted">{d.label}</div>
                      <div className="text-xs text-text-primary">{d.value}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </SectionCard>
  );
}

function ChecksTab({ rows }: { rows: Txn360Check[] }) {
  return (
    <SectionCard icon={<ShieldCheck size={15} />} title="Checks">
      {rows.length === 0 ? (
        <EmptyState title="No checks" message="No validation or compliance checks are available for this transaction." />
      ) : (
        <div className="flex flex-col divide-y divide-border-default">
          {rows.map((c, i) => {
            const passed = (c.status ?? 'PASS').toUpperCase() !== 'FAIL';
            return (
              <div key={i} className="flex items-center gap-3 py-2.5">
                <span
                  className={`flex size-5 shrink-0 items-center justify-center rounded-full ${
                    passed ? 'text-accent-green' : 'text-accent-red'
                  }`}
                >
                  {passed ? <Check size={13} /> : <X size={13} />}
                </span>
                <div className="flex-1">
                  <div className="text-xs font-medium text-text-primary">{c.name ?? '—'}</div>
                  {c.detail && <div className="text-[11px] text-text-muted">{c.detail}</div>}
                </div>
                {c.time && <div className="whitespace-nowrap font-mono text-[11px] text-text-muted">{c.time}</div>}
              </div>
            );
          })}
        </div>
      )}
    </SectionCard>
  );
}

function MessagesTab({ rows }: { rows: Txn360Message[] }) {
  return (
    <SectionCard icon={<Route size={15} />} title="Messages">
      {rows.length === 0 ? (
        <EmptyState title="No messages" message="No SWIFT / ISO 20022 messages are available for this transaction." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-border-default text-[10px] uppercase tracking-wider text-text-muted">
                <th className="px-3 py-2">Message Type</th>
                <th className="px-3 py-2">Direction</th>
                <th className="px-3 py-2">Status</th>
                <th className="px-3 py-2">Reference</th>
                <th className="px-3 py-2">Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((m, i) => (
                <tr key={i} className="border-b border-border-default">
                  <td className="px-3 py-2">
                    <Badge variant="blue" size="sm">
                      {m.messageType ?? '—'}
                    </Badge>
                  </td>
                  <td className="px-3 py-2">
                    <DirectionBadge direction={m.direction} />
                  </td>
                  <td className="px-3 py-2 text-text-secondary">{m.status ?? '—'}</td>
                  <td className="px-3 py-2 font-mono">{m.reference ?? '—'}</td>
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-text-muted">{formatTime(m.timestamp)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </SectionCard>
  );
}

function FinancialTab({ rows }: { rows: Txn360FinancialPosting[] }) {
  return (
    <SectionCard icon={<Landmark size={15} />} title="Financial Postings">
      {rows.length === 0 ? (
        <EmptyState title="No postings" message="No financial postings are available for this transaction." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-border-default text-[10px] uppercase tracking-wider text-text-muted">
                <th className="px-3 py-2">Account</th>
                <th className="px-3 py-2">Entry</th>
                <th className="px-3 py-2">Amount</th>
                <th className="px-3 py-2">Status</th>
                <th className="px-3 py-2">Posted At</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((f, i) => {
                const debit = (f.entryType ?? '').toUpperCase() === 'DEBIT';
                return (
                  <tr key={i} className="border-b border-border-default">
                    <td className="px-3 py-2 font-mono">{f.account ?? '—'}</td>
                    <td className={`px-3 py-2 font-semibold ${debit ? 'text-accent-red' : 'text-accent-green'}`}>
                      {f.entryType ?? '—'}
                    </td>
                    <td className="px-3 py-2 font-mono">
                      {formatAmount(f.amount)} {f.currency}
                    </td>
                    <td className="px-3 py-2 text-text-secondary">{f.status ?? '—'}</td>
                    <td className="whitespace-nowrap px-3 py-2 font-mono text-text-muted">{formatTime(f.postedAt)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </SectionCard>
  );
}

// ─── Tab metadata ──────────────────────────────────────────────────────────────

interface TabDef {
  key: string;
  label: string;
  count: number;
}

// ─── Page ──────────────────────────────────────────────────────────────────────

export function Transaction360Page() {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  // The Transactions grid passes the clicked row in navigation state; use it as a
  // placeholder so the Hero/summary paints immediately while the full 360 view loads.
  const summary = (location.state as { summary?: Payment } | null)?.summary;

  const {
    data: detail,
    isLoading,
    isPlaceholderData,
    error,
  } = useQuery({
    queryKey: ['transaction360', id],
    queryFn: () => fetchTransaction360(id!),
    enabled: !!id,
    placeholderData: summary ? summaryToPlaceholder(summary) : undefined,
  });

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error || !detail) {
    return (
      <div className="p-6">
        <EmptyState
          title="Transaction not found"
          message={`Transaction "${id ?? ''}" could not be loaded or the service is unavailable.`}
        />
      </div>
    );
  }

  const timeline = detail.timeline ?? [];
  const journey = detail.workflowJourney ?? [];
  const audit = detail.auditTrail ?? [];
  const settlement = detail.settlementEntries ?? [];
  const notifications = detail.notifications ?? [];
  const exceptions = detail.exceptions ?? [];
  const gpi = detail.gpiTracker ?? [];
  const parties = detail.parties ?? [];
  const checks = detail.checks ?? [];
  const messages = detail.messages ?? [];
  const financial = detail.financialPostings ?? [];

  const executedCount = journey.filter((s) => (s.status ?? '').toUpperCase() !== 'PENDING').length;

  const tabs: TabDef[] = [
    { key: 'timeline', label: 'Timeline', count: timeline.length },
    { key: 'workflow', label: 'Workflow', count: executedCount },
    { key: 'audit', label: 'Audit', count: audit.length },
    { key: 'settlement', label: 'Settlement', count: settlement.length },
    { key: 'notifications', label: 'Notifications', count: notifications.length },
    { key: 'exceptions', label: 'Exceptions', count: exceptions.length },
    { key: 'gpi', label: 'GPI Tracker', count: gpi.length },
    { key: 'parties', label: 'Parties', count: parties.length },
    { key: 'checks', label: 'Checks', count: checks.length },
    { key: 'messages', label: 'Messages', count: messages.length },
    { key: 'financial', label: 'Financial', count: financial.length },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Transaction 360"
        subtitle={isPlaceholderData ? 'Loading full details…' : undefined}
      />
      <PageBody>
        <div className="flex flex-col gap-6">
          <Hero detail={detail} />

          <Tabs defaultValue="timeline">
        <TabsList className="mb-4 flex flex-wrap">
          {tabs.map((t) => (
            <TabsTrigger key={t.key} value={t.key} className="gap-1.5">
              {t.label}
              {t.count > 0 && (
                <Badge variant={t.key === 'exceptions' ? 'red' : 'default'} size="sm">
                  {t.count}
                </Badge>
              )}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="timeline">
          <TimelineTab events={timeline} traceViewUrl={detail.traceViewUrl} />
        </TabsContent>
        <TabsContent value="workflow">
          <WorkflowTab journey={journey} />
        </TabsContent>
        <TabsContent value="audit">
          <AuditTab rows={audit} />
        </TabsContent>
        <TabsContent value="settlement">
          <SettlementTab rows={settlement} />
        </TabsContent>
        <TabsContent value="notifications">
          <NotificationsTab rows={notifications} />
        </TabsContent>
        <TabsContent value="exceptions">
          <ExceptionsTab rows={exceptions} />
        </TabsContent>
        <TabsContent value="gpi">
          <GpiTab rows={gpi} />
        </TabsContent>
        <TabsContent value="parties">
          <PartiesTab rows={parties} />
        </TabsContent>
        <TabsContent value="checks">
          <ChecksTab rows={checks} />
        </TabsContent>
        <TabsContent value="messages">
          <MessagesTab rows={messages} />
        </TabsContent>
        <TabsContent value="financial">
          <FinancialTab rows={financial} />
        </TabsContent>
          </Tabs>
        </div>
      </PageBody>
    </PageShell>
  );
}
