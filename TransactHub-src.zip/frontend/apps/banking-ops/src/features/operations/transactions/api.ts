import { bankingApi } from '../../../shared/api/bankingApi';
import { toUtcRangeParams } from '@paymenthub/ui';
import type { PaginatedResponse, Payment, PaymentRail, PaymentStatus, TimelineEvent } from '@paymenthub/ui';
import type {
  NewTransactionPayload,
  TransactionSearchParams,
  Txn360View,
  WorkflowEngineResult,
} from './types';

/**
 * Search-query params. Extends the shared {@link TransactionSearchParams} with a
 * single-valued `scheme` used by the rail quick-tabs — this carries rail values
 * that are NOT part of the strict `PaymentRail` union (e.g. `XBDR` / Cross-Rail),
 * and, when present, takes precedence over the `rail[]` multi-select.
 */
export interface TransactionSearchQuery extends TransactionSearchParams {
  scheme?: string;
}

/**
 * A transaction-search result row. Extends `Payment` with the extra columns the
 * search grid shows. Fields the observability summary does not return
 * (sender/receiver names, value date, E2E ref, UETR) are surfaced as empty so
 * the grid renders a graceful blank rather than fabricating values.
 */
export interface TransactionSearchRow extends Payment {
  direction: string;
  senderName: string;
  receiverName: string;
  valueDate: string | null;
  createdAt: string;
  e2eRef: string;
  uetr: string;
}

/**
 * Backend transaction-report row (Operations API — GET /api/reports/transactions,
 * served from `platform.TransactionReports`). Adapted to the frontend `Payment`.
 */
interface TransactionReportRow {
  id: number;
  transactionId: string;
  schemaType: string; // IPI, WPS, FTS, CBFT, NPSS
  tenantId: string;
  direction: string;
  category: string;
  status: string;
  endToEndId?: string | null;
  instructionId?: string | null;
  postingReferenceNumber?: string | null;
  transactionDate: string;
  amount: number;
  currency: string;
  debtorAccountNumber?: string | null;
  creditorAccountNumber?: string | null;
  createdAt: string;
}

interface BackendPaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

const RAIL_ALIASES: Record<string, PaymentRail> = {
  IPI: 'IPI',
  IPP: 'IPP',
  WPS: 'WPS',
  SWIFT: 'SWIFT',
  UAEFTS: 'UAEFTS',
  FTS: 'UAEFTS',
};

/** PaymentRail → backend schemaType (the reports table stores 'FTS', not 'UAEFTS'). */
const RAIL_TO_SCHEMA: Record<PaymentRail, string> = {
  UAEFTS: 'FTS',
  IPI: 'IPI',
  IPP: 'IPP',
  WPS: 'WPS',
  SWIFT: 'SWIFT',
};

function normalizeRail(rail: string): PaymentRail {
  return RAIL_ALIASES[rail?.toUpperCase()] ?? 'UAEFTS';
}

function mapTransactionReport(row: TransactionReportRow): Payment {
  return {
    // Row identity is the business transaction id — the 360 view (navigation target)
    // resolves by transactionId, not the numeric DB id.
    id: row.transactionId,
    referenceNumber: row.endToEndId ?? row.postingReferenceNumber ?? row.instructionId ?? row.transactionId,
    rail: normalizeRail(row.schemaType),
    status: (row.status?.toUpperCase() ?? 'PENDING') as PaymentStatus,
    amount: row.amount,
    currency: row.currency ?? 'AED',
    debtorAccount: row.debtorAccountNumber ?? '',
    creditorAccount: row.creditorAccountNumber ?? '',
    submittedAt: row.transactionDate ?? row.createdAt,
    makerUserId: '',
    tenantId: row.tenantId ?? '',
    correlationId: row.transactionId,
  };
}

/**
 * Backend transaction summary from the observability search
 * (GET /api/observability/transactions/search, served from the `platform.Transactions`
 * CQRS projection). Unlike `platform.TransactionReports`, these transactions have linked
 * 360° detail (timeline / workflow journey / audit / settlement), so a row here can be
 * opened in the 360 view with populated tabs.
 */
interface ObservabilityTxnSummary {
  transactionId: string;
  tenantId: string;
  status: string; // raw timeline status: Settled | Initiated | Processing | Failed | …
  initiatedAt: string;
  durationMs: number | null;
  scheme: string;
  direction: string;
  amount: number;
  currency: string;
}

/** Frontend PaymentStatus → backend timeline status value (for the server-side status filter). */
const STATUS_TO_BACKEND: Record<string, string> = {
  COMPLETED: 'Settled',
  PENDING: 'Initiated',
  PROCESSING: 'Processing',
  FAILED: 'Failed',
  CANCELLED: 'Reversed',
};

function mapObsStatus(s: string): PaymentStatus {
  switch ((s ?? '').toUpperCase()) {
    case 'SETTLED':
    case 'COMPLETED':
      return 'COMPLETED';
    case 'INITIATED':
    case 'CREATED':
    case 'PENDING':
    case 'PROCESSING':
      return 'PROCESSING';
    case 'REJECTED':
    case 'RULES_FAILED':
      return 'REJECTED';
    case 'FAILED':
      return 'FAILED';
    case 'REVERSED':
      return 'REVERSED';
    case 'CANCELLED':
      return 'CANCELLED';
    default:
      return ((s ?? 'PROCESSING').toUpperCase()) as PaymentStatus;
  }
}

function mapObservabilitySummary(row: ObservabilityTxnSummary): TransactionSearchRow {
  return {
    id: row.transactionId,
    referenceNumber: row.transactionId,
    rail: normalizeRail(row.scheme),
    status: mapObsStatus(row.status),
    amount: row.amount,
    currency: row.currency ?? 'AED',
    debtorAccount: '',
    creditorAccount: '',
    submittedAt: row.initiatedAt,
    makerUserId: '',
    tenantId: row.tenantId ?? '',
    correlationId: row.transactionId,
    // ── Extended grid columns ──────────────────────────────────────────────
    direction: row.direction ?? '',
    createdAt: row.initiatedAt,
    // Not carried by the observability summary — rendered blank, never faked.
    senderName: '',
    receiverName: '',
    valueDate: null,
    e2eRef: '',
    uetr: '',
  };
}

export const transactionsApi = {
  search: async (params: TransactionSearchQuery) => {
    // Source from the observability projection (platform.Transactions) — its rows have
    // linked 360° data. (platform.TransactionReports is a disjoint demo dataset whose
    // ids have NO timeline/audit/settlement, so those 360 tabs come back empty.)
    const query: Record<string, string | number> = {
      page: params.page ?? 1,
      pageSize: params.pageSize ?? 50,
    };
    if (params.referenceNumber) query.transactionId = params.referenceNumber;
    // Session-zone days as UTC [from, to); the server compares CreatedAt < to (UTC date-time T-22).
    const submitted = toUtcRangeParams(params.submittedFrom, params.submittedTo);
    if (submitted.from) query.from = submitted.from;
    if (submitted.to) query.to = submitted.to;

    // Rail: an explicit `scheme` (from the rail quick-tab, incl. non-PaymentRail
    // values like XBDR) wins; otherwise fall back to the `rail[]` multi-select.
    // NOTE: send ALL selected values (comma-joined, mirroring the Angular
    // `filter[rail]` service) instead of only when exactly one is picked — the
    // old `=== 1` guard silently dropped the filter for 2+ selections.
    if (params.scheme && params.scheme.toLowerCase() !== 'all') {
      const s = params.scheme.toUpperCase();
      query.scheme = (RAIL_TO_SCHEMA as Record<string, string>)[s] ?? s;
    } else if (params.rail?.length) {
      query.scheme = params.rail.map((r) => RAIL_TO_SCHEMA[r]).join(',');
    }
    if (params.status?.length) {
      query.status = params.status.map((s) => STATUS_TO_BACKEND[s] ?? s).join(',');
    }

    const res = await bankingApi.get<BackendPaginatedResponse<ObservabilityTxnSummary>>(
      '/observability/transactions/search',
      { params: query },
    );
    const { items, total, page, pageSize } = res.data;
    const mapped: PaginatedResponse<TransactionSearchRow> = {
      items: items.map(mapObservabilitySummary),
      total,
      page,
      pageSize,
      totalPages: pageSize > 0 ? Math.ceil(total / pageSize) : 0,
    };
    return { ...res, data: mapped };
  },

  get: async (id: string) => {
    const res = await bankingApi.get<TransactionReportRow>(`/reports/transactions/${encodeURIComponent(id)}`);
    return { ...res, data: mapTransactionReport(res.data) };
  },

  getTimeline: (id: string) =>
    bankingApi.get<TimelineEvent[]>(`/reports/transactions/${encodeURIComponent(id)}/timeline`),

  create: (payload: NewTransactionPayload) => bankingApi.post<Payment>('/transactions', payload),

  /** Rich Operations-API 360° view (workflow journey, audit, settlement, …). */
  getTransaction360View: (id: string) =>
    bankingApi.get<Txn360View>(`/transactions/${encodeURIComponent(id)}/360`),

  /** Workflow-engine fallback used when the 360 view is unavailable. */
  getTransaction360: (id: string) =>
    bankingApi.get<WorkflowEngineResult>(`/payment/${encodeURIComponent(id)}/360`),

  /** Resolve a 360° view by Workflow ID / Payment Reference / UETR. */
  getTransactionDetail: (query: string) =>
    bankingApi.get<Txn360View>(`/transactions/${encodeURIComponent(query)}/360`),
};
