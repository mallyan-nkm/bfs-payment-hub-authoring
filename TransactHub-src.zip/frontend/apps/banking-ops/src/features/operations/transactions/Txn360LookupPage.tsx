import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Compass, Search } from 'lucide-react';
import { Button, PageShell, PageHeader, PageBody } from '@paymenthub/ui';

/** Txn 360° View — enter a transaction reference to open its full 360 dossier. */
export function Txn360LookupPage() {
  const navigate = useNavigate();
  const [id, setId] = useState('');

  const go = (e: React.FormEvent) => {
    e.preventDefault();
    const v = id.trim();
    if (v) navigate(`/operations/transactions/${encodeURIComponent(v)}/360`);
  };

  return (
    <PageShell>
      <PageHeader title="Transaction 360° View" subtitle="Look up a transaction to view its complete lifecycle" />
      <PageBody>
        <div className="mx-auto mt-10 max-w-xl rounded-2xl border border-[var(--border)] bg-[var(--bg-card)] p-8 text-center shadow-[var(--shadow-sm)]">
          <span className="mx-auto mb-4 grid size-14 place-items-center rounded-2xl text-white" style={{ background: 'var(--brand-gradient)' }}>
            <Compass size={26} />
          </span>
          <h2 className="text-lg font-semibold text-[var(--text-primary)]">Find a transaction</h2>
          <p className="mt-1 text-sm text-[var(--text-muted)]">
            Enter a transaction reference to open its 360° view — timeline, workflow, settlement, parties and more.
          </p>
          <form onSubmit={go} className="mt-6 flex gap-2">
            <div className="relative flex-1">
              <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
              <input
                value={id}
                onChange={(e) => setId(e.target.value)}
                placeholder="e.g. WPS-REC-… or TXN-…"
                className="h-11 w-full rounded-xl border border-[var(--border)] bg-[var(--bg-input)] pl-10 pr-3 text-sm text-[var(--text-primary)] outline-none focus:border-[var(--accent)]"
              />
            </div>
            <Button type="submit" variant="primary" disabled={!id.trim()}>
              Open 360°
            </Button>
          </form>
          <p className="mt-4 text-xs text-[var(--text-muted)]">
            Or browse from{' '}
            <button type="button" onClick={() => navigate('/operations/transactions')} className="font-medium text-[var(--accent)] hover:underline">
              Transaction Search
            </button>
            .
          </p>
        </div>
      </PageBody>
    </PageShell>
  );
}
