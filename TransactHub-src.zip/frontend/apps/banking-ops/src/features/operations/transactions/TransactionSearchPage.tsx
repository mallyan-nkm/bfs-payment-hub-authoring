import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, ChevronLeft, ChevronRight, Search, Plus, SlidersHorizontal, Check } from 'lucide-react';
import {
  Button,
  Input,
  DataTable,
  RichSelect,
  DateRangePicker,
  Badge,
  StatusBadge,
  DropdownMenu,
  PageShell,
  PageHeader,
  PageToolbar,
  PageBody,
  cn,
} from '@paymenthub/ui';
import type { DataTableColumn, DataTableSort, DateRange, PaymentStatus } from '@paymenthub/ui';
import { transactionsApi } from './api';
import type { TransactionSearchQuery, TransactionSearchRow } from './api';

/** Rail quick-tabs — mirrors Angular's `railTabs` (single-select strip, incl. Cross-Rail/XBDR). */
const RAIL_TABS: { key: string; label: string }[] = [
  { key: 'all', label: 'All Rails' },
  { key: 'UAEFTS', label: 'UAEFTS' },
  { key: 'IPI', label: 'IPI' },
  { key: 'IPP', label: 'IPP' },
  { key: 'WPS', label: 'WPS' },
  { key: 'SWIFT', label: 'SWIFT' },
  { key: 'XBDR', label: 'Cross-Rail' },
];

/** Quick-filter chips — mirrors Angular's `quickFilters`. Applied client-side to the fetched page. */
const QUICK_FILTERS: { key: string; label: string }[] = [
  { key: 'failed', label: 'Failed' },
  { key: 'held', label: 'Held' },
  { key: 'highValue', label: 'High value (>1M)' },
];

const STATUS_OPTIONS: { label: string; value: PaymentStatus }[] = [
  { label: 'Draft', value: 'DRAFT' },
  { label: 'Pending Approval', value: 'PENDING_APPROVAL' },
  { label: 'Approved', value: 'APPROVED' },
  { label: 'Processing', value: 'PROCESSING' },
  { label: 'Completed', value: 'COMPLETED' },
  { label: 'Rejected', value: 'REJECTED' },
  { label: 'Cancelled', value: 'CANCELLED' },
  { label: 'Failed', value: 'FAILED' },
  { label: 'Reversed', value: 'REVERSED' },
];

const PAGE_SIZE_OPTIONS = [25, 50, 100];

const HIGH_VALUE_THRESHOLD = 1_000_000;
const DASH = '—';

/** Sort the current (server) page client-side — the search endpoint has no sort param. */
function sortRows(rows: TransactionSearchRow[], sort: DataTableSort): TransactionSearchRow[] {
  const dir = sort.direction === 'asc' ? 1 : -1;
  const dateKeys = new Set(['createdAt', 'valueDate', 'submittedAt']);
  return [...rows].sort((a, b) => {
    const av = (a as unknown as Record<string, unknown>)[sort.key];
    const bv = (b as unknown as Record<string, unknown>)[sort.key];
    if (sort.key === 'amount') {
      return ((typeof av === 'number' ? av : 0) - (typeof bv === 'number' ? bv : 0)) * dir;
    }
    if (dateKeys.has(sort.key)) {
      const at = av ? new Date(String(av)).getTime() : 0;
      const bt = bv ? new Date(String(bv)).getTime() : 0;
      return (at - bt) * dir;
    }
    return String(av ?? '').localeCompare(String(bv ?? '')) * dir;
  });
}

export function TransactionSearchPage() {
  const navigate = useNavigate();
  const [referenceNumber, setReferenceNumber] = useState('');
  const [activeRail, setActiveRail] = useState('all');
  const [status, setStatus] = useState<PaymentStatus[]>([]);
  const [dateRange, setDateRange] = useState<DateRange>({});
  const [quickFilters, setQuickFilters] = useState<string[]>([]);
  const [sort, setSort] = useState<DataTableSort>({ key: 'createdAt', direction: 'desc' });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [showE2e, setShowE2e] = useState(false);
  const [showUetr, setShowUetr] = useState(false);

  const params: TransactionSearchQuery = {
    referenceNumber: referenceNumber || undefined,
    scheme: activeRail !== 'all' ? activeRail : undefined,
    status: status.length ? status : undefined,
    submittedFrom: dateRange.from,
    submittedTo: dateRange.to,
    page,
    pageSize,
  };

  const { data, isFetching } = useQuery({
    queryKey: ['transaction-search', params],
    queryFn: () => transactionsApi.search(params).then((r) => r.data),
  });

  const total = data?.total ?? 0;
  const totalPages = data?.totalPages ?? 1;
  const showingFrom = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const showingTo = Math.min(page * pageSize, total);

  /** Client-side quick-filter chips + column sort over the fetched page. */
  const viewRows = useMemo(() => {
    let rows = data?.items ?? [];
    if (quickFilters.includes('failed')) rows = rows.filter((r) => r.status === 'FAILED');
    if (quickFilters.includes('held')) rows = rows.filter((r) => r.status === 'REJECTED');
    if (quickFilters.includes('highValue')) rows = rows.filter((r) => r.amount > HIGH_VALUE_THRESHOLD);
    return sortRows(rows, sort);
  }, [data, quickFilters, sort]);

  const columns = useMemo<DataTableColumn<TransactionSearchRow>[]>(() => {
    const cols: DataTableColumn<TransactionSearchRow>[] = [
      { key: 'referenceNumber', header: 'Transaction ID', sortable: true, className: 'font-mono text-xs', render: (r) => r.referenceNumber },
      { key: 'rail', header: 'Rail', sortable: true, render: (r) => <Badge variant="outline">{r.rail}</Badge> },
      { key: 'direction', header: 'Direction', sortable: true, render: (r) => (r.direction ? <Badge variant="outline">{r.direction}</Badge> : DASH) },
      { key: 'status', header: 'Status', sortable: true, render: (r) => <StatusBadge status={r.status} /> },
      { key: 'amount', header: 'Amount', align: 'right', sortable: true, render: (r) => r.amount.toLocaleString() },
      { key: 'currency', header: 'CCY', render: (r) => r.currency || DASH },
      { key: 'senderName', header: 'Sender', sortable: true, render: (r) => r.senderName || DASH },
      { key: 'receiverName', header: 'Receiver', sortable: true, render: (r) => r.receiverName || DASH },
      { key: 'valueDate', header: 'Value Date', sortable: true, kind: 'calendarDate' },
    ];
    if (showE2e) cols.push({ key: 'e2eRef', header: 'E2E Ref', sortable: true, className: 'font-mono text-xs', render: (r) => r.e2eRef || DASH });
    if (showUetr) cols.push({ key: 'uetr', header: 'UETR', sortable: true, className: 'font-mono text-xs', render: (r) => r.uetr || DASH });
    cols.push({ key: 'createdAt', header: 'Created', sortable: true, kind: 'instant' });
    return cols;
  }, [showE2e, showUetr]);

  function toggleQuickFilter(key: string) {
    setQuickFilters((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }

  return (
    <PageShell>
      <PageHeader
        title="Transaction Search"
        subtitle={`${total.toLocaleString()} result${total !== 1 ? 's' : ''}`}
        actions={
          <>
            <DropdownMenu
              trigger={
                <Button variant="secondary" size="sm">
                  <SlidersHorizontal size={14} /> Columns
                </Button>
              }
              items={[
                { label: 'E2E Ref', icon: showE2e ? <Check size={14} /> : <span className="inline-block w-3.5" />, onClick: () => setShowE2e((v) => !v) },
                { label: 'UETR', icon: showUetr ? <Check size={14} /> : <span className="inline-block w-3.5" />, onClick: () => setShowUetr((v) => !v) },
              ]}
            />
            <Button variant="primary" size="sm" onClick={() => navigate('/operations/transactions/new')}>
              <Plus size={14} /> New Transaction
            </Button>
          </>
        }
      />

      <PageToolbar className="items-end">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
          <Input
            label="Search"
            placeholder="Search by ID, UETR, E2E ref, sender, receiver…"
            className="pl-8"
            value={referenceNumber}
            onChange={(e) => {
              setReferenceNumber(e.target.value);
              setPage(1);
            }}
          />
        </div>
        <RichSelect
          label="Status"
          options={STATUS_OPTIONS}
          value={status}
          onChange={(v) => {
            setStatus(v as PaymentStatus[]);
            setPage(1);
          }}
          placeholder="All statuses"
          className="w-56"
        />
        <DateRangePicker
          label="Submitted"
          value={dateRange}
          onChange={(v) => {
            setDateRange(v);
            setPage(1);
          }}
          className="w-72"
        />
      </PageToolbar>

      {/* Rail quick-tabs */}
      <div className="flex flex-wrap gap-1">
        {RAIL_TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => {
              setActiveRail(t.key);
              setPage(1);
            }}
            className={cn(
              'rounded-full border px-3 py-1 text-xs transition-colors',
              activeRail === t.key
                ? 'border-[var(--accent)] bg-[var(--accent)]/10 text-[var(--accent)]'
                : 'border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--accent)]',
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Quick-filter chips */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-[var(--text-muted)]">Quick filters</span>
        {QUICK_FILTERS.map((f) => {
          const active = quickFilters.includes(f.key);
          return (
            <button
              key={f.key}
              type="button"
              onClick={() => toggleQuickFilter(f.key)}
              className={cn(
                'rounded-full border px-3 py-1 text-xs transition-colors',
                active
                  ? 'border-[var(--accent)] bg-[var(--accent)]/10 text-[var(--accent)]'
                  : 'border-[var(--border)] text-[var(--text-secondary)] hover:border-[var(--accent)]',
              )}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable<TransactionSearchRow>
            columns={columns}
            data={viewRows}
            rowKey={(row) => row.id}
            sort={sort}
            onSortChange={setSort}
            paginated={false}
            onRowClick={(row) =>
              navigate(`/operations/transactions/${row.id}/360`, { state: { summary: row } })
            }
            loading={isFetching}
            emptyTitle="No transactions found"
            emptyMessage="Adjust your search filters and try again."
          />

          {/* Server-side pagination footer + page-size control */}
          <div className="pq-pagination">
            <span>
              Showing <strong>{showingFrom}–{showingTo}</strong> of <strong>{total.toLocaleString()}</strong> records
            </span>
            <div className="pq-pagination-controls">
              <div className="pq-pagesize">
                <span>Rows per page:</span>
                <div className="pq-pagesize-select">
                  <select
                    value={pageSize}
                    onChange={(e) => {
                      setPageSize(Number(e.target.value));
                      setPage(1);
                    }}
                  >
                    {PAGE_SIZE_OPTIONS.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                  <ChevronDown size={13} className="pq-pagesize-caret" />
                </div>
              </div>
              <button type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1} className="btn-tertiary">
                <ChevronLeft size={14} /> Previous
              </button>
              <span className="pq-page-badge">{page}</span>
              <button type="button" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages} className="btn-tertiary">
                Next <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>
      </PageBody>
    </PageShell>
  );
}
