import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { StepWizard, Input, RichSelect, Select, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { PaymentRail, WizardStep } from '@paymenthub/ui';
import { transactionsApi } from './api';
import { useRailAccess } from '../../../shared/auth/rails';

const RAIL_OPTIONS: { label: string; value: PaymentRail }[] = [
  { label: 'UAEFTS', value: 'UAEFTS' },
  { label: 'IPI', value: 'IPI' },
  { label: 'IPP', value: 'IPP' },
  { label: 'WPS', value: 'WPS' },
  { label: 'SWIFT', value: 'SWIFT' },
];

const CURRENCY_OPTIONS = [
  { label: 'AED', value: 'AED' },
  { label: 'USD', value: 'USD' },
  { label: 'EUR', value: 'EUR' },
  { label: 'GBP', value: 'GBP' },
];

interface BeneficiaryForm {
  name: string;
  account: string;
  bank: string;
}

interface AmountForm {
  rail: string[];
  amount: string;
  currency: string;
}

export function NewTransactionPage() {
  const { allows: allowsRail } = useRailAccess();
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [beneficiary, setBeneficiary] = useState<BeneficiaryForm>({ name: '', account: '', bank: '' });
  const [amountForm, setAmountForm] = useState<AmountForm>({ rail: [], amount: '', currency: 'AED' });

  const mutation = useMutation({
    mutationFn: () =>
      transactionsApi
        .create({
          beneficiaryName: beneficiary.name,
          beneficiaryAccount: beneficiary.account,
          beneficiaryBank: beneficiary.bank,
          rail: amountForm.rail[0] as PaymentRail,
          amount: Number(amountForm.amount),
          currency: amountForm.currency,
        })
        .then((r) => r.data),
    onSuccess: (payment) => {
      navigate(`/operations/transactions/${payment.id}/360`);
    },
  });

  function isStepValid(index: number): boolean {
    if (index === 0) {
      return !!beneficiary.name && !!beneficiary.account && !!beneficiary.bank;
    }
    if (index === 1) {
      return amountForm.rail.length > 0 && Number(amountForm.amount) > 0 && !!amountForm.currency;
    }
    return true;
  }

  const steps: WizardStep[] = [
    {
      id: 'beneficiary',
      label: 'Beneficiary',
      content: (
        <div className="flex flex-col gap-3 max-w-md">
          <Input
            label="Beneficiary name"
            value={beneficiary.name}
            onChange={(e) => setBeneficiary((b) => ({ ...b, name: e.target.value }))}
          />
          <Input
            label="Account number"
            value={beneficiary.account}
            onChange={(e) => setBeneficiary((b) => ({ ...b, account: e.target.value }))}
          />
          <Input
            label="Bank"
            value={beneficiary.bank}
            onChange={(e) => setBeneficiary((b) => ({ ...b, bank: e.target.value }))}
          />
        </div>
      ),
    },
    {
      id: 'amount',
      label: 'Amount / Rail',
      content: (
        <div className="flex flex-col gap-3 max-w-md">
          <RichSelect
            label="Payment rail"
            options={RAIL_OPTIONS.filter((o) => allowsRail(o.value))}
            value={amountForm.rail}
            onChange={(v) => setAmountForm((f) => ({ ...f, rail: v }))}
            multiple={false}
            placeholder="Select rail"
          />
          <Input
            label="Amount"
            type="number"
            min={0}
            value={amountForm.amount}
            onChange={(e) => setAmountForm((f) => ({ ...f, amount: e.target.value }))}
          />
          <Select
            label="Currency"
            options={CURRENCY_OPTIONS}
            value={amountForm.currency}
            onValueChange={(v) => setAmountForm((f) => ({ ...f, currency: v }))}
          />
        </div>
      ),
    },
    {
      id: 'review',
      label: 'Review',
      content: (
        <dl className="grid grid-cols-2 gap-3 max-w-md text-sm">
          <div>
            <dt className="text-xs text-[var(--text-muted)]">Beneficiary</dt>
            <dd className="text-[var(--text-primary)]">{beneficiary.name}</dd>
          </div>
          <div>
            <dt className="text-xs text-[var(--text-muted)]">Account</dt>
            <dd className="text-[var(--text-primary)]">{beneficiary.account}</dd>
          </div>
          <div>
            <dt className="text-xs text-[var(--text-muted)]">Bank</dt>
            <dd className="text-[var(--text-primary)]">{beneficiary.bank}</dd>
          </div>
          <div>
            <dt className="text-xs text-[var(--text-muted)]">Rail</dt>
            <dd className="text-[var(--text-primary)]">{amountForm.rail[0] ?? '—'}</dd>
          </div>
          <div>
            <dt className="text-xs text-[var(--text-muted)]">Amount</dt>
            <dd className="text-[var(--text-primary)]">
              {amountForm.amount} {amountForm.currency}
            </dd>
          </div>
          {mutation.isError && (
            <div className="col-span-2">
              <p className="text-sm text-[var(--accent-red)]">Failed to create transaction.</p>
            </div>
          )}
        </dl>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader title="New Transaction" />
      <PageBody>
        <StepWizard
          steps={steps}
          activeStep={activeStep}
          onStepChange={setActiveStep}
          onComplete={() => mutation.mutate()}
          isStepValid={isStepValid}
          completeLabel="Submit"
          busy={mutation.isPending}
        />
      </PageBody>
    </PageShell>
  );
}
