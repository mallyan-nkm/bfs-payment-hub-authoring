import type { PaymentRail } from '@paymenthub/ui';

export interface TransactionSearchParams {
  referenceNumber?: string;
  rail?: PaymentRail[];
  status?: string[];
  submittedFrom?: string;
  submittedTo?: string;
  page?: number;
  pageSize?: number;
}

export interface NewTransactionPayload {
  beneficiaryName: string;
  beneficiaryAccount: string;
  beneficiaryBank: string;
  rail: PaymentRail;
  amount: number;
  currency: string;
}

// ─── Transaction 360° View DTO ────────────────────────────────────────────────
// Mirrors the Operations API `/transactions/:id/360` response consumed by the
// Angular transaction-360 component. All rich collections are optional because
// the backend omits empty sections and the workflow-engine fallback populates a
// subset.

export type Txn360Severity = 'INFO' | 'WARNING' | 'ERROR' | string;

/** A single step in the DSL workflow journey. */
export interface Txn360WorkflowStep {
  stepId: string;
  stepName?: string | null;
  stepType?: string | null;
  /** COMPLETED | EVALUATED | FAILED | SKIPPED | COMPENSATED | PENDING | RUNNING | … */
  status: string;
  durationMs?: number | null;
  retryCount?: number | null;
  errorMessage?: string | null;
  compensationStatus?: string | null;
  startedAt?: string | null;
  completedAt?: string | null;
}

/** A unified timeline entry (workflow / audit / settlement / notification / exception). */
export interface Txn360TimelineEvent {
  timestamp: string;
  /** WORKFLOW | AUDIT | SETTLEMENT | NOTIFICATION | EXCEPTION */
  source?: string | null;
  eventType?: string | null;
  description?: string | null;
  severity?: Txn360Severity | null;
  spanId?: string | null;
}

export interface Txn360AuditEntry {
  timestamp: string;
  eventType?: string | null;
  eventSource?: string | null;
  action?: string | null;
  userId?: string | null;
  newValue?: string | null;
}

export interface Txn360SettlementEntry {
  settlementId?: string | null;
  entryType?: 'DEBIT' | 'CREDIT' | string | null;
  amount?: number | null;
  currency?: string | null;
  status?: string | null;
  valueDate?: string | null;
}

export interface Txn360Notification {
  notificationType?: string | null;
  recipient?: string | null;
  templateKey?: string | null;
  status?: string | null;
  sentAt?: string | null;
  retryCount?: number | null;
  failureReason?: string | null;
}

export interface Txn360Exception {
  exceptionType?: string | null;
  status?: string | null;
  raisedAt?: string | null;
  assignedTo?: string | null;
  resolution?: string | null;
}

/** A SWIFT GPI tracker hop. */
export interface Txn360GpiEvent {
  status?: string | null;
  agent?: string | null;
  timestamp?: string | null;
  amount?: number | null;
  currency?: string | null;
  detail?: string | null;
}

export interface Txn360PartyDetail {
  label: string;
  value: string;
}

export interface Txn360Party {
  role?: string | null;
  name?: string | null;
  meta?: string | null;
  verified?: boolean | null;
  details?: Txn360PartyDetail[];
}

export interface Txn360Check {
  name?: string | null;
  detail?: string | null;
  status?: string | null;
  time?: string | null;
  category?: string | null;
}

export interface Txn360Message {
  messageType?: string | null;
  direction?: string | null;
  status?: string | null;
  timestamp?: string | null;
  reference?: string | null;
}

export interface Txn360FinancialPosting {
  account?: string | null;
  entryType?: 'DEBIT' | 'CREDIT' | string | null;
  amount?: number | null;
  currency?: string | null;
  status?: string | null;
  postedAt?: string | null;
}

export interface Txn360View {
  transactionId: string;
  paymentScheme?: string | null;
  status?: string | null;
  direction?: string | null;
  amount?: number | null;
  currency?: string | null;
  senderIban?: string | null;
  beneficiaryIban?: string | null;
  tenantId?: string | null;
  channel?: string | null;
  traceId?: string | null;
  traceViewUrl?: string | null;
  riskScore?: number | null;
  riskLevel?: string | null;
  slaStatus?: string | null;
  initiatedAt?: string | null;
  completedAt?: string | null;
  processingDurationMs?: number | null;
  workflowJourney?: Txn360WorkflowStep[];
  timeline?: Txn360TimelineEvent[];
  auditTrail?: Txn360AuditEntry[];
  settlementEntries?: Txn360SettlementEntry[];
  notifications?: Txn360Notification[];
  exceptions?: Txn360Exception[];
  gpiTracker?: Txn360GpiEvent[];
  parties?: Txn360Party[];
  checks?: Txn360Check[];
  messages?: Txn360Message[];
  financialPostings?: Txn360FinancialPosting[];
}

/** Raw workflow-engine response used as a fallback when the 360 view 404s. */
export interface WorkflowEngineResult {
  transactionId?: string | null;
  payload?: {
    payment_scheme?: string | null;
    scheme?: string | null;
    direction?: string | null;
    amount?: number | null;
    currency?: string | null;
    sender_iban?: string | null;
    debtor_iban?: string | null;
    beneficiary_iban?: string | null;
    creditor_iban?: string | null;
  } | null;
  workflow?: {
    status?: string | null;
    startTime?: string | null;
    closeTime?: string | null;
    executionDurationMs?: number | null;
  } | null;
  workflowState?: { state?: Record<string, string> } | Record<string, string> | null;
  temporalHistory?: { timestamp: string; eventType?: string | null; eventId?: number | string }[];
  auditTrail?: Txn360AuditEntry[];
  settlements?: Txn360SettlementEntry[];
  notifications?: Txn360Notification[];
  exceptions?: Txn360Exception[];
  traceId?: string | null;
  traceViewUrl?: string | null;
}
