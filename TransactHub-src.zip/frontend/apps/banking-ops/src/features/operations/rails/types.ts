export interface RailStats {
  volumeToday: number;
  successRate: number;
  avgLatencyMs: number;
  failuresToday: number;
}
