import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { KpiCard, DataTable, StatusBadge, EmptyState, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { DataTableColumn, Payment, PaymentRail } from '@paymenthub/ui';
import { railsApi } from './api';

const VALID_RAILS: PaymentRail[] = ['UAEFTS', 'IPI', 'IPP', 'WPS', 'SWIFT'];

export function RailWorkspacePage() {
  const { rail } = useParams<{ rail: string }>();
  const isValidRail = !!rail && VALID_RAILS.includes(rail as PaymentRail);
  const railValue = rail as PaymentRail;

  const { data: stats, isLoading: loadingStats } = useQuery({
    queryKey: ['rail-stats', railValue],
    queryFn: () => railsApi.getStats(railValue).then((r) => r.data),
    enabled: isValidRail,
  });

  const { data: inFlight = [], isLoading: loadingInFlight } = useQuery({
    queryKey: ['rail-in-flight', railValue],
    queryFn: () => railsApi.getInFlight(railValue).then((r) => r.data),
    enabled: isValidRail,
  });

  if (!isValidRail) {
    return <EmptyState title="Unknown rail" message="The requested payment rail does not exist." />;
  }

  const columns: DataTableColumn<Payment>[] = [
    { key: 'referenceNumber', header: 'Reference', sortable: true },
    {
      key: 'amount',
      header: 'Amount',
      align: 'right',
      render: (row) => `${row.amount.toLocaleString()} ${row.currency}`,
    },
    { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
    {
      key: 'submittedAt',
      header: 'Submitted',
      kind: 'instant',
    },
    { key: 'makerUserId', header: 'Maker' },
  ];

  return (
    <PageShell>
      <PageHeader title={`${railValue} Workspace`} />
      <PageBody>
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <KpiCard label="Volume Today" value={loadingStats ? '—' : (stats?.volumeToday ?? 0).toLocaleString()} />
            <KpiCard label="Success Rate" value={loadingStats ? '—' : `${(stats?.successRate ?? 0).toFixed(1)}%`} />
            <KpiCard label="Avg Latency" value={loadingStats ? '—' : `${stats?.avgLatencyMs ?? 0}ms`} />
            <KpiCard label="Failures Today" value={loadingStats ? '—' : (stats?.failuresToday ?? 0)} />
          </div>

          <div>
            <h2 className="mb-3 text-sm font-medium text-[var(--text-primary)]">In-flight payments</h2>
            <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
              <DataTable<Payment>
                columns={columns}
                data={inFlight}
                rowKey={(row) => row.id}
                loading={loadingInFlight}
                emptyTitle="No in-flight payments"
                emptyMessage={`No PROCESSING or PENDING_APPROVAL payments on ${railValue} right now.`}
              />
            </div>
          </div>
        </div>
      </PageBody>
    </PageShell>
  );
}
