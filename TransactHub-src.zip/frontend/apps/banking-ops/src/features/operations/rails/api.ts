import { bankingApi } from '../../../shared/api/bankingApi';
import type { Payment, PaymentRail, PaymentStatus } from '@paymenthub/ui';
import type { RailStats } from './types';

/**
 * Rails workspace is backed by the Operations dashboard endpoints:
 *  - stats     ← /api/ops/dashboard/transaction-summary-by-rail (rail row)
 *  - in-flight ← /api/ops/dashboard/tps-transactions (processing rows for the rail)
 */
interface RailSummaryRow {
  rail: string;
  totalTxns: number;
  success: number;
  failed: number;
  inProgress: number;
  pending: number;
  exceptions: number;
  totalAed: number;
}

interface TransactionSummaryByRailResponse {
  rails: RailSummaryRow[];
  totals: RailSummaryRow;
  avgProcessingTimeSec: number;
}

interface TpsTransactionRow {
  endToEndReference: string;
  senderReferenceNumber?: string | null;
  status?: string | null;
  currency?: string | null;
  amount?: number | null;
  channel?: string | null;
  orderingAccount?: string | null;
  beneficiaryAccount?: string | null;
  valueDate?: string | null;
  createdAt?: string | null;
}

interface TpsTransactionResponse {
  transactions: TpsTransactionRow[];
  totalCount: number;
}

/** PaymentRail → backend rail/scheme code (the dashboard stores 'FTS', not 'UAEFTS'). */
const RAIL_TO_SCHEMA: Record<PaymentRail, string> = {
  UAEFTS: 'FTS',
  IPI: 'IPI',
  IPP: 'IPP',
  WPS: 'WPS',
  SWIFT: 'SWIFT',
};

function railMatches(rowRail: string, rail: PaymentRail): boolean {
  const r = rowRail?.toUpperCase();
  return r === rail || r === RAIL_TO_SCHEMA[rail];
}

function mapTpsRow(row: TpsTransactionRow, rail: PaymentRail): Payment {
  return {
    id: row.endToEndReference,
    referenceNumber: row.senderReferenceNumber ?? row.endToEndReference,
    rail,
    status: (row.status?.toUpperCase() ?? 'PROCESSING') as PaymentStatus,
    amount: row.amount ?? 0,
    currency: row.currency ?? 'AED',
    debtorAccount: row.orderingAccount ?? '',
    creditorAccount: row.beneficiaryAccount ?? '',
    submittedAt: row.createdAt ?? row.valueDate ?? new Date().toISOString(),
    makerUserId: '',
    tenantId: '',
    correlationId: row.endToEndReference,
  };
}

export const railsApi = {
  getStats: async (rail: PaymentRail) => {
    const res = await bankingApi.get<TransactionSummaryByRailResponse>(
      '/ops/dashboard/transaction-summary-by-rail',
      { params: { direction: 'Outward', dateRange: 'today' } },
    );
    const row = res.data.rails.find((r) => railMatches(r.rail, rail));
    const stats: RailStats = {
      volumeToday: row?.totalTxns ?? 0,
      successRate: row && row.totalTxns > 0 ? (row.success / row.totalTxns) * 100 : 0,
      // Per-rail latency isn't exposed; use the aggregate avg processing time (→ ms).
      avgLatencyMs: Math.round((res.data.avgProcessingTimeSec ?? 0) * 1000),
      failuresToday: (row?.failed ?? 0) + (row?.exceptions ?? 0),
    };
    return { ...res, data: stats };
  },

  getInFlight: async (rail: PaymentRail) => {
    const res = await bankingApi.get<TpsTransactionResponse>('/ops/dashboard/tps-transactions', {
      params: {
        rail: RAIL_TO_SCHEMA[rail],
        direction: 'Outward',
        dateRange: 'today',
        pageSize: 40,
        pageNumber: 1,
      },
    });
    return { ...res, data: res.data.transactions.map((row) => mapTpsRow(row, rail)) };
  },
};
