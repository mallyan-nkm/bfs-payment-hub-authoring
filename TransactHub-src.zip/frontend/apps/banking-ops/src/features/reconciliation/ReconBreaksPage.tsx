import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Zap } from 'lucide-react';
import {
  Button,
  DataTable,
  EmptyState,
  LoadingSpinner,
  PageBody,
  PageHeader,
  PageShell,
  Sheet,
  StatusBadge,
  Textarea,
  cn,
} from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { reconApi } from './api';
import type { ReconBreak, ReconDiffRow } from './types';
import { useOfflineAwareAction, useCurrentUsername } from '../../shared/hooks/useOfflineAwareAction';

const numberFmt = (v: number) => v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

type BreakActionKind = 'resolve' | 'match' | 'investigate' | 'escalate';

const ACTION_CONFIG: Record<
  BreakActionKind,
  { path: string; eventType: string; action: string; status: ReconBreak['status']; failVerb: string }
> = {
  resolve: {
    path: 'resolve',
    eventType: 'RECON_BREAK_RESOLVED',
    action: 'RESOLVE',
    status: 'RESOLVED',
    failVerb: 'resolve',
  },
  match: {
    path: 'match',
    eventType: 'RECON_BREAK_MATCHED',
    action: 'MANUAL_MATCH',
    status: 'RESOLVED',
    failVerb: 'match',
  },
  investigate: {
    path: 'investigate',
    eventType: 'RECON_BREAK_INVESTIGATING',
    action: 'INVESTIGATE',
    status: 'INVESTIGATING',
    failVerb: 'investigate',
  },
  escalate: {
    path: 'escalate',
    eventType: 'RECON_BREAK_ESCALATED',
    action: 'ESCALATE',
    status: 'INVESTIGATING',
    failVerb: 'escalate',
  },
};

export function ReconBreaksPage() {
  const queryClient = useQueryClient();
  const performAction = useOfflineAwareAction();
  const username = useCurrentUsername();

  const [selectedBreak, setSelectedBreak] = useState<ReconBreak | null>(null);
  const [notes, setNotes] = useState('');
  const [pendingAction, setPendingAction] = useState<BreakActionKind | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const { data, isFetching } = useQuery({
    queryKey: ['recon-breaks'],
    queryFn: () => reconApi.listBreaks({ page: 1, pageSize: 20 }).then((r) => r.data),
  });

  const detailQuery = useQuery({
    queryKey: ['recon-break', selectedBreak?.id],
    queryFn: () => reconApi.getBreak(selectedBreak!.id).then((r) => r.data),
    enabled: !!selectedBreak,
  });

  const breaks = data?.items ?? [];
  const detail = detailQuery.data;

  function openBreak(row: ReconBreak) {
    setSelectedBreak(row);
    setNotes('');
    setSubmitError(null);
    setPendingAction(null);
  }

  async function runAction(kind: BreakActionKind) {
    if (!selectedBreak) return;
    const cfg = ACTION_CONFIG[kind];
    setPendingAction(kind);
    setSubmitError(null);
    try {
      await performAction({
        endpoint: `/reconciliation/breaks/${selectedBreak.id}/${cfg.path}`,
        method: 'POST',
        payload: { notes },
        auditEntry: {
          eventType: cfg.eventType,
          resourceType: 'ReconBreak',
          resourceId: selectedBreak.id,
          user: username,
          tenantId: 'unknown',
          action: cfg.action,
          details: { reference: selectedBreak.reference, notes },
          newValue: { status: cfg.status, notes },
        },
      });
      setSelectedBreak(null);
      setNotes('');
      queryClient.invalidateQueries({ queryKey: ['recon-breaks'] });
      queryClient.invalidateQueries({ queryKey: ['recon-summary'] });
    } catch {
      setSubmitError(`Failed to ${cfg.failVerb} break. Please try again.`);
    } finally {
      setPendingAction(null);
    }
  }

  const columns: DataTableColumn<ReconBreak>[] = [
    { key: 'reference', header: 'Reference', render: (r) => <span className="font-mono text-xs font-medium">{r.reference}</span> },
    {
      key: 'expectedAmount',
      header: 'Expected',
      align: 'right',
      render: (r) => `${numberFmt(r.expectedAmount)} ${r.currency}`,
    },
    {
      key: 'actualAmount',
      header: 'Actual',
      align: 'right',
      render: (r) => `${numberFmt(r.actualAmount)} ${r.currency}`,
    },
    {
      key: 'difference',
      header: 'Difference',
      align: 'right',
      render: (r) => (
        <span className={r.difference >= 0 ? 'text-[var(--success)]' : 'text-[var(--danger)]'}>
          {numberFmt(r.difference)} {r.currency}
        </span>
      ),
    },
    { key: 'ageInDays', header: 'Age (days)', align: 'right' },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <Button
          variant="secondary"
          size="sm"
          disabled={r.status === 'RESOLVED' || r.status === 'WRITTEN_OFF'}
          onClick={(e) => {
            e.stopPropagation();
            openBreak(r);
          }}
        >
          Resolve
        </Button>
      ),
    },
  ];

  const anyPending = pendingAction !== null;
  const isClosed = selectedBreak?.status === 'RESOLVED' || selectedBreak?.status === 'WRITTEN_OFF';

  return (
    <PageShell>
      <PageHeader
        title="Reconciliation Breaks"
        subtitle="Unmatched records requiring resolution"
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={breaks}
            rowKey={(r) => r.id}
            onRowClick={openBreak}
            loading={isFetching}
            emptyTitle="No breaks"
            emptyMessage="No unmatched reconciliation records found."
          />
        </div>
      </PageBody>

      <Sheet
        open={!!selectedBreak}
        onOpenChange={(open) => !open && setSelectedBreak(null)}
        title="Reconciliation Break"
        description={selectedBreak ? `Reference: ${selectedBreak.reference}` : undefined}
        width="w-[620px]"
      >
        {detailQuery.isLoading ? (
          <div className="flex h-64 items-center justify-center">
            <LoadingSpinner />
          </div>
        ) : detail ? (
          <div className="flex flex-col gap-5">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Nostro Account" value={detail.nostroAccount} />
              <Field label="Detected At" value={detail.detectedAt} mono />
              <Field label="Break Type" value={detail.breakType} />
              <Field label="Severity" value={detail.severity} danger />
            </div>

            <div>
              <div className="mb-2 text-xs font-bold text-[var(--text-primary)]">
                Ledger vs Statement Comparison
              </div>
              <div className="grid grid-cols-2 overflow-hidden rounded-md border border-[var(--border)]">
                <DiffSide title="Internal Ledger" rows={detail.ledger} />
                <DiffSide title="Bank Statement" rows={detail.statement} borderLeft />
              </div>
            </div>

            {detail.autoResolution && (
              <div className="rounded-md border border-[var(--accent)]/30 bg-[var(--accent)]/[0.08] px-3.5 py-3">
                <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold text-[var(--accent)]">
                  <Zap size={13} aria-hidden="true" />
                  Auto-Resolution Suggestion
                </div>
                <p className="text-[11px] leading-relaxed text-[var(--text-secondary)]">
                  {detail.autoResolution.summary} Confidence:{' '}
                  <span className="font-mono font-semibold text-[var(--success)]">
                    {detail.autoResolution.confidencePct}%
                  </span>
                  . Recommended action: {detail.autoResolution.recommendedAction}
                </p>
              </div>
            )}

            <Textarea
              label="Resolution Notes"
              placeholder="Describe the resolution, match, or reason for escalation…"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />

            {submitError && <p className="text-xs text-[var(--accent-red)]">{submitError}</p>}

            <div className="flex flex-wrap gap-2">
              <Button
                variant="primary"
                size="sm"
                loading={pendingAction === 'resolve'}
                disabled={anyPending || isClosed}
                onClick={() => runAction('resolve')}
              >
                {detail.autoResolution ? 'Accept Auto-Resolution' : 'Resolve'}
              </Button>
              <Button
                variant="secondary"
                size="sm"
                loading={pendingAction === 'match'}
                disabled={anyPending || isClosed}
                onClick={() => runAction('match')}
              >
                Manual Match
              </Button>
              <Button
                variant="secondary"
                size="sm"
                loading={pendingAction === 'investigate'}
                disabled={anyPending || isClosed}
                onClick={() => runAction('investigate')}
              >
                Investigate
              </Button>
              <Button
                variant="secondary"
                size="sm"
                loading={pendingAction === 'escalate'}
                disabled={anyPending || isClosed}
                onClick={() => runAction('escalate')}
              >
                Escalate
              </Button>
            </div>
          </div>
        ) : (
          <EmptyState
            title="Break detail unavailable"
            message="Could not load the comparison detail for this break."
          />
        )}
      </Sheet>
    </PageShell>
  );
}

function DiffSide({ title, rows, borderLeft }: { title: string; rows: ReconDiffRow[]; borderLeft?: boolean }) {
  return (
    <div className={cn(borderLeft && 'border-l border-[var(--border)]')}>
      <div className="border-b border-[var(--border)] bg-[var(--bg-secondary)] px-3 py-2 text-[10px] font-bold uppercase text-[var(--text-secondary)]">
        {title}
      </div>
      {rows.map((row) => (
        <div
          key={row.label}
          className="flex items-center justify-between gap-3 border-b border-[var(--border-light)] px-3 py-1.5 text-[11px] last:border-b-0"
        >
          <span className="shrink-0 text-[10px] font-medium text-[var(--text-muted)]">{row.label}</span>
          <span
            className={cn(
              'text-right font-mono',
              row.status === 'mismatch' && 'font-semibold text-[var(--danger)]',
              row.status === 'match' && 'text-[var(--success)]',
              !row.status && 'text-[var(--text-primary)]',
            )}
          >
            {row.value}
          </span>
        </div>
      ))}
    </div>
  );
}

function Field({ label, value, mono, danger }: { label: string; value: string; mono?: boolean; danger?: boolean }) {
  return (
    <div>
      <div className="mb-0.5 text-[10px] font-semibold uppercase text-[var(--text-muted)]">{label}</div>
      <div
        className={cn(
          'text-xs font-medium',
          danger ? 'font-semibold text-[var(--danger)]' : 'text-[var(--text-primary)]',
          mono && 'font-mono',
        )}
      >
        {value}
      </div>
    </div>
  );
}
