import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2, XCircle, Percent } from 'lucide-react';
import { Button, KpiCard, DataTable, PageBody, PageHeader, PageShell, StatusBadge } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { reconApi } from './api';
import type { ReconRun } from './types';

export function ReconWorkspacePage() {
  const navigate = useNavigate();

  const { data: summary, isLoading: loadingSummary } = useQuery({
    queryKey: ['recon-summary'],
    queryFn: () => reconApi.getSummary().then((r) => r.data),
  });

  const { data, isFetching } = useQuery({
    queryKey: ['recon-runs'],
    queryFn: () => reconApi.listRuns({ page: 1, pageSize: 20 }).then((r) => r.data),
  });

  const runs = data?.items ?? [];

  const columns: DataTableColumn<ReconRun>[] = [
    { key: 'runId', header: 'Run ID', render: (r) => <span className="font-mono text-xs font-medium">{r.runId}</span> },
    { key: 'source', header: 'Source' },
    { key: 'target', header: 'Target' },
    { key: 'startedAt', header: 'Started', kind: 'instant' },
    {
      key: 'completedAt',
      header: 'Completed',
      kind: 'instant',
    },
    { key: 'matchedCount', header: 'Matched', align: 'right', render: (r) => r.matchedCount.toLocaleString() },
    { key: 'unmatchedCount', header: 'Unmatched', align: 'right', render: (r) => r.unmatchedCount.toLocaleString() },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Reconciliation"
        subtitle="Recon run overview and recent activity"
        actions={
          <Button variant="secondary" size="sm" onClick={() => navigate('/reconciliation/breaks')}>
            View Breaks <ArrowRight size={14} />
          </Button>
        }
      />

      <PageBody className="space-y-6">
        {!loadingSummary && summary && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <KpiCard label="Matched" value={summary.matchedCount.toLocaleString()} icon={<CheckCircle2 size={16} />} />
            <KpiCard label="Unmatched" value={summary.unmatchedCount.toLocaleString()} icon={<XCircle size={16} />} />
            <KpiCard label="Match Rate" value={`${summary.matchRatePct.toFixed(1)}%`} icon={<Percent size={16} />} />
          </div>
        )}

        <div>
          <h2 className="text-sm font-semibold text-[var(--text-primary)] mb-3">Recent Recon Runs</h2>
          <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <DataTable
              columns={columns}
              data={runs}
              rowKey={(r) => r.runId}
              loading={isFetching}
              emptyTitle="No recon runs"
              emptyMessage="No reconciliation runs have been recorded yet."
            />
          </div>
        </div>
      </PageBody>
    </PageShell>
  );
}
