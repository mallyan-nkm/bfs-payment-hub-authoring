import { bankingApi } from '../../shared/api/bankingApi';
import type { PaginatedResponse } from '@paymenthub/ui';
import type {
  ReconRun,
  ReconBreak,
  ReconBreakDetail,
  ReconSummary,
  ReconRunListParams,
  ReconBreakListParams,
} from './types';

export const reconApi = {
  getSummary: () => bankingApi.get<ReconSummary>('/reconciliation/summary'),

  listRuns: (params: ReconRunListParams) =>
    bankingApi.get<PaginatedResponse<ReconRun>>('/reconciliation/runs', { params }),

  listBreaks: (params: ReconBreakListParams) =>
    bankingApi.get<PaginatedResponse<ReconBreak>>('/reconciliation/breaks', { params }),

  getBreak: (id: string) =>
    bankingApi.get<ReconBreakDetail>(`/reconciliation/breaks/${id}`),

  resolveBreak: (id: string, notes: string) =>
    bankingApi.post<ReconBreak>(`/reconciliation/breaks/${id}/resolve`, { notes }),

  matchBreak: (id: string, notes: string) =>
    bankingApi.post<ReconBreak>(`/reconciliation/breaks/${id}/match`, { notes }),

  investigateBreak: (id: string, notes: string) =>
    bankingApi.post<ReconBreak>(`/reconciliation/breaks/${id}/investigate`, { notes }),

  escalateBreak: (id: string, notes: string) =>
    bankingApi.post<ReconBreak>(`/reconciliation/breaks/${id}/escalate`, { notes }),
};
