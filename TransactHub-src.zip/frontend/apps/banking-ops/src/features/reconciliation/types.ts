export type ReconRunStatus = 'RUNNING' | 'COMPLETED' | 'FAILED' | 'PARTIAL';

export interface ReconRun {
  runId: string;
  source: string;
  target: string;
  startedAt: string;
  completedAt: string | null;
  status: ReconRunStatus;
  matchedCount: number;
  unmatchedCount: number;
}

export type ReconBreakStatus = 'OPEN' | 'INVESTIGATING' | 'RESOLVED' | 'WRITTEN_OFF';

export interface ReconBreak {
  id: string;
  reference: string;
  expectedAmount: number;
  actualAmount: number;
  difference: number;
  ageInDays: number;
  status: ReconBreakStatus;
  currency: string;
}

export interface ReconSummary {
  matchedCount: number;
  unmatchedCount: number;
  matchRatePct: number;
}

export interface ReconRunListParams {
  page?: number;
  pageSize?: number;
}

export interface ReconBreakListParams {
  page?: number;
  pageSize?: number;
  status?: string;
}

/** A single field of one side of the Ledger-vs-Statement comparison. */
export interface ReconDiffRow {
  label: string;
  value: string;
  status?: 'match' | 'mismatch';
}

/** System-proposed resolution for a break, surfaced to the operator. */
export interface ReconAutoResolution {
  reference: string;
  summary: string;
  confidencePct: number;
  recommendedAction: string;
}

/**
 * Full operator-workspace payload for a single break — the Internal Ledger vs
 * bank Statement comparison plus any auto-resolution suggestion needed to
 * resolve, manually match, investigate, or escalate.
 */
export interface ReconBreakDetail extends ReconBreak {
  nostroAccount: string;
  detectedAt: string;
  breakType: string;
  severity: string;
  ledger: ReconDiffRow[];
  statement: ReconDiffRow[];
  autoResolution: ReconAutoResolution | null;
}
