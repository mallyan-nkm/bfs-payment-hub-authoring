import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, BellPlus, CheckCheck } from 'lucide-react';
import { Button, DataTable, Badge, RichSelect, EmptyState, cn, useRealtimeChannel, PageShell, PageHeader, PageToolbar, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { useNotificationStore } from '../../stores/notificationStore';
import type { InAppNotification } from '../../stores/notificationStore';
import { usePushNotifications } from '../../shared/hooks/usePushNotifications';

const TYPE_OPTIONS = [
  { label: 'Approval', value: 'approval' },
  { label: 'Alert', value: 'alert' },
  { label: 'Escalation', value: 'escalation' },
  { label: 'Info', value: 'info' },
];

const TYPE_BADGE_VARIANT: Record<InAppNotification['type'], 'red' | 'amber' | 'blue' | 'outline'> = {
  approval: 'blue',
  alert: 'red',
  escalation: 'amber',
  info: 'outline',
};

export function NotificationCenterPage() {
  const navigate = useNavigate();
  const { notifications, unreadCount, push, markRead, markAllRead } = useNotificationStore();
  const [typeFilter, setTypeFilter] = useState<string[]>([]);
  const { state: pushState, subscribe: subscribeToPush } = usePushNotifications();

  const { messages } = useRealtimeChannel<InAppNotification>('notifications');

  useEffect(() => {
    if (messages.length === 0) return;
    const existingIds = new Set(notifications.map((n) => n.id));
    messages.forEach((msg) => {
      if (!existingIds.has(msg.id)) {
        push(msg);
      }
    });
    // notifications/push intentionally excluded to avoid re-running on every store update;
    // this effect should only react to new SSE messages.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages]);

  const filtered = typeFilter.length === 0
    ? notifications
    : notifications.filter((n) => typeFilter.includes(n.type));

  function handleRowClick(row: InAppNotification) {
    markRead(row.id);
    if (row.actionUrl) {
      navigate(row.actionUrl);
    }
  }

  const columns: DataTableColumn<InAppNotification>[] = [
    {
      key: 'type',
      header: 'Type',
      render: (row) => <Badge variant={TYPE_BADGE_VARIANT[row.type]}>{row.type}</Badge>,
    },
    {
      key: 'title',
      header: 'Title',
      render: (row) => (
        <span className={cn(!row.read && 'font-semibold text-[var(--text-primary)]')}>{row.title}</span>
      ),
    },
    { key: 'body', header: 'Message', render: (row) => <span className="text-[var(--text-secondary)]">{row.body}</span> },
    {
      key: 'createdAt',
      header: 'Received',
      sortable: true,
      kind: 'instant',
    },
    {
      key: 'read',
      header: 'Status',
      render: (row) => (row.read ? <Badge variant="outline">Read</Badge> : <Badge variant="green">New</Badge>),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title={
          <span className="inline-flex items-center gap-2">
            <Bell size={18} className="text-[var(--text-muted)]" />
            Notification Center
          </span>
        }
        subtitle={
          <>
            {unreadCount} unread of {notifications.length}
          </>
        }
        actions={
          <>
            {pushState !== 'unsupported' && pushState !== 'subscribed' && (
              <Button variant="secondary" size="sm" onClick={subscribeToPush} disabled={pushState === 'denied'}>
                <BellPlus size={14} />
                {pushState === 'denied' ? 'Push notifications blocked' : 'Enable push notifications'}
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={markAllRead} disabled={unreadCount === 0}>
              <CheckCheck size={14} /> Mark all read
            </Button>
          </>
        }
      />

      <PageToolbar>
        <RichSelect
          options={TYPE_OPTIONS}
          value={typeFilter}
          onChange={setTypeFilter}
          placeholder="Filter by type"
          searchPlaceholder="Search types…"
          className="w-56"
        />
      </PageToolbar>

      <PageBody>
        {filtered.length === 0 ? (
          <EmptyState title="No notifications" message="You're all caught up." />
        ) : (
          <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
            <DataTable
              columns={columns}
              data={filtered}
              rowKey={(row) => row.id}
              onRowClick={handleRowClick}
              emptyTitle="No notifications"
            />
          </div>
        )}
      </PageBody>
    </PageShell>
  );
}
