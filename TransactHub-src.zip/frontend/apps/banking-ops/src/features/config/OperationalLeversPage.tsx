import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Switch, LoadingSpinner, EmptyState, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import { configApi } from './api';
import { useCurrentUsername, useActiveTenantId, useOfflineAwareAction } from '../../shared/hooks/useOfflineAwareAction';

export function OperationalLeversPage() {
  const queryClient = useQueryClient();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();
  const offlineAwareAction = useOfflineAwareAction();

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'levers'],
    queryFn: () => configApi.levers.list().then((r) => r.data),
  });

  const levers = data ?? [];

  async function handleToggle(id: string, label: string, enabled: boolean) {
    await offlineAwareAction({
      endpoint: `/config/operational-levers/${id}`,
      method: 'PATCH',
      payload: { enabled },
      auditEntry: {
        eventType: 'OPERATIONAL_LEVER_TOGGLE',
        resourceType: 'OperationalLever',
        resourceId: id,
        user: username,
        tenantId,
        details: { label, enabled },
        action: 'OPERATIONAL_LEVER_TOGGLE',
      },
    });
    queryClient.invalidateQueries({ queryKey: ['config', 'levers'] });
  }

  if (isFetching && levers.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <PageShell>
      <PageHeader
        title="Operational Levers"
        subtitle="Toggle operationally significant controls. Each change is audited."
      />

      <PageBody>
        {levers.length === 0 ? (
          <EmptyState title="No levers configured" message="No operational levers are available." />
        ) : (
          <ul className="flex flex-col gap-3">
            {levers.map((lever) => (
              <li
                key={lever.id}
                className="flex items-start justify-between gap-3 rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-4 py-3"
              >
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-[var(--text-primary)]">{lever.label}</span>
                  <span className="text-xs text-[var(--text-muted)]">{lever.description}</span>
                </div>
                <Switch
                  checked={lever.enabled}
                  onCheckedChange={(checked) => handleToggle(lever.id, lever.label, checked)}
                />
              </li>
            ))}
          </ul>
        )}
      </PageBody>
    </PageShell>
  );
}
