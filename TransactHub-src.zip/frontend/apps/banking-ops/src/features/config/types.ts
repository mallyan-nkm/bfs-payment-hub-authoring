// Reference Data
export interface ReferenceDataEntry {
  id: string;
  category: string;
  code: string;
  value: string;
  description: string;
  active: boolean;
}

// Maintenance Windows
export type MaintenanceStatus = 'scheduled' | 'in-progress' | 'completed' | 'cancelled';

export interface MaintenanceWindow {
  id: string;
  title: string;
  startAt: string;
  endAt: string;
  status: MaintenanceStatus;
}

export interface MaintenanceCreatePayload {
  title: string;
  startAt: string;
  endAt: string;
}

// Webhooks
export interface WebhookSubscription {
  id: string;
  url: string;
  events: string[];
  active: boolean;
  payloadTemplate: string;
}

export interface WebhookUpsertPayload {
  url: string;
  events: string[];
  active: boolean;
  payloadTemplate: string;
}

// Fee Management
/** Rich fee taxonomy (restored from the Angular console). */
export type FeeCategory = 'per-transaction' | 'tiered' | 'flat-fx' | 'per-file';
export type FeeStatus = 'active' | 'draft';

export interface FeeRule {
  id: string;
  rail: string;
  feeType: 'fixed' | 'percentage';
  amount: number;
  currency: string;
  active: boolean;
  /** Pricing model — drives which components apply (base, %, cap). */
  category?: FeeCategory;
  /** Flat base component charged per transaction / file. */
  baseFee?: number;
  /** Ad-valorem percentage component (e.g. 0.005 = 0.005%). Omitted when not applicable. */
  percentage?: number;
  /** Upper bound applied to the percentage component. Omitted when uncapped. */
  cap?: number;
  /** Publication status — a Draft schedule is not yet live. */
  status?: FeeStatus;
}

export type FeeRuleUpsertPayload = Omit<FeeRule, 'id'>;

// Holiday Calendar
export interface Holiday {
  id: string;
  date: string;
  name: string;
  market: string;
}

export type HolidayCreatePayload = Omit<Holiday, 'id'>;

// Cutoff Times
export interface CutoffTimeRule {
  id: string;
  rail: string;
  /** Settlement cutoff clock time in `HH:mm` (interpreted in `timezone`). */
  cutoffTime: string;
  timezone: string;
  active: boolean;
  /** Opening time of the next settlement window, `HH:mm` (optional display hint). */
  nextWindow?: string;
}

// Operational Levers
export interface OperationalLever {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

// Match Rules
export interface MatchRule {
  id: string;
  name: string;
  criteriaSummary: string;
  criteriaJson: string;
  active: boolean;
}

export type MatchRuleUpsertPayload = Omit<MatchRule, 'id'>;
