import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { DataTable, Switch, cn, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { configApi } from './api';
import type { CutoffTimeRule } from './types';

/** Ticks every `intervalMs`, returning `Date.now()` so consumers re-render live. */
function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(timer);
  }, [intervalMs]);
  return now;
}

type CutoffStatus = 'open' | 'closing' | 'closed';

interface CutoffState {
  status: CutoffStatus;
  label: string;
  countdown: string;
}

/** Minutes-until-cutoff below which the window is flagged "Closing Soon". */
const CLOSING_SOON_MINUTES = 60;

/** Derives live status + countdown from an `HH:mm` cutoff clock time. */
function getCutoffState(cutoffTime: string, now: number): CutoffState {
  const match = /(\d{1,2}):(\d{2})/.exec(cutoffTime);
  if (!match) {
    return { status: 'closed', label: 'Closed', countdown: '—' };
  }

  const target = new Date(now);
  target.setHours(Number(match[1]), Number(match[2]), 0, 0);
  const diffMs = target.getTime() - now;

  if (diffMs <= 0) {
    return { status: 'closed', label: 'Closed', countdown: 'Closed' };
  }

  const totalSeconds = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const countdown = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m ${seconds}s`;

  if (diffMs <= CLOSING_SOON_MINUTES * 60 * 1000) {
    return { status: 'closing', label: 'Closing Soon', countdown };
  }
  return { status: 'open', label: 'Open', countdown };
}

const STATUS_DOT: Record<CutoffStatus, string> = {
  open: 'bg-[var(--success)]',
  closing: 'bg-[var(--warning)]',
  closed: 'bg-[var(--text-muted)]',
};

const STATUS_TEXT: Record<CutoffStatus, string> = {
  open: 'text-[var(--success)]',
  closing: 'text-[var(--warning)]',
  closed: 'text-[var(--text-muted)]',
};

function StatusIndicator({ state }: { state: CutoffState }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 text-xs font-medium', STATUS_TEXT[state.status])}>
      <span className={cn('size-1.5 rounded-full', STATUS_DOT[state.status])} />
      {state.label}
    </span>
  );
}

export function CutoffTimesPage() {
  const queryClient = useQueryClient();
  const now = useNow(1000);

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'cutoffs'],
    queryFn: () => configApi.cutoffs.list({ page: 1, pageSize: 100 }).then((r) => r.data),
  });

  const rules = data?.items ?? [];

  const toggleActive = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) => configApi.cutoffs.setActive(id, active),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['config', 'cutoffs'] }),
  });

  const columns: DataTableColumn<CutoffTimeRule>[] = [
    { key: 'rail', header: 'Rail', sortable: true },
    {
      key: 'cutoffTime',
      header: 'Cutoff',
      render: (row) => <span className="font-mono tabular-nums">{row.cutoffTime}</span>,
    },
    {
      key: 'nextWindow',
      header: 'Next Window',
      render: (row) => <span className="font-mono tabular-nums">{row.nextWindow ?? '—'}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <StatusIndicator state={getCutoffState(row.cutoffTime, now)} />,
    },
    {
      key: 'countdown',
      header: 'Countdown',
      render: (row) => {
        const state = getCutoffState(row.cutoffTime, now);
        return (
          <span className={cn('font-mono font-semibold tabular-nums', STATUS_TEXT[state.status])}>
            {state.countdown}
          </span>
        );
      },
    },
    {
      key: 'active',
      header: 'Active',
      render: (row) => (
        <Switch checked={row.active} onCheckedChange={(checked) => toggleActive.mutate({ id: row.id, active: checked })} />
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Cutoff Times"
        subtitle={
          <>
            Settlement windows · live countdown · {rules.length} rail{rules.length !== 1 ? 's' : ''} configured
          </>
        }
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={rules}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No cutoff rules"
            emptyMessage="No cutoff time rules have been configured."
          />
        </div>
      </PageBody>
    </PageShell>
  );
}
