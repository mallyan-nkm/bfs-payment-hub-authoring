import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Pencil, Plus } from 'lucide-react';
import { Button, DataTable, Switch, Dialog, Input, Select, Badge, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { BadgeVariant, DataTableColumn } from '@paymenthub/ui';
import { configApi } from './api';
import type { FeeCategory, FeeRule, FeeStatus } from './types';

interface FeeFormState {
  id: string | null;
  rail: string;
  category: FeeCategory;
  baseFee: string;
  percentage: string;
  cap: string;
  currency: string;
  status: FeeStatus;
}

const EMPTY_FORM: FeeFormState = {
  id: null,
  rail: 'IPI',
  category: 'per-transaction',
  baseFee: '',
  percentage: '',
  cap: '',
  currency: 'AED',
  status: 'active',
};

const RAIL_OPTIONS = ['UAEFTS', 'IPI', 'IPP', 'WPS', 'SWIFT'].map((r) => ({ label: r, value: r }));

const CATEGORY_LABEL: Record<FeeCategory, string> = {
  'per-transaction': 'Per-Transaction',
  tiered: 'Tiered',
  'flat-fx': 'Flat + FX',
  'per-file': 'Per-File',
};

const CATEGORY_OPTIONS = (Object.keys(CATEGORY_LABEL) as FeeCategory[]).map((c) => ({
  label: CATEGORY_LABEL[c],
  value: c,
}));

const RAIL_VARIANT: Record<string, BadgeVariant> = {
  UAEFTS: 'blue',
  IPI: 'cyan',
  IPP: 'cyan',
  SWIFT: 'purple',
  WPS: 'amber',
};

function money(amount: number | undefined, currency: string): string {
  if (amount == null) return '—';
  return `${currency} ${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/** Draft schedules aren't live yet; everything else follows the active flag. */
function effectiveStatus(fee: FeeRule): FeeStatus {
  return fee.status ?? (fee.active ? 'active' : 'draft');
}

export function FeeManagementPage() {
  const [form, setForm] = useState<FeeFormState | null>(null);
  const queryClient = useQueryClient();

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'fees'],
    queryFn: () => configApi.fees.list({ page: 1, pageSize: 100 }).then((r) => r.data),
  });

  const fees = data?.items ?? [];

  const toggleActive = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) =>
      configApi.fees.upsert(id, { ...fees.find((f) => f.id === id)!, active }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['config', 'fees'] }),
  });

  const upsertMutation = useMutation({
    mutationFn: (f: FeeFormState) => {
      const baseFee = Number(f.baseFee) || 0;
      const percentage = f.percentage.trim() ? Number(f.percentage) : undefined;
      const cap = f.cap.trim() ? Number(f.cap) : undefined;
      return configApi.fees.upsert(f.id, {
        rail: f.rail,
        // Preserve the existing simple pricing wiring…
        feeType: percentage != null ? 'percentage' : 'fixed',
        amount: baseFee,
        currency: f.currency,
        active: f.status === 'active',
        // …and the restored rich taxonomy.
        category: f.category,
        baseFee,
        percentage,
        cap,
        status: f.status,
      });
    },
    onSuccess: () => {
      setForm(null);
      queryClient.invalidateQueries({ queryKey: ['config', 'fees'] });
    },
  });

  function openEdit(fee: FeeRule) {
    setForm({
      id: fee.id,
      rail: fee.rail,
      category: fee.category ?? (fee.feeType === 'percentage' ? 'tiered' : 'per-transaction'),
      baseFee: String(fee.baseFee ?? fee.amount),
      percentage: fee.percentage != null ? String(fee.percentage) : '',
      cap: fee.cap != null ? String(fee.cap) : '',
      currency: fee.currency,
      status: effectiveStatus(fee),
    });
  }

  const columns: DataTableColumn<FeeRule>[] = [
    { key: 'rail', header: 'Rail', sortable: true, render: (row) => <Badge variant={RAIL_VARIANT[row.rail] ?? 'default'}>{row.rail}</Badge> },
    { key: 'category', header: 'Type', render: (row) => CATEGORY_LABEL[row.category ?? 'per-transaction'] },
    { key: 'baseFee', header: 'Base Fee', align: 'right', render: (row) => <span className="font-mono">{money(row.baseFee ?? row.amount, row.currency)}</span> },
    { key: 'percentage', header: 'Percentage', align: 'right', render: (row) => <span className="font-mono">{row.percentage != null ? `${row.percentage}%` : '—'}</span> },
    { key: 'cap', header: 'Cap', align: 'right', render: (row) => <span className="font-mono">{money(row.cap, row.currency)}</span> },
    {
      key: 'status',
      header: 'Status',
      render: (row) => {
        const status = effectiveStatus(row);
        return <Badge variant={status === 'active' ? 'green' : 'amber'}>{status === 'active' ? 'Active' : 'Draft'}</Badge>;
      },
    },
    {
      key: 'active',
      header: 'Active',
      render: (row) => (
        <Switch checked={row.active} onCheckedChange={(checked) => toggleActive.mutate({ id: row.id, active: checked })} />
      ),
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (row) => (
        <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); openEdit(row); }}>
          <Pencil size={14} />
        </Button>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Fee Management"
        subtitle={`Fee schedules · tier configuration · ${fees.length} schedules`}
        actions={
          <Button variant="primary" size="sm" onClick={() => setForm(EMPTY_FORM)}>
            <Plus size={14} /> New Fee Schedule
          </Button>
        }
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={fees}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No fee schedules"
            emptyMessage="No fee schedules have been configured."
          />
        </div>
      </PageBody>

      {form && (
        <Dialog
          open={!!form}
          onOpenChange={(open) => !open && setForm(null)}
          title={form.id ? 'Edit Fee Schedule' : 'New Fee Schedule'}
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setForm(null)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                disabled={!form.baseFee.trim()}
                loading={upsertMutation.isPending}
                onClick={() => upsertMutation.mutate(form)}
              >
                Save
              </Button>
            </>
          }
        >
          <div className="flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-3">
              <Select label="Rail" options={RAIL_OPTIONS} value={form.rail} onValueChange={(v) => setForm({ ...form, rail: v })} />
              <Select
                label="Fee Type"
                options={CATEGORY_OPTIONS}
                value={form.category}
                onValueChange={(v) => setForm({ ...form, category: v as FeeCategory })}
              />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <Input label="Base Fee" type="number" value={form.baseFee} onChange={(e) => setForm({ ...form, baseFee: e.target.value })} />
              <Input
                label="Percentage"
                type="number"
                value={form.percentage}
                helperText="Blank if none"
                onChange={(e) => setForm({ ...form, percentage: e.target.value })}
              />
              <Input
                label="Cap"
                type="number"
                value={form.cap}
                helperText="Blank if uncapped"
                onChange={(e) => setForm({ ...form, cap: e.target.value })}
              />
            </div>
            <Input label="Currency" value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} />
            <div className="flex items-center justify-between rounded-md border border-[var(--border)] px-3 py-2">
              <div>
                <p className="text-sm font-medium text-[var(--text-primary)]">Save as draft</p>
                <p className="text-xs text-[var(--text-muted)]">Draft schedules are not applied to live pricing.</p>
              </div>
              <Switch
                checked={form.status === 'draft'}
                onCheckedChange={(checked) => setForm({ ...form, status: checked ? 'draft' : 'active' })}
              />
            </div>
          </div>
        </Dialog>
      )}
    </PageShell>
  );
}
