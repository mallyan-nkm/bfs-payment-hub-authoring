import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Pencil } from 'lucide-react';
import { Button, DataTable, Switch, Dialog, Input, Textarea, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { configApi } from './api';
import type { ReferenceDataEntry } from './types';

export function ReferenceDataPage() {
  const [editing, setEditing] = useState<ReferenceDataEntry | null>(null);
  const queryClient = useQueryClient();

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'reference-data'],
    queryFn: () => configApi.referenceData.list({ page: 1, pageSize: 100 }).then((r) => r.data),
  });

  const entries = data?.items ?? [];

  const toggleActive = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) =>
      configApi.referenceData.update(id, { active }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['config', 'reference-data'] }),
  });

  const saveEdit = useMutation({
    mutationFn: (entry: ReferenceDataEntry) =>
      configApi.referenceData.update(entry.id, {
        value: entry.value,
        description: entry.description,
      }),
    onSuccess: () => {
      setEditing(null);
      queryClient.invalidateQueries({ queryKey: ['config', 'reference-data'] });
    },
  });

  const columns: DataTableColumn<ReferenceDataEntry>[] = [
    { key: 'category', header: 'Category', sortable: true },
    { key: 'code', header: 'Code' },
    { key: 'value', header: 'Value' },
    { key: 'description', header: 'Description' },
    {
      key: 'active',
      header: 'Active',
      render: (row) => (
        <Switch
          checked={row.active}
          onCheckedChange={(checked) => toggleActive.mutate({ id: row.id, active: checked })}
        />
      ),
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (row) => (
        <Button
          variant="ghost"
          size="sm"
          onClick={(e) => {
            e.stopPropagation();
            setEditing(row);
          }}
        >
          <Pencil size={14} />
        </Button>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Reference Data"
        subtitle={<>{entries.length} entr{entries.length !== 1 ? 'ies' : 'y'}</>}
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={entries}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No reference data"
            emptyMessage="No reference data entries have been configured."
          />
        </div>
      </PageBody>

      {editing && (
        <Dialog
          open={!!editing}
          onOpenChange={(open) => !open && setEditing(null)}
          title={`Edit ${editing.code}`}
          description={editing.category}
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setEditing(null)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => saveEdit.mutate(editing)}
                loading={saveEdit.isPending}
              >
                Save
              </Button>
            </>
          }
        >
          <div className="flex flex-col gap-3">
            <Input
              label="Value"
              value={editing.value}
              onChange={(e) => setEditing({ ...editing, value: e.target.value })}
            />
            <Textarea
              label="Description"
              value={editing.description}
              onChange={(e) => setEditing({ ...editing, description: e.target.value })}
              rows={3}
            />
          </div>
        </Dialog>
      )}
    </PageShell>
  );
}
