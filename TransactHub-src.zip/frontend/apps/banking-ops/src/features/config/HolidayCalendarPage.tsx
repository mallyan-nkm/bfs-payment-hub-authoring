import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { Button, DataTable, Dialog, Input, Select, DateRangePicker, PageShell, PageHeader, PageToolbar, PageBody } from '@paymenthub/ui';
import type { DataTableColumn, DateRange } from '@paymenthub/ui';
import { configApi } from './api';
import type { Holiday } from './types';

const MARKET_OPTIONS = ['UAE', 'KSA', 'EGY', 'GBR', 'USA'].map((m) => ({ label: m, value: m }));

export function HolidayCalendarPage() {
  const [dateRange, setDateRange] = useState<DateRange>({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [date, setDate] = useState('');
  const [name, setName] = useState('');
  const [market, setMarket] = useState('UAE');
  const queryClient = useQueryClient();

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'holidays', dateRange],
    queryFn: () =>
      configApi.holidays.list({ page: 1, pageSize: 100, from: dateRange.from, to: dateRange.to }).then((r) => r.data),
  });

  const holidays = data?.items ?? [];

  const createMutation = useMutation({
    mutationFn: () => configApi.holidays.create({ date, name, market }),
    onSuccess: () => {
      setDialogOpen(false);
      setDate('');
      setName('');
      queryClient.invalidateQueries({ queryKey: ['config', 'holidays'] });
    },
  });

  const columns: DataTableColumn<Holiday>[] = [
    { key: 'date', header: 'Date', sortable: true, kind: 'calendarDate' },
    { key: 'name', header: 'Holiday' },
    { key: 'market', header: 'Market/Country' },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Holiday Calendar"
        subtitle={`${holidays.length} holidays`}
        actions={
          <Button variant="primary" size="sm" onClick={() => setDialogOpen(true)}>
            <Plus size={14} /> Add Holiday
          </Button>
        }
      />

      <PageToolbar>
        <DateRangePicker value={dateRange} onChange={setDateRange} label="Filter by date range" />
      </PageToolbar>

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={holidays}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No holidays"
            emptyMessage="No holidays found for the selected range."
          />
        </div>
      </PageBody>

      <Dialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title="Add Holiday"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              disabled={!date || !name.trim()}
              loading={createMutation.isPending}
              onClick={() => createMutation.mutate()}
            >
              Add
            </Button>
          </>
        }
      >
        <div className="flex flex-col gap-3">
          <Input label="Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          <Input label="Name" value={name} onChange={(e) => setName(e.target.value)} />
          <Select label="Market" options={MARKET_OPTIONS} value={market} onValueChange={setMarket} />
        </div>
      </Dialog>
    </PageShell>
  );
}
