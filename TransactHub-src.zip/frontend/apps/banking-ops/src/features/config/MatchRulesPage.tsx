import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Pencil, Plus } from 'lucide-react';
import { Button, DataTable, Switch, Dialog, Input, CodeEditor, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { configApi } from './api';
import type { MatchRule } from './types';

interface MatchRuleFormState {
  id: string | null;
  name: string;
  criteriaSummary: string;
  criteriaJson: string;
  active: boolean;
}

const EMPTY_FORM: MatchRuleFormState = { id: null, name: '', criteriaSummary: '', criteriaJson: '{}', active: true };

export function MatchRulesPage() {
  const [form, setForm] = useState<MatchRuleFormState | null>(null);
  const queryClient = useQueryClient();

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'match-rules'],
    queryFn: () => configApi.matchRules.list({ page: 1, pageSize: 100 }).then((r) => r.data),
  });

  const rules = data?.items ?? [];

  const toggleActive = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) => {
      const existing = rules.find((r) => r.id === id)!;
      return configApi.matchRules.upsert(id, {
        name: existing.name,
        criteriaSummary: existing.criteriaSummary,
        criteriaJson: existing.criteriaJson,
        active,
      });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['config', 'match-rules'] }),
  });

  const upsertMutation = useMutation({
    mutationFn: (f: MatchRuleFormState) =>
      configApi.matchRules.upsert(f.id, {
        name: f.name,
        criteriaSummary: f.criteriaSummary,
        criteriaJson: f.criteriaJson,
        active: f.active,
      }),
    onSuccess: () => {
      setForm(null);
      queryClient.invalidateQueries({ queryKey: ['config', 'match-rules'] });
    },
  });

  function openEdit(rule: MatchRule) {
    setForm({ id: rule.id, name: rule.name, criteriaSummary: rule.criteriaSummary, criteriaJson: rule.criteriaJson, active: rule.active });
  }

  const columns: DataTableColumn<MatchRule>[] = [
    { key: 'name', header: 'Name' },
    { key: 'criteriaSummary', header: 'Criteria' },
    {
      key: 'active',
      header: 'Active',
      render: (row) => (
        <Switch checked={row.active} onCheckedChange={(checked) => toggleActive.mutate({ id: row.id, active: checked })} />
      ),
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (row) => (
        <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); openEdit(row); }}>
          <Pencil size={14} />
        </Button>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Reconciliation Match Rules"
        subtitle={`${rules.length} rules`}
        actions={
          <Button variant="primary" size="sm" onClick={() => setForm(EMPTY_FORM)}>
            <Plus size={14} /> New Match Rule
          </Button>
        }
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={rules}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No match rules"
            emptyMessage="No reconciliation match rules have been configured."
          />
        </div>
      </PageBody>

      {form && (
        <Dialog
          open={!!form}
          onOpenChange={(open) => !open && setForm(null)}
          title={form.id ? 'Edit Match Rule' : 'New Match Rule'}
          maxWidth="sm:max-w-2xl"
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setForm(null)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                disabled={!form.name.trim()}
                loading={upsertMutation.isPending}
                onClick={() => upsertMutation.mutate(form)}
              >
                Save
              </Button>
            </>
          }
        >
          <div className="flex flex-col gap-3">
            <Input label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <Input
              label="Criteria Summary"
              value={form.criteriaSummary}
              onChange={(e) => setForm({ ...form, criteriaSummary: e.target.value })}
            />
            <CodeEditor
              label="Matching Criteria (JSON)"
              value={form.criteriaJson}
              onChange={(value) => setForm({ ...form, criteriaJson: value })}
              language="json"
            />
          </div>
        </Dialog>
      )}
    </PageShell>
  );
}
