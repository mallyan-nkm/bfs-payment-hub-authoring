import { bankingApi } from '../../shared/api/bankingApi';
import type { PaginatedResponse } from '@paymenthub/ui';
import type {
  CutoffTimeRule,
  FeeRule,
  FeeRuleUpsertPayload,
  Holiday,
  HolidayCreatePayload,
  MaintenanceCreatePayload,
  MaintenanceWindow,
  MatchRule,
  MatchRuleUpsertPayload,
  OperationalLever,
  ReferenceDataEntry,
  WebhookSubscription,
  WebhookUpsertPayload,
} from './types';

export interface ListParams {
  page?: number;
  pageSize?: number;
}

export const configApi = {
  referenceData: {
    list: (params: ListParams) =>
      bankingApi.get<PaginatedResponse<ReferenceDataEntry>>('/config/reference-data', { params }),
    update: (id: string, body: Partial<ReferenceDataEntry>) =>
      bankingApi.put<ReferenceDataEntry>(`/config/reference-data/${id}`, body),
  },

  maintenance: {
    list: (params: ListParams) =>
      bankingApi.get<PaginatedResponse<MaintenanceWindow>>('/config/maintenance-windows', { params }),
    create: (body: MaintenanceCreatePayload) =>
      bankingApi.post<MaintenanceWindow>('/config/maintenance-windows', body),
  },

  webhooks: {
    list: (params: ListParams) =>
      bankingApi.get<PaginatedResponse<WebhookSubscription>>('/config/webhooks', { params }),
    upsert: (id: string | null, body: WebhookUpsertPayload) =>
      id
        ? bankingApi.put<WebhookSubscription>(`/config/webhooks/${id}`, body)
        : bankingApi.post<WebhookSubscription>('/config/webhooks', body),
    setActive: (id: string, active: boolean) =>
      bankingApi.patch<WebhookSubscription>(`/config/webhooks/${id}`, { active }),
  },

  fees: {
    list: (params: ListParams) =>
      bankingApi.get<PaginatedResponse<FeeRule>>('/config/fee-rules', { params }),
    upsert: (id: string | null, body: FeeRuleUpsertPayload) =>
      id
        ? bankingApi.put<FeeRule>(`/config/fee-rules/${id}`, body)
        : bankingApi.post<FeeRule>('/config/fee-rules', body),
  },

  holidays: {
    list: (params: ListParams & { from?: string; to?: string }) =>
      bankingApi.get<PaginatedResponse<Holiday>>('/config/holidays', { params }),
    create: (body: HolidayCreatePayload) => bankingApi.post<Holiday>('/config/holidays', body),
  },

  cutoffs: {
    list: (params: ListParams) =>
      bankingApi.get<PaginatedResponse<CutoffTimeRule>>('/config/cutoff-times', { params }),
    setActive: (id: string, active: boolean) =>
      bankingApi.patch<CutoffTimeRule>(`/config/cutoff-times/${id}`, { active }),
  },

  levers: {
    list: () => bankingApi.get<OperationalLever[]>('/config/operational-levers'),
    toggle: (id: string, enabled: boolean) =>
      bankingApi.patch<OperationalLever>(`/config/operational-levers/${id}`, { enabled }),
  },

  matchRules: {
    list: (params: ListParams) =>
      bankingApi.get<PaginatedResponse<MatchRule>>('/config/match-rules', { params }),
    upsert: (id: string | null, body: MatchRuleUpsertPayload) =>
      id
        ? bankingApi.put<MatchRule>(`/config/match-rules/${id}`, body)
        : bankingApi.post<MatchRule>('/config/match-rules', body),
  },
};
