import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { Button, DataTable, Badge, Dialog, Input, PageShell, PageHeader, PageBody, DEFAULT_TIME_ZONE, formatInstant, zoneLabel, useSessionDateTime } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { configApi } from './api';
import type { MaintenanceStatus, MaintenanceWindow } from './types';

const STATUS_VARIANT: Record<MaintenanceStatus, 'green' | 'amber' | 'outline' | 'red'> = {
  scheduled: 'amber',
  'in-progress': 'green',
  completed: 'outline',
  cancelled: 'red',
};

export function MaintenancePage() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [startAt, setStartAt] = useState('');
  const [endAt, setEndAt] = useState('');
  const queryClient = useQueryClient();

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'maintenance'],
    queryFn: () => configApi.maintenance.list({ page: 1, pageSize: 100 }).then((r) => r.data),
  });

  const windows = data?.items ?? [];

  const createMutation = useMutation({
    // A maintenance window is a bank schedule (UTC date-time design §4, INV-09): its wall time belongs to the bank
    // zone. /api/config/maintenance has no backend yet (§6.5 note), so the datetime-local value is sent as entered;
    // the bank-zone conversion belongs to that backend when it exists (T-22).
    mutationFn: () => configApi.maintenance.create({ title, startAt, endAt }),
    onSuccess: () => {
      setDialogOpen(false);
      setTitle('');
      setStartAt('');
      setEndAt('');
      queryClient.invalidateQueries({ queryKey: ['config', 'maintenance'] });
    },
  });

  // Shown in the BANK zone, labelled (design §4: a bank schedule is displayed in the bank zone, not the session zone).
  // The bank schedule zone is iam.user.timezone, whose default is DEFAULT_TIME_ZONE; BankingOps has no other source
  // for it until OD-10 makes DefaultTimeZone the single bank zone. `kind` stays for sorting on the instant (PF-6).
  const { locale } = useSessionDateTime();
  const bankZone = { timeZone: DEFAULT_TIME_ZONE, locale };
  const bankZoneLabel = zoneLabel(DEFAULT_TIME_ZONE, locale);
  const columns: DataTableColumn<MaintenanceWindow>[] = [
    { key: 'title', header: 'Title' },
    {
      key: 'startAt',
      header: `Start (bank time, ${bankZoneLabel})`,
      sortable: true,
      kind: 'instant',
      render: (row) => formatInstant(row.startAt, bankZone),
    },
    {
      key: 'endAt',
      header: `End (bank time, ${bankZoneLabel})`,
      kind: 'instant',
      render: (row) => formatInstant(row.endAt, bankZone),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge variant={STATUS_VARIANT[row.status]}>{row.status}</Badge>,
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Maintenance Windows"
        subtitle={`${windows.length} scheduled`}
        actions={
          <Button variant="primary" size="sm" onClick={() => setDialogOpen(true)}>
            <Plus size={14} /> Schedule Maintenance
          </Button>
        }
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={windows}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No maintenance windows"
            emptyMessage="No maintenance windows have been scheduled."
          />
        </div>
      </PageBody>

      <Dialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title="Schedule Maintenance"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              disabled={!title.trim() || !startAt || !endAt}
              loading={createMutation.isPending}
              onClick={() => createMutation.mutate()}
            >
              Schedule
            </Button>
          </>
        }
      >
        <div className="flex flex-col gap-3">
          <Input label="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Input
            label="Start"
            type="datetime-local"
            value={startAt}
            onChange={(e) => setStartAt(e.target.value)}
          />
          <Input label="End" type="datetime-local" value={endAt} onChange={(e) => setEndAt(e.target.value)} />
        </div>
      </Dialog>
    </PageShell>
  );
}
