import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Pencil, Plus } from 'lucide-react';
import { Button, DataTable, Switch, Dialog, Input, CodeEditor, Badge, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { configApi } from './api';
import type { WebhookSubscription } from './types';

interface WebhookFormState {
  id: string | null;
  url: string;
  eventsCsv: string;
  active: boolean;
  payloadTemplate: string;
}

const EMPTY_FORM: WebhookFormState = { id: null, url: '', eventsCsv: '', active: true, payloadTemplate: '{}' };

export function WebhookPage() {
  const [form, setForm] = useState<WebhookFormState | null>(null);
  const queryClient = useQueryClient();

  const { data, isFetching } = useQuery({
    queryKey: ['config', 'webhooks'],
    queryFn: () => configApi.webhooks.list({ page: 1, pageSize: 100 }).then((r) => r.data),
  });

  const webhooks = data?.items ?? [];

  const toggleActive = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) => configApi.webhooks.setActive(id, active),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['config', 'webhooks'] }),
  });

  const upsertMutation = useMutation({
    mutationFn: (f: WebhookFormState) =>
      configApi.webhooks.upsert(f.id, {
        url: f.url,
        events: f.eventsCsv.split(',').map((e) => e.trim()).filter(Boolean),
        active: f.active,
        payloadTemplate: f.payloadTemplate,
      }),
    onSuccess: () => {
      setForm(null);
      queryClient.invalidateQueries({ queryKey: ['config', 'webhooks'] });
    },
  });

  function openEdit(webhook: WebhookSubscription) {
    setForm({
      id: webhook.id,
      url: webhook.url,
      eventsCsv: webhook.events.join(', '),
      active: webhook.active,
      payloadTemplate: webhook.payloadTemplate,
    });
  }

  const columns: DataTableColumn<WebhookSubscription>[] = [
    { key: 'url', header: 'URL' },
    { key: 'events', header: 'Events', render: (row) => row.events.map((e) => <Badge key={e} variant="outline" className="mr-1">{e}</Badge>) },
    {
      key: 'active',
      header: 'Status',
      render: (row) => (
        <Switch checked={row.active} onCheckedChange={(checked) => toggleActive.mutate({ id: row.id, active: checked })} />
      ),
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (row) => (
        <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); openEdit(row); }}>
          <Pencil size={14} />
        </Button>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Webhook Subscriptions"
        subtitle={`${webhooks.length} subscriptions`}
        actions={
          <Button variant="primary" size="sm" onClick={() => setForm(EMPTY_FORM)}>
            <Plus size={14} /> New Webhook
          </Button>
        }
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={webhooks}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No webhooks"
            emptyMessage="No webhook subscriptions configured."
          />
        </div>
      </PageBody>

      {form && (
        <Dialog
          open={!!form}
          onOpenChange={(open) => !open && setForm(null)}
          title={form.id ? 'Edit Webhook' : 'New Webhook'}
          maxWidth="sm:max-w-2xl"
          footer={
            <>
              <Button variant="ghost" size="sm" onClick={() => setForm(null)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                disabled={!form.url.trim()}
                loading={upsertMutation.isPending}
                onClick={() => upsertMutation.mutate(form)}
              >
                Save
              </Button>
            </>
          }
        >
          <div className="flex flex-col gap-3">
            <Input label="URL" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
            <Input
              label="Events (comma separated)"
              value={form.eventsCsv}
              onChange={(e) => setForm({ ...form, eventsCsv: e.target.value })}
              placeholder="payment.completed, payment.failed"
            />
            <CodeEditor
              label="Payload Template"
              value={form.payloadTemplate}
              onChange={(value) => setForm({ ...form, payloadTemplate: value })}
              language="json"
            />
          </div>
        </Dialog>
      )}
    </PageShell>
  );
}
