import { bankingApi } from '../../shared/api/bankingApi';
import { toUtcRangeParams } from '@paymenthub/ui';
import type { PaginatedResponse } from '@paymenthub/ui';
import type {
  GeneratedReport,
  ScheduledReport,
  RegulatoryReport,
  NewScheduleRequest,
  ReportingListParams,
} from './types';

/**
 * Report Builder expression shape authored in the UI. Only the `platform.Transactions`
 * source with simple field/op/value filters is translatable to the real reporting API.
 */
interface BuilderExpression {
  source?: string;
  filters?: { field: string; op?: string; value?: unknown }[];
  fields?: string[];
}

interface ReportExecuteResponse {
  items: Record<string, unknown>[];
  total: number;
}

export const reportingApi = {
  // ── Report Builder ── real: POST /api/reports/execute (transaction reports).
  // The builder's ad-hoc {source,filters,fields} DSL is mapped to the fixed
  // ReportExecuteRequest contract; the transaction source's status/date/tenant
  // filters are honoured. Arbitrary sources/field projections are not (the backend
  // returns a fixed transaction column set).
  runQuery: async (expression: string) => {
    let parsed: BuilderExpression = {};
    try {
      parsed = JSON.parse(expression) as BuilderExpression;
    } catch {
      parsed = {};
    }
    const filters = Array.isArray(parsed.filters) ? parsed.filters : [];
    const valueOf = (field: string): string | undefined => {
      const match = filters.find((f) => f.field === field);
      return match?.value != null ? String(match.value) : undefined;
    };
    // Session-zone days as UTC [from, to) (UTC date-time T-22); the server reads instants as given and maps
    // them back to session days for the day-keyed snapshot Period.
    const window = toUtcRangeParams(valueOf('dateFrom'), valueOf('dateTo'));
    const body = {
      status: valueOf('status'),
      scheme: valueOf('scheme') ?? valueOf('rail') ?? valueOf('schemaType'),
      dateFrom: window.from,
      dateTo: window.to,
      tenantId: valueOf('tenantId'),
    };
    const res = await bankingApi.post<ReportExecuteResponse>('/reports/execute', body);
    return { ...res, data: res.data.items };
  },

  // ── Tier 2 (no backend yet) ──────────────────────────────────────────────────
  // The generated-report history, scheduled-report definitions, and regulatory
  // submission list have no Operations API endpoint. The `regulatory.Submissions`
  // and `platform.ReportExecutions`/`ReportSnapshots` tables exist, but no service
  // reads them yet. These stay on their intended routes until the backend is built;
  // pages render their empty state in the meantime.
  listGenerated: (params: ReportingListParams) =>
    bankingApi.get<PaginatedResponse<GeneratedReport>>('/reporting/generated', { params }),

  listScheduled: () => bankingApi.get<ScheduledReport[]>('/reporting/scheduled'),

  createSchedule: (payload: NewScheduleRequest) =>
    bankingApi.post<ScheduledReport>('/reporting/scheduled', payload),

  toggleSchedule: (id: string, enabled: boolean) =>
    bankingApi.patch<ScheduledReport>(`/reporting/scheduled/${id}`, { enabled }),

  listRegulatory: (params: ReportingListParams) =>
    bankingApi.get<PaginatedResponse<RegulatoryReport>>('/reporting/regulatory', { params }),
};
