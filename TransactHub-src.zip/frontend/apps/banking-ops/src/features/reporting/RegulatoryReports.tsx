import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DataTable, DateRangePicker, StatusBadge, PageShell, PageHeader, PageToolbar, PageBody } from '@paymenthub/ui';
import type { DataTableColumn, DateRange } from '@paymenthub/ui';
import { reportingApi } from './api';
import type { RegulatoryReport } from './types';

export function RegulatoryReports() {
  const [range, setRange] = useState<DateRange>({});

  const { data, isFetching } = useQuery({
    queryKey: ['reporting-regulatory', range],
    queryFn: () =>
      reportingApi
        .listRegulatory({ page: 1, pageSize: 20, dateFrom: range.from, dateTo: range.to })
        .then((r) => r.data),
  });

  const reports = data?.items ?? [];

  const columns: DataTableColumn<RegulatoryReport>[] = [
    { key: 'reportType', header: 'Report Type' },
    { key: 'period', header: 'Period' },
    { key: 'status', header: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    {
      key: 'submittedAt',
      header: 'Submitted At',
      kind: 'instant',
    },
    { key: 'reference', header: 'Reference', render: (r) => <span className="font-mono text-xs">{r.reference}</span> },
  ];

  return (
    <PageShell>
      <PageHeader title="Regulatory Reports" subtitle="CBUAE filings and regulatory submissions" />

      <PageToolbar>
        <DateRangePicker value={range} onChange={setRange} />
      </PageToolbar>

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={reports}
            rowKey={(r) => r.id}
            loading={isFetching}
            emptyTitle="No regulatory reports"
            emptyMessage="No regulatory submissions found for the selected period."
          />
        </div>
      </PageBody>
    </PageShell>
  );
}
