import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import {
  Button,
  Dialog,
  DataTable,
  Input,
  Select,
  Switch,
  PageShell,
  PageHeader,
  PageBody,
} from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { reportingApi } from './api';
import type { ScheduledReport, NewScheduleRequest, ScheduleFrequency } from './types';

const FREQUENCY_OPTIONS: { label: string; value: ScheduleFrequency }[] = [
  { label: 'Daily', value: 'Daily' },
  { label: 'Weekly', value: 'Weekly' },
  { label: 'Monthly', value: 'Monthly' },
];

const emptyForm: NewScheduleRequest = { name: '', frequency: 'Daily', reportType: '' };

export function ScheduledReports() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<NewScheduleRequest>(emptyForm);

  const { data: schedules = [], isFetching } = useQuery({
    queryKey: ['reporting-scheduled'],
    queryFn: () => reportingApi.listScheduled().then((r) => r.data),
  });

  const createMutation = useMutation({
    mutationFn: (payload: NewScheduleRequest) => reportingApi.createSchedule(payload),
    onSuccess: () => {
      setDialogOpen(false);
      setForm(emptyForm);
      queryClient.invalidateQueries({ queryKey: ['reporting-scheduled'] });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, enabled }: { id: string; enabled: boolean }) => reportingApi.toggleSchedule(id, enabled),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reporting-scheduled'] });
    },
  });

  const columns: DataTableColumn<ScheduledReport>[] = [
    { key: 'name', header: 'Name' },
    { key: 'frequency', header: 'Frequency' },
    { key: 'nextRun', header: 'Next Run', kind: 'instant' },
    {
      key: 'lastRun',
      header: 'Last Run',
      kind: 'instant',
    },
    {
      key: 'enabled',
      header: 'Status',
      render: (r) => (
        <Switch
          checked={r.enabled}
          onCheckedChange={(checked) => toggleMutation.mutate({ id: r.id, enabled: checked })}
          disabled={toggleMutation.isPending}
        />
      ),
    },
  ];

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    createMutation.mutate(form);
  }

  return (
    <PageShell>
      <PageHeader
        title="Scheduled Reports"
        subtitle="Recurring report definitions"
        actions={
          <Button variant="primary" size="sm" onClick={() => setDialogOpen(true)}>
            <Plus size={14} /> New Schedule
          </Button>
        }
      />

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={schedules}
            rowKey={(r) => r.id}
            loading={isFetching}
            emptyTitle="No scheduled reports"
            emptyMessage="No recurring report schedules have been defined yet."
          />
        </div>
      </PageBody>

      <Dialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title="New Schedule"
        description="Define a new recurring report schedule."
        footer={
          <>
            <Button variant="secondary" size="sm" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" loading={createMutation.isPending} onClick={handleSubmit}>
              Create Schedule
            </Button>
          </>
        }
      >
        <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
          <Input
            label="Name"
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
          />
          <Input
            label="Report Type"
            value={form.reportType}
            onChange={(e) => setForm((f) => ({ ...f, reportType: e.target.value }))}
          />
          <Select
            label="Frequency"
            options={FREQUENCY_OPTIONS}
            value={form.frequency}
            onValueChange={(v) => setForm((f) => ({ ...f, frequency: v as ScheduleFrequency }))}
          />
          {createMutation.isError && (
            <p className="text-xs text-[var(--accent-red)]">Failed to create schedule. Please try again.</p>
          )}
        </form>
      </Dialog>
    </PageShell>
  );
}
