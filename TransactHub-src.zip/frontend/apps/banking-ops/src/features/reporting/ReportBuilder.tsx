import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Play } from 'lucide-react';
import { Button, CodeEditor, DataTable, LoadingSpinner, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { reportingApi } from './api';

const DEFAULT_EXPRESSION = JSON.stringify(
  {
    source: 'platform.Transactions',
    filters: [{ field: 'status', op: 'eq', value: 'COMPLETED' }],
    fields: ['transactionId', 'amount', 'currency', 'status'],
  },
  null,
  2,
);

export function ReportBuilder() {
  const [expression, setExpression] = useState(DEFAULT_EXPRESSION);

  const runMutation = useMutation({
    mutationFn: (expr: string) => reportingApi.runQuery(expr).then((r) => r.data),
  });

  const rows = runMutation.data ?? [];
  const columns: DataTableColumn<Record<string, unknown>>[] =
    rows.length > 0
      ? Object.keys(rows[0]).map((key) => ({
          key,
          header: key,
          render: (row: Record<string, unknown>) => String(row[key] ?? ''),
        }))
      : [];

  let isValidJson = true;
  try {
    JSON.parse(expression);
  } catch {
    isValidJson = false;
  }

  return (
    <PageShell>
      <PageHeader
        title="Report Builder"
        subtitle="Author a query expression and run it ad hoc"
        actions={
          <Button
            variant="primary"
            size="sm"
            disabled={!isValidJson}
            loading={runMutation.isPending}
            onClick={() => runMutation.mutate(expression)}
          >
            <Play size={14} /> Run
          </Button>
        }
      />

      <PageBody className="space-y-6">
        <CodeEditor
          label="Query Expression"
          value={expression}
          onChange={setExpression}
          language="json"
          validateJson
          minHeight="220px"
        />

        <div>
          <h2 className="text-sm font-semibold text-[var(--text-primary)] mb-3">Results</h2>
          {runMutation.isPending ? (
            <div className="flex justify-center py-12"><LoadingSpinner /></div>
          ) : runMutation.isError ? (
            <p className="text-sm text-[var(--accent-red)]">Failed to run query. Please check the expression and try again.</p>
          ) : (
            <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
              <DataTable
                columns={columns}
                data={rows}
                rowKey={(row) => JSON.stringify(row)}
                emptyTitle="No results"
                emptyMessage="Run a query to see results here."
              />
            </div>
          )}
        </div>
      </PageBody>
    </PageShell>
  );
}
