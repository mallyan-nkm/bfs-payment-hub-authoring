export type GeneratedReportStatus = 'COMPLETED' | 'PROCESSING' | 'FAILED';

export interface GeneratedReport {
  id: string;
  name: string;
  type: string;
  generatedAt: string;
  generatedBy: string;
  status: GeneratedReportStatus;
  downloadUrl?: string;
}

export type ScheduleFrequency = 'Daily' | 'Weekly' | 'Monthly';

export interface ScheduledReport {
  id: string;
  name: string;
  frequency: ScheduleFrequency;
  nextRun: string;
  lastRun: string | null;
  enabled: boolean;
}

export interface NewScheduleRequest {
  name: string;
  frequency: ScheduleFrequency;
  reportType: string;
}

export type RegulatoryReportStatus = 'SUBMITTED' | 'PENDING' | 'REJECTED' | 'ACCEPTED';

export interface RegulatoryReport {
  id: string;
  reportType: string;
  period: string;
  status: RegulatoryReportStatus;
  submittedAt: string | null;
  reference: string;
}

export interface ReportingListParams {
  page?: number;
  pageSize?: number;
  dateFrom?: string;
  dateTo?: string;
}
