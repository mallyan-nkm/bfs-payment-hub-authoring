import { useState } from 'react';
import { Button, Can } from '@paymenthub/ui';
import { AlertTriangle, ChevronDown } from 'lucide-react';
import { PERM } from '../../shared/auth/permissionKeys';
import { useRailImpact } from './api';
import { railErrorMessage } from './errors';
import { PanelError } from './formParts';
import { useRailTranslation } from './i18n';
import { PII_FEATURE_CODE, RAIL_IMPACT_CHANGE } from './types';
import type { RailFeature, RailImpactChange, RailImpactParams, RailImpactPreview, RailPiiImpactPreview } from './types';

/** A preview the Maker ran: what it was asked, whether it stops the save, and the figures (sent as `impactSummary`). */
export interface StatusPreview {
  change: RailImpactChange;
  blocked: boolean;
  data: RailImpactPreview;
}

export interface PiiPreview {
  enable: boolean;
  data: RailPiiImpactPreview;
}

/**
 * Whether a rail preview stops the save (design §5.2, §8.4.6): re-enabling is blocked while a role's own IAM
 * request is pending; disabling is blocked while the reconciler is still working on the rail.
 */
export function isBlocked(change: RailImpactChange, data: RailImpactPreview): boolean {
  return change === RAIL_IMPACT_CHANGE.Enable ? data.blocking.length > 0 : data.reconcileInProgress;
}

const box = 'mt-2 rounded-lg border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2 text-xs text-[var(--text-2)]';

/** Runs one on-demand preview. The IAM route is write/approve-gated, so the button sits inside `<Can railWrite>`. */
function PreviewButton({
  params,
  onData,
}: {
  params: RailImpactParams;
  onData: (data: RailImpactPreview | RailPiiImpactPreview) => void;
}) {
  const { t } = useRailTranslation();
  const impact = useRailImpact();
  return (
    <Can permission={PERM.railWrite}>
      <div className="mt-2">
        {impact.isError && <PanelError message={railErrorMessage(impact.error, t('IMPACT.PREVIEW_FAILED'))} />}
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={impact.isPending}
          onClick={() => impact.mutate(params, { onSuccess: onData })}
        >
          {impact.isPending ? t('IMPACT.PREVIEWING') : t('IMPACT.PREVIEW')}
        </Button>
      </div>
    </Can>
  );
}

/** The figures of a rail preview: what a disable takes away, or what an enable restores and what stops it. */
function StatusFigures({ change, data }: { change: RailImpactChange; data: RailImpactPreview }) {
  const { t } = useRailTranslation();
  const disabling = change === RAIL_IMPACT_CHANGE.Disable;
  return (
    <div className={box} role="status">
      <p className="font-semibold text-[var(--text-primary)]">
        {t(disabling ? 'IMPACT.DISABLE_HEADING' : 'IMPACT.ENABLE_HEADING')}
      </p>
      {disabling ? (
        <p>
          {t('IMPACT.ROLES', {
            count: data.directRoles + data.wildcardRoles + data.overlayRoles,
            direct: data.directRoles,
            wildcard: data.wildcardRoles,
            overlay: data.overlayRoles,
          })}
        </p>
      ) : (
        <>
          <p>{t('IMPACT.ROLES_COUNT', { count: data.roles.length })}</p>
          <p>{t('IMPACT.RESTORE', { count: data.restore })}</p>
          <p>{t('IMPACT.SKIPPED', { count: data.skipped })}</p>
        </>
      )}
      <p>{t('IMPACT.USERS', { count: data.users })}</p>
      {data.roles.length > 0 && <p className="mt-1 break-words text-[11px]">{data.roles.join(', ')}</p>}
      {disabling && <p className="mt-1 text-[11px]">{t('IMPACT.DISABLE_NOTE')}</p>}

      {!disabling && data.blocking.length > 0 && (
        <div role="alert" className="mt-2 text-[var(--accent-red)]">
          <p className="font-semibold">{t('IMPACT.BLOCKING')}</p>
          <ul className="list-disc ps-4">
            {data.blocking.map((b) => (
              <li key={`${b.roleName}-${b.requestId}`}>
                {t('IMPACT.BLOCKING_ITEM', { role: b.roleName, requestId: b.requestId })}
              </li>
            ))}
          </ul>
        </div>
      )}
      {disabling && data.reconcileInProgress && (
        <p role="alert" className="mt-2 text-[var(--accent-red)]">
          {t('IMPACT.RECONCILING')}
        </p>
      )}
    </div>
  );
}

/**
 * The Impact Area of the rail's own status (Active ⇄ Disabled), shown once the Maker has changed it. The preview is
 * on demand and never runs for PLATFORM, whose status is read-only (design decision 3).
 */
export function RailStatusImpact({
  railCode,
  change,
  preview,
  onPreview,
}: {
  railCode: string;
  change: RailImpactChange;
  preview: StatusPreview | null;
  onPreview: (preview: StatusPreview) => void;
}) {
  const { t } = useRailTranslation();
  // A preview of the other direction is stale, so it is not shown.
  const current = preview?.change === change ? preview : null;
  return (
    <section aria-label={t('IMPACT.TITLE')} className="mt-3">
      <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-primary)]">{t('IMPACT.TITLE')}</p>
      <PreviewButton
        params={{ kind: 'rail', rail: railCode, change }}
        onData={(data) =>
          onPreview({ change, blocked: isBlocked(change, data as RailImpactPreview), data: data as RailImpactPreview })
        }
      />
      {current && <StatusFigures change={change} data={current.data} />}
    </section>
  );
}

function PiiFigures({ data, enable }: { data: RailPiiImpactPreview; enable: boolean }) {
  const { t } = useRailTranslation();
  return (
    <div className={box} role="status">
      {data.fields.length === 0 ? (
        <p>{t('IMPACT.PII_NONE')}</p>
      ) : (
        <>
          <p className="flex items-start gap-1.5 text-[var(--accent-amber)]">
            <AlertTriangle size={14} className="mt-0.5 shrink-0" aria-hidden="true" />
            {t('IMPACT.PII_WARNING')}
          </p>
          <ul className="mt-1 list-disc ps-4">
            {data.fields.map((f) => (
              <li key={f.viewKey}>
                {t('IMPACT.PII_FIELD', { field: f.viewKey, roles: f.roles.length, users: f.users })}
              </li>
            ))}
          </ul>
          <p className="mt-1">{t('IMPACT.PII_USERS', { count: data.users })}</p>
        </>
      )}
      {!enable && <p className="mt-1 text-[11px]">{t('IMPACT.PII_SIF_NOTE')}</p>}
    </div>
  );
}

/**
 * One feature's Impact Area expander: its static text and the rails it is core for, from the detail. PII on PLATFORM
 * adds the IAM preview (PII mode); no other feature has an IAM preview, and rail mode is never called here.
 */
export function FeatureImpact({
  feature,
  isPlatform,
  preview,
  onPreview,
}: {
  feature: RailFeature;
  isPlatform: boolean;
  preview: PiiPreview | null;
  onPreview: (preview: PiiPreview) => void;
}) {
  const { t } = useRailTranslation();
  const [open, setOpen] = useState(false);
  const panelId = `impact-${feature.featureCode}`;
  const hasPii = isPlatform && feature.featureCode === PII_FEATURE_CODE;
  // The only change a toggle can make is to flip the stored state, so that is what is previewed.
  const enable = !feature.isEnabled;
  const current = preview?.enable === enable ? preview : null;

  return (
    <div className="mt-2">
      <Button
        type="button"
        unstyled
        aria-expanded={open}
        aria-controls={panelId}
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1 text-[11px] font-semibold text-[var(--primary-blue)]"
      >
        <ChevronDown size={14} className={open ? 'rotate-180' : undefined} aria-hidden="true" />
        {t('IMPACT.TITLE')}
      </Button>
      {open && (
        <div id={panelId}>
          {feature.impactText && <p className={box}>{feature.impactText}</p>}
          {feature.coreForRails.length > 0 && (
            <p className="mt-2 text-xs text-[var(--text-2)]">
              {t('IMPACT.CORE_FOR', { rails: feature.coreForRails.join(', ') })}
            </p>
          )}
          {hasPii && (
            <>
              <PreviewButton
                params={{ kind: 'pii', enable }}
                onData={(data) => onPreview({ enable, data: data as RailPiiImpactPreview })}
              />
              {current && <PiiFigures data={current.data} enable={current.enable} />}
            </>
          )}
        </div>
      )}
    </div>
  );
}
