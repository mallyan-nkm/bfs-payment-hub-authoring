import { parseMultiFilter } from '@paymenthub/ui';
import { RAIL_FILTER } from './columns';
import type { RailListParams, RailStatus } from './types';

/** The grid's flat filter record as the list endpoint's parameters: multi-selects become repeated keys. */
export function filtersToParams(f: Record<string, string>): Partial<RailListParams> {
  const text = (key: string) => f[key]?.trim() || undefined;
  const many = (key: string) => {
    const values = parseMultiFilter(f[key]);
    return values.length ? values : undefined;
  };
  return {
    railCode: text(RAIL_FILTER.RailCode),
    railName: text(RAIL_FILTER.RailName),
    description: text(RAIL_FILTER.Description),
    currency: text(RAIL_FILTER.Currency),
    createdFrom: text(`${RAIL_FILTER.Created}From`),
    createdTo: text(`${RAIL_FILTER.Created}To`),
    createdBy: text(RAIL_FILTER.CreatedBy),
    status: many(RAIL_FILTER.Status) as RailStatus[] | undefined,
    lastModifiedFrom: text(`${RAIL_FILTER.LastModified}From`),
    lastModifiedTo: text(`${RAIL_FILTER.LastModified}To`),
    lastModifiedBy: text(RAIL_FILTER.LastModifiedBy),
    lastAction: many(RAIL_FILTER.LastAction),
  };
}
