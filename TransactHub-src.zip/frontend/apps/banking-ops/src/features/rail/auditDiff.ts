import { RAIL_AUDIT_SECTION } from './types';
import type { RailAuditEntry } from './types';

/**
 * The Audit Trail card contents, read from `OldData` / `NewData` as `RailAuditWriter` writes them: camelCase JSON,
 * one snapshot shape per section. RAIL Update, Status Change and RAIL Created carry
 * `{railCode, railName, description, status, currencies}`; Feature Change `{featureCode, isEnabled}`; Approval
 * `{decision, checkerId, decidedAt}`. A below-final level's Approval card (LevelApproved) instead carries the request's
 * proposed change: a rail or feature snapshot with its before-snapshot, plus `decision` and the level keys.
 */

/** The rail fields a card can show, in display order. The card names each in the reader's language. */
export type AuditField = 'railCode' | 'railName' | 'description' | 'status' | 'currencies';

/** A snapshot value as text; null is "none" (shown as "—"). */
export type AuditValue = string | null;

/** One "Field · Before → After" line (FSD §5.4.3). */
export interface AuditFieldChange {
  field: AuditField;
  before: AuditValue;
  after: AuditValue;
}

/** A Feature Change card: which feature, and its enabled state before (null when no before-snapshot) and after. */
export interface AuditFeatureChange {
  featureCode: string;
  before: boolean | null;
  after: boolean;
}

/** An Approval card: the Checker's decision. */
export interface AuditApproval {
  decision: string;
  checkerId: string | null;
  decidedAt: string | null;
  /** Which approval level acted, and how many there are; null on a card written before multi-level approval. */
  level: number | null;
  totalLevels: number | null;
}

/**
 * A reconciler card: what IAM's rail-access reconciler did to the roles after the RAIL's status changed. It is written
 * on the Rail entity, under Status Change, with no before-snapshot and only counts in `NewData`:
 * `{railCode, phase: 'disable', revoked, denied}` after a disable, `{railCode, phase: 'restore', restored, skipped,
 * deferred}` after a re-enable. Read as a field change it shows a meaningless "RAIL Code — → FTS".
 */
export interface AuditReconciliation {
  phase: 'disable' | 'restore';
  revoked: number;
  denied: number;
  restored: number;
  skipped: number;
  deferred: number;
}

const SNAPSHOT_FIELDS: { key: string; field: AuditField }[] = [
  { key: 'railname', field: 'railName' },
  { key: 'description', field: 'description' },
  { key: 'status', field: 'status' },
  { key: 'currencies', field: 'currencies' },
];

/** Parses a snapshot, reading its keys case-insensitively so a PascalCase writer reads the same. */
function parse(json: string | null): Record<string, unknown> | null {
  if (!json) return null;
  try {
    const value: unknown = JSON.parse(json);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([k, v]) => [k.toLowerCase(), v]));
  } catch {
    return null;
  }
}

function text(v: unknown): AuditValue {
  return v === null || v === undefined || v === '' ? null : String(v);
}

/**
 * The lines of a RAIL Update, Status Change or RAIL Created card. A Created row has no before-snapshot, so every
 * field reads none → value, rail code first; otherwise only the fields that differ are listed. Empty for any
 * other section.
 */
export function auditFieldChanges(entry: RailAuditEntry): AuditFieldChange[] {
  // A LevelApproved card sits in Approval but records the proposed rail change, with a before-snapshot.
  const levelChange = entry.section === RAIL_AUDIT_SECTION.Approval && parse(entry.oldData) !== null;
  if (
    !levelChange &&
    entry.section !== RAIL_AUDIT_SECTION.RailUpdate &&
    entry.section !== RAIL_AUDIT_SECTION.StatusChange &&
    entry.section !== RAIL_AUDIT_SECTION.RailCreated
  ) {
    return [];
  }
  if (auditReconciliation(entry)) return [];
  const before = parse(entry.oldData);
  const after = parse(entry.newData);
  if (!after) return [];

  if (!before) {
    const code = text(after.railcode);
    return [
      ...(code ? [{ field: 'railCode' as const, before: null, after: code }] : []),
      ...SNAPSHOT_FIELDS.filter((f) => f.key in after).map((f) => ({
        field: f.field,
        before: null,
        after: text(after[f.key]),
      })),
    ];
  }

  return SNAPSHOT_FIELDS.flatMap((f) => {
    const b = text(before[f.key]);
    const a = text(after[f.key]);
    return b === a ? [] : [{ field: f.field, before: b, after: a }];
  });
}

/** The line of a Feature Change card, or null when the row isn't one or carries no feature. */
export function auditFeatureChange(entry: RailAuditEntry): AuditFeatureChange | null {
  if (entry.section !== RAIL_AUDIT_SECTION.FeatureChange && entry.section !== RAIL_AUDIT_SECTION.Approval) return null;
  const after = parse(entry.newData);
  if (!after || typeof after.featurecode !== 'string' || typeof after.isenabled !== 'boolean') return null;
  const before = parse(entry.oldData);
  return {
    featureCode: after.featurecode,
    before: typeof before?.isenabled === 'boolean' ? before.isenabled : null,
    after: after.isenabled,
  };
}

/** The decision of an Approval card, or null when the row isn't one. */
export function auditApproval(entry: RailAuditEntry): AuditApproval | null {
  if (entry.section !== RAIL_AUDIT_SECTION.Approval) return null;
  const data = parse(entry.newData);
  if (!data || typeof data.decision !== 'string') return null;
  const levelOf = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);
  return {
    decision: data.decision,
    checkerId: text(data.checkerid),
    decidedAt: text(data.decidedat),
    level: levelOf(data.level),
    totalLevels: levelOf(data.totallevels),
  };
}

const count = (v: unknown): number => (typeof v === 'number' && Number.isFinite(v) ? v : 0);

/** The counts of a reconciler card, or null when the row isn't one (a Status Change card carries no `phase`). */
export function auditReconciliation(entry: RailAuditEntry): AuditReconciliation | null {
  if (entry.section !== RAIL_AUDIT_SECTION.StatusChange) return null;
  const data = parse(entry.newData);
  const phase = data?.phase;
  if (!data || (phase !== 'disable' && phase !== 'restore')) return null;
  return {
    phase,
    revoked: count(data.revoked),
    denied: count(data.denied),
    restored: count(data.restored),
    skipped: count(data.skipped),
    deferred: count(data.deferred),
  };
}
