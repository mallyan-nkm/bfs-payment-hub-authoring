import { render, renderHook, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { RailCodeBadge, RailLastActionBadge, RailStatusBadge } from './badges';
import { lastActionLabel, useRailTranslation } from './i18n';

/** The screen's `t`, as a component gets it. */
const railT = () => renderHook(() => useRailTranslation()).result.current.t;

describe('Last Action label (AC-RAIL-072)', () => {
  it.each([
    ['Pending', 'Modify RAIL'],
    ['Applied', 'Modify RAIL - Accepted'],
    ['Rejected', 'Modify RAIL - Rejected'],
  ])('%s reads "%s"', (outcome, label) => {
    expect(lastActionLabel(railT(), { action: 'x', outcome })).toBe(label);
  });

  it('shows "—" when there is no request', () => {
    render(<RailLastActionBadge lastAction={null} />);
    expect(screen.getByText('—')).toBeInTheDocument();
  });

  it('is green when accepted and amber while pending or rejected, always with its text', () => {
    const { rerender } = render(<RailLastActionBadge lastAction={{ action: 'x', outcome: 'Applied' }} />);
    expect(screen.getByText('Modify RAIL - Accepted').className).toContain('accent-green');

    rerender(<RailLastActionBadge lastAction={{ action: 'x', outcome: 'Pending' }} />);
    expect(screen.getByText('Modify RAIL').className).toContain('accent-amber');

    rerender(<RailLastActionBadge lastAction={{ action: 'x', outcome: 'Rejected' }} />);
    expect(screen.getByText('Modify RAIL - Rejected').className).toContain('accent-amber');
  });
});

describe('RAIL status and code badges', () => {
  it('maps each status to its modifier, on theme tokens only', () => {
    const { rerender } = render(<RailStatusBadge status="Active" />);
    expect(screen.getByText('Active').className).toContain('success');
    rerender(<RailStatusBadge status="Disabled" />);
    expect(screen.getByText('Disabled').className).toContain('error');
    rerender(<RailStatusBadge status="Pending" />);
    expect(screen.getByText('Pending').className).toContain('warn');
    expect(screen.getByText('Pending').className).not.toMatch(/#[0-9a-f]{3,6}/i);
  });

  it('renders the RAIL code in monospace', () => {
    render(<RailCodeBadge code="IPI" />);
    expect(screen.getByText('IPI').className).toContain('font-mono');
  });
});
