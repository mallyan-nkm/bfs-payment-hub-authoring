import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiError, apiOk, chooseOption, grant, optionsOf, renderWithProviders } from '../../../test/renderWithProviders';
import { RailAuditTrailModal } from './RailAuditTrailModal';
import type { RailAuditEntry, RailRow } from './types';

vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

const ROW: RailRow = {
  sl: 1,
  railCode: 'IPI',
  railName: 'Instant Payments',
  description: 'd',
  currency: 'AED',
  createdAt: '2026-01-01T00:00:00Z',
  createdBy: 'seed',
  status: 'Active',
  isPending: false,
  lastModifiedAt: null,
  lastModifiedBy: null,
  lastAction: null,
};

function entry(n: number, overrides: Partial<RailAuditEntry> = {}): RailAuditEntry {
  return {
    entryNumber: n,
    userName: 'maker1',
    userRole: 'Maker',
    section: 'RAIL Update',
    remarks: `remark ${n}`,
    actionDate: '2026-09-28T14:15:00Z',
    changedFields: '["railName"]',
    oldData: '{"railCode":"IPI","railName":"Old","description":"d","status":"Active","currencies":"AED"}',
    newData: '{"railCode":"IPI","railName":"New","description":"d","status":"Active","currencies":"AED"}',
    ...overrides,
  };
}

function serve(items: RailAuditEntry[], totalRecords = items.length) {
  get.mockResolvedValue(apiOk({ items, pageNumber: 1, pageSize: 10, totalRecords }));
}

const lastParams = () => (get.mock.calls.at(-1)?.[1] as { params: Record<string, unknown> }).params;

function open() {
  renderWithProviders(<RailAuditTrailModal row={ROW} onClose={vi.fn()} />);
}

beforeEach(() => {
  get.mockReset();
  grant(PERM.railPage);
});

describe('Audit Trail modal (AC-RAIL-076)', () => {
  it('loads the first page of the rail, newest first as the server returns it', async () => {
    serve([entry(2), entry(1)]);
    open();

    expect(await screen.findByText('remark 2')).toBeInTheDocument();
    expect(get).toHaveBeenCalledWith('/ops/railAudit/IPI', { params: expect.objectContaining({ pageNumber: 1 }) });
    const cards = screen.getAllByRole('listitem');
    expect(cards[0]).toHaveTextContent('remark 2');
  });

  it('has no page-size control and pages ten at a time', async () => {
    serve(Array.from({ length: 10 }, (_, i) => entry(i + 1)), 25);
    open();

    await screen.findByText('remark 1');
    expect(screen.queryByRole('combobox', { name: /page size|rows/i })).not.toBeInTheDocument();
    expect(screen.getByText('1–10 of 25')).toBeInTheDocument();

    await userEvent.click(screen.getByRole('button', { name: /Next/ }));

    await waitFor(() => expect(lastParams().pageNumber).toBe(2));
  });

  it('shows the date in the session zone as DD-MM-YYYY HH:MM:SS', async () => {
    serve([entry(1)]);
    open();

    expect(await screen.findByText('28-09-2026 18:15:00')).toBeInTheDocument();
  });

  it('lists the five sections and sends the chosen one on Search', async () => {
    serve([entry(1)]);
    open();
    await screen.findByText('remark 1');

    const section = screen.getByRole('combobox', { name: 'Section' });
    expect(await optionsOf(section)).toEqual([
      'All sections',
      'RAIL Update',
      'Feature Change',
      'Status Change',
      'RAIL Created',
      'Approval',
    ]);
    await chooseOption(section, 'Approval');
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    await waitFor(() => expect(lastParams().section).toBe('Approval'));
    expect(lastParams().pageNumber).toBe(1);
  });

  it('refuses a To date before the From date and sends nothing', async () => {
    serve([entry(1)]);
    open();
    await screen.findByText('remark 1');
    const calls = get.mock.calls.length;

    await userEvent.type(screen.getByLabelText('From'), '2026-09-10');
    await userEvent.type(screen.getByLabelText('To'), '2026-09-01');

    expect(await screen.findByText('To date cannot be before From date.')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Search' })).toBeDisabled();
    expect(get.mock.calls.length).toBe(calls);
  });

  it('sends the dates on Search', async () => {
    serve([entry(1)]);
    open();
    await screen.findByText('remark 1');

    await userEvent.type(screen.getByLabelText('From'), '2026-09-01');
    await userEvent.type(screen.getByLabelText('To'), '2026-09-30');
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    await waitFor(() => expect(lastParams()).toMatchObject({ fromDate: '2026-09-01', toDate: '2026-09-30' }));
  });

  it('shows Field · Before → After lines for an update', async () => {
    serve([entry(1)]);
    open();

    expect(await screen.findByText('RAIL Name')).toBeInTheDocument();
    expect(screen.getByText('Old')).toBeInTheDocument();
    expect(screen.getByText('New')).toBeInTheDocument();
  });

  it('shows a feature change as Disabled → Enabled', async () => {
    serve([
      entry(1, {
        section: 'Feature Change',
        changedFields: '["isEnabled"]',
        oldData: '{"featureCode":"PII","isEnabled":false}',
        newData: '{"featureCode":"PII","isEnabled":true}',
      }),
    ]);
    open();

    expect(await screen.findByText('PII')).toBeInTheDocument();
    expect(screen.getByText('Disabled')).toBeInTheDocument();
    expect(screen.getByText('Enabled')).toBeInTheDocument();
  });

  it('shows an approval card with the decision', async () => {
    serve([
      entry(1, {
        section: 'Approval',
        changedFields: null,
        oldData: null,
        newData: '{"decision":"Approved","checkerId":"u7","decidedAt":"2026-09-28T14:15:00Z"}',
      }),
    ]);
    open();

    expect(await screen.findByText('Approved')).toBeInTheDocument();
    expect(screen.getByText(/Checker: u7/)).toBeInTheDocument();
  });

  it('shows an empty state', async () => {
    serve([]);
    open();

    expect(await screen.findByText('No audit entries match.')).toBeInTheDocument();
  });

  it('shows the server refusal', async () => {
    get.mockRejectedValue(apiError(500, 'Audit unavailable.'));
    open();

    expect(await screen.findByRole('alert')).toHaveTextContent('Audit unavailable.');
  });
});

describe('Audit Trail modal: reconciler cards', () => {
  const disableCard = (n: number) =>
    entry(n, {
      userName: 'iam:rail-reconciler',
      userRole: 'System',
      section: 'Status Change',
      remarks: null,
      changedFields: null,
      oldData: null,
      newData: '{"railCode":"IPI","phase":"disable","revoked":0,"denied":1}',
    });

  it('says what the system did to the roles instead of a meaningless "RAIL Code" change', async () => {
    serve([disableCard(2), entry(1)]);
    open();

    const card = (await screen.findByText('Role access removed after the RAIL was disabled')).closest('li') as HTMLElement;
    expect(card).toHaveTextContent('0 grant(s) revoked · 1 role(s) denied access');
    expect(card).toHaveTextContent('Rail access reconciler');
    expect(card).toHaveTextContent('System');
    expect(card).not.toHaveTextContent('iam:rail-reconciler');
    expect(card).not.toHaveTextContent('RAIL Code');
  });

  it('replaces the empty Comments line with a note that the system recorded it', async () => {
    serve([disableCard(2)]);
    open();

    const card = (await screen.findByText('Role access removed after the RAIL was disabled')).closest('li') as HTMLElement;
    expect(card).toHaveTextContent('Recorded automatically by the system');
    expect(card).not.toHaveTextContent('Comments:');
  });

  it('leaves an ordinary card as it was, with its Comments', async () => {
    serve([disableCard(2), entry(1)]);
    open();

    await screen.findByText('remark 1');
    expect(screen.getByText('remark 1').closest('li')).toHaveTextContent('Comments:');
  });
});
