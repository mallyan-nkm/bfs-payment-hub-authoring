import { useTranslation } from 'react-i18next';
import { RAIL_LAST_ACTION_FILTER } from './types';
import type { RailAuditSection, RailLastAction, RailStatus } from './types';

/**
 * The RAIL screen's copy: the `RAIL` block of the shared `@paymenthub/ui` translations (`i18n/en.json`, `ar.json`),
 * the same pattern as `DEPARTMENT.*`. Keys below are relative to that block.
 */
export function useRailTranslation() {
  return useTranslation('translation', { keyPrefix: 'RAIL' });
}

/** The prefixed `t`, for helpers that build copy outside a component. */
export type RailT = ReturnType<typeof useRailTranslation>['t'];

export const STATUS_KEY: Record<RailStatus, string> = {
  Active: 'STATUS.ACTIVE',
  Disabled: 'STATUS.DISABLED',
  Pending: 'STATUS.PENDING',
};

/** The Audit Trail's Section labels; the value sent to the server stays the stored section string. */
export const SECTION_KEY: Record<RailAuditSection, string> = {
  'RAIL Update': 'AUDIT.SECTIONS.RAIL_UPDATE',
  'Feature Change': 'AUDIT.SECTIONS.FEATURE_CHANGE',
  'Status Change': 'AUDIT.SECTIONS.STATUS_CHANGE',
  'RAIL Created': 'AUDIT.SECTIONS.RAIL_CREATED',
  Approval: 'AUDIT.SECTIONS.APPROVAL',
};

/** Last Action label per request outcome (Pending = awaiting the checker; Applied shows as Accepted). */
const LAST_ACTION_KEY: Record<string, string> = {
  Pending: 'LAST_ACTION.PENDING',
  Applied: 'LAST_ACTION.ACCEPTED',
  Rejected: 'LAST_ACTION.REJECTED',
};

/** The grid's Last Action filter values, as the server expects them, with their translated labels. */
export const LAST_ACTION_FILTER_OPTIONS: { value: string; key: string }[] = [
  { value: RAIL_LAST_ACTION_FILTER.Pending, key: 'LAST_ACTION.PENDING' },
  { value: RAIL_LAST_ACTION_FILTER.Accepted, key: 'LAST_ACTION.ACCEPTED' },
  { value: RAIL_LAST_ACTION_FILTER.Rejected, key: 'LAST_ACTION.REJECTED' },
];

export function lastActionLabel(t: RailT, lastAction: RailLastAction | null): string | null {
  if (!lastAction) return null;
  const key = LAST_ACTION_KEY[lastAction.outcome];
  return key ? t(key) : lastAction.action;
}

export function statusLabel(t: RailT, status: RailStatus): string {
  return t(STATUS_KEY[status]);
}
