import type { RefObject } from 'react';
import { Button } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { RailCodeBadge, RailLastActionBadge, RailStatusBadge } from './badges';
import { LAST_ACTION_FILTER_OPTIONS, lastActionLabel, statusLabel } from './i18n';
import type { RailT } from './i18n';
import { RAIL_STATUS } from './types';
import type { RailRow } from './types';

/**
 * Handlers and the live page, behind a ref. SmartGrid snapshots column definitions on first mount and never
 * re-reads them, so the render closures must read through a ref to see today's page and handlers.
 */
export interface RailGridView {
  rows: RailRow[];
  page: number;
  pageSize: number;
  onViewModify: (row: RailRow) => void;
  onAuditTrail: (row: RailRow) => void;
}

/** Grid filter keys. The date ranges' `…From` / `…To` pair is what the list endpoint binds (`createdFrom`…). */
export const RAIL_FILTER = {
  RailCode: 'railCode',
  RailName: 'railName',
  Description: 'description',
  Currency: 'currency',
  Created: 'created',
  CreatedBy: 'createdBy',
  Status: 'status',
  LastModified: 'lastModified',
  LastModifiedBy: 'lastModifiedBy',
  LastAction: 'lastAction',
} as const;

const STATUS_FILTERS = [RAIL_STATUS.Active, RAIL_STATUS.Disabled, RAIL_STATUS.Pending];

/**
 * Column keys double as the export's column keys (RailExportMapper) and `sortKey` is the backend's sort whitelist
 * name (RailListSort). Currency is a list and has no sort; Sl and Actions have neither sort nor filter.
 */
export function buildColumns(view: RefObject<RailGridView>, t: RailT): SmartGridColumn<RailRow>[] {
  return [
    {
      key: 'slNo',
      label: t('COLUMNS.SL'),
      locked: true,
      numeric: true,
      render: (r) => {
        const { rows, page, pageSize } = view.current;
        const index = rows.indexOf(r);
        return index < 0 ? '—' : (page - 1) * pageSize + index + 1;
      },
    },
    {
      key: 'railCode',
      label: t('COLUMNS.RAIL_CODE'),
      filterKey: RAIL_FILTER.RailCode,
      sortKey: 'railCode',
      getValue: (r) => r.railCode,
      render: (r) => <RailCodeBadge code={r.railCode} />,
    },
    {
      key: 'railName',
      label: t('COLUMNS.RAIL_NAME'),
      filterKey: RAIL_FILTER.RailName,
      sortKey: 'railName',
      getValue: (r) => r.railName,
    },
    {
      key: 'description',
      label: t('COLUMNS.DESCRIPTION'),
      filterKey: RAIL_FILTER.Description,
      sortKey: 'description',
      wrap: true,
      maxWidth: 280,
      getValue: (r) => r.description,
    },
    {
      key: 'currency',
      label: t('COLUMNS.CURRENCY'),
      filterKey: RAIL_FILTER.Currency,
      getValue: (r) => r.currency || '—',
    },
    {
      key: 'createdAt',
      label: t('COLUMNS.CREATED'),
      filterKey: RAIL_FILTER.Created,
      filterType: 'dateRange',
      sortKey: 'createdAt',
      kind: 'instant',
    },
    {
      key: 'createdBy',
      label: t('COLUMNS.CREATED_BY'),
      filterKey: RAIL_FILTER.CreatedBy,
      sortKey: 'createdBy',
      getValue: (r) => r.createdBy,
    },
    {
      key: 'status',
      label: t('COLUMNS.STATUS'),
      filterKey: RAIL_FILTER.Status,
      filterType: 'multiSelect',
      filterOptions: STATUS_FILTERS.map((s) => ({ value: s, label: statusLabel(t, s) })),
      sortKey: 'status',
      // A request awaiting the checker shows as Pending whatever the stored status (design §7.1).
      getValue: (r) => statusLabel(t, r.isPending ? RAIL_STATUS.Pending : r.status),
      render: (r) => <RailStatusBadge status={r.isPending ? RAIL_STATUS.Pending : r.status} />,
    },
    {
      key: 'lastModifiedAt',
      label: t('COLUMNS.LAST_MODIFIED'),
      filterKey: RAIL_FILTER.LastModified,
      filterType: 'dateRange',
      sortKey: 'lastModifiedAt',
      kind: 'instant',
    },
    {
      key: 'lastModifiedBy',
      label: t('COLUMNS.LAST_MODIFIED_BY'),
      filterKey: RAIL_FILTER.LastModifiedBy,
      sortKey: 'lastModifiedBy',
      getValue: (r) => r.lastModifiedBy ?? '—',
    },
    {
      key: 'lastAction',
      label: t('COLUMNS.LAST_ACTION'),
      filterKey: RAIL_FILTER.LastAction,
      filterType: 'multiSelect',
      filterOptions: LAST_ACTION_FILTER_OPTIONS.map((o) => ({ value: o.value, label: t(o.key) })),
      sortKey: 'lastAction',
      getValue: (r) => lastActionLabel(t, r.lastAction) ?? '—',
      render: (r) => <RailLastActionBadge lastAction={r.lastAction} />,
    },
    {
      key: 'actions',
      label: t('COLUMNS.ACTIONS'),
      locked: true,
      render: (r) => (
        <div className="pq-row-actions">
          <Button
            type="button"
            variant="secondary"
            size="sm"
            disabled={r.isPending}
            title={r.isPending ? t('ROW.PENDING_HINT') : undefined}
            onClick={(e) => {
              e.stopPropagation();
              view.current.onViewModify(r);
            }}
            aria-label={t('ROW.VIEW_MODIFY_LABEL', { code: r.railCode })}
          >
            {t('ROW.VIEW_MODIFY')}
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              view.current.onAuditTrail(r);
            }}
            aria-label={t('ROW.AUDIT_LABEL', { code: r.railCode })}
          >
            {t('ROW.AUDIT')}
          </Button>
        </div>
      ),
    },
  ];
}
