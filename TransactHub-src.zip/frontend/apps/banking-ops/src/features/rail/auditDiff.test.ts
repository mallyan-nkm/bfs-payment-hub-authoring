import { describe, expect, it } from 'vitest';
import { auditApproval, auditFeatureChange, auditFieldChanges, auditReconciliation } from './auditDiff';
import type { RailAuditEntry } from './types';

function entry(overrides: Partial<RailAuditEntry>): RailAuditEntry {
  return {
    entryNumber: 1,
    userName: 'maker1',
    userRole: 'Maker',
    section: 'RAIL Update',
    remarks: 'r',
    actionDate: '2026-09-28T14:15:00Z',
    changedFields: null,
    oldData: null,
    newData: '{}',
    ...overrides,
  };
}

// Card shapes are RailAuditWriter's: camelCase JSON, one snapshot shape per section.
describe('auditFieldChanges (AC-RAIL-076: "Field · Before → After" from OldData / NewData)', () => {
  it('lists only the fields that changed', () => {
    const changes = auditFieldChanges(
      entry({
        oldData: '{"railCode":"IPI","railName":"Old","description":"d","status":"Active","currencies":"AED"}',
        newData: '{"railCode":"IPI","railName":"New","description":"d","status":"Disabled","currencies":"AED"}',
      }),
    );

    expect(changes).toEqual([
      { field: 'railName', before: 'Old', after: 'New' },
      { field: 'status', before: 'Active', after: 'Disabled' },
    ]);
  });

  it('reads PascalCase keys the same', () => {
    const changes = auditFieldChanges(entry({ oldData: '{"RailName":"A"}', newData: '{"RailName":"B"}' }));

    expect(changes).toEqual([{ field: 'railName', before: 'A', after: 'B' }]);
  });

  it('treats null and empty as none', () => {
    const changes = auditFieldChanges(entry({ oldData: '{"description":null}', newData: '{"description":"new"}' }));

    expect(changes).toEqual([{ field: 'description', before: null, after: 'new' }]);
  });

  it('shows every seed field as none → value on a RAIL Created card, code first', () => {
    const changes = auditFieldChanges(
      entry({
        section: 'RAIL Created',
        newData: '{"railCode":"IPI","railName":"Instant","description":null,"status":"Active","currencies":"AED"}',
      }),
    );

    expect(changes.map((c) => c.field)).toEqual(['railCode', 'railName', 'description', 'status', 'currencies']);
    expect(changes.every((c) => c.before === null)).toBe(true);
    expect(changes[2].after).toBeNull();
  });

  it('is empty for unreadable data and for the other sections', () => {
    expect(auditFieldChanges(entry({ newData: 'not json' }))).toEqual([]);
    expect(auditFieldChanges(entry({ section: 'Approval', newData: '{"decision":"Approved"}' }))).toEqual([]);
    expect(auditFieldChanges(entry({ section: 'Feature Change', newData: '{"featureCode":"X","isEnabled":true}' }))).toEqual([]);
  });
});

describe('auditFeatureChange', () => {
  it('reads the feature and its before and after state', () => {
    const change = auditFeatureChange(
      entry({
        section: 'Feature Change',
        oldData: '{"featureCode":"PII","isEnabled":false}',
        newData: '{"featureCode":"PII","isEnabled":true}',
      }),
    );

    expect(change).toEqual({ featureCode: 'PII', before: false, after: true });
  });

  it('is null for another section or a card without a feature', () => {
    expect(auditFeatureChange(entry({ newData: '{"featureCode":"PII","isEnabled":true}' }))).toBeNull();
    expect(auditFeatureChange(entry({ section: 'Feature Change', newData: '{}' }))).toBeNull();
  });
});

describe('auditApproval', () => {
  it('reads the decision, checker and time', () => {
    const approval = auditApproval(
      entry({
        section: 'Approval',
        newData: '{"decision":"Rejected","checkerId":"u7","decidedAt":"2026-09-28T14:15:00Z"}',
      }),
    );

    expect(approval).toEqual({ decision: 'Rejected', checkerId: 'u7', decidedAt: '2026-09-28T14:15:00Z', level: null, totalLevels: null });
  });

  it('is null for another section', () => {
    expect(auditApproval(entry({ newData: '{"decision":"Approved"}' }))).toBeNull();
  });
});

// The reconciler writes its summary on the Rail entity, under Status Change, with counts and no before-snapshot.
describe('auditReconciliation (what IAM did to the roles after a status change)', () => {
  const disable = entry({
    section: 'Status Change',
    userName: 'iam:rail-reconciler',
    userRole: 'System',
    remarks: null,
    newData: '{"railCode":"FTS","phase":"disable","revoked":0,"denied":1}',
  });
  const restore = entry({
    section: 'Status Change',
    newData: '{"railCode":"FTS","phase":"restore","restored":2,"skipped":1,"deferred":3}',
  });

  it('reads the counts of a disable card', () => {
    expect(auditReconciliation(disable)).toEqual({
      phase: 'disable',
      revoked: 0,
      denied: 1,
      restored: 0,
      skipped: 0,
      deferred: 0,
    });
  });

  it('reads the counts of a restore card', () => {
    expect(auditReconciliation(restore)).toEqual({
      phase: 'restore',
      revoked: 0,
      denied: 0,
      restored: 2,
      skipped: 1,
      deferred: 3,
    });
  });

  it('counts a missing or non-numeric figure as 0', () => {
    const e = entry({ section: 'Status Change', newData: '{"phase":"disable","revoked":"x"}' });
    expect(auditReconciliation(e)).toMatchObject({ revoked: 0, denied: 0 });
  });

  it('is null for a real status change, another section, or an unknown phase', () => {
    const status = entry({
      section: 'Status Change',
      oldData: '{"status":"Active"}',
      newData: '{"railCode":"FTS","status":"Disabled"}',
    });
    expect(auditReconciliation(status)).toBeNull();
    expect(auditReconciliation(entry({ section: 'RAIL Update', newData: '{"phase":"disable"}' }))).toBeNull();
    expect(auditReconciliation(entry({ section: 'Status Change', newData: '{"phase":"other"}' }))).toBeNull();
  });

  it('is not also listed as a field change: no "RAIL Code — → FTS" line', () => {
    expect(auditFieldChanges(disable)).toEqual([]);
    expect(auditFieldChanges(restore)).toEqual([]);
  });
});

describe('a LevelApproved card (Approval section carrying the proposed change)', () => {
  const level = entry({
    section: 'Approval',
    oldData: '{"railCode":"IPI","railName":"Old","description":null,"status":"Active","currencies":"AED"}',
    newData:
      '{"railCode":"IPI","railName":"New","description":null,"status":"Active","currencies":"AED","decision":"Approved","level":1,"totalLevels":2,"workflowType":"SEQUENTIAL","requestId":9}',
  });

  it('shows the real changed fields and keeps its level', () => {
    expect(auditFieldChanges(level)).toEqual([{ field: 'railName', before: 'Old', after: 'New' }]);
    expect(auditApproval(level)).toMatchObject({ decision: 'Approved', checkerId: null, level: 1, totalLevels: 2 });
  });

  it('shows a feature-only proposal as a feature line', () => {
    const feature = entry({
      section: 'Approval',
      oldData: '{"featureCode":"PII","isEnabled":false}',
      newData: '{"featureCode":"PII","isEnabled":true,"decision":"Approved","level":1,"totalLevels":2}',
    });
    expect(auditFeatureChange(feature)).toEqual({ featureCode: 'PII', before: false, after: true });
  });
});
