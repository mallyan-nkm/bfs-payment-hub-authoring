import { RAIL_RULE_CODES } from './types';
import type { RailIamError, RailProblemDetails } from './types';

/**
 * Reading a RAIL refusal (design §5). Operations answers ProblemDetails; the IAM impact routes answer `{ error }`.
 * A refusal is put on a field by its `errors` map or rule code, never by matching English text.
 */

function bodyOf(error: unknown): Record<string, unknown> | null {
  const data = (error as { response?: { data?: unknown } } | null)?.response?.data;
  return data && typeof data === 'object' ? (data as Record<string, unknown>) : null;
}

/** The ProblemDetails body of a failed Operations call, or null when it carried none. */
export function railProblem(error: unknown): RailProblemDetails | null {
  const data = bodyOf(error);
  return data && ('errorCode' in data || 'detail' in data || 'errors' in data) ? (data as RailProblemDetails) : null;
}

/** The `{ error }` message of a failed IAM call, or null. */
export function railIamError(error: unknown): string | null {
  const data = bodyOf(error) as Partial<RailIamError> | null;
  return typeof data?.error === 'string' && data.error ? data.error : null;
}

/** The rule a refusal enforces: `ruleCode`, else `errorCode` when that already is a rule code. */
export function railRuleCode(problem: RailProblemDetails | null): string | null {
  if (!problem) return null;
  if (problem.ruleCode) return problem.ruleCode;
  const known: readonly string[] = Object.values(RAIL_RULE_CODES);
  return problem.errorCode && known.includes(problem.errorCode) ? problem.errorCode : null;
}

export function isRailRule(error: unknown, rule: string): boolean {
  return railRuleCode(railProblem(error)) === rule;
}

export function isRailErrorCode(error: unknown, code: string): boolean {
  return railProblem(error)?.errorCode === code;
}

export function railHttpStatus(error: unknown): number | null {
  const status = (error as { response?: { status?: number } } | null)?.response?.status;
  return typeof status === 'number' ? status : null;
}

/** The message to show: the server's `detail`, else the IAM `error`, else the caller's translated fallback. */
export function railErrorMessage(error: unknown, fallback: string): string {
  return railProblem(error)?.detail || railIamError(error) || fallback;
}

/** The readable lines of a 422's `violations[]`: plain strings, or objects carrying a `message`/`detail`. */
export function railViolationMessages(problem: RailProblemDetails | null): string[] {
  return (problem?.violations ?? [])
    .map((v) => {
      if (typeof v === 'string') return v;
      const o = v as { message?: unknown; detail?: unknown } | null;
      return typeof o?.message === 'string' ? o.message : typeof o?.detail === 'string' ? o.detail : '';
    })
    .filter((m) => m.length > 0);
}

export interface RailFieldMap<F extends string> {
  /** Server property name → form field, matched case-insensitively on the last segment of a dotted path. */
  properties: Partial<Record<string, F>>;
  /** Rule code → form field, for a refusal without an `errors` map. */
  rules?: Partial<Record<string, F>>;
}

export interface RailFieldError<F extends string> {
  field: F;
  message: string;
}

/** The field errors a refusal carries. Empty when it is about no field, so the caller shows it at the panel top. */
export function railFieldErrors<F extends string>(error: unknown, map: RailFieldMap<F>): RailFieldError<F>[] {
  const problem = railProblem(error);
  if (!problem) return [];

  const properties = Object.fromEntries(
    Object.entries(map.properties).map(([name, field]) => [name.toLowerCase(), field]),
  ) as Partial<Record<string, F>>;

  const found: RailFieldError<F>[] = [];
  for (const [property, messages] of Object.entries(problem.errors ?? {})) {
    const field = properties[property.split('.').pop()?.toLowerCase() ?? ''];
    const message = messages?.find((m) => Boolean(m));
    if (field && message && !found.some((f) => f.field === field)) found.push({ field, message });
  }
  if (found.length > 0) return found;

  const rule = railRuleCode(problem);
  const field = rule ? map.rules?.[rule] : undefined;
  return field && problem.detail ? [{ field, message: problem.detail }] : [];
}
