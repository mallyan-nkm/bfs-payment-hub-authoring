import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiError, apiOk, chooseOption, grant, renderWithProviders } from '../../../test/renderWithProviders';
import { RailModifySheet } from './RailModifySheet';
import type { RailDetail, RailFeature } from './types';

vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

const SAVED = apiOk({ railCode: 'IPI', requestId: 5, applied: true, actionDate: '2026-10-12T10:00:00Z' });

function feature(overrides: Partial<RailFeature>): RailFeature {
  return {
    featureCode: 'PII',
    featureName: 'PII Masking',
    isEnabled: false,
    isLocked: false,
    lockOnceEnabled: false,
    isCore: false,
    baseFeatureTimelineId: 11,
    impactText: null,
    coreForRails: [],
    ...overrides,
  };
}

function detailOf(overrides: Partial<RailDetail> = {}): RailDetail {
  return {
    railCode: 'IPI',
    railName: 'Instant Payments',
    description: 'Instant payment rail',
    status: 'Active',
    currencies: ['AED', 'USD'],
    baseTimelineId: 7,
    isPending: false,
    lastAction: null,
    features: [feature({}), feature({ featureCode: 'LOCKME', featureName: 'Sanctions', lockOnceEnabled: true, baseFeatureTimelineId: 12 })],
    latestRequest: null,
    ...overrides,
  };
}

function serve(detail: RailDetail, makerOnlyActions: string[] = ['ModifyRail']) {
  get.mockImplementation((url: string) =>
    Promise.resolve(url.includes('railWorkflow') ? apiOk({ makerOnlyActions, checkerPermission: null }) : apiOk(detail)),
  );
}

async function open(detail: RailDetail, props: { onClose?: () => void; onCompleted?: (m: string) => void } = {}) {
  serve(detail);
  renderWithProviders(
    <RailModifySheet railCode={detail.railCode} onClose={props.onClose ?? vi.fn()} onCompleted={props.onCompleted ?? vi.fn()} />,
  );
  await screen.findByLabelText(/RAIL Name/);
}

beforeEach(() => {
  get.mockReset();
  post.mockReset();
  grant(PERM.railPage, PERM.railWrite);
});

describe('View & Modify panel (AC-RAIL-068, 070, 071)', () => {
  it('shows the code and currencies read-only and the name, description and status editable', async () => {
    await open(detailOf());

    expect(screen.getByLabelText('RAIL Code')).toHaveAttribute('readonly');
    expect(screen.getByLabelText('Currency')).toHaveValue('AED, USD');
    expect(screen.getByLabelText(/RAIL Name/)).not.toHaveAttribute('readonly');
    expect(screen.getByLabelText(/Description/)).not.toHaveAttribute('readonly');
  });

  it('shows "—" for the currency and a read-only status on PLATFORM', async () => {
    await open(detailOf({ railCode: 'PLATFORM', currencies: [] }));

    expect(screen.getByLabelText('Currency')).toHaveValue('—');
    expect(screen.getByLabelText('Status')).toBeDisabled();
  });

  it('shows Approver Remarks read-only only when the last action was rejected', async () => {
    await open(
      detailOf({
        lastAction: { action: 'Modify RAIL - Rejected', outcome: 'Rejected' },
        latestRequest: {
          requestId: 4,
          action: 'ModifyRail',
          status: 'Rejected',
          makerName: 'm',
          makerAt: null,
          makerRemarks: null,
          checkerName: 'c',
          checkerAt: '2026-10-01T09:05:07Z',
          checkerRemarks: 'Wrong name',
        },
      }),
    );

    const remarks = screen.getByRole('textbox', { name: 'Approver Remarks' });
    expect(remarks).toHaveValue('Wrong name');
    expect(remarks).toHaveAttribute('readonly');
  });

  it('has no Approver Remarks box when the last action was not a rejection', async () => {
    await open(detailOf({ lastAction: { action: 'Modify RAIL - Accepted', outcome: 'Applied' } }));

    expect(screen.queryByText('Approver Remarks')).not.toBeInTheDocument();
  });

  it('shows the Maker-only notice when ModifyRail is Maker-only, and not otherwise', async () => {
    await open(detailOf());
    expect(await screen.findByText(/applied immediately/)).toBeInTheDocument();
  });

  it('has no Maker-only notice when ModifyRail is not Maker-only', async () => {
    serve(detailOf(), []);
    renderWithProviders(<RailModifySheet railCode="IPI" onClose={vi.fn()} onCompleted={vi.fn()} />);
    await screen.findByLabelText(/RAIL Name/);
    await waitFor(() => expect(get).toHaveBeenCalledWith('/ops/railWorkflow'));

    expect(screen.queryByText(/applied immediately/)).not.toBeInTheDocument();
  });

  it('shows "No features configured" for a rail with no features (AC-116)', async () => {
    await open(detailOf({ features: [] }));

    expect(screen.getByText('No features configured')).toBeInTheDocument();
  });

  it('is not actionable without the write key', async () => {
    grant(PERM.railPage);
    await open(detailOf());

    expect(screen.queryByRole('button', { name: 'Save Changes' })).not.toBeInTheDocument();
    expect(screen.queryByLabelText(/Remarks/)).not.toBeInTheDocument();
    expect(screen.getByLabelText(/RAIL Name/)).toHaveAttribute('readonly');
    expect(screen.getByRole('switch', { name: /PII Masking/ })).toBeDisabled();
  });

  it('disables Save and the toggles while a request is pending', async () => {
    await open(detailOf({ isPending: true }));

    expect(screen.getByRole('button', { name: 'Save Changes' })).toBeDisabled();
    expect(screen.getByRole('switch', { name: /PII Masking/ })).toBeDisabled();
  });

  it('requires remarks and writes nothing', async () => {
    await open(detailOf());

    await userEvent.type(screen.getByLabelText(/RAIL Name/), ' 2');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    expect(await screen.findByText('Remarks are required.')).toBeInTheDocument();
    expect(post).not.toHaveBeenCalled();
  });

  it('refuses a save with no change', async () => {
    await open(detailOf());

    await userEvent.type(screen.getByLabelText(/^Remarks/), 'nothing');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Nothing has changed');
    expect(post).not.toHaveBeenCalled();
  });

  it('sends only the changed features with their base ids, never effectiveFrom', async () => {
    post.mockResolvedValue(SAVED);
    const onCompleted = vi.fn();
    await open(detailOf(), { onCompleted });

    await userEvent.click(screen.getByRole('switch', { name: /PII Masking/ }));
    await userEvent.type(screen.getByLabelText(/^Remarks/), 'Enable PII');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    await waitFor(() => expect(onCompleted).toHaveBeenCalledWith('RAIL IPI updated.'));
    expect(post).toHaveBeenCalledWith('/ops/railSave/IPI', {
      baseTimelineId: 7,
      railName: 'Instant Payments',
      description: 'Instant payment rail',
      status: 'Active',
      features: [{ featureCode: 'PII', isEnabled: true, baseFeatureTimelineId: 11 }],
      lockConfirmed: false,
      remarks: 'Enable PII',
    });
  });
});

describe('Lock confirmation (AC-RAIL-073)', () => {
  async function enableLockFeature() {
    await open(detailOf());
    await userEvent.click(screen.getByRole('switch', { name: /Sanctions/ }));
    await userEvent.type(screen.getByLabelText(/^Remarks/), 'Lock it');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));
  }

  it('asks first and sends nothing until OK', async () => {
    await enableLockFeature();

    expect(await screen.findByRole('dialog')).toHaveTextContent('Sanctions');
    expect(post).not.toHaveBeenCalled();
  });

  it('sends lockConfirmed=true only after OK', async () => {
    post.mockResolvedValue(SAVED);
    await enableLockFeature();

    await userEvent.click(await screen.findByRole('button', { name: 'OK' }));

    await waitFor(() => expect(post).toHaveBeenCalledTimes(1));
    expect(post.mock.calls[0][1]).toMatchObject({
      lockConfirmed: true,
      features: [{ featureCode: 'LOCKME', isEnabled: true, baseFeatureTimelineId: 12 }],
    });
  });

  it('sends nothing when the dialog is cancelled', async () => {
    await enableLockFeature();

    const dialog = await screen.findByRole('dialog');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Cancel' }));

    // The panel itself is also a dialog, so the lock prompt is found by its title.
    await waitFor(() => expect(screen.queryByRole('dialog', { name: 'Lock feature' })).not.toBeInTheDocument());
    expect(post).not.toHaveBeenCalled();
  });
});

describe('Impact Area (AC-RAIL-069, 075)', () => {
  const ROLE_PREVIEW = {
    directRoles: 2,
    wildcardRoles: 1,
    overlayRoles: 0,
    roles: ['Ops', 'Admin', 'Audit'],
    users: 7,
    restore: 0,
    skipped: 0,
    blocking: [],
    reconcileInProgress: false,
  };

  function serveImpact(detail: RailDetail, impact: unknown) {
    get.mockImplementation((url: string) =>
      Promise.resolve(
        url.includes('railWorkflow')
          ? apiOk({ makerOnlyActions: ['ModifyRail'], checkerPermission: null })
          : url.includes('rail-impact')
            ? apiOk(impact)
            : apiOk(detail),
      ),
    );
  }

  async function openImpact(detail: RailDetail, impact: unknown) {
    serveImpact(detail, impact);
    renderWithProviders(<RailModifySheet railCode={detail.railCode} onClose={vi.fn()} onCompleted={vi.fn()} />);
    await screen.findByLabelText(/RAIL Name/);
  }

  const impactCalls = () => get.mock.calls.filter(([url]) => url === '/iam/rail-impact');

  it('runs no preview until asked, then asks for the status change in rail mode', async () => {
    await openImpact(detailOf(), ROLE_PREVIEW);
    expect(impactCalls()).toHaveLength(0);

    await chooseOption(screen.getByRole('combobox', { name: 'Status' }), 'Disabled');
    await userEvent.click(screen.getByRole('button', { name: 'Preview impact' }));

    expect(await screen.findByText(/Roles affected: 3/)).toBeInTheDocument();
    expect(screen.getByText('Users affected: 7')).toBeInTheDocument();
    expect(impactCalls()[0][1]).toEqual({ params: { rail: 'IPI', change: 'disable' } });
  });

  it('offers no preview without the write key', async () => {
    grant(PERM.railPage);
    await openImpact(detailOf({ railCode: 'PLATFORM', currencies: [] }), {});

    await userEvent.click(screen.getAllByRole('button', { name: 'Impact Area' })[0]);

    expect(screen.queryByRole('button', { name: 'Preview impact' })).not.toBeInTheDocument();
  });

  it('disables Save while a disable is running its reconcile', async () => {
    await openImpact(detailOf(), { ...ROLE_PREVIEW, reconcileInProgress: true });

    await chooseOption(screen.getByRole('combobox', { name: 'Status' }), 'Disabled');
    await userEvent.click(screen.getByRole('button', { name: 'Preview impact' }));

    expect(await screen.findByText(/still running/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Save Changes' })).toBeDisabled();
  });

  it('disables Save while an enable is blocked by a role request, and lists it', async () => {
    await openImpact(detailOf({ status: 'Disabled' }), {
      ...ROLE_PREVIEW,
      directRoles: 0,
      wildcardRoles: 0,
      restore: 1,
      blocking: [{ roleName: 'Ops', requestId: 31 }],
    });

    await chooseOption(screen.getByRole('combobox', { name: 'Status' }), 'Active');
    await userEvent.click(screen.getByRole('button', { name: 'Preview impact' }));

    expect(await screen.findByText('Ops (request 31)')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Save Changes' })).toBeDisabled();
  });

  it('does not block an enable for a reconcile, nor a disable for a pending role request', async () => {
    await openImpact(detailOf(), { ...ROLE_PREVIEW, blocking: [{ roleName: 'Ops', requestId: 31 }] });

    await chooseOption(screen.getByRole('combobox', { name: 'Status' }), 'Disabled');
    await userEvent.click(screen.getByRole('button', { name: 'Preview impact' }));
    await screen.findByText(/Roles affected: 3/);

    expect(screen.getByRole('button', { name: 'Save Changes' })).toBeEnabled();
  });

  it('sends the preview it saw as impactSummary', async () => {
    post.mockResolvedValue(SAVED);
    await openImpact(detailOf(), ROLE_PREVIEW);

    await chooseOption(screen.getByRole('combobox', { name: 'Status' }), 'Disabled');
    await userEvent.click(screen.getByRole('button', { name: 'Preview impact' }));
    await screen.findByText(/Roles affected: 3/);
    await userEvent.type(screen.getByLabelText(/^Remarks/), 'Retire it');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    await waitFor(() => expect(post).toHaveBeenCalledTimes(1));
    expect(post.mock.calls[0][1]).toMatchObject({ status: 'Disabled', impactSummary: { status: ROLE_PREVIEW } });
  });

  it('sends no impactSummary when no preview was run', async () => {
    post.mockResolvedValue(SAVED);
    await openImpact(detailOf(), ROLE_PREVIEW);

    await userEvent.click(screen.getByRole('switch', { name: /PII Masking/ }));
    await userEvent.type(screen.getByLabelText(/^Remarks/), 'Enable');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    await waitFor(() => expect(post).toHaveBeenCalledTimes(1));
    expect(post.mock.calls[0][1]).not.toHaveProperty('impactSummary', expect.anything());
  });

  it('previews PII on PLATFORM in PII mode and never calls rail mode', async () => {
    await openImpact(detailOf({ railCode: 'PLATFORM', currencies: [], features: [feature({ isEnabled: true })] }), {
      fields: [{ viewKey: 'field.iban:view', roles: ['Ops'], users: 4 }],
      users: 4,
    });

    await userEvent.click(screen.getByRole('button', { name: 'Impact Area' }));
    await userEvent.click(screen.getByRole('button', { name: 'Preview impact' }));

    expect(await screen.findByText('field.iban:view: 1 roles, 4 users')).toBeInTheDocument();
    expect(impactCalls()[0][1]).toEqual({ params: { feature: 'PII', level: 'PLATFORM', enable: false } });
    expect(impactCalls().every(([, config]) => !('rail' in (config as { params: object }).params))).toBe(true);
  });

  it('shows a feature\'s impact text and the rails it is core for', async () => {
    await openImpact(
      detailOf({ features: [feature({ impactText: 'Masks card numbers.', coreForRails: ['FTS'] })] }),
      {},
    );

    await userEvent.click(screen.getByRole('button', { name: 'Impact Area' }));

    expect(screen.getByText('Masks card numbers.')).toBeInTheDocument();
    expect(screen.getByText('Core feature for: FTS')).toBeInTheDocument();
  });
});

describe('Save refusals (AC-RAIL-074)', () => {
  async function trySave() {
    await userEvent.click(screen.getByRole('switch', { name: /PII Masking/ }));
    await userEvent.type(screen.getByLabelText(/^Remarks/), 'Because');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));
  }

  it('tells the Maker a concurrent change happened (409 RAIL_CONCURRENT)', async () => {
    post.mockRejectedValue(apiError(409, 'stale', 'RAIL_CONCURRENT'));
    await open(detailOf());

    await trySave();

    expect(await screen.findByRole('alert')).toHaveTextContent('changed by someone else');
  });

  it('names the maker and request of a pending change (409 RAIL_PENDING)', async () => {
    post.mockRejectedValue(apiError(409, 'pending', 'RAIL_PENDING', { requestId: 9, makerBy: 'maker2' }));
    await open(detailOf());

    await trySave();

    expect(await screen.findByRole('alert')).toHaveTextContent('request 9, by maker2');
  });

  it('shows a 422 refusal with its violations', async () => {
    post.mockRejectedValue(
      apiError(422, 'Cannot save.', 'RAIL_RULE', { ruleCode: 'BR-RAIL-004', violations: ['Core feature required'] }),
    );
    await open(detailOf());

    await trySave();

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent('Cannot save.');
    expect(alert).toHaveTextContent('Core feature required');
  });

  it("puts a validator's errors-map entry on its field (400)", async () => {
    post.mockRejectedValue(
      apiError(400, 'Too long.', 'ValidationFailed', { errors: { RailName: ['RAIL Name is too long.'] } }),
    );
    await open(detailOf());

    await trySave();

    await waitFor(() => expect(screen.getByLabelText(/RAIL Name/)).toHaveAttribute('aria-invalid', 'true'));
    expect(screen.getByText('RAIL Name is too long.')).toBeInTheDocument();
  });
});
