import type { ReactNode } from 'react';
import { render, screen, within } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import type { RouteObject } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiOk, expectNotActionable, grant, renderWithProviders } from '../../../test/renderWithProviders';
import { DesktopSidebar } from '../../shared/layouts/DesktopSidebar';
import { routes } from '../../router';
import { RailConfigurationPage } from './RailConfigurationPage';
import { railApi } from './api';
import { filtersToParams } from './filters';
import type { RailRow } from './types';

// The route guard's session check reads storage; a signed-in session is all these cases need.
vi.mock('@paymenthub/ui', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@paymenthub/ui')>()),
  getCurrentUserFromStorage: () => ({ id: 'u1' }),
}));
vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

const ROW: RailRow = {
  sl: 1,
  railCode: 'IPI',
  railName: 'Instant Payments',
  description: 'Instant payment rail',
  currency: 'AED, USD',
  createdAt: '2026-09-28T14:15:30Z',
  createdBy: 'maker1',
  status: 'Active',
  isPending: false,
  lastModifiedAt: '2026-10-01T09:05:07Z',
  lastModifiedBy: 'maker2',
  lastAction: { action: 'Modify RAIL - Accepted', outcome: 'Applied' },
};

function listOf(items: RailRow[]) {
  return apiOk({ items, pageNumber: 1, pageSize: 20, totalRecords: items.length });
}

beforeEach(() => {
  get.mockReset();
  get.mockResolvedValue(listOf([]));
});

function findRoute(list: RouteObject[], path: string): RouteObject | undefined {
  for (const r of list) {
    if (r.path === path) return r;
    const nested = r.children ? findRoute(r.children, path) : undefined;
    if (nested) return nested;
  }
  return undefined;
}

function inClient(ui: ReactNode, entry: string) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[entry]}>{ui}</MemoryRouter>
    </QueryClientProvider>,
  );
}

// ── Route and header (AC-RAIL-063, 077) ─────────────────────────────────────────

describe('RAIL route', () => {
  const route = findRoute(routes, 'admin/rails');

  function mountRoute() {
    return inClient(
      <Routes>
        <Route path="/admin/rails" element={route?.element} />
        <Route path="/unauthorized" element={<p>Unauthorized</p>} />
      </Routes>,
      '/admin/rails',
    );
  }

  it('is declared at admin/rails and the old platform/rail route is gone', () => {
    expect(route).toBeDefined();
    expect(findRoute(routes, 'platform/rail')).toBeUndefined();
  });

  it('sends a session without page.rail:view to /unauthorized', async () => {
    grant(PERM.departmentPage);
    mountRoute();
    expect(await screen.findByText('Unauthorized')).toBeInTheDocument();
  });

  it('opens the screen for a holder of page.rail:view', async () => {
    grant(PERM.railPage);
    mountRoute();
    expect(await screen.findByRole('heading', { name: 'RAIL Configuration' })).toBeInTheDocument();
  });
});

describe('RAIL page shell', () => {
  it('shows the header and the full breadcrumb, with no New, Approve or Reject control', () => {
    grant(PERM.railPage, PERM.railWrite);
    renderWithProviders(<RailConfigurationPage />);

    expect(screen.getByRole('heading', { name: 'RAIL Configuration' })).toBeInTheDocument();
    const crumb = screen.getByRole('navigation', { name: 'Breadcrumb' });
    expect(crumb).toHaveTextContent('Payment Hub Operations Console › Administration › RAIL');
    expect(screen.queryByRole('button', { name: /New/ })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /Approve|Reject/ })).not.toBeInTheDocument();
  });
});

// ── Sidebar ─────────────────────────────────────────────────────────────────────

describe('RAIL sidebar entry', () => {
  it('lists RAIL under the Platform heading in Administration for a holder, linking to admin/rails', () => {
    grant(PERM.railPage);
    inClient(<DesktopSidebar />, '/admin/rails');

    const link = screen.getAllByRole('link', { name: 'RAIL' })[0];
    expect(link).toHaveAttribute('href', '/admin/rails');
    expect(screen.getAllByText('Platform').length).toBeGreaterThan(0);
  });

  it('hides the entry from a session without the page key', () => {
    grant(PERM.departmentPage);
    inClient(<DesktopSidebar />, '/admin/departments');

    expect(screen.queryByRole('link', { name: 'RAIL' })).not.toBeInTheDocument();
  });
});

// ── Grid (AC-RAIL-064, 065, 066, 067, 072) ──────────────────────────────────────

describe('RAIL grid', () => {
  it('shows the 12 FSD columns in order and loads page 1 at size 20', async () => {
    grant(PERM.railPage, PERM.railWrite);
    get.mockResolvedValue(listOf([ROW]));
    renderWithProviders(<RailConfigurationPage />);

    await screen.findByText('IPI');
    const headers = within(screen.getAllByRole('row')[0])
      .getAllByRole('columnheader')
      .map((h) => h.textContent?.trim() ?? '');
    const expected = [
      'Sl', 'RAIL Code', 'RAIL Name', 'Description', 'Currency', 'Created', 'Created By',
      'Status', 'Last Modified', 'Last Modified By', 'Last Action', 'Actions',
    ];
    const positions = expected.map((label) => headers.findIndex((h) => h.startsWith(label)));
    expect(positions.every((p) => p >= 0)).toBe(true);
    expect([...positions].sort((a, b) => a - b)).toEqual(positions);

    expect(get).toHaveBeenCalledWith(
      '/ops/railList',
      expect.objectContaining({ params: expect.objectContaining({ pageSize: 20, pageNumber: 1 }) }),
    );
  });

  it('formats dates DD-MM-YYYY HH:MM:SS and shows the Last Action label', async () => {
    grant(PERM.railPage);
    get.mockResolvedValue(listOf([ROW]));
    renderWithProviders(<RailConfigurationPage />);

    expect(await screen.findByText('28-09-2026 18:15:30')).toBeInTheDocument(); // session zone (Dubai), was UTC
    expect(screen.getByText('01-10-2026 13:05:07')).toBeInTheDocument();
    expect(screen.getByText('Modify RAIL - Accepted')).toBeInTheDocument();
    expect(screen.getByText('AED, USD')).toBeInTheDocument();
  });

  it('shows a pending rail as Pending with View & Modify disabled and Audit Trail enabled', async () => {
    grant(PERM.railPage, PERM.railWrite);
    get.mockResolvedValue(
      listOf([
        { ...ROW, railCode: 'FTS', isPending: true, lastAction: { action: 'Modify RAIL', outcome: 'Pending' } },
        { ...ROW, railCode: 'PLATFORM', currency: null, status: 'Disabled', lastAction: null },
      ]),
    );
    renderWithProviders(<RailConfigurationPage />);
    await screen.findByText('FTS');

    expect(screen.getByText('Pending')).toBeInTheDocument();
    expect(screen.getByText('Modify RAIL')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'View and modify FTS' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'View audit trail for FTS' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'View and modify PLATFORM' })).toBeEnabled();
    expect(screen.getByText('Disabled')).toBeInTheDocument();
    // PLATFORM has no currency and no last action.
    expect(screen.getAllByText('—').length).toBeGreaterThanOrEqual(2);
  });

  it('shows the empty state', async () => {
    grant(PERM.railPage);
    renderWithProviders(<RailConfigurationPage />);

    expect(await screen.findByText('No rails')).toBeInTheDocument();
    expect(screen.getByText('No rails match the current filters.')).toBeInTheDocument();
  });

  it('shows a retryable error when the list cannot be loaded', async () => {
    grant(PERM.railPage);
    get.mockRejectedValue(new Error('boom'));
    renderWithProviders(<RailConfigurationPage />);

    expect(await screen.findByRole('alert')).toHaveTextContent('The rails could not be loaded.');
    expect(screen.getByRole('button', { name: 'Retry' })).toBeInTheDocument();
  });

  it('offers Export only to a holder of ops:report:export', async () => {
    grant(PERM.railPage);
    get.mockResolvedValue(listOf([ROW]));
    const { unmount } = renderWithProviders(<RailConfigurationPage />);
    await screen.findByText('IPI');
    expectNotActionable(screen.queryByRole('button', { name: /Export/ }));
    unmount();

    grant(PERM.railPage, PERM.opsReportExport);
    renderWithProviders(<RailConfigurationPage />);
    await screen.findByText('IPI');
    expect(screen.getByRole('button', { name: /Export/ })).toBeInTheDocument();
  });
});

describe('RAIL grid filters', () => {
  it('maps the grid filters to list parameters, with arrays for Status and Last Action', () => {
    expect(
      filtersToParams({
        railCode: ' ipi ',
        createdFrom: '2026-09-01',
        createdTo: '2026-09-30',
        status: 'Active,Pending',
        lastAction: 'Modify RAIL,Modify RAIL - Rejected',
        lastModifiedBy: '',
      }),
    ).toEqual(
      expect.objectContaining({
        railCode: 'ipi',
        createdFrom: '2026-09-01',
        createdTo: '2026-09-30',
        status: ['Active', 'Pending'],
        lastAction: ['Modify RAIL', 'Modify RAIL - Rejected'],
        lastModifiedBy: undefined,
        currency: undefined,
      }),
    );
  });

  it('asks for repeated keys, not indexed ones (serializer config only; the real server is not yet exercised)', async () => {
    await railApi.list({ status: ['Active', 'Pending'], lastAction: ['Modify RAIL'], pageSize: 20, pageNumber: 1 });
    const config = get.mock.calls.at(-1)?.[1] as { params: Record<string, unknown>; paramsSerializer: unknown };
    expect(config.params.status).toEqual(['Active', 'Pending']);
    expect(config.paramsSerializer).toEqual({ indexes: null });
  });
});
