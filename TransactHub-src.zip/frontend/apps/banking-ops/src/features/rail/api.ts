import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { bankingApi } from '../../shared/api/bankingApi';
import { railKeys } from './queryKeys';
import { PII_FEATURE_CODE, PLATFORM_RAIL_CODE } from './types';
import type {
  RailAuditParams,
  RailAuditResponse,
  RailDetail,
  RailExportFormat,
  RailImpactParams,
  RailImpactPreview,
  RailListParams,
  RailListResponse,
  RailPiiImpactPreview,
  RailSavedResponse,
  RailWorkflow,
  SaveRailRequest,
} from './types';

/**
 * RAIL configuration over the Operations API (RAIL design §5) and the IAM impact preview. The tenant and the
 * acting user come from the session server-side. The browser base is `bankingApi` (`/api`), so the paths here
 * are `/ops/...` and `/iam/...`.
 */
const BASE = '/ops';

/** Repeated keys for arrays (`status=A&status=B`), as the server's list binder reads them. */
const REPEAT_KEYS = { indexes: null } as const;

function listQuery(p: RailListParams) {
  return {
    railCode: p.railCode || undefined,
    railName: p.railName || undefined,
    description: p.description || undefined,
    currency: p.currency || undefined,
    // Days stay `yyyy-MM-dd`: these endpoints bind DateOnly days and read them in the session zone (UTC date-time T-22).
    createdFrom: p.createdFrom || undefined,
    createdTo: p.createdTo || undefined,
    createdBy: p.createdBy || undefined,
    status: p.status?.length ? p.status : undefined,
    lastModifiedFrom: p.lastModifiedFrom || undefined,
    lastModifiedTo: p.lastModifiedTo || undefined,
    lastModifiedBy: p.lastModifiedBy || undefined,
    lastAction: p.lastAction?.length ? p.lastAction : undefined,
    sortBy: p.sortBy,
    sortDirection: p.sortBy ? p.sortDirection : undefined,
  };
}

export const railApi = {
  list: (p: RailListParams) =>
    bankingApi
      .get<RailListResponse>(`${BASE}/railList`, {
        params: { ...listQuery(p), pageSize: p.pageSize, pageNumber: p.pageNumber },
        paramsSerializer: REPEAT_KEYS,
      })
      .then((r) => r.data),

  detail: (railCode: string) =>
    bankingApi.get<RailDetail>(`${BASE}/railDetail/${encodeURIComponent(railCode)}`).then((r) => r.data),

  workflow: () => bankingApi.get<RailWorkflow>(`${BASE}/railWorkflow`).then((r) => r.data),

  audit: (railCode: string, p: RailAuditParams) =>
    bankingApi
      .get<RailAuditResponse>(`${BASE}/railAudit/${encodeURIComponent(railCode)}`, {
        params: {
          section: p.section || undefined,
          // Days stay `yyyy-MM-dd`: these endpoints bind DateOnly days and read them in the session zone (UTC date-time T-22).
          fromDate: p.fromDate || undefined,
          toDate: p.toDate || undefined,
          pageNumber: p.pageNumber,
        },
      })
      .then((r) => r.data),

  save: (railCode: string, body: SaveRailRequest) =>
    bankingApi
      .post<RailSavedResponse>(`${BASE}/railSave/${encodeURIComponent(railCode)}`, body)
      .then((r) => r.data),

  /** The whole filtered set, server-rendered; `columns` are the visible column keys in display order. */
  export: (format: RailExportFormat, p: RailListParams, columns: string[]) =>
    bankingApi
      .get<Blob>(`${BASE}/railExport/${format}`, {
        // The server reads `Columns` as one comma-separated string, not a repeated key.
        params: { ...listQuery(p), columns: columns.length > 0 ? columns.join(',') : undefined },
        paramsSerializer: REPEAT_KEYS,
        responseType: 'blob',
      })
      .then((r) => r.data),

  /** Rail mode (`rail` + `change`, never for PLATFORM) or PII mode (`feature=PII&level=PLATFORM&enable`). */
  impact: (p: RailImpactParams) =>
    bankingApi
      .get<RailImpactPreview | RailPiiImpactPreview>('/iam/rail-impact', {
        params:
          p.kind === 'rail'
            ? { rail: p.rail, change: p.change }
            : { feature: PII_FEATURE_CODE, level: PLATFORM_RAIL_CODE, enable: p.enable },
      })
      .then((r) => r.data),
};

export function useRailList(params: RailListParams) {
  return useQuery({
    queryKey: railKeys.list(params),
    queryFn: () => railApi.list(params),
    placeholderData: keepPreviousData,
  });
}

export function useRailDetail(railCode: string) {
  return useQuery({
    queryKey: railKeys.detail(railCode),
    queryFn: () => railApi.detail(railCode),
  });
}

export function useRailWorkflow() {
  return useQuery({
    queryKey: railKeys.workflow(),
    queryFn: () => railApi.workflow(),
    staleTime: 5 * 60_000,
  });
}

export function useRailAudit(railCode: string, params: RailAuditParams) {
  return useQuery({
    queryKey: railKeys.audit(railCode, params),
    queryFn: () => railApi.audit(railCode, params),
    placeholderData: keepPreviousData,
  });
}

/** A save refreshes the grid and the rail's detail and audit feed. */
export function useSaveRail() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ railCode, body }: { railCode: string; body: SaveRailRequest }) => railApi.save(railCode, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: railKeys.all }),
  });
}

/** The impact preview is on demand, so it is a mutation: no cache, one call per operator request. */
export function useRailImpact() {
  return useMutation({
    mutationFn: (p: RailImpactParams) => railApi.impact(p),
  });
}
