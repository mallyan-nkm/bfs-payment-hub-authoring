import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Can, Dialog, Input, Select, Switch, Textarea, cn, usePermissions, useSessionDateTime } from '@paymenthub/ui';
import { Info, Lock } from 'lucide-react';
import { SideSheet } from '../../shared/components/SideSheet';
import { PERM } from '../../shared/auth/permissionKeys';
import { useRailDetail, useRailWorkflow, useSaveRail } from './api';
import { isRailErrorCode, railErrorMessage, railFieldErrors, railProblem, railViolationMessages } from './errors';
import type { RailFieldMap } from './errors';
import {
  FormRow,
  MAX_DESCRIPTION,
  MAX_RAIL_NAME,
  PANEL_WIDTH,
  PanelError,
  PanelFooter,
  ReadOnlyInput,
  RemarksField,
  SERVER_ERROR,
  fieldErrorText,
} from './formParts';
import { statusLabel, useRailTranslation } from './i18n';
import { modifyRailSchema } from './schemas';
import type { ModifyRailForm } from './schemas';
import { FeatureImpact, RailStatusImpact } from './RailImpactArea';
import type { PiiPreview, StatusPreview } from './RailImpactArea';
import {
  PII_FEATURE_CODE,
  PLATFORM_RAIL_CODE,
  RAIL_ACTION,
  RAIL_ERROR_CODES,
  RAIL_IMPACT_CHANGE,
  RAIL_OUTCOME,
  RAIL_STATUS,
} from './types';
import type { RailDetail, RailImpactChange, RailImpactSummary, RailStatus, SaveRailFeature } from './types';

/** The server names the Maker's comments `Remarks`, as the form does. */
const SERVER_FIELDS: RailFieldMap<keyof ModifyRailForm> = {
  properties: { railName: 'railName', description: 'description', status: 'status', remarks: 'remarks' },
};

/** Pending is shown when it is the rail's state, but it is never an option to choose. */
const EDITABLE_STATUSES: RailStatus[] = [RAIL_STATUS.Active, RAIL_STATUS.Disabled];

const featureValues = (detail: RailDetail) =>
  Object.fromEntries(detail.features.map((f) => [f.featureCode, f.isEnabled])) as Record<string, boolean>;

/**
 * View & Modify (FSD §5.3, design §7.2). Reads `railDetail`, not the grid row, because what can be done depends
 * on the newest request: a Pending one locks the rail until the Checker decides, a Rejected one shows the
 * Checker's remarks read-only. Maker-only: a save applies at once, so there is no Approve or Reject here.
 */
export function RailModifySheet({
  railCode,
  onClose,
  onCompleted,
}: {
  railCode: string;
  onClose: () => void;
  onCompleted: (message: string) => void;
}) {
  const { t } = useRailTranslation();
  const detailQuery = useRailDetail(railCode);
  const detail = detailQuery.data;

  if (detail) {
    return (
      <ModifyForm
        // Remount on a refetch after a save, so the form starts from the rail's new state.
        key={`${detail.railCode}-${detail.baseTimelineId}-${detail.latestRequest?.requestId ?? 0}`}
        detail={detail}
        onClose={onClose}
        onCompleted={onCompleted}
      />
    );
  }

  return (
    <SideSheet
      eyebrow={t('MODIFY.EYEBROW')}
      title={t('MODIFY.LOADING_TITLE')}
      subtitle={t('MODIFY.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={
        <Button type="button" variant="secondary" onClick={onClose}>
          {t('FORM.CANCEL')}
        </Button>
      }
    >
      {detailQuery.isError ? (
        <div className="flex flex-col items-center gap-3">
          <PanelError message={railErrorMessage(detailQuery.error, t('ERROR.REQUEST_FAILED'))} />
          <Button type="button" variant="outline" size="sm" onClick={() => void detailQuery.refetch()}>
            {t('MODIFY.RETRY')}
          </Button>
        </div>
      ) : (
        <p role="status" className="p-6 text-center text-sm text-[var(--text-2)]">
          {t('MODIFY.LOADING')}
        </p>
      )}
    </SideSheet>
  );
}

function ModifyForm({
  detail,
  onClose,
  onCompleted,
}: {
  detail: RailDetail;
  onClose: () => void;
  onCompleted: (message: string) => void;
}) {
  const { t } = useRailTranslation();
  const { formatInstant } = useSessionDateTime();
  const { can } = usePermissions();
  const canWrite = can(PERM.railWrite);
  const [panelError, setPanelError] = useState<{ message: string; items: string[] } | null>(null);
  const [lockPrompt, setLockPrompt] = useState<string[] | null>(null);
  // The last preview the Maker ran for the status and for PII; each counts only while it matches the form.
  const [statusPreview, setStatusPreview] = useState<StatusPreview | null>(null);
  const [piiPreview, setPiiPreview] = useState<PiiPreview | null>(null);

  const save = useSaveRail();
  const workflow = useRailWorkflow();
  const makerOnly = workflow.data?.makerOnlyActions.includes(RAIL_ACTION.ModifyRail) ?? false;

  const isPlatform = detail.railCode === PLATFORM_RAIL_CODE;
  const canModify = canWrite && !detail.isPending;

  const {
    register,
    control,
    handleSubmit,
    setError,
    setValue,
    watch,
    formState: { errors },
  } = useForm<ModifyRailForm>({
    resolver: zodResolver(modifyRailSchema),
    defaultValues: {
      railName: detail.railName,
      description: detail.description,
      status: detail.status,
      features: featureValues(detail),
      remarks: '',
    },
    shouldFocusError: true,
  });

  // A refusal is about what was submitted; editing anything clears it.
  useEffect(() => {
    const subscription = watch(() => setPanelError(null));
    return () => subscription.unsubscribe();
  }, [watch]);

  const features = watch('features');
  const statusValue = watch('status');

  // The rail's own Disabled ⇄ Active change has an IAM preview; PLATFORM's status is read-only, so it has none.
  const statusChange: RailImpactChange | null =
    isPlatform || statusValue === detail.status
      ? null
      : statusValue === RAIL_STATUS.Disabled
        ? RAIL_IMPACT_CHANGE.Disable
        : statusValue === RAIL_STATUS.Active
          ? RAIL_IMPACT_CHANGE.Enable
          : null;
  const currentStatusPreview = statusChange && statusPreview?.change === statusChange ? statusPreview : null;
  // Save waits while a re-enable is blocked by a role's pending request, or a disable by a running reconcile.
  const previewBlocked = currentStatusPreview?.blocked ?? false;

  const rejected = detail.lastAction?.outcome === RAIL_OUTCOME.Rejected;
  const request = detail.latestRequest;

  const statusOptions: RailStatus[] = EDITABLE_STATUSES.includes(detail.status)
    ? EDITABLE_STATUSES
    : [detail.status, ...EDITABLE_STATUSES];

  function fail(error: unknown) {
    if (isRailErrorCode(error, RAIL_ERROR_CODES.Concurrent)) {
      setPanelError({ message: t('ERROR.CONCURRENT'), items: [] });
      return;
    }
    const problem = railProblem(error);
    if (isRailErrorCode(error, RAIL_ERROR_CODES.Pending)) {
      setPanelError({
        message: t('ERROR.PENDING', { requestId: problem?.requestId ?? '', makerBy: problem?.makerBy ?? '—' }),
        items: [],
      });
      return;
    }
    const fieldErrors = railFieldErrors(error, SERVER_FIELDS);
    if (fieldErrors.length === 0) {
      setPanelError({
        message: railErrorMessage(error, t('ERROR.REQUEST_FAILED')),
        items: railViolationMessages(problem),
      });
      return;
    }
    fieldErrors.forEach(({ field, message }, i) =>
      setError(field, { type: SERVER_ERROR, message }, { shouldFocus: i === 0 }),
    );
  }

  /** Only features that differ from the detail go to the server, each with the row it was read from. */
  function changedFeatures(values: ModifyRailForm): SaveRailFeature[] {
    return detail.features
      .filter((f) => values.features[f.featureCode] !== f.isEnabled)
      .map((f) => ({
        featureCode: f.featureCode,
        isEnabled: values.features[f.featureCode],
        baseFeatureTimelineId: f.baseFeatureTimelineId,
      }));
  }

  /** The previews the Maker saw that still describe what is being saved (D-4); undefined when there are none. */
  function impactSummaryOf(values: ModifyRailForm, changed: SaveRailFeature[]): RailImpactSummary | undefined {
    const pii = changed.some((c) => c.featureCode === PII_FEATURE_CODE) &&
      piiPreview?.enable === values.features[PII_FEATURE_CODE]
      ? piiPreview.data
      : undefined;
    const status = currentStatusPreview?.data;
    return status || pii ? { ...(status && { status }), ...(pii && { pii }) } : undefined;
  }

  async function submit(values: ModifyRailForm, lockConfirmed: boolean) {
    const changed = changedFeatures(values);
    const unchanged =
      values.railName.trim() === detail.railName &&
      values.description.trim() === detail.description &&
      values.status === detail.status &&
      changed.length === 0;
    if (unchanged) {
      setPanelError({ message: t('MODIFY.NO_CHANGES'), items: [] });
      return;
    }

    // A lock-once feature being turned on needs the Maker's explicit OK first (design §7.3).
    const locking = detail.features.filter(
      (f) => f.lockOnceEnabled && !f.isEnabled && changed.some((c) => c.featureCode === f.featureCode),
    );
    if (locking.length > 0 && !lockConfirmed) {
      setLockPrompt(locking.map((f) => f.featureName));
      return;
    }

    try {
      const result = await save.mutateAsync({
        railCode: detail.railCode,
        body: {
          baseTimelineId: detail.baseTimelineId,
          railName: values.railName.trim(),
          description: values.description.trim(),
          status: values.status,
          features: changed,
          lockConfirmed,
          remarks: values.remarks.trim(),
          impactSummary: impactSummaryOf(values, changed),
        },
      });
      onCompleted(t(result.applied ? 'TOAST.APPLIED' : 'TOAST.SUBMITTED', { code: detail.railCode }));
    } catch (error) {
      fail(error);
    }
  }

  const saveChanges = (lockConfirmed: boolean) => handleSubmit((values) => submit(values, lockConfirmed))();

  const footer = (
    <PanelFooter onCancel={onClose}>
      <Can permission={PERM.railWrite}>
        <Button
          type="button"
          variant="primary"
          disabled={!canModify || save.isPending || previewBlocked}
          title={canModify ? undefined : t('MODIFY.BLOCKED_PENDING')}
          onClick={() => void saveChanges(false)}
        >
          {save.isPending ? t('FORM.SAVING') : t('MODIFY.SAVE_CHANGES')}
        </Button>
      </Can>
    </PanelFooter>
  );

  return (
    <SideSheet
      eyebrow={t('MODIFY.EYEBROW')}
      title={detail.railName}
      subtitle={t('MODIFY.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={footer}
    >
      <div>
        <PanelError message={panelError?.message ?? null} items={panelError?.items} />

        {makerOnly && canWrite && (
          <div
            role="note"
            className="mb-4 flex gap-2 rounded-lg border border-[var(--primary-blue)]/30 bg-[var(--primary-blue)]/5 px-3 py-2 text-xs text-[var(--text-primary)]"
          >
            <Info size={14} className="mt-0.5 shrink-0 text-[var(--primary-blue)]" aria-hidden="true" />
            <span>{t('MODIFY.MAKER_ONLY')}</span>
          </div>
        )}

        {detail.isPending && (
          <div
            role="status"
            className="mb-4 flex gap-2 rounded-lg border border-[var(--accent-amber)]/40 bg-[var(--accent-amber)]/10 px-3 py-2 text-xs text-[var(--text-primary)]"
          >
            <Info size={14} className="mt-0.5 shrink-0 text-[var(--accent-amber)]" aria-hidden="true" />
            <span>{t('MODIFY.PENDING_NOTICE', { requestId: request?.requestId ?? '' })}</span>
          </div>
        )}

        {rejected && request && (
          <section
            aria-labelledby="approver-remarks-heading"
            className="mb-4 rounded-lg border border-[var(--accent-red)]/40 bg-[var(--accent-red)]/5 px-3 py-2"
          >
            <h3
              id="approver-remarks-heading"
              className="text-xs font-bold uppercase tracking-wider text-[var(--accent-red)]"
            >
              {t('MODIFY.APPROVER_REMARKS')}
            </h3>
            <p className="mt-1 text-[11px] text-[var(--text-muted)]">
              {t('MODIFY.CHECKER', {
                checker: request.checkerName ?? '—',
                at: formatInstant(request.checkerAt),
              })}
            </p>
            <Textarea
              id="approver-remarks"
              aria-labelledby="approver-remarks-heading"
              value={request.checkerRemarks ?? ''}
              readOnly
              rows={3}
              className="input-cls mt-2 w-full cursor-default resize-none bg-[var(--bg-secondary)] text-xs text-[var(--text-2)]"
            />
          </section>
        )}

        <div className="flex flex-col gap-3">
          <FormRow label={t('FORM.RAIL_CODE')} htmlFor="modify-rail-code">
            <ReadOnlyInput id="modify-rail-code" value={detail.railCode} mono />
          </FormRow>
          <FormRow label={t('FORM.CURRENCY')} htmlFor="modify-rail-currency">
            <ReadOnlyInput
              id="modify-rail-currency"
              value={isPlatform || detail.currencies.length === 0 ? '—' : detail.currencies.join(', ')}
            />
          </FormRow>
          <FormRow label={t('FORM.RAIL_NAME')} htmlFor="modify-rail-name" required={canModify}>
            <Input
              id="modify-rail-name"
              maxLength={MAX_RAIL_NAME}
              readOnly={!canModify}
              aria-required={canModify}
              error={fieldErrorText(t, errors.railName)}
              className={cn(
                'h-10 w-full text-xs',
                !canModify && 'cursor-not-allowed bg-[var(--bg-secondary)] text-[var(--text-2)]',
              )}
              {...register('railName')}
            />
          </FormRow>
          <FormRow label={t('FORM.DESCRIPTION')} htmlFor="modify-rail-description" required={canModify}>
            <Textarea
              id="modify-rail-description"
              rows={2}
              maxLength={MAX_DESCRIPTION}
              readOnly={!canModify}
              aria-required={canModify}
              error={fieldErrorText(t, errors.description)}
              className={cn(
                'w-full resize-none text-xs',
                !canModify && 'cursor-not-allowed bg-[var(--bg-secondary)] text-[var(--text-2)]',
              )}
              {...register('description')}
            />
          </FormRow>
          <FormRow label={t('FORM.STATUS')} htmlFor="modify-rail-status">
            <Controller
              control={control}
              name="status"
              render={({ field }) => (
                <Select
                  id="modify-rail-status"
                  value={field.value}
                  onValueChange={(v) => field.onChange(v as RailStatus)}
                  // PLATFORM's status is read-only (design §7.2).
                  disabled={!canModify || isPlatform}
                  options={statusOptions.map((s) => ({
                    value: s,
                    label: statusLabel(t, s),
                    disabled: !EDITABLE_STATUSES.includes(s),
                  }))}
                  className="h-10 w-full text-xs"
                />
              )}
            />
          </FormRow>
          {canModify && statusChange && (
            <RailStatusImpact
              railCode={detail.railCode}
              change={statusChange}
              preview={statusPreview}
              onPreview={setStatusPreview}
            />
          )}
        </div>

        <section aria-labelledby="rail-features-heading" className="mt-5">
          <h3
            id="rail-features-heading"
            className="mb-2 text-xs font-bold uppercase tracking-wider text-[var(--text-primary)]"
          >
            {t('FEATURES.TITLE')}
          </h3>
          {detail.features.length === 0 ? (
            <p role="status" className="rounded-lg border border-dashed border-[var(--border)] p-4 text-center text-xs text-[var(--text-2)]">
              {t('FEATURES.EMPTY')}
            </p>
          ) : (
            <ul className="flex flex-col gap-2">
              {detail.features.map((f) => {
                const switchId = `rail-feature-${f.featureCode}`;
                const isOn = features[f.featureCode] ?? f.isEnabled;
                return (
                  <li
                    key={f.featureCode}
                    className="rounded-lg border border-[var(--border)] bg-[var(--bg-secondary)] px-3 py-2"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <label
                        htmlFor={switchId}
                        className={cn(
                          'min-w-0 flex-1 text-xs font-semibold text-[var(--text-primary)]',
                          !canModify || f.isLocked ? 'cursor-not-allowed' : 'cursor-pointer',
                        )}
                      >
                        {f.featureName}
                      </label>
                      {f.lockOnceEnabled && (
                        <Lock
                          size={14}
                          className="shrink-0 text-[var(--text-muted)]"
                          role="img"
                          aria-label={t(f.isLocked ? 'FEATURES.LOCKED' : 'FEATURES.LOCK_ONCE', { feature: f.featureName })}
                        />
                      )}
                      <Switch
                        id={switchId}
                        checked={isOn}
                        disabled={!canModify || f.isLocked}
                        onCheckedChange={(on) => setValue('features', { ...features, [f.featureCode]: on }, { shouldDirty: true })}
                      />
                      <span
                        className={cn(
                          'min-w-[4rem] text-end text-xs',
                          isOn ? 'font-semibold text-[var(--tone-green-fg)]' : 'text-[var(--text-muted)]',
                        )}
                      >
                        {t(isOn ? 'FEATURES.STATE_ENABLED' : 'FEATURES.STATE_DISABLED')}
                      </span>
                    </div>
                    <FeatureImpact
                      feature={f}
                      isPlatform={isPlatform}
                      preview={piiPreview}
                      onPreview={setPiiPreview}
                    />
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {canModify && (
          <div className="mt-5">
            <RemarksField
              id="modify-remarks"
              label={t('FORM.REMARKS')}
              placeholder={t('FORM.REMARKS_PLACEHOLDER')}
              error={fieldErrorText(t, errors.remarks)}
              {...register('remarks')}
            />
          </div>
        )}
      </div>

      <Dialog
        open={lockPrompt !== null}
        onOpenChange={(open) => !open && setLockPrompt(null)}
        title={t('LOCK.TITLE')}
        description={t('LOCK.MESSAGE', { features: (lockPrompt ?? []).join(', ') })}
        footer={
          <>
            <Button type="button" variant="secondary" onClick={() => setLockPrompt(null)}>
              {t('LOCK.CANCEL')}
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={() => {
                setLockPrompt(null);
                // lockConfirmed is sent only from here: the OK is the Maker's explicit confirmation.
                void saveChanges(true);
              }}
            >
              {t('LOCK.OK')}
            </Button>
          </>
        }
      >
        <></>
      </Dialog>
    </SideSheet>
  );
}
