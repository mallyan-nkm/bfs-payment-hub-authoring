import type { RailAuditParams, RailImpactParams, RailListParams } from './types';

/** RAIL query keys (React UI guideline §7). Every command invalidates `all`. */
export const railKeys = {
  all: ['rails'] as const,
  list: (params: RailListParams) => ['rails', 'list', params] as const,
  detail: (railCode: string) => ['rails', 'detail', railCode] as const,
  workflow: () => ['rails', 'workflow'] as const,
  audit: (railCode: string, params: RailAuditParams) => ['rails', 'audit', railCode, params] as const,
  impact: (railCode: string, params: RailImpactParams) => ['rails', 'impact', railCode, params] as const,
};

