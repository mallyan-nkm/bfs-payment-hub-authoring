import { useState } from 'react';
import { Badge, Button, Input, Select, cn, useSessionDateTime } from '@paymenthub/ui';
import type { BadgeVariant } from '@paymenthub/ui';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { SideSheet } from '../../shared/components/SideSheet';
import { useRailAudit } from './api';
import { auditApproval, auditFeatureChange, auditFieldChanges, auditReconciliation } from './auditDiff';
import type { AuditField } from './auditDiff';
import { railErrorMessage } from './errors';
import { formatAuditDateTime } from './format';
import { PanelError } from './formParts';
import { SECTION_KEY, useRailTranslation } from './i18n';
import type { RailT } from './i18n';
import { RAIL_AUDIT_SECTION } from './types';
import type { AuditReconciliation } from './auditDiff';
import type { RailAuditEntry, RailAuditSection, RailRow } from './types';

/** Fixed by the server; the screen has no page-size control (design §7.4). */
const PAGE_SIZE = 10;

const AUDIT_SECTIONS: RailAuditSection[] = Object.values(RAIL_AUDIT_SECTION);

/** Badge variant and heading colour per section, all theme tokens. */
const SECTION_TONE: Record<RailAuditSection, { badge: BadgeVariant; heading: string; bar: string }> = {
  'RAIL Update': { badge: 'blue', heading: 'text-[var(--accent-blue)]', bar: 'bg-[var(--accent-blue)]' },
  'Feature Change': { badge: 'green', heading: 'text-[var(--accent-green)]', bar: 'bg-[var(--accent-green)]' },
  'Status Change': { badge: 'amber', heading: 'text-[var(--accent-amber)]', bar: 'bg-[var(--accent-amber)]' },
  'RAIL Created': { badge: 'outline', heading: 'text-[var(--text-2)]', bar: 'bg-[var(--text-muted)]' },
  Approval: { badge: 'purple', heading: 'text-[var(--accent-purple)]', bar: 'bg-[var(--accent-purple)]' },
};

const FIELD_KEY: Record<AuditField, string> = {
  railCode: 'AUDIT.FIELDS.RAIL_CODE',
  railName: 'AUDIT.FIELDS.RAIL_NAME',
  description: 'AUDIT.FIELDS.DESCRIPTION',
  status: 'AUDIT.FIELDS.STATUS',
  currencies: 'AUDIT.FIELDS.CURRENCIES',
};

const DECISION_KEY: Record<string, string> = {
  Approved: 'AUDIT.APPROVED',
  LevelApproved: 'AUDIT.LEVEL_APPROVED',
  Rejected: 'AUDIT.REJECTED',
};

interface Filters {
  section: RailAuditSection | '';
  fromDate: string;
  toDate: string;
}

const NO_FILTERS: Filters = { section: '', fromDate: '', toDate: '' };

/** Icons that point along the reading direction mirror under RTL. */
const FLIP_IN_RTL = 'rtl:rotate-180';

const valueText = (v: string | null) => v ?? '—';

/**
 * Audit Trail (FSD §5.4, design §7.4): every recorded change to one rail, newest first, as cards. Section and the
 * From / To days are applied by the server (`railAudit`), ten cards a page.
 */
/** The rail the trail is of; the Admin Activity Audit Log opens it from just the code. */
export type RailAuditTarget = Pick<RailRow, 'railCode'>;

export function RailAuditTrailModal({ row, onClose }: { row: RailAuditTarget; onClose: () => void }) {
  const { t } = useRailTranslation();
  const [draft, setDraft] = useState<Filters>(NO_FILTERS);
  const [applied, setApplied] = useState<Filters>(NO_FILTERS);
  const [page, setPage] = useState(1);

  const auditQuery = useRailAudit(row.railCode, {
    section: applied.section || undefined,
    fromDate: applied.fromDate || undefined,
    toDate: applied.toDate || undefined,
    pageNumber: page,
  });

  const entries = auditQuery.data?.items ?? [];
  const total = auditQuery.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const start = (page - 1) * PAGE_SIZE;

  // `yyyy-MM-dd` strings compare in date order.
  const invertedRange = Boolean(draft.fromDate && draft.toDate && draft.toDate < draft.fromDate);

  function search() {
    setApplied(draft);
    setPage(1);
  }

  const sectionOptions = [
    { value: '', label: t('AUDIT.ALL_SECTIONS') },
    ...AUDIT_SECTIONS.map((s) => ({ value: s, label: t(SECTION_KEY[s]) })),
  ];

  const filterLabel = 'text-[11px] font-semibold text-[var(--text-2)]';

  return (
    <SideSheet
      eyebrow={t('AUDIT.EYEBROW', { code: row.railCode })}
      title={t('AUDIT.TITLE')}
      subtitle={t('AUDIT.SUBTITLE')}
      width={560}
      onClose={onClose}
      toolbar={
        <form
          noValidate
          className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1fr_1fr_auto] sm:items-start"
          onSubmit={(e) => {
            e.preventDefault();
            if (!invertedRange) search();
          }}
        >
          <div className="flex min-w-0 flex-col gap-1">
            <label htmlFor="rail-audit-section" className={filterLabel}>
              {t('AUDIT.SECTION')}
            </label>
            <Select
              id="rail-audit-section"
              value={draft.section}
              onValueChange={(v) => setDraft((d) => ({ ...d, section: v as RailAuditSection | '' }))}
              options={sectionOptions}
              className="h-10 min-w-0 px-2 text-xs"
            />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <label htmlFor="rail-audit-from" className={filterLabel}>
              {t('AUDIT.FROM')}
            </label>
            <Input
              id="rail-audit-from"
              type="date"
              value={draft.fromDate}
              onChange={(e) => setDraft((d) => ({ ...d, fromDate: e.target.value }))}
              className="h-10 min-w-0 px-2 text-xs"
            />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <label htmlFor="rail-audit-to" className={filterLabel}>
              {t('AUDIT.TO')}
            </label>
            <Input
              id="rail-audit-to"
              type="date"
              value={draft.toDate}
              onChange={(e) => setDraft((d) => ({ ...d, toDate: e.target.value }))}
              error={invertedRange ? t('AUDIT.RANGE_INVERTED') : undefined}
              className="h-10 min-w-0 px-2 text-xs"
            />
          </div>
          <div className="flex flex-col gap-1">
            {/* Keeps the button level with the controls, under the labels' row. */}
            <span className={cn(filterLabel, 'invisible')} aria-hidden="true">
              {t('AUDIT.SEARCH')}
            </span>
            <Button type="submit" variant="primary" disabled={invertedRange} className="h-10">
              {t('AUDIT.SEARCH')}
            </Button>
          </div>
        </form>
      }
      footer={
        <div className="flex w-full items-center justify-between gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>
            {t('AUDIT.CLOSE')}
          </Button>
          <nav aria-label={t('AUDIT.PAGES')} className="flex items-center gap-2 text-xs text-[var(--text-2)]">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={page <= 1 || auditQuery.isFetching}
              onClick={() => setPage((p) => p - 1)}
              icon={<ChevronLeft size={14} className={FLIP_IN_RTL} aria-hidden="true" />}
            >
              {t('AUDIT.PREV')}
            </Button>
            <span aria-live="polite">
              {t('AUDIT.RANGE', {
                from: total === 0 ? 0 : start + 1,
                to: total === 0 ? 0 : start + entries.length,
                total,
              })}
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={page >= totalPages || auditQuery.isFetching}
              onClick={() => setPage((p) => p + 1)}
            >
              {t('AUDIT.NEXT')}
              <ChevronRight size={14} className={FLIP_IN_RTL} aria-hidden="true" />
            </Button>
          </nav>
        </div>
      }
    >
      {auditQuery.isError ? (
        <PanelError message={railErrorMessage(auditQuery.error, t('ERROR.REQUEST_FAILED'))} />
      ) : auditQuery.isPending ? (
        <p role="status" className="p-6 text-center text-sm text-[var(--text-2)]">
          {t('AUDIT.LOADING')}
        </p>
      ) : entries.length === 0 ? (
        <p role="status" className="p-6 text-center text-sm text-[var(--text-2)]">
          {t('AUDIT.EMPTY')}
        </p>
      ) : (
        <ol className="flex flex-col gap-4" aria-label={t('AUDIT.LIST_LABEL')}>
          {entries.map((entry) => (
            <AuditCard key={entry.entryNumber} entry={entry} />
          ))}
        </ol>
      )}
    </SideSheet>
  );
}

function ChangeLine({ label, before, after }: { label: string; before: string; after: string }) {
  const { t } = useRailTranslation();
  return (
    <div className="flex flex-wrap items-center gap-2 py-1 text-sm">
      <span className="text-[var(--text-primary)]">{label}</span>
      <span className="rounded bg-[var(--accent-red)]/10 px-2 py-0.5 text-xs font-semibold text-[var(--accent-red)]">
        <span className="sr-only">{t('AUDIT.FROM_SR')} </span>
        {before}
      </span>
      <ArrowRight size={14} className={cn('shrink-0 text-[var(--text-muted)]', FLIP_IN_RTL)} aria-hidden="true" />
      <span className="rounded bg-[var(--accent-green)]/10 px-2 py-0.5 text-xs font-semibold text-[var(--accent-green)]">
        <span className="sr-only">{t('AUDIT.TO_SR')} </span>
        {after}
      </span>
    </div>
  );
}

/** What the rail-access reconciler did to the roles: one headline and the counts behind it. */
function ReconciliationLines({ result }: { result: AuditReconciliation }) {
  const { t } = useRailTranslation();
  const disabled = result.phase === 'disable';
  return (
    <div className="py-1 text-sm text-[var(--text-primary)]">
      <p className="font-semibold">{t(disabled ? 'AUDIT.RECONCILE_DISABLE' : 'AUDIT.RECONCILE_RESTORE')}</p>
      <p className="mt-1 text-xs text-[var(--text-2)]">
        {disabled
          ? t('AUDIT.RECONCILE_DISABLE_COUNTS', { revoked: result.revoked, denied: result.denied })
          : t('AUDIT.RECONCILE_RESTORE_COUNTS', {
              restored: result.restored,
              skipped: result.skipped,
              deferred: result.deferred,
            })}
      </p>
    </div>
  );
}

const enabledText = (t: RailT, on: boolean | null) => (on === null ? '—' : t(on ? 'AUDIT.ENABLED' : 'AUDIT.DISABLED'));

function AuditCard({ entry }: { entry: RailAuditEntry }) {
  const { t } = useRailTranslation();
  const { formatInstant } = useSessionDateTime();
  const known = entry.section in SECTION_KEY;
  const tone = SECTION_TONE[entry.section as RailAuditSection] ?? SECTION_TONE['RAIL Update'];
  const sectionText = known ? t(SECTION_KEY[entry.section as RailAuditSection]) : entry.section;
  const fieldChanges = auditFieldChanges(entry);
  const feature = auditFeatureChange(entry);
  const approval = auditApproval(entry);
  const reconciliation = auditReconciliation(entry);

  return (
    <li className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
      <div className="flex items-start justify-between gap-3 border-b border-[var(--border)] bg-[var(--bg-secondary)]/50 px-4 py-3">
        <div className="flex items-center gap-3">
          <span
            className="grid size-7 shrink-0 place-items-center rounded-full bg-[var(--bg-3)] text-xs font-bold text-[var(--text-2)]"
            aria-label={t('AUDIT.ENTRY', { n: entry.entryNumber })}
          >
            {entry.entryNumber}
          </span>
          <div>
            <p className="text-sm font-bold text-[var(--primary-blue)]">
              {reconciliation ? t('AUDIT.RECONCILER_NAME') : entry.userName}
              {entry.userRole && <span className="ms-2 text-[11px] font-normal text-[var(--text-muted)]">{entry.userRole}</span>}
            </p>
            <p className="text-[11px] text-[var(--text-muted)]">{formatInstant(entry.actionDate)}</p>
          </div>
        </div>
        <Badge variant={tone.badge} className="whitespace-nowrap">
          {sectionText}
        </Badge>
      </div>

      <div className="px-4 py-3">
        <p className={cn('mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider', tone.heading)}>
          <span className={cn('h-3.5 w-[3px] rounded', tone.bar)} aria-hidden="true" />
          {sectionText}
        </p>

        {fieldChanges.map((c) => (
          <ChangeLine key={c.field} label={t(FIELD_KEY[c.field])} before={valueText(c.before)} after={valueText(c.after)} />
        ))}

        {feature && (
          <ChangeLine
            label={feature.featureCode}
            before={enabledText(t, feature.before)}
            after={enabledText(t, feature.after)}
          />
        )}

        {reconciliation && <ReconciliationLines result={reconciliation} />}

        {approval && (
          <p className="py-1 text-sm text-[var(--text-primary)]">
            {t('AUDIT.DECISION')}:{' '}
            <span className="font-semibold">
              {DECISION_KEY[approval.decision] ? t(DECISION_KEY[approval.decision]) : approval.decision}
            </span>
            {approval.level !== null && approval.totalLevels !== null && (
              <span className="ms-2 text-xs text-[var(--text-2)]">
                {t('AUDIT.LEVEL_OF', { level: approval.level, total: approval.totalLevels })}
              </span>
            )}
            {/* A level card records the proposed change and the card's own header names the Checker; it has no decision line. */}
            {(approval.checkerId !== null || approval.decidedAt !== null) && (
              <span className="ms-2 text-xs text-[var(--text-2)]">
                {t('AUDIT.CHECKER')}: {approval.checkerId ?? '—'} · {t('AUDIT.DECIDED_AT')}: {formatAuditDateTime(approval.decidedAt)}
              </span>
            )}
          </p>
        )}
      </div>

      <p className="border-t border-[var(--border)] bg-[var(--bg-secondary)]/50 px-4 py-2 text-xs text-[var(--text-2)]">
        {reconciliation ? (
          // The system writes no comment; say so rather than leave the line empty.
          t('AUDIT.RECONCILE_NOTE')
        ) : (
          <>
            <span className="font-semibold text-[var(--text-primary)]">{t('AUDIT.COMMENTS')}</span> {entry.remarks}
          </>
        )}
      </p>
    </li>
  );
}
