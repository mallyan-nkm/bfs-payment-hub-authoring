import { Badge, cn } from '@paymenthub/ui';
import { RAIL_OUTCOME, RAIL_STATUS } from './types';
import type { RailLastAction, RailStatus } from './types';
import { lastActionLabel, statusLabel, useRailTranslation } from './i18n';

/** Modifier on the shared `.status-badge` (sass/_typography.scss). */
const STATUS_MODIFIER: Record<RailStatus, string> = {
  [RAIL_STATUS.Active]: 'success',
  [RAIL_STATUS.Disabled]: 'error',
  [RAIL_STATUS.Pending]: 'warn',
};

export function RailStatusBadge({ status }: { status: RailStatus }) {
  const { t } = useRailTranslation();
  return <span className={cn('status-badge', STATUS_MODIFIER[status])}>{statusLabel(t, status)}</span>;
}

/** The RAIL Code as the grid's monospace identifier badge. */
export function RailCodeBadge({ code }: { code: string }) {
  return <span className="pq-refno-cell font-mono font-bold">{code}</span>;
}

/** Accepted reads green; Pending and Rejected both still need someone's attention, so amber. "—" for none. */
export function RailLastActionBadge({ lastAction }: { lastAction: RailLastAction | null }) {
  const { t } = useRailTranslation();
  const label = lastActionLabel(t, lastAction);
  if (!label) return <span className="text-[var(--text-muted)]">—</span>;
  return (
    <Badge variant={lastAction?.outcome === RAIL_OUTCOME.Applied ? 'green' : 'amber'} className="whitespace-nowrap">
      {label}
    </Badge>
  );
}
