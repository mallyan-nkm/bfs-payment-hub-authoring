import { z } from 'zod';
import { RAIL_STATUS } from './types';

/**
 * The RAIL modify panel's form (React UI guideline §12). Messages are keys in the `RAIL` translation block, so a
 * schema needs no language and a test can assert the rule rather than the copy. The server stays authoritative.
 */
export const VALIDATION = {
  railNameRequired: 'VALIDATION.RAIL_NAME_REQUIRED',
  descriptionRequired: 'VALIDATION.DESCRIPTION_REQUIRED',
  remarksRequired: 'VALIDATION.REMARKS_REQUIRED',
} as const;

const required = (message: string) => z.string().trim().min(1, message);

export const modifyRailSchema = z.object({
  railName: required(VALIDATION.railNameRequired),
  description: required(VALIDATION.descriptionRequired),
  // Pending is shown, never chosen: a rail with a request in flight carries it until the decision.
  status: z.enum([RAIL_STATUS.Active, RAIL_STATUS.Disabled, RAIL_STATUS.Pending]),
  // Feature toggles by featureCode; only those that differ from the detail are sent.
  features: z.record(z.string(), z.boolean()),
  remarks: required(VALIDATION.remarksRequired),
});

export type ModifyRailForm = z.infer<typeof modifyRailSchema>;
