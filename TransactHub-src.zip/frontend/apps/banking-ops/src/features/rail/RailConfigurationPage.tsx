import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, PageBody, PageShell, SmartGrid, usePermissions } from '@paymenthub/ui';
import type { SmartGridQueryChange } from '@paymenthub/ui';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { PERM } from '../../shared/auth/permissionKeys';
import { RailAuditTrailModal } from './RailAuditTrailModal';
import { RailModifySheet } from './RailModifySheet';
import { buildColumns } from './columns';
import type { RailGridView } from './columns';
import { railApi, useRailList } from './api';
import { filtersToParams } from './filters';
import { useRailTranslation } from './i18n';
import type { RailExportFormat, RailListParams, RailRow, RailSortBy } from './types';

const DEFAULT_PAGE_SIZE = 20;

interface GridQuery {
  page: number;
  pageSize: number;
  sortBy: string | null;
  sortDir: 'asc' | 'desc';
  filters: Record<string, string>;
}

const EMPTY_QUERY: GridQuery = { page: 1, pageSize: DEFAULT_PAGE_SIZE, sortBy: null, sortDir: 'asc', filters: {} };

/**
 * RAIL Configuration (Administration → Platform → RAIL): manage payment rails and the features each one
 * enables (RAIL design §7).
 *
 * The grid runs in server mode: column filters, sort and paging all go to `railList`, and export asks the
 * server for the whole filtered set. The View & Modify panel (with its Impact Area) and the Audit Trail mount
 * from the row buttons. Maker-only: the screen has no New, Approve or Reject control.
 */
export function RailConfigurationPage() {
  const navigate = useNavigate();
  const { t } = useRailTranslation();
  const { can } = usePermissions();
  // The export routes need `ops:report:export` on top of the page key (design §8.2).
  const canExport = can(PERM.opsReportExport);

  const [query, setQuery] = useState<GridQuery>(EMPTY_QUERY);
  // The row buttons open the View & Modify panel or the Audit Trail from this.
  const [selected, setSelected] = useState<{ kind: 'modify' | 'audit'; row: RailRow } | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);
  // Stable, so SideSheet's focus/Escape effect doesn't re-run on every page render.
  const closeSheet = useCallback(() => setSelected(null), []);

  const listParams: RailListParams = useMemo(
    () => ({
      ...filtersToParams(query.filters),
      sortBy: (query.sortBy as RailSortBy | null) ?? undefined,
      sortDirection: query.sortBy ? query.sortDir : undefined,
      pageSize: query.pageSize,
      pageNumber: query.page,
    }),
    [query],
  );

  const listQuery = useRailList(listParams);
  const rows = listQuery.data?.items ?? [];
  const totalRecords = listQuery.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalRecords / query.pageSize));

  // A narrower filter can leave the operator past the last page; server mode trusts the caller to clamp.
  useEffect(() => {
    if (query.page > totalPages) setQuery((q) => ({ ...q, page: totalPages }));
  }, [query.page, totalPages]);

  const onViewModify = useCallback((row: RailRow) => setSelected({ kind: 'modify', row }), []);
  const onAuditTrail = useCallback((row: RailRow) => setSelected({ kind: 'audit', row }), []);

  const gridView = useRef<RailGridView>({ rows, page: query.page, pageSize: query.pageSize, onViewModify, onAuditTrail });
  gridView.current.rows = rows;
  gridView.current.page = query.page;
  gridView.current.pageSize = query.pageSize;

  // Built once per language: SmartGrid never re-reads column definitions, and the closures read through the ref.
  const columns = useMemo(() => buildColumns(gridView, t), [t]);

  function handleQueryChange(change: SmartGridQueryChange) {
    setQuery((prev) => ({
      ...prev,
      page: change.page ?? prev.page,
      pageSize: change.pageSize ?? prev.pageSize,
      sortBy: change.sortBy !== undefined ? change.sortBy : prev.sortBy,
      sortDir: change.sortDir ?? prev.sortDir,
      filters: change.filters ?? prev.filters,
    }));
  }

  /** The server renders the whole filtered set, with only the columns the operator has visible. */
  const handleExport = (format: RailExportFormat, visibleColumnKeys: string[]) =>
    railApi.export(
      format,
      listParams,
      visibleColumnKeys.filter((k) => k !== 'slNo'),
    );

  return (
    <PageShell>
      <PageBody>
        <div className="pq-page pr-2">
          {/* Breadcrumb: Payment Hub Operations Console › Administration › RAIL */}
          <nav aria-label={t('PAGE.BREADCRUMB_LABEL')}>
            <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
              <Button type="button" unstyled onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">
                {t('PAGE.BREADCRUMB_ROOT')}
              </Button>
              {' › '}
              <span>{t('PAGE.BREADCRUMB_PARENT')}</span>
              {' › '}
              <span aria-current="page">{t('PAGE.BREADCRUMB')}</span>
            </p>
          </nav>

          <div className="pq-header">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                {t('PAGE.TITLE')}
              </h1>
              <p className="pq-header-subtitle">{t('PAGE.SUBTITLE')}</p>
            </div>
          </div>

          {listQuery.isError ? (
            <div role="alert" className="flex flex-col items-center gap-3 p-10 text-center text-sm text-[var(--text-2)]">
              <p>{t('PAGE.LOAD_FAILED')}</p>
              <Button type="button" variant="outline" size="sm" onClick={() => void listQuery.refetch()}>
                {t('PAGE.RETRY')}
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <SmartGrid<RailRow>
                columns={columns}
                rows={rows}
                getRowId={(r) => r.railCode}
                storageKey="rail-columns-v1"
                loading={listQuery.isFetching}
                emptyTitle={t('PAGE.EMPTY_TITLE')}
                emptyMessage={t('PAGE.EMPTY_MESSAGE')}
                exportFilename="rails"
                onExport={canExport ? handleExport : undefined}
                exportFormats={canExport ? ['csv', 'excel', 'pdf'] : []}
                server={{
                  page: query.page,
                  pageSize: query.pageSize,
                  total: totalRecords,
                  sortBy: query.sortBy,
                  sortDir: query.sortDir,
                  onQueryChange: handleQueryChange,
                }}
              />
            </div>
          )}
        </div>
      </PageBody>

      {selected?.kind === 'modify' && (
        <RailModifySheet
          railCode={selected.row.railCode}
          onClose={closeSheet}
          onCompleted={(message) => {
            setToast({ tone: 'success', message });
            closeSheet();
          }}
        />
      )}

      {selected?.kind === 'audit' && <RailAuditTrailModal row={selected.row} onClose={closeSheet} />}

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}
