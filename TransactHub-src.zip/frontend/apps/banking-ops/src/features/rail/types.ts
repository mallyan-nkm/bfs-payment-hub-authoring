/** RAIL configuration over the Operations API (RAIL design §5, §7) and the IAM impact preview. */

export const RAIL_STATUS = { Active: 'Active', Disabled: 'Disabled', Pending: 'Pending' } as const;
export type RailStatus = (typeof RAIL_STATUS)[keyof typeof RAIL_STATUS];

/** The one non-rail entry: no currency, a read-only status, and PII-only IAM preview (design decision 3). */
export const PLATFORM_RAIL_CODE = 'PLATFORM';

export const RAIL_ACTION = { ModifyRail: 'ModifyRail' } as const;
export type RailAction = (typeof RAIL_ACTION)[keyof typeof RAIL_ACTION];

export const RAIL_OUTCOME = { Pending: 'Pending', Applied: 'Applied', Rejected: 'Rejected' } as const;
export type RailOutcome = (typeof RAIL_OUTCOME)[keyof typeof RAIL_OUTCOME];

/** The Last Action labels the list endpoint's `lastAction` filter accepts (RailLastActions on the server). */
export const RAIL_LAST_ACTION_FILTER = {
  Pending: 'Modify RAIL',
  Accepted: 'Modify RAIL - Accepted',
  Rejected: 'Modify RAIL - Rejected',
} as const;

export interface RailLastAction {
  action: string;
  outcome: string;
}

export type RailSortBy =
  | 'railCode'
  | 'railName'
  | 'description'
  | 'createdAt'
  | 'createdBy'
  | 'status'
  | 'lastModifiedAt'
  | 'lastModifiedBy'
  | 'lastAction';

export interface RailRow {
  sl: number;
  railCode: string;
  railName: string;
  description: string;
  /** Comma-joined; null for PLATFORM. */
  currency: string | null;
  createdAt: string;
  createdBy: string;
  status: RailStatus;
  isPending: boolean;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  lastAction: RailLastAction | null;
}

export interface RailListParams {
  railCode?: string;
  railName?: string;
  description?: string;
  currency?: string;
  createdFrom?: string;
  createdTo?: string;
  createdBy?: string;
  status?: RailStatus[];
  lastModifiedFrom?: string;
  lastModifiedTo?: string;
  lastModifiedBy?: string;
  lastAction?: string[];
  sortBy?: RailSortBy;
  sortDirection?: 'asc' | 'desc';
  /** 5-100, default 20. */
  pageSize: number;
  pageNumber: number;
}

export interface RailListResponse {
  items: RailRow[];
  pageNumber: number;
  pageSize: number;
  totalRecords: number;
}

export type RailExportFormat = 'csv' | 'excel' | 'pdf';

export interface RailFeature {
  featureCode: string;
  featureName: string;
  isEnabled: boolean;
  isLocked: boolean;
  lockOnceEnabled: boolean;
  isCore: boolean;
  baseFeatureTimelineId: number;
  /** Null until the BA supplies the text (OI-1). */
  impactText: string | null;
  coreForRails: string[];
}

export interface RailLatestRequest {
  requestId: number;
  action: string;
  status: string;
  makerName: string | null;
  makerAt: string | null;
  makerRemarks: string | null;
  checkerName: string | null;
  checkerAt: string | null;
  checkerRemarks: string | null;
}

export interface RailDetail {
  railCode: string;
  railName: string;
  description: string;
  status: RailStatus;
  currencies: string[];
  baseTimelineId: number;
  isPending: boolean;
  lastAction: RailLastAction | null;
  features: RailFeature[];
  latestRequest: RailLatestRequest | null;
}

export interface RailWorkflow {
  makerOnlyActions: string[];
  checkerPermission: string | null;
}

export interface SaveRailFeature {
  featureCode: string;
  isEnabled: boolean;
  baseFeatureTimelineId: number;
}

/** `effectiveFrom` is never sent (design). Only changed features are listed. */
export interface SaveRailRequest {
  baseTimelineId: number;
  railName: string;
  description: string;
  status: RailStatus;
  features: SaveRailFeature[];
  lockConfirmed: boolean;
  remarks: string;
  impactSummary?: RailImpactSummary;
}

export interface RailSavedResponse {
  railCode: string;
  requestId: number;
  applied: boolean;
  actionDate: string;
}

export const RAIL_AUDIT_SECTION = {
  RailUpdate: 'RAIL Update',
  FeatureChange: 'Feature Change',
  StatusChange: 'Status Change',
  RailCreated: 'RAIL Created',
  Approval: 'Approval',
} as const;
export type RailAuditSection = (typeof RAIL_AUDIT_SECTION)[keyof typeof RAIL_AUDIT_SECTION];

export interface RailAuditParams {
  section?: RailAuditSection;
  fromDate?: string;
  toDate?: string;
  pageNumber: number;
}

/** The server fixes the page size at 10; `changedFields`, `oldData` and `newData` are raw strings. */
export interface RailAuditEntry {
  entryNumber: number;
  userName: string;
  userRole: string | null;
  section: string;
  remarks: string | null;
  actionDate: string;
  changedFields: string | null;
  oldData: string | null;
  newData: string | null;
}

export interface RailAuditResponse {
  items: RailAuditEntry[];
  pageNumber: number;
  pageSize: number;
  totalRecords: number;
}

/** IAM impact preview, rail mode (`GET /iam/rail-impact`). */
export interface RailImpactBlocker {
  roleName: string;
  requestId: number;
}

export interface RailImpactPreview {
  directRoles: number;
  wildcardRoles: number;
  overlayRoles: number;
  roles: string[];
  users: number;
  restore: number;
  skipped: number;
  blocking: RailImpactBlocker[];
  reconcileInProgress: boolean;
}

/** IAM impact preview, PII mode (PLATFORM level). */
export interface RailPiiImpactPreview {
  fields: { viewKey: string; roles: string[]; users: number }[];
  users: number;
}

/** What the preview is asked about: a bank rail being disabled or re-enabled, or PII on PLATFORM being toggled. */
export const RAIL_IMPACT_CHANGE = { Disable: 'disable', Enable: 'enable' } as const;
export type RailImpactChange = (typeof RAIL_IMPACT_CHANGE)[keyof typeof RAIL_IMPACT_CHANGE];

export const PII_FEATURE_CODE = 'PII';

export type RailImpactParams =
  | { kind: 'rail'; rail: string; change: RailImpactChange }
  | { kind: 'pii'; enable: boolean };

/** The preview(s) the Maker saw, stored with the request for the Checker (design D-4). */
export interface RailImpactSummary {
  status?: RailImpactPreview;
  pii?: RailPiiImpactPreview;
}

/** Rule codes the Operations API returns in `ruleCode` / `errorCode` (design §5, §6). */
export const RAIL_RULE_CODES = {
  BrRail002: 'BR-RAIL-002',
  BrRail004: 'BR-RAIL-004',
  BrRail007: 'BR-RAIL-007',
  BrRail010: 'BR-RAIL-10',
  E2: 'E-2',
  E4: 'E-4',
  E10: 'E-10',
  E13: 'E-13',
  Lock: 'RAIL-LOCK',
  LockConfirm: 'RAIL-LOCK-CONFIRM',
} as const;

export const RAIL_ERROR_CODES = {
  Pending: 'RAIL_PENDING',
  Concurrent: 'RAIL_CONCURRENT',
} as const;

/** ProblemDetails from Operations; a pending 409 adds `requestId`, `action` and `makerBy`. */
export interface RailProblemDetails {
  title?: string;
  status?: number;
  detail?: string;
  errorCode?: string;
  ruleCode?: string;
  traceId?: string;
  errors?: Record<string, string[]>;
  violations?: unknown[];
  requestId?: number;
  action?: string;
  makerBy?: string;
}

/** The IAM impact routes answer `{ error }`, not ProblemDetails. */
export interface RailIamError {
  error: string;
}
