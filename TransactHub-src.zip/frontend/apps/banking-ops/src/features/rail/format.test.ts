import { afterEach, describe, expect, it } from 'vitest';
import { setSessionDateTime } from '@paymenthub/ui';
import { formatAuditDateTime, formatGridDateTime } from './format';

// UTC date-time design §6.7 (T-23): Rail no longer forces UTC; instants are shown in the session zone,
// `dd-MM-yyyy HH:mm:ss`. With no provider mounted the zone is the bank default, Asia/Dubai (UTC+04:00).

afterEach(() => setSessionDateTime(null));

describe('formatAuditDateTime (AC-RAIL-076, now in the session zone)', () => {
  it('shows the session-zone date and 24-hour time', () => {
    expect(formatAuditDateTime('2026-09-28T14:15:00Z')).toBe('28-09-2026 18:15:00');
    expect(formatAuditDateTime('2026-09-28T00:05:00Z')).toBe('28-09-2026 04:05:00');
    expect(formatAuditDateTime('2026-09-28T21:00:00Z')).toBe('29-09-2026 01:00:00');
  });

  it('follows the session zone (L03)', () => {
    setSessionDateTime({ timeZone: 'Asia/Kolkata', locale: 'en', provided: true });
    expect(formatAuditDateTime('2026-09-28T14:15:00Z')).toBe('28-09-2026 19:45:00');
  });

  it('shows "—" for no date or an unreadable one', () => {
    expect(formatAuditDateTime(null)).toBe('—');
    expect(formatAuditDateTime('nope')).toBe('—');
  });
});

describe('formatGridDateTime (AC-RAIL-072: DD-MM-YYYY HH:MM:SS, session zone)', () => {
  it('formats day-first with 24-hour time, whatever the browser zone', () => {
    expect(formatGridDateTime('2026-09-28T14:15:30Z')).toBe('28-09-2026 18:15:30');
    expect(formatGridDateTime('2026-01-05T00:00:00Z')).toBe('05-01-2026 04:00:00');
    expect(formatGridDateTime('2026-12-31T23:59:59Z')).toBe('01-01-2027 03:59:59');
  });

  it('shows "—" for no date or an unreadable one', () => {
    expect(formatGridDateTime(null)).toBe('—');
    expect(formatGridDateTime(undefined)).toBe('—');
    expect(formatGridDateTime('not a date')).toBe('—');
  });
});
