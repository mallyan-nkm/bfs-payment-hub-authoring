import { createPortal } from 'react-dom';
import { useEffect, useRef, useState } from 'react';
import { cn } from '@paymenthub/ui';
import { Ban, FileText, Info, MessageSquare, Play, RefreshCw, TriangleAlert, X } from 'lucide-react';
import { CollapsibleCard, CommentsField, ErrorPanel, Field, FieldGrid } from './panelParts';
import { EM_DASH, PriorityBadge, RailBadge, formatQueueAge, formatTimestamp } from './badges';
import type { TechnicalExceptionRow } from './types';

/**
 * Whether this row can actually be retried — the same gate the backend applies
 * (`TechnicalExceptionQueueService`: category must be in `RetryEnabledCategoryCodes`
 * *and* the exception must still be `OPEN`). `isRetryAllowed` alone is not enough on
 * its own: a category can be retry-enabled while this particular exception has
 * already been retried/resolved and moved out of `OPEN`.
 */
function isRetryable(row: TechnicalExceptionRow): boolean {
  return row.isRetryAllowed && row.itStatusCode === 'OPEN';
}

/**
 * Whether this row can actually be rejected — mirrors `isRetryable`, gated on
 * `isRejectAllowed`/`RejectEnabledCategoryCodes` instead (a narrower set than Retry's:
 * it excludes categories whose activity can never safely terminate on a non-retry
 * decision — see `TechnicalExceptionQueueDefaults.RejectEnabledCategoryCodes`).
 */
function isRejectable(row: TechnicalExceptionRow): boolean {
  return row.isRejectAllowed && row.itStatusCode === 'OPEN';
}

/**
 * Detail panel — FSD §8.1's summary bar plus accordion cards, plus a Retry action.
 *
 * **It fetches nothing.** The list response already carries detail-level rows, so the
 * panel renders from the row in hand. The mock behaves the same way: its
 * `openDetail(id)` reads a local `rows[id]`. A `/detail` endpoint earns its place in
 * Drop 2, where FSD §8.1 requires re-reading live IT and Operations status before an
 * action is submitted (design §4.8, §5).
 *
 * **Actions card, added on top of the original Drop 1 read-only shape**: unlike the
 * business queue's `ActionPicker` radio group of several mutually exclusive choices,
 * Retry and Reject here are two independent actions, each gated on its own
 * eligibility (`isRetryAllowed`/`isRejectAllowed` AND still `OPEN`) and each fired by
 * its own footer button from the same shared comments box — neither
 * `TechnicalExceptionQueueService.RetryAsync` nor `RejectAsync` takes an `action` or
 * `nextAction` (each POST executes immediately, no approval step), so there is nothing
 * to pick between the way the business panel's picker requires. Mark as Closed is
 * still Drop 2 and is not added here.
 *
 * One remaining FSD-driven omission:
 * - **No SLA Status in the summary bar.** FSD v1.1 removed it; the mock still shows it,
 *   and the FSD wins (design §4.11.3).
 */
export function ExceptionDetailSheet({
  row,
  onClose,
  onRetry,
  onReject,
  submitting,
}: {
  row: TechnicalExceptionRow;
  onClose: () => void;
  /** Fires the retry with the operator's comments. Omit to keep the panel read-only. */
  onRetry?: (comments: string) => void;
  /** Fires the reject with the operator's comments. Omit to keep the panel read-only. */
  onReject?: (comments: string) => void;
  submitting?: boolean;
}) {
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const [comments, setComments] = useState('');

  useEffect(() => {
    setComments('');
  }, [row.exceptionKey]);

  const retryable = Boolean(onRetry) && isRetryable(row);
  const rejectable = Boolean(onReject) && isRejectable(row);
  const hasAction = retryable || rejectable;

  // Focus the panel on open and restore it on close, and let Escape dismiss —
  // a slide-in that traps a keyboard user is not usable (guideline §15).
  useEffect(() => {
    const previouslyFocused = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      previouslyFocused?.focus();
    };
  }, [onClose]);

  if (typeof document === 'undefined') return null;

  const details = row.transactionDetails ?? {};
  const hasDetails = Object.keys(details).length > 0;

  return createPortal(
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label="Exception detail"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      {/* Full width on mobile, right-docked from sm: — the Sheet shape the guideline
          names for detail panels. */}
      <div className="flex h-full w-full max-w-lg flex-col overflow-hidden rounded-bl-[40px] rounded-tl-[40px] border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all sm:max-w-xl">
        <header className="flex items-start justify-between gap-3 border-b border-[var(--border)] bg-[var(--bg-secondary)]/50 p-6">
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-xl font-bold text-[var(--text-primary)]">
              {retryable && rejectable
                ? 'Resolve Exception'
                : retryable
                  ? 'Retry Exception'
                  : rejectable
                    ? 'Reject Exception'
                    : 'Exception Detail — View'}
            </h2>
            <p className="mt-1 truncate text-xs text-[var(--text-muted)]">
              {row.transactionSystemId} · {row.itStatusCode === 'OPEN' ? 'Active Exception' : 'Exception'}
            </p>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Close exception detail"
            className="grid size-9 shrink-0 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} aria-hidden="true" />
          </button>
        </header>

        {/* Summary bar — always visible, not collapsible (FSD §8.1). */}
        <div className="flex flex-wrap items-center gap-6 border-b border-[var(--border)] bg-[var(--bg-secondary)] px-6 py-3">
          <SummaryItem label="Rail">
            <RailBadge rail={row.railCode} />
          </SummaryItem>
          <SummaryItem label="Message Type">
            <span className="text-xs font-semibold text-[var(--text-primary)]">{row.messageType || EM_DASH}</span>
          </SummaryItem>
          <SummaryItem label="Priority">
            <PriorityBadge priority={row.priorityCode} />
          </SummaryItem>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex flex-col gap-4">
            {/* Card 1 — Exception Summary. Expanded, per FSD §8.2. */}
            <CollapsibleCard title="Exception Summary" tone="info" icon={<Info size={11} />} defaultOpen>
              <FieldGrid>
                <Field label="Transaction System ID" mono emphasis>
                  {row.transactionSystemId}
                </Field>
                <Field label="Bank Ref No.">{row.bankRefNo || EM_DASH}</Field>
                <Field label="CB Ref No.">{row.cbRefNo || EM_DASH}</Field>
                <Field label="Exception Category">{row.exceptionCategoryName}</Field>
                <Field label="Exception Type">{row.exceptionTypeName}</Field>
                <Field label="Channel">{row.channel || EM_DASH}</Field>
                <Field label="Age">{formatQueueAge(row.queueAgeSeconds)}</Field>
                <Field label="Exception Date & Time">{formatTimestamp(row.occurredAt)}</Field>
                <Field label="Latest IT Status">{row.itStatusCode || EM_DASH}</Field>
                <Field label="Latest Operations Status">{row.operationsStatusCode || EM_DASH}</Field>
              </FieldGrid>
            </CollapsibleCard>

            {/* Card 2 — Exception Details. Expanded, per FSD §8.2. */}
            <CollapsibleCard title="Exception Details" tone="warn" icon={<TriangleAlert size={11} />} defaultOpen>
              <ErrorPanel
                code={row.errorCode}
                narrative={[row.errorDescription, row.errorDetails].filter(Boolean).join(' — ')}
              />
            </CollapsibleCard>

            {/* Card 3 — Transaction / Message Details. Collapsed; content is per-rail. */}
            <CollapsibleCard
              title="Transaction / Message Details"
              note={`${row.railCode} · ${row.messageType || row.exceptionTypeName}`}
              tone="txn"
              icon={<FileText size={11} />}
            >
              {hasDetails ? (
                <>
                  <FieldGrid>
                    {Object.entries(details).map(([label, value]) => (
                      <Field key={label} label={label}>
                        {value}
                      </Field>
                    ))}
                  </FieldGrid>
                  <p className="mt-2.5 text-[10px] italic text-[var(--text-muted)]">
                    Fields shown are dynamic and configurable per rail and message type.
                  </p>
                </>
              ) : (
                /* Honest rather than empty: these fields depend on a producer writing
                   AdditionalData, which does not exist yet (design §7.2). */
                <p className="text-xs text-[var(--text-2)]">
                  No transaction or message details were recorded against this exception.
                </p>
              )}
            </CollapsibleCard>

            {/* Card 4 — Comments. Read-only, and a single value rather than separate IT
                and Operations comments: attributing a comment to a team needs the
                ActorRole column that Drop 1 does not have (design §4.8, D-3). */}
            <CollapsibleCard title="Comments" tone="act" icon={<MessageSquare size={11} />} defaultOpen>
              {row.latestComment ? (
                <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-secondary)]/50 p-3">
                  <p className="whitespace-pre-wrap break-words text-sm text-[var(--text-primary)]">
                    {row.latestComment}
                  </p>
                  {row.latestCommentBy && (
                    <p className="mt-1.5 text-[10px] text-[var(--text-muted)]">— {row.latestCommentBy}</p>
                  )}
                </div>
              ) : (
                <p className="text-xs text-[var(--text-2)]">No comments recorded.</p>
              )}
            </CollapsibleCard>

            {/* Card 5 — Actions. Only when the caller wired onRetry/onReject and this row
                qualifies for at least one of them (isRetryAllowed/isRejectAllowed AND still
                OPEN) — Mark as Closed is still Drop 2, so a non-actionable row stays
                read-only exactly as before. Both actions execute immediately from the same
                comments, via their own footer button — there is nothing to pick between. */}
            {hasAction && (
              <CollapsibleCard title="Actions" note="No approval step" tone="act" icon={<Play size={11} />} defaultOpen>
                <div className="flex flex-wrap items-center gap-2">
                  {retryable && (
                    <span className="flex items-center gap-1.5 rounded-full border border-[var(--primary-blue)] bg-[var(--primary-blue)]/10 px-4 py-1.5 text-xs font-semibold text-[var(--primary-blue)]">
                      <RefreshCw size={12} aria-hidden="true" />
                      Retry
                    </span>
                  )}
                  {rejectable && (
                    <span className="flex items-center gap-1.5 rounded-full border border-[var(--accent-red)] bg-[var(--accent-red)]/10 px-4 py-1.5 text-xs font-semibold text-[var(--accent-red)]">
                      <Ban size={12} aria-hidden="true" />
                      Reject
                    </span>
                  )}
                </div>
                <p className="mt-2 text-[10px] italic text-[var(--text-muted)]">
                  Technical exceptions execute immediately — there is no approval step.
                </p>
                <div className="mt-2.5">
                  <CommentsField value={comments} onChange={setComments} placeholder="Add comments or remarks (required)…" />
                </div>
              </CollapsibleCard>
            )}
          </div>
        </div>

        {/* Footer — CLOSE always; RETRY/REJECT added independently when the row qualifies
            for each and the caller wired the matching handler. MARK AS CLOSED is still
            Drop 2. Both share the same comments box above; there is no action picker. */}
        <footer className="flex items-center gap-3 border-t border-[var(--border)] bg-[var(--bg-card)] p-6">
          {retryable && (
            <button
              type="button"
              onClick={() => onRetry?.(comments.trim())}
              disabled={submitting || !comments.trim()}
              title={!comments.trim() ? 'Comments are required before retrying' : undefined}
              className="btn-primary large-btn !w-full flex-1 justify-center !py-2.5 text-sm disabled:cursor-not-allowed disabled:opacity-50"
            >
              {submitting ? 'Retrying…' : 'Retry'}
            </button>
          )}
          {rejectable && (
            <button
              type="button"
              onClick={() => onReject?.(comments.trim())}
              disabled={submitting || !comments.trim()}
              title={!comments.trim() ? 'Comments are required before rejecting' : undefined}
              className={cn(
                'btn-secondary large-btn !w-40 justify-center !py-2.5 text-sm',
                '',
              )}
            >
              {submitting ? 'Rejecting…' : 'Reject'}
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            disabled={submitting}
            className="btn-secondary large-btn !w-full flex-1 justify-center !py-2.5 text-sm"
          >
            Close
          </button>
        </footer>
      </div>
    </div>,
    document.body,
  );
}

function SummaryItem({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <div className="input-label mb-1 block">{label}</div>
      {children}
    </div>
  );
}
