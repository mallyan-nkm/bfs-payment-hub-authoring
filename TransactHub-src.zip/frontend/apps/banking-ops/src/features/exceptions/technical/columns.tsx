import type { RefObject } from 'react';
import type { SmartGridColumn } from '@paymenthub/ui';
import {
  ItStatusBadge,
  OperationsStatusBadge,
  OrDash,
  PriorityBadge,
  RailBadge,
  RetryCountChip,
  SeverityBadge,
  SlaChip,
  formatQueueAge,
  formatTimestamp,
} from './badges';
import type { TechnicalExceptionRow } from './types';

/**
 * The 21 grid columns of FSD §6.1, in FSD order.
 *
 * Every column is present even where no producer writes its value yet — a blank cell
 * is honest, and it means the column-visibility menu, the export column set and the
 * operator's saved layout are complete from day one. When the producer lands, values
 * appear with no UI change (design §3.2).
 *
 * `filterKey` is set only where the backend can honour the filter. Key Word,
 * Transaction Date & Time and Message Type come from AdditionalData, which is not a
 * SQL predicate in Drop 1, so they are not filterable — a filter over an always-blank
 * column would only mislead (design §4.6.1, §5.1.1).
 */

const RAIL_FILTER_OPTIONS = ['WPS', 'IPI', 'UAEFTS', 'FTS', 'IPP', 'SWIFT'];
const SEVERITY_FILTER_OPTIONS = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
const IT_STATUS_FILTER_OPTIONS = [
  { value: 'OPEN', label: 'Open' },
  { value: 'CLOSED', label: 'Closed' },
];
const SLA_FILTER_OPTIONS = [
  { value: 'WITHIN', label: 'Within SLA' },
  { value: 'APPROACHING', label: 'Approaching' },
  { value: 'BREACHED', label: 'Breached' },
];

/**
 * What the `slNo` counter needs, behind a ref rather than passed by value.
 *
 * SmartGrid copies the column definitions into component state **once**, in a lazy
 * `useState` initialiser, and never re-syncs them when the prop changes
 * (`SmartGrid.tsx`). So the `render` closures the grid actually calls are the ones built
 * on the first render — when the list query is still in flight and `rows` is `[]`. Read
 * by value, `rows.indexOf(row)` was therefore always `-1` against that empty snapshot,
 * and `-1 + 1` printed `0` on every line.
 *
 * A ref survives that: the closure captures the ref object, and its `.current` is
 * repointed at the live page on every render, so the counter reads today's rows and
 * today's page even though the closure itself is stale.
 */
export interface SlNoView {
  page: number;
  pageSize: number;
  rows: TechnicalExceptionRow[];
}

export interface ColumnContext {
  /** Serial numbers are per-tab and per-page — see the `slNo` column. */
  slNoView: RefObject<SlNoView>;
  categoryOptions: { value: string; label: string }[];
  onViewDetails: (row: TechnicalExceptionRow) => void;
  onViewAuditTrail: (row: TechnicalExceptionRow) => void;
}

export function buildColumns(ctx: ColumnContext): SmartGridColumn<TechnicalExceptionRow>[] {
  return [
    {
      key: 'slNo',
      label: 'Sl. No.',
      // Recomputed from the row's position in the current page, so switching tabs or
      // paging restarts the sequence at 1 with no gaps (BR-ITEQ-006). Not sortable and
      // not filterable — it is a view-local counter, not data.
      locked: true,
      numeric: true,
      align: 'right',
      render: (r) => {
        const { page, pageSize, rows } = ctx.slNoView.current;
        const index = rows.indexOf(r);
        // A dash rather than a number when the row is not in the current page: the
        // counter has no meaning then, and printing one anyway is how this column came
        // to show 0 on every line instead of looking broken.
        return index < 0 ? '—' : (page - 1) * pageSize + index + 1;
      },
    },
    {
      key: 'transactionSystemId',
      label: 'Transaction System ID',
      filterKey: 'search',
      sortKey: 'transactionSystemId',
      getValue: (r) => r.transactionSystemId,
      render: (r) => (
        <span className="pq-refno-cell">{r.transactionSystemId}</span>
      ),
    },
    {
      key: 'bankRefNo',
      label: 'Bank Ref No.',
      getValue: (r) => r.bankRefNo ?? '',
      render: (r) => <OrDash value={r.bankRefNo} />,
    },
    {
      key: 'cbRefNo',
      label: 'CB Ref No.',
      getValue: (r) => r.cbRefNo ?? '',
      render: (r) => <OrDash value={r.cbRefNo} />,
    },
    {
      key: 'keyWord',
      label: 'Key Word',
      // Not filterable: sourced from AdditionalData, which has no producer yet.
      getValue: (r) => r.keyWord ?? '',
      render: (r) => (
        <span className="font-mono text-xs">
          <OrDash value={r.keyWord} />
        </span>
      ),
    },
    {
      key: 'rail',
      label: 'Rail',
      filterKey: 'rail',
      filterType: 'select',
      filterOptions: RAIL_FILTER_OPTIONS,
      sortKey: 'rail',
      getValue: (r) => r.railCode,
      render: (r) => <RailBadge rail={r.railCode} />,
    },
    {
      key: 'transactionAt',
      label: 'Transaction Date & Time',
      // Not filterable — same AdditionalData reason as Key Word.
      getValue: (r) => formatTimestamp(r.transactionAt),
      render: (r) => <OrDash value={formatTimestamp(r.transactionAt)} />,
    },
    {
      key: 'occurredAt',
      label: 'Exception Date & Time',
      filterKey: 'occurred',
      filterType: 'dateRange',
      sortKey: 'occurredAt',
      getValue: (r) => formatTimestamp(r.occurredAt),
      render: (r) => formatTimestamp(r.occurredAt),
    },
    {
      key: 'exceptionCategory',
      label: 'Exception Category',
      filterKey: 'category',
      filterType: 'select',
      filterOptions: ctx.categoryOptions,
      sortKey: 'exceptionCategory',
      getValue: (r) => r.exceptionCategoryName,
      render: (r) => (
        <span className="rounded-full bg-[var(--accent-amber)]/15 px-2 py-0.5 text-xs font-medium text-[var(--accent-amber)]">
          {r.exceptionCategoryName}
        </span>
      ),
    },
    {
      key: 'errorCode',
      label: 'Error Code',
      filterKey: 'errorCode',
      getValue: (r) => r.errorCode ?? '',
      render: (r) => (
        <span className="font-mono text-xs">
          <OrDash value={r.errorCode} />
        </span>
      ),
    },
    {
      key: 'errorDescription',
      label: 'Error Description',
      filterKey: 'errorDescription',
      getValue: (r) => r.errorDescription ?? '',
      // Truncated here, full text in the detail panel (FSD §6.1 col 12). The title
      // attribute gives the whole string on hover without widening the column.
      render: (r) => (
        <span className="block max-w-[22rem] truncate" title={r.errorDescription ?? undefined}>
          <OrDash value={r.errorDescription} />
        </span>
      ),
    },
    {
      key: 'messageType',
      label: 'Message Type',
      // Not filterable — AdditionalData.
      getValue: (r) => r.messageType ?? '',
      render: (r) => <OrDash value={r.messageType} />,
    },
    {
      key: 'severity',
      label: 'Severity',
      filterKey: 'severity',
      filterType: 'select',
      filterOptions: SEVERITY_FILTER_OPTIONS,
      sortKey: 'severity',
      getValue: (r) => r.severityCode,
      render: (r) => <SeverityBadge severity={r.severityCode} />,
    },
    {
      key: 'priority',
      label: 'Priority',
      getValue: (r) => r.priorityCode ?? '',
      render: (r) => <PriorityBadge priority={r.priorityCode} />,
    },
    {
      key: 'itStatus',
      label: 'IT Status',
      filterKey: 'itStatus',
      filterType: 'multiSelect',
      filterOptions: IT_STATUS_FILTER_OPTIONS,
      sortKey: 'itStatus',
      getValue: (r) => r.itStatusCode ?? '',
      render: (r) => <ItStatusBadge status={r.itStatusCode} />,
    },
    {
      key: 'operationsStatus',
      label: 'Operations Status',
      // Not filterable server-side: the backend translates only the IT status filter
      // to the underlying StatusCode set. Sortable locally within the page.
      localSortKey: 'operationsStatusCode',
      getValue: (r) => r.operationsStatusCode ?? '',
      render: (r) => <OperationsStatusBadge status={r.operationsStatusCode} />,
    },
    {
      key: 'queueAge',
      label: 'Queue Age',
      // Sorts on OccurredAt with the direction inverted — an older exception has a
      // larger age (design §4.7.1). SmartGrid sends `queueAge`; api.ts maps it.
      sortKey: 'queueAge',
      getValue: (r) => formatQueueAge(r.queueAgeSeconds),
      render: (r) => formatQueueAge(r.queueAgeSeconds),
    },
    {
      key: 'sla',
      label: 'SLA',
      filterKey: 'sla',
      filterType: 'select',
      filterOptions: SLA_FILTER_OPTIONS,
      getValue: (r) => r.slaState ?? '',
      render: (r) => <SlaChip state={r.slaState} />,
    },
    {
      key: 'retryCount',
      label: 'Retry Count',
      filterKey: 'retryCount',
      filterType: 'number',
      sortKey: 'retryCount',
      numeric: true,
      align: 'right',
      getValue: (r) => String(r.retryCount),
      render: (r) => <RetryCountChip count={r.retryCount} />,
    },
    {
      key: 'actions',
      label: 'Action',
      locked: true,
      // Drop 1 is read-only, so the row offers View Details and Audit Trail. Resolve
      // and View & Close arrive in Drop 2 with the endpoints that submit them — a
      // disabled button promising an action we cannot perform would be worse.
      render: (r) => (
        <div className="pq-row-actions">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              ctx.onViewDetails(r);
            }}
            className="btn-secondary pq-view-action-btn"
            aria-label={`View details for ${r.transactionSystemId}`}
          >
            View Details
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              ctx.onViewAuditTrail(r);
            }}
            className="btn-tertiary pq-view-action-btn"
            aria-label={`View audit trail for ${r.transactionSystemId}`}
          >
            Audit Trail
          </button>
        </div>
      ),
    },
  ];
}

/**
 * Columns visible by default on a narrow viewport. A 21-column grid cannot fit a
 * phone, and the operator's saved layout always wins once they set one — this is
 * only the first-load default (design §4.13).
 */
export const NARROW_DEFAULT_COLUMNS = [
  'slNo',
  'transactionSystemId',
  'rail',
  'occurredAt',
  'exceptionCategory',
  'itStatus',
  'actions',
];
