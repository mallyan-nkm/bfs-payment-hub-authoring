import { bankingApi } from '../../../shared/api/bankingApi';
import { toUtcRangeParams } from '@paymenthub/ui';
import type {
  ExceptionCategoryOption,
  TechnicalExceptionAuditRow,
  TechnicalExceptionListResponse,
  TechnicalExceptionRejectResult,
  TechnicalExceptionRetryResult,
  TechnicalExceptionTab,
  TechnicalExceptionTabCounts,
} from './types';

/**
 * Technical Exception Queue data access — GET /api/ops/technical-exceptions. Read-only.
 * Tenant is resolved server-side from the JWT claim, never sent by the client. PII is
 * always masked server-side; there is no client-side mask/unmask.
 */

const BASE = '/ops/technical-exceptions';

export interface TechnicalExceptionListParams {
  tab: TechnicalExceptionTab;
  page: number;
  pageSize: number;
  /** Full-text search — the backend ORs it across transaction id, key, error code, error text and CB ref. */
  search?: string;
  /** Single rail code; the backend's filter takes one value, not an array. */
  rail?: string;
  /** Exact category code from `categories()` — there is no free-text category filter. */
  exceptionCategoryCode?: string;
  severity?: string;
  /** IT Status values; the backend translates these to the underlying StatusCode set. */
  itStatusCodes?: string[];
  slaState?: string;
  occurredFrom?: string;
  occurredTo?: string;
  /** Backend filters `RetryCount >= minRetryCount` — a lower bound, not an exact match. */
  minRetryCount?: number;
  /** One of the grid's sortable columns — see SORT_COLUMN_MAP. */
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
}

/** Grid sort key → the backend's AllowedSortColumns. Unlisted keys are not sortable server-side. */
const SORT_COLUMN_MAP: Record<string, string> = {
  transactionSystemId: 'ExceptionKey',
  rail: 'RailCode',
  occurredAt: 'OccurredAt',
  queueAge: 'QueueAge',
  severity: 'SeverityCode',
  itStatus: 'StatusCode',
  exceptionCategory: 'ExceptionCategoryCode',
  retryCount: 'RetryCount',
};

export type ExportFormat = 'csv' | 'excel' | 'pdf';

function toQuery(p: TechnicalExceptionListParams): Record<string, unknown> {
  // The grid's days are session-zone days; the server filters OccurredAt as UTC [from, to) (UTC date-time T-22).
  const occurred = toUtcRangeParams(p.occurredFrom, p.occurredTo);
  return {
    tab: p.tab,
    pageNumber: p.page,
    pageSize: p.pageSize,
    searchQuery: p.search || undefined,
    railCode: p.rail || undefined,
    exceptionCategoryCode: p.exceptionCategoryCode || undefined,
    severityCode: p.severity || undefined,
    itStatusCodes: p.itStatusCodes?.length ? p.itStatusCodes : undefined,
    slaState: p.slaState || undefined,
    occurredFrom: occurred.from,
    occurredTo: occurred.to,
    minRetryCount: p.minRetryCount,
    sortColumn: p.sortBy ? SORT_COLUMN_MAP[p.sortBy] : undefined,
    // Direction only travels with a column — alone it would override the OccurredAt DESC default.
    sortDescending: p.sortBy && p.sortDir ? p.sortDir === 'desc' : undefined,
  };
}

export const technicalExceptionsApi = {
  list: async (params: TechnicalExceptionListParams): Promise<TechnicalExceptionListResponse> => {
    const res = await bankingApi.get<TechnicalExceptionListResponse>(BASE, { params: toQuery(params) });
    return res.data;
  },

  /** Badge counts for all three tabs in one call — FSD §5 wants them as at page load. */
  tabCounts: async (): Promise<TechnicalExceptionTabCounts> => {
    const res = await bankingApi.get<TechnicalExceptionTabCounts>(`${BASE}/tab-counts`);
    return res.data;
  },

  /** Master data for the category filter — technical classifications only. */
  categories: async (): Promise<ExceptionCategoryOption[]> => {
    const res = await bankingApi.get<ExceptionCategoryOption[]>(`${BASE}/categories`);
    return res.data;
  },

  /** Every version of one exception, oldest first — the Audit Trail modal's source. */
  auditTrail: async (transactionSystemId: string): Promise<TechnicalExceptionAuditRow[]> => {
    const res = await bankingApi.get<TechnicalExceptionAuditRow[]>(
      `${BASE}/${encodeURIComponent(transactionSystemId)}/audit-trail`,
    );
    return res.data;
  },

  /**
   * POST /api/ops/technical-exceptions/retry — one of the two resolution actions Technical
   * Exceptions support (TechnicalExceptionQueueService rejects anything else with
   * ArgumentException for a category not in RetryEnabledCategoryCodes). Unlike the
   * business queue's resolve, there is no `action` choice and no approval step: the
   * backend executes immediately, gated only on `row.isRetryAllowed`.
   */
  retry: async (transactionSystemIds: string[], comments: string): Promise<TechnicalExceptionRetryResult> => {
    const res = await bankingApi.post<TechnicalExceptionRetryResult>(`${BASE}/retry`, {
      transactionSystemIds,
      comments,
    });
    return res.data;
  },

  /**
   * POST /api/ops/technical-exceptions/reject — the other resolution action, gated on
   * `row.isRejectAllowed` (TechnicalExceptionQueueService.RejectEnabledCategoryCodes).
   * Same shape as retry: no `action` choice, no approval step, executes immediately.
   */
  reject: async (transactionSystemIds: string[], comments: string): Promise<TechnicalExceptionRejectResult> => {
    const res = await bankingApi.post<TechnicalExceptionRejectResult>(`${BASE}/reject`, {
      transactionSystemIds,
      comments,
    });
    return res.data;
  },

  /**
   * Server-rendered export of the whole filtered set. `visibleColumns` carries the
   * operator's current column keys in display order, so the file matches the screen.
   * The response also carries `X-Export-Truncated` when a row cap was hit; the caller
   * reads it off the headers to warn rather than hand over a silently partial file.
   */
  export: async (
    format: ExportFormat,
    params: TechnicalExceptionListParams,
    visibleColumns: string[],
  ): Promise<{ blob: Blob; truncated: boolean }> => {
    const res = await bankingApi.get<Blob>(`${BASE}/export/${format}`, {
      params: { ...toQuery(params), columns: visibleColumns.join(',') },
      responseType: 'blob',
    });

    return {
      blob: res.data,
      truncated: String(res.headers['x-export-truncated'] ?? '').toLowerCase() === 'true',
    };
  },
};
