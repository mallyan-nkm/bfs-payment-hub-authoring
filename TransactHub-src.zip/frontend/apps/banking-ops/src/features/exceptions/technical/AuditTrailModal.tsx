import { createPortal } from 'react-dom';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { LoadingSpinner, cn, sanitizeCsvCell } from '@paymenthub/ui';
import { ChevronDown, Download, X } from 'lucide-react';
import { technicalExceptionsApi } from './api';
import { formatTimestamp } from './badges';

/**
 * Audit Trail — the end-to-end lifecycle of one exception.
 *
 * BR-ITEQ-008 fixes the structure: a summary bar plus a seven-column table
 * (Activity, Action By, Actioned Date & Time, Channel, Status, Remarks, More Details),
 * identical across every exception queue screen.
 *
 * BR-ITEQ-007 is satisfied structurally rather than by convention — one row per
 * `platform.PaymentException` version, and versions are immutable, so retries can
 * never be collapsed or grouped.
 *
 * Copied from `../business/AuditTrailModal.tsx` rather than shared with it: moving that
 * file would edit a live screen's imports for no user-visible gain (design §4.18,
 * D-13). Consolidation is a Drop 2 item, once this one grows the REQ/RES payload rows
 * the business queue does not have.
 */

const HEADERS = [
  'Activity',
  'Action By',
  'Actioned Date & Time',
  'Channel',
  'Status',
  'Remarks',
  'More Details',
] as const;

const TH = 'px-3 py-2 text-left text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]';
const TD = 'px-3 py-2 align-top text-xs text-[var(--text-primary)]';

/** Humanises an event type the map below does not special-case: SOME_EVENT → Some Event. */
function humanize(code: string): string {
  return code
    .toLowerCase()
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

/**
 * Activity labels for the event vocabulary `CK_PaymentException_EventType` actually
 * permits — read from the database, not assumed. Anything outside this map falls
 * through to `humanize()`, so an unmapped value still reads sensibly.
 */
const EVENT_LABEL: Record<string, string> = {
  EXCEPTION_CREATED: 'Exception Raised',
  STATUS_CHANGED: 'Status Changed',
  ASSIGNED: 'Assigned',
  ESCALATED: 'Escalated',
  MANUAL_ACTION: 'Manual Action',
  RETRY_INITIATED: 'Retry Initiated',
  RETRY_SUCCEEDED: 'Retry Succeeded',
  RETRY_FAILED: 'Retry Failed',
  RESOLVED: 'Resolved',
  CLOSED: 'Closed',
  REOPENED: 'Reopened',
};

/** The six values `CK_PaymentException_StatusCode` permits. */
const STATUS_TONE: Record<string, string> = {
  OPEN: 'bg-[var(--accent-blue)]/15 text-[var(--accent-blue)]',
  IN_PROGRESS: 'bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]',
  RETRYING: 'bg-[var(--accent-blue)]/15 text-[var(--accent-blue)]',
  RESOLVED: 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]',
  CLOSED: 'bg-[var(--bg-3)] text-[var(--text-2)]',
  IGNORED: 'bg-[var(--bg-3)] text-[var(--text-muted)]',
};

/** Renders ActorRole-ish values as words. `ChangeSource` is a system name, not a UI label. */
const CHANNEL_LABEL: Record<string, string> = {
  OPS_API: 'Operations Console',
  AUTO_CLOSURE: 'System',
  WORKFLOW: 'Workflow',
  INTEGRATION: 'Integration',
};

export function AuditTrailModal({
  transactionSystemId,
  onClose,
}: {
  transactionSystemId: string;
  onClose: () => void;
}) {
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  useEffect(() => {
    const previouslyFocused = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      previouslyFocused?.focus();
    };
  }, [onClose]);

  const trailQuery = useQuery({
    queryKey: ['technical-exceptions', 'audit-trail', transactionSystemId],
    queryFn: () => technicalExceptionsApi.auditTrail(transactionSystemId),
  });

  const rows = trailQuery.data ?? [];
  const latest = rows.length > 0 ? rows[rows.length - 1] : undefined;

  const csv = useMemo(() => {
    const esc = (v: string) => `"${sanitizeCsvCell(v).replace(/"/g, '""')}"`;
    const header = HEADERS.slice(0, 6).map(esc).join(',');
    const lines = rows.map((r) =>
      [
        EVENT_LABEL[r.eventType?.toUpperCase()] ?? humanize(r.eventType ?? 'Event'),
        r.actionBy ?? 'System',
        formatTimestamp(r.occurredAt),
        CHANNEL_LABEL[r.channel?.toUpperCase() ?? ''] ?? r.channel ?? '',
        r.statusCode,
        r.remarks ?? r.errorDescription ?? '',
      ]
        .map((v) => esc(String(v)))
        .join(','),
    );
    return [header, ...lines].join('\n');
  }, [rows]);

  function downloadCsv() {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    try {
      const link = document.createElement('a');
      link.href = url;
      link.download = `audit-trail-${transactionSystemId}.csv`;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      link.remove();
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  function toggleRow(version: number) {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(version)) next.delete(version);
      else next.add(version);
      return next;
    });
  }

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[10003] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label="Audit trail"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="flex h-full w-full max-w-4xl flex-col overflow-hidden rounded-bl-[40px] rounded-tl-[40px] border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all">
        <header className="flex items-start justify-between gap-3 border-b border-[var(--border)] bg-[var(--bg-secondary)]/50 p-6">
          <div className="min-w-0 flex-1">
            <h2 className="text-xl font-bold text-[var(--text-primary)]">Audit Trail</h2>
            <p className="mt-1 truncate text-xs text-[var(--text-muted)]">{transactionSystemId}</p>
          </div>
          <button
            type="button"
            onClick={downloadCsv}
            disabled={rows.length === 0}
            className="btn-tertiary h-38px shrink-0 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Download size={13} aria-hidden="true" />
            Download CSV
          </button>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Close audit trail"
            className="grid size-9 shrink-0 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} aria-hidden="true" />
          </button>
        </header>

        {/* Summary bar — BR-ITEQ-008. */}
        {latest && (
          <div className="flex flex-wrap items-center gap-6 border-b border-[var(--border)] bg-[var(--bg-secondary)] px-6 py-3">
            <SummaryItem label="Reference" value={latest.exceptionKey} mono />
            <SummaryItem label="Transaction Type" value={`${latest.railCode} — ${latest.exceptionCategoryName}`} />
            <SummaryItem label="Exception Type" value={latest.exceptionTypeName} />
            <SummaryItem label="Status" value={latest.statusCode} />
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-6">
          {trailQuery.isLoading ? (
            <div className="p-10">
              <LoadingSpinner />
            </div>
          ) : trailQuery.isError ? (
            <p className="p-6 text-sm text-[var(--accent-red)]">
              Could not load the audit trail. It may belong to another tenant, or the request failed — retry, and
              check the identifier if it persists.
            </p>
          ) : rows.length === 0 ? (
            <p className="p-6 text-sm text-[var(--text-2)]">No audit trail recorded for this exception.</p>
          ) : (
            /* Seven columns is wide — it scrolls inside this container, never the page. */
            <div className="overflow-x-auto rounded-lg border border-[var(--border)]">
              <table className="w-full min-w-[52rem] border-collapse">
                <thead className="sticky top-0 bg-[var(--bg-2)]">
                  <tr>
                    {HEADERS.map((h, i) => (
                      <th key={h} className={cn(TH, i === HEADERS.length - 1 && 'text-center')}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const isOpen = expanded.has(r.version);
                    return (
                      <>
                        <tr key={r.version} className="border-t border-[var(--border-light)]">
                          <td className={cn(TD, 'font-semibold')}>
                            {EVENT_LABEL[r.eventType?.toUpperCase()] ?? humanize(r.eventType ?? 'Event')}
                          </td>
                          <td className={TD}>{r.actionBy ?? 'System'}</td>
                          <td className={cn(TD, 'whitespace-nowrap')}>{formatTimestamp(r.occurredAt)}</td>
                          <td className={TD}>
                            {CHANNEL_LABEL[r.channel?.toUpperCase() ?? ''] ?? r.channel ?? '—'}
                          </td>
                          <td className={TD}>
                            <span
                              className={cn(
                                'rounded px-1.5 py-0.5 text-[10px] font-bold',
                                STATUS_TONE[r.statusCode?.toUpperCase()] ?? 'bg-[var(--bg-3)] text-[var(--text-2)]',
                              )}
                            >
                              {r.statusCode}
                            </span>
                          </td>
                          <td className={cn(TD, 'max-w-[20rem]')}>{r.remarks ?? r.errorDescription ?? '—'}</td>
                          <td className={cn(TD, 'text-center')}>
                            <button
                              type="button"
                              onClick={() => toggleRow(r.version)}
                              aria-expanded={isOpen}
                              className="btn-tertiary pq-view-action-btn"
                            >
                              More Details
                              <ChevronDown
                                size={10}
                                className={cn('transition-transform', !isOpen && '-rotate-90')}
                                aria-hidden="true"
                              />
                            </button>
                          </td>
                        </tr>
                        {isOpen && (
                          <tr key={`${r.version}-detail`} className="bg-[var(--bg-2)]">
                            <td colSpan={HEADERS.length} className="px-3 py-2.5">
                              <dl className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                                <Detail label="Version" value={String(r.version)} />
                                <Detail label="Event Type" value={r.eventType} />
                                <Detail label="Previous Status" value={r.previousStatusCode ?? '—'} />
                                <Detail label="Retry Count" value={String(r.retryCount)} />
                                <Detail label="Error Code" value={r.errorCode ?? '—'} />
                                <Detail label="Resolution Code" value={r.resolutionCode ?? '—'} />
                              </dl>
                            </td>
                          </tr>
                        )}
                      </>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <footer className="flex justify-end border-t border-[var(--border)] bg-[var(--bg-card)] p-6">
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary large-btn !w-40 justify-center !py-2.5 text-sm"
          >
            Close
          </button>
        </footer>
      </div>
    </div>,
    document.body,
  );
}

function SummaryItem({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="min-w-0">
      <div className="mb-0.5 text-[9px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{label}</div>
      <div className={cn('truncate text-xs font-semibold text-[var(--text-primary)]', mono && 'font-mono')}>
        {value}
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-[9px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{label}</dt>
      <dd className="truncate font-mono text-[11px] text-[var(--text-primary)]">{value}</dd>
    </div>
  );
}
