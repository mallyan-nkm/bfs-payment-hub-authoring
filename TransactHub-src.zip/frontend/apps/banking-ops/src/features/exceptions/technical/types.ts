// ─── Technical Exception Queue ────────────────────────────────────────────────
// Domain model for the Technical Exception Queue (route /technical-exceptions).
// A technical exception is a payment that stalled on an *infrastructure* step — a
// core-banking timeout, a channel notification that never landed, a file that
// could not be read — and needs IT diagnosis before the payment can move on.
//
// Drop 1 is read-only: the operator can look, filter, export and follow the audit
// trail. Retry and Mark as Closed arrive in Drop 2, so nothing here models an
// action or a submission.
//
// Shapes mirror what GET /api/ops/technical-exceptions actually returns
// (TechnicalExceptionQueueEndpoints.cs). Fields the FSD names but no producer
// writes yet — key word, transaction timestamp, message type — are modelled as
// optional and render blank, never as invented values.

/** The three tabs, matching the backend's `tab` parameter. */
export type TechnicalExceptionTab = 'action-pending' | 'active-exceptions' | 'all';

/** Rail code as stored on platform.PaymentException.RailCode — not a closed set. */
export type ExceptionRail = string;

/**
 * A closed set, and safe to treat as one: `CK_PaymentException_SeverityCode` on
 * platform.PaymentException admits only these four values, and the API passes the column
 * through unchanged. Contrast `ExceptionRail` above, which genuinely is open-ended.
 *
 * Rendering still normalises rather than trusting this — `SeverityBadge` upper-cases and
 * falls back to the raw value for anything unrecognised — because a type is erased at
 * runtime and cannot police a response.
 */
export type ExceptionSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

/**
 * IT-side status, derived server-side from StatusCode plus the classification's
 * technical flag. `null` means this is not a technical exception — the em dash
 * FSD §6.2 specifies.
 */
export type ItStatus = 'OPEN' | 'CLOSED';

/**
 * Business-side status, derived the same way from the business flag. `Rejected by
 * Approver` is absent because no backend state distinguishes a rejection from an
 * open record until the status pair is persisted in Drop 2.
 */
export type OperationsStatus = 'OPEN' | 'PENDING_APPROVAL' | 'RESOLVED';

/** SLA banding — Queue Age measured against the category's threshold. */
export type SlaState = 'WITHIN' | 'APPROACHING' | 'BREACHED';

/** One grid row. Field names match the API response exactly. */
export interface TechnicalExceptionRow {
  /** Stable logical id across versions — used as the grid row key. */
  exceptionKey: string;
  exceptionVersion: number;
  /** Identifier used to address this exception on the audit-trail endpoint. */
  transactionSystemId: string;
  bankRefNo?: string | null;
  cbRefNo?: string | null;
  /** Bank-configured identifier per rail. Masked server-side; blank until a producer writes it. */
  keyWord?: string | null;
  railCode: ExceptionRail;
  /** Original transaction timestamp. Blank until a producer writes it. */
  transactionAt?: string | null;
  /** When the exception was raised — the only timestamp the schema itself carries. */
  occurredAt: string;
  exceptionCategoryCode: string;
  exceptionCategoryName: string;
  exceptionTypeCode: string;
  exceptionTypeName: string;
  errorCode?: string | null;
  /** Masked server-side — integration error text routinely embeds account numbers. */
  errorDescription?: string | null;
  errorDetails?: string | null;
  messageType?: string | null;
  severityCode: ExceptionSeverity;
  priorityCode?: string | null;
  itStatusCode?: ItStatus | null;
  operationsStatusCode?: OperationsStatus | null;
  /** Seconds since `occurredAt`, as at the moment the page was fetched. */
  queueAgeSeconds: number;
  slaState?: SlaState | null;
  slaThresholdMinutes?: number | null;
  retryCount: number;
  /** Whether Retry is configured for this category — drives Drop 2's action set. */
  isRetryAllowed: boolean;
  /** Whether Reject is configured for this category — same eligibility-driven gate as Retry. */
  isRejectAllowed: boolean;
  channel?: string | null;
  /** Latest comment from either team. Not attributed per side until Drop 2. */
  latestComment?: string | null;
  latestCommentBy?: string | null;
  /** Per-rail transaction or message fields for the detail panel's third card. */
  transactionDetails?: Record<string, string> | null;
}

export interface TechnicalExceptionListResponse {
  exceptions: TechnicalExceptionRow[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
}

export interface TechnicalExceptionTabCounts {
  actionPending: number;
  activeExceptions: number;
  all: number;
}

export interface ExceptionCategoryOption {
  categoryCode: string;
  categoryName: string;
  description?: string | null;
}

/** Response shape of POST /api/ops/technical-exceptions/retry. */
export interface TechnicalExceptionRetryResult {
  accepted: number;
  exceptions: string[];
}

/** Response shape of POST /api/ops/technical-exceptions/reject. */
export interface TechnicalExceptionRejectResult {
  accepted: number;
  exceptions: string[];
}

/**
 * One Audit Trail row — one exception version, so one state change. Never
 * collapsed: each retry is its own row (BR-ITEQ-007).
 */
export interface TechnicalExceptionAuditRow {
  exceptionKey: string;
  version: number;
  eventType: string;
  previousStatusCode?: string | null;
  statusCode: string;
  railCode: string;
  exceptionCategoryName: string;
  exceptionTypeName: string;
  errorCode?: string | null;
  errorDescription?: string | null;
  retryCount: number;
  occurredAt: string;
  resolutionCode?: string | null;
  /** Comment recorded with the action, masked server-side. Audit Trail "Remarks". */
  remarks?: string | null;
  /** Audit Trail "Action By". */
  actionBy?: string | null;
  /** Audit Trail "Channel" — the system or path that wrote this version. */
  channel?: string | null;
}
