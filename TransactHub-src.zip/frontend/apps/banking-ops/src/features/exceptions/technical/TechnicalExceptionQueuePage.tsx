import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PageBody, PageShell, SmartGrid, Tooltip, cn, parseMultiFilter, usePermissions } from '@paymenthub/ui';
import type { SmartGridQueryChange } from '@paymenthub/ui';
import { Inbox, Lock } from 'lucide-react';
import { Toast } from '../../../shared/components/Toast';
import type { ToastState } from '../../../shared/components/Toast';
import { technicalExceptionsApi } from './api';
// `SmartGridExportFormat` is not re-exported from the barrel, and adding it there would
// mean editing ui-common-lib and re-gating all three apps for a type alias. This local
// union is structurally identical, so `onExport` still type-checks against the primitive.
import type { ExportFormat, TechnicalExceptionListParams } from './api';
import { buildColumns } from './columns';
import type { SlNoView } from './columns';
import type { TechnicalExceptionRow, TechnicalExceptionTab } from './types';
import { PERM } from '../../../shared/auth/permissionKeys';
import { ExceptionDetailSheet } from './ExceptionDetailSheet';
import { AuditTrailModal } from './AuditTrailModal';

interface Query {
  page: number;
  pageSize: number;
  filters: Record<string, string>;
  sortBy: string | null;
  sortDir: 'asc' | 'desc';
}

/** Newest first: in a queue, the latest exception is the one an operator is being paged about. */
/** The server's reason (ApiErrorResponse.detail) when it refused the request, e.g. "Transition not allowed for status 'CLOSED'". */
export function serverReason(error: unknown): string | undefined {
  const detail = (error as { response?: { data?: { detail?: string | null } } })?.response?.data?.detail;
  return detail || undefined;
}

const EMPTY_QUERY: Query = { page: 1, pageSize: 10, filters: {}, sortBy: 'occurredAt', sortDir: 'desc' };

const TABS: { key: TechnicalExceptionTab; label: string; tone: string }[] = [
  { key: 'action-pending', label: 'Action Pending', tone: 'bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]' },
  { key: 'active-exceptions', label: 'Active Exceptions', tone: 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]' },
  { key: 'all', label: 'All', tone: 'bg-[var(--bg-3)] text-[var(--text-2)]' },
];

/**
 * Empty-state copy per tab. Action Pending explains *why* it can be empty — without
 * that line an operator reasonably reads an empty tab as a broken screen, when in
 * fact no category has Retry configured yet (design §4.10, D-7).
 */
const EMPTY_STATE: Record<TechnicalExceptionTab, { title: string; message: string }> = {
  'action-pending': {
    title: 'No exceptions are pending IT action',
    message:
      'Only exception categories configured for Retry appear here. If this stays empty, the retry-enabled categories may not be configured yet.',
  },
  'active-exceptions': {
    title: 'No active technical exceptions',
    message: 'Technical exceptions awaiting IT review will appear here.',
  },
  all: {
    title: 'No exception records found',
    message: 'No records match the current filters. Clear the filters to see the full set.',
  },
};

/**
 * Technical Exception Queue — the IT Operations queue for payments that stalled on a
 * technical step (core-banking timeout, channel notification failure, file read error).
 *
 * Drop 1 is read-only: look, filter, sort, export, and follow the audit trail. Retry
 * and Mark as Closed arrive in Drop 2 with the endpoints that submit them, so this
 * page deliberately renders no action it cannot perform.
 *
 * Grid mechanics — column filters, sorting, column visibility and reorder, pagination,
 * export menu — all come from the shared `SmartGrid` primitive. This page owns only the
 * server query state, the tab predicate, and the two read-only popups.
 */
/**
 * Unmask PII — visible, permanently disabled placeholder.
 *
 * Deliberately **not** `SmartGrid`'s `pii` prop: that control is contractually gated on
 * `canUnmask` and hides itself entirely when unmask isn't available ("`canUnmask: false`
 * (or omit `pii`) rather than relying on a disabled state" — SmartGrid.tsx). This screen
 * wants the opposite for now: the affordance **visible**, so the toolbar reads as complete
 * and matches the sibling screens that already show it, but genuinely inert.
 *
 * No masked/unmasked state is held here, no value is cached, and there is no click handler
 * — this renders exactly what §4.15 and D-5(a) require in Drop 1: masking is server-side
 * and always on, with no reveal path. A real, permission- and session-gated unmask arrives
 * in Drop 2, mirroring the SIF Detail Report's server-backed unmask session rather than the
 * WPS Upload History screen's client-cached one (design §6.4; the Upload History pattern
 * carries every unmasked value to the browser regardless of permission and is flagged in
 * its own source as needing to be gated before release — not a pattern to extend here).
 */
function UnmaskPiiPlaceholder() {
  return (
    <Tooltip content="Unmask PII is available in a later phase." side="top">
      <span className="pq-pii-toggle cursor-not-allowed text-[var(--text-muted)] opacity-60" aria-disabled="true">
        <Lock size={13} aria-hidden="true" />
        Unmask PII
      </span>
    </Tooltip>
  );
}

export function TechnicalExceptionQueuePage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  /**
   * The three export routes sit on a group nested inside the page gate, so they need
   * `ops:report:export` on top of the page key. Hiding the menu for a caller who lacks it keeps the
   * toolbar honest — the server refuses either way, and an export button that always 403s reads as
   * a broken screen rather than as a permission.
   */
  const { can } = usePermissions();
  const canExport = can(PERM.opsReportExport);

  const [activeTab, setActiveTab] = useState<TechnicalExceptionTab>('active-exceptions');
  const [query, setQuery] = useState<Query>(EMPTY_QUERY);
  const [detailRow, setDetailRow] = useState<TechnicalExceptionRow | null>(null);
  const [auditFor, setAuditFor] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);

  const listParams: TechnicalExceptionListParams = useMemo(() => {
    const f = query.filters;

    // IT Status is a multiSelect (Common Grid Features spec §2) and the backend's
    // itStatusCodes takes an array, so every checked value goes in one request.
    const itStatusCodes = parseMultiFilter(f.itStatus);

    // The backend exposes one full-text `searchQuery` — it already ORs across
    // transaction id, exception key, error code, error text and CB ref — so the three
    // search-like filter cells feed it. If more than one is filled, Transaction System
    // ID wins, then Error Code, then Error Description: operators searching one of
    // these rarely fill two at once. Same precedence as the business queue, so moving
    // between the screens holds no surprises.
    const search = f.search?.trim() || f.errorCode?.trim() || f.errorDescription?.trim() || undefined;

    // A dateRange filter yields two keys — `${filterKey}From` and `${filterKey}To`.
    const retryCountFilter = f.retryCount?.trim();

    return {
      tab: activeTab,
      page: query.page,
      pageSize: query.pageSize,
      search,
      rail: f.rail?.trim() || undefined,
      exceptionCategoryCode: f.category?.trim() || undefined,
      severity: f.severity?.trim() || undefined,
      itStatusCodes: itStatusCodes.length > 0 ? itStatusCodes : undefined,
      slaState: f.sla?.trim() || undefined,
      occurredFrom: f.occurredFrom || undefined,
      occurredTo: f.occurredTo || undefined,
      minRetryCount: retryCountFilter ? Number(retryCountFilter) : undefined,
      sortBy: query.sortBy ?? undefined,
      sortDir: query.sortDir,
    };
  }, [activeTab, query]);

  const categoriesQuery = useQuery({
    queryKey: ['technical-exceptions', 'categories'],
    queryFn: () => technicalExceptionsApi.categories(),
    staleTime: 5 * 60 * 1000,
  });

  const categoryOptions = useMemo(
    () => (categoriesQuery.data ?? []).map((c) => ({ value: c.categoryCode, label: c.categoryName })),
    [categoriesQuery.data],
  );

  const listQuery = useQuery({
    queryKey: ['technical-exceptions', 'list', listParams],
    queryFn: () => technicalExceptionsApi.list(listParams),
  });

  // FSD §5 wants the badge counts as at load time, so this is fetched once per mount
  // and on refetch — never on a timer.
  const countsQuery = useQuery({
    queryKey: ['technical-exceptions', 'tab-counts'],
    queryFn: () => technicalExceptionsApi.tabCounts(),
  });

  const rows = listQuery.data?.exceptions ?? [];
  const totalRecords = listQuery.data?.totalCount ?? 0;

  /**
   * The live page, for the Sl. No. counter. Repointed on every render rather than passed
   * into `buildColumns` by value, because SmartGrid snapshots the column definitions on
   * first mount and never re-reads the prop — see `SlNoView` in columns.tsx.
   */
  const slNoView = useRef<SlNoView>({ page: query.page, pageSize: query.pageSize, rows });
  slNoView.current = { page: query.page, pageSize: query.pageSize, rows };
  const totalPages = Math.max(1, Math.ceil(totalRecords / query.pageSize));

  // Filtering, sorting or switching tabs can shrink the result set below the page the
  // operator was on. SmartGrid's server mode trusts the caller to clamp — without this
  // the query keeps asking for an out-of-range page and the grid reports "no matches"
  // while matches exist elsewhere.
  useEffect(() => {
    if (query.page > totalPages) setQuery((q) => ({ ...q, page: 1 }));
  }, [query.page, totalPages]);

  function handleQueryChange(change: SmartGridQueryChange) {
    setQuery((prev) => ({
      page: change.page ?? prev.page,
      pageSize: change.pageSize ?? prev.pageSize,
      filters: change.filters ?? prev.filters,
      sortBy: change.sortBy !== undefined ? change.sortBy : prev.sortBy,
      sortDir: change.sortDir ?? prev.sortDir,
    }));
  }

  /**
   * Switching a tab resets the page and restarts Sl. No. at 1 (BR-ITEQ-006) but
   * **keeps the filters** — an operator who has narrowed to a rail and then checks
   * another tab expects that narrowing to hold.
   */
  function switchTab(tab: TechnicalExceptionTab) {
    setActiveTab(tab);
    setQuery((q) => ({ ...q, page: 1 }));
  }

  const columns = useMemo(
    () =>
      buildColumns({
        slNoView,
        categoryOptions,
        onViewDetails: setDetailRow,
        onViewAuditTrail: (r) => setAuditFor(r.transactionSystemId),
      }),
    // `slNoView` is a ref, so it is stable and deliberately not a dependency — the counter
    // reads through it rather than from anything captured here. Page, page size and rows
    // are gone from the list for the same reason: rebuilding the columns for them achieved
    // nothing anyway, since SmartGrid only ever reads the definitions it saw on mount.
    [categoryOptions],
  );

  /**
   * Export hands off to the server, which renders genuine CSV / XLSX / PDF bytes through
   * the same chain the SIF reports use. `columns` carries the operator's visible column
   * keys so the file matches the screen, and `X-Export-Truncated` surfaces as a warning
   * rather than handing over a silently partial file.
   */
  const handleExport = async (format: ExportFormat): Promise<Blob> => {
    const visibleColumns = columns.filter((c) => c.key !== 'slNo' && c.key !== 'actions').map((c) => c.key);

    const { blob, truncated } = await technicalExceptionsApi.export(format, listParams, visibleColumns);

    if (truncated) {
      setToast({
        tone: 'error',
        message:
          'The export hit its row limit and is incomplete — narrow the filters to export the remaining records.',
      });
    }

    return blob;
  };

  /**
   * One of the two resolution actions this queue has — see ExceptionDetailSheet's own
   * note: no `action` choice and no approval step, unlike the business queue's resolve.
   * Invalidates both the list and the tab counts, since a successful retry moves the
   * row out of Action Pending (and, on the DB side, versions the exception the same
   * append-only way business resolve does).
   */
  const retryMutation = useMutation({
    // Addressed by exception key: a transaction can carry several keys (one per park), so the TransactionId could land on another one.
    mutationFn: ({ exceptionKey, comments }: { exceptionKey: string; comments: string }) =>
      technicalExceptionsApi.retry([exceptionKey], comments),
    onSuccess: (result, { exceptionKey }) => {
      setToast({
        tone: 'success',
        message:
          result.accepted > 0
            ? `Retry submitted for ${exceptionKey}.`
            : `${exceptionKey} could not be retried — it may have already been resolved.`,
      });
      setDetailRow(null);
      queryClient.invalidateQueries({ queryKey: ['technical-exceptions'] });
    },
    onError: (error: unknown) =>
      setToast({ tone: 'error', message: serverReason(error) || 'Could not submit the retry. Please try again.' }),
  });

  /** The other resolution action — same shape and same invalidation as retryMutation. */
  const rejectMutation = useMutation({
    mutationFn: ({ exceptionKey, comments }: { exceptionKey: string; comments: string }) =>
      technicalExceptionsApi.reject([exceptionKey], comments),
    onSuccess: (result, { exceptionKey }) => {
      setToast({
        tone: 'success',
        message:
          result.accepted > 0
            ? `Reject submitted for ${exceptionKey}.`
            : `${exceptionKey} could not be rejected — it may have already been resolved.`,
      });
      setDetailRow(null);
      queryClient.invalidateQueries({ queryKey: ['technical-exceptions'] });
    },
    onError: (error: unknown) =>
      setToast({ tone: 'error', message: serverReason(error) || 'Could not submit the reject. Please try again.' }),
  });

  const counts = countsQuery.data;
  const emptyState = EMPTY_STATE[activeTab];

  return (
    <PageShell>
      <PageBody>
        <div className="pq-page pr-2">
          {/* Breadcrumb */}
          <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
            <button onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">
              Dashboard
            </button>
            {' / Operations / '}
            <span>Technical Exception Queue</span>
          </p>

          {/* Title header */}
          <div className="pq-header">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                Technical Exception Queue
              </h1>
              <p className="pq-header-subtitle">
                Payment exceptions requiring IT diagnosis — review the error, follow the audit trail, and export for
                analysis
              </p>
            </div>
            {counts?.actionPending !== undefined && (
              <div className="pq-header-meta">
                <span className="pq-pending-badge">{counts.actionPending.toLocaleString()} pending</span>
              </div>
            )}
          </div>

          {/* Tabs. Mutually exclusive, each with a count badge fetched at load time. */}
          <div role="tablist" aria-label="Exception queue tabs" className="flex flex-wrap items-center gap-2">
            {TABS.map((t) => {
              // const count =
              //   t.key === 'action-pending'
              //     ? counts?.actionPending
              //     : t.key === 'active-exceptions'
              //       ? counts?.activeExceptions
              //       : counts?.all;

              return (
                <button
                  key={t.key}
                  type="button"
                  role="tab"
                  aria-selected={activeTab === t.key}
                  onClick={() => switchTab(t.key)}
                  className={cn('common-pill', activeTab === t.key && 'active-pill')}
                >
                  <span className="pq-tab-label">{t.label}</span>
                  {/* {count !== undefined && <span className="pq-tab-count">{count}</span>} */}
                </button>
              );
            })}
          </div>

          {listQuery.isError ? (
            /* An error must not present as an empty grid — the operator has to be able
               to tell "nothing matched" from "the query failed", and retry. */
            <div className="flex flex-col items-start gap-3 rounded-lg border border-[var(--accent-red)]/40 bg-[var(--accent-red)]/5 p-6">
              <div className="flex items-center gap-2 text-sm font-semibold text-[var(--accent-red)]">
                <Inbox size={16} aria-hidden="true" />
                Could not load the exception queue
              </div>
              <p className="text-sm text-[var(--text-2)]">
                The request failed. This is usually temporary — retry, and if it persists check that your session
                still has access to this queue.
              </p>
              <button
                type="button"
                onClick={() => listQuery.refetch()}
                className="btn-tertiary h-38px"
              >
                Retry
              </button>
            </div>
          ) : (
            <SmartGrid<TechnicalExceptionRow>
              columns={columns}
              rows={rows}
              getRowId={(r) => r.exceptionKey}
              storageKey="technical-exceptions-columns-v1"
              loading={listQuery.isFetching}
              emptyTitle={emptyState.title}
              emptyMessage={emptyState.message}
              exportFilename={`technical-exceptions-${activeTab}`}
              onExport={canExport ? handleExport : undefined}
              exportFormats={canExport ? ['csv', 'excel', 'pdf'] : []}
              toolbarExtra={<UnmaskPiiPlaceholder />}
              banner={
                activeTab === 'all' ? (
                  <p className="text-xs text-[var(--text-2)]">
                    Showing all records, including closed, resolved and archived exceptions. Actions are not available
                    from this tab.
                  </p>
                ) : undefined
              }
              server={{
                page: query.page,
                pageSize: query.pageSize,
                total: totalRecords,
                sortBy: query.sortBy,
                sortDir: query.sortDir,
                onQueryChange: handleQueryChange,
              }}
            />
          )}
        </div>
      </PageBody>

      {detailRow && (
        <ExceptionDetailSheet
          row={detailRow}
          onClose={() => setDetailRow(null)}
          onRetry={(comments) => retryMutation.mutate({ exceptionKey: detailRow.exceptionKey, comments })}
          onReject={(comments) => rejectMutation.mutate({ exceptionKey: detailRow.exceptionKey, comments })}
          submitting={retryMutation.isPending || rejectMutation.isPending}
        />
      )}

      {auditFor && <AuditTrailModal transactionSystemId={auditFor} onClose={() => setAuditFor(null)} />}

      {/* timeout={0}: the operator dismisses it, so a truncated export cannot be missed. */}
      <Toast toast={toast} onDismiss={() => setToast(null)} timeout={0} />
    </PageShell>
  );
}
