import { useState } from 'react';
import type { ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '@paymenthub/ui';

/**
 * Accordion and field primitives for the Technical Exception Queue's detail panel.
 *
 * Copied from `../business/panelParts.tsx` rather than shared from it. Drop 1's rule is
 * to add, never to edit a file another live screen depends on (design §4.18), and the
 * two panels are already diverging — this one is read-only with no Actions card, while
 * the business panel carries action pickers and a submit footer. Consolidating them is
 * a tracked Drop 2 item (D-2), not something to do while the shapes are still moving.
 */

type CardTone = 'info' | 'warn' | 'txn' | 'act';

const TONE_CLASS: Record<CardTone, string> = {
  info: 'bg-[var(--accent-blue)]/15 text-[var(--accent-blue)]',
  warn: 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]',
  txn: 'bg-[var(--accent-purple)]/15 text-[var(--accent-purple)]',
  act: 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]',
};

export function CollapsibleCard({
  title,
  note,
  tone,
  icon,
  defaultOpen = false,
  children,
}: {
  title: string;
  /** Small italic hint next to the title, e.g. "fields are dynamic and configurable". */
  note?: string;
  tone: CardTone;
  icon: ReactNode;
  defaultOpen?: boolean;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <section className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--bg-card)]">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={cn(
          'flex w-full items-center gap-2.5 bg-[var(--bg-secondary)]/50 px-4 py-3 text-left transition-colors hover:bg-[var(--bg-secondary)]',
          open && 'border-b border-[var(--border)]',
        )}
      >
        <span className={cn('grid size-7 shrink-0 place-items-center rounded-full', TONE_CLASS[tone])}>{icon}</span>
        <span className="text-sm font-bold text-[var(--text-primary)]">{title}</span>
        {note && <span className="truncate text-xs text-[var(--text-muted)]">{note}</span>}
        <ChevronDown
          size={16}
          className={cn('ml-auto shrink-0 text-[var(--text-muted)] transition-transform', !open && '-rotate-90')}
        />
      </button>
      {open && <div className="p-4">{children}</div>}
    </section>
  );
}

export function FieldGrid({ children }: { children: ReactNode }) {
  return <div className="grid grid-cols-2 gap-4">{children}</div>;
}

export function Field({
  label,
  children,
  full,
  mono,
  emphasis,
}: {
  label: string;
  children: ReactNode;
  full?: boolean;
  mono?: boolean;
  emphasis?: boolean;
}) {
  return (
    <div className={cn('min-w-0', full && 'col-span-2')}>
      <div className="input-label mb-1 block">{label}</div>
      <div
        className={cn(
          'break-words text-sm text-[var(--text-primary)]',
          mono && 'font-mono',
          emphasis && 'font-bold text-[var(--primary-blue)]',
        )}
      >
        {children}
      </div>
    </div>
  );
}

/** The error code badge and full error text — FSD §8.1 card 2. */
export function ErrorPanel({ code, narrative }: { code?: string | null; narrative?: string | null }) {
  return (
    <div className="rounded-xl border border-[var(--accent-red)]/30 bg-[var(--accent-red)]/5 p-4">
      {code && (
        <span className="mb-2 inline-block rounded-full bg-[var(--accent-red)]/15 px-2.5 py-0.5 font-mono text-[11px] font-bold text-[var(--accent-red)]">
          {code}
        </span>
      )}
      <p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-[var(--text-primary)]">
        {narrative || 'No error details recorded.'}
      </p>
    </div>
  );
}

/**
 * Comments box for the Retry action — added alongside the Actions card below. Copied
 * from `../business/panelParts.tsx`'s `CommentsField` rather than shared, same
 * not-editing-a-file-another-screen-depends-on rule this file's own header names.
 */
export function CommentsField({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (next: string) => void;
  placeholder: string;
}) {
  return (
    <label className="block">
      <span className="input-label mb-1.5 block">
        Comments <span className="text-red-500">*</span>
      </span>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        required
        className="input-cls w-full resize-y text-xs"
      />
    </label>
  );
}
