import { Badge, EMPTY_DATE, cn, sessionInstant } from '@paymenthub/ui';
import { TriangleAlert } from 'lucide-react';
import type { SlaState } from './types';

/**
 * Cell renderers for the Technical Exception Queue grid.
 *
 * The UI mock (IT_Operation_Exception_Management_v0.1.html) is a light-theme page of
 * hardcoded hex values. Every one of them is mapped here to a semantic `Badge`
 * variant or a design token, so the screen themes correctly in light, dim and dark
 * without a per-theme override — see design §4.11.2 for the full mapping table.
 *
 * No new `Badge` variant was needed: the barrel already exposes
 * green | blue | amber | red | purple | cyan | default.
 */

/** Rendered wherever a value is absent, matching the grid's em dash (FSD §6.2). */
export const EM_DASH = '—';

type BadgeVariant = 'green' | 'blue' | 'amber' | 'red' | 'purple' | 'cyan' | 'default';

/** Mock: .rail-wps #dcfce7/#15803d, .rail-ipi #ede9fe/#6d28d9, .rail-fts #e0f2fe/#0369a1, … */
const RAIL_VARIANT: Record<string, BadgeVariant> = {
  WPS: 'green',
  IPI: 'purple',
  FTS: 'cyan',
  UAEFTS: 'cyan',
  IPP: 'amber',
  SWIFT: 'amber',
};

/** Mock: .sev-critical #dc2626, .sev-high #b45309, .sev-medium #15803d, .sev-low #475569 */
const SEVERITY_VARIANT: Record<string, BadgeVariant> = {
  CRITICAL: 'red',
  HIGH: 'amber',
  MEDIUM: 'green',
  LOW: 'default',
};

/** Mock: .pri-c1 #dc2626, .pri-c2 #ea580c, .pri-l1/.pri-l2 grey */
const PRIORITY_VARIANT: Record<string, BadgeVariant> = {
  C1: 'red',
  C2: 'amber',
  L1: 'default',
  L2: 'default',
};

const IT_STATUS_VARIANT: Record<string, BadgeVariant> = {
  OPEN: 'blue',
  CLOSED: 'default',
};

const OPERATIONS_STATUS_VARIANT: Record<string, BadgeVariant> = {
  OPEN: 'blue',
  PENDING_APPROVAL: 'amber',
  RESOLVED: 'green',
};

/** FSD §6.2 labels, which differ from the codes the API returns. */
const OPERATIONS_STATUS_LABEL: Record<string, string> = {
  OPEN: 'Open',
  PENDING_APPROVAL: 'Pending Approval',
  RESOLVED: 'Resolved',
};

const IT_STATUS_LABEL: Record<string, string> = {
  OPEN: 'Open',
  CLOSED: 'Closed',
};

const SEVERITY_LABEL: Record<string, string> = {
  CRITICAL: 'Critical',
  HIGH: 'High',
  MEDIUM: 'Medium',
  LOW: 'Low',
};

/** Mock: .sla-ok dot #22c55e, .sla-warn #f59e0b, .sla-breach #ef4444. */
const SLA_PRESENTATION: Record<SlaState, { dot: string; text: string; label: string }> = {
  WITHIN: { dot: 'var(--accent-green)', text: 'var(--accent-green)', label: 'Within SLA' },
  APPROACHING: { dot: 'var(--accent-amber)', text: 'var(--accent-amber)', label: 'Approaching' },
  BREACHED: { dot: 'var(--accent-red)', text: 'var(--accent-red)', label: 'Breached' },
};

export function RailBadge({ rail }: { rail: string }) {
  return <Badge variant={RAIL_VARIANT[rail?.toUpperCase()] ?? 'default'}>{rail}</Badge>;
}

export function SeverityBadge({ severity }: { severity: string }) {
  const key = severity?.toUpperCase();
  return <Badge variant={SEVERITY_VARIANT[key] ?? 'default'}>{SEVERITY_LABEL[key] ?? severity}</Badge>;
}

export function PriorityBadge({ priority }: { priority?: string | null }) {
  // Blank rather than a placeholder when priority is not configured (design §3.2).
  if (!priority) return <span className="text-[var(--text-muted)]">{EM_DASH}</span>;
  return <Badge variant={PRIORITY_VARIANT[priority.toUpperCase()] ?? 'default'}>{priority}</Badge>;
}

export function ItStatusBadge({ status }: { status?: string | null }) {
  // Null means "not a technical exception" — the blank dash of FSD §6.2, not an error.
  if (!status) return <span className="text-[var(--text-muted)]">{EM_DASH}</span>;
  const key = status.toUpperCase();
  return <Badge variant={IT_STATUS_VARIANT[key] ?? 'default'}>{IT_STATUS_LABEL[key] ?? status}</Badge>;
}

export function OperationsStatusBadge({ status }: { status?: string | null }) {
  if (!status) return <span className="text-[var(--text-muted)]">{EM_DASH}</span>;
  const key = status.toUpperCase();
  return (
    <Badge variant={OPERATIONS_STATUS_VARIANT[key] ?? 'default'}>
      {OPERATIONS_STATUS_LABEL[key] ?? status}
    </Badge>
  );
}

/**
 * SLA chip — a coloured dot plus a text label. The label is not decorative: colour
 * must never be the sole carrier of meaning (guideline §15), and a breached SLA also
 * gets an icon so it reads without colour at all.
 */
export function SlaChip({ state }: { state?: string | null }) {
  if (!state) return <span className="text-[var(--text-muted)]">{EM_DASH}</span>;

  const presentation = SLA_PRESENTATION[state.toUpperCase() as SlaState];
  if (!presentation) return <span className="text-[var(--text-muted)]">{EM_DASH}</span>;

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold" style={{ color: presentation.text }}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: presentation.dot }} aria-hidden="true" />
      {presentation.label}
      {state.toUpperCase() === 'BREACHED' && <TriangleAlert size={12} aria-hidden="true" />}
    </span>
  );
}

/** Mock: .retry-chip, green when the last attempt succeeded, red when exhausted. */
export function RetryCountChip({ count }: { count: number }) {
  return (
    <span
      className={cn(
        count === 0
          ? 'badge-selected'
          : 'inline-flex min-w-[1.75rem] justify-center rounded px-2 py-0.5 text-xs font-semibold bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]',
      )}
      // The FSD counts automatic and manual attempts together; only the manual count
      // exists until a producer supplies `autoRetryCount` (design §3.5).
      title={`${count} operator-initiated ${count === 1 ? 'retry' : 'retries'}. Automatic attempts are not yet reported.`}
    >
      {count}
    </span>
  );
}

/** Renders a value, or the em dash when it is absent. Never a placeholder. */
export function OrDash({ value }: { value?: string | null }) {
  return value ? <>{value}</> : <span className="text-[var(--text-muted)]">{EM_DASH}</span>;
}

/** Queue Age as FSD §6.1 col 18 words it — "5m", "1h 22m", "3 days". */
export function formatQueueAge(seconds: number): string {
  if (seconds < 60) return `${Math.max(0, Math.floor(seconds))}s`;

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    const remainder = minutes % 60;
    return remainder > 0 ? `${hours}h ${remainder}m` : `${hours}h`;
  }

  const days = Math.floor(hours / 24);
  return days === 1 ? '1 day' : `${days} days`;
}

/**
 * An instant in the session zone, `dd-MM-yyyy HH:mm:ss` (UTC date-time design §6.7); `''` when absent or unreadable,
 * so callers can still fall back to their em dash. A thin delegate to the `@paymenthub/ui` date-time module.
 */
export function formatTimestamp(value?: string | null): string {
  const text = sessionInstant(value);
  return text === EMPTY_DATE ? '' : text;
}
