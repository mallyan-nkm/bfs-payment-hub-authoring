import { useState } from 'react';
import type { ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import type { ReferenceField } from './types';

/**
 * Content-building blocks used inside `ExceptionDetailSheet` — collapsible
 * cards, field grids and the resolve-form pickers. The chrome around them
 * (header, close, action buttons) is the shared `Sheet` primitive, matching
 * `TaskDetailSheet`'s convention of free-form content inside a standard Sheet.
 */

export type CardTone = 'blue' | 'red' | 'purple' | 'amber' | 'teal';

const TONE_CLASS: Record<CardTone, string> = {
  blue: 'bg-[var(--accent-blue)]/12 text-[var(--accent-blue)]',
  red: 'bg-[var(--accent-red)]/12 text-[var(--accent-red)]',
  purple: 'bg-[var(--accent-purple)]/12 text-[var(--accent-purple)]',
  amber: 'bg-[var(--accent-amber)]/12 text-[var(--accent-amber)]',
  teal: 'bg-[var(--accent-cyan)]/12 text-[var(--accent-cyan)]',
};

export function CollapsibleCard({
  title,
  note,
  tone,
  icon,
  defaultOpen = false,
  children,
}: {
  title: string;
  /** Small italic hint next to the title, e.g. "(configurable per category)". */
  note?: string;
  tone: CardTone;
  icon: ReactNode;
  defaultOpen?: boolean;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <section className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={cn(
          'flex w-full items-center gap-2 px-3 py-2 text-left hover:bg-[var(--bg-card-hover)]',
          open && 'border-b border-[var(--border-light)]',
        )}
      >
        <span className={cn('grid size-5 shrink-0 place-items-center rounded', TONE_CLASS[tone])}>{icon}</span>
        <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-secondary)]">{title}</span>
        {note && <span className="truncate text-[10px] italic text-[var(--text-muted)]">{note}</span>}
        <ChevronDown
          size={13}
          className={cn('ml-auto shrink-0 text-[var(--text-muted)] transition-transform', !open && '-rotate-90')}
        />
      </button>
      {open && <div className="p-3">{children}</div>}
    </section>
  );
}

export function FieldGrid({ children }: { children: ReactNode }) {
  return <div className="grid grid-cols-2 gap-3">{children}</div>;
}

export function Field({
  label,
  children,
  full,
  mono,
  emphasis,
}: {
  label: string;
  children: ReactNode;
  full?: boolean;
  mono?: boolean;
  emphasis?: boolean;
}) {
  return (
    <div className={cn('min-w-0', full && 'col-span-2')}>
      <div className="mb-0.5 text-[10px] font-bold uppercase tracking-wide text-[var(--text-muted)]">{label}</div>
      <div
        className={cn(
          'break-words text-xs text-[var(--text-primary)]',
          mono && 'font-mono',
          emphasis && 'font-bold',
        )}
      >
        {children}
      </div>
    </div>
  );
}

/** Renders the exception's soft-reference ids and any parsed AdditionalData. */
export function MessageFields({ fields }: { fields: ReferenceField[] }) {
  if (fields.length === 0) {
    return <p className="text-xs text-[var(--text-muted)]">No reference details recorded for this exception.</p>;
  }

  return (
    <FieldGrid>
      {fields.map((field) => (
        <Field key={field.label} label={field.label} mono={field.mono}>
          {field.value}
        </Field>
      ))}
    </FieldGrid>
  );
}

export function ErrorPanel({ code, narrative }: { code: string; narrative: string }) {
  return (
    <div className="rounded-md border border-[var(--accent-red)]/30 bg-[var(--accent-red)]/10 p-3">
      <span className="inline-block rounded border border-[var(--accent-red)]/40 bg-[var(--bg-card)] px-2 py-0.5 font-mono text-xs font-bold text-[var(--accent-red)]">
        {code}
      </span>
      <p className="mt-2 text-xs leading-relaxed text-[var(--text-secondary)]">{narrative}</p>
    </div>
  );
}

/** Radio-style list of the resolution actions available for this category. */
export function ActionPicker({
  actions,
  selected,
  onSelect,
}: {
  actions: string[];
  selected: string | null;
  onSelect: (action: string) => void;
}) {
  return (
    <div className="flex flex-col gap-1.5" role="radiogroup" aria-label="Resolution action">
      {actions.map((action) => {
        const active = selected === action;
        return (
          <button
            key={action}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onSelect(action)}
            className={cn(
              'flex items-center gap-2.5 rounded-md border px-3 py-2 text-left text-xs transition-colors',
              active
                ? 'border-[var(--accent)] bg-[var(--accent)]/10 font-semibold text-[var(--accent)]'
                : 'border-[var(--border)] text-[var(--text-secondary)] hover:border-[var(--accent)]/40 hover:bg-[var(--bg-card-hover)]',
            )}
          >
            <span
              className={cn(
                'grid size-3.5 shrink-0 place-items-center rounded-full border-2',
                active ? 'border-[var(--accent)]' : 'border-[var(--border)]',
              )}
            >
              {active && <span className="size-1.5 rounded-full bg-[var(--accent)]" />}
            </span>
            {action}
          </button>
        );
      })}
    </div>
  );
}

/** The action label the dual-control set covers (it maps to MANUAL_COMPLETE on the server). */
export const MARK_AS_SUCCESS = 'Mark as Success';

/**
 * The one next action a dual-control exception accepts for `action`, or undefined when the operator may
 * choose (WPS inward Activity 28 design §9.4 points 3, 8): Mark as Success can only be submitted for
 * approval, and every other action only executed — /resolve refuses the other combination with a 400.
 */
export function forcedNextAction(requiresApproval: boolean, action: string | null): 'approval' | 'execute' | undefined {
  if (!requiresApproval || !action) return undefined;
  return action === MARK_AS_SUCCESS ? 'approval' : 'execute';
}

/**
 * The Next action a modal starts on. Only a dual-control item can be submitted for approval — the server refuses 'approval' for any other
 * type, and nobody could approve it — so an item that is not dual-controlled (for a batch: none of the selected items) starts on 'execute'.
 */
export function defaultNextAction(requiresApproval: boolean): 'approval' | 'execute' {
  return requiresApproval ? 'approval' : 'execute';
}

/**
 * Approval-required vs execute-now. Whether an operator may execute directly is
 * a bank configuration; the screen shows both so the choice is explicit and
 * lands in the audit trail either way — except where `only` names the one the
 * server accepts (a dual-control item), when the other choice is not shown.
 */
export function NextActionPicker({
  value,
  onChange,
  only,
}: {
  value: 'approval' | 'execute';
  onChange: (next: 'approval' | 'execute') => void;
  only?: 'approval' | 'execute';
}) {
  const allOptions = [
    {
      key: 'approval' as const,
      title: 'Approval Required',
      description: 'Submit for supervisor approval before execution',
      activeClass: 'border-[var(--accent)] bg-[var(--accent)]/10',
      titleClass: 'text-[var(--accent)]',
    },
    {
      key: 'execute' as const,
      title: 'Execute the Action',
      description: 'No approval needed — executes immediately',
      activeClass: 'border-[var(--accent-green)] bg-[var(--accent-green)]/10',
      titleClass: 'text-[var(--accent-green)]',
    },
  ];
  const options = only ? allOptions.filter((o) => o.key === only) : allOptions;

  return (
    <div className="flex gap-2" role="radiogroup" aria-label="Next action">
      {options.map((option) => {
        const active = value === option.key;
        return (
          <button
            key={option.key}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(option.key)}
            className={cn(
              'flex-1 rounded-lg border-2 px-3 py-2.5 text-left transition-colors',
              active
                ? option.activeClass
                : 'border-[var(--border)] hover:border-[var(--accent)]/40 hover:bg-[var(--bg-card-hover)]',
            )}
          >
            <div className={cn('text-xs font-bold', active ? option.titleClass : 'text-[var(--text-muted)]')}>
              {option.title}
            </div>
            <div className="mt-0.5 text-[10px] leading-snug text-[var(--text-muted)]">{option.description}</div>
          </button>
        );
      })}
    </div>
  );
}

/** Comments box shared by the resolve form. */
export function CommentsField({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (next: string) => void;
  placeholder: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] font-bold uppercase tracking-wide text-[var(--text-muted)]">
        Comments <span className="text-[var(--danger,#dc2626)]">*</span>
      </span>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        required
        className="w-full resize-y rounded-md border border-[var(--border)] bg-[var(--bg-input)] px-2.5 py-2 text-xs text-[var(--text-primary)] outline-none focus:border-[var(--accent)]"
      />
    </label>
  );
}
