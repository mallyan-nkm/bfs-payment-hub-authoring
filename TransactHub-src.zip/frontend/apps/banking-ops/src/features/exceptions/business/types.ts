// ─── Business Exception Management ────────────────────────────────────────────
// Domain model for the Business Exception Management screen (route
// /business-exceptions). A business exception is a payment that completed its
// technical workflow but stalled on a *business* step — a core-banking callback
// that never arrived, a suspense posting the CBS rejected, a reversal that could
// not be posted — and therefore needs an operator decision (retry / mark
// success / mark failure) before the payment can move on.
//
// This shape is trimmed to what the real backend
// (PaymentHub.Operations.API — GET/POST /api/ops/business-exceptions, backed by
// platform.PaymentException + platform.ExceptionClassification) actually
// returns. Fields the old design mock invented but the schema has no column for
// — bank/CB reference, a free-text key word, channel, priority, message type,
// age-in-days, an SLA countdown — are not modelled here. See ./api.ts for the
// exact endpoint contract and the adapter that maps the backend DTO onto this
// shape.

/** Rail code as stored on platform.PaymentException.RailCode (e.g. WPS, FTS, IPI) — not a closed set. */
export type ExceptionRail = string;

export type ExceptionSeverityLevel = 'Critical' | 'High' | 'Medium' | 'Low';

/**
 * Queue status, derived from platform.PaymentException.StatusCode.
 * The backend has no rejected/checker state today — `IN_PROGRESS` is only ever
 * reached via the "submit for approval" path, so it is mapped to
 * `Pending Approval` here. `Resolved` and `Closed` only appear in history.
 */
export type BusinessExceptionStatus = 'Open' | 'Pending Approval' | 'Retrying' | 'Resolved' | 'Closed';

/** One label/value pair in the detail panel's "Transaction / Message Details" card. */
export interface ReferenceField {
  label: string;
  value: string;
  /** Render in the mono font — references, correlation/workflow ids. */
  mono?: boolean;
}

/** Outcome of the last recorded action — the History panel's summary card. */
export interface LatestActionInfo {
  action: string;
  actionedBy: string;
  actionedOn: string;
}

export interface BusinessExceptionDetail {
  /** Error text for the red Exception Details panel — ErrorMessage, with ErrorDetails appended when present. */
  errorNarrative: string;
  /** Rail + exception-type label shown next to the card title, e.g. "WPS · Callback Timeout". */
  messageContext: string;
  /** Soft-reference ids and any parsed AdditionalData — only the fields the record actually carries. */
  referenceFields: ReferenceField[];
  /** Resolution actions offered for this exception category (client-side posting/reversal heuristic — see api.ts). */
  actions: string[];
  /** Comments captured with the resolving action (PaymentException.ResolutionComments), if any. */
  resolutionComments?: string;
  latestAction?: LatestActionInfo;
  /**
   * Mark as Success on this exception is dual-controlled (the server's `requiresApproval`; WPS inward
   * Activity 28): it can only be submitted for approval, and the other actions only executed. Advisory —
   * /resolve refuses anything else on its own.
   */
  requiresApproval: boolean;
  /** Who submitted the pending Mark as Success (the IN_PROGRESS / PENDING_APPROVAL version's ChangedBy), when one is pending. */
  approvalSubmittedBy?: string;
}

export interface BusinessExceptionRow {
  /** Stable logical id across versions — platform.PaymentException.ExceptionKey. */
  id: string;
  /** Identifier used to address this exception in the detail/history/resolve endpoints. */
  transactionSystemId: string;
  rail: ExceptionRail;
  /** ISO 8601 — OccurredAt, the only timestamp the schema carries for an exception event. */
  occurredAt: string;
  exceptionCategory: string;
  exceptionCategoryCode: string;
  /** Specific failure within the category — platform.PaymentException.ExceptionTypeCode. Paired with
   * exceptionCategoryCode, this is the canonical exception classification identity (TypeCode alone
   * is only unique within a category) — see BusinessExceptionManagementPage's same-classification
   * bulk-selection rule. */
  exceptionTypeCode: string;
  errorCode: string;
  errorDescription: string;
  severity: ExceptionSeverityLevel;
  exceptionStatus: BusinessExceptionStatus;
  retryCount: number;
  detail: BusinessExceptionDetail;
}

// ─── Audit trail ──────────────────────────────────────────────────────────────
// Built from GET /{id}/history — one row per PaymentException version, i.e. one
// row per state transition. This is a thinner record than a narrated activity
// log: there is no per-step endpoint/response detail from the backend, only the
// status transition itself plus whatever error/resolution codes were set.

export type AuditActivityStatus = 'Success' | 'Failed' | 'Pending' | 'Open' | 'In Progress';

export interface AuditActivity {
  activity: string;
  actionBy: string;
  /** Display-formatted already — audit rows are a historical record, not a filter source. */
  actionedOn: string;
  channel: string;
  status: AuditActivityStatus;
  remarks: string;
  /** Error/resolution code key-values behind the "Details" toggle. */
  details?: Record<string, string>;
}

export interface AuditTrail {
  reference: string;
  transactionType: string;
  status: BusinessExceptionStatus;
  activities: AuditActivity[];
}

// ─── Resolve form ─────────────────────────────────────────────────────────────

/** Whether the chosen action goes to a supervisor or executes straight away. */
export type NextAction = 'approval' | 'execute';

/** Matches ResolveSubmissionRequestDto field-for-field (camelCased) — see api.ts. */
export interface ResolveSubmission {
  transactionSystemIds: string[];
  action: string;
  nextAction: NextAction;
  comments: string;
}

/** Matches ApprovalDecisionRequestDto (camelCased): the body of /approvals/approve and /approvals/reject. */
export interface ApprovalDecision {
  transactionSystemIds: string[];
  comments: string;
}
