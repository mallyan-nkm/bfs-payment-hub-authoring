import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { FileText, Info, Play, Settings, ShieldCheck, TriangleAlert, X } from 'lucide-react';
import { Can, cn, usePermissions, useSessionDateTime } from '@paymenthub/ui';
import { PERM } from '../../../shared/auth/permissionKeys';
import { useCurrentUsername } from '../../../shared/hooks/useOfflineAwareAction';
import type {
  ApprovalDecision,
  BusinessExceptionRow,
  BusinessExceptionStatus,
  ExceptionSeverityLevel,
  NextAction,
  ResolveSubmission,
} from './types';
import {
  ActionPicker,
  CollapsibleCard,
  CommentsField,
  ErrorPanel,
  Field,
  FieldGrid,
  MessageFields,
  NextActionPicker,
  defaultNextAction,
  forcedNextAction,
} from './panelParts';

const STATUS_TONE: Record<BusinessExceptionStatus, string> = {
  Open: 'border-blue-300 bg-blue-50 text-blue-700',
  'Pending Approval': 'border-amber-300 bg-amber-50 text-amber-700',
  Retrying: 'border-purple-300 bg-purple-50 text-purple-700',
  Resolved: 'border-green-300 bg-green-50 text-green-700',
  Closed: 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]',
};

const SEVERITY_TONE: Record<ExceptionSeverityLevel, string> = {
  Critical: 'border-red-300 bg-red-50 text-red-700',
  High: 'border-amber-300 bg-amber-50 text-amber-700',
  Medium: 'border-green-300 bg-green-50 text-green-700',
  Low: 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]',
};

const RAIL_COLOR: Record<string, string> = {
  WPS: '#16a34a',
  IPI: '#9333ea',
  UAEFTS: '#0891b2',
  FTS: '#0891b2',
  IPP: '#d97706',
  SWIFT: '#2563eb',
};

function isResolvable(row: BusinessExceptionRow): boolean {
  return row.exceptionStatus === 'Open' || row.exceptionStatus === 'Retrying';
}

interface ExceptionDetailModalProps {
  row: BusinessExceptionRow;
  onClose: () => void;
  onSubmit: (submission: ResolveSubmission) => void;
  /** The checker's decision on a pending dual-control Mark as Success (POST /approvals/approve | /reject). */
  onDecideApproval?: (approve: boolean, decision: ApprovalDecision) => void;
  submitting?: boolean;
}

export function ExceptionDetailModal({ row, onClose, onSubmit, onDecideApproval, submitting }: ExceptionDetailModalProps) {
  const [action, setAction] = useState<string | null>(row.detail.actions[0] ?? null);
  const [nextAction, setNextAction] = useState<NextAction>(defaultNextAction(row.detail.requiresApproval));
  const [comments, setComments] = useState('');

  useEffect(() => {
    setAction(row.detail.actions[0] ?? null);
    setNextAction(defaultNextAction(row.detail.requiresApproval));
    setComments('');
  }, [row.id]);

  // A row in a resolvable status is still read-only to a caller without ops:exception:manage —
  // POST /resolve requires it on top of the page key — so the modal opens as a detail view.
  const { can } = usePermissions();
  const { formatInstant } = useSessionDateTime();
  const resolvable = isResolvable(row) && can(PERM.opsExceptionManage);

  // Dual control (WPS inward Activity 28 §9.4 point 8): on such an item Mark as Success can only be submitted for approval and
  // the other actions only executed, so the picker shows the one choice the server accepts.
  const forced = forcedNextAction(row.detail.requiresApproval, action);
  const effectiveNextAction: NextAction = forced ?? nextAction;

  // A pending dual-control Mark as Success is decided here by a holder of businessExceptionsApprove who did not submit it. The server
  // refuses the submitter with a 403 on its own; the buttons are only disabled for them.
  const username = useCurrentUsername();
  const awaitingApproval = row.exceptionStatus === 'Pending Approval' && row.detail.requiresApproval && !!onDecideApproval;
  const ownSubmission =
    !!row.detail.approvalSubmittedBy && row.detail.approvalSubmittedBy.toLowerCase() === username.toLowerCase();

  function submit() {
    if (!action || !comments.trim()) return;
    onSubmit({
      // The exception key, not the TransactionId: a transaction can carry several keys (one per park), and the decision must act on this one.
      transactionSystemIds: [row.id],
      action,
      nextAction: effectiveNextAction,
      comments: comments.trim(),
    });
  }

  function decide(approve: boolean) {
    if (!comments.trim() || !onDecideApproval) return;
    onDecideApproval(approve, { transactionSystemIds: [row.id], comments: comments.trim() });
  }

  const ownTitle = 'You submitted this request; another approver must decide it.';

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={resolvable ? 'Resolve Exception' : 'Exception Detail'}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="flex h-full w-full max-w-2xl sm:max-w-3xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div className="flex items-center gap-3">
            <span
              className="flex size-10 items-center justify-center rounded-lg text-xl border border-red-200 bg-red-50 text-red-600"
              aria-hidden="true"
            >
              ⚠
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold leading-none text-[var(--text-primary)]">
                  {resolvable ? 'Resolve Exception' : 'Exception Detail'}
                </h2>
                <span className={cn('inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase', STATUS_TONE[row.exceptionStatus])}>
                  {row.exceptionStatus}
                </span>
              </div>
              <p className="mt-1 font-mono text-xs text-[var(--text-muted)]">{row.transactionSystemId}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Informational Hint Banner */}
        <div className="flex items-center gap-2.5 border-b border-[var(--border)] bg-[#eff6ff] px-6 py-3 text-xs text-[#1e40af]">
          <span className="font-bold">ℹ</span>
          <span>
            {resolvable
              ? 'Select an operational action to apply to this stalled payment and determine if approval is required.'
              : 'Review the exception attributes, error context, and final execution remarks for this record.'}
          </span>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 space-y-4 overflow-y-auto p-6">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className="rounded px-2 py-0.5 text-[10px] font-bold uppercase text-white shadow-sm"
              style={{ background: RAIL_COLOR[row.rail] ?? 'var(--primary-blue)' }}
            >
              {row.rail}
            </span>
            <span className={cn('inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase', SEVERITY_TONE[row.severity])}>
              {row.severity}
            </span>
          </div>

          <CollapsibleCard title="Exception Summary" tone="blue" icon={<Info size={11} />} defaultOpen>
            <FieldGrid>
              <Field label="Transaction System ID" full mono>
                {row.transactionSystemId}
              </Field>
              <Field label="Exception Category" full>
                {row.exceptionCategory}
              </Field>
              <Field label="Occurred At">{formatInstant(row.occurredAt)}</Field>
              <Field label="Retry Count">{row.retryCount}</Field>
            </FieldGrid>
          </CollapsibleCard>

          <CollapsibleCard title="Exception Details" tone="red" icon={<TriangleAlert size={11} />} defaultOpen>
            <ErrorPanel code={row.errorCode} narrative={row.detail.errorNarrative} />
          </CollapsibleCard>

          <CollapsibleCard
            title="Transaction / Message Details"
            note={`(${row.detail.messageContext})`}
            tone="purple"
            icon={<FileText size={11} />}
          >
            <MessageFields fields={row.detail.referenceFields} />
          </CollapsibleCard>

          {resolvable ? (
            <>
              <CollapsibleCard
                title="Actions"
                note="(configurable per exception category)"
                tone="amber"
                icon={<Settings size={11} />}
                defaultOpen
              >
                <ActionPicker actions={row.detail.actions} selected={action} onSelect={setAction} />
              </CollapsibleCard>

              <CollapsibleCard title="Next Action" tone="teal" icon={<Play size={11} />} defaultOpen>
                <NextActionPicker value={effectiveNextAction} onChange={setNextAction} only={forced} />
                {forced === 'approval' && (
                  <p className="mt-2 text-[11px] text-[var(--text-muted)]">
                    Mark as Success on this item needs a second person's approval: submit it, and an approver decides it.
                  </p>
                )}
                <div className="mt-2.5">
                  <CommentsField value={comments} onChange={setComments} placeholder="Add comments or remarks (required)…" />
                </div>
              </CollapsibleCard>
            </>
          ) : awaitingApproval ? (
            <CollapsibleCard title="Approval" tone="teal" icon={<ShieldCheck size={11} />} defaultOpen>
              <FieldGrid>
                <Field label="Proposed Action">Mark as Success</Field>
                <Field label="Submitted By">{row.detail.approvalSubmittedBy ?? '—'}</Field>
              </FieldGrid>
              {row.detail.resolutionComments && (
                <p className="mt-3 rounded-md border border-[var(--border)] bg-[var(--bg-secondary)] px-2.5 py-2 text-xs leading-relaxed text-[var(--text-secondary)]">
                  {row.detail.resolutionComments}
                </p>
              )}
              <div className="mt-2.5">
                <CommentsField value={comments} onChange={setComments} placeholder="Add the approver's comments (required)…" />
              </div>
            </CollapsibleCard>
          ) : (
            <CollapsibleCard title="Latest Action Details" tone="teal" icon={<Play size={11} />} defaultOpen>
              {row.detail.latestAction ? (
                <FieldGrid>
                  <Field label="Action Taken">{row.detail.latestAction.action}</Field>
                  <Field label="Actioned By">{row.detail.latestAction.actionedBy}</Field>
                  <Field label="Actioned On" full>
                    {formatInstant(row.detail.latestAction.actionedOn)}
                  </Field>
                </FieldGrid>
              ) : (
                <p className="text-xs text-[var(--text-muted)]">
                  No operator action was recorded — this exception closed automatically.
                </p>
              )}
              {row.detail.resolutionComments && (
                <div className="mt-3 border-t border-[var(--border-light)] pt-3">
                  <div className="mb-1 text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                    Operator Comments
                  </div>
                  <p className="rounded-md border border-[var(--border)] bg-[var(--bg-secondary)] px-2.5 py-2 text-xs leading-relaxed text-[var(--text-secondary)]">
                    {row.detail.resolutionComments}
                  </p>
                </div>
              )}
            </CollapsibleCard>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <div>
            {resolvable && (
              <button
                type="button"
                onClick={() => {
                  setAction(row.detail.actions[0] ?? null);
                  setComments('');
                  setNextAction(defaultNextAction(row.detail.requiresApproval));
                }}
                disabled={submitting}
                className="btn-secondary large-btn !w-28 justify-center"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="btn-secondary large-btn !w-28 justify-center"
            >
              Close
            </button>
            {resolvable && (
              <button
                type="button"
                onClick={submit}
                disabled={submitting || !action || !comments.trim()}
                title={!comments.trim() ? 'Comments are required' : undefined}
                className="btn-primary large-btn !w-32 justify-center disabled:cursor-not-allowed disabled:opacity-50"
              >
                {submitting ? 'Submitting…' : 'Apply'}
              </button>
            )}
            {awaitingApproval && (
              <>
                <Can permission={PERM.businessExceptionsApprove}>
                  <button
                    type="button"
                    onClick={() => decide(false)}
                    disabled={submitting || ownSubmission || !comments.trim()}
                    title={ownSubmission ? ownTitle : !comments.trim() ? 'Comments are required' : undefined}
                    className="btn-secondary large-btn !w-40 justify-center disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Reject approval
                  </button>
                </Can>
                <Can permission={PERM.businessExceptionsApprove}>
                  <button
                    type="button"
                    onClick={() => decide(true)}
                    disabled={submitting || ownSubmission || !comments.trim()}
                    title={ownSubmission ? ownTitle : !comments.trim() ? 'Comments are required' : undefined}
                    className="btn-primary large-btn !w-32 justify-center disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? 'Submitting…' : 'Approve'}
                  </button>
                </Can>
              </>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}