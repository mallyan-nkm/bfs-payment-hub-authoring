import { Fragment, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Download, X } from 'lucide-react';
import { LoadingSpinner, cn } from '@paymenthub/ui';
import { businessExceptionsApi } from './api';
import type { AuditActivityStatus, AuditTrail, BusinessExceptionStatus } from './types';

const STATUS_TONE: Record<BusinessExceptionStatus, string> = {
  Open: 'border-blue-300 bg-blue-50 text-blue-700',
  'Pending Approval': 'border-amber-300 bg-amber-50 text-amber-700',
  Retrying: 'border-purple-300 bg-purple-50 text-purple-700',
  Resolved: 'border-green-300 bg-green-50 text-green-700',
  Closed: 'border-[var(--border)] bg-[var(--bg-secondary)] text-[var(--text-secondary)]',
};

const AUDIT_STATUS_TONE: Record<AuditActivityStatus, string> = {
  Success: 'border-green-300 bg-green-50 text-green-700',
  Failed: 'border-red-300 bg-red-50 text-red-700',
  Pending: 'border-amber-300 bg-amber-50 text-amber-700',
  Open: 'border-blue-300 bg-blue-50 text-blue-700',
  'In Progress': 'border-amber-300 bg-amber-50 text-amber-700',
};

const csvCell = (value: string) => `"${value.replace(/"/g, '""')}"`;

function downloadCsv(audit: AuditTrail) {
  const headers = ['Activity', 'Action By', 'Actioned Date & Time', 'Channel', 'Status', 'Remarks', 'More Details'];
  const rows = audit.activities.map((activity) =>
    [
      activity.activity,
      activity.actionBy,
      activity.actionedOn,
      activity.channel,
      activity.status,
      activity.remarks,
      activity.details
        ? Object.entries(activity.details)
            .map(([k, v]) => `${k}: ${v}`)
            .join(' | ')
        : '—',
    ]
      .map(csvCell)
      .join(','),
  );
  const blob = new Blob([[headers.map(csvCell).join(','), ...rows].join('\n')], {
    type: 'text/csv;charset=utf-8;',
  });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  // date-format-ok: file-name stamp, not a displayed date
  link.download = `audit-trail-${audit.reference}-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

const TH = 'px-3 py-2.5 text-left text-[14px] font-semibold uppercase tracking-wide text-[#4B5563] whitespace-nowrap';
const TD = 'px-3 py-2.5 text-[14px] text-[var(--text-secondary)] whitespace-nowrap';
const SECTION = 'input-label text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]';

function DetailRows({ details }: { details: Record<string, string> }) {
  return (
    <div className="flex flex-col gap-1.5 border-y border-[var(--border)] bg-[var(--bg-secondary)]/40 px-6 py-3">
      {Object.entries(details).map(([key, value]) => {
        const isError = key.toLowerCase().includes('error') || value.includes('FAILED') || value.includes('TIMEOUT');
        const isOk = ['SUCCESS', 'PASS', 'ACK Received'].includes(value);
        return (
          <div key={key} className="flex flex-wrap items-start gap-2.5 text-xs">
            <span className="min-w-32 shrink-0 input-label text-[10px] uppercase">
              {key}:
            </span>
            <span
              className={cn(
                'min-w-0 flex-1 break-all font-mono text-xs',
                isError && 'font-bold text-[var(--accent-red)]',
                isOk && 'font-bold text-[var(--accent-green)]',
                !isError && !isOk && 'text-[var(--text-secondary)] font-medium',
              )}
            >
              {value}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export function AuditTrailModal({
  transactionSystemId,
  onClose,
}: {
  transactionSystemId: string;
  onClose: () => void;
}) {
  const [expanded, setExpanded] = useState<Set<number>>(new Set());

  const auditQ = useQuery({
    queryKey: ['business-exception-audit', transactionSystemId],
    queryFn: () => businessExceptionsApi.auditTrail(transactionSystemId),
  });

  const audit = auditQ.data ?? null;

  const toggle = (index: number) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });

  return (
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={`Audit trail for ${transactionSystemId}`}
      onClick={onClose}
    >
      <div
        className="flex h-full w-full max-w-4xl sm:max-w-5xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div className="min-w-0">
            <h2 className="text-xl font-bold text-[var(--text-primary)]">Audit Trail</h2>
            <p className="mt-1 truncate font-mono text-xs text-[var(--text-muted)]">{transactionSystemId}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => audit && downloadCsv(audit)}
              disabled={!audit || audit.activities.length === 0}
              className="btn-secondary large-btn !py-1.5 !px-3 text-xs inline-flex items-center gap-1.5 disabled:cursor-not-allowed disabled:opacity-45"
            >
              <Download size={13} /> Download CSV
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close drawer"
              className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {auditQ.isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <LoadingSpinner />
            </div>
          ) : !audit ? (
            <div className="flex h-56 flex-col items-center justify-center gap-1.5 px-6 text-center text-xs text-[var(--text-muted)]">
              <p className="text-sm font-semibold text-[var(--text-primary)]">No audit trail available</p>
              <p>No recorded activity was found for {transactionSystemId}.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-6">
              {/* Summary Metadata Card */}
              <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm">
                <div className="border-b border-[var(--border)] bg-[var(--bg-secondary)]/40 px-5 py-3">
                  <p className={SECTION}>Transaction Context</p>
                </div>
                <div className="p-5">
                  <dl className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-3">
                    <div>
                      <dt className="input-label text-[10px] mb-1">Reference</dt>
                      <dd className="font-mono text-xs font-bold text-[var(--primary-blue)]">{audit.reference}</dd>
                    </div>
                    <div>
                      <dt className="input-label text-[10px] mb-1">Rail · Category</dt>
                      <dd className="text-xs font-semibold text-[var(--text-primary)]">{audit.transactionType}</dd>
                    </div>
                    <div>
                      <dt className="input-label text-[10px] mb-1">Status</dt>
                      <dd>
                        <span className={cn('inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase', STATUS_TONE[audit.status])}>
                          {audit.status}
                        </span>
                      </dd>
                    </div>
                  </dl>
                </div>
              </div>

              {/* Activities Grid */}
              <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm">
                <div className="border-b border-[var(--border)] bg-[var(--bg-secondary)] px-4 py-3">
                  <span className="text-[13px] font-semibold text-[var(--text-primary)]">Activities Timeline</span>
                  <span className="ml-2 text-xs text-[var(--text-muted)]">
                    ({audit.activities.length} activit{audit.activities.length === 1 ? 'y' : 'ies'})
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full min-w-max text-sm">
                    <thead>
                      <tr className="border-b border-[var(--border)] bg-[var(--bg-secondary)]/60">
                        <th className={TH}>Activity</th>
                        <th className={TH}>Action By</th>
                        <th className={TH}>Actioned Date & Time</th>
                        <th className={TH}>Channel</th>
                        <th className={TH}>Status</th>
                        <th className={TH}>Remarks</th>
                        <th className={cn(TH, 'text-center')}>More Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border-light)]">
                      {audit.activities.map((activity, index) => (
                        <Fragment key={`${activity.activity}-${activity.actionedOn}-${index}`}>
                          <tr className="odd:bg-[var(--bg-secondary)]/20 hover:bg-[var(--bg-card-hover)] transition-colors">
                            <td className={cn(TD, 'font-bold text-[var(--text-primary)]')}>
                              {activity.activity}
                            </td>
                            <td className={TD}>{activity.actionBy}</td>
                            <td className={cn(TD, 'font-mono text-xs')}>{activity.actionedOn}</td>
                            <td className={TD}>{activity.channel}</td>
                            <td className={TD}>
                              <span className={cn('inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase', AUDIT_STATUS_TONE[activity.status])}>
                                {activity.status}
                              </span>
                            </td>
                            <td className={cn(TD, 'max-w-[280px] whitespace-normal break-words text-xs text-[var(--text-muted)]')}>
                              {activity.remarks}
                            </td>
                            <td className={cn(TD, 'text-center')}>
                              {activity.details ? (
                                <button
                                  type="button"
                                  onClick={() => toggle(index)}
                                  className="btn-secondary !py-1 !px-2.5 text-[11px]"
                                >
                                  {expanded.has(index) ? 'Hide' : 'Details'}
                                </button>
                              ) : (
                                <span className="text-[var(--text-muted)]">—</span>
                              )}
                            </td>
                          </tr>
                          {activity.details && expanded.has(index) && (
                            <tr>
                              <td colSpan={7} className="p-0">
                                <DetailRows details={activity.details} />
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <span className="text-xs text-[var(--text-muted)] font-medium">
            {audit ? `${audit.activities.length} activities logged` : ''}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary large-btn !w-32 justify-center"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}