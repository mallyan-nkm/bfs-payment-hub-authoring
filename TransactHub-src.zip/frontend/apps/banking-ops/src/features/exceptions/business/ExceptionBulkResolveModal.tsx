import { useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { Play, Settings, TriangleAlert, X } from 'lucide-react';
import type { BusinessExceptionRow, NextAction, ResolveSubmission } from './types';
import { ActionPicker, CollapsibleCard, CommentsField, NextActionPicker, defaultNextAction, forcedNextAction } from './panelParts';

interface ExceptionBulkResolveModalProps {
  rows: BusinessExceptionRow[];
  onClose: () => void;
  onSubmit: (submission: ResolveSubmission) => void;
  submitting?: boolean;
}

export function ExceptionBulkResolveModal({ rows, onClose, onSubmit, submitting }: ExceptionBulkResolveModalProps) {
  // PM/FSD rule: a bulk action is only valid when every selected exception carries the exact same
  // classification — exceptionCategoryCode + exceptionTypeCode. Being in the same broad category
  // (e.g. all Business exceptions) is not sufficient; two different types within one category, or
  // the same type name under a different category, must both be blocked. Checked ahead of
  // sharedActions below because two *different* non-reversal types otherwise share an identical
  // action set and would slip through an actions-only check.
  const sameClassification = useMemo(() => {
    if (rows.length <= 1) return true;
    const [first, ...rest] = rows;
    return rest.every(
      (r) => r.exceptionCategoryCode === first.exceptionCategoryCode && r.exceptionTypeCode === first.exceptionTypeCode,
    );
  }, [rows]);

  const sharedActions = useMemo(() => {
    if (rows.length === 0 || !sameClassification) return [];
    return rows.map((r) => r.detail.actions).reduce((common, actions) => common.filter((a) => actions.includes(a)));
  }, [rows, sameClassification]);

  const [action, setAction] = useState<string | null>(sharedActions[0] ?? null);
  const anyRequiresApproval = rows.some((r) => r.detail.requiresApproval);
  const [nextAction, setNextAction] = useState<NextAction>(defaultNextAction(anyRequiresApproval));
  const [comments, setComments] = useState('');

  // Dual control (WPS inward Activity 28 §9.4 point 8, D-A28-22): the bulk modal sends `nextAction` too, so a batch of dual-control
  // items gets the same forced choice as the detail modal — Mark as Success for approval only, the others executed only. Any row
  // requiring approval forces it (the batch is one classification, so in practice all or none do).
  const forced = forcedNextAction(anyRequiresApproval, action);
  const effectiveNextAction: NextAction = forced ?? nextAction;

  function submit() {
    if (!action || !comments.trim()) return;
    onSubmit({
      transactionSystemIds: rows.map((r) => r.id),
      action,
      nextAction: effectiveNextAction,
      comments: comments.trim(),
    });
  }

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[10002] flex justify-end bg-black/50 transition-opacity"
      role="dialog"
      aria-modal="true"
      aria-label={`Bulk Resolve — ${rows.length} Records`}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="flex h-full w-full max-w-2xl sm:max-w-3xl flex-col border-l border-[var(--border)] bg-[var(--bg-card)] shadow-2xl transition-all rounded-tl-[40px] rounded-bl-[40px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--border)] p-6 bg-[var(--bg-secondary)]/50">
          <div>
            <h2 className="text-xl font-bold text-[var(--text-primary)]">
              Bulk Resolve — {rows.length} Record{rows.length === 1 ? '' : 's'}
            </h2>
            <p className="mt-1 text-xs text-[var(--text-muted)]">
              Apply a common operational action to all selected business exceptions
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close drawer"
            className="grid size-9 place-items-center rounded-full bg-[var(--bg-secondary)] text-[var(--text-muted)] transition-colors hover:bg-[var(--border)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Informational Hint Banner */}
        <div className="flex items-center gap-2.5 border-b border-[var(--border)] bg-[#eff6ff] px-6 py-3 text-xs text-[#1e40af]">
          <span className="font-bold">ℹ</span>
          <span>
            Only resolution actions common to all selected exception categories can be applied in batch.
          </span>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 space-y-4 overflow-y-auto p-6">
          <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-secondary)]/30 p-4">
            <div className="mb-2 input-label text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
              Selected Transactions ({rows.length})
            </div>
            <div className="flex max-h-28 flex-wrap gap-1.5 overflow-y-auto pr-1">
              {rows.map((row) => (
                <span
                  key={row.id}
                  className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)] px-2.5 py-1 font-mono text-[11px] font-bold text-[var(--primary-blue)] shadow-xs"
                >
                  {row.transactionSystemId}
                </span>
              ))}
            </div>
          </div>

          {!sameClassification ? (
            <div className="flex items-start gap-2.5 rounded-xl border border-amber-300 bg-amber-50 p-4 text-xs leading-relaxed text-amber-900 shadow-xs">
              <TriangleAlert size={16} className="mt-0.5 shrink-0 text-amber-600" />
              <p>
                The selected exceptions belong to different exception classifications. Select exceptions of the exact
                same category and type to resolve them together.
              </p>
            </div>
          ) : sharedActions.length === 0 ? (
            <div className="flex items-start gap-2.5 rounded-xl border border-amber-300 bg-amber-50 p-4 text-xs leading-relaxed text-amber-900 shadow-xs">
              <TriangleAlert size={16} className="mt-0.5 shrink-0 text-amber-600" />
              <p>
                The selected exceptions have no resolution action in common. Select exceptions of a single category
                to resolve them together.
              </p>
            </div>
          ) : (
            <>
              <CollapsibleCard title="Actions" note="(applied to all selected records)" tone="amber" icon={<Settings size={11} />} defaultOpen>
                <ActionPicker actions={sharedActions} selected={action} onSelect={setAction} />
              </CollapsibleCard>

              <CollapsibleCard title="Next Action" tone="teal" icon={<Play size={11} />} defaultOpen>
                <NextActionPicker value={effectiveNextAction} onChange={setNextAction} only={forced} />
                <div className="mt-2.5">
                  <CommentsField
                    value={comments}
                    onChange={setComments}
                    placeholder="Add comments or remarks for all selected records (required)…"
                  />
                </div>
              </CollapsibleCard>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-[var(--border)] p-6 bg-[var(--bg-card)]">
          <div>
            {sharedActions.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setAction(sharedActions[0] ?? null);
                  setComments('');
                  setNextAction(defaultNextAction(anyRequiresApproval));
                }}
                disabled={submitting}
                className="btn-secondary large-btn !w-28 justify-center"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="btn-secondary large-btn !w-28 justify-center"
            >
              Close
            </button>
            {sharedActions.length > 0 && (
              <button
                type="button"
                onClick={submit}
                disabled={submitting || !action || !comments.trim()}
                title={!comments.trim() ? 'Comments are required' : undefined}
                className="btn-primary large-btn !w-36 justify-center disabled:cursor-not-allowed disabled:opacity-50"
              >
                {submitting ? 'Submitting…' : 'Apply to All'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}