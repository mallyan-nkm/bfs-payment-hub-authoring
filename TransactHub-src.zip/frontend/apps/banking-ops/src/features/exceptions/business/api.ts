import { bankingApi } from '../../../shared/api/bankingApi';
import type { PaginatedResponse } from '@paymenthub/ui';
import { toUtcRangeParams } from '@paymenthub/ui';
import type {
  ApprovalDecision,
  AuditActivity,
  AuditActivityStatus,
  AuditTrail,
  BusinessExceptionRow,
  BusinessExceptionStatus,
  ExceptionSeverityLevel,
  ReferenceField,
  ResolveSubmission,
} from './types';

/**
 * Business Exception Management data access — GET/POST /api/ops/business-exceptions
 * (PaymentHub.Operations.API, backed by platform.PaymentException +
 * platform.ExceptionClassification; see BusinessExceptionManagementEndpoints.cs).
 *
 * `list()` is a real server-side filtered/sorted/paginated query — the backend
 * already supports category, rail, status, severity, date-range, full-text
 * search and sort — matching how every other list screen in this app
 * (TransactionSearchPage, MyTasksPage, QueuePage) drives its `DataTable` off a
 * server query rather than fetching everything and filtering client-side.
 *
 * The list endpoint already returns full detail-level rows (`PaymentExceptionDetailDto`,
 * the same shape the `/detail` endpoint returns), so one list call is enough to
 * populate both the grid and the resolve/history sheet — no per-row detail fetch.
 *
 * `scope=history` alone applies no status filter server-side (the backend only
 * defaults a status filter for `scope=active`), so history explicitly asks for
 * `RESOLVED`/`CLOSED` rows unless the caller narrows it further.
 *
 * `IN_PROGRESS` is only ever reached via the "submit for approval" path, so it
 * maps to `Pending Approval` below. `resubmit` (reopening a rejected item) has
 * no reachable trigger without a rejected state, so it is not wired here.
 *
 * The checker endpoints `/approvals/approve` and `/approvals/reject` exist for the
 * dual-control items only (`requiresApproval`: Mark as Success on an RFA reversal
 * item, WPS inward Activity 28). They are gated on `businessExceptionsApprove`, not on
 * `opsExceptionManage`, and the server refuses the person who submitted the item.
 */

const BASE = '/ops/business-exceptions';

export interface BusinessExceptionListParams {
  scope: 'active' | 'history';
  page: number;
  pageSize: number;
  search?: string;
  /** Single rail code — the backend's `railCode` filter takes one value, not an array. */
  rail?: string;
  /** Exact category code (from `categories()`) — the backend has no free-text category filter. */
  exceptionCategoryCode?: string;
  statusCodes?: BusinessExceptionStatus[];
  /** Single severity — the backend's `severityCode` filter takes one value, not an array. */
  severity?: ExceptionSeverityLevel;
  occurredFrom?: string;
  occurredTo?: string;
  /** Backend filters `RetryCount >= minRetryCount` — a lower-bound, not an exact match. */
  minRetryCount?: number;
  /** One of the grid's sortable columns — see SORT_COLUMN_MAP below. */
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
}

interface PaymentExceptionDetailDto {
  exceptionKey: string;
  exceptionVersion: number;
  transactionId?: string | null;
  transactionReference?: string | null;
  externalReference?: string | null;
  workflowId?: string | null;
  correlationId?: string | null;
  requestId?: string | null;
  railCode: string;
  exceptionCategoryCode: string;
  categoryName: string;
  exceptionTypeCode: string;
  exceptionTypeName: string;
  severityCode: string;
  errorCode?: string | null;
  errorMessage?: string | null;
  errorDetails?: string | null;
  statusCode: string;
  retryCount: number;
  occurredAt?: string | null;
  resolutionComments?: string | null;
  resolvedBy?: string | null;
  additionalData?: string | null;
  /** Resolution actions the server allows for this exception. */
  availableActions?: string[];
  resolutionCode?: string | null;
  changedBy?: string | null;
  /** Mark as Success on this exception needs a second person's approval (the dual-control set). */
  requiresApproval?: boolean;
}

interface BusinessExceptionListResponseDto {
  exceptions: PaymentExceptionDetailDto[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
}

export interface ExceptionCategoryOption {
  categoryCode: string;
  categoryName: string;
}

interface ExceptionAuditActivityDto {
  exceptionKey: string;
  version: number;
  railCode: string;
  categoryName: string;
  exceptionTypeName: string;
  errorCode?: string | null;
  errorMessage?: string | null;
  eventType: string;
  previousStatusCode?: string | null;
  statusCode: string;
  retryCount: number;
  occurredAt?: string | null;
  resolutionCode?: string | null;
  resolvedBy?: string | null;
  changedBy?: string | null;
  changeSource?: string | null;
}

const STATUS_MAP: Record<string, BusinessExceptionStatus> = {
  OPEN: 'Open',
  IN_PROGRESS: 'Pending Approval',
  RETRYING: 'Retrying',
  RESOLVED: 'Resolved',
  CLOSED: 'Closed',
};

const STATUS_CODE: Record<BusinessExceptionStatus, string> = {
  Open: 'OPEN',
  'Pending Approval': 'IN_PROGRESS',
  Retrying: 'RETRYING',
  Resolved: 'RESOLVED',
  Closed: 'CLOSED',
};

function mapStatus(statusCode?: string | null): BusinessExceptionStatus {
  if (!statusCode) return 'Open';
  return STATUS_MAP[statusCode.toUpperCase()] ?? 'Open';
}

const AUDIT_STATUS_BY_ROW_STATUS: Record<BusinessExceptionStatus, AuditActivityStatus> = {
  Open: 'Open',
  'Pending Approval': 'Pending',
  Retrying: 'In Progress',
  Resolved: 'Success',
  Closed: 'Success',
};

const SEVERITY_MAP: Record<string, ExceptionSeverityLevel> = {
  CRITICAL: 'Critical',
  HIGH: 'High',
  MEDIUM: 'Medium',
  LOW: 'Low',
};

const SEVERITY_CODE: Record<ExceptionSeverityLevel, string> = {
  Critical: 'CRITICAL',
  High: 'HIGH',
  Medium: 'MEDIUM',
  Low: 'LOW',
};

function mapSeverity(severityCode?: string | null): ExceptionSeverityLevel {
  if (!severityCode) return 'Medium';
  return SEVERITY_MAP[severityCode.toUpperCase()] ?? 'Medium';
}

/** Grid sort-column key → the backend's AllowedSortColumns; unlisted keys aren't sortable. */
const SORT_COLUMN_MAP: Record<string, string> = {
  transactionSystemId: 'ExceptionKey',
  rail: 'RailCode',
  occurredAt: 'OccurredAt',
  severity: 'SeverityCode',
  exceptionStatus: 'StatusCode',
  retryCount: 'RetryCount',
};

/** The fallback when the server sends no list (an older Operations API). */
const DEFAULT_EXCEPTION_ACTIONS = ['Retry', 'Mark as Success', 'Mark as Failure'];

/** The actions the server allows for this exception (BusinessExceptionManagementConstants.ActionsFor):
 * Retry is left out when the exception's workflow has ended, as there is no step left to re-run. */
function actionsFor(dto: Pick<PaymentExceptionDetailDto, 'availableActions'>): string[] {
  return dto.availableActions && dto.availableActions.length > 0 ? dto.availableActions : DEFAULT_EXCEPTION_ACTIONS;
}

function tryParseJson(value?: string | null): Record<string, unknown> | undefined {
  if (!value) return undefined;
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : undefined;
  } catch {
    return undefined;
  }
}

/** Soft-reference ids and any parsed AdditionalData — only fields the record actually carries. */
function referenceFieldsFor(dto: PaymentExceptionDetailDto): ReferenceField[] {
  const fields: ReferenceField[] = [];
  const add = (label: string, value?: string | null) => {
    if (value) fields.push({ label, value, mono: true });
  };
  add('Transaction Reference', dto.transactionReference);
  add('External Reference', dto.externalReference);
  add('Workflow ID', dto.workflowId);
  add('Correlation ID', dto.correlationId);
  add('Request ID', dto.requestId);
  const extra = tryParseJson(dto.additionalData);
  if (extra) {
    for (const [key, value] of Object.entries(extra)) {
      fields.push({ label: key, value: String(value) });
    }
  }
  return fields;
}

function mapRow(dto: PaymentExceptionDetailDto): BusinessExceptionRow {
  const errorNarrative = [dto.errorMessage, dto.errorDetails].filter(Boolean).join(' — ') || 'No error details recorded.';

  return {
    id: dto.exceptionKey,
    transactionSystemId: dto.transactionId ?? dto.exceptionKey,
    rail: dto.railCode,
    occurredAt: dto.occurredAt ?? '',
    exceptionCategory: dto.categoryName,
    exceptionCategoryCode: dto.exceptionCategoryCode,
    exceptionTypeCode: dto.exceptionTypeCode,
    errorCode: dto.errorCode ?? '—',
    errorDescription: dto.errorMessage ?? '—',
    severity: mapSeverity(dto.severityCode),
    exceptionStatus: mapStatus(dto.statusCode),
    retryCount: dto.retryCount,
    detail: {
      errorNarrative,
      messageContext: `${dto.railCode} · ${dto.exceptionTypeName}`,
      referenceFields: referenceFieldsFor(dto),
      actions: actionsFor(dto),
      resolutionComments: dto.resolutionComments ?? undefined,
      latestAction: dto.resolvedBy
        ? { action: dto.categoryName, actionedBy: dto.resolvedBy, actionedOn: dto.occurredAt ?? '' }
        : undefined,
      requiresApproval: dto.requiresApproval ?? false,
      approvalSubmittedBy:
        dto.statusCode?.toUpperCase() === 'IN_PROGRESS' && dto.resolutionCode?.toUpperCase() === 'PENDING_APPROVAL'
          ? (dto.changedBy ?? undefined)
          : undefined,
    },
  };
}

/** Humanises an EventType the mapping below doesn't special-case, e.g. "SOME_EVENT" → "Some Event". */
function humanize(code: string): string {
  return code
    .toLowerCase()
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

const EVENT_LABEL: Record<string, string> = {
  RESOLVED: 'Resolved',
  RETRY_INITIATED: 'Retry Initiated',
  STATUS_CHANGED: 'Submitted for Approval',
};

function mapHistoryActivity(row: ExceptionAuditActivityDto): AuditActivity {
  const status = mapStatus(row.statusCode);
  const remarks =
    row.errorMessage ??
    `Status changed from ${humanize(row.previousStatusCode ?? row.statusCode)} to ${humanize(row.statusCode)}` +
      (row.resolutionCode ? ` (${humanize(row.resolutionCode)})` : '');

  const details: Record<string, string> = {};
  if (row.errorCode) details['Error Code'] = row.errorCode;
  if (row.resolutionCode) details['Resolution Code'] = row.resolutionCode;
  details['Retry Count'] = String(row.retryCount);

  return {
    activity: EVENT_LABEL[row.eventType?.toUpperCase()] ?? humanize(row.eventType ?? 'Event'),
    actionBy: row.changedBy ?? row.resolvedBy ?? 'System',
    actionedOn: row.occurredAt ?? '',
    channel: row.changeSource ?? '—',
    status: AUDIT_STATUS_BY_ROW_STATUS[status],
    remarks,
    details: Object.keys(details).length > 0 ? details : undefined,
  };
}

function mapHistory(rows: ExceptionAuditActivityDto[]): AuditTrail | null {
  if (rows.length === 0) return null;
  const latest = rows[rows.length - 1];
  return {
    reference: latest.exceptionKey,
    transactionType: `${latest.railCode} · ${latest.categoryName}`,
    status: mapStatus(latest.statusCode),
    activities: rows.map(mapHistoryActivity),
  };
}

/** The list filters as the backend names them. Shared by the list and the export, so a file always
 *  covers exactly the rows the grid is filtered to. */
function toFilterQuery(params: BusinessExceptionListParams): Record<string, unknown> {
  const statusCodes =
    params.statusCodes && params.statusCodes.length > 0
      ? params.statusCodes.map((s) => STATUS_CODE[s])
      : params.scope === 'history'
        ? ['RESOLVED', 'CLOSED']
        : undefined;

  // Session-zone days as UTC [from, to); the server compares OccurredAt < to (UTC date-time T-22).
  const occurred = toUtcRangeParams(params.occurredFrom, params.occurredTo);

  return {
    scope: params.scope,
    searchQuery: params.search || undefined,
    railCode: params.rail || undefined,
    exceptionCategoryCode: params.exceptionCategoryCode || undefined,
    statusCodes,
    severityCode: params.severity ? SEVERITY_CODE[params.severity] : undefined,
    occurredFrom: occurred.from,
    occurredTo: occurred.to,
    minRetryCount: params.minRetryCount,
    sortColumn: params.sortBy ? SORT_COLUMN_MAP[params.sortBy] : undefined,
    // Direction only travels with a column. Sent alone, it would override the backend's
    // OccurredAt DESC default and list the oldest exceptions first.
    sortDescending: params.sortBy && params.sortDir ? params.sortDir === 'desc' : undefined,
  };
}

export type BusinessExceptionExportFormat = 'csv' | 'excel' | 'pdf';

export const businessExceptionsApi = {
  list: async (params: BusinessExceptionListParams): Promise<PaginatedResponse<BusinessExceptionRow>> => {
    const query: Record<string, unknown> = {
      ...toFilterQuery(params),
      pageNumber: params.page,
      pageSize: params.pageSize,
    };

    const res = await bankingApi.get<BusinessExceptionListResponseDto>(BASE, { params: query });
    const { exceptions, totalCount, pageNumber, pageSize } = res.data;
    return {
      items: exceptions.map(mapRow),
      total: totalCount,
      page: pageNumber,
      pageSize,
      totalPages: pageSize > 0 ? Math.ceil(totalCount / pageSize) : 0,
    };
  },

  /**
   * Server-rendered export of the whole filtered set — GET /export/{format}, gated on the page key
   * AND `ops:report:export`. Replaced a browser-built CSV that the export key could not refuse.
   * `X-Export-Truncated` comes back when the row cap was hit, so the caller can say so.
   */
  export: async (
    format: BusinessExceptionExportFormat,
    params: BusinessExceptionListParams,
    visibleColumns: string[],
  ): Promise<{ blob: Blob; truncated: boolean }> => {
    const res = await bankingApi.get<Blob>(`${BASE}/export/${format}`, {
      params: { ...toFilterQuery(params), columns: visibleColumns.join(',') },
      responseType: 'blob',
    });

    return {
      blob: res.data,
      truncated: String(res.headers['x-export-truncated'] ?? '').toLowerCase() === 'true',
    };
  },

  auditTrail: async (transactionSystemId: string): Promise<AuditTrail | null> => {
    const res = await bankingApi.get<ExceptionAuditActivityDto[]>(`${BASE}/${transactionSystemId}/history`);
    return mapHistory(res.data);
  },

  resolve: async (submission: ResolveSubmission): Promise<{ accepted: number }> => {
    const res = await bankingApi.post<{ accepted: number }>(`${BASE}/resolve`, submission);
    return res.data;
  },

  /** The checker approves a proposed Mark as Success — POST /approvals/approve (page key AND businessExceptionsApprove). */
  approve: async (decision: ApprovalDecision): Promise<{ accepted: number }> => {
    const res = await bankingApi.post<{ accepted: number }>(`${BASE}/approvals/approve`, decision);
    return res.data;
  },

  /** The checker rejects a proposed Mark as Success — POST /approvals/reject; the item returns to Open. */
  rejectApproval: async (decision: ApprovalDecision): Promise<{ accepted: number }> => {
    const res = await bankingApi.post<{ accepted: number }>(`${BASE}/approvals/reject`, decision);
    return res.data;
  },

  /** Master data for the category filter — GET /categories, business exceptions only. */
  categories: async (): Promise<ExceptionCategoryOption[]> => {
    const res = await bankingApi.get<ExceptionCategoryOption[]>(`${BASE}/categories`);
    return res.data;
  },
};
