import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PageBody, PageShell, SmartGrid, cn, parseMultiFilter, usePermissions } from '@paymenthub/ui';
import type { SmartGridColumn, SmartGridQueryChange } from '@paymenthub/ui';
import { Toast } from '../../../shared/components/Toast';
import type { ToastState } from '../../../shared/components/Toast';
import { PERM } from '../../../shared/auth/permissionKeys';
import { businessExceptionsApi } from './api';
import type { BusinessExceptionExportFormat, BusinessExceptionListParams } from './api';
import type { ApprovalDecision, BusinessExceptionRow, BusinessExceptionStatus, ExceptionSeverityLevel, ResolveSubmission } from './types';
import { ExceptionDetailModal } from './ExceptionDetailModal';
import { ExceptionBulkResolveModal } from './ExceptionBulkResolveModal';
import { AuditTrailModal } from './AuditTrailModal';

type Scope = 'active' | 'history';

interface Query {
  page: number;
  pageSize: number;
  filters: Record<string, string>;
  sortBy: string | null;
  sortDir: 'asc' | 'desc';
}

/** Newest first: in a queue, the latest exception is the one an operator is being paged about. */
const EMPTY_QUERY: Query = { page: 1, pageSize: 10, filters: {}, sortBy: 'occurredAt', sortDir: 'desc' };

const RAIL_FILTER_OPTIONS = ['WPS', 'IPI', 'UAEFTS', 'FTS', 'IPP', 'SWIFT'];
const SEVERITY_FILTER_OPTIONS: ExceptionSeverityLevel[] = ['Critical', 'High', 'Medium', 'Low'];
const ACTIVE_STATUS_VALUES: BusinessExceptionStatus[] = ['Open', 'Pending Approval', 'Retrying'];
const HISTORY_STATUS_VALUES: BusinessExceptionStatus[] = ['Resolved', 'Closed'];

const RAIL_COLOR: Record<string, string> = {
  WPS: '#16a34a',
  IPI: '#9333ea',
  UAEFTS: '#0891b2',
  FTS: '#0891b2',
  IPP: '#d97706',
  SWIFT: '#2563eb',
};

const STATUS_TONE: Record<BusinessExceptionStatus, string> = {
  Open: 'status-badge',
  'Pending Approval': 'status-badge warn',
  Retrying: 'status-badge blue',
  Resolved: 'status-success',
  Closed: 'status-badge success',
};

const SEVERITY_TONE: Record<ExceptionSeverityLevel, string> = {
  Critical: 'bg-[var(--accent-red)]/15 text-[var(--accent-red)]',
  High: 'bg-[var(--accent-amber)]/15 text-[var(--accent-amber)]',
  Medium: 'bg-[var(--accent-green)]/15 text-[var(--accent-green)]',
  Low: 'bg-[var(--text-muted)]/15 text-[var(--text-muted)]',
};

function isResolvable(row: BusinessExceptionRow): boolean {
  return row.exceptionStatus === 'Open' || row.exceptionStatus === 'Retrying';
}

/**
 * Business Exception Management — the operator queue for payments that stalled
 * on a business step (core-banking callback, suspense/nostro posting, reversal)
 * and need a human decision.
 *
 * Grid mechanics (column filters/sort/reorder, pagination, toolbar) now come from the shared
 * `SmartGrid` primitive in `@paymenthub/ui` — this page owns only the business logic: the
 * server-driven query state SmartGrid delegates to, the real `businessExceptionsApi.list()`
 * query, row selection for bulk-resolve, and the row/bulk popups. Previously this was a third,
 * independent hand-rolled copy of the same chrome `SifSummaryReportPage`/`ChargeConfigPage`/
 * Routing Configurations each built separately — that duplication is gone.
 */
export function BusinessExceptionManagementPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [activeTab, setActiveTab] = useState<Scope>('active');
  const [query, setQuery] = useState<Query>(EMPTY_QUERY);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [detailRow, setDetailRow] = useState<BusinessExceptionRow | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [auditFor, setAuditFor] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);
  const { can } = usePermissions();
  const canExport = can(PERM.opsReportExport);
  // /resolve and /resubmit sit on a group requiring the page key AND ops:exception:manage.
  const canManage = can(PERM.opsExceptionManage);

  const listParams: BusinessExceptionListParams = useMemo(() => {
    const f = query.filters;
    // Exception Status is a multiSelect filter (Common Grid Features spec §2: dropdown filters
    // allow one or more values) — the backend's `statusCodes` param already accepts an array, so
    // no fan-out call is needed; every checked status is sent in one request.
    const statusValues = parseMultiFilter(f.exceptionStatus) as BusinessExceptionStatus[];
    const retryCountFilter = f.retryCount?.trim();
    // The backend has one full-text `searchQuery` param (it already ORs across TransactionId,
    // ErrorCode, ErrorMessage, ExternalReference, ExceptionKey) — no dedicated per-column filter
    // for Error Code / Error Description. All three "search-like" filter cells feed this same
    // param; if more than one is filled, Transaction System ID wins, then Error Code, then Error
    // Description, since operators searching one of these rarely fill more than one at a time.
    const search = f.search?.trim() || f.errorCode?.trim() || f.errorDescription?.trim() || undefined;

    return {
      scope: activeTab,
      page: query.page,
      pageSize: query.pageSize,
      search,
      rail: f.rail?.trim() || undefined,
      exceptionCategoryCode: f.category?.trim() || undefined,
      statusCodes: statusValues.length > 0 ? statusValues : undefined,
      severity: (f.severity?.trim() as ExceptionSeverityLevel) || undefined,
      occurredFrom: f.occurredFrom || undefined,
      occurredTo: f.occurredTo || undefined,
      minRetryCount: retryCountFilter ? Number(retryCountFilter) : undefined,
      sortBy: query.sortBy ?? undefined,
      sortDir: query.sortDir,
    };
  }, [activeTab, query]);

  const categoriesQuery = useQuery({
    queryKey: ['business-exceptions', 'categories'],
    queryFn: () => businessExceptionsApi.categories(),
    staleTime: 5 * 60 * 1000,
  });
  const categoryOptions = (categoriesQuery.data ?? []).map((c) => ({ value: c.categoryCode, label: c.categoryName }));

  const listQuery = useQuery({
    queryKey: ['business-exceptions', 'list', listParams],
    queryFn: () => businessExceptionsApi.list(listParams),
  });

  const rows = listQuery.data?.items ?? [];
  const totalRecords = listQuery.data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalRecords / query.pageSize));

  // Filtering, sorting, or switching tabs can shrink the result set below the page an operator
  // was sitting on — SmartGrid's server mode trusts the caller to clamp this itself. Without it,
  // the query keeps requesting an out-of-range pageNumber and the grid shows "No exceptions match
  // the current filters" even though matches exist elsewhere.
  useEffect(() => {
    if (query.page > totalPages) setQuery((q) => ({ ...q, page: 1 }));
  }, [query.page, totalPages]);

  const selectedRows = useMemo(() => rows.filter((r) => selectedIds.has(r.id)), [rows, selectedIds]);

  // Prune any selected id no longer on the current page — otherwise navigating pages, filtering,
  // or sorting leaves a stale "Resolve (N)" count whose bulk modal opens with zero rows, since
  // `selectedRows` only ever matches against whatever the latest query actually returned.
  useEffect(() => {
    setSelectedIds((prev) => {
      if (prev.size === 0) return prev;
      const visibleIds = new Set(rows.map((r) => r.id));
      const next = new Set([...prev].filter((id) => visibleIds.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [rows]);

  function handleQueryChange(change: SmartGridQueryChange) {
    setQuery((prev) => ({
      page: change.page ?? prev.page,
      pageSize: change.pageSize ?? prev.pageSize,
      filters: change.filters ?? prev.filters,
      sortBy: change.sortBy !== undefined ? change.sortBy : prev.sortBy,
      sortDir: change.sortDir ?? prev.sortDir,
    }));
  }

  function switchTab(tab: Scope) {
    setActiveTab(tab);
    setQuery((q) => ({ ...q, filters: {}, page: 1 }));
    setSelectedIds(new Set());
  }

  function toggleRow(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function settle(message: string) {
    setToast({ tone: 'success', message });
    setDetailRow(null);
    setBulkOpen(false);
    setSelectedIds(new Set());
    queryClient.invalidateQueries({ queryKey: ['business-exceptions'] });
  }

  const resolveMutation = useMutation({
    mutationFn: (submission: ResolveSubmission) => businessExceptionsApi.resolve(submission),
    onSuccess: (result, submission) => {
      const executed = submission.nextAction === 'execute';
      const label = executed ? 'executed' : 'submitted for approval';
      settle(
        result.accepted > 1
          ? `"${submission.action}" ${label} for ${result.accepted} exceptions.`
          : `"${submission.action}" ${label} for ${submission.transactionSystemIds[0]}.`,
      );
    },
    // The server's reason when it refused the request (e.g. Retry on an exception whose workflow has
    // ended), otherwise a generic message.
    onError: (error: unknown) => {
      const detail = (error as { response?: { data?: { detail?: string | null } } })?.response?.data?.detail;
      setToast({ tone: 'error', message: detail || 'Could not submit the request. Please retry.' });
    },
  });

  // The checker's decision on a pending dual-control Mark as Success (POST /approvals/approve | /reject). The server refuses the
  // submitter (403) and an approval no run can apply (409); its reason is shown as for /resolve.
  const approvalMutation = useMutation({
    mutationFn: ({ approve, decision }: { approve: boolean; decision: ApprovalDecision }) =>
      approve ? businessExceptionsApi.approve(decision) : businessExceptionsApi.rejectApproval(decision),
    onSuccess: (_result, { approve, decision }) => {
      settle(`Mark as Success ${approve ? 'approved' : 'approval rejected'} for ${decision.transactionSystemIds[0]}.`);
    },
    onError: (error: unknown) => {
      const detail = (error as { response?: { data?: { detail?: string | null } } })?.response?.data?.detail;
      setToast({ tone: 'error', message: detail || 'Could not record the approval decision. Please retry.' });
    },
  });

  /**
   * Exports every row matching the current filters, server-side, in the chosen format.
   *
   * This used to page the list endpoint from the browser and assemble the CSV here, which meant
   * `ops:report:export` was checked nowhere — the only thing a server could refuse was the list
   * read behind the page key, and re-enabling the button produced the file. The server export is
   * gated on the page key AND the export key, and renders genuine .xlsx/.pdf as well as CSV.
   * `columns` carries the visible column keys so the file matches the screen.
   */
  const handleExport = async (format: BusinessExceptionExportFormat): Promise<Blob> => {
    const visibleColumns = columns.filter((c) => c.key !== 'actions').map((c) => c.key);
    const { blob, truncated } = await businessExceptionsApi.export(format, listParams, visibleColumns);

    if (truncated) {
      setToast({
        tone: 'error',
        message: 'The export hit its row limit and is incomplete — narrow the filters to export the remaining records.',
      });
    }

    return blob;
  };

  const columns: SmartGridColumn<BusinessExceptionRow>[] = [
    {
      key: 'transactionSystemId',
      label: 'Transaction System ID',
      filterKey: 'search',
      sortKey: 'transactionSystemId',
      render: (r) => <span className="font-mono text-xs font-semibold text-[var(--primary-blue)]">{r.transactionSystemId}</span>,
    },
    {
      key: 'rail',
      label: 'Rail',
      filterKey: 'rail',
      filterType: 'select',
      filterOptions: RAIL_FILTER_OPTIONS,
      sortKey: 'rail',
      render: (r) => (
        <span className="rounded px-1.5 py-0.5 text-[10px] font-bold uppercase text-white" style={{ background: RAIL_COLOR[r.rail] ?? 'var(--primary-blue)' }}>
          {r.rail}
        </span>
      ),
    },
    {
      key: 'occurredAt',
      label: 'Occurred At',
      filterKey: 'occurred',
      filterType: 'dateRange',
      sortKey: 'occurredAt',
      kind: 'instant',
    },
    {
      key: 'exceptionCategory',
      label: 'Exception Category',
      filterKey: 'category',
      filterType: 'select',
      filterOptions: categoryOptions,
      localSortKey: 'exceptionCategory',
    },
    {
      key: 'errorCode',
      label: 'Error Code',
      filterKey: 'errorCode',
      localSortKey: 'errorCode',
      render: (r) => <span className="font-mono text-xs">{r.errorCode}</span>,
    },
    {
      key: 'errorDescription',
      label: 'Error Description',
      filterKey: 'errorDescription',
      localSortKey: 'errorDescription',
      // truncate (overflow-hidden + text-ellipsis) is load-bearing, not cosmetic: `max-w` alone
      // only bounds the box, not its content, so without it a long description overflows into
      // Severity/Exception Status/Retry Count/Actions. `title` restores the untruncated text on hover.
      render: (r) => (
        <span className="block max-w-[260px] truncate text-[var(--text-muted)]" title={r.errorDescription}>
          {r.errorDescription}
        </span>
      ),
    },
    {
      key: 'severity',
      label: 'Severity',
      filterKey: 'severity',
      filterType: 'select',
      filterOptions: SEVERITY_FILTER_OPTIONS,
      sortKey: 'severity',
      render: (r) => <span className={cn('rounded-full px-2 py-0.5 text-[11px] font-semibold', SEVERITY_TONE[r.severity])}>{r.severity}</span>,
    },
    {
      key: 'exceptionStatus',
      label: 'Exception Status',
      filterKey: 'exceptionStatus',
      filterType: 'multiSelect',
      filterOptions: activeTab === 'active' ? ACTIVE_STATUS_VALUES : HISTORY_STATUS_VALUES,
      sortKey: 'exceptionStatus',
      render: (r) => <span className={cn('rounded-full px-2 py-0.5 text-[11px] font-semibold', STATUS_TONE[r.exceptionStatus])}>{r.exceptionStatus}</span>,
    },
    {
      key: 'retryCount',
      label: 'Retry Count',
      filterKey: 'retryCount',
      filterType: 'number',
      sortKey: 'retryCount',
      align: 'left',
    },
    {
      key: 'actions',
      label: 'Actions',
      locked: true,
      render: (r) => (
        <div className="flex flex-nowrap items-center gap-1">
          {/* Without ops:exception:manage the row opens read-only: /resolve would refuse it. */}
          {isResolvable(r) && canManage ? (
            <button
              onClick={() => setDetailRow(r)}
              className="btn-secondary whitespace-nowrap"
            >
              Resolve
            </button>
          ) : (
            <button
              onClick={() => setDetailRow(r)}
              className="btn-secondary whitespace-nowrap"
            >
              View Details
            </button>
          )}
          <button
            onClick={() => setAuditFor(r.transactionSystemId)}
            className="btn-tertiary whitespace-nowrap"
          >
            Audit Trail
          </button>
        </div>
      ),
    },
  ];

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / Operations / '}
              <span className="text-[var(--text-secondary)]">Business Exception Management</span>
            </p>
          </div>

          {/* Title Header */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                Business Exception Management
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Payments held on a business step — retry, record an outcome, or route for approval
              </p>
            </div>
          </div>

          {/* Scope Selection Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {(
              [
                { key: 'active' as Scope, label: 'Active Exceptions' },
                { key: 'history' as Scope, label: 'Exception History' },
              ]
            ).map((t) => (
              <button
                key={t.key}
                onClick={() => switchTab(t.key)}
                className={cn(
                  'common-pill',
                  activeTab === t.key
                    ? 'active-pill'
                    : '',
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          <SmartGrid<BusinessExceptionRow>
            columns={columns}
            rows={rows}
            getRowId={(r) => r.id}
            storageKey="business-exceptions-columns-v1"
            loading={listQuery.isLoading}
            emptyMessage="No exceptions match the current filters."
            exportFilename={`business-exceptions-${activeTab}`}
            // Hidden without the export key, as on the technical queue — the server refuses it anyway.
            onExport={canExport ? handleExport : undefined}
            exportFormats={canExport ? ['csv', 'excel', 'pdf'] : []}
            // Selection exists only to bulk-resolve, so it goes with the manage key.
            selectable={activeTab === 'active' && canManage}
            selectedIds={selectedIds}
            onToggleSelect={toggleRow}
            isRowSelectable={isResolvable}
            toolbarExtra={
              activeTab === 'active' && canManage && selectedIds.size >= 2 ? (
                <button
                  onClick={() => setBulkOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-semibold text-white"
                  style={{ background: 'var(--brand-gradient)' }}
                >
                  Resolve ({selectedIds.size})
                </button>
              ) : undefined
            }
            server={{
              page: query.page,
              pageSize: query.pageSize,
              total: totalRecords,
              sortBy: query.sortBy,
              sortDir: query.sortDir,
              onQueryChange: handleQueryChange,
            }}
          />
        </div>
      </PageBody>

      {detailRow && (
        <ExceptionDetailModal
          row={detailRow}
          onClose={() => setDetailRow(null)}
          onSubmit={(submission) => resolveMutation.mutate(submission)}
          onDecideApproval={(approve, decision) => approvalMutation.mutate({ approve, decision })}
          submitting={resolveMutation.isPending || approvalMutation.isPending}
        />
      )}

      {bulkOpen && (
        <ExceptionBulkResolveModal
          rows={selectedRows}
          onClose={() => setBulkOpen(false)}
          onSubmit={(submission) => resolveMutation.mutate(submission)}
          submitting={resolveMutation.isPending}
        />
      )}

      {auditFor && <AuditTrailModal transactionSystemId={auditFor} onClose={() => setAuditFor(null)} />}

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}
