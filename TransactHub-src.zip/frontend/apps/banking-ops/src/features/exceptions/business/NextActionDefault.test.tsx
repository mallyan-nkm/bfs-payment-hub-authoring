import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { grant, renderWithProviders } from '../../../../test/renderWithProviders';
import { PERM } from '../../../shared/auth/permissionKeys';
import { ExceptionBulkResolveModal } from './ExceptionBulkResolveModal';
import { ExceptionDetailModal } from './ExceptionDetailModal';
import { defaultNextAction, forcedNextAction, MARK_AS_SUCCESS } from './panelParts';
import type { BusinessExceptionRow } from './types';

/** BUG-OPS-02: Next action starts on Execute unless the item is dual-controlled, so a non-dual-control item is never parked at Pending Approval. */

function row(id: string, typeCode: string, requiresApproval: boolean, actions: string[]): BusinessExceptionRow {
  return {
    id,
    transactionSystemId: `TX-${id}`,
    rail: 'WPS',
    occurredAt: '2026-11-05T10:54:07Z',
    exceptionCategory: 'WPS Inward',
    exceptionCategoryCode: 'WPS_INWARD',
    exceptionTypeCode: typeCode,
    errorCode: 'E1',
    errorDescription: 'desc',
    severity: 'Medium',
    exceptionStatus: 'Open',
    retryCount: 0,
    detail: { errorNarrative: 'n', messageContext: 'WPS · x', referenceFields: [], actions, requiresApproval },
  };
}

const PLAIN = row('EXC-019ca0675722', 'WPS_INWARD_DIF_NAK', false, ['Mark as Failure']);
const DUAL = row('EXC-dual00000001', 'INWARD_RFA_REVERSAL_REJECTED', true, [MARK_AS_SUCCESS, 'Mark as Failure']);

const checked = (name: string) => screen.getByRole('radio', { name: new RegExp(name) }).getAttribute('aria-checked');

beforeEach(() => grant(PERM.opsExceptionManage));

describe('defaultNextAction / forcedNextAction', () => {
  it('defaults to execute for an item that is not dual-controlled and approval for one that is', () => {
    expect(defaultNextAction(false)).toBe('execute');
    expect(defaultNextAction(true)).toBe('approval');
  });

  it('keeps the forced value only for dual-controlled items', () => {
    expect(forcedNextAction(true, MARK_AS_SUCCESS)).toBe('approval');
    expect(forcedNextAction(true, 'Mark as Failure')).toBe('execute');
    expect(forcedNextAction(false, MARK_AS_SUCCESS)).toBeUndefined();
  });
});

describe('ExceptionDetailModal', () => {
  it('starts on Execute the Action for a non-dual-control item and submits execute by exception key', async () => {
    const onSubmit = vi.fn();
    renderWithProviders(<ExceptionDetailModal row={PLAIN} onClose={vi.fn()} onSubmit={onSubmit} />);

    expect(checked('Execute the Action')).toBe('true');
    expect(checked('Approval Required')).toBe('false');

    await userEvent.type(screen.getByPlaceholderText(/Add comments/), 'close it');
    await userEvent.click(screen.getByRole('button', { name: 'Apply' }));

    expect(onSubmit).toHaveBeenCalledWith(
      expect.objectContaining({ transactionSystemIds: ['EXC-019ca0675722'], nextAction: 'execute' }),
    );
  });

  it('forces approval for Mark as Success on a dual-controlled item and offers no other choice', () => {
    renderWithProviders(<ExceptionDetailModal row={DUAL} onClose={vi.fn()} onSubmit={vi.fn()} />);

    expect(screen.queryByRole('radio', { name: /Execute the Action/ })).toBeNull();
    expect(checked('Approval Required')).toBe('true');
  });
});

describe('ExceptionBulkResolveModal', () => {
  it('starts on Execute when no selected item is dual-controlled', () => {
    renderWithProviders(
      <ExceptionBulkResolveModal
        rows={[PLAIN, row('EXC-2', 'WPS_INWARD_DIF_NAK', false, ['Mark as Failure'])]}
        onClose={vi.fn()}
        onSubmit={vi.fn()}
      />,
    );

    expect(checked('Execute the Action')).toBe('true');
  });

  it('follows the forced rule when the selection is dual-controlled', () => {
    renderWithProviders(
      <ExceptionBulkResolveModal
        rows={[DUAL, row('EXC-dual00000002', 'INWARD_RFA_REVERSAL_REJECTED', true, [MARK_AS_SUCCESS, 'Mark as Failure'])]}
        onClose={vi.fn()}
        onSubmit={vi.fn()}
      />,
    );

    expect(screen.queryByRole('radio', { name: /Execute the Action/ })).toBeNull();
    expect(checked('Approval Required')).toBe('true');
  });
});
