import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Download, RefreshCw, Search } from 'lucide-react';
import { Badge, Button, Can, DataTable, Input, Select, cn, PageToolbar, PageBody } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import type { DataTableColumn, SelectOption } from '@paymenthub/ui';
import { exceptionsApi } from './api';
import type { ExceptionRecord, ExceptionSeverity, ExceptionStatus } from './types';
import {
  useActiveTenantId,
  useCurrentUsername,
  useOfflineAwareAction,
} from '../../shared/hooks/useOfflineAwareAction';

const SEVERITY_ORDER: ExceptionSeverity[] = ['CRITICAL', 'HIGH', 'NORMAL', 'LOW'];

const SEVERITY_STYLE: Record<ExceptionSeverity, { bg: string; fg: string; bar: string }> = {
  CRITICAL: { bg: 'rgba(239,68,68,0.15)', fg: 'var(--accent-red)', bar: 'var(--accent-red)' },
  HIGH: { bg: 'rgba(245,158,11,0.15)', fg: 'var(--accent-amber)', bar: 'var(--accent-amber)' },
  NORMAL: { bg: 'rgba(59,130,246,0.15)', fg: 'var(--accent-blue)', bar: 'var(--accent-blue)' },
  LOW: { bg: 'rgba(90,110,132,0.18)', fg: 'var(--text-muted)', bar: 'var(--text-muted)' },
};

const STATUS_BADGE: Record<ExceptionStatus, 'amber' | 'blue' | 'purple' | 'green'> = {
  OPEN: 'amber',
  IN_PROGRESS: 'blue',
  ESCALATED: 'purple',
  RESOLVED: 'green',
};

const STATUS_TABS: Array<{ key: 'ALL' | ExceptionStatus; label: string }> = [
  { key: 'ALL', label: 'All' },
  { key: 'OPEN', label: 'Open' },
  { key: 'IN_PROGRESS', label: 'In Progress' },
  { key: 'ESCALATED', label: 'Escalated' },
  { key: 'RESOLVED', label: 'Resolved' },
];

// Type filter mirrors Angular exceptions.component.ts (Validation / Routing /
// Posting / Timeout). Matched case-insensitively against exceptionType.
const TYPE_OPTIONS: SelectOption[] = [
  { label: 'All Types', value: '' },
  { label: 'Validation', value: 'VALIDATION' },
  { label: 'Routing', value: 'ROUTING' },
  { label: 'Posting', value: 'POSTING' },
  { label: 'Timeout', value: 'TIMEOUT' },
];

function ageLabel(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '—';
  const mins = Math.max(0, Math.floor((Date.now() - then) / 60000));
  if (mins < 60) return `${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ${mins % 60}m`;
  const days = Math.floor(hours / 24);
  return `${days}d ${hours % 24}h`;
}

function toCsv(rows: ExceptionRecord[]): string {
  const head = ['ExceptionId', 'Type', 'Severity', 'Status', 'Tenant', 'Transaction', 'Workflow', 'Description', 'Retries', 'Created'];
  const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = rows.map((r) =>
    [r.exceptionId, r.exceptionType, r.severity, r.status, r.tenantId, r.transactionId, r.workflowName, r.description, r.retryCount, r.createdAt]
      .map(esc)
      .join(','),
  );
  return [head.join(','), ...lines].join('\n');
}

export function ExceptionQueuePanel() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();

  const [statusTab, setStatusTab] = useState<'ALL' | ExceptionStatus>('ALL');
  const [severities, setSeverities] = useState<Set<ExceptionSeverity>>(new Set());
  const [typeFilter, setTypeFilter] = useState('');
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState<string | null>(null);

  // The exception set is small; fetch it all and filter client-side so tab
  // counts, severity chips, search and CSV all operate on the full result set.
  const { data, isFetching, refetch } = useQuery({
    queryKey: ['exceptions', 'all'],
    queryFn: () => exceptionsApi.list({ take: 500 }).then((r) => r.data),
  });

  const all = useMemo(() => data?.items ?? [], [data]);

  const statusCounts = useMemo(() => {
    const c: Record<string, number> = { ALL: all.length };
    for (const r of all) c[r.status] = (c[r.status] ?? 0) + 1;
    return c;
  }, [all]);

  const criticalCount = useMemo(() => all.filter((r) => r.severity === 'CRITICAL').length, [all]);
  const openCount = useMemo(() => all.filter((r) => r.status !== 'RESOLVED').length, [all]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const type = typeFilter.toUpperCase();
    return all.filter((r) => {
      if (statusTab !== 'ALL' && r.status !== statusTab) return false;
      if (severities.size > 0 && !severities.has(r.severity)) return false;
      if (type && !(r.exceptionType ?? '').toUpperCase().includes(type)) return false;
      if (q) {
        const hay = `${r.exceptionId} ${r.transactionId} ${r.exceptionType} ${r.description ?? ''} ${r.tenantId}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [all, statusTab, severities, typeFilter, search]);

  const runAction = (kind: 'retry' | 'resolve', record: ExceptionRecord) =>
    offlineAwareAction({
      endpoint: `/exceptions/${record.id}/${kind}`,
      method: 'POST',
      payload: kind === 'resolve' ? { resolution: 'Resolved manually from exceptions queue' } : {},
      auditEntry: {
        eventType: kind === 'retry' ? 'EXCEPTION_RETRIED' : 'EXCEPTION_RESOLVED',
        resourceType: 'ExceptionRecord',
        resourceId: String(record.id),
        user: username,
        tenantId,
        details: { transactionId: record.transactionId, exceptionType: record.exceptionType },
        action: kind.toUpperCase(),
      },
    });

  const retryMutation = useMutation({
    mutationFn: (record: ExceptionRecord) => runAction('retry', record),
    onSuccess: (result) => {
      setMessage(result.queued ? 'Queued — will sync when back online' : null);
      queryClient.invalidateQueries({ queryKey: ['exceptions'] });
    },
  });

  const resolveMutation = useMutation({
    mutationFn: (record: ExceptionRecord) => runAction('resolve', record),
    onSuccess: (result) => {
      setMessage(result.queued ? 'Queued — will sync when back online' : null);
      queryClient.invalidateQueries({ queryKey: ['exceptions'] });
    },
  });

  const toggleSeverity = (s: ExceptionSeverity) =>
    setSeverities((prev) => {
      const next = new Set(prev);
      if (next.has(s)) next.delete(s);
      else next.add(s);
      return next;
    });

  const exportCsv = () => {
    const blob = new Blob([toCsv(filtered)], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    // date-format-ok: file-name stamp, not a displayed date
    a.download = `exceptions-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const columns: DataTableColumn<ExceptionRecord>[] = [
    {
      key: 'exceptionType',
      header: 'Exception',
      render: (r) => (
        <div className="flex items-center gap-2">
          <span className="h-8 w-1 rounded-full" style={{ backgroundColor: SEVERITY_STYLE[r.severity].bar }} />
          <div className="min-w-0">
            <div className="font-medium text-[var(--text-primary)]">{r.exceptionType}</div>
            <div className="truncate text-xs text-[var(--text-muted)]">{r.description ?? r.exceptionId}</div>
          </div>
        </div>
      ),
    },
    {
      key: 'severity',
      header: 'Severity',
      render: (r) => (
        <span
          className="inline-flex rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide"
          style={{ backgroundColor: SEVERITY_STYLE[r.severity].bg, color: SEVERITY_STYLE[r.severity].fg }}
        >
          {r.severity}
        </span>
      ),
    },
    { key: 'tenantId', header: 'Tenant', render: (r) => <Badge variant="outline">{r.tenantId}</Badge> },
    {
      key: 'transactionId',
      header: 'Transaction',
      render: (r) => (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/operations/transactions/${encodeURIComponent(r.transactionId)}/360`);
          }}
          className="font-mono text-xs text-[var(--accent)] hover:underline"
          title={r.transactionId}
        >
          {r.transactionId.length > 20 ? `${r.transactionId.slice(0, 20)}…` : r.transactionId}
        </button>
      ),
    },
    { key: 'retryCount', header: 'Retries', align: 'right', render: (r) => r.retryCount },
    { key: 'age', header: 'Age', render: (r) => <span className="text-[var(--text-muted)]">{ageLabel(r.createdAt)}</span> },
    { key: 'status', header: 'Status', render: (r) => <Badge variant={STATUS_BADGE[r.status]}>{r.status.replace('_', ' ')}</Badge> },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (r) => (
        <div className="flex justify-end gap-2">
          {/* POST /exceptions/{id}/retry and /resolve are on Routing's routing:exception:manage group. */}
          <Can permission={PERM.routingExceptionManage}>
            <Button
              variant="secondary"
              size="sm"
              disabled={r.status === 'RESOLVED' || retryMutation.isPending}
              onClick={(e) => {
                e.stopPropagation();
                retryMutation.mutate(r);
              }}
            >
              Retry
            </Button>
          </Can>
          <Can permission={PERM.routingExceptionManage}>
            <Button
              variant="primary"
              size="sm"
              disabled={r.status === 'RESOLVED' || resolveMutation.isPending}
              onClick={(e) => {
                e.stopPropagation();
                resolveMutation.mutate(r);
              }}
            >
              Resolve
            </Button>
          </Can>
        </div>
      ),
    },
  ];

  return (
    <>
      <PageToolbar className="items-center gap-3">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
          <Input
            placeholder="Search type, description, reference…"
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="w-44">
          <Select options={TYPE_OPTIONS} value={typeFilter} onValueChange={setTypeFilter} placeholder="All Types" />
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-medium uppercase tracking-wider text-[var(--text-muted)]">Severity</span>
          {SEVERITY_ORDER.map((s) => {
            const active = severities.has(s);
            return (
              <button
                key={s}
                type="button"
                onClick={() => toggleSeverity(s)}
                className={cn(
                  'rounded-full border px-2.5 py-0.5 text-xs font-medium transition-colors',
                  active ? '' : 'border-[var(--border)] text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
                )}
                style={active ? { backgroundColor: SEVERITY_STYLE[s].bg, color: SEVERITY_STYLE[s].fg, borderColor: SEVERITY_STYLE[s].fg } : undefined}
              >
                {s.charAt(0) + s.slice(1).toLowerCase()}
              </button>
            );
          })}
        </div>
        <div className="ml-auto flex items-center gap-2">
          {criticalCount > 0 && (
            <span
              className="rounded-full border px-2.5 py-0.5 text-xs font-semibold"
              style={{ borderColor: 'var(--accent-red)', color: 'var(--accent-red)' }}
            >
              {criticalCount} Critical
            </span>
          )}
          <span
            className="rounded-full border px-2.5 py-0.5 text-xs font-semibold"
            style={{ borderColor: 'var(--accent-amber)', color: 'var(--accent-amber)' }}
          >
            {openCount} Open
          </span>
          <Button variant="secondary" size="sm" onClick={exportCsv}>
            <Download size={14} /> Export CSV
          </Button>
          <Button variant="ghost" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
          </Button>
        </div>
      </PageToolbar>

      {/* Category tabs by status with live counts */}
      <div className="flex shrink-0 items-center gap-1 border-b border-[var(--border)] bg-[var(--bg-secondary)] px-5">
        {STATUS_TABS.map((t) => {
          const count = statusCounts[t.key] ?? 0;
          const active = statusTab === t.key;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => setStatusTab(t.key)}
              className={cn(
                'flex items-center gap-1.5 border-b-2 px-3 py-2 text-sm transition-colors',
                active
                  ? 'border-[var(--accent)] font-medium text-[var(--text-primary)]'
                  : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-secondary)]',
              )}
            >
              {t.label}
              <span className="rounded-full bg-[var(--bg-card-hover)] px-1.5 text-xs text-[var(--text-secondary)]">{count}</span>
            </button>
          );
        })}
      </div>

      {message && <p className="shrink-0 px-5 pt-3 text-sm text-[var(--accent-amber)]">{message}</p>}

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={filtered}
            rowKey={(r) => String(r.id)}
            onRowClick={(r) => navigate(`/operations/transactions/${encodeURIComponent(r.transactionId)}/360`)}
            loading={isFetching}
            pageSize={25}
            emptyTitle="No exceptions"
            emptyMessage="No exception records match the current filters."
          />
        </div>
      </PageBody>
    </>
  );
}
