import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useSearchParams } from 'react-router-dom';
import { Download } from 'lucide-react';
import { Button, Can, Select, cn, PageToolbar, PageBody, sessionToday } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import type { SelectOption } from '@paymenthub/ui';
import { activeExceptionsApi } from './api';
import type {
  ExceptionDateRange,
  ExceptionDateType,
  ExceptionFilterRequest,
  ExceptionSummary,
  ExceptionViewMode,
  StatusExceptionRow,
} from './types';

// ─── Colour tokens (mirror Angular active-exceptions.component styles) ─────────
const C = {
  red: '#dc2626',
  amber: '#d97706',
  burntOrange: '#9a3412',
  purple: '#8b5cf6',
  blue: '#2563eb',
} as const;

const CARD_TOP = {
  red: '#ef4444',
  amber: '#f59e0b',
  burntOrange: '#9a3412',
  purple: '#8b5cf6',
  blue: '#3b82f6',
} as const;

interface KpiSpec {
  key: keyof ExceptionSummary;
  label: string;
  sub: string;
  top: string;
  value: string;
}

const KPI_CARDS: KpiSpec[] = [
  { key: 'totalExceptions', label: 'TOTAL EXCEPTIONS', sub: 'All open exceptions', top: CARD_TOP.red, value: C.red },
  { key: 'formatValidation', label: 'Format / Validation', sub: 'Format / XSD / rule failures', top: CARD_TOP.amber, value: C.amber },
  { key: 'duplicate', label: 'Duplicate', sub: 'Duplicate transaction detected', top: CARD_TOP.burntOrange, value: C.burntOrange },
  { key: 'accountError', label: 'Account Error', sub: 'Invalid / closed / insufficient', top: CARD_TOP.red, value: C.red },
  { key: 'complianceAml', label: 'Compliance / AML', sub: 'Sanction / AML screening hit', top: CARD_TOP.purple, value: C.purple },
  { key: 'settlementCb', label: 'Settlement / CB', sub: 'CB rejection / settlement fail', top: CARD_TOP.blue, value: C.blue },
  { key: 'slaBreached', label: 'SLA BREACHED', sub: 'Past SLA threshold', top: CARD_TOP.red, value: C.red },
];

const DATE_TYPE_OPTIONS: SelectOption[] = [
  { label: 'Transaction Date', value: 'transactionDate' },
  { label: 'Value Date', value: 'valueDate' },
];

const DATE_RANGE_OPTIONS: SelectOption[] = [
  { label: 'Till Today — All Open', value: 'tillToday' },
  { label: 'Today', value: 'today' },
  { label: 'Yesterday', value: 'yesterday' },
  { label: 'Custom Range', value: 'customRange' },
];

const VIEW_MODES: Array<{ key: ExceptionViewMode; label: string }> = [
  { key: 'rail', label: 'By Rail' },
  { key: 'channel', label: 'By Channel' },
  { key: 'status', label: 'By Status' },
];

const EMPTY_SUMMARY: ExceptionSummary = {
  totalExceptions: 0,
  formatValidation: 0,
  duplicate: 0,
  accountError: 0,
  complianceAml: 0,
  settlementCb: 0,
  timeout: 0,
  slaBreached: 0,
};

function railBadgeColor(rail: string): { bg: string; fg: string } {
  const key = rail.toUpperCase();
  if (key.includes('IPI')) return { bg: 'rgba(29,78,216,0.15)', fg: '#60a5fa' };
  if (key.includes('FTS')) return { bg: 'rgba(126,34,206,0.15)', fg: '#c084fc' };
  if (key.includes('WPS')) return { bg: 'rgba(21,128,61,0.15)', fg: '#4ade80' };
  if (key.includes('IPP')) return { bg: 'rgba(194,65,12,0.15)', fg: '#fb923c' };
  if (key.includes('SWIFT') || key.includes('CBFT')) return { bg: 'rgba(161,98,7,0.15)', fg: '#fbbf24' };
  return { bg: 'rgba(90,110,132,0.18)', fg: 'var(--text-secondary)' };
}

const n = (v: number | undefined) => (v ?? 0).toLocaleString();

// The session zone's date, not the UTC one (UTC date-time T-22, AC-UT-K02).
const todayIso = () => sessionToday();

function rangeLabel(range: ExceptionDateRange): string {
  switch (range) {
    case 'tillToday':
      return 'Till Today — All Open';
    case 'today':
      return 'Today';
    case 'yesterday':
      return 'Yesterday';
    case 'customRange':
      return 'Custom Range';
  }
}

// Shared header/cell classes for the pivot tables.
const th = 'px-3 py-2.5 text-left text-[10px] font-bold uppercase tracking-[0.04em] text-[var(--text-muted)] whitespace-nowrap border-b border-[var(--border)]';
const td = 'px-3 py-2.5 border-b border-[var(--border)] text-[var(--text-secondary)]';
const numCell = 'text-center';

export function ActiveExceptionsPanel({ onViewQueue }: { onViewQueue: () => void }) {
  const [searchParams] = useSearchParams();
  const direction = searchParams.get('direction')?.toLowerCase() === 'inbound' ? 'Inbound' : 'Outward';

  // Draft filter (edited in the bar) vs applied filter (drives the queries).
  const [dateType, setDateType] = useState<ExceptionDateType>('transactionDate');
  const [dateRange, setDateRange] = useState<ExceptionDateRange>('tillToday');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [dateError, setDateError] = useState('');
  const [viewMode, setViewMode] = useState<ExceptionViewMode>('rail');
  const [exporting, setExporting] = useState(false);

  const [applied, setApplied] = useState<ExceptionFilterRequest>({
    direction,
    dateType: 'transactionDate',
    dateRange: 'tillToday',
  });

  const validateRange = (): boolean => {
    setDateError('');
    if (dateRange !== 'customRange') return true;
    if (!customFrom || !customTo) {
      setDateError('Please select both From and To dates');
      return false;
    }
    // yyyy-MM-dd days compare as strings; "today" is the session zone's.
    if (customTo > todayIso()) {
      setDateError('To date cannot be in the future');
      return false;
    }
    if (customFrom > customTo) {
      setDateError('From date must be before To date');
      return false;
    }
    return true;
  };

  const applySearch = () => {
    if (!validateRange()) return;
    const next: ExceptionFilterRequest = { direction, dateType, dateRange };
    if (dateRange === 'customRange') {
      if (customFrom) next.from = customFrom;
      if (customTo) next.to = customTo;
    }
    setApplied(next);
  };

  const summaryQuery = useQuery({
    queryKey: ['exceptions-analytics', 'summary', applied],
    queryFn: () => activeExceptionsApi.summary(applied),
  });

  const railQuery = useQuery({
    queryKey: ['exceptions-analytics', 'by-rail', applied],
    queryFn: () => activeExceptionsApi.byRail(applied),
    enabled: viewMode === 'rail',
  });

  const channelQuery = useQuery({
    queryKey: ['exceptions-analytics', 'by-channel', applied],
    queryFn: () => activeExceptionsApi.byChannel(applied),
    enabled: viewMode === 'channel',
  });

  const statusQuery = useQuery({
    queryKey: ['exceptions-analytics', 'by-status', applied],
    queryFn: () => activeExceptionsApi.byStatus(applied),
    enabled: viewMode === 'status',
  });

  const summary = summaryQuery.data ?? EMPTY_SUMMARY;

  const statusTotals = useMemo(() => {
    const rows: StatusExceptionRow[] = statusQuery.data?.statuses ?? [];
    return rows.reduce(
      (acc, r) => ({
        count: acc.count + (r.total || 0),
        critical: acc.critical + (r.critical || 0),
        high: acc.high + (r.high || 0),
        medium: acc.medium + (r.medium || 0),
        low: acc.low + (r.low || 0),
      }),
      { count: 0, critical: 0, high: 0, medium: 0, low: 0 },
    );
  }, [statusQuery.data]);

  const filterSummaryText = useMemo(() => {
    const typeLabel = applied.dateType === 'transactionDate' ? 'Transaction Date' : 'Value Date';
    if (applied.dateRange === 'customRange' && applied.from && applied.to) {
      return `${typeLabel}: ${applied.from} — ${applied.to}`;
    }
    return `${typeLabel}: ${rangeLabel(applied.dateRange)}`;
  }, [applied]);

  const exportCsv = async () => {
    if (!validateRange()) return;
    setExporting(true);
    try {
      const csv = await activeExceptionsApi.exportCsv(viewMode, applied);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `exceptions_by_${viewMode}_${todayIso().replace(/-/g, '')}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setExporting(false);
    }
  };

  const activeLoading =
    (viewMode === 'rail' && railQuery.isFetching) ||
    (viewMode === 'channel' && channelQuery.isFetching) ||
    (viewMode === 'status' && statusQuery.isFetching);

  const ViewQueueLink = ({ color }: { color?: string }) => (
    <button
      type="button"
      onClick={onViewQueue}
      className="whitespace-nowrap text-[11px] font-bold hover:underline"
      style={{ color: color ?? '#2dd4bf' }}
    >
      → View Queue
    </button>
  );

  return (
    <>
      <PageToolbar className="items-center gap-2.5">
        <span className="text-[13px] font-semibold text-[var(--text-secondary)]">Exceptions raised:</span>
        <div className="w-44">
          <Select
            options={DATE_TYPE_OPTIONS}
            value={dateType}
            onValueChange={(v) => setDateType(v as ExceptionDateType)}
          />
        </div>
        <div className="w-52">
          <Select
            options={DATE_RANGE_OPTIONS}
            value={dateRange}
            onValueChange={(v) => setDateRange(v as ExceptionDateRange)}
          />
        </div>
        {dateRange === 'customRange' && (
          <div className="flex items-center gap-2">
            <label className="text-xs text-[var(--text-muted)]">From:</label>
            <input
              type="date"
              max={todayIso()}
              value={customFrom}
              onChange={(e) => setCustomFrom(e.target.value)}
              className="rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-2 py-1.5 text-xs text-[var(--text-secondary)]"
            />
            <label className="text-xs text-[var(--text-muted)]">To:</label>
            <input
              type="date"
              max={todayIso()}
              value={customTo}
              onChange={(e) => setCustomTo(e.target.value)}
              className="rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-2 py-1.5 text-xs text-[var(--text-secondary)]"
            />
            {dateError && <span className="text-[11px] text-[var(--accent-red)]">⚠ {dateError}</span>}
          </div>
        )}
        <Button variant="primary" size="sm" onClick={applySearch}>
          Search
        </Button>
        {/* The by-* exports need ops:exception:read AND ops:report:export. */}
        <Can permission={PERM.opsReportExport}>
          <Button variant="secondary" size="sm" onClick={exportCsv} disabled={exporting}>
            <Download size={14} /> {exporting ? 'Exporting…' : 'Export CSV'}
          </Button>
        </Can>
        <div className="ml-auto flex items-center gap-1 rounded-md border border-[var(--border)] p-0.5">
          {VIEW_MODES.map((v) => {
            const active = viewMode === v.key;
            return (
              <button
                key={v.key}
                type="button"
                onClick={() => setViewMode(v.key)}
                className={cn(
                  'rounded px-3 py-1 text-xs font-semibold transition-colors',
                  active
                    ? 'bg-[var(--accent)] text-white'
                    : 'text-[var(--text-secondary)] hover:bg-[var(--bg-card-hover)]',
                )}
              >
                {v.label}
              </button>
            );
          })}
        </div>
      </PageToolbar>

      <PageBody>
        {/* 7 category KPI cards */}
        <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-7">
          {KPI_CARDS.map((c) => (
            <div
              key={c.key}
              className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)] p-4"
              style={{ borderTop: `3px solid ${c.top}` }}
            >
              <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]">{c.label}</div>
              <div className="text-[26px] font-bold leading-none" style={{ color: c.value }}>
                {summaryQuery.isFetching ? '—' : n(summary[c.key])}
              </div>
              <div className="mt-2 border-t border-dashed border-[var(--border)] pt-1.5 text-xs text-[var(--text-muted)]">{c.sub}</div>
            </div>
          ))}
        </div>

        <div className="mb-3 text-xs text-[var(--text-muted)]">📅 {filterSummaryText}</div>

        <div className="overflow-x-auto rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          {activeLoading ? (
            <div className="p-8 text-center text-sm italic text-[var(--text-muted)]">Loading {viewMode} data…</div>
          ) : viewMode === 'rail' ? (
            <table className="w-full min-w-[900px] border-collapse text-xs">
              <thead>
                <tr className="bg-[var(--bg-secondary)]">
                  <th className={th}>RAIL</th>
                  <th className={cn(th, numCell)}>TOTAL</th>
                  <th className={cn(th, numCell)} style={{ color: C.amber }}>FORMAT / VALIDATION</th>
                  <th className={cn(th, numCell)}>DUPLICATE</th>
                  <th className={cn(th, numCell)} style={{ color: C.red }}>ACCOUNT ERROR</th>
                  <th className={cn(th, numCell)} style={{ color: C.purple }}>COMPLIANCE / AML</th>
                  <th className={cn(th, numCell)} style={{ color: C.blue }}>SETTLEMENT / CB</th>
                  <th className={cn(th, numCell)}>TIMEOUT</th>
                  <th className={cn(th, numCell)} style={{ color: C.red }}>SLA BREACHED</th>
                  <th className={th}>ACTION</th>
                </tr>
              </thead>
              <tbody>
                {(railQuery.data?.rails ?? []).map((r) => {
                  const badge = railBadgeColor(r.rail);
                  return (
                    <tr key={r.rail} className="hover:bg-[var(--bg-card-hover)]">
                      <td className={td}>
                        <span className="inline-block rounded px-2 py-0.5 text-[11px] font-bold" style={{ backgroundColor: badge.bg, color: badge.fg }}>
                          {r.rail}
                        </span>
                      </td>
                      <td className={cn(td, numCell, 'font-bold text-[var(--text-primary)]')}>{n(r.total)}</td>
                      <td className={cn(td, numCell)} style={{ color: C.amber }}>{n(r.formatValidation)}</td>
                      <td className={cn(td, numCell)}>{n(r.duplicate)}</td>
                      <td className={cn(td, numCell, 'font-bold')} style={{ color: C.red }}>{n(r.accountError)}</td>
                      <td className={cn(td, numCell)} style={{ color: C.purple }}>{n(r.complianceAml)}</td>
                      <td className={cn(td, numCell)} style={{ color: C.blue }}>{n(r.settlementCb)}</td>
                      <td className={cn(td, numCell)}>{n(r.timeout)}</td>
                      <td className={cn(td, numCell, 'font-bold')} style={{ color: C.red }}>{n(r.slaBreached)}</td>
                      <td className={td}><ViewQueueLink color={badge.fg} /></td>
                    </tr>
                  );
                })}
                <tr className="bg-[var(--bg-secondary)] font-bold">
                  <td className={cn(td, 'text-[var(--text-primary)]')}>Total</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(summary.totalExceptions)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.amber }}>{n(summary.formatValidation)}</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(summary.duplicate)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.red }}>{n(summary.accountError)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.purple }}>{n(summary.complianceAml)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.blue }}>{n(summary.settlementCb)}</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(summary.timeout)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.red }}>{n(summary.slaBreached)}</td>
                  <td className={td} />
                </tr>
              </tbody>
            </table>
          ) : viewMode === 'channel' ? (
            <table className="w-full min-w-[900px] border-collapse text-xs">
              <thead>
                <tr className="bg-[var(--bg-secondary)]">
                  <th className={th}>CHANNEL</th>
                  <th className={cn(th, numCell)}>TOTAL</th>
                  <th className={cn(th, numCell)} style={{ color: C.amber }}>FORMAT / VALIDATION</th>
                  <th className={cn(th, numCell)}>DUPLICATE</th>
                  <th className={cn(th, numCell)} style={{ color: C.red }}>ACCOUNT ERROR</th>
                  <th className={cn(th, numCell)} style={{ color: C.purple }}>COMPLIANCE / AML</th>
                  <th className={cn(th, numCell)} style={{ color: C.blue }}>SETTLEMENT / CB</th>
                  <th className={cn(th, numCell)}>TIMEOUT</th>
                  <th className={cn(th, numCell)} style={{ color: C.red }}>SLA BREACHED</th>
                  <th className={th}>ACTION</th>
                </tr>
              </thead>
              <tbody>
                {(channelQuery.data?.channels ?? []).map((r) => (
                  <tr key={r.channel} className="hover:bg-[var(--bg-card-hover)]">
                    <td className={cn(td, 'font-semibold text-[var(--text-primary)]')}>{r.channel}</td>
                    <td className={cn(td, numCell, 'font-bold text-[var(--text-primary)]')}>{n(r.total)}</td>
                    <td className={cn(td, numCell)} style={{ color: C.amber }}>{n(r.formatValidation)}</td>
                    <td className={cn(td, numCell)}>{n(r.duplicate)}</td>
                    <td className={cn(td, numCell, 'font-bold')} style={{ color: C.red }}>{n(r.accountError)}</td>
                    <td className={cn(td, numCell)} style={{ color: C.purple }}>{n(r.complianceAml)}</td>
                    <td className={cn(td, numCell)} style={{ color: C.blue }}>{n(r.settlementCb)}</td>
                    <td className={cn(td, numCell)}>{n(r.timeout)}</td>
                    <td className={cn(td, numCell, 'font-bold')} style={{ color: C.red }}>{n(r.slaBreached)}</td>
                    <td className={td}><ViewQueueLink /></td>
                  </tr>
                ))}
                <tr className="bg-[var(--bg-secondary)] font-bold">
                  <td className={cn(td, 'text-[var(--text-primary)]')}>Total</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(summary.totalExceptions)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.amber }}>{n(summary.formatValidation)}</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(summary.duplicate)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.red }}>{n(summary.accountError)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.purple }}>{n(summary.complianceAml)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.blue }}>{n(summary.settlementCb)}</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(summary.timeout)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.red }}>{n(summary.slaBreached)}</td>
                  <td className={td} />
                </tr>
              </tbody>
            </table>
          ) : (
            <table className="w-full min-w-[720px] border-collapse text-xs">
              <thead>
                <tr className="bg-[var(--bg-secondary)]">
                  <th className={th}>FAILURE / EXCEPTION TYPE</th>
                  <th className={cn(th, numCell)}>COUNT</th>
                  <th className={cn(th, numCell)}>% OF TOTAL</th>
                  <th className={cn(th, numCell)} style={{ color: C.red }}>CRITICAL</th>
                  <th className={cn(th, numCell)} style={{ color: C.amber }}>HIGH</th>
                  <th className={cn(th, numCell)} style={{ color: C.blue }}>MEDIUM</th>
                  <th className={cn(th, numCell)}>LOW</th>
                  <th className={th}>ACTION</th>
                </tr>
              </thead>
              <tbody>
                {(statusQuery.data?.statuses ?? []).map((r) => (
                  <tr key={r.exceptionType} className="hover:bg-[var(--bg-card-hover)]">
                    <td className={td}>
                      <span
                        className="mr-1.5 inline-block h-2 w-2 rounded-full align-middle"
                        style={{ backgroundColor: r.critical > 0 ? C.red : '#f59e0b' }}
                      />
                      {r.exceptionType || 'Unknown'}
                    </td>
                    <td className={cn(td, numCell, 'font-bold text-[var(--text-primary)]')}>{n(r.total)}</td>
                    <td className={cn(td, numCell, 'text-[var(--text-muted)]')}>{(r.percentOfTotal ?? 0).toFixed(1)}%</td>
                    <td className={cn(td, numCell, 'font-bold')} style={{ color: C.red }}>{n(r.critical)}</td>
                    <td className={cn(td, numCell)} style={{ color: C.amber }}>{n(r.high)}</td>
                    <td className={cn(td, numCell)} style={{ color: C.blue }}>{n(r.medium)}</td>
                    <td className={cn(td, numCell)}>{n(r.low)}</td>
                    <td className={td}><ViewQueueLink /></td>
                  </tr>
                ))}
                <tr className="bg-[var(--bg-secondary)] font-bold">
                  <td className={cn(td, 'text-[var(--text-primary)]')}>Total Active</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(statusTotals.count)}</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>100%</td>
                  <td className={cn(td, numCell)} style={{ color: C.red }}>{n(statusTotals.critical)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.amber }}>{n(statusTotals.high)}</td>
                  <td className={cn(td, numCell)} style={{ color: C.blue }}>{n(statusTotals.medium)}</td>
                  <td className={cn(td, numCell, 'text-[var(--text-primary)]')}>{n(statusTotals.low)}</td>
                  <td className={td} />
                </tr>
              </tbody>
            </table>
          )}
        </div>
      </PageBody>
    </>
  );
}
