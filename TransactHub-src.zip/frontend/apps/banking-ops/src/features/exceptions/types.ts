export type ExceptionStatus = 'OPEN' | 'IN_PROGRESS' | 'ESCALATED' | 'RESOLVED';
export type ExceptionSeverity = 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW';

/** Mirrors the Operations API exception DTO (GET /api/exceptions). */
export interface ExceptionRecord {
  id: number;
  exceptionId: string;
  transactionId: string;
  exceptionType: string;
  severity: ExceptionSeverity;
  status: ExceptionStatus;
  tenantId: string;
  workflowName: string | null;
  stepId: string | null;
  description: string | null;
  errorDetails: string | null;
  assignedTo: string | null;
  createdAt: string;
  resolvedAt: string | null;
  escalatedAt: string | null;
  retryCount: number;
  lastRetryAt: string | null;
}

export interface ExceptionListResponse {
  items: ExceptionRecord[];
  total: number;
  page: number;
  pageSize: number;
}

export interface ExceptionListParams {
  page?: number;
  pageSize?: number;
  take?: number;
  status?: string;
  severity?: string;
  exceptionType?: string;
  tenantId?: string;
}

// ─── Active-Exceptions analytics drill-down ────────────────────────────────────
// Mirrors the Operations API DTOs served by GET /api/ops/exceptions/{summary,
// by-rail, by-channel, by-status} (see ExceptionDtos.cs / ExceptionEndpoints.cs).

export type ExceptionDateType = 'transactionDate' | 'valueDate';
export type ExceptionDateRange = 'tillToday' | 'today' | 'yesterday' | 'customRange';
export type ExceptionViewMode = 'rail' | 'channel' | 'status';

export interface ExceptionFilterRequest {
  direction: string; // 'Outward' | 'Inbound'
  dateType: ExceptionDateType;
  dateRange: ExceptionDateRange;
  from?: string; // YYYY-MM-DD (custom range start)
  to?: string; // YYYY-MM-DD (custom range end)
}

export interface ExceptionSummary {
  totalExceptions: number;
  formatValidation: number;
  duplicate: number;
  accountError: number;
  complianceAml: number;
  settlementCb: number;
  timeout: number;
  slaBreached: number;
}

export interface RailExceptionRow {
  rail: string;
  total: number;
  formatValidation: number;
  duplicate: number;
  accountError: number;
  complianceAml: number;
  settlementCb: number;
  timeout: number;
  slaBreached: number;
  warnAction: boolean;
}

export interface ChannelExceptionRow {
  channel: string;
  total: number;
  formatValidation: number;
  duplicate: number;
  accountError: number;
  complianceAml: number;
  settlementCb: number;
  timeout: number;
  slaBreached: number;
  warnAction: boolean;
}

export interface StatusExceptionRow {
  exceptionType: string;
  total: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
  percentOfTotal: number;
}

export interface ExceptionsByRailResponse {
  summary: ExceptionSummary;
  rails: RailExceptionRow[];
}

export interface ExceptionsByChannelResponse {
  summary: ExceptionSummary;
  channels: ChannelExceptionRow[];
}

export interface ExceptionsByStatusResponse {
  summary: ExceptionSummary;
  statuses: StatusExceptionRow[];
}

// ─── Disputes ──────────────────────────────────────────────────────────────────
// Mirrors PaymentDispute served by GET /api/disputes (ExceptionHandler service).
export interface DisputeRecord {
  id: number;
  disputeId: string;
  transactionId: string;
  disputeType: string;
  status: string;
  raisedBy: string;
  tenantId: string | null;
  description: string;
  disputedAmount: number | null;
  currency: string | null;
  assignedTo: string | null;
  createdAt: string;
  resolvedAt: string | null;
  slaDeadline: string | null;
}
