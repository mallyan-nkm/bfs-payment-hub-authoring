import { useState } from 'react';
import { cn, PageShell, PageHeader } from '@paymenthub/ui';
import { ActiveExceptionsPanel } from './ActiveExceptionsPanel';
import { ExceptionQueuePanel } from './ExceptionQueuePanel';
import { DisputesPanel } from './DisputesPanel';

type TopTab = 'analytics' | 'queue' | 'disputes';

const TOP_TABS: Array<{ key: TopTab; label: string; title: string }> = [
  { key: 'analytics', label: 'Active Exceptions', title: 'Analytics drill-down by rail, channel, and status' },
  { key: 'queue', label: 'Exception Queue', title: 'Operational queue — investigate, retry, and resolve' },
  { key: 'disputes', label: 'Disputes', title: 'Customer or bank-raised payment disputes' },
];

export function ExceptionsPage() {
  const [tab, setTab] = useState<TopTab>('analytics');

  return (
    <PageShell>
      <PageHeader
        title="Exception Management"
        subtitle="Track, assign, and resolve payment exceptions and disputes"
      />

      <div className="flex shrink-0 items-center gap-1 border-b border-[var(--border)] px-5">
        {TOP_TABS.map((t) => {
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              type="button"
              title={t.title}
              onClick={() => setTab(t.key)}
              className={cn(
                'border-b-2 px-4 py-2.5 text-sm transition-colors',
                active
                  ? 'border-[var(--accent)] font-semibold text-[var(--text-primary)]'
                  : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-secondary)]',
              )}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'analytics' && <ActiveExceptionsPanel onViewQueue={() => setTab('queue')} />}
      {tab === 'queue' && <ExceptionQueuePanel />}
      {tab === 'disputes' && <DisputesPanel />}
    </PageShell>
  );
}
