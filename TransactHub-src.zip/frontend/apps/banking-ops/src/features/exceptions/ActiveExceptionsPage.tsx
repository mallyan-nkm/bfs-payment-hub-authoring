import { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { ChevronDown, Download, Search, Calendar } from 'lucide-react';
import {
  Can,
  LoadingSpinner,
  PageBody,
  PageShell,
  cn,
} from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { activeExceptionsApi } from './api';
import type {
  ExceptionDateRange,
  ExceptionDateType,
  ExceptionFilterRequest,
  ExceptionSummary,
  ExceptionViewMode,
  StatusExceptionRow,
} from './types';
import { sessionToday } from '@paymenthub/ui';

const C = {
  red: '#dc2626',
  amber: '#d97706',
  burntOrange: '#9a3412',
  purple: '#8b5cf6',
  blue: '#2563eb',
} as const;

const CARD_TOP = {
  red: '#ef4444',
  amber: '#f59e0b',
  burntOrange: '#9a3412',
  purple: '#8b5cf6',
  blue: '#3b82f6',
} as const;

interface KpiSpec {
  key: keyof ExceptionSummary;
  label: string;
  sub: string;
  top: string;
  value: string;
}

const KPI_CARDS: KpiSpec[] = [
  { key: 'totalExceptions', label: 'TOTAL EXCEPTIONS', sub: 'All open exceptions', top: CARD_TOP.red, value: C.red },
  { key: 'formatValidation', label: 'Format / Validation', sub: 'Format / XSD / rule failures', top: CARD_TOP.amber, value: C.amber },
  { key: 'duplicate', label: 'Duplicate', sub: 'Duplicate transaction detected', top: CARD_TOP.burntOrange, value: C.burntOrange },
  { key: 'accountError', label: 'Account Error', sub: 'Invalid / closed / insufficient', top: CARD_TOP.red, value: C.red },
  { key: 'complianceAml', label: 'Compliance / AML', sub: 'Sanction / AML screening hit', top: CARD_TOP.purple, value: C.purple },
  { key: 'settlementCb', label: 'Settlement / CB', sub: 'CB rejection / settlement fail', top: CARD_TOP.blue, value: C.blue },
  { key: 'slaBreached', label: 'SLA BREACHED', sub: 'Past SLA threshold', top: CARD_TOP.red, value: C.red },
];

const VIEW_MODES: Array<{ key: ExceptionViewMode; label: string }> = [
  { key: 'rail', label: 'By Rail' },
  { key: 'channel', label: 'By Channel' },
  { key: 'status', label: 'By Status' },
];

const EMPTY_SUMMARY: ExceptionSummary = {
  totalExceptions: 0,
  formatValidation: 0,
  duplicate: 0,
  accountError: 0,
  complianceAml: 0,
  settlementCb: 0,
  timeout: 0,
  slaBreached: 0,
};

function railBadgeColor(rail: string): { bg: string; fg: string } {
  const key = rail.toUpperCase();
  if (key.includes('IPI')) return { bg: 'rgba(29,78,216,0.15)', fg: '#1d4ed8' };
  if (key.includes('FTS')) return { bg: 'rgba(126,34,206,0.15)', fg: '#7e22ce' };
  if (key.includes('WPS')) return { bg: 'rgba(21,128,61,0.15)', fg: '#15803d' };
  if (key.includes('IPP')) return { bg: 'rgba(194,65,12,0.15)', fg: '#c2410c' };
  if (key.includes('SWIFT') || key.includes('CBFT')) return { bg: 'rgba(161,98,7,0.15)', fg: '#a16207' };
  return { bg: 'rgba(90,110,132,0.18)', fg: 'var(--text-secondary)' };
}

const n = (v: number | undefined) => (v ?? 0).toLocaleString();
// The session zone's date, not the UTC one (UTC date-time T-22, AC-UT-K02).
const todayIso = () => sessionToday();

function rangeLabel(range: ExceptionDateRange): string {
  switch (range) {
    case 'tillToday':
      return 'Till Today — All Open';
    case 'today':
      return 'Today';
    case 'yesterday':
      return 'Yesterday';
    case 'customRange':
      return 'Custom Range';
  }
}

// const TH = 'px-3.5 py-3 text-left text-[14px] font-semibold uppercase tracking-wide text-[#4B5563] whitespace-nowrap';
// const TH_NUM = 'px-3.5 py-3 text-center text-[14px] font-semibold uppercase tracking-wide text-[#4B5563] whitespace-nowrap';
// const TD = 'px-3.5 py-3 text-[14px] text-[var(--text-secondary)] whitespace-nowrap';
// const TD_NUM = 'px-3.5 py-3 text-center text-[14px] tabular-nums whitespace-nowrap';

export function ActiveExceptionsPage() {
  const [searchParams] = useSearchParams();
  const direction = searchParams.get('direction')?.toLowerCase() === 'inbound' ? 'Inbound' : 'Outward';
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [dateType, setDateType] = useState<ExceptionDateType>('transactionDate');
  const [dateRange, setDateRange] = useState<ExceptionDateRange>('tillToday');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [dateError, setDateError] = useState('');
  const [viewMode, setViewMode] = useState<ExceptionViewMode>('rail');
  const [exporting, setExporting] = useState(false);

  const [applied, setApplied] = useState<ExceptionFilterRequest>({
    direction,
    dateType: 'transactionDate',
    dateRange: 'tillToday',
  });

  const validateRange = (): boolean => {
    setDateError('');
    if (dateRange !== 'customRange') return true;
    if (!customFrom || !customTo) {
      setDateError('Please select both From and To dates');
      return false;
    }
    // yyyy-MM-dd days compare as strings; "today" is the session zone's.
    if (customTo > todayIso()) {
      setDateError('To date cannot be in the future');
      return false;
    }
    if (customFrom > customTo) {
      setDateError('From date must be before To date');
      return false;
    }
    return true;
  };

  const applySearch = () => {
    if (!validateRange()) return;
    const next: ExceptionFilterRequest = { direction, dateType, dateRange };
    if (dateRange === 'customRange') {
      if (customFrom) next.from = customFrom;
      if (customTo) next.to = customTo;
    }
    setApplied(next);
    void queryClient.invalidateQueries({ queryKey: ['exceptions-analytics'] });
  };

  const summaryQuery = useQuery({
    queryKey: ['exceptions-analytics', 'summary', applied],
    queryFn: () => activeExceptionsApi.summary(applied),
  });

  const railQuery = useQuery({
    queryKey: ['exceptions-analytics', 'by-rail', applied],
    queryFn: () => activeExceptionsApi.byRail(applied),
    enabled: viewMode === 'rail',
  });

  const channelQuery = useQuery({
    queryKey: ['exceptions-analytics', 'by-channel', applied],
    queryFn: () => activeExceptionsApi.byChannel(applied),
    enabled: viewMode === 'channel',
  });

  const statusQuery = useQuery({
    queryKey: ['exceptions-analytics', 'by-status', applied],
    queryFn: () => activeExceptionsApi.byStatus(applied),
    enabled: viewMode === 'status',
  });

  const summary = summaryQuery.data ?? EMPTY_SUMMARY;

  const statusTotals = useMemo(() => {
    const rows: StatusExceptionRow[] = statusQuery.data?.statuses ?? [];
    return rows.reduce(
      (acc, r) => ({
        count: acc.count + (r.total || 0),
        critical: acc.critical + (r.critical || 0),
        high: acc.high + (r.high || 0),
        medium: acc.medium + (r.medium || 0),
        low: acc.low + (r.low || 0),
      }),
      { count: 0, critical: 0, high: 0, medium: 0, low: 0 },
    );
  }, [statusQuery.data]);

  const filterSummaryText = useMemo(() => {
    const typeLabel = applied.dateType === 'transactionDate' ? 'Transaction Date' : 'Value Date';
    if (applied.dateRange === 'customRange' && applied.from && applied.to) {
      return `${typeLabel}: ${applied.from} — ${applied.to}`;
    }
    return `${typeLabel}: ${rangeLabel(applied.dateRange)}`;
  }, [applied]);

  const exportCsv = async () => {
    if (!validateRange()) return;
    setExporting(true);
    try {
      const csv = await activeExceptionsApi.exportCsv(viewMode, applied);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `exceptions_by_${viewMode}_${todayIso().replace(/-/g, '')}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setExporting(false);
    }
  };

  const activeLoading =
    (viewMode === 'rail' && railQuery.isFetching) ||
    (viewMode === 'channel' && channelQuery.isFetching) ||
    (viewMode === 'status' && statusQuery.isFetching);

  const onViewQueue = () => {
    navigate('/business-exceptions');
  };

  const ViewQueueLink = ({  }: { itemKey?: string; color?: string }) => (
    <button
      type="button"
      onClick={onViewQueue}
      className="btn-secondary"
     
    >
      View Queue
    </button>
  );

  return (
    <PageShell>
      <PageBody>
        <div className="flex flex-col gap-4 pr-2">
          {/* Breadcrumbs */}
          <div>
            <p className="mt-2 text-xs text-[var(--text-muted)]">
              <button onClick={() => navigate('/dashboard')} className="text-[var(--primary-blue)] hover:underline">
                Dashboard
              </button>
              {' / Operations / '}
              <span className="text-[var(--text-secondary)]">{direction} Active Exceptions</span>
            </p>
          </div>

          {/* Title Header */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="truncate text-[18px] sm:text-[22px] lg:text-[24px] font-black text-[var(--text-primary)]">
                Active Exceptions — Drill-Down
              </h1>
              <p className="mt-0.5 text-sm text-[var(--text-thirtiary)]">
                Click a rail row to drill into the exception queue | Counts shown by exception type per rail
              </p>
            </div>
          </div>

          {/* KPI Cards Grid */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-7">
            {KPI_CARDS.map((c) => (
              <div
                key={c.key}
                className="trand-card rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]"
                style={{ borderTop: `3px solid ${c.top}` }}
              >
                <p className="input-label text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)] truncate">
                  {c.label}
                </p>
                <p className="mt-1 text-2xl sm:text-3xl font-bold leading-none tabular-nums" style={{ color: c.value }}>
                  {summaryQuery.isFetching ? '—' : n(summary[c.key])}
                </p>
                <p className="mt-2 truncate text-[11px] text-[var(--text-muted)] border-t border-dashed border-[var(--border)] pt-1.5">
                  {c.sub}
                </p>
              </div>
            ))}
          </div>

          {/* Filter Bar Card */}
          <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4 shadow-[var(--shadow-sm)]">
            <p className="input-label mb-2 text-[11px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
              Exceptions raised filter
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <select
                  value={dateType}
                  onChange={(e) => setDateType(e.target.value as ExceptionDateType)}
                  className="input-cls h-32px min-w-[220px] appearance-none pr-7 "
                >
                  <option value="transactionDate">Transaction Date</option>
                  <option value="valueDate">Value Date</option>
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-2.5 size-3 text-[var(--text-muted)]" />
              </div>

              <div className="relative">
                <select
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value as ExceptionDateRange)}
                  className="input-cls h-32px min-w-[200px] appearance-none pr-7 "
                >
                  <option value="tillToday">Till Today — All Open</option>
                  <option value="today">Today</option>
                  <option value="yesterday">Yesterday</option>
                  <option value="customRange">Custom Range</option>
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-2.5 size-3 text-[var(--text-muted)]" />
              </div>

             

              <button
                type="button"
                onClick={applySearch}
                className="btn-primary h-38px !py-1.5 !px-3.5 text-xs inline-flex items-center gap-1"
              >
                <Search size={13} />
                Search
              </button>

              {/* The by-* exports need ops:exception:read AND ops:report:export; the page already
                  requires the first. */}
              <Can permission={PERM.opsReportExport}>
                <button
                  type="button"
                  onClick={exportCsv}
                  disabled={exporting}
                  className="btn-secondary h-38px !py-1.5 !px-3 text-xs inline-flex items-center gap-1.5 disabled:cursor-not-allowed disabled:opacity-45"
                >
                  <Download size={13} />
                  {exporting ? 'Exporting…' : 'Export CSV'}
                </button>
              </Can>
            </div>
             {dateRange === 'customRange' && (
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-[var(--border)] pt-3 w-full">
                  <div className='w-[125px]'>
                    <label className="input-label">From:</label>
                    <input
                      type="date"
                      max={todayIso()}
                      value={customFrom}
                      onChange={(e) => setCustomFrom(e.target.value)}
                      className="input-cls h-32px appearance-none pr-7 "
                    /></div>
                  <div className='w-[125px]'>
                    <label className="input-label">To:</label>
                    <input
                      type="date"
                      max={todayIso()}
                      value={customTo}
                      onChange={(e) => setCustomTo(e.target.value)}
                      className="input-cls h-32px appearance-none pr-7 "
                    />
                  </div>
                </div>
              )}

            {dateError && (
              <p
                role="alert"
                aria-live="assertive"
                className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700"
              >
                {dateError}
              </p>
            )}


          </div>
          <div className="overflow-x-auto rounded-lg border border-[var(--border)] table-holder">
            <div className="flex flex-wrap items-center justify-between gap-3 border border-[var(--border)] px-[12px] py-[8px]">
              <div className="flex flex-wrap items-center justify-between gap-3 w-full">
                <div className="flex items-center gap-2">
                  <span className="input-label">View:</span>
                  <div className="flex items-center gap-1.5">
                    {VIEW_MODES.map((v) => (
                      <button
                        key={v.key}
                        type="button"
                        onClick={() => setViewMode(v.key)}
                        className={cn(
                          'common-pill',
                          viewMode === v.key
                            ? 'active-pill'
                            : '',
                        )}
                      >
                        {v.label}
                      </button>
                    ))}
                  </div>
                </div>
                <span className="text-xs text-[var(--text-muted)] font-medium flex gap-1 ml-auto">
                  <Calendar size={14} />
                  <strong className="text-[var(--text-secondary)]">{filterSummaryText}</strong>
                </span>
              </div>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-[12px] py-[8px]">
              <h4 className="mb-2"> Active Exceptions — {viewMode === 'rail' ? 'By Rail' : viewMode === 'channel' ? 'By Channel' : 'By Status'}</h4>

            </div>

            <div className="overflow-x-auto">
              {activeLoading ? (
                <div className="flex h-48 items-center justify-center">
                  <LoadingSpinner />
                </div>
              ) : viewMode === 'rail' ? (
                <table className="w-full min-w-max text-sm">
                  <thead>
                    <tr>
                      <th>RAIL</th>
                      <th >TOTAL</th>
                      <th  style={{ color: C.amber }}>FORMAT / VALIDATION</th>
                      <th >DUPLICATE</th>
                      <th style={{ color: C.red }}>ACCOUNT ERROR</th>
                      <th style={{ color: C.purple }}>COMPLIANCE / AML</th>
                      <th style={{ color: C.blue }}>SETTLEMENT / CB</th>
                      <th>TIMEOUT</th>
                      <th  style={{ color: C.red }}>SLA BREACHED</th>
                      <th>ACTION</th>
                    </tr>
                  </thead>
                  <tbody >
                    {(railQuery.data?.rails ?? []).map((r) => {
                      const badge = railBadgeColor(r.rail);
                      return (
                        <tr key={r.rail} >
                          <td >
                            <span
                              className="common-badge"
                              style={{ backgroundColor: badge.bg, color: badge.fg }}
                            >
                              {r.rail}
                            </span>
                          </td>
                          <td className={cn('font-bold text-[var(--text-primary)]')}>{n(r.total)}</td>
                          <td className={cn('font-semibold')} style={{ color: C.amber }}>{n(r.formatValidation)}</td>
                          <td>{n(r.duplicate)}</td>
                          <td style={{ color: C.red }}>{n(r.accountError)}</td>
                          <td style={{ color: C.purple }}>{n(r.complianceAml)}</td>
                          <td style={{ color: C.blue }}>{n(r.settlementCb)}</td>
                          <td >{n(r.timeout)}</td>
                          <td style={{ color: C.red }}>{n(r.slaBreached)}</td>
                          <td >
                            <ViewQueueLink itemKey={r.rail}  />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr >
                      <td className="px-3.5 py-3 text-xs font-black uppercase text-[var(--text-primary)]">Total</td>
                      <td className={cn('font-bold text-[var(--text-primary)]')}>{n(summary.totalExceptions)}</td>
                      <td className={cn('font-bold')} style={{ color: C.amber }}>{n(summary.formatValidation)}</td>
                      <td >{n(summary.duplicate)}</td>
                      <td className={cn('font-bold')} style={{ color: C.red }}>{n(summary.accountError)}</td>
                      <td className={cn('font-bold')} style={{ color: C.purple }}>{n(summary.complianceAml)}</td>
                      <td className={cn('font-bold')} style={{ color: C.blue }}>{n(summary.settlementCb)}</td>
                      <td >{n(summary.timeout)}</td>
                      <td className={cn('font-bold')} style={{ color: C.red }}>{n(summary.slaBreached)}</td>
                      <td  />
                    </tr>
                  </tfoot>
                </table>
              ) : viewMode === 'channel' ? (
                <table className="w-full min-w-max text-sm">
                  <thead>
                    <tr className="border-b border-[var(--border)] ">
                      <th >CHANNEL</th>
                      <th>TOTAL</th>
                      <th style={{ color: C.amber }}>FORMAT / VALIDATION</th>
                      <th >DUPLICATE</th>
                      <th  style={{ color: C.red }}>ACCOUNT ERROR</th>
                      <th  style={{ color: C.purple }}>COMPLIANCE / AML</th>
                      <th  style={{ color: C.blue }}>SETTLEMENT / CB</th>
                      <th >TIMEOUT</th>
                      <th  style={{ color: C.red }}>SLA BREACHED</th>
                      <th >ACTION</th>
                    </tr>
                  </thead>
                  <tbody >
                    {(channelQuery.data?.channels ?? []).map((r) => (
                      <tr key={r.channel} >
                        <td className={cn('font-semibold text-[var(--text-primary)]')}>{r.channel}</td>
                        <td className={cn('font-bold text-[var(--text-primary)]')}>{n(r.total)}</td>
                        <td className={cn('font-semibold')} style={{ color: C.amber }}>{n(r.formatValidation)}</td>
                        <td >{n(r.duplicate)}</td>
                        <td className={cn( 'font-bold')} style={{ color: C.red }}>{n(r.accountError)}</td>
                        <td className={cn('font-semibold')} style={{ color: C.purple }}>{n(r.complianceAml)}</td>
                        <td className={cn('font-semibold')} style={{ color: C.blue }}>{n(r.settlementCb)}</td>
                        <td >{n(r.timeout)}</td>
                        <td className={cn('font-bold')} style={{ color: C.red }}>{n(r.slaBreached)}</td>
                        <td >
                          <ViewQueueLink itemKey={r.channel} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr >
                      <td className="px-3.5 py-3 text-xs font-black uppercase text-[var(--text-primary)]">Total</td>
                      <td className={cn('font-bold text-[var(--text-primary)]')}>{n(summary.totalExceptions)}</td>
                      <td className={cn( 'font-bold')} style={{ color: C.amber }}>{n(summary.formatValidation)}</td>
                      <td >{n(summary.duplicate)}</td>
                      <td className={cn('font-bold')} style={{ color: C.red }}>{n(summary.accountError)}</td>
                      <td className={cn('font-bold')} style={{ color: C.purple }}>{n(summary.complianceAml)}</td>
                      <td className={cn('font-bold')} style={{ color: C.blue }}>{n(summary.settlementCb)}</td>
                      <td >{n(summary.timeout)}</td>
                      <td className={cn('font-bold')} style={{ color: C.red }}>{n(summary.slaBreached)}</td>
                      <td />
                    </tr>
                  </tfoot>
                </table>
              ) : (
                <table >
                  <thead>
                    <tr >
                      <th >FAILURE / EXCEPTION TYPE</th>
                      <th >COUNT</th>
                      <th>% OF TOTAL</th>
                      <th  style={{ backgroundColor: 'rgba(220,38,38,0.06)', color: C.red }}>CRITICAL</th>
                      <th style={{ backgroundColor: 'rgba(154,52,18,0.06)', color: C.burntOrange }}>HIGH</th>
                      <th  style={{ backgroundColor: 'rgba(37,99,235,0.06)', color: C.blue }}>MEDIUM</th>
                      <th >LOW</th>
                      <th >ACTION</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border-light)]">
                    {(statusQuery.data?.statuses ?? []).map((s) => {
                      const count = s.total ?? 0;
                      const pct = statusTotals.count ? Math.round((count / statusTotals.count) * 100) : 0;
                      return (
                        <tr key={s.exceptionType} >
                          <td >{s.exceptionType}</td>
                          <td className={cn('text-[var(--text-primary)]')}>{n(count)}</td>
                          <td >{statusTotals.count ? `${pct}%` : '0%'}</td>
                          <td className={cn( 'text-red-700')}>{n(s.critical)}</td>
                          <td className={cn( 'text-amber-800 ')}>{n(s.high)}</td>
                          <td className={cn('text-blue-700 ')}>{n(s.medium)}</td>
                          <td >{n(s.low)}</td>
                          <td >
                            <ViewQueueLink />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr >
                      <td >Total</td>
                      <td className={cn('font-bold text-[var(--text-primary)]')}>{n(statusTotals.count)}</td>
                      <td >{statusTotals.count ? '100%' : '0%'}</td>
                      <td className={cn('font-bold text-red-700 ')}>{n(statusTotals.critical)}</td>
                      <td className={cn('font-bold text-amber-800 ')}>{n(statusTotals.high)}</td>
                      <td className={cn( 'font-bold text-blue-700 ')}>{n(statusTotals.medium)}</td>
                      <td >{n(statusTotals.low)}</td>
                      <td  />
                    </tr>
                  </tfoot>
                </table>
              )}
            </div>

          </div>

          {/* View Mode Selection Pills */}



        </div>
      </PageBody>
    </PageShell>
  );
}