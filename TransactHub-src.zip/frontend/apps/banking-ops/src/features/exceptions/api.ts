import { bankingApi } from '../../shared/api/bankingApi';
import { toUtcRangeParams } from '@paymenthub/ui';
import type {
  DisputeRecord,
  ExceptionFilterRequest,
  ExceptionListParams,
  ExceptionListResponse,
  ExceptionRecord,
  ExceptionSummary,
  ExceptionsByChannelResponse,
  ExceptionsByRailResponse,
  ExceptionsByStatusResponse,
  ExceptionViewMode,
} from './types';

/**
 * GET /api/exceptions returns different shapes by param:
 *   - ?take=N            → a raw ExceptionRecord[] array
 *   - ?page=&pageSize=   → a paginated { items, total, page, pageSize }
 * Normalize both to ExceptionListResponse so callers have one shape.
 */
export const exceptionsApi = {
  list: (params: ExceptionListParams) =>
    bankingApi
      .get<ExceptionListResponse | ExceptionRecord[]>('/exceptions', { params })
      .then((res) => {
        const d = res.data;
        const normalized: ExceptionListResponse = Array.isArray(d)
          ? { items: d, total: d.length, page: 1, pageSize: d.length }
          : d;
        return { ...res, data: normalized };
      }),

  retry: (id: number) => bankingApi.post(`/exceptions/${id}/retry`),

  resolve: (id: number, resolution: string) =>
    bankingApi.post(`/exceptions/${id}/resolve`, { resolution }),
};

/**
 * Query params for the analytics endpoints. Mirrors Angular's
 * ActiveExceptionsService.buildParams — direction/dateType/dateRange always sent,
 * from/to only for custom ranges.
 */
function toParams(filter: ExceptionFilterRequest): Record<string, string> {
  const params: Record<string, string> = {
    direction: filter.direction,
    dateType: filter.dateType,
    dateRange: filter.dateRange,
  };
  // A custom range's days are session-zone days, sent as UTC [from, to) (UTC date-time T-22).
  const { from, to } = toUtcRangeParams(filter.from, filter.to);
  if (from) params.from = from;
  if (to) params.to = to;
  return params;
}

/**
 * Active-Exceptions analytics drill-down.
 * Real endpoints under /api/ops/exceptions (Operations API — ExceptionEndpoints.cs).
 */
export const activeExceptionsApi = {
  summary: (filter: ExceptionFilterRequest) =>
    bankingApi
      .get<ExceptionSummary>('/ops/exceptions/summary', { params: toParams(filter) })
      .then((r) => r.data),

  byRail: (filter: ExceptionFilterRequest) =>
    bankingApi
      .get<ExceptionsByRailResponse>('/ops/exceptions/by-rail', { params: toParams(filter) })
      .then((r) => r.data),

  byChannel: (filter: ExceptionFilterRequest) =>
    bankingApi
      .get<ExceptionsByChannelResponse>('/ops/exceptions/by-channel', { params: toParams(filter) })
      .then((r) => r.data),

  byStatus: (filter: ExceptionFilterRequest) =>
    bankingApi
      .get<ExceptionsByStatusResponse>('/ops/exceptions/by-status', { params: toParams(filter) })
      .then((r) => r.data),

  /**
   * CSV export for the active view. The backend returns the CSV payload as a
   * (JSON-encoded) string body; axios decodes it back to a plain string.
   */
  exportCsv: (view: ExceptionViewMode, filter: ExceptionFilterRequest) =>
    bankingApi
      .get<string>(`/ops/exceptions/by-${view}/export`, {
        params: toParams(filter),
        // See the note on `tpsExportCsv` — keeps the CSV a string rather than parsed JSON.
        responseType: 'text',
      })
      .then((r) => r.data),
};

/** Disputes — GET /api/disputes (ExceptionHandler service, real endpoint). */
export const disputesApi = {
  list: (params: { tenantId?: string; take?: number } = {}) =>
    bankingApi.get<DisputeRecord[]>('/disputes', { params }).then((r) => r.data ?? []),
};
