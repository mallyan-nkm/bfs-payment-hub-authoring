import { useQuery } from '@tanstack/react-query';
import { RefreshCw } from 'lucide-react';
import { Badge, Button, DataTable, cn, PageToolbar, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { disputesApi } from './api';
import type { DisputeRecord } from './types';

function slaDaysLabel(deadline: string | null): string {
  if (!deadline) return '-';
  const ms = new Date(deadline).getTime();
  if (Number.isNaN(ms)) return '-';
  const days = Math.ceil((ms - Date.now()) / 86_400_000);
  return days >= 0 ? `${days}d` : `${Math.abs(days)}d overdue`;
}

function statusVariant(status: string): 'green' | 'amber' | 'red' {
  const s = status.toUpperCase();
  if (s === 'RESOLVED' || s === 'CLOSED') return 'green';
  if (s === 'REJECTED') return 'red';
  return 'amber';
}

const fmtAmount = (r: DisputeRecord) =>
  r.disputedAmount != null
    ? `${r.disputedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${r.currency ?? 'AED'}`
    : '—';

export function DisputesPanel() {
  const { data, isFetching, refetch } = useQuery({
    queryKey: ['disputes', 'all'],
    queryFn: () => disputesApi.list({ take: 200 }),
  });

  const rows = data ?? [];

  const columns: DataTableColumn<DisputeRecord>[] = [
    { key: 'disputeId', header: 'ID', render: (d) => <span className="font-mono text-xs">{d.disputeId}</span> },
    {
      key: 'transactionId',
      header: 'Transaction',
      render: (d) => <span className="font-mono text-xs text-[var(--text-secondary)]">{d.transactionId}</span>,
    },
    { key: 'disputeType', header: 'Type', render: (d) => <Badge variant="amber">{d.disputeType}</Badge> },
    { key: 'raisedBy', header: 'Raised By', render: (d) => d.raisedBy || '-' },
    { key: 'disputedAmount', header: 'Amount', align: 'right', render: fmtAmount },
    { key: 'status', header: 'Status', render: (d) => <Badge variant={statusVariant(d.status)}>{d.status}</Badge> },
    { key: 'slaDeadline', header: 'SLA Days', render: (d) => <span className="text-[var(--text-secondary)]">{slaDaysLabel(d.slaDeadline)}</span> },
  ];

  return (
    <>
      <PageToolbar className="items-center">
        <span className="text-sm font-medium text-[var(--text-secondary)]">Payment Disputes</span>
        <span className="text-xs text-[var(--text-muted)]">{rows.length} open</span>
        <Button variant="ghost" size="sm" className="ml-auto" onClick={() => refetch()} disabled={isFetching}>
          <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
        </Button>
      </PageToolbar>
      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={rows}
            rowKey={(d) => String(d.id ?? d.disputeId)}
            loading={isFetching}
            pageSize={25}
            emptyTitle="No disputes"
            emptyMessage="No payment disputes are currently open."
          />
        </div>
      </PageBody>
    </>
  );
}
