export type FraudAlertSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type FraudAlertStatus = 'NEW' | 'ACKNOWLEDGED' | 'ESCALATED' | 'RESOLVED';

export interface FraudAlert {
  id: string;
  severity: FraudAlertSeverity;
  ruleName: string;
  paymentId?: string;
  triggeredAt: string;
  status: FraudAlertStatus;
  description?: string;
  tenantId: string;
}

export interface FraudAlertListParams {
  page?: number;
  pageSize?: number;
  severity?: FraudAlertSeverity[];
  status?: FraudAlertStatus[];
}
