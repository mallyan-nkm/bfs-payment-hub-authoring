import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { RefreshCw } from 'lucide-react';
import { Badge, Button, DataTable, EmptyState, PageBody, PageHeader, PageShell, PaginationBar, Paginator, cn, useRealtimeChannel, useSessionDateTime } from '@paymenthub/ui';
import type { DataTableColumn, DataTableSort } from '@paymenthub/ui';
import { fraudAlertsApi } from './api';
import type { FraudAlert, FraudAlertListParams } from './types';
import { useActiveTenantId, useCurrentUsername, useOfflineAwareAction } from '../../../shared/hooks/useOfflineAwareAction';

const SEVERITY_BADGE: Record<FraudAlert['severity'], 'default' | 'amber' | 'red' | 'purple'> = {
  LOW: 'default',
  MEDIUM: 'amber',
  HIGH: 'red',
  CRITICAL: 'purple',
};

const STATUS_BADGE: Record<FraudAlert['status'], 'blue' | 'amber' | 'red' | 'green'> = {
  NEW: 'blue',
  ACKNOWLEDGED: 'amber',
  ESCALATED: 'red',
  RESOLVED: 'green',
};

export function FraudAlertsPage() {
  const { formatInstant } = useSessionDateTime();
  const queryClient = useQueryClient();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<DataTableSort | undefined>(undefined);
  const [message, setMessage] = useState<string | null>(null);
  const pageSize = 20;

  const { messages: liveAlerts, status: liveStatus, clear: clearLive } = useRealtimeChannel<FraudAlert>('fraud-alerts');

  const params: FraudAlertListParams = useMemo(() => ({ page, pageSize }), [page]);

  const { data, isFetching, refetch } = useQuery({
    queryKey: ['fraud-alerts', params],
    queryFn: () => fraudAlertsApi.list(params).then((r) => r.data),
  });

  const ackMutation = useMutation({
    mutationFn: async (alert: FraudAlert) =>
      offlineAwareAction({
        endpoint: `/fraud/alerts/${alert.id}/acknowledge`,
        method: 'POST',
        payload: {},
        auditEntry: {
          eventType: 'FRAUD_ALERT_ACKNOWLEDGED',
          resourceType: 'FraudAlert',
          resourceId: alert.id,
          user: username,
          tenantId,
          details: { ruleName: alert.ruleName },
          action: 'ACKNOWLEDGE',
        },
      }),
    onSuccess: (result) => {
      setMessage(result.queued ? 'Queued — will sync when back online' : null);
      queryClient.invalidateQueries({ queryKey: ['fraud-alerts'] });
    },
  });

  const escalateMutation = useMutation({
    mutationFn: async (alert: FraudAlert) =>
      offlineAwareAction({
        endpoint: `/fraud/alerts/${alert.id}/escalate`,
        method: 'POST',
        payload: { reason: 'Escalated from alerts feed' },
        auditEntry: {
          eventType: 'FRAUD_ALERT_ESCALATED',
          resourceType: 'FraudAlert',
          resourceId: alert.id,
          user: username,
          tenantId,
          details: { ruleName: alert.ruleName },
          action: 'ESCALATE',
        },
      }),
    onSuccess: (result) => {
      setMessage(result.queued ? 'Queued — will sync when back online' : null);
      queryClient.invalidateQueries({ queryKey: ['fraud-alerts'] });
    },
  });

  const alerts = data?.items ?? [];
  const total = data?.total ?? 0;
  const pag = new Paginator(total, pageSize, page);

  const recentLive = [...liveAlerts].reverse();

  const columns: DataTableColumn<FraudAlert>[] = [
    { key: 'ruleName', header: 'Rule' },
    { key: 'paymentId', header: 'Payment', render: (a) => a.paymentId ?? '—' },
    {
      key: 'severity',
      header: 'Severity',
      sortable: true,
      render: (a) => <Badge variant={SEVERITY_BADGE[a.severity]}>{a.severity}</Badge>,
    },
    { key: 'status', header: 'Status', render: (a) => <Badge variant={STATUS_BADGE[a.status]}>{a.status}</Badge> },
    {
      key: 'triggeredAt',
      header: 'Triggered',
      sortable: true,
      kind: 'instant',
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (a) => (
        <div className="flex justify-end gap-2">
          <Button
            variant="secondary"
            size="sm"
            disabled={a.status !== 'NEW' || ackMutation.isPending}
            onClick={(e) => {
              e.stopPropagation();
              ackMutation.mutate(a);
            }}
          >
            Acknowledge
          </Button>
          <Button
            variant="danger"
            size="sm"
            disabled={a.status === 'ESCALATED' || a.status === 'RESOLVED' || escalateMutation.isPending}
            onClick={(e) => {
              e.stopPropagation();
              escalateMutation.mutate(a);
            }}
          >
            Escalate
          </Button>
        </div>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Fraud Alerts"
        subtitle={`Live feed: ${liveStatus} · ${total} historical alert${total !== 1 ? 's' : ''}`}
        actions={
          <Button variant="ghost" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
          </Button>
        }
      />

      {message && <p className="px-6 pt-3 text-sm text-[var(--accent-amber)] shrink-0">{message}</p>}

      <div className="border-b border-[var(--border)] bg-[var(--bg-secondary)] px-6 py-3 shrink-0">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-medium text-[var(--text-primary)]">Live alerts</h2>
          {liveAlerts.length > 0 && (
            <Button variant="ghost" size="sm" onClick={clearLive}>
              Clear feed
            </Button>
          )}
        </div>
        {recentLive.length === 0 ? (
          <EmptyState title="No live alerts" message="Waiting for new fraud alerts to arrive." />
        ) : (
          <ul className="flex max-h-48 flex-col gap-2 overflow-auto">
            {recentLive.map((alert) => (
              <li
                key={alert.id}
                className="flex items-center justify-between rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2 text-sm"
              >
                <div className="flex items-center gap-2">
                  <Badge variant={SEVERITY_BADGE[alert.severity]}>{alert.severity}</Badge>
                  <span className="text-[var(--text-primary)]">{alert.ruleName}</span>
                  {alert.paymentId && (
                    <span className="font-mono text-xs text-[var(--text-muted)]">{alert.paymentId}</span>
                  )}
                </div>
                <span className="text-xs text-[var(--text-muted)]">
                  {formatInstant(alert.triggeredAt, 'time')}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={alerts}
            rowKey={(a) => a.id}
            loading={isFetching}
            sort={sort}
            onSortChange={setSort}
            emptyTitle="No fraud alerts"
            emptyMessage="No historical fraud alerts found."
          />
        </div>
      </PageBody>

      {total > pageSize && (
        <div className="border-t border-[var(--border)] px-6 py-3 shrink-0">
          <PaginationBar paginator={pag} onPageChange={setPage} />
        </div>
      )}
    </PageShell>
  );
}
