import { bankingApi } from '../../../shared/api/bankingApi';
import type { PaginatedResponse } from '@paymenthub/ui';
import type { FraudAlert, FraudAlertListParams } from './types';

export const fraudAlertsApi = {
  list: (params: FraudAlertListParams) =>
    bankingApi.get<PaginatedResponse<FraudAlert>>('/fraud/alerts', { params }),

  acknowledge: (id: string) => bankingApi.post<FraudAlert>(`/fraud/alerts/${id}/acknowledge`),

  escalate: (id: string, body: { reason: string }) =>
    bankingApi.post<FraudAlert>(`/fraud/alerts/${id}/escalate`, body),
};
