export type FraudCaseSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type FraudCaseStatus = 'OPEN' | 'INVESTIGATING' | 'CONFIRMED' | 'DISMISSED' | 'CLOSED';

export interface FraudCase {
  id: string;
  paymentId?: string;
  severity: FraudCaseSeverity;
  status: FraudCaseStatus;
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
  description: string;
  tenantId: string;
}

export interface FraudCaseListParams {
  page?: number;
  pageSize?: number;
  severity?: FraudCaseSeverity[];
  status?: FraudCaseStatus[];
  search?: string;
}

export interface FraudCaseHistoryEntry {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  detail?: string;
}
