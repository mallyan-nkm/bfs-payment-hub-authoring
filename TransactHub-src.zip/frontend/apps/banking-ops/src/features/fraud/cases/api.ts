import { bankingApi } from '../../../shared/api/bankingApi';
import type { PaginatedResponse } from '@paymenthub/ui';
import type { FraudCase, FraudCaseHistoryEntry, FraudCaseListParams, FraudCaseStatus } from './types';

export const fraudCasesApi = {
  list: (params: FraudCaseListParams) =>
    bankingApi.get<PaginatedResponse<FraudCase>>('/fraud/cases', { params }),

  get: (id: string) => bankingApi.get<FraudCase>(`/fraud/cases/${id}`),

  getHistory: (id: string) => bankingApi.get<FraudCaseHistoryEntry[]>(`/fraud/cases/${id}/history`),

  updateStatus: (id: string, status: FraudCaseStatus) =>
    bankingApi.patch<FraudCase>(`/fraud/cases/${id}/status`, { status }),
};
