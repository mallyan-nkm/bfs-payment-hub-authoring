import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, EmptyState, LoadingSpinner, PageBody, PageHeader, PageShell, Timeline, useSessionDateTime } from '@paymenthub/ui';
import type { TimelineEvent } from '@paymenthub/ui';
import { fraudCasesApi } from './api';
import type { FraudCaseSeverity, FraudCaseStatus } from './types';
import { useActiveTenantId, useCurrentUsername, useOfflineAwareAction } from '../../../shared/hooks/useOfflineAwareAction';

const SEVERITY_BADGE: Record<FraudCaseSeverity, 'default' | 'amber' | 'red' | 'purple'> = {
  LOW: 'default',
  MEDIUM: 'amber',
  HIGH: 'red',
  CRITICAL: 'purple',
};

const STATUS_BADGE: Record<FraudCaseStatus, 'amber' | 'blue' | 'red' | 'default' | 'green'> = {
  OPEN: 'amber',
  INVESTIGATING: 'blue',
  CONFIRMED: 'red',
  DISMISSED: 'default',
  CLOSED: 'green',
};

export function FraudCaseDetail() {
  const { formatInstant } = useSessionDateTime();
  const { id } = useParams<{ id: string }>();
  const queryClient = useQueryClient();
  const offlineAwareAction = useOfflineAwareAction();
  const username = useCurrentUsername();
  const tenantId = useActiveTenantId();
  const [message, setMessage] = useState<string | null>(null);

  const { data: fraudCase, isLoading: loadingCase } = useQuery({
    queryKey: ['fraud-case', id],
    queryFn: () => fraudCasesApi.get(id!).then((r) => r.data),
    enabled: !!id,
  });

  const { data: history = [], isLoading: loadingHistory } = useQuery({
    queryKey: ['fraud-case-history', id],
    queryFn: () => fraudCasesApi.getHistory(id!).then((r) => r.data),
    enabled: !!id,
  });

  const statusMutation = useMutation({
    mutationFn: async (newStatus: FraudCaseStatus) => {
      if (!id) throw new Error('No case selected');
      return offlineAwareAction({
        endpoint: `/fraud/cases/${id}/status`,
        method: 'PATCH',
        payload: { status: newStatus },
        auditEntry: {
          eventType: 'FRAUD_CASE_STATUS_CHANGED',
          resourceType: 'FraudCase',
          resourceId: id,
          user: username,
          tenantId,
          details: { status: newStatus },
          action: `STATUS_${newStatus}`,
        },
      });
    },
    onSuccess: (result) => {
      setMessage(result.queued ? 'Queued — will sync when back online' : null);
      queryClient.invalidateQueries({ queryKey: ['fraud-case', id] });
      queryClient.invalidateQueries({ queryKey: ['fraud-cases'] });
    },
  });

  if (loadingCase) {
    return (
      <div className="flex h-64 items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (!fraudCase) {
    return <EmptyState title="Case not found" message="This fraud case could not be loaded." />;
  }

  const events: TimelineEvent[] = history.map((h) => ({
    id: h.id,
    timestamp: h.timestamp,
    title: h.action,
    description: h.detail ? `${h.actor} · ${h.detail}` : h.actor,
  }));

  return (
    <PageShell>
      <PageHeader
        title={`Fraud Case ${fraudCase.id}`}
        subtitle={fraudCase.paymentId ? `Payment ${fraudCase.paymentId}` : 'No linked payment'}
        actions={
          <>
            <Badge variant={SEVERITY_BADGE[fraudCase.severity]}>{fraudCase.severity}</Badge>
            <Badge variant={STATUS_BADGE[fraudCase.status]}>{fraudCase.status}</Badge>
          </>
        }
      />

      <PageBody className="flex flex-col gap-6">
      <p className="text-sm text-[var(--text-secondary)]">{fraudCase.description}</p>

      <dl className="grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
        <div>
          <dt className="text-xs text-[var(--text-muted)]">Assigned to</dt>
          <dd className="text-[var(--text-secondary)]">{fraudCase.assignedTo ?? 'Unassigned'}</dd>
        </div>
        <div>
          <dt className="text-xs text-[var(--text-muted)]">Created</dt>
          <dd className="text-[var(--text-secondary)]">{formatInstant(fraudCase.createdAt)}</dd>
        </div>
        <div>
          <dt className="text-xs text-[var(--text-muted)]">Updated</dt>
          <dd className="text-[var(--text-secondary)]">{formatInstant(fraudCase.updatedAt)}</dd>
        </div>
        <div>
          <dt className="text-xs text-[var(--text-muted)]">Tenant</dt>
          <dd className="text-[var(--text-secondary)]">{fraudCase.tenantId}</dd>
        </div>
      </dl>

      {message && <p className="text-sm text-[var(--accent-amber)]">{message}</p>}

      <div className="flex gap-2 border-t border-[var(--border)] pt-4">
        <Button
          variant="secondary"
          size="sm"
          onClick={() => statusMutation.mutate('INVESTIGATING')}
          loading={statusMutation.isPending}
          disabled={fraudCase.status === 'INVESTIGATING'}
        >
          Start Investigation
        </Button>
        <Button
          variant="danger"
          size="sm"
          onClick={() => statusMutation.mutate('CONFIRMED')}
          loading={statusMutation.isPending}
          disabled={fraudCase.status === 'CONFIRMED'}
        >
          Confirm Fraud
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => statusMutation.mutate('DISMISSED')}
          loading={statusMutation.isPending}
          disabled={fraudCase.status === 'DISMISSED'}
        >
          Dismiss
        </Button>
        <Button
          variant="primary"
          size="sm"
          onClick={() => statusMutation.mutate('CLOSED')}
          loading={statusMutation.isPending}
          disabled={fraudCase.status === 'CLOSED'}
        >
          Close Case
        </Button>
      </div>

      <div>
        <h2 className="mb-3 text-sm font-medium text-[var(--text-primary)]">Investigation history</h2>
        {loadingHistory ? (
          <div className="flex justify-center py-6">
            <LoadingSpinner />
          </div>
        ) : (
          <Timeline events={events} emptyMessage="No investigation activity recorded yet." />
        )}
      </div>
      </PageBody>
    </PageShell>
  );
}
