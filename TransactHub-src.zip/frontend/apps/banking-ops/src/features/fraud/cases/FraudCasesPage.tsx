import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { RefreshCw } from 'lucide-react';
import { Badge, Button, DataTable, PageBody, PageHeader, PageShell, PageToolbar, PaginationBar, Paginator, RichSelect, cn } from '@paymenthub/ui';
import type { DataTableColumn, DataTableSort } from '@paymenthub/ui';
import { fraudCasesApi } from './api';
import type { FraudCase, FraudCaseListParams, FraudCaseSeverity, FraudCaseStatus } from './types';

const SEVERITY_OPTIONS: { label: string; value: FraudCaseSeverity }[] = [
  { label: 'Low', value: 'LOW' },
  { label: 'Medium', value: 'MEDIUM' },
  { label: 'High', value: 'HIGH' },
  { label: 'Critical', value: 'CRITICAL' },
];

const STATUS_OPTIONS: { label: string; value: FraudCaseStatus }[] = [
  { label: 'Open', value: 'OPEN' },
  { label: 'Investigating', value: 'INVESTIGATING' },
  { label: 'Confirmed', value: 'CONFIRMED' },
  { label: 'Dismissed', value: 'DISMISSED' },
  { label: 'Closed', value: 'CLOSED' },
];

const SEVERITY_BADGE: Record<FraudCaseSeverity, 'default' | 'amber' | 'red' | 'purple'> = {
  LOW: 'default',
  MEDIUM: 'amber',
  HIGH: 'red',
  CRITICAL: 'purple',
};

const STATUS_BADGE: Record<FraudCaseStatus, 'amber' | 'blue' | 'red' | 'default' | 'green'> = {
  OPEN: 'amber',
  INVESTIGATING: 'blue',
  CONFIRMED: 'red',
  DISMISSED: 'default',
  CLOSED: 'green',
};

export function FraudCasesPage() {
  const navigate = useNavigate();
  const [severity, setSeverity] = useState<FraudCaseSeverity[]>([]);
  const [status, setStatus] = useState<FraudCaseStatus[]>([]);
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<DataTableSort | undefined>(undefined);
  const pageSize = 20;

  const params: FraudCaseListParams = useMemo(
    () => ({
      page,
      pageSize,
      severity: severity.length ? severity : undefined,
      status: status.length ? status : undefined,
    }),
    [page, severity, status],
  );

  const { data, isFetching, refetch } = useQuery({
    queryKey: ['fraud-cases', params],
    queryFn: () => fraudCasesApi.list(params).then((r) => r.data),
  });

  const cases = data?.items ?? [];
  const total = data?.total ?? 0;
  const pag = new Paginator(total, pageSize, page);

  const columns: DataTableColumn<FraudCase>[] = [
    { key: 'id', header: 'Case ID', render: (c) => <span className="font-mono text-xs">{c.id}</span> },
    { key: 'paymentId', header: 'Payment', render: (c) => c.paymentId ?? '—' },
    {
      key: 'severity',
      header: 'Severity',
      sortable: true,
      render: (c) => <Badge variant={SEVERITY_BADGE[c.severity]}>{c.severity}</Badge>,
    },
    { key: 'status', header: 'Status', render: (c) => <Badge variant={STATUS_BADGE[c.status]}>{c.status}</Badge> },
    { key: 'assignedTo', header: 'Assigned To', render: (c) => c.assignedTo ?? 'Unassigned' },
    {
      key: 'createdAt',
      header: 'Created',
      sortable: true,
      kind: 'instant',
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Fraud Cases"
        subtitle={`${total} case${total !== 1 ? 's' : ''}`}
        actions={
          <Button variant="ghost" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
          </Button>
        }
      />

      <PageToolbar>
        <RichSelect
          label="Severity"
          options={SEVERITY_OPTIONS}
          value={severity}
          onChange={(v) => {
            setSeverity(v as FraudCaseSeverity[]);
            setPage(1);
          }}
          placeholder="All severities"
          className="w-48"
        />
        <RichSelect
          label="Status"
          options={STATUS_OPTIONS}
          value={status}
          onChange={(v) => {
            setStatus(v as FraudCaseStatus[]);
            setPage(1);
          }}
          placeholder="All statuses"
          className="w-56"
        />
      </PageToolbar>

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={cases}
            rowKey={(c) => c.id}
            loading={isFetching}
            sort={sort}
            onSortChange={setSort}
            onRowClick={(c) => navigate(`/fraud/cases/${c.id}`)}
            emptyTitle="No fraud cases"
            emptyMessage="No fraud cases match the current filters."
          />
        </div>
      </PageBody>

      {total > pageSize && (
        <div className="border-t border-[var(--border)] px-6 py-3 shrink-0">
          <PaginationBar paginator={pag} onPageChange={setPage} />
        </div>
      )}
    </PageShell>
  );
}
