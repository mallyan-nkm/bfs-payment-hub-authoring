import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { EmptyState, LoadingSpinner, PageBody, PageHeader, PageShell } from '@paymenthub/ui';
import { counterparty360Api } from './api';
import { CounterpartyHeader } from './CounterpartyHeader';
import { ExposureSummary } from './ExposureSummary';
import { SanctionsHistory } from './SanctionsHistory';

export function Counterparty360Page() {
  const { id } = useParams<{ id: string }>();

  const { data: counterparty, isLoading, error } = useQuery({
    queryKey: ['counterparty360', id],
    queryFn: () => counterparty360Api.get(id!).then((r) => r.data),
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error || !counterparty) {
    return <EmptyState title="Counterparty not found" message="This counterparty profile could not be loaded." />;
  }

  return (
    <PageShell>
      <PageHeader title="Counterparty 360" />

      <PageBody className="flex flex-col gap-6">
      <CounterpartyHeader counterparty={counterparty} />

      <div>
        <h2 className="mb-3 text-sm font-medium text-[var(--text-primary)]">Exposure</h2>
        <ExposureSummary counterpartyId={counterparty.id} />
      </div>

      <div>
        <h2 className="mb-3 text-sm font-medium text-[var(--text-primary)]">Sanctions history</h2>
        <SanctionsHistory counterpartyId={counterparty.id} />
      </div>
      </PageBody>
    </PageShell>
  );
}
