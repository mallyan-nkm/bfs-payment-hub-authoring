import { bankingApi } from '../../shared/api/bankingApi';
import type { SanctionsHit } from '@paymenthub/ui';
import type { CounterpartyProfile, ExposureData } from './types';

export const counterparty360Api = {
  get: (id: string) => bankingApi.get<CounterpartyProfile>(`/counterparties/${id}`),

  getExposure: (id: string) => bankingApi.get<ExposureData>(`/counterparties/${id}/exposure`),

  getSanctionsHistory: (id: string) =>
    bankingApi.get<SanctionsHit[]>(`/counterparties/${id}/sanctions-history`),
};
