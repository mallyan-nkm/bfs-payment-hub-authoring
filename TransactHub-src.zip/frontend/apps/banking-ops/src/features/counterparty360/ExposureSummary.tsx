import { useQuery } from '@tanstack/react-query';
import { Badge, Card, CardContent, EmptyState, LoadingSpinner, useSessionDateTime } from '@paymenthub/ui';
import { counterparty360Api } from './api';

interface ExposureSummaryProps {
  counterpartyId: string;
}

export function ExposureSummary({ counterpartyId }: ExposureSummaryProps) {
  const { formatInstant } = useSessionDateTime();
  const { data: exposure, isLoading, error } = useQuery({
    queryKey: ['counterparty360-exposure', counterpartyId],
    queryFn: () => counterparty360Api.getExposure(counterpartyId).then((r) => r.data),
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  if (error || !exposure) {
    return <p className="text-sm text-[var(--accent-red)]">Failed to load exposure data.</p>;
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-[var(--text-muted)]">Net exposure</p>
            <p
              className={
                exposure.netExposure >= 0
                  ? 'text-xl font-semibold text-[var(--success)]'
                  : 'text-xl font-semibold text-[var(--danger)]'
              }
            >
              {exposure.netExposure.toLocaleString()} {exposure.netExposureCurrency}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-[var(--text-muted)]">Transaction volume</p>
            <p className="text-xl font-semibold text-[var(--text-primary)]">
              {exposure.transactionVolume.toLocaleString()}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-[var(--text-muted)]">Transaction count</p>
            <p className="text-xl font-semibold text-[var(--text-primary)]">
              {exposure.transactionCount.toLocaleString()}
            </p>
          </CardContent>
        </Card>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-[var(--text-primary)]">Currency breakdown</p>
        {exposure.currencyBreakdown.length === 0 ? (
          <EmptyState title="No breakdown" message="No currency exposure recorded." />
        ) : (
          <ul className="flex flex-wrap gap-2">
            {exposure.currencyBreakdown.map((c) => (
              <li
                key={c.currency}
                className="flex items-center gap-2 rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2 text-sm"
              >
                <Badge variant="outline">{c.currency}</Badge>
                <span className="text-[var(--text-secondary)]">{c.volume.toLocaleString()}</span>
                <span className="text-xs text-[var(--text-muted)]">({c.count} txns)</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <p className="text-xs text-[var(--text-muted)]">As of {formatInstant(exposure.asOf)}</p>
    </div>
  );
}
