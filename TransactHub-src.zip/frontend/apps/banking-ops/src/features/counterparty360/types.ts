export type CounterpartyRelationship = 'CORRESPONDENT' | 'CUSTOMER' | 'INTERBANK' | 'MERCHANT';

export interface CounterpartyProfile {
  id: string;
  name: string;
  bic: string;
  country: string;
  relationshipType: CounterpartyRelationship;
  onboardedAt: string;
  tenantId: string;
}

export interface CurrencyExposure {
  currency: string;
  volume: number;
  count: number;
}

export interface ExposureData {
  counterpartyId: string;
  netExposure: number;
  netExposureCurrency: string;
  transactionVolume: number;
  transactionCount: number;
  currencyBreakdown: CurrencyExposure[];
  asOf: string;
}
