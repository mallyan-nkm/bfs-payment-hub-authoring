import { Badge } from '@paymenthub/ui';
import type { CounterpartyProfile } from './types';

export function CounterpartyHeader({ counterparty }: { counterparty: CounterpartyProfile }) {
  return (
    <div className="flex items-center justify-between border-b border-[var(--border)] pb-4">
      <div>
        <h1 className="text-lg font-semibold text-[var(--text-primary)]">{counterparty.name}</h1>
        <p className="text-sm text-[var(--text-muted)]">
          {counterparty.bic} · {counterparty.country}
        </p>
      </div>
      <Badge variant="outline">{counterparty.relationshipType}</Badge>
    </div>
  );
}
