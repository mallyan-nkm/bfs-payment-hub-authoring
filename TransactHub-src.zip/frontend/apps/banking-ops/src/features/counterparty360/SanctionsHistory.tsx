import { useQuery } from '@tanstack/react-query';
import { LoadingSpinner, Timeline } from '@paymenthub/ui';
import type { TimelineEvent } from '@paymenthub/ui';
import { counterparty360Api } from './api';

interface SanctionsHistoryProps {
  counterpartyId: string;
}

export function SanctionsHistory({ counterpartyId }: SanctionsHistoryProps) {
  const { data: hits = [], isLoading, error } = useQuery({
    queryKey: ['counterparty360-sanctions', counterpartyId],
    queryFn: () => counterparty360Api.getSanctionsHistory(counterpartyId).then((r) => r.data),
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return <p className="text-sm text-[var(--accent-red)]">Failed to load sanctions history.</p>;
  }

  const events: TimelineEvent[] = hits.map((hit) => ({
    id: hit.id,
    timestamp: new Date().toISOString(),
    title: `${hit.listName} match — ${hit.matchedName}`,
    description: `Score ${hit.matchScore}% · ${hit.status}${hit.reviewedBy ? ` · reviewed by ${hit.reviewedBy}` : ''}`,
    variant: hit.status === 'BLOCKED' ? 'danger' : hit.status === 'CLEARED' ? 'success' : 'warning',
  }));

  return <Timeline events={events} emptyMessage="No sanctions screening hits for this counterparty." />;
}
