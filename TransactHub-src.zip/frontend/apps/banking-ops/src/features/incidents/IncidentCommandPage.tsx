import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Phone, Plus, RefreshCw } from 'lucide-react';
import {
  Badge,
  Button,
  Card,
  CardContent,
  Checkbox,
  DataTable,
  Dialog,
  Input,
  LoadingSpinner,
  Select,
  Textarea,
  Timeline,
  cn,
  PageShell,
  PageHeader,
  PageBody,
} from '@paymenthub/ui';
import type { DataTableColumn, TimelineEvent } from '@paymenthub/ui';
import { incidentsApi } from './api';
import type {
  DeclareIncidentPayload,
  Incident,
  IncidentSeverity,
  IncidentStatus,
} from './types';
import { CollaborationPanel } from './CollaborationPanel';
import { useSessionDateTime } from '@paymenthub/ui';

const SEVERITY_VARIANT: Record<IncidentSeverity, 'red' | 'amber' | 'outline'> = {
  critical: 'red',
  high: 'red',
  medium: 'amber',
  low: 'outline',
};

const SEVERITY_OPTIONS: { label: string; value: IncidentSeverity }[] = [
  { label: 'Critical (P1)', value: 'critical' },
  { label: 'High (P2)', value: 'high' },
  { label: 'Medium (P3)', value: 'medium' },
  { label: 'Low (P4)', value: 'low' },
];

const STATUS_OPTIONS: { label: string; value: IncidentStatus }[] = [
  { label: 'Open', value: 'open' },
  { label: 'Investigating', value: 'investigating' },
  { label: 'Mitigated', value: 'mitigated' },
  { label: 'Resolved', value: 'resolved' },
  { label: 'Closed', value: 'closed' },
];

const COMMS_CHANNELS = ['Correspondent Ops', 'Compliance', 'CRO', 'Client Comms'];

const PRESET_LEVERS: { id: string; label: string }[] = [
  { id: 'throttle-swift', label: 'Throttle SWIFT outbound to 50%' },
  { id: 'pause-fx', label: 'Pause automated FX booking' },
  { id: 'reroute-corridor', label: 'Reroute affected corridor to backup rail' },
  { id: 'hold-high-value', label: 'Hold high-value releases for manual review' },
];

type DialogKind = 'declare' | 'status' | 'comms' | 'levers';

const EMPTY_DECLARE: DeclareIncidentPayload = {
  title: '',
  severity: 'medium',
  type: '',
  commander: '',
  affectedScope: '',
};

function CommandField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-[10px] font-medium uppercase tracking-wide text-[var(--text-muted)]">{label}</div>
      <div className="mt-1 text-sm font-medium text-[var(--text-primary)]">{children}</div>
    </div>
  );
}

export function IncidentCommandPage() {
  const { formatInstant } = useSessionDateTime();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [dialog, setDialog] = useState<DialogKind | null>(null);
  const [declareForm, setDeclareForm] = useState<DeclareIncidentPayload>(EMPTY_DECLARE);
  const [nextStatus, setNextStatus] = useState<IncidentStatus>('investigating');
  const [commsMessage, setCommsMessage] = useState('');
  const [commsChannels, setCommsChannels] = useState<string[]>([]);
  const [selectedLevers, setSelectedLevers] = useState<string[]>([]);
  const queryClient = useQueryClient();

  const { data, isFetching, refetch } = useQuery({
    queryKey: ['incidents', 'list'],
    queryFn: () => incidentsApi.list({ page: 1, pageSize: 50 }).then((r) => r.data),
  });

  const incidents = data?.items ?? [];

  const { data: events, isFetching: eventsLoading } = useQuery({
    queryKey: ['incidents', selectedId, 'events'],
    queryFn: () => incidentsApi.getEvents(selectedId!).then((r) => r.data),
    enabled: !!selectedId,
  });

  function invalidateIncident() {
    queryClient.invalidateQueries({ queryKey: ['incidents', 'list'] });
    if (selectedId) {
      queryClient.invalidateQueries({ queryKey: ['incidents', selectedId, 'events'] });
    }
  }

  const declareMutation = useMutation({
    mutationFn: (payload: DeclareIncidentPayload) => incidentsApi.declare(payload).then((r) => r.data),
    onSuccess: (created) => {
      setDialog(null);
      setDeclareForm(EMPTY_DECLARE);
      setSelectedId(created.id);
      queryClient.invalidateQueries({ queryKey: ['incidents', 'list'] });
    },
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: IncidentStatus }) => incidentsApi.updateStatus(id, status),
    onSuccess: () => {
      setDialog(null);
      invalidateIncident();
    },
  });

  const commsMutation = useMutation({
    mutationFn: ({ id, message, channels }: { id: string; message: string; channels: string[] }) =>
      incidentsApi.sendCommunication(id, { message, channels }),
    onSuccess: () => {
      setDialog(null);
      setCommsMessage('');
      setCommsChannels([]);
      invalidateIncident();
    },
  });

  const leversMutation = useMutation({
    mutationFn: ({ id, leverIds }: { id: string; leverIds: string[] }) => incidentsApi.activateLevers(id, leverIds),
    onSuccess: () => {
      setDialog(null);
      setSelectedLevers([]);
      invalidateIncident();
    },
  });

  const timelineEvents: TimelineEvent[] = (events ?? []).map((e) => ({
    id: e.id,
    timestamp: e.timestamp,
    title: e.title,
    description: e.description,
    variant: e.variant,
  }));

  const columns: DataTableColumn<Incident>[] = [
    { key: 'id', header: 'ID', render: (row) => <span className="font-mono text-xs">{row.id}</span> },
    { key: 'title', header: 'Title' },
    {
      key: 'severity',
      header: 'Severity',
      sortable: true,
      render: (row) => <Badge variant={SEVERITY_VARIANT[row.severity]}>{row.severity}</Badge>,
    },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <Badge variant="outline">{row.status}</Badge> },
    {
      key: 'openedAt',
      header: 'Opened',
      sortable: true,
      kind: 'instant',
    },
    { key: 'owner', header: 'Owner' },
  ];

  const selectedIncident = incidents.find((i) => i.id === selectedId) ?? null;
  const isTerminal = selectedIncident?.status === 'resolved' || selectedIncident?.status === 'closed';

  function toggleChannel(channel: string, checked: boolean) {
    setCommsChannels((prev) => (checked ? [...prev, channel] : prev.filter((c) => c !== channel)));
  }

  function toggleLever(id: string, checked: boolean) {
    setSelectedLevers((prev) => (checked ? [...prev, id] : prev.filter((l) => l !== id)));
  }

  return (
    <PageShell>
      <PageHeader
        title="Incident Command"
        subtitle={
          <>
            Response coordination workspace · {incidents.length} incident{incidents.length !== 1 ? 's' : ''}
          </>
        }
        actions={
          <>
            <Button variant="ghost" size="sm" onClick={() => refetch()} disabled={isFetching}>
              <RefreshCw size={14} className={cn(isFetching && 'animate-spin')} />
            </Button>
            <Button variant="danger" size="sm" onClick={() => { setDeclareForm(EMPTY_DECLARE); setDialog('declare'); }}>
              <Plus size={14} /> Declare Incident
            </Button>
          </>
        }
      />

      <PageBody className="flex flex-col gap-6">
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={incidents}
            rowKey={(row) => row.id}
            loading={isFetching}
            onRowClick={(row) => setSelectedId(row.id === selectedId ? null : row.id)}
            emptyTitle="No incidents"
            emptyMessage="There are no active or recent incidents."
          />
        </div>

        {selectedIncident && (
          <div className="flex flex-col gap-6 border-t border-[var(--border)] pt-6">
            {/* Command panel */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-sm font-bold text-[var(--text-primary)]">{selectedIncident.id}</span>
                  <Badge variant={SEVERITY_VARIANT[selectedIncident.severity]}>{selectedIncident.severity}</Badge>
                  <Badge variant="outline">{selectedIncident.status}</Badge>
                  <span className="ml-auto text-xs text-[var(--text-muted)]">
                    Declared {formatInstant(selectedIncident.openedAt)}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  <CommandField label="Type">{selectedIncident.type ?? selectedIncident.affectedRail ?? '—'}</CommandField>
                  <CommandField label="Incident Commander">{selectedIncident.commander ?? selectedIncident.owner}</CommandField>
                  <CommandField label="Affected Scope">{selectedIncident.affectedScope ?? '—'}</CommandField>
                  <CommandField label="Value at Risk">
                    {selectedIncident.valueAtRisk != null ? (
                      <span className="font-mono">
                        {(selectedIncident.valueAtRiskCurrency ?? 'AED')}{' '}
                        {selectedIncident.valueAtRisk.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    ) : (
                      '—'
                    )}
                  </CommandField>
                  <CommandField label="Stakeholders">
                    {selectedIncident.stakeholders && selectedIncident.stakeholders.length > 0
                      ? selectedIncident.stakeholders.join(' · ')
                      : '—'}
                  </CommandField>
                  <CommandField label="Bridge Call">
                    {selectedIncident.bridgeCallUrl ? (
                      <a
                        href={selectedIncident.bridgeCallUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 font-semibold text-[var(--accent-blue)] hover:underline"
                      >
                        <Phone size={13} /> Join
                        {selectedIncident.bridgeActiveCount != null ? ` (${selectedIncident.bridgeActiveCount} active)` : ''}
                      </a>
                    ) : (
                      '—'
                    )}
                  </CommandField>
                </div>

                {/* Action bar */}
                <div className="mt-6 flex flex-wrap justify-end gap-2 border-t border-[var(--border)] pt-4">
                  <Button variant="secondary" size="sm" onClick={() => { setNextStatus(selectedIncident.status); setDialog('status'); }}>
                    Update Status
                  </Button>
                  <Button variant="secondary" size="sm" onClick={() => setDialog('comms')}>
                    Communications
                  </Button>
                  <Button variant="secondary" size="sm" onClick={() => setDialog('levers')}>
                    Activate Levers
                  </Button>
                  <Button
                    variant="primary"
                    size="sm"
                    disabled={isTerminal}
                    loading={statusMutation.isPending && statusMutation.variables?.status === 'resolved'}
                    onClick={() => statusMutation.mutate({ id: selectedIncident.id, status: 'resolved' })}
                  >
                    Mark Resolved
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h2 className="text-sm font-semibold text-[var(--text-primary)] mb-3">
                  {selectedIncident.title} — Timeline
                </h2>
                {eventsLoading ? (
                  <div className="flex items-center justify-center py-6">
                    <LoadingSpinner />
                  </div>
                ) : (
                  <Timeline events={timelineEvents} emptyMessage="No events recorded for this incident." />
                )}
              </div>
              <CollaborationPanel incidentId={selectedIncident.id} />
            </div>
          </div>
        )}
      </PageBody>

      {/* Declare Incident */}
      <Dialog
        open={dialog === 'declare'}
        onOpenChange={(open) => !open && setDialog(null)}
        title="Declare Incident"
        description="Opens the war room and pages the on-call response team."
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDialog(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              size="sm"
              disabled={!declareForm.title.trim()}
              loading={declareMutation.isPending}
              onClick={() => declareMutation.mutate(declareForm)}
            >
              Declare
            </Button>
          </>
        }
      >
        <div className="flex flex-col gap-3">
          <Input label="Title" value={declareForm.title} onChange={(e) => setDeclareForm({ ...declareForm, title: e.target.value })} />
          <Select
            label="Severity"
            options={SEVERITY_OPTIONS}
            value={declareForm.severity}
            onValueChange={(v) => setDeclareForm({ ...declareForm, severity: v as IncidentSeverity })}
          />
          <Input label="Type" value={declareForm.type} onChange={(e) => setDeclareForm({ ...declareForm, type: e.target.value })} />
          <Input label="Incident Commander" value={declareForm.commander} onChange={(e) => setDeclareForm({ ...declareForm, commander: e.target.value })} />
          <Input label="Affected Scope" value={declareForm.affectedScope} onChange={(e) => setDeclareForm({ ...declareForm, affectedScope: e.target.value })} />
        </div>
      </Dialog>

      {/* Update Status */}
      <Dialog
        open={dialog === 'status'}
        onOpenChange={(open) => !open && setDialog(null)}
        title="Update Status"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDialog(null)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              loading={statusMutation.isPending}
              disabled={!selectedIncident}
              onClick={() => selectedIncident && statusMutation.mutate({ id: selectedIncident.id, status: nextStatus })}
            >
              Update
            </Button>
          </>
        }
      >
        <Select label="Status" options={STATUS_OPTIONS} value={nextStatus} onValueChange={(v) => setNextStatus(v as IncidentStatus)} />
      </Dialog>

      {/* Communications */}
      <Dialog
        open={dialog === 'comms'}
        onOpenChange={(open) => !open && setDialog(null)}
        title="Send Communication"
        description="Notify stakeholders of the current incident status."
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDialog(null)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              disabled={!selectedIncident || !commsMessage.trim() || commsChannels.length === 0}
              loading={commsMutation.isPending}
              onClick={() =>
                selectedIncident &&
                commsMutation.mutate({ id: selectedIncident.id, message: commsMessage, channels: commsChannels })
              }
            >
              Send
            </Button>
          </>
        }
      >
        <div className="flex flex-col gap-3">
          <Textarea
            placeholder="Communication to stakeholders…"
            value={commsMessage}
            onChange={(e) => setCommsMessage(e.target.value)}
            rows={4}
          />
          <div className="flex flex-col gap-2">
            <span className="text-xs font-medium uppercase tracking-wide text-[var(--text-muted)]">Channels</span>
            {COMMS_CHANNELS.map((channel) => (
              <Checkbox
                key={channel}
                label={channel}
                checked={commsChannels.includes(channel)}
                onCheckedChange={(checked) => toggleChannel(channel, checked)}
              />
            ))}
          </div>
        </div>
      </Dialog>

      {/* Activate Levers */}
      <Dialog
        open={dialog === 'levers'}
        onOpenChange={(open) => !open && setDialog(null)}
        title="Activate Levers"
        description="Engage operational levers to contain the incident."
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setDialog(null)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              disabled={!selectedIncident || selectedLevers.length === 0}
              loading={leversMutation.isPending}
              onClick={() => selectedIncident && leversMutation.mutate({ id: selectedIncident.id, leverIds: selectedLevers })}
            >
              Activate
            </Button>
          </>
        }
      >
        <div className="flex flex-col gap-2">
          {PRESET_LEVERS.map((lever) => (
            <Checkbox
              key={lever.id}
              label={lever.label}
              checked={selectedLevers.includes(lever.id)}
              onCheckedChange={(checked) => toggleLever(lever.id, checked)}
            />
          ))}
        </div>
      </Dialog>
    </PageShell>
  );
}
