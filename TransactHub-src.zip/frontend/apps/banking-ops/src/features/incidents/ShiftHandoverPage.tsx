import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Textarea, LoadingSpinner, EmptyState, StepWizard, Badge, PageShell, PageHeader, PageBody, useSessionDateTime } from '@paymenthub/ui';
import type { WizardStep } from '@paymenthub/ui';
import { incidentsApi } from './api';
import { useCurrentUsername, useOfflineAwareAction } from '../../shared/hooks/useOfflineAwareAction';

export function ShiftHandoverPage() {
  const { formatInstant } = useSessionDateTime();
  const [activeStep, setActiveStep] = useState(0);
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState<string | null>(null);
  const username = useCurrentUsername();
  const offlineAwareAction = useOfflineAwareAction();

  const { data, isFetching } = useQuery({
    queryKey: ['shift-handover', 'summary'],
    queryFn: () => incidentsApi.getHandoverSummary().then((r) => r.data),
  });

  const submitHandover = useMutation({
    mutationFn: () => {
      const payload = { notes, signedOffBy: username, signedOffAt: new Date().toISOString() };
      return offlineAwareAction({
        endpoint: '/operations/shift-handover',
        method: 'POST',
        payload,
        auditEntry: {
          eventType: 'SHIFT_HANDOVER_SIGNOFF',
          resourceType: 'ShiftHandover',
          resourceId: payload.signedOffAt,
          user: username,
          tenantId: 'unknown',
          details: { notes },
          action: 'SHIFT_HANDOVER_SIGNOFF',
        },
      });
    },
    onSuccess: (result) => {
      setSubmitted(result.queued ? 'Handover queued — will sync when back online.' : 'Handover submitted.');
    },
  });

  if (isFetching && !data) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (!data) {
    return <EmptyState title="No handover data" message="Unable to load shift handover summary." />;
  }

  const steps: WizardStep[] = [
    {
      id: 'open-items',
      label: 'Open Items Review',
      content: (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-[var(--text-primary)]">Open Items</h3>
          {data.openItems.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">No open items for this shift.</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {data.openItems.map((item) => (
                <li key={item.id} className="rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2">
                  <p className="text-sm font-medium text-[var(--text-primary)]">{item.title}</p>
                  <p className="text-xs text-[var(--text-muted)]">{item.detail}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      ),
    },
    {
      id: 'pending-approvals',
      label: 'Pending Approvals Review',
      content: (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-[var(--text-primary)]">Pending Approvals</h3>
          {data.pendingApprovals.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">No pending approvals.</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {data.pendingApprovals.map((item) => (
                <li
                  key={item.id}
                  className="flex items-center justify-between rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2"
                >
                  <span className="text-sm text-[var(--text-primary)]">{item.reference}</span>
                  <span className="text-sm text-[var(--text-secondary)]">
                    {item.amount.toLocaleString()} {item.currency}
                  </span>
                  <span className="text-xs text-[var(--text-muted)]">
                    Since {formatInstant(item.pendingSince)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      ),
    },
    {
      id: 'incident-status',
      label: 'Incident Status',
      content: (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-[var(--text-primary)]">Active Incidents</h3>
          {data.incidents.length === 0 ? (
            <p className="text-sm text-[var(--text-muted)]">No active incidents.</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {data.incidents.map((inc) => (
                <li
                  key={inc.id}
                  className="flex items-center justify-between rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2"
                >
                  <span className="text-sm text-[var(--text-primary)]">{inc.title}</span>
                  <span className="flex items-center gap-2">
                    <Badge variant="outline">{inc.severity}</Badge>
                    <Badge variant="outline">{inc.status}</Badge>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      ),
    },
    {
      id: 'notes-signoff',
      label: 'Handover Notes & Sign-off',
      content: (
        <div className="flex flex-col gap-3">
          <h3 className="text-sm font-medium text-[var(--text-primary)]">Handover Notes</h3>
          <Textarea
            placeholder="Summarize anything the next shift should know…"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={6}
          />
          <p className="text-xs text-[var(--text-muted)]">
            Signing off as <span className="font-medium text-[var(--text-secondary)]">{username}</span> at{' '}
            {formatInstant(Date.now())}
          </p>
          {submitted && <p className="text-sm text-[var(--accent-green)]">{submitted}</p>}
          {submitHandover.isError && (
            <p className="text-sm text-[var(--accent-red)]">Failed to submit handover. Please try again.</p>
          )}
        </div>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Shift Handover"
        subtitle={
          <>
            Shift {formatInstant(data.shiftStart)} – {formatInstant(data.shiftEnd)}
          </>
        }
      />
      <PageBody>
        <StepWizard
          steps={steps}
          activeStep={activeStep}
          onStepChange={setActiveStep}
          isStepValid={(idx) => (idx === steps.length - 1 ? notes.trim().length > 0 : true)}
          onComplete={() => submitHandover.mutate()}
          completeLabel="Sign Off & Submit"
          busy={submitHandover.isPending}
        />
      </PageBody>
    </PageShell>
  );
}
