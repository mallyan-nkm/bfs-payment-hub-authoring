export type IncidentSeverity = 'critical' | 'high' | 'medium' | 'low';
export type IncidentStatus = 'open' | 'investigating' | 'mitigated' | 'resolved' | 'closed';

export interface Incident {
  id: string;
  title: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  openedAt: string;
  owner: string;
  description?: string;
  affectedRail?: string;
  /** Incident category, e.g. "Scheme Issue — SWIFT GPI Delays". */
  type?: string;
  /** Named incident commander leading the response. */
  commander?: string;
  /** Human summary of impact scope, e.g. "EMEA Corridor · 23 in-flight". */
  affectedScope?: string;
  /** Monetary exposure held up by the incident. */
  valueAtRisk?: number;
  valueAtRiskCurrency?: string;
  /** Teams engaged on the response bridge. */
  stakeholders?: string[];
  /** Join URL for the live incident bridge call. */
  bridgeCallUrl?: string;
  /** Participants currently on the bridge. */
  bridgeActiveCount?: number;
}

export interface DeclareIncidentPayload {
  title: string;
  severity: IncidentSeverity;
  type: string;
  commander: string;
  affectedScope: string;
}

export interface IncidentCommunicationPayload {
  message: string;
  channels: string[];
}

export interface IncidentEvent {
  id: string;
  timestamp: string;
  title: string;
  description?: string;
  variant?: 'default' | 'success' | 'warning' | 'danger';
}

export interface IncidentComment {
  id: string;
  author: string;
  body: string;
  createdAt: string;
}

export interface HandoverOpenItem {
  id: string;
  title: string;
  detail: string;
}

export interface HandoverPendingApproval {
  id: string;
  reference: string;
  amount: number;
  currency: string;
  pendingSince: string;
}

export interface HandoverIncidentSummary {
  id: string;
  title: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
}

export interface HandoverSummary {
  openItems: HandoverOpenItem[];
  pendingApprovals: HandoverPendingApproval[];
  incidents: HandoverIncidentSummary[];
  shiftStart: string;
  shiftEnd: string;
}

export interface HandoverSubmitPayload {
  notes: string;
  signedOffBy: string;
  signedOffAt: string;
}

export interface IncidentDocument {
  id: string;
  name: string;
  uploadedBy: string;
  uploadedAt: string;
  size: number;
  category: string;
}
