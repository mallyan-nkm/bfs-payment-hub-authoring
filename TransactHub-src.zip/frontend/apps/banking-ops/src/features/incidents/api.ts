import { bankingApi } from '../../shared/api/bankingApi';
import type { PaginatedResponse, WorkflowHistoryEvent, WorkflowRun } from '@paymenthub/ui';
import type {
  DeclareIncidentPayload,
  HandoverSubmitPayload,
  HandoverSummary,
  Incident,
  IncidentComment,
  IncidentCommunicationPayload,
  IncidentDocument,
  IncidentEvent,
  IncidentStatus,
} from './types';

export interface IncidentListParams {
  page?: number;
  pageSize?: number;
  status?: string;
  severity?: string;
}

export interface DocumentListParams {
  page?: number;
  pageSize?: number;
  category?: string;
}

export const incidentsApi = {
  list: (params: IncidentListParams) =>
    bankingApi.get<PaginatedResponse<Incident>>('/incidents', { params }),

  get: (id: string) => bankingApi.get<Incident>(`/incidents/${id}`),

  declare: (body: DeclareIncidentPayload) => bankingApi.post<Incident>('/incidents', body),

  updateStatus: (id: string, status: IncidentStatus) =>
    bankingApi.patch<Incident>(`/incidents/${id}/status`, { status }),

  sendCommunication: (id: string, body: IncidentCommunicationPayload) =>
    bankingApi.post(`/incidents/${id}/communications`, body),

  activateLevers: (id: string, leverIds: string[]) =>
    bankingApi.post(`/incidents/${id}/levers`, { leverIds }),

  getEvents: (id: string) => bankingApi.get<IncidentEvent[]>(`/incidents/${id}/events`),

  addComment: (id: string, body: string) =>
    bankingApi.post<IncidentComment>(`/incidents/${id}/comments`, { body }),

  listComments: (id: string) => bankingApi.get<IncidentComment[]>(`/incidents/${id}/comments`),

  getHandoverSummary: () => bankingApi.get<HandoverSummary>('/operations/shift-handover/summary'),

  submitHandover: (payload: HandoverSubmitPayload) =>
    bankingApi.post('/operations/shift-handover', payload),

  searchWorkflowRun: (workflowId: string) =>
    bankingApi.get<WorkflowRun>(`/workflows/${encodeURIComponent(workflowId)}`),

  getWorkflowHistory: (workflowId: string) =>
    bankingApi.get<WorkflowHistoryEvent[]>(`/workflows/${encodeURIComponent(workflowId)}/history`),

  listDocuments: (params: DocumentListParams) =>
    bankingApi.get<PaginatedResponse<IncidentDocument>>('/incidents/documents', { params }),

  uploadDocument: (files: File[], category: string) => {
    const formData = new FormData();
    files.forEach((file) => formData.append('files', file));
    formData.append('category', category);
    return bankingApi.post<IncidentDocument[]>('/incidents/documents', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  deleteDocument: (id: string) => bankingApi.delete(`/incidents/documents/${id}`),
};
