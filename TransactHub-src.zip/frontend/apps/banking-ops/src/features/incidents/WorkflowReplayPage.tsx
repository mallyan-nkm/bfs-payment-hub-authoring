import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search } from 'lucide-react';
import { Button, Input, CodeEditor, Timeline, LoadingSpinner, EmptyState, Badge, PageShell, PageHeader, PageToolbar, PageBody, useSessionDateTime } from '@paymenthub/ui';
import type { TimelineEvent } from '@paymenthub/ui';
import { incidentsApi } from './api';

export function WorkflowReplayPage() {
  const { formatInstant } = useSessionDateTime();
  const [workflowIdInput, setWorkflowIdInput] = useState('');
  const [searchedId, setSearchedId] = useState<string | null>(null);
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);

  const { data: run, isFetching: runLoading, isError: runError } = useQuery({
    queryKey: ['workflow-replay', 'run', searchedId],
    queryFn: () => incidentsApi.searchWorkflowRun(searchedId!).then((r) => r.data),
    enabled: !!searchedId,
  });

  const { data: history, isFetching: historyLoading } = useQuery({
    queryKey: ['workflow-replay', 'history', searchedId],
    queryFn: () => incidentsApi.getWorkflowHistory(searchedId!).then((r) => r.data),
    enabled: !!searchedId,
  });

  const events = history ?? [];

  const timelineEvents: TimelineEvent[] = events.map((e) => ({
    id: String(e.eventId),
    timestamp: e.timestamp,
    title: e.eventType,
    description: `Event #${e.eventId}`,
    meta: (
      <Button variant="link" size="sm" onClick={() => setSelectedEventId(e.eventId)}>
        View payload
      </Button>
    ),
  }));

  const selectedEvent = useMemo(
    () => events.find((e) => e.eventId === selectedEventId) ?? null,
    [events, selectedEventId],
  );

  function handleSearch() {
    setSelectedEventId(null);
    setSearchedId(workflowIdInput.trim() || null);
  }

  return (
    <PageShell>
      <PageHeader title="Workflow Forensics" />

      <PageToolbar>
        <Input
          placeholder="Workflow ID…"
          value={workflowIdInput}
          onChange={(e) => setWorkflowIdInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          className="max-w-sm h-9"
        />
        <Button variant="primary" size="sm" onClick={handleSearch} disabled={!workflowIdInput.trim()}>
          <Search size={14} /> Search
        </Button>
      </PageToolbar>

      <PageBody>
        {!searchedId ? (
          <EmptyState title="Search a workflow" message="Enter a workflow ID above to inspect its execution history." />
        ) : runLoading || historyLoading ? (
          <div className="flex items-center justify-center h-64">
            <LoadingSpinner />
          </div>
        ) : runError || !run ? (
          <EmptyState title="Workflow not found" message={`No workflow run found for "${searchedId}".`} />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="mb-3 flex items-center gap-2">
                <h2 className="text-sm font-semibold text-[var(--text-primary)]">{run.workflowType}</h2>
                <Badge variant="outline">{run.status}</Badge>
              </div>
              <p className="text-xs text-[var(--text-muted)] mb-3">
                Run {run.runId} · Task queue {run.taskQueue} · Started {formatInstant(run.startTime)}
              </p>
              <Timeline events={timelineEvents} emptyMessage="No history events for this workflow run." />
            </div>
            <div>
              <CodeEditor
                label="Event payload"
                value={selectedEvent ? JSON.stringify(selectedEvent.attributes, null, 2) : ''}
                language="json"
                readOnly
                minHeight="360px"
              />
              {!selectedEvent && (
                <p className="mt-2 text-xs text-[var(--text-muted)]">
                  Click "View payload" on a timeline event to inspect it here.
                </p>
              )}
            </div>
          </div>
        )}
      </PageBody>
    </PageShell>
  );
}
