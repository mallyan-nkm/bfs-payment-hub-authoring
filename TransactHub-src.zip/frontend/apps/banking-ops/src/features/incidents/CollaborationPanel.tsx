import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Textarea, LoadingSpinner, EmptyState, cn, useSessionDateTime } from '@paymenthub/ui';
import { incidentsApi } from './api';
import { useCurrentUsername } from '../../shared/hooks/useOfflineAwareAction';

export interface CollaborationPanelProps {
  incidentId: string;
  className?: string;
}

export function CollaborationPanel({ incidentId, className }: CollaborationPanelProps) {
  const { formatInstant } = useSessionDateTime();
  const [body, setBody] = useState('');
  const queryClient = useQueryClient();
  const username = useCurrentUsername();

  const { data, isFetching } = useQuery({
    queryKey: ['incidents', incidentId, 'comments'],
    queryFn: () => incidentsApi.listComments(incidentId).then((r) => r.data),
  });

  const comments = data ?? [];

  const postComment = useMutation({
    mutationFn: () => incidentsApi.addComment(incidentId, body),
    onSuccess: () => {
      setBody('');
      queryClient.invalidateQueries({ queryKey: ['incidents', incidentId, 'comments'] });
    },
  });

  return (
    <div className={cn('flex flex-col gap-3', className)}>
      <h3 className="text-sm font-semibold text-[var(--text-primary)]">Collaboration</h3>

      <div className="flex-1 overflow-auto max-h-64">
        {isFetching && comments.length === 0 ? (
          <div className="flex items-center justify-center py-6">
            <LoadingSpinner />
          </div>
        ) : comments.length === 0 ? (
          <EmptyState title="No comments yet" message="Be the first to add a note on this incident." />
        ) : (
          <ul className="flex flex-col gap-3">
            {comments.map((comment) => (
              <li key={comment.id} className="rounded-md border border-[var(--border)] bg-[var(--bg-card)] px-3 py-2">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-sm font-medium text-[var(--text-primary)]">{comment.author}</span>
                  <time className="text-xs text-[var(--text-muted)]">
                    {formatInstant(comment.createdAt)}
                  </time>
                </div>
                <p className="mt-1 text-sm text-[var(--text-secondary)]">{comment.body}</p>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="flex flex-col gap-2">
        <Textarea
          placeholder={`Add a note as ${username}…`}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          rows={3}
        />
        <div className="flex justify-end">
          <Button
            variant="primary"
            size="sm"
            disabled={!body.trim() || postComment.isPending}
            loading={postComment.isPending}
            onClick={() => postComment.mutate()}
          >
            Post
          </Button>
        </div>
        {postComment.isError && (
          <p className="text-xs text-[var(--accent-red)]">Failed to post comment. Please try again.</p>
        )}
      </div>
    </div>
  );
}
