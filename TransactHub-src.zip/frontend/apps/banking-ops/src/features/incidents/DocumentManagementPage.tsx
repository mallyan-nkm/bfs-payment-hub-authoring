import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Trash2 } from 'lucide-react';
import { Button, DataTable, FileUpload, Select, cn, PageShell, PageHeader, PageBody } from '@paymenthub/ui';
import type { DataTableColumn } from '@paymenthub/ui';
import { incidentsApi } from './api';
import type { IncidentDocument } from './types';

const CATEGORY_OPTIONS = [
  { label: 'Incident Evidence', value: 'incident-evidence' },
  { label: 'Compliance', value: 'compliance' },
  { label: 'Operational Runbook', value: 'runbook' },
  { label: 'Other', value: 'other' },
];

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function DocumentManagementPage() {
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [category, setCategory] = useState('incident-evidence');
  const queryClient = useQueryClient();

  const { data, isFetching } = useQuery({
    queryKey: ['incidents', 'documents'],
    queryFn: () => incidentsApi.listDocuments({ page: 1, pageSize: 100 }).then((r) => r.data),
  });

  const documents = data?.items ?? [];

  const uploadMutation = useMutation({
    mutationFn: () => incidentsApi.uploadDocument(pendingFiles, category),
    onSuccess: () => {
      setPendingFiles([]);
      queryClient.invalidateQueries({ queryKey: ['incidents', 'documents'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => incidentsApi.deleteDocument(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['incidents', 'documents'] }),
  });

  const columns: DataTableColumn<IncidentDocument>[] = [
    { key: 'name', header: 'Name' },
    { key: 'category', header: 'Category' },
    { key: 'uploadedBy', header: 'Uploaded By' },
    {
      key: 'uploadedAt',
      header: 'Uploaded At',
      sortable: true,
      kind: 'instant',
    },
    { key: 'size', header: 'Size', align: 'right', render: (row) => formatSize(row.size) },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (row) => (
        <Button
          variant="ghost"
          size="sm"
          onClick={(e) => {
            e.stopPropagation();
            deleteMutation.mutate(row.id);
          }}
          disabled={deleteMutation.isPending}
        >
          <Trash2 size={14} />
        </Button>
      ),
    },
  ];

  return (
    <PageShell>
      <PageHeader
        title="Document Management"
        subtitle={
          <>
            {documents.length} document{documents.length !== 1 ? 's' : ''}
          </>
        }
      />

      <div className="flex flex-col gap-3 px-6 py-4 border-b border-[var(--border)] bg-[var(--bg-secondary)] shrink-0">
        <div className="flex items-end gap-3">
          <Select
            options={CATEGORY_OPTIONS}
            value={category}
            onValueChange={setCategory}
            label="Category"
            className="w-56"
          />
          <Button
            variant="primary"
            size="sm"
            disabled={pendingFiles.length === 0 || uploadMutation.isPending}
            loading={uploadMutation.isPending}
            onClick={() => uploadMutation.mutate()}
          >
            Upload {pendingFiles.length > 0 ? `(${pendingFiles.length})` : ''}
          </Button>
        </div>
        <FileUpload
          multiple
          onFilesSelected={(files) => setPendingFiles((prev) => [...prev, ...files])}
          files={pendingFiles.map((f) => ({ name: f.name, size: f.size }))}
          onRemove={(name) => setPendingFiles((prev) => prev.filter((f) => f.name !== name))}
          helperText="Attach incident evidence, compliance artifacts, or operational documents."
        />
        {uploadMutation.isError && (
          <p className={cn('text-xs text-[var(--accent-red)]')}>Upload failed. Please try again.</p>
        )}
      </div>

      <PageBody>
        <div className="overflow-hidden rounded-lg border border-[var(--border)] bg-[var(--bg-card)]">
          <DataTable
            columns={columns}
            data={documents}
            rowKey={(row) => row.id}
            loading={isFetching}
            emptyTitle="No documents"
            emptyMessage="No documents have been uploaded yet."
          />
        </div>
      </PageBody>
    </PageShell>
  );
}
