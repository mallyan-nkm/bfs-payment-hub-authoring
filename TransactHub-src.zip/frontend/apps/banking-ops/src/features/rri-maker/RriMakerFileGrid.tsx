import { useQuery } from '@tanstack/react-query';
import { Button, EmptyState, LoadingSpinner } from '@paymenthub/ui';
import { rriMakerApi } from './api';
import { readProblem } from './errors';
import { useRriMakerTranslation } from './i18n';
import { rriMakerKeys } from './queryKeys';
import { RriManualBlockAction } from './RriManualBlockAction';
import type { RriMakerFile, RriMakerView } from './types';

/** The block-marker words are shown exactly as the server sends them; only the counts are joined. */
const markerSummary = (counts: Record<string, number>) =>
  Object.entries(counts)
    .map(([marker, n]) => `${marker} ${n}`)
    .join(', ');

/**
 * The two views of design §4.1: files to verify, and files waiting for a manual block. Every row comes from the endpoint.
 * v1.1 (§4.1, V-Q-1; task V5): a file the checker sent back is listed with the others and flagged with the rejected verification.
 */
export function RriMakerFileGrid({
  view,
  selectedId,
  onSelect,
}: {
  view: RriMakerView;
  selectedId: string | null;
  onSelect: (file: RriMakerFile) => void;
}) {
  const { t } = useRriMakerTranslation();
  const files = useQuery({ queryKey: rriMakerKeys.files(view), queryFn: () => rriMakerApi.files(view) });

  if (files.isPending) return <LoadingSpinner />;
  if (files.isError) return <p role="alert">{readProblem(t, files.error).message}</p>;
  if (files.data.length === 0) return <EmptyState title={t('FILES.EMPTY_TITLE')} message={t('FILES.EMPTY_MESSAGE')} />;

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" aria-label={view === 'verify' ? t('FILES.TABLE_VERIFY') : t('FILES.TABLE_MANUAL_BLOCK')}>
        <thead>
          <tr className="text-left text-[var(--text-secondary)]">
            <th className="p-2">{t('FILES.COLUMNS.FILE')}</th>
            <th className="p-2">{t('FILES.COLUMNS.ESTABLISHMENT')}</th>
            <th className="p-2">{t('FILES.COLUMNS.LINES')}</th>
            <th className="p-2">{t('FILES.COLUMNS.TOTAL')}</th>
            {view === 'verify' ? <th className="p-2">{t('FILES.COLUMNS.VERIFICATION')}</th> : <th className="p-2">{t('FILES.COLUMNS.MARKERS')}</th>}
            {view === 'manual-block' && <th className="p-2">{t('FILES.COLUMNS.ACTION')}</th>}
          </tr>
        </thead>
        <tbody>
          {files.data.map((f) => (
            <tr key={f.transactionId} className={f.transactionId === selectedId ? 'bg-[var(--bg-2)]' : undefined}>
              <td className="p-2">
                {view === 'verify' ? (
                  <Button variant="link" size="sm" onClick={() => onSelect(f)}>
                    {f.fileName}
                  </Button>
                ) : (
                  f.fileName
                )}
              </td>
              <td className="p-2">{f.establishmentReference ?? ''}</td>
              <td className="p-2">{f.lineCount}</td>
              <td className="p-2">{f.totalAmount.toFixed(2)}</td>
              {view === 'verify' ? (
                <td className="p-2">
                  {f.verificationNo}
                  {f.returnedByChecker && (
                    <span className="ml-2 rounded border border-[var(--accent-amber)] px-1 text-xs">
                      {t('FILES.RETURNED_BADGE', { rejected: f.rejectedVerificationNo ?? '' })}
                    </span>
                  )}
                </td>
              ) : (
                <td className="p-2">{markerSummary(f.markerCounts)}</td>
              )}
              {view === 'manual-block' && (
                <td className="p-2">
                  <RriManualBlockAction file={f} />
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
