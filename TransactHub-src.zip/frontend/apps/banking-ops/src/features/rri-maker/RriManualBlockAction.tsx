import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button, Can } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { rriMakerApi } from './api';
import { readProblem } from './errors';
import { useRriMakerTranslation } from './i18n';
import { rriMakerKeys } from './queryKeys';
import type { RriMakerFile } from './types';

/** What the action last reported; turned into copy at render time, so it follows the reader's language. */
type ManualBlockNotice = { kind: 'requested'; alreadyRequested: boolean } | { kind: 'problem'; error: unknown };

/**
 * "Block RRI Amount and Forward to Checker" (design §4.5, FWD-20, Q-2). Enabled only in the manual-block view, for a file whose
 * ABF count is above 0 and whose MB:{c} does not exist yet (AC-DRF-08). The server writes the one header 644 MB:{c}; Activity 3's
 * next pass re-attempts the ABF lines. Gated on the manual-block key the route enforces (H-RRI4-1); hidden without it.
 */
export function RriManualBlockAction({ file }: { file: RriMakerFile }) {
  const { t } = useRriMakerTranslation();
  const client = useQueryClient();
  const [notice, setNotice] = useState<ManualBlockNotice | null>(null);
  const enabled = file.autoBlockFailedCount > 0 && !file.manualBlockRequested;
  const block = useMutation({
    mutationFn: () => rriMakerApi.manualBlock(file.transactionId),
    onSuccess: (r) => {
      setNotice({ kind: 'requested', alreadyRequested: r.alreadyRequested });
      void client.invalidateQueries({ queryKey: rriMakerKeys.files('manual-block') });
    },
    onError: (e) => setNotice({ kind: 'problem', error: e }),
  });

  const message =
    notice === null
      ? null
      : notice.kind === 'problem'
        ? readProblem(t, notice.error).message
        : t(notice.alreadyRequested ? 'MANUAL_BLOCK.ALREADY_REQUESTED' : 'MANUAL_BLOCK.REQUESTED');

  return (
    <div className="flex flex-col items-start gap-1">
      <Can permission={PERM.rriMakerManualBlock}>
        <Button size="sm" variant="primary" disabled={!enabled || block.isPending} loading={block.isPending} onClick={() => block.mutate()}>
          {t('MANUAL_BLOCK.BUTTON')}
        </Button>
      </Can>
      {message && (
        <span role="status" className="text-xs text-[var(--text-secondary)]">
          {message}
        </span>
      )}
    </div>
  );
}
