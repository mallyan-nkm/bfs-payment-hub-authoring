import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiError, apiOk, grant, renderWithProviders } from '../../../test/renderWithProviders';
import { RriMakerPage } from './RriMakerPage';
import type { RriMakerFile, RriMakerLine, RriMakerLinesPage } from './types';

// Every response here is mocked; the server-side gates are proven in tests/PaymentHub.IntegrationTests (RriMakerAuthorizationTests).
vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

const FILE: RriMakerFile = {
  transactionId: 'TX-1',
  fileName: 'F1.RRI',
  establishmentReference: 'EST-1',
  lineCount: 4,
  totalAmount: 400,
  stateAt: null,
  verificationNo: 1,
  markerCounts: {},
  autoBlockFailedCount: 0,
  diversionCycle: 0,
  manualBlockRequested: false,
  returnedByChecker: false,
  rejectedVerificationNo: null,
};

const line = (n: number, extra: Partial<RriMakerLine> = {}): RriMakerLine => ({
  drrId: 100 + n,
  lineNo: n,
  personId: 'P1234567890',
  account: 'AE070260001015000000001',
  refundAmount: 100,
  refundReason: '005',
  refundType: 'RRI',
  marker: 'BLOCKED',
  notEligibleReason: null,
  latestOutcome: null,
  decidingOutcome: null,
  ...extra,
});

const LINES = [
  line(1),
  line(2, { marker: 'NOT_ELIGIBLE', notEligibleReason: 'NOT_DIB_ACCOUNT' }),
  line(3, { decidingOutcome: 'INSUFFICIENT', latestOutcome: 'INSUFFICIENT' }),
  line(4, { marker: 'NOT_ELIGIBLE', notEligibleReason: 'NOT_ON_DIF' }),
];

function serve(page: Partial<RriMakerLinesPage> = {}, file: RriMakerFile = FILE) {
  get.mockImplementation((url: string) => {
    if (url.endsWith('/files')) return Promise.resolve(apiOk([file]));
    if (url.endsWith('/reject-reasons'))
      return Promise.resolve(apiOk([{ code: '005', description: 'Employee left' }, { code: '000', description: 'Accepted' }, { code: '002', description: 'Insufficient' }]));
    if (url.endsWith('/lines'))
      return Promise.resolve(apiOk({ transactionId: 'TX-1', verificationNo: 1, page: 1, size: 100, lineCount: 4, balanceCheckRequired: true, lines: LINES, ...page }));
    return Promise.reject(new Error(`unexpected GET ${url}`));
  });
}

async function openFile() {
  renderWithProviders(<RriMakerPage />);
  await userEvent.click(await screen.findByRole('button', { name: 'F1.RRI' }));
  await screen.findByRole('table', { name: 'RRI lines' });
}

const decision = (n: number) => screen.getByRole('combobox', { name: `Decision for line ${n}` });
const confirm = () => screen.getByRole('button', { name: /Confirm and forward/ });

describe('RRI maker screen (design §4.1, §4.3; task T9)', () => {
  beforeEach(() => {
    grant(PERM.railWps, PERM.rriMakerPage, PERM.rriMakerVerify, PERM.rriMakerManualBlock);
    get.mockReset();
    post.mockReset();
    serve();
  });

  it('AC-DRF-01, AC-DRF-02: the unmapped and the INSUFFICIENT lines are preset REJECT and locked', async () => {
    await openFile();

    expect(within(screen.getByTestId('rri-line-2')).getByText('Rejected: mapping not found')).toBeInTheDocument();
    expect(within(screen.getByTestId('rri-line-3')).getByText(/Rejected: 002/)).toBeInTheDocument();
    expect(within(screen.getByTestId('rri-line-2')).queryByRole('combobox')).toBeNull();
    expect(within(screen.getByTestId('rri-line-3')).queryByRole('combobox')).toBeNull();
  });

  it('AC-DRF-03: a REJECT needs a catalogue reason, and 000 and 002 are not offered', async () => {
    await openFile();
    await userEvent.selectOptions(decision(1), 'Reject');

    const reason = screen.getByRole('combobox', { name: 'Reason for line 1' });
    expect(within(reason).getAllByRole('option').map((o) => o.textContent)).toEqual(['Reason', '005 Employee left']);
  });

  it('AC-DRF-04: NOT_ON_DIF is shown "not blocked" and decided by the maker', async () => {
    await openFile();
    const row = screen.getByTestId('rri-line-4');

    expect(within(row).getByText('Not blocked')).toBeInTheDocument();
    expect(within(row).getByRole('combobox', { name: 'Decision for line 4' })).toBeEnabled();
  });

  it('masks the account and the person ID', async () => {
    await openFile();
    const row = screen.getByTestId('rri-line-1');

    expect(within(row).queryByText('AE070260001015000000001')).toBeNull();
    expect(within(row).queryByText('P1234567890')).toBeNull();
  });

  it('AC-DRF-05, AC-DRF-06: confirm waits for every decision, and nothing is posted but runs before confirm', async () => {
    post.mockResolvedValue(apiOk({ runId: 9 }));
    await openFile();
    expect(confirm()).toBeDisabled();

    await userEvent.selectOptions(decision(1), 'Accept');
    await userEvent.click(screen.getByRole('button', { name: /Check balance \(1\)/ }));
    expect(confirm()).toBeDisabled();
    await userEvent.selectOptions(decision(4), 'Accept');

    expect(confirm()).toBeEnabled();
    expect(post.mock.calls.map((c) => c[0])).toEqual(['/wps/rri/maker/files/TX-1/balance-checks']);
    expect(post.mock.calls[0][1]).toEqual({ lineIds: [101] });
  });

  it('confirms with one decision per line and shows the counts and the server changes (AC-VER-29)', async () => {
    post.mockResolvedValue(
      apiOk({
        acceptedCount: 1,
        rejectedCount: 3,
        confirmation: 'RRI Verification Done by Bank Maker',
        serverChanged: [{ lineNo: 1, decision: 'REJECTED', reasonCode: '002', cause: 'INSUFFICIENT' }],
        balanceCheckBypassed: false,
      }),
    );
    await openFile();
    await userEvent.selectOptions(decision(1), 'Accept');
    await userEvent.selectOptions(decision(4), 'Accept');
    await userEvent.click(confirm());

    expect(await screen.findByText(/RRI Verification Done by Bank Maker: 1 accepted, 3 rejected/)).toBeInTheDocument();
    expect(within(screen.getByRole('list', { name: 'Server changes' })).getByText(/Line 1: REJECTED 002 \(INSUFFICIENT\)/)).toBeInTheDocument();
    const body = post.mock.calls[0][1] as { submissionKey: string; verificationNo: number; decisions: unknown[] };
    expect(body.decisions).toHaveLength(4);
    expect(body.verificationNo).toBe(1);
    expect(body.submissionKey).toBeTruthy();
  });

  it('AC-DRF-07: the bypass is shown before and after confirm', async () => {
    serve({ balanceCheckRequired: false });
    post.mockResolvedValue(apiOk({ acceptedCount: 2, rejectedCount: 2, confirmation: 'Done', serverChanged: [], balanceCheckBypassed: true }));
    await openFile();

    expect(screen.getByRole('note')).toHaveTextContent(/bypassed/);
    await userEvent.selectOptions(decision(1), 'Accept');
    await userEvent.selectOptions(decision(4), 'Accept');
    await userEvent.click(confirm());
    await screen.findByText(/2 accepted, 2 rejected/);
    expect(screen.getByRole('note')).toHaveTextContent(/bypassed/);
  });

  it('shows a refusal by its code and line numbers only (AC-ERR-03)', async () => {
    post.mockRejectedValue(apiError(422, 'x', 'Unprocessable', { code: 'RRI_MAKER_BALANCE_REQUIRED', lineNos: [1] }));
    await openFile();
    await userEvent.selectOptions(decision(1), 'Accept');
    await userEvent.selectOptions(decision(4), 'Accept');
    await userEvent.click(confirm());

    await waitFor(() => expect(screen.getByRole('alert')).toHaveTextContent('An accepted line needs a sufficient balance check. Lines: 1.'));
  });
});

const RETURNED: RriMakerFile = { ...FILE, verificationNo: 2, returnedByChecker: true, rejectedVerificationNo: 1 };

describe('RRI maker screen, gates (H-RRI4-1)', () => {
  beforeEach(() => {
    get.mockReset();
    post.mockReset();
    serve();
  });

  it('without the verify key, neither Check balance nor Confirm and forward can be used (the server refuses both anyway)', async () => {
    grant(PERM.railWps, PERM.rriMakerPage);
    await openFile();
    await userEvent.selectOptions(decision(1), 'Accept');

    const usable = (name: RegExp) => {
      const button = screen.queryByRole('button', { name });
      return button !== null && !(button as HTMLButtonElement).disabled;
    };
    expect(usable(/Check balance/)).toBe(false);
    expect(usable(/Confirm and forward/)).toBe(false);
    expect(post).not.toHaveBeenCalled();
  });
});

describe('RRI maker screen, v1.1 (design §4.1 "A returned file", §4.3; task V5)', () => {
  beforeEach(() => {
    grant(PERM.railWps, PERM.rriMakerPage, PERM.rriMakerVerify, PERM.rriMakerManualBlock);
    get.mockReset();
    post.mockReset();
  });

  it('AC-DRF-07 (D-21): with balanceCheckRequired true from the lines response, no bypass is shown', async () => {
    serve({ balanceCheckRequired: true });
    await openFile();

    expect(screen.queryByRole('note')).toBeNull();
  });

  it('AC-DRF-09: a returned file is flagged with its rejected verification, in the list and on the screen', async () => {
    serve({ verificationNo: 2 }, RETURNED);
    renderWithProviders(<RriMakerPage />);

    expect(await screen.findByText('Returned by checker (verification 1 rejected)')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: 'F1.RRI' }));
    await screen.findByRole('table', { name: 'RRI lines' });
    expect(screen.getByRole('note', { name: 'Returned by checker' })).toHaveTextContent(/verification 1 was rejected\. This is verification 2/);
  });

  it('AC-DRF-09 (V-Q-4, EC-27): the draft starts empty; only presets from v + 1 deciding results apply, and the forward is v + 1', async () => {
    // The server returns only v + 1's results: line 3's INSUFFICIENT is a v + 1 result; the other lines have none yet.
    serve({ verificationNo: 2 }, RETURNED);
    post.mockResolvedValue(apiOk({ acceptedCount: 2, rejectedCount: 2, confirmation: 'Done', serverChanged: [], balanceCheckBypassed: false }));
    renderWithProviders(<RriMakerPage />);
    await userEvent.click(await screen.findByRole('button', { name: 'F1.RRI' }));
    await screen.findByRole('table', { name: 'RRI lines' });

    expect(decision(1)).toHaveValue('');
    expect(decision(4)).toHaveValue('');
    expect(within(screen.getByTestId('rri-line-3')).getByText(/Rejected: 002/)).toBeInTheDocument();
    expect(confirm()).toBeDisabled();

    await userEvent.selectOptions(decision(1), 'Accept');
    await userEvent.selectOptions(decision(4), 'Accept');
    await userEvent.click(confirm());

    await screen.findByText(/2 accepted, 2 rejected/);
    const body = post.mock.calls[0][1] as { verificationNo: number; decisions: unknown[] };
    expect(body.verificationNo).toBe(2);
    expect(body.decisions).toHaveLength(4);
  });
});
