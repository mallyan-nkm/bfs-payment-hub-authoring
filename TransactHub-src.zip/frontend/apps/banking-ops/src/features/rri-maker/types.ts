/**
 * Contracts of the RRI maker verification API (design Inward_RRI_Maker_Verification v1.0 §4.1–§4.5, task T9; v1.1 §4.1, task V5).
 * They mirror `PaymentHub.WpsBusiness.API.DTOs.RriMaker`. Nothing here is static data (AC-SEC-09): every list comes from the endpoints.
 */

export type RriMakerView = 'verify' | 'manual-block';

export interface RriMakerFile {
  transactionId: string;
  fileName: string;
  establishmentReference: string | null;
  lineCount: number;
  totalAmount: number;
  stateAt: string | null;
  verificationNo: number;
  markerCounts: Record<string, number>;
  autoBlockFailedCount: number;
  diversionCycle: number;
  manualBlockRequested: boolean;
  /** v1.1 (design §4.1, V-Q-1): Activity 5's checker sent the file back ("Reject RRI"); it is verified again as `verificationNo`. */
  returnedByChecker: boolean;
  /** v1.1: the verification the checker rejected; null unless `returnedByChecker`. */
  rejectedVerificationNo: number | null;
}

export interface RriMakerLine {
  drrId: number;
  lineNo: number;
  personId: string;
  account: string;
  refundAmount: number;
  refundReason: string;
  refundType: string;
  marker: string;
  notEligibleReason: string | null;
  latestOutcome: string | null;
  decidingOutcome: string | null;
}

export interface RriMakerLinesPage {
  transactionId: string;
  verificationNo: number;
  page: number;
  size: number;
  lineCount: number;
  balanceCheckRequired: boolean;
  lines: RriMakerLine[];
}

export interface RriRejectReason {
  code: string;
  description: string;
}

export interface RriBalanceRun {
  runId: number;
  verificationNo: number;
  completed: number;
  lineCount: number;
  isComplete: boolean;
  lines: { lineNo: number; outcome: string }[];
}

export type RriDecisionWord = 'ACCEPT' | 'REJECT';

export interface RriForwardRequest {
  submissionKey: string;
  verificationNo: number;
  decisions: { drrId: number; decision: RriDecisionWord; reasonCode: string | null }[];
}

export interface RriServerChange {
  lineNo: number;
  decision: string;
  reasonCode: string;
  cause: string;
}

export interface RriForwardResponse {
  acceptedCount: number;
  rejectedCount: number;
  confirmation: string;
  serverChanged: RriServerChange[];
  balanceCheckBypassed: boolean;
}

export interface RriManualBlockResponse {
  cycle: number;
  alreadyRequested: boolean;
}

/** One line's decision in the screen's draft (design §4.3). `locked` lines are preset by the server's rules and cannot be changed. */
export interface RriDraftEntry {
  decision: RriDecisionWord | null;
  reasonCode: string | null;
  locked: boolean;
}
