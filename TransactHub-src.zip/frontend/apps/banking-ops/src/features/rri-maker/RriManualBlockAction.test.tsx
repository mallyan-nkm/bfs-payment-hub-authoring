import { screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiOk, grant, renderWithProviders } from '../../../test/renderWithProviders';
import { RriMakerPage } from './RriMakerPage';
import type { RriMakerFile } from './types';

// Every response here is mocked; the server-side gates are proven in tests/PaymentHub.IntegrationTests (RriMakerAuthorizationTests).
vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

const file = (id: string, abf: number, requested: boolean): RriMakerFile => ({
  transactionId: id,
  fileName: `${id}.RRI`,
  establishmentReference: null,
  lineCount: 2,
  totalAmount: 20,
  stateAt: null,
  verificationNo: 1,
  markerCounts: { ABF: abf, BLOCKED: 2 - abf },
  autoBlockFailedCount: abf,
  diversionCycle: 1,
  manualBlockRequested: requested,
  returnedByChecker: false,
  rejectedVerificationNo: null,
});

describe('Block RRI Amount and Forward to Checker (design §4.5; task T9)', () => {
  beforeEach(() => {
    grant(PERM.railWps, PERM.rriMakerPage, PERM.rriMakerVerify, PERM.rriMakerManualBlock);
    get.mockReset();
    post.mockReset();
    get.mockImplementation((_url: string, config?: { params?: { view?: string } }) =>
      Promise.resolve(
        apiOk(config?.params?.view === 'manual-block' ? [file('TX-A', 1, false), file('TX-B', 0, false), file('TX-C', 1, true)] : []),
      ),
    );
  });

  async function openManualView() {
    renderWithProviders(<RriMakerPage />);
    await userEvent.click(screen.getByRole('button', { name: 'Manual block' }));
    await screen.findByRole('table', { name: 'RRI files waiting for a manual block' });
    return screen.getAllByRole('button', { name: 'Block RRI Amount and Forward to Checker' });
  }

  it('AC-DRF-08: enabled only for a file with ABF lines and no MB:{c}', async () => {
    const [a, b, c] = await openManualView();

    expect(a).toBeEnabled();
    expect(b).toBeDisabled();
    expect(c).toBeDisabled();
  });

  it('AC-DRF-08: the verify view offers no manual block', async () => {
    renderWithProviders(<RriMakerPage />);
    await screen.findByText('No RRI files');

    expect(screen.queryByRole('button', { name: 'Block RRI Amount and Forward to Checker' })).toBeNull();
  });

  it('requests the block and reports the answer', async () => {
    post.mockResolvedValue(apiOk({ cycle: 1, alreadyRequested: false }));
    const [a] = await openManualView();
    await userEvent.click(a);

    expect(await screen.findByText('Manual block requested.')).toBeInTheDocument();
    expect(post).toHaveBeenCalledWith('/wps/rri/maker/files/TX-A/manual-block');
  });

  it('H-RRI4-1: without the manual-block key the button cannot be used, even on an eligible file (the server refuses it anyway)', async () => {
    grant(PERM.railWps, PERM.rriMakerPage, PERM.rriMakerVerify);
    renderWithProviders(<RriMakerPage />);
    await userEvent.click(screen.getByRole('button', { name: 'Manual block' }));
    await screen.findByRole('table', { name: 'RRI files waiting for a manual block' });

    const buttons = screen.queryAllByRole('button', { name: 'Block RRI Amount and Forward to Checker' });
    expect(buttons.every((b) => (b as HTMLButtonElement).disabled)).toBe(true);
    expect(post).not.toHaveBeenCalled();
  });
});
