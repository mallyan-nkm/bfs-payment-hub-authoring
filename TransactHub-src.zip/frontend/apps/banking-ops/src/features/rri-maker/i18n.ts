import { useTranslation } from 'react-i18next';
import type { RriDecisionWord } from './types';

/**
 * The RRI maker screen's copy: the `RRI_MAKER` block of the shared `@paymenthub/ui` translations (`i18n/en.json`,
 * `ar.json`), the same pattern as `DEPARTMENT.*` (React UI guideline §16). Keys below are relative to that block.
 */
export function useRriMakerTranslation() {
  return useTranslation('translation', { keyPrefix: 'RRI_MAKER' });
}

/** The prefixed `t`, for helpers that build copy outside a component (problem messages, line labels). */
export type RriMakerT = ReturnType<typeof useRriMakerTranslation>['t'];

/** The maker's decision words as offered in the line grid; the value sent to the server stays the word. */
export const DECISION_KEY: Record<RriDecisionWord, string> = {
  ACCEPT: 'LINES.ACCEPT',
  REJECT: 'LINES.REJECT',
};
