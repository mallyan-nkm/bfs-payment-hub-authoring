import type { RriDraftEntry, RriForwardRequest, RriMakerLine } from './types';

/**
 * The screen's draft rules (design §4.3, I-4). Pure: no I/O. The draft lives on the screen only; nothing is stored before
 * confirm except balance-check runs (AC-DRF-05).
 * - A NOT_DIB_ACCOUNT line is preset REJECT and locked. Its reason is the catalogue's "mapping not found" code, which the server
 *   records whatever the screen sends (AC-VER-13). Until OD-RRI4-7 names that code, the screen sends no reason for it.
 * - A line whose deciding result is INSUFFICIENT is preset REJECT 002 and locked. When a later run makes the deciding result
 *   SUFFICIENT, the preset is lifted and the line is undecided again (AC-DRF-02).
 * - Every other line, NOT_LINKED and NOT_ON_DIF included, is decided by the maker (AC-DRF-04).
 */
export const NOT_DIB_ACCOUNT = 'NOT_DIB_ACCOUNT';
export const INSUFFICIENT = 'INSUFFICIENT';
export const INSUFFICIENT_REASON = '002';
/** System reason codes, never offered to the maker (AC-DRF-03). */
export const SYSTEM_REASONS: readonly string[] = ['000', INSUFFICIENT_REASON];

export type RriDraft = Record<number, RriDraftEntry>;

/** The preset of a line, or null when the maker decides it. */
export function presetOf(line: RriMakerLine): RriDraftEntry | null {
  if (line.notEligibleReason === NOT_DIB_ACCOUNT) return { decision: 'REJECT', reasonCode: null, locked: true };
  if (line.decidingOutcome === INSUFFICIENT) return { decision: 'REJECT', reasonCode: INSUFFICIENT_REASON, locked: true };
  return null;
}

/** Merges a loaded page into the draft: presets are applied, lifted presets are cleared, the maker's choices are kept. */
export function mergePage(draft: RriDraft, lines: RriMakerLine[]): RriDraft {
  const next: RriDraft = { ...draft };
  for (const line of lines) {
    const preset = presetOf(line);
    const current = next[line.drrId];
    if (preset) {
      next[line.drrId] = preset;
    } else if (!current || current.locked) {
      next[line.drrId] = { decision: null, reasonCode: null, locked: false };
    }
  }
  return next;
}

/** True when the entry is a complete decision: an ACCEPT, a locked preset, or a maker REJECT with a reason. */
export function isDecided(entry: RriDraftEntry | undefined): boolean {
  if (!entry?.decision) return false;
  return entry.decision === 'ACCEPT' || entry.locked || !!entry.reasonCode;
}

/** Confirm is allowed only when every line of the file has a complete decision (AC-DRF-06). */
export function canConfirm(draft: RriDraft, lineCount: number): boolean {
  const entries = Object.values(draft);
  return lineCount > 0 && entries.length === lineCount && entries.every(isDecided);
}

/** The lines the maker currently intends to accept: the candidates of a balance-check run (design §4.2). */
export function acceptCandidates(draft: RriDraft): number[] {
  return Object.entries(draft)
    .filter(([, entry]) => entry.decision === 'ACCEPT')
    .map(([id]) => Number(id));
}

/** The forward body of the draft. */
export function forwardBody(draft: RriDraft, submissionKey: string, verificationNo: number): RriForwardRequest {
  return {
    submissionKey,
    verificationNo,
    decisions: Object.entries(draft).map(([id, entry]) => ({
      drrId: Number(id),
      decision: entry.decision ?? 'REJECT',
      reasonCode: entry.decision === 'ACCEPT' ? null : entry.reasonCode,
    })),
  };
}
