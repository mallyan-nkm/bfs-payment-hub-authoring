import type { RriMakerT } from './i18n';

/**
 * The maker API's problem codes (design §8.1) as screen messages, from `RRI_MAKER.ERRORS` of the shared translations. Line-level
 * codes carry `lineNos` only (AC-ERR-03), and a message names line numbers, never an account, amount or person ID.
 */
const CODES: readonly string[] = [
  'RRI_MAKER_FILE_NOT_FOUND',
  'RRI_MAKER_STATE_CHANGED',
  'RRI_MAKER_NOT_READY',
  'RRI_MAKER_INCOMPLETE',
  'RRI_MAKER_REASON_INVALID',
  'RRI_MAKER_BALANCE_REQUIRED',
  'RRI_BALANCE_RUN_ACTIVE',
  'RRI_MANUAL_BLOCK_NOT_MANUAL',
  'RRI_MAKER_REQUEST_INVALID',
  'RRI_MAKER_UNAVAILABLE',
];

const FALLBACK_CODE = 'RRI_MAKER_UNAVAILABLE';

export interface RriProblem {
  code: string | null;
  message: string;
  lineNos: number[];
}

/**
 * Reads an axios failure into its code, the screen message and the refused line numbers. Called at render time with the
 * screen's prefixed `t`, so the message follows the reader's language.
 */
export function readProblem(t: RriMakerT, error: unknown): RriProblem {
  const data = (error as { response?: { data?: { code?: unknown; lineNos?: unknown } } } | null)?.response?.data;
  const code = typeof data?.code === 'string' ? data.code : null;
  const lineNos = Array.isArray(data?.lineNos) ? data.lineNos.filter((n): n is number => typeof n === 'number') : [];
  const base = t(`ERRORS.${code !== null && CODES.includes(code) ? code : FALLBACK_CODE}`);
  return {
    code,
    lineNos,
    message: lineNos.length > 0 ? t('ERRORS.WITH_LINES', { message: base, lines: lineNos.join(', ') }) : base,
  };
}
