import { describe, expect, it } from 'vitest';
import { acceptCandidates, canConfirm, forwardBody, mergePage, presetOf } from './draft';
import type { RriMakerLine } from './types';

const line = (drrId: number, extra: Partial<RriMakerLine> = {}): RriMakerLine => ({
  drrId,
  lineNo: drrId,
  personId: 'P1',
  account: 'AE070260001015000000001',
  refundAmount: 10,
  refundReason: '005',
  refundType: 'RRI',
  marker: 'BLOCKED',
  notEligibleReason: null,
  latestOutcome: null,
  decidingOutcome: null,
  ...extra,
});

describe('RRI maker draft rules (design §4.3)', () => {
  it('AC-DRF-01: a NOT_DIB_ACCOUNT line is preset REJECT and locked (reason pending OD-RRI4-7)', () => {
    expect(presetOf(line(1, { notEligibleReason: 'NOT_DIB_ACCOUNT', marker: 'NOT_ELIGIBLE' }))).toEqual({
      decision: 'REJECT',
      reasonCode: null,
      locked: true,
    });
  });

  it('AC-DRF-02: a deciding INSUFFICIENT is preset REJECT 002; a later SUFFICIENT lifts the preset', () => {
    const insufficient = mergePage({}, [line(1, { decidingOutcome: 'INSUFFICIENT' })]);
    const lifted = mergePage(insufficient, [line(1, { decidingOutcome: 'SUFFICIENT' })]);

    expect(insufficient[1]).toEqual({ decision: 'REJECT', reasonCode: '002', locked: true });
    expect(lifted[1]).toEqual({ decision: null, reasonCode: null, locked: false });
  });

  it('AC-DRF-04: NOT_LINKED and NOT_ON_DIF lines are decided by the maker', () => {
    expect(presetOf(line(1, { notEligibleReason: 'NOT_LINKED', marker: 'NOT_ELIGIBLE' }))).toBeNull();
    expect(presetOf(line(2, { notEligibleReason: 'NOT_ON_DIF', marker: 'NOT_ELIGIBLE' }))).toBeNull();
  });

  it('keeps the maker’s choices when a page is re-read', () => {
    const draft = mergePage({ 1: { decision: 'ACCEPT', reasonCode: null, locked: false } }, [line(1)]);
    expect(draft[1].decision).toBe('ACCEPT');
  });

  it('AC-DRF-06: confirm needs a complete decision for every line of the file', () => {
    const draft = mergePage({}, [line(1), line(2, { notEligibleReason: 'NOT_DIB_ACCOUNT' })]);
    expect(canConfirm(draft, 2)).toBe(false);
    expect(canConfirm({ ...draft, 1: { decision: 'REJECT', reasonCode: null, locked: false } }, 2)).toBe(false);
    expect(canConfirm({ ...draft, 1: { decision: 'ACCEPT', reasonCode: null, locked: false } }, 2)).toBe(true);
    expect(canConfirm({ ...draft, 1: { decision: 'ACCEPT', reasonCode: null, locked: false } }, 3)).toBe(false);
  });

  it('builds the run candidates and the forward body from the draft', () => {
    const draft = {
      1: { decision: 'ACCEPT' as const, reasonCode: null, locked: false },
      2: { decision: 'REJECT' as const, reasonCode: '005', locked: false },
    };
    expect(acceptCandidates(draft)).toEqual([1]);
    expect(forwardBody(draft, 'k', 3)).toEqual({
      submissionKey: 'k',
      verificationNo: 3,
      decisions: [
        { drrId: 1, decision: 'ACCEPT', reasonCode: null },
        { drrId: 2, decision: 'REJECT', reasonCode: '005' },
      ],
    });
  });

  it('AC-SEC-09: the feature holds no static data rows; every list comes from the endpoints', () => {
    // v1.1 (V8, finding F-7): the sources are read through Vite's import.meta.glob, not node:fs, so the root tsconfig type-checks this file.
    const sources = import.meta.glob<string>(['./*.ts', './*.tsx', '!./*.test.ts', '!./*.test.tsx'], {
      query: '?raw',
      import: 'default',
      eager: true,
    });
    expect(Object.keys(sources).length).toBeGreaterThan(5);
    for (const [file, text] of Object.entries(sources)) {
      expect(text, file).not.toMatch(/\b(transactionId|drrId|fileName|description)\s*:\s*['"\d]/);
    }
  });
});
