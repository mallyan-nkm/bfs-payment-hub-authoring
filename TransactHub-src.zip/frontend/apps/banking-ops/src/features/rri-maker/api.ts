import { bankingApi } from '../../shared/api/bankingApi';
import type {
  RriBalanceRun,
  RriForwardRequest,
  RriForwardResponse,
  RriMakerFile,
  RriMakerLinesPage,
  RriMakerView,
  RriManualBlockResponse,
  RriRejectReason,
} from './types';

/**
 * The RRI maker verification endpoints (design §4.1–§4.5). `bankingApi` is scoped to `/api`.
 * Release blocker RB-2: WPS Business does not map these routes until the rbac follow-up (H-RRI4-1) gates them, so the screen is
 * routed as "no backend" and its tests run against mocked responses.
 */
const BASE = '/wps/rri/maker';
const fileBase = (transactionId: string) => `${BASE}/files/${encodeURIComponent(transactionId)}`;

export const rriMakerApi = {
  files: (view: RriMakerView) => bankingApi.get<RriMakerFile[]>(`${BASE}/files`, { params: { view } }).then((r) => r.data),

  lines: (transactionId: string, page: number, size: number) =>
    bankingApi.get<RriMakerLinesPage>(`${fileBase(transactionId)}/lines`, { params: { page, size } }).then((r) => r.data),

  rejectReasons: () => bankingApi.get<RriRejectReason[]>(`${BASE}/reject-reasons`).then((r) => r.data),

  startBalanceCheck: (transactionId: string, lineIds: number[]) =>
    bankingApi.post<{ runId: number }>(`${fileBase(transactionId)}/balance-checks`, { lineIds }).then((r) => r.data),

  balanceCheck: (transactionId: string, runId: number) =>
    bankingApi.get<RriBalanceRun>(`${fileBase(transactionId)}/balance-checks/${runId}`).then((r) => r.data),

  forward: (transactionId: string, body: RriForwardRequest) =>
    bankingApi.post<RriForwardResponse>(`${fileBase(transactionId)}/forward`, body).then((r) => r.data),

  manualBlock: (transactionId: string) =>
    bankingApi.post<RriManualBlockResponse>(`${fileBase(transactionId)}/manual-block`).then((r) => r.data),
};
