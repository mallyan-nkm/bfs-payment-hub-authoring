import { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Can, LoadingSpinner, PageBody, PageHeader, PageShell } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { rriMakerApi } from './api';
import { acceptCandidates, canConfirm, forwardBody, mergePage, type RriDraft } from './draft';
import { readProblem } from './errors';
import { useRriMakerTranslation } from './i18n';
import { rriMakerKeys } from './queryKeys';
import { RriBalanceCheckPanel } from './RriBalanceCheckPanel';
import { RriMakerFileGrid } from './RriMakerFileGrid';
import { RriMakerLineGrid } from './RriMakerLineGrid';
import type { RriDraftEntry, RriForwardResponse, RriMakerFile, RriMakerView } from './types';

const PAGE_SIZE = 100;
const newKey = () => globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;

/**
 * Bank maker verification of an RRI file (RRI Activity 4; design Inward_RRI_Maker_Verification v1.0 §3.1, §4, task T9; v1.1 §4.1, §4.3,
 * task V5: a file the checker rejected comes back flagged and is verified again from an empty draft).
 * The verify view holds the draft on the screen until confirm; the manual-block view offers "Block RRI Amount and Forward to
 * Checker". The routes behind it are not mapped until the rbac follow-up (RB-2), so the route is "no backend" for now.
 * Copy comes from `RRI_MAKER` of the shared translations (React UI guideline §16).
 */
export function RriMakerPage() {
  const { t } = useRriMakerTranslation();
  const [view, setView] = useState<RriMakerView>('verify');
  const [file, setFile] = useState<RriMakerFile | null>(null);

  return (
    <PageShell>
      <PageHeader title={t('PAGE.TITLE')} subtitle={t('PAGE.SUBTITLE')} live={false} />
      <PageBody>
        <div className="mb-4 flex gap-2" role="group" aria-label={t('PAGE.VIEW_GROUP')}>
          <Button variant={view === 'verify' ? 'primary' : 'outline'} aria-pressed={view === 'verify'} onClick={() => setView('verify')}>
            {t('PAGE.VIEW_VERIFY')}
          </Button>
          <Button
            variant={view === 'manual-block' ? 'primary' : 'outline'}
            aria-pressed={view === 'manual-block'}
            onClick={() => {
              setView('manual-block');
              setFile(null);
            }}
          >
            {t('PAGE.VIEW_MANUAL_BLOCK')}
          </Button>
        </div>
        <RriMakerFileGrid view={view} selectedId={file?.transactionId ?? null} onSelect={setFile} />
        {view === 'verify' && file && <RriVerifyPanel key={file.transactionId} file={file} onDone={() => setFile(null)} />}
      </PageBody>
    </PageShell>
  );
}

function RriVerifyPanel({ file, onDone }: { file: RriMakerFile; onDone: () => void }) {
  const { t } = useRriMakerTranslation();
  const client = useQueryClient();
  const [page, setPage] = useState(1);
  const [draft, setDraft] = useState<RriDraft>({});
  const [submissionKey] = useState(newKey);
  const [result, setResult] = useState<RriForwardResponse | null>(null);
  // The failure itself is kept, not its message, so the message is read at render time in the reader's language.
  const [failure, setFailure] = useState<{ error: unknown } | null>(null);
  const lines = useQuery({
    queryKey: rriMakerKeys.lines(file.transactionId, page),
    queryFn: () => rriMakerApi.lines(file.transactionId, page, PAGE_SIZE),
  });
  const reasons = useQuery({ queryKey: rriMakerKeys.reasons(), queryFn: rriMakerApi.rejectReasons });
  const forward = useMutation({
    mutationFn: () => rriMakerApi.forward(file.transactionId, forwardBody(draft, submissionKey, lines.data?.verificationNo ?? file.verificationNo)),
    onSuccess: (r) => {
      setFailure(null);
      setResult(r);
      void client.invalidateQueries({ queryKey: rriMakerKeys.files('verify') });
    },
    onError: (e) => setFailure({ error: e }),
  });

  useEffect(() => {
    if (lines.data) setDraft((d) => mergePage(d, lines.data.lines));
  }, [lines.data]);

  const candidates = useMemo(() => acceptCandidates(draft), [draft]);
  const lineCount = lines.data?.lineCount ?? file.lineCount;
  const pages = Math.max(1, Math.ceil(lineCount / PAGE_SIZE));
  const bypass = lines.data?.balanceCheckRequired === false;

  if (result) return <RriForwardResult result={result} onDone={onDone} />;
  if (lines.isPending) return <LoadingSpinner />;
  if (lines.isError) return <p role="alert">{readProblem(t, lines.error).message}</p>;

  return (
    <section className="mt-6 flex flex-col gap-4" aria-label={t('VERIFY.LINES_OF', { fileName: file.fileName })}>
      {file.returnedByChecker && <ReturnedNotice file={file} />}
      {bypass && <BypassNotice />}
      <RriBalanceCheckPanel transactionId={file.transactionId} candidates={candidates} />
      <RriMakerLineGrid
        lines={lines.data.lines}
        draft={draft}
        reasons={reasons.data ?? []}
        onChange={(drrId: number, entry: RriDraftEntry) => setDraft((d) => ({ ...d, [drrId]: entry }))}
      />
      <div className="flex flex-wrap items-center gap-3">
        <Button variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
          {t('VERIFY.PREVIOUS')}
        </Button>
        <span>{t('VERIFY.PAGE_OF', { page, pages })}</span>
        <Button variant="outline" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
          {t('VERIFY.NEXT')}
        </Button>
        <Can permission={PERM.rriMakerVerify}>
          <Button
            variant="primary"
            disabled={!canConfirm(draft, lineCount) || forward.isPending}
            loading={forward.isPending}
            onClick={() => forward.mutate()}
          >
            {t('VERIFY.CONFIRM')}
          </Button>
        </Can>
      </div>
      {failure && <p role="alert">{readProblem(t, failure.error).message}</p>}
    </section>
  );
}

/**
 * v1.1 (design §4.1 "A returned file", §4.3, V-Q-3, V-Q-4; AC-DRF-09): the checker sent the file back. The draft starts empty; the
 * rejected verification's decisions and balance results are not carried over (the server returns only the new verification's), so the
 * presets come from the new verification's deciding results only.
 */
function ReturnedNotice({ file }: { file: RriMakerFile }) {
  const { t } = useRriMakerTranslation();
  return (
    <p role="note" aria-label={t('VERIFY.RETURNED_LABEL')} className="rounded border border-[var(--accent-amber)] p-2">
      {t('VERIFY.RETURNED_NOTICE', { rejected: file.rejectedVerificationNo ?? '', current: file.verificationNo })}
    </p>
  );
}

function BypassNotice() {
  const { t } = useRriMakerTranslation();
  return (
    <p role="note" className="rounded border border-[var(--accent-amber)] p-2">
      {t('VERIFY.BYPASS_NOTICE')}
    </p>
  );
}

/** The forward's answer (design §4.4 step 6): counts, the confirmation, the lines the server recorded differently, and the bypass. */
function RriForwardResult({ result, onDone }: { result: RriForwardResponse; onDone: () => void }) {
  const { t } = useRriMakerTranslation();
  return (
    <section className="mt-6 flex flex-col gap-3" aria-label={t('RESULT.LABEL')}>
      <p role="status">
        {t('RESULT.COUNTS', { confirmation: result.confirmation, accepted: result.acceptedCount, rejected: result.rejectedCount })}
      </p>
      {result.balanceCheckBypassed && <BypassNotice />}
      {result.serverChanged.length > 0 && (
        <div>
          <p>{t('RESULT.SERVER_CHANGED')}</p>
          <ul aria-label={t('RESULT.SERVER_CHANGES_LABEL')}>
            {result.serverChanged.map((c) => (
              <li key={c.lineNo}>
                {t('RESULT.SERVER_CHANGE', { lineNo: c.lineNo, decision: c.decision, reasonCode: c.reasonCode ?? '', cause: c.cause })}
              </li>
            ))}
          </ul>
        </div>
      )}
      <Button variant="outline" onClick={onDone}>
        {t('RESULT.BACK')}
      </Button>
    </section>
  );
}
