import { Badge } from '@paymenthub/ui';
import { maskAccount, maskId } from '../wps/piiMask';
import { NOT_DIB_ACCOUNT, SYSTEM_REASONS, type RriDraft } from './draft';
import { DECISION_KEY, useRriMakerTranslation, type RriMakerT } from './i18n';
import type { RriDecisionWord, RriDraftEntry, RriMakerLine, RriRejectReason } from './types';

const DECISIONS: readonly RriDecisionWord[] = ['ACCEPT', 'REJECT'];

/**
 * The displayed marker: NOT_LINKED and NOT_ON_DIF lines are "not blocked" (AC-DRF-04); a NOT_DIB_ACCOUNT line has no DIB account.
 * Every other marker is shown exactly as the server sends it.
 */
function markerLabel(t: RriMakerT, line: RriMakerLine): string {
  if (line.notEligibleReason === NOT_DIB_ACCOUNT) return t('LINES.MARKER_MAPPING_NOT_FOUND');
  if (line.notEligibleReason) return t('LINES.MARKER_NOT_BLOCKED');
  return line.marker;
}

function lockedLabel(t: RriMakerT, line: RriMakerLine, entry: RriDraftEntry): string {
  return line.notEligibleReason === NOT_DIB_ACCOUNT
    ? t('LINES.LOCKED_MAPPING_NOT_FOUND')
    : t('LINES.LOCKED_INSUFFICIENT', { reasonCode: entry.reasonCode ?? '' });
}

/**
 * One page of a file's lines with the maker's draft decisions (design §4.1, §4.3). Locked presets cannot be changed
 * (AC-DRF-01, AC-DRF-02). A REJECT needs a reason from the catalogue; the system codes 000 and 002 are never offered (AC-DRF-03).
 * The account and person ID are masked (UI guidelines §13).
 */
export function RriMakerLineGrid({
  lines,
  draft,
  reasons,
  onChange,
}: {
  lines: RriMakerLine[];
  draft: RriDraft;
  reasons: RriRejectReason[];
  onChange: (drrId: number, entry: RriDraftEntry) => void;
}) {
  const { t } = useRriMakerTranslation();
  const reasonOptions = reasons
    .filter((r) => !SYSTEM_REASONS.includes(r.code))
    .map((r) => ({ label: `${r.code} ${r.description}`, value: r.code }));

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" aria-label={t('LINES.TABLE')}>
        <thead>
          <tr className="text-left text-[var(--text-secondary)]">
            <th className="p-2">{t('LINES.COLUMNS.LINE')}</th>
            <th className="p-2">{t('LINES.COLUMNS.PERSON_ID')}</th>
            <th className="p-2">{t('LINES.COLUMNS.ACCOUNT')}</th>
            <th className="p-2">{t('LINES.COLUMNS.REFUND')}</th>
            <th className="p-2">{t('LINES.COLUMNS.TYPE')}</th>
            <th className="p-2">{t('LINES.COLUMNS.MARKER')}</th>
            <th className="p-2">{t('LINES.COLUMNS.BALANCE')}</th>
            <th className="p-2">{t('LINES.COLUMNS.DECISION')}</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((line) => {
            const entry = draft[line.drrId] ?? { decision: null, reasonCode: null, locked: false };
            return (
              <tr key={line.drrId} data-testid={`rri-line-${line.lineNo}`}>
                <td className="p-2">{line.lineNo}</td>
                <td className="p-2">{maskId(line.personId)}</td>
                <td className="p-2">{maskAccount(line.account)}</td>
                <td className="p-2">{line.refundAmount.toFixed(2)}</td>
                <td className="p-2">{line.refundType}</td>
                <td className="p-2">{markerLabel(t, line)}</td>
                <td className="p-2">{line.decidingOutcome ?? line.latestOutcome ?? ''}</td>
                <td className="p-2">
                  {entry.locked ? (
                    <Badge variant="red">{lockedLabel(t, line, entry)}</Badge>
                  ) : (
                    <DecisionCell line={line} entry={entry} reasonOptions={reasonOptions} onChange={onChange} />
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function DecisionCell({
  line,
  entry,
  reasonOptions,
  onChange,
}: {
  line: RriMakerLine;
  entry: RriDraftEntry;
  reasonOptions: { label: string; value: string }[];
  onChange: (drrId: number, entry: RriDraftEntry) => void;
}) {
  const { t } = useRriMakerTranslation();
  // Native selects, as in bank-policies/PolicyHistoryTab: a page holds up to 100 rows of two controls each, and the portalled shared
  // Select costs a popup per control. Build choice D-22.
  return (
    <div className="flex flex-wrap gap-2">
      <select
        aria-label={t('LINES.DECISION_FOR', { lineNo: line.lineNo })}
        className="input-cls h-38px px-2 text-xs"
        value={entry.decision ?? ''}
        onChange={(e) =>
          onChange(line.drrId, { decision: e.target.value === 'ACCEPT' ? 'ACCEPT' : e.target.value === 'REJECT' ? 'REJECT' : null, reasonCode: null, locked: false })
        }
      >
        <option value="">{t('LINES.DECIDE')}</option>
        {DECISIONS.map((d) => (
          <option key={d} value={d}>
            {t(DECISION_KEY[d])}
          </option>
        ))}
      </select>
      {entry.decision === 'REJECT' && (
        <select
          aria-label={t('LINES.REASON_FOR', { lineNo: line.lineNo })}
          className="input-cls h-38px px-2 text-xs"
          value={entry.reasonCode ?? ''}
          onChange={(e) => onChange(line.drrId, { ...entry, reasonCode: e.target.value || null })}
        >
          <option value="">{t('LINES.REASON')}</option>
          {reasonOptions.map((r) => (
            <option key={r.value} value={r.value}>
              {r.label}
            </option>
          ))}
        </select>
      )}
    </div>
  );
}
