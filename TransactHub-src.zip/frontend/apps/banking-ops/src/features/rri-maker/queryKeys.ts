import type { RriMakerView } from './types';

/** react-query keys of the RRI maker screen. `file(tx)` prefixes every lines page and run of that file. */
export const rriMakerKeys = {
  all: ['rriMaker'] as const,
  files: (view: RriMakerView) => [...rriMakerKeys.all, 'files', view] as const,
  file: (transactionId: string) => [...rriMakerKeys.all, 'file', transactionId] as const,
  lines: (transactionId: string, page: number) => [...rriMakerKeys.file(transactionId), 'lines', page] as const,
  run: (transactionId: string, runId: number) => [...rriMakerKeys.file(transactionId), 'run', runId] as const,
  reasons: () => [...rriMakerKeys.all, 'reasons'] as const,
};
