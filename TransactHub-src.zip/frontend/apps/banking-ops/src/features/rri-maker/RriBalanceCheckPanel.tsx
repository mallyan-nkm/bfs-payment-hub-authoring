import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Can } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { rriMakerApi } from './api';
import { readProblem } from './errors';
import { useRriMakerTranslation } from './i18n';
import { rriMakerKeys } from './queryKeys';

const POLL_MS = 2000;

/**
 * Starts a balance-check run over the lines the maker intends to accept, and shows its progress (design §4.2). The run is the only
 * write before confirm (AC-DRF-05). When it completes, the file's lines are re-read so that the deciding results, and with them the
 * INSUFFICIENT presets, are current (AC-DRF-02).
 */
export function RriBalanceCheckPanel({ transactionId, candidates }: { transactionId: string; candidates: number[] }) {
  const { t } = useRriMakerTranslation();
  const client = useQueryClient();
  const [runId, setRunId] = useState<number | null>(null);
  // The failure itself is kept, not its message, so the message is read at render time in the reader's language.
  const [failure, setFailure] = useState<{ error: unknown } | null>(null);
  const start = useMutation({
    mutationFn: () => rriMakerApi.startBalanceCheck(transactionId, candidates),
    onSuccess: (r) => {
      setFailure(null);
      setRunId(r.runId);
    },
    onError: (e) => setFailure({ error: e }),
  });
  const run = useQuery({
    queryKey: rriMakerKeys.run(transactionId, runId ?? 0),
    queryFn: () => rriMakerApi.balanceCheck(transactionId, runId ?? 0),
    enabled: runId !== null,
    refetchInterval: (q) => (q.state.data?.isComplete ? false : POLL_MS),
  });
  const complete = run.data?.isComplete === true;

  useEffect(() => {
    if (complete) void client.invalidateQueries({ queryKey: [...rriMakerKeys.file(transactionId), 'lines'] });
  }, [complete, client, transactionId]);

  return (
    <div className="flex flex-wrap items-center gap-3">
      <Can permission={PERM.rriMakerVerify}>
        <Button
          variant="secondary"
          disabled={candidates.length === 0 || start.isPending || (runId !== null && !complete)}
          loading={start.isPending}
          onClick={() => start.mutate()}
        >
          {t('BALANCE.CHECK', { candidates: candidates.length })}
        </Button>
      </Can>
      {run.data && (
        <span role="status">
          {t(complete ? 'BALANCE.COMPLETE' : 'BALANCE.RUNNING', { completed: run.data.completed, lineCount: run.data.lineCount })}
        </span>
      )}
      {failure && <span role="alert">{readProblem(t, failure.error).message}</span>}
    </div>
  );
}
