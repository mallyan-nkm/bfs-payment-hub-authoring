import { useRef, useState } from 'react';
import { cn } from '@paymenthub/ui';
import { paymentQueueProblem } from './api/paymentQueueApi';
import type { ActOnPaymentQueueItemResultDto } from './api/paymentQueueApi';
import {
  useActOnPaymentQueueItem,
  usePaymentQueueAvailableActions,
  usePaymentQueueReassignTargets,
} from './api/paymentQueueQueries';
import { usePaymentQueueTranslation } from './i18n';
import type { PaymentQueueT } from './i18n';
import type { PaymentQueueRow, QueueAction } from './types';

const APPROVE = 'APPROVE';
const RETURNED = 'RETURNED';

/** The fresh idempotency key of one attempt: a UUID, or a random fallback where `crypto.randomUUID` is absent. */
function newClientRequestId(): string {
  const c = globalThis.crypto as Crypto | undefined;
  return c?.randomUUID ? c.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

/** How a button looks, by action code. Which buttons exist is R10's decision; this only colours them. */
function buttonClass(code: string): string {
  if (code === APPROVE) return 'btn-primary pq-btn-approve';
  if (code === 'REJECT' || code === 'CLOSE') return 'btn-primary pq-btn-reject';
  return 'btn-tertiary';
}

/** The message shown for a refused or failed W1: the server's own text where it sent one. */
function failureMessage(t: PaymentQueueT, status: number, detail: string | null): string {
  if (status === 409) return t('FOOTER.CONFLICT', { reason: detail ?? t('FOOTER.CONFLICT_REASON') });
  if (status === 403) return detail ?? t('FOOTER.FORBIDDEN');
  return detail ?? t('FOOTER.FAILED');
}

/** What W1 applied: the button the user pressed (R10's label) and the server's answer, for the page's confirmation. */
export interface AppliedQueueAction {
  label: string;
  result: ActOnPaymentQueueItemResultDto;
}

interface Props {
  row: PaymentQueueRow;
  /** True for the View footer (All Queues tab, a View-only user): Close only, no remarks, no R10 call. */
  readOnly?: boolean;
  onClose: () => void;
  /** The action was applied (W1 answered 200). */
  onApplied: (action: QueueAction, remarks: string, applied: AppliedQueueAction) => void;
}

/**
 * The drawer footer (design §8.10, I-10; AC-PMQ-081). The buttons are exactly R10's actions: the screen never adds,
 * removes or relabels one. No offered action is the read-only footer: Close only and no Remarks field, so nobody
 * believes they acted. Choosing a button opens the confirm / cancel strip; Confirm posts W1.
 */
export function PaymentQueueActionFooter({ row, readOnly = false, onClose, onApplied }: Props) {
  const { t } = usePaymentQueueTranslation();
  const available = usePaymentQueueAvailableActions(row.id, !readOnly);
  const act = useActOnPaymentQueueItem(row.id);

  const [selected, setSelected] = useState<string | null>(null);
  const [remarks, setRemarks] = useState('');
  const [target, setTarget] = useState('');
  const [error, setError] = useState<string | null>(null);
  // After a 409 the row the page holds is stale: the state R10 was just refreshed on is the one to name.
  const [conflicted, setConflicted] = useState(false);
  // One attempt keeps its idempotency key until it is applied or refused, so a retry is the same request.
  const attempt = useRef<{ key: string; id: string } | null>(null);

  const offered = readOnly ? [] : (available.data?.actions ?? []);
  const chosen = offered.find((a) => a.action === selected) ?? null;
  const targets = usePaymentQueueReassignTargets(row.id, chosen?.requiresTargetDepartment === true);

  if (readOnly || (!available.isLoading && !available.isError && offered.length === 0)) {
    return (
      <div className="pq-modal-footer">
        <div className="pq-modal-actions">
          <button type="button" className="btn-secondary" onClick={onClose}>
            {t('COMMON.CLOSE')}
          </button>
        </div>
      </div>
    );
  }

  if (available.isLoading) {
    return (
      <div className="pq-modal-footer">
        <p className="pq-muted-note" role="status">
          {t('FOOTER.LOADING')}
        </p>
      </div>
    );
  }

  if (available.isError) {
    return (
      <div className="pq-modal-footer">
        <p role="alert" className="pq-footer-error">
          {t('FOOTER.LOAD_FAILED')}
        </p>
        <div className="pq-modal-actions">
          <button type="button" className="btn-secondary" onClick={() => void available.refetch()}>
            {t('COMMON.RETRY')}
          </button>
          <button type="button" className="btn-secondary" onClick={onClose}>
            {t('COMMON.CLOSE')}
          </button>
        </div>
      </div>
    );
  }

  const remarksMissing = chosen !== null && chosen.remarksMandatory && remarks.trim() === '';
  const targetMissing = chosen !== null && chosen.requiresTargetDepartment && target === '';
  const canConfirm = chosen !== null && !remarksMissing && !targetMissing && !act.isPending && !available.isFetching;

  function choose(code: string) {
    setSelected(code);
    setTarget('');
    setError(null);
  }

  function cancel() {
    setSelected(null);
    setTarget('');
    setError(null);
  }

  function confirm() {
    if (!chosen || !canConfirm) return;
    const text = remarks.trim();
    const expectedStateId = conflicted && available.data ? available.data.expectedStateId : row.currentStateId;
    const key = [chosen.action, text, target, expectedStateId].join('|');
    if (attempt.current?.key !== key) attempt.current = { key, id: newClientRequestId() };
    const clientRequestId = attempt.current.id;
    setError(null);

    act.mutate(
      {
        action: chosen.action,
        ...(text ? { remarks: text } : {}),
        ...(chosen.requiresTargetDepartment ? { targetDepartmentId: Number(target) } : {}),
        expectedStateId,
        clientRequestId,
      },
      {
        onSuccess: (result) => {
          attempt.current = null;
          onApplied(chosen.action, text, { label: chosen.label, result });
        },
        onError: (e) => {
          const { status, detail } = paymentQueueProblem(e);
          // A refusal is final for this attempt; only a failure with no answer is retried under the same key.
          if (status >= 400 && status < 500) attempt.current = null;
          if (status === 409) setConflicted(true);
          if (status === 409 || status === 403) setSelected(null);
          setError(failureMessage(t, status, detail));
        },
      },
    );
  }

  return (
    <div className="pq-modal-footer">
      <label className="pq-comment-label" htmlFor="pq-comment">
        {chosen?.remarksMandatory ? t('FOOTER.COMMENT_REQUIRED') : t('FOOTER.COMMENT')}
      </label>
      <textarea
        id="pq-comment"
        rows={2}
        value={remarks}
        onChange={(e) => setRemarks(e.target.value)}
        placeholder={t('FOOTER.COMMENT_PLACEHOLDER')}
        className="pq-comment-input"
        aria-required={chosen?.remarksMandatory === true}
        disabled={act.isPending}
      />

      <div className="pq-modal-actions" role="group" aria-label={t('FOOTER.ACTIONS')}>
        {offered.map((a) => (
          <button
            key={a.action}
            type="button"
            className={cn(buttonClass(a.action), selected === a.action && 'pq-action-selected')}
            aria-pressed={selected === a.action}
            disabled={act.isPending}
            onClick={() => choose(a.action)}
          >
            {a.label}
          </button>
        ))}
      </div>

      {chosen && (
        <div className="pq-confirm-strip" role="group" aria-label={t('FOOTER.CONFIRM', { action: chosen.label })}>
          {chosen.action === APPROVE && row.stateCode === RETURNED && <p className="pq-footer-hint">{t('FOOTER.RESUBMIT_HINT')}</p>}

          {chosen.requiresTargetDepartment && (
            <div className="pq-confirm-field">
              <label className="pq-comment-label" htmlFor="pq-reassign-target">
                {t('FOOTER.REASSIGN_TO')}
              </label>
              {targets.isError ? (
                <p role="alert" className="pq-footer-error">
                  {t('FOOTER.DEPARTMENTS_FAILED')}
                </p>
              ) : (
                <select
                  id="pq-reassign-target"
                  className="pq-comment-input"
                  value={target}
                  disabled={targets.isLoading || act.isPending}
                  onChange={(e) => setTarget(e.target.value)}
                >
                  <option value="">{targets.isLoading ? t('FOOTER.DEPARTMENTS_LOADING') : t('FOOTER.SELECT_DEPARTMENT')}</option>
                  {(targets.data ?? []).map((target) => (
                    <option key={target.departmentId} value={String(target.departmentId)} disabled={target.noEligibleActor}>
                      {target.noEligibleActor ? t('FOOTER.NO_ELIGIBLE', { name: target.departmentName }) : target.departmentName}
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {remarksMissing && <p className="pq-footer-hint">{t('FOOTER.REMARKS_REQUIRED', { action: chosen.label })}</p>}

          <div className="pq-modal-actions">
            <button type="button" className="btn-primary" disabled={!canConfirm} onClick={confirm}>
              {t('FOOTER.CONFIRM', { action: chosen.label })}
            </button>
            <button type="button" className="btn-secondary" disabled={act.isPending} onClick={cancel}>
              {t('COMMON.CANCEL')}
            </button>
          </div>
        </div>
      )}

      {error && (
        <p role="alert" className="pq-footer-error">
          {error}
        </p>
      )}
    </div>
  );
}
