import { parseMultiFilter } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import type { PaymentQueueGridFilters } from './api/paymentQueueApi';
import type { FilterCode, PanelOptions } from './filterOptions';
import type { PaymentQueueRow } from './types';

/**
 * The grid's inline column filters (the Filters toggle), as far as R1 can apply them.
 *
 * R1 filters on the left panel's nine fields only, so exactly those columns carry a filter: Queue Status, Payment Type,
 * Rail, Channel, Priority, Amount (minimum) and Transaction Date. A column with no R1 filter (names, references,
 * accounts) has no filter icon, because a filter the server cannot apply would only narrow the page held in the browser
 * and make the total and the paging wrong.
 *
 * Column filters are session-only and additive (FSD BR-PMQ-008, design R-16): they narrow what the left panel already
 * narrowed, and they are never part of the saved filter. {@link mergeColumnFilters} is where the two meet.
 */

/** The `filterKey`s the grid's filter row edits; a date range adds `From` and `To` to its key. */
export const COLUMN_FILTER_KEY = {
  status: 'queueStatus',
  paymentType: 'paymentType',
  rail: 'rail',
  channel: 'channel',
  priority: 'priority',
  amount: 'amount',
  date: 'transactionDate',
} as const;

type ColumnFilterFields = Pick<SmartGridColumn<PaymentQueueRow>, 'filterKey' | 'filterType' | 'filterOptions'>;

/**
 * The filter a column carries, or nothing when R4 has turned that filter off for the tenant (the panel hides it for the
 * same reason, so a filter that is off never narrows the grid unseen). Lists are the panel's own values.
 */
export function columnFilterFor(column: string, options: PanelOptions): ColumnFilterFields {
  const on = (code: FilterCode) => options.enabled.has(code);
  switch (column) {
    case 'queueStatus':
      return on('status')
        ? { filterKey: COLUMN_FILTER_KEY.status, filterType: 'multiSelect', filterOptions: options.status }
        : {};
    case 'paymentType':
      return on('paymentType')
        ? { filterKey: COLUMN_FILTER_KEY.paymentType, filterType: 'multiSelect', filterOptions: options.paymentType }
        : {};
    case 'rail':
      return on('rail') ? { filterKey: COLUMN_FILTER_KEY.rail, filterType: 'multiSelect', filterOptions: options.rail } : {};
    case 'channel':
      return on('channel')
        ? { filterKey: COLUMN_FILTER_KEY.channel, filterType: 'multiSelect', filterOptions: options.channel }
        : {};
    case 'priority':
      return on('priority')
        ? { filterKey: COLUMN_FILTER_KEY.priority, filterType: 'multiSelect', filterOptions: options.priority }
        : {};
    case 'amount':
      return on('amount') ? { filterKey: COLUMN_FILTER_KEY.amount, filterType: 'number' } : {};
    case 'transactionDate':
      return on('dateRange') ? { filterKey: COLUMN_FILTER_KEY.date, filterType: 'dateRange' } : {};
    default:
      return {};
  }
}

export interface MergedFilters {
  filters: PaymentQueueGridFilters;
  /** The panel and the column filters cannot both hold (no value in common, or a minimum above a maximum): no row matches. */
  none: boolean;
}

/** Both groups narrow: a value must be in both. R1 reads an empty list as "no filter", so an empty overlap is reported separately. */
function intersect(panel: string[] | undefined, column: string[]): { values: string[] | undefined; none: boolean } {
  if (column.length === 0) return { values: panel, none: false };
  if (!panel || panel.length === 0) return { values: column, none: false };
  const both = panel.filter((v) => column.includes(v));
  return { values: both, none: both.length === 0 };
}

function numberOf(value: string | undefined): number | undefined {
  if (!value || !value.trim()) return undefined;
  const n = Number(value);
  return Number.isFinite(n) ? n : undefined;
}

const DAY = /^\d{4}-\d{2}-\d{2}$/;

/**
 * The left panel's R1 filters narrowed by the grid's column filters. `column` is the grid's flat filter record
 * (`multiSelect` values comma-joined, a date range as `<key>From` / `<key>To`). Amount and date bounds take the tighter
 * of the two; `yyyy-MM-dd` strings compare in date order.
 */
export function mergeColumnFilters(panel: PaymentQueueGridFilters, column: Record<string, string>): MergedFilters {
  const status = intersect(panel.status, parseMultiFilter(column[COLUMN_FILTER_KEY.status]));
  const paymentType = intersect(panel.paymentType, parseMultiFilter(column[COLUMN_FILTER_KEY.paymentType]));
  const rail = intersect(panel.rail, parseMultiFilter(column[COLUMN_FILTER_KEY.rail]));
  const channel = intersect(panel.channel, parseMultiFilter(column[COLUMN_FILTER_KEY.channel]));
  const priority = intersect(panel.priority, parseMultiFilter(column[COLUMN_FILTER_KEY.priority]));

  const panelMin = numberOf(panel.amountMin);
  const columnMin = numberOf(column[COLUMN_FILTER_KEY.amount]);
  const min = panelMin !== undefined && columnMin !== undefined ? Math.max(panelMin, columnMin) : (columnMin ?? panelMin);
  const max = numberOf(panel.amountMax);

  const columnFrom = column[`${COLUMN_FILTER_KEY.date}From`];
  const columnTo = column[`${COLUMN_FILTER_KEY.date}To`];
  const from = [panel.dateFrom, DAY.test(columnFrom ?? '') ? columnFrom : undefined].filter((d): d is string => !!d).sort().pop();
  const to = [panel.dateTo, DAY.test(columnTo ?? '') ? columnTo : undefined].filter((d): d is string => !!d).sort()[0];

  const none =
    status.none ||
    paymentType.none ||
    rail.none ||
    channel.none ||
    priority.none ||
    (min !== undefined && max !== undefined && min > max) ||
    (from !== undefined && to !== undefined && from > to);

  return {
    none,
    filters: {
      status: status.values,
      paymentType: paymentType.values,
      rail: rail.values,
      channel: channel.values,
      priority: priority.values,
      amountMin: min !== undefined ? String(min) : panel.amountMin,
      amountMax: panel.amountMax,
      dateFrom: from,
      dateTo: to,
    },
  };
}
