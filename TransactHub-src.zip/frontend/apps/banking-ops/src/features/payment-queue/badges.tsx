import { cn } from '@paymenthub/ui';
import { PAYMENT_TYPE_KEY, PRIORITY_KEY, usePaymentQueueTranslation } from './i18n';
import type { KnownQueueStatus, MessageType, PriorityLevel, QueueStatus, RailCode } from './types';

/** The server's numbered approval labels ("Pending Approver 1", "Pending Approver 2", …; BA AC-23) take the pending tone. */
const NUMBERED_APPROVER_LABEL = /^Pending Approver \d+$/;

/** Tones of the server's default labels (BA AC-24). A label a bank has renamed shows neutral. */
const STATUS_TONE: Record<KnownQueueStatus, string> = {
  'Pending Approval': 'warn',
  'Pending Action': 'blue',
  Held: '',
  Returned: 'error',
};

function statusTone(status: QueueStatus): string {
  if (NUMBERED_APPROVER_LABEL.test(status)) {
    return STATUS_TONE['Pending Approval'];
  }
  return Object.hasOwn(STATUS_TONE, status) ? STATUS_TONE[status as KnownQueueStatus] : '';
}

const PRIORITY_TONE: Record<PriorityLevel, string> = {
  Urgent: 'error',
  High: 'warn',
  Normal: '',
};

const MESSAGE_TONE: Record<MessageType, string> = {
  SIF: 'blue',
  'SIF NAK': 'error',
  MT103: 'blue',
  'pacs.008': 'blue',
  ACK: 'success',
};

export function RailBadge({ rail }: { rail: RailCode }) {
  return (
    <span className="common-badge pq-rail-badge" data-rail={rail.toUpperCase()}>
      {rail}
    </span>
  );
}

export function QueueStatusBadge({ status }: { status: QueueStatus }) {
  return <span className={cn('status-badge', statusTone(status))}>{status}</span>;
}

/** Priority and Payment Type are words the screen's own mapper produces, so they are translated; the rest render as sent. */
export function PriorityBadge({ priority }: { priority: PriorityLevel }) {
  const { t } = usePaymentQueueTranslation();
  return <span className={cn('status-badge', PRIORITY_TONE[priority])}>{t(PRIORITY_KEY[priority])}</span>;
}

export function MessageTypeBadge({ messageType }: { messageType: MessageType }) {
  return <span className={cn('status-badge', MESSAGE_TONE[messageType])}>{messageType}</span>;
}

export function PaymentTypeBadge({ type }: { type: 'Batch' | 'Single' }) {
  const { t } = usePaymentQueueTranslation();
  return <span className="status-badge">{t(PAYMENT_TYPE_KEY[type])}</span>;
}
