import { QUEUE_STATUS_LABELS } from './types';
import type { PaymentTypeFilter, PriorityLevel } from './types';
import type { AdvancedFilterState } from './AdvancedFilterPanel';
import type { PaymentQueueFilterOptionsDto, PaymentQueueGridFilters } from './api/paymentQueueApi';

/** The filter codes R4 can enable (design §9.1), in the order the panel draws them. */
export type FilterCode = 'status' | 'paymentType' | 'rail' | 'channel' | 'priority' | 'amount' | 'dateRange';

const ALL_CODES: readonly FilterCode[] = ['status', 'paymentType', 'rail', 'channel', 'priority', 'amount', 'dateRange'];

const PAYMENT_TYPES: readonly PaymentTypeFilter[] = ['Batch', 'Single'];
const PRIORITIES: readonly PriorityLevel[] = ['Urgent', 'High', 'Normal'];

/** What the panel draws: which filters are on, and the chip values of the ones that pick from a list. */
export interface PanelOptions {
  enabled: ReadonlySet<FilterCode>;
  status: string[];
  paymentType: PaymentTypeFilter[];
  rail: string[];
  channel: string[];
  priority: PriorityLevel[];
}

/**
 * The panel before R4 has answered, or when it cannot: every filter on, the fixed lists the screen has always had, and
 * no Rail or Channel values (they exist only in the data; nothing is invented). The filters still apply on the server.
 */
export const FALLBACK_PANEL_OPTIONS: PanelOptions = {
  enabled: new Set<FilterCode>(ALL_CODES),
  status: [...QUEUE_STATUS_LABELS],
  paymentType: [...PAYMENT_TYPES],
  rail: [],
  channel: [],
  priority: [...PRIORITIES],
};

function isFilterCode(value: string): value is FilterCode {
  return ALL_CODES.some((c) => c === value);
}

function optionsOf(dto: PaymentQueueFilterOptionsDto, code: FilterCode): string[] {
  return dto.filters.find((f) => f.code === code)?.options ?? [];
}

/**
 * R4's answer as the panel's options: the filters it lists are on (a filter it leaves out is off, and a blank setting
 * leaves out all of them), and the chip values are the server's, already limited to the caller's scope. A code this
 * build does not know is ignored.
 */
export function toPanelOptions(dto: PaymentQueueFilterOptionsDto): PanelOptions {
  return {
    enabled: new Set(dto.filters.map((f) => f.code).filter(isFilterCode)),
    status: optionsOf(dto, 'status'),
    paymentType: optionsOf(dto, 'paymentType').filter((v): v is PaymentTypeFilter => PAYMENT_TYPES.some((p) => p === v)),
    rail: optionsOf(dto, 'rail'),
    channel: optionsOf(dto, 'channel'),
    priority: optionsOf(dto, 'priority').filter((v): v is PriorityLevel => PRIORITIES.some((p) => p === v)),
  };
}

/** The most an amount filter can say: a larger number is clamped (the column is DECIMAL(18,4)). */
const AMOUNT_LIMIT = 1e14;

/** An amount as R1 reads it, or nothing for a blank or non-numeric entry. */
function amountText(value: string): string | undefined {
  const trimmed = value.trim();
  if (!trimmed) return undefined;
  const n = Number(trimmed);
  return Number.isFinite(n) ? String(Math.min(Math.max(n, -AMOUNT_LIMIT), AMOUNT_LIMIT)) : undefined;
}

/** A date as R1 reads it (`yyyy-MM-dd`, a date input's own value), or nothing while the input is incomplete. */
function dateText(value: string): string | undefined {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : undefined;
}

/**
 * The panel's state as R1's filter parameters. Only filters that are on are sent, so a filter the setting has since
 * turned off never narrows the grid unseen. The panel is single-select per group, so each list holds at most one value.
 */
export function toGridFilters(state: AdvancedFilterState, enabled: ReadonlySet<FilterCode>): PaymentQueueGridFilters {
  const on = (code: FilterCode) => enabled.has(code);
  return {
    status: on('status') ? state.status : undefined,
    paymentType: on('paymentType') ? state.paymentType : undefined,
    rail: on('rail') ? state.rail : undefined,
    channel: on('channel') ? state.channel : undefined,
    priority: on('priority') ? state.priority : undefined,
    amountMin: on('amount') ? amountText(state.amountMin) : undefined,
    amountMax: on('amount') ? amountText(state.amountMax) : undefined,
    dateFrom: on('dateRange') ? dateText(state.dateFrom) : undefined,
    dateTo: on('dateRange') ? dateText(state.dateTo) : undefined,
  };
}
