import { LoadingSpinner } from '@paymenthub/ui';
import { SideSheet } from '../../shared/components/SideSheet';
import { asUtcIso } from './api/paymentQueueApi';
import { usePaymentQueueAuditTrail } from './api/paymentQueueQueries';
import { formatDateTime, usePaymentQueueTranslation } from './i18n';
import type { PaymentQueueRow } from './types';

/** Shown for a value the server did not send. */
const NOT_AVAILABLE = '—';

/** "PENDING → HELD", or the one state the server knows, or "—". */
function stateChange(from: string | null | undefined, to: string | null | undefined): string {
  if (from && to) return `${from} → ${to}`;
  return from || to || NOT_AVAILABLE;
}

interface Props {
  row: PaymentQueueRow;
  onClose: () => void;
}

/**
 * The Audit Trail of one queue item (design §10: the row's Audit Trail button opens the common Audit Trail, not a
 * screen-local list; P1-5 ruling Z11: the page key is the only gate). It shows what the audit-trail route returns,
 * newest first, in the shared right-docked sheet, and never builds a row of its own.
 */
export function PaymentQueueAuditTrail({ row, onClose }: Props) {
  const { t, i18n } = usePaymentQueueTranslation();
  const audit = usePaymentQueueAuditTrail(row.id);
  const entries = audit.data ?? [];

  return (
    <SideSheet
      eyebrow={t('AUDIT.EYEBROW')}
      title={row.systemReferenceNo}
      ariaLabel={t('AUDIT.ARIA', { reference: row.systemReferenceNo })}
      widthClass="max-w-4xl"
      onClose={onClose}
      footer={
        <button type="button" onClick={onClose} className="btn-secondary ms-auto">
          {t('COMMON.CLOSE')}
        </button>
      }
    >
      {audit.isLoading ? (
        <div className="flex h-48 items-center justify-center">
          <LoadingSpinner label={t('AUDIT.LOADING')} />
        </div>
      ) : audit.isError ? (
        <div role="alert" className="flex flex-col items-center gap-3 p-6 text-center text-sm text-[var(--text-2)]">
          <p>{t('AUDIT.FAILED')}</p>
          <button type="button" className="btn-secondary" onClick={() => void audit.refetch()}>
            {t('COMMON.RETRY')}
          </button>
        </div>
      ) : entries.length === 0 ? (
        <p className="p-6 text-center text-sm text-[var(--text-muted)]">{t('AUDIT.EMPTY')}</p>
      ) : (
        <div className="table-holder overflow-x-auto rounded-lg border border-[var(--border)] pq-audit-table">
          <table>
            <thead>
              <tr>
                <th>{t('AUDIT.EVENT')}</th>
                <th>{t('AUDIT.ACTION_BY')}</th>
                <th>{t('AUDIT.DATE_TIME')}</th>
                <th>{t('AUDIT.STATE')}</th>
                <th>{t('AUDIT.LEVEL')}</th>
                <th>{t('AUDIT.REMARKS')}</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.auditId}>
                  <td className="pq-audit-activity">{e.eventType}</td>
                  <td>{e.userName || e.userId || t('SYSTEM')}</td>
                  <td>{formatDateTime(asUtcIso(e.occurredAt), i18n.language)}</td>
                  <td>{stateChange(e.fromState, e.toState)}</td>
                  <td>{e.stageSeq ?? NOT_AVAILABLE}</td>
                  <td>{e.remarks || NOT_AVAILABLE}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </SideSheet>
  );
}
