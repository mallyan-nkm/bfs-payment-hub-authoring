import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { renderWithProviders } from '../../../test/renderWithProviders';
import { toTabCounts } from './api/paymentQueueApi';
import { QueueStatusBadge } from './badges';
import { PaymentQueuePage } from './PaymentQueuePage';
import { QUEUE_STATUS_LABELS } from './types';

/**
 * PMQ-P4-2: two tabs (AC-PMQ-079, B-14, N-19) and the server's four Queue Status labels (BA AC-24).
 */

function renderPage() {
  return renderWithProviders(
    <PaymentQueuePage
      direction="outward"
      title="Payment Queue Outward"
      tabCounts={toTabCounts({ all: 4, actionable: 1 })}
    />,
  );
}

describe('Payment Queue tabs (AC-PMQ-079)', () => {
  it('shows exactly All Queues and Payment Queue, each with one badge', () => {
    renderPage();

    const tabs = screen.getAllByRole('tab');
    expect(tabs.map((t) => t.querySelector('.pq-tab-label')?.textContent)).toEqual(['All Queues', 'Payment Queue']);
    expect(tabs.map((t) => t.querySelector('.pq-tab-count')?.textContent)).toEqual(['4', '1']);
  });

  it('has no Compliance or Fraud tab', () => {
    renderPage();

    expect(screen.queryByRole('tab', { name: /compliance|fraud/i })).not.toBeInTheDocument();
    expect(screen.queryByText(/compliance|fraud/i)).not.toBeInTheDocument();
  });

  it('shows every row on All Queues and only the actionable rows on Payment Queue', async () => {
    renderPage();
    expect(screen.getAllByRole('row')).toHaveLength(5);

    await userEvent.click(screen.getByRole('tab', { name: /Payment Queue/ }));

    expect(screen.getAllByRole('row')).toHaveLength(2);
    expect(screen.getByText('REF-A')).toBeInTheDocument();
    expect(screen.queryByText('REF-B')).not.toBeInTheDocument();
  });
});

describe('Payment Queue status labels (BA AC-24)', () => {
  it('shows the server label of each row', () => {
    renderPage();

    const body = screen.getAllByRole('row').slice(1);
    const labels = body.map((r) => within(r).getByText(/^(Pending Approval|Pending Action|Held|Returned)$/).textContent);
    expect(labels).toEqual(['Pending Approval', 'Pending Action', 'Held', 'Returned']);
  });

  it('gives each label its own tone and renders an unknown label neutral', () => {
    const tone = (status: string) => {
      const { container, unmount } = render(<QueueStatusBadge status={status} />);
      const cls = container.firstElementChild?.className ?? '';
      unmount();
      return cls;
    };

    expect(tone('Pending Approval')).toContain('warn');
    expect(tone('Pending Action')).toContain('blue');
    expect(tone('Returned')).toContain('error');
    expect(tone('Held')).toBe('status-badge');
    expect(tone('Renamed By Bank')).toBe('status-badge');
    // A name on Object.prototype is not a label.
    expect(tone('toString')).toBe('status-badge');
  });

  it('offers exactly the four labels in the Status filter, and filters by one', async () => {
    renderPage();

    const select = screen.getByRole('combobox', { name: 'Status' });
    const options = within(select)
      .getAllByRole('option')
      .map((o) => o.textContent);
    expect(options).toEqual(['All', ...QUEUE_STATUS_LABELS]);
    expect(options).not.toContain('Escalated');
    expect(options).not.toContain('Pending Maker');
    expect(options).not.toContain('Pending Checker');

    await userEvent.selectOptions(select, 'Held');

    expect(screen.getAllByRole('row')).toHaveLength(2);
    expect(screen.getByText('REF-C')).toBeInTheDocument();
  });
});

describe('Payment Queue source (AC-PMQ-079)', () => {
  const sources = import.meta.glob<string>(['./types.ts', './PaymentQueuePage.tsx', './badges.tsx', './AdvancedFilterPanel.tsx'], {
    query: '?raw',
    import: 'default',
    eager: true,
  });

  it('reads the four files', () => {
    expect(Object.keys(sources).sort()).toEqual(['./AdvancedFilterPanel.tsx', './PaymentQueuePage.tsx', './badges.tsx', './types.ts']);
  });

  it('names QueueTabKey as all | payment, with no Compliance or Fraud code left', () => {
    expect(sources['./types.ts']).toMatch(/export type QueueTabKey = 'all' \| 'payment';/);
    const offenders = Object.entries(sources)
      .filter(([, text]) => /compliance|fraud/i.test(text))
      .map(([path]) => path);
    expect(offenders).toEqual([]);
  });

  it('keeps no mock status label or Escalate control in the page, badges or filter', () => {
    const offenders = Object.entries(sources)
      .filter(([path]) => path !== './types.ts')
      .filter(([, text]) => /Pending Maker|Pending Checker|Escalat/.test(text))
      .map(([path]) => path);
    expect(offenders).toEqual([]);
  });
});
