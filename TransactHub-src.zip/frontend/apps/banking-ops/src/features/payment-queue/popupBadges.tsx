import { cn } from '@paymenthub/ui';
import type { PopupValue, PopupValues } from './popupValues';

/**
 * Adapter field codes the popup draws as a badge (BA AC-36: Charge Source as a "Global" badge). The server sends their
 * value as text; a badge is a client-built node, so the text is wrapped here and nothing else about the value changes.
 * Masking is unaffected: the server has already decided what the text is. Add a code here to badge another text field.
 */
const BADGE_FIELD_CODES: ReadonlySet<string> = new Set(['charge.source']);

function asBadge(value: PopupValue): PopupValue {
  if (typeof value !== 'string' || value.trim() === '') return value;
  return { type: 'node', node: <span className={cn('status-badge', 'blue')}>{value}</span> };
}

/** The adapter's values with the badge fields wrapped; every other field and every grid is returned as it was. */
export function withBadgeFields(values: PopupValues): PopupValues {
  const fields = { ...values.fields };
  for (const code of BADGE_FIELD_CODES) {
    if (code in fields) fields[code] = asBadge(fields[code]);
  }
  return { ...values, fields };
}
