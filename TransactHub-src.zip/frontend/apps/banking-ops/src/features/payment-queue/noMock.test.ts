import { describe, expect, it } from 'vitest';

/**
 * AC-PMQ-083: the mock of the Payment Queue screen is gone. Reads the feature folder's source (bundler glob, no Node
 * types needed), so a mock file that comes back, or an import of one, fails here rather than showing fake rows on a
 * failed call.
 */
const sources = import.meta.glob<string>(['./**/*.ts', './**/*.tsx', '!./**/*.test.ts', '!./**/*.test.tsx'], {
  query: '?raw',
  import: 'default',
  eager: true,
});

const files = Object.entries(sources);

describe('Payment Queue: no mock (AC-PMQ-083)', () => {
  it('reads the feature source', () => {
    // Guards the scan below against a glob that silently matches nothing.
    expect(files.map(([path]) => path)).toEqual(
      expect.arrayContaining(['./PaymentQueuePage.tsx', './api/paymentQueueApi.ts', './outward/PaymentQueueOutwardPage.tsx']),
    );
  });

  it('has neither mock file', () => {
    const paths = files.map(([path]) => path);
    expect(paths).not.toContain('./mockGenerator.ts');
    expect(paths).not.toContain('./outward/mockData.ts');
  });

  it('imports no mock module from any source file', () => {
    const offenders = files
      .filter(([, text]) => /from\s+['"][^'"]*(mockGenerator|mockData)['"]/.test(text))
      .map(([path]) => path);
    expect(offenders).toEqual([]);
  });

  it('names no mock constant or builder', () => {
    const offenders = files
      .filter(([, text]) => /\b(OUTWARD_ROWS|OUTWARD_TAB_COUNTS|buildMockRows?)\b/.test(text))
      .map(([path]) => path);
    expect(offenders).toEqual([]);
  });
});
