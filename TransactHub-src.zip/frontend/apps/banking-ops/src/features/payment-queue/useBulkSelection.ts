import { useMemo, useRef, useState } from 'react';
import type { PaymentQueueRow } from './types';

interface Options {
  /** The rows the grid shows now: the current page only, empty while it loads. */
  pageRows: PaymentQueueRow[];
  /** The most records one bulk action takes (W2's limit, design §6.5). */
  max: number;
  /** Called when a tick is refused for the cap. */
  onCapReached: () => void;
}

export interface BulkSelection {
  /** The ticked row ids, for the grid's checkboxes. */
  selectedIds: Set<string>;
  /** A snapshot of each ticked row, as it was read when it was ticked, in the order ticked. */
  selectedRows: PaymentQueueRow[];
  /** A row's checkbox; also called once per row by the grid's header checkbox, which acts on the current page only. */
  toggle: (id: string) => void;
  /** Unticks everything: a filter change, a tab change or Clear. */
  clear: () => void;
  /** Unticks the records a bulk action applied; the others stay ticked. */
  removeApplied: (ids: ReadonlySet<string>) => void;
}

/**
 * The bulk selection of the Payment Queue in server mode (PMQ-P7-4).
 *
 * In server mode only the current page is in the browser, but a bulk action may cover rows ticked on several pages, so
 * the selection keeps a **snapshot of each ticked row**, taken from the page when the row is ticked. Everything the bulk
 * bar and W2 need is read from the snapshots, never from the page the grid now shows: the rail, message type and
 * payment type that must agree, `isActionable` (the Payment Queue tab only), and `currentStateId`, which becomes the
 * record's `expectedStateId` exactly as it was read when the row was ticked (a record that has moved since is a
 * `conflict` in W2's answer, never acted on blind).
 *
 * The cap counts the snapshots across all pages. The state and a ref are one value written together: the grid's header
 * checkbox calls `toggle` once per row inside one event, before React re-renders, so each call must see what the calls
 * before it added.
 */
export function useBulkSelection({ pageRows, max, onCapReached }: Options): BulkSelection {
  const [selection, setSelection] = useState<ReadonlyMap<string, PaymentQueueRow>>(() => new Map());
  const selectionRef = useRef<ReadonlyMap<string, PaymentQueueRow>>(selection);
  const pageRowsRef = useRef(pageRows);
  pageRowsRef.current = pageRows;

  /** The one place the selection changes, so the ref and the state never disagree. */
  function commit(next: ReadonlyMap<string, PaymentQueueRow>) {
    selectionRef.current = next;
    setSelection(next);
  }

  function toggle(id: string) {
    const current = selectionRef.current;
    if (current.has(id)) {
      const next = new Map(current);
      next.delete(id);
      commit(next);
      return;
    }

    // Only a row the grid is showing can be ticked, and its snapshot is that row as read now.
    const row = pageRowsRef.current.find((r) => r.id === id);
    if (!row) return;

    if (current.size >= max) {
      onCapReached();
      return;
    }
    commit(new Map(current).set(id, row));
  }

  function clear() {
    commit(new Map());
  }

  function removeApplied(ids: ReadonlySet<string>) {
    commit(new Map([...selectionRef.current].filter(([id]) => !ids.has(id))));
  }

  const selectedIds = useMemo(() => new Set(selection.keys()), [selection]);
  const selectedRows = useMemo(() => [...selection.values()], [selection]);
  return { selectedIds, selectedRows, toggle, clear, removeApplied };
}
