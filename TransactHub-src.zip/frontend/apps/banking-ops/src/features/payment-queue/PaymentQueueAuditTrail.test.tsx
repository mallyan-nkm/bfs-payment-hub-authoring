import { screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { apiOk, renderWithProviders } from '../../../test/renderWithProviders';
import { queueRow } from '../../../test/paymentQueueFixtures';
import type { PaymentQueueAuditTrailRowDto } from './api/paymentQueueApi';
import { PaymentQueueAuditTrail } from './PaymentQueueAuditTrail';

vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

const AUDIT_URL = '/ops/payment-queue/items/PQ-0001/audit-trail';

const auditRow = (over: Partial<PaymentQueueAuditTrailRowDto> = {}): PaymentQueueAuditTrailRowDto => ({
  auditId: 1,
  eventType: 'PaymentQueue.Approved',
  action: 'APPROVE',
  occurredAt: '2026-10-17T09:30:00Z',
  userId: 'sara.khan',
  userName: 'Sara Khan',
  fromState: 'PENDING',
  toState: 'PENDING',
  stageSeq: 2,
  remarks: 'Looks fine',
  ...over,
});

beforeEach(() => {
  get.mockReset();
});

describe('Payment Queue Audit Trail (replaces the screen-local AuditTrailModal)', () => {
  it('shows what the audit-trail route returns, in its order, for the item', async () => {
    get.mockResolvedValue(
      apiOk([
        auditRow({ auditId: 2, eventType: 'PaymentQueue.Held', userName: null, userId: null, toState: 'HELD', remarks: null }),
        auditRow({ auditId: 1 }),
      ]),
    );
    renderWithProviders(<PaymentQueueAuditTrail row={queueRow()} onClose={vi.fn()} />);

    const table = await screen.findByRole('table');
    expect(get).toHaveBeenCalledWith(AUDIT_URL);
    const rows = within(table).getAllByRole('row').slice(1);
    expect(rows).toHaveLength(2);
    expect(rows[0]).toHaveTextContent('PaymentQueue.Held');
    expect(rows[0]).toHaveTextContent('System');
    expect(rows[0]).toHaveTextContent('PENDING → HELD');
    expect(rows[1]).toHaveTextContent('Sara Khan');
    expect(rows[1]).toHaveTextContent('17-10-2026 13:30:00');
    expect(rows[1]).toHaveTextContent('Looks fine');
    expect(screen.getByRole('dialog', { name: 'Audit trail for WPS-2026-00401' })).toBeInTheDocument();
  });

  it('says so when there are no events', async () => {
    get.mockResolvedValue(apiOk([]));
    renderWithProviders(<PaymentQueueAuditTrail row={queueRow()} onClose={vi.fn()} />);
    expect(await screen.findByText('No audit events are recorded for this item.')).toBeInTheDocument();
  });

  it('says so when the route fails, with no invented rows', async () => {
    get.mockRejectedValue(new Error('boom'));
    renderWithProviders(<PaymentQueueAuditTrail row={queueRow()} onClose={vi.fn()} />);
    expect(await screen.findByText('The audit trail could not be loaded.')).toBeInTheDocument();
    expect(screen.queryByRole('table')).not.toBeInTheDocument();
  });

  it('closes from the footer', async () => {
    get.mockResolvedValue(apiOk([]));
    const onClose = vi.fn();
    renderWithProviders(<PaymentQueueAuditTrail row={queueRow()} onClose={onClose} />);
    await screen.findByText('No audit events are recorded for this item.');

    const footer = document.querySelector('footer') as HTMLElement;
    await userEvent.click(within(footer).getByRole('button', { name: 'Close' }));
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('is the only audit trail view: the screen-local modal file is gone', () => {
    const files = Object.keys(import.meta.glob('./AuditTrailModal.tsx'));
    expect(files).toEqual([]);
  });
});
