import { useQuery } from '@tanstack/react-query';
import { bankingApi } from '../../../shared/api/bankingApi';
import { parsePopupLayout, SUPPORTED_LAYOUT_SCHEMA_VERSION } from '../popupLayout';
import type { PopupLayout } from '../popupLayout';
import { paymentQueueKeys } from './queryKeys';

/**
 * R14 (design §7): the popup layout of one item. The tenant, rail and message type come from the validated caller and
 * the item server-side, so the request names none of them. The path is `/api` (the shared client's base) +
 * `/ops/payment-queue/items/{id}/layout`.
 */
const layoutPath = (queueEntryId: string) => `/ops/payment-queue/items/${encodeURIComponent(queueEntryId)}/layout`;

/** R14 on the wire (`PaymentQueuePopupLayoutResponse`). */
export interface PaymentQueuePopupLayoutDto {
  /** False when no layout applies to the item's rail and message type (E23): the popup shows a banner (A-17). */
  configured: boolean;
  layoutId?: number | null;
  layoutCode?: string | null;
  versionNo?: number | null;
  /** The JSON schema version `layout` follows. */
  schemaVersion?: number | null;
  /** The layout JSON (`tabs`, `footer`). Null when not configured. */
  layout?: unknown;
}

/** Why the popup has no layout to draw, or that it has one. */
export type PopupLayoutState =
  | { kind: 'ready'; layout: PopupLayout }
  | { kind: 'notConfigured' }
  | { kind: 'unsupported' };

/**
 * What the popup draws from an R14 answer: the parsed layout, "not configured" (the server said so, or the layout has no
 * tab), or "unsupported" (a schema version this renderer does not know, so drawing it could misplace a field).
 */
export function toPopupLayoutState(dto: PaymentQueuePopupLayoutDto): PopupLayoutState {
  if (!dto.configured || dto.layout == null) return { kind: 'notConfigured' };
  if (dto.schemaVersion !== SUPPORTED_LAYOUT_SCHEMA_VERSION) return { kind: 'unsupported' };
  const layout = parsePopupLayout(dto.layout);
  return layout ? { kind: 'ready', layout } : { kind: 'notConfigured' };
}

export const popupLayoutApi = {
  /** R14: the resolved layout of one item. A 404 is an item out of scope, like R5. */
  layout: (queueEntryId: string) =>
    bankingApi.get<PaymentQueuePopupLayoutDto>(layoutPath(queueEntryId)).then((r) => r.data),
};

/** A layout changes only by a new version row, so a few minutes of caching never shows a stale one for long. */
const LAYOUT_STALE_MS = 5 * 60_000;

/** R14 as the popup reads it: what to draw. */
export function usePaymentQueuePopupLayout(queueEntryId: string) {
  return useQuery({
    queryKey: paymentQueueKeys.layout(queueEntryId),
    queryFn: () => popupLayoutApi.layout(queueEntryId),
    select: toPopupLayoutState,
    staleTime: LAYOUT_STALE_MS,
  });
}
