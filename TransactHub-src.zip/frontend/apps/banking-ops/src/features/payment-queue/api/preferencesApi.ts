import { bankingApi } from '../../../shared/api/bankingApi';

/**
 * P1–P4 (design §7, PMQ-P7-5): the user's one saved filter and the grid's column layout. The login and the tenant come
 * from the validated caller server-side, so no request here names either; each user reads and writes only their own
 * rows. Every write is an insert on the server: a save supersedes the previous one, and Clear inserts a cleared row.
 * The path is `/api` (the shared client's base) + `/ops/payment-queue/preferences`.
 */
const BASE = '/ops/payment-queue/preferences';

/** The screen these preferences belong to (`PaymentQueuePreferenceRules.OutboundScreen`). */
export const PREFERENCE_SCREEN = 'payment-queue-outbound';

/**
 * The saved left-panel filter on the wire (R-16): the left panel's values and nothing else. Never a grid column filter,
 * a search, a sort or a page; the server refuses any other key with 400.
 */
export interface PaymentQueueSavedFilterDto {
  status: string[];
  paymentType: string[];
  rail: string[];
  channel: string[];
  priority: string[];
  amountMin?: string | null;
  amountMax?: string | null;
  dateFrom?: string | null;
  dateTo?: string | null;
}

/** One column of the saved layout: SmartGrid's `SmartGridStoredColumn`. */
export interface PaymentQueueColumnLayoutEntryDto {
  key: string;
  visible: boolean;
}

/** P1 on the wire (`PaymentQueuePreferencesResponse`). */
export interface PaymentQueuePreferencesDto {
  screen: string;
  /** The one saved filter, applied when the screen opens (Q-16); null when none is saved or after a Clear. */
  savedFilter?: PaymentQueueSavedFilterDto | null;
  savedFilterAt?: string | null;
  /** The column layout in column order; null when none is saved or after a reset. */
  columnLayout?: PaymentQueueColumnLayoutEntryDto[] | null;
  columnLayoutAt?: string | null;
}

/** P2–P4 on the wire (`PaymentQueuePreferenceSavedResponse`). */
export interface PaymentQueuePreferenceSavedDto {
  screen: string;
  kind: string;
  cleared: boolean;
  savedAt: string;
}

export const preferencesApi = {
  /** P1: the caller's saved filter and column layout. */
  get: () =>
    bankingApi.get<PaymentQueuePreferencesDto>(BASE, { params: { screen: PREFERENCE_SCREEN } }).then((r) => r.data),

  /** P2: saves the left-panel filter; it replaces the previous one and opens with the screen. */
  saveFilter: (filter: PaymentQueueSavedFilterDto) =>
    bankingApi
      .post<PaymentQueuePreferenceSavedDto>(`${BASE}/saved-filter`, { screen: PREFERENCE_SCREEN, filter })
      .then((r) => r.data),

  /** P3: clears the saved filter (the server inserts a cleared row; nothing is deleted). */
  clearFilter: () =>
    bankingApi
      .post<PaymentQueuePreferenceSavedDto>(`${BASE}/saved-filter/clear`, { screen: PREFERENCE_SCREEN })
      .then((r) => r.data),

  /** P4: saves the column layout; an empty list resets it to the grid's defaults. */
  saveColumnLayout: (columns: PaymentQueueColumnLayoutEntryDto[]) =>
    bankingApi
      .post<PaymentQueuePreferenceSavedDto>(`${BASE}/column-layout`, { screen: PREFERENCE_SCREEN, columns })
      .then((r) => r.data),
};
