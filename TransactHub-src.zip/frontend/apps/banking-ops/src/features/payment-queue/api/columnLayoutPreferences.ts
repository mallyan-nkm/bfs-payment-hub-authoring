import type { SmartGridProps } from '@paymenthub/ui';

/**
 * SmartGrid's `SmartGridPreferences` and `SmartGridStoredColumn`. The library does not export them by name, so they are
 * read off the exported props here rather than by changing the shared library.
 */
export type SmartGridPreferences = NonNullable<SmartGridProps<unknown>['preferences']>;
export type SmartGridStoredColumn = Parameters<SmartGridPreferences['save']>[0][number];

interface Options {
  /** The layout P1 returned, or null (none saved, a reset, or P1 could not be read: the grid's defaults). */
  initial: SmartGridStoredColumn[] | null;
  /** P4. An empty list is a reset. */
  save: (layout: SmartGridStoredColumn[]) => Promise<unknown>;
  /** Called once per failed save; the screen shows a toast. */
  onSaveFailed: () => void;
}

/**
 * The grid's column layout on the server (design §9.5, PMQ-P7-5): a `SmartGridPreferences` adapter backed by P1 / P4,
 * passed as the grid's `preferences` so this screen no longer uses the browser's localStorage default.
 *
 * - `load` is synchronous (SmartGrid reads it once, when it mounts), so it answers the layout held in memory: P1's
 *   answer at first, then the user's latest choice. A remount (a language switch) therefore keeps that choice.
 * - `save` keeps the choice in memory **first**, then sends P4. A failed P4 calls `onSaveFailed` and the choice stays
 *   on screen for this session; it never rejects, so the grid is never left with an unhandled error.
 * - `clear` (the grid's Reset to Default) forgets the choice and sends P4 with an empty list, which the server stores as
 *   a reset row: the next load opens on the grid's own defaults.
 *
 * Nothing about the grid's inline column filters is saved: they are off on this screen, and the layout is only
 * `{ key, visible }` per column.
 */
export function createColumnLayoutPreferences({ initial, save, onSaveFailed }: Options): SmartGridPreferences {
  let current: SmartGridStoredColumn[] | null = initial && initial.length > 0 ? initial : null;

  const send = (layout: SmartGridStoredColumn[]) =>
    save(layout).then(
      () => undefined,
      () => onSaveFailed(),
    );

  return {
    load: () => current,
    save: (layout) => {
      current = layout.map(({ key, visible }) => ({ key, visible }));
      return send(current);
    },
    clear: () => {
      current = null;
      return send([]);
    },
  };
}
