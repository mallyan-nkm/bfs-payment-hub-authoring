import { bankingApi } from '../../../shared/api/bankingApi';
import { sessionHeaders } from './unmaskSession';
import type {
  PaymentQueueRow,
  PaymentTypeFilter,
  PriorityLevel,
  QueueTabCount,
  WorkflowStep,
  WorkflowStepStatus,
} from '../types';

/**
 * Payment Queue – Outbound over the Operations API (design §7). The tenant, the rails and the departments come from the
 * validated caller server-side, so no request here names any of them. The browser reaches the routes through the
 * gateway's `/api/ops` prefix, so the path below is `/api` (the shared client's base) + `/ops/payment-queue`.
 *
 * PMQ-P4-1 wires R1 (grid page) and R2 (counts). The other Phase 1 routes (R5, R8, R9, R10, R11, W1, W2) are added
 * by the task that first uses each one.
 */
const BASE = '/ops/payment-queue';

/** R1's largest page (`PaymentQueueGridRequest.MaxPageSize`); the server answers 400 above it. */
export const GRID_PAGE_SIZE = 100;

/** R1 `tab`: All Queues, or the Payment Queue (the rows the caller can act on). */
export type PaymentQueueTabParam = 'all' | 'actionable';

/** One R1 grid row on the wire (`PaymentQueueGridRowResponse`, camelCase JSON). */
export interface PaymentQueueGridRowDto {
  queueEntryId: string;
  currentStateId: number;
  /** `PENDING`, `HELD` or `RETURNED`. */
  stateCode: string;
  /** The current state's label (Queue Status). */
  queueStatus: string;
  stageSeq?: number | null;
  systemReference: string;
  subBatchNo?: string | null;
  debtorName: string;
  /** Masked by the server unless the caller holds the unmask key and has an open session. */
  debtorAccount?: string | null;
  creditorAccount?: string | null;
  creditorName?: string | null;
  creditorBank?: string | null;
  amount: number;
  currency: string;
  rail: string;
  messageType: string;
  /** `Batch` or `Single`. */
  paymentType: string;
  channel: string;
  isRepairResubmission: boolean;
  /** Null is shown as Normal. */
  priority?: string | null;
  /** UTC. */
  transactionDate: string;
  /** UTC. */
  submittedAt: string;
  /** Null shows "System". */
  submittedBy?: string | null;
  /** True when the caller may act on the row now (it belongs on the Payment Queue tab). Absent reads as the tab's own answer. */
  isActionable?: boolean;
}

/** R1 on the wire (`PaymentQueueGridPageResponse`). */
export interface PaymentQueueGridPageDto {
  items: PaymentQueueGridRowDto[];
  page: number;
  size: number;
  /** Every row of the tab for this caller, not only this page. */
  totalCount: number;
}

/** R2 on the wire (`PaymentQueueCountsResponse`). */
export interface PaymentQueueCountsDto {
  all: number;
  actionable: number;
}

/**
 * R1's sort columns (`PaymentQueueGridSort`, design §9.6), by the name R1 reads, case-insensitively. The grid's
 * sortable columns use these names as their `sortKey`, so a header click maps to a value the server accepts.
 */
export const PAYMENT_QUEUE_SORT_COLUMNS = [
  'submittedDate',
  'systemReference',
  'debtorName',
  'amount',
  'currency',
  'transactionDate',
  'priority',
  'queueStatus',
  'rail',
  'messageType',
  'paymentType',
  'channel',
  'submittedBy',
  'creditorName',
  'creditorBank',
] as const;

export type PaymentQueueSortColumn = (typeof PAYMENT_QUEUE_SORT_COLUMNS)[number];

/** True for a name R1 can sort on (the grid can hand back any key it was given, or null). */
export function isPaymentQueueSortColumn(value: string | null | undefined): value is PaymentQueueSortColumn {
  return PAYMENT_QUEUE_SORT_COLUMNS.some((c) => c === value);
}

/**
 * The left-panel filters R1 applies in SQL (PMQ-P7-4): the same nine fields the panel has always had. Values inside
 * one group combine with OR, groups with AND (design §9.1, Q-23); an absent or empty group does not filter. Amounts are
 * plain numbers as text, dates are `yyyy-MM-dd` (the UTC day of Transaction Date), both inclusive.
 */
export interface PaymentQueueGridFilters {
  status?: string[];
  paymentType?: string[];
  rail?: string[];
  channel?: string[];
  priority?: string[];
  amountMin?: string;
  amountMax?: string;
  dateFrom?: string;
  dateTo?: string;
}

export interface PaymentQueueGridParams {
  tab: PaymentQueueTabParam;
  page?: number;
  size?: number;
  /** One of {@link PAYMENT_QUEUE_SORT_COLUMNS}; absent is R1's own default (Submitted Date). */
  sort?: PaymentQueueSortColumn;
  sortDirection?: 'asc' | 'desc';
  filters?: PaymentQueueGridFilters;
}

/** One enabled filter on the wire (`PaymentQueueFilterDefinitionResponse`, R4). */
export interface PaymentQueueFilterDefinitionDto {
  /** `status`, `paymentType`, `rail`, `channel`, `priority`, `amount` or `dateRange`. */
  code: string;
  /** `options`, `amountRange` or `dateRange`. */
  kind: string;
  /** The R1 query parameters it sets. */
  parameters: string[];
  /** The chip values within the caller's scope; empty for a range. */
  options: string[];
}

/** R4 on the wire (`PaymentQueueFilterOptionsResponse`): the enabled filters only, in the panel's order. */
export interface PaymentQueueFilterOptionsDto {
  filters: PaymentQueueFilterDefinitionDto[];
}

/** R1's repeated keys for the filter arrays (`status=A&status=B`), as the server's binder reads them. */
const REPEAT_KEYS = { indexes: null } as const;

/** The query string of R1: the tab, the page, the sort and every filter that has a value (an empty one is left out). */
export function gridQueryParams(p: PaymentQueueGridParams): Record<string, unknown> {
  const f = p.filters ?? {};
  const list = (values: string[] | undefined) => (values && values.length > 0 ? values : undefined);
  const params: Record<string, unknown> = {
    tab: p.tab,
    page: p.page ?? 1,
    size: p.size ?? GRID_PAGE_SIZE,
    sort: p.sort,
    sortDirection: p.sort ? (p.sortDirection ?? 'desc') : undefined,
    status: list(f.status),
    paymentType: list(f.paymentType),
    rail: list(f.rail),
    channel: list(f.channel),
    priority: list(f.priority),
    amountMin: f.amountMin || undefined,
    amountMax: f.amountMax || undefined,
    dateFrom: f.dateFrom || undefined,
    dateTo: f.dateTo || undefined,
  };
  return Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined));
}

const PRIORITIES: readonly PriorityLevel[] = ['Urgent', 'High', 'Normal'];

/** The server's priority, or Normal for none (R1: "null is shown as Normal"). */
function toPriority(value: string | null | undefined): PriorityLevel {
  return PRIORITIES.find((p) => p.toLowerCase() === value?.trim().toLowerCase()) ?? 'Normal';
}

function toPaymentType(value: string): PaymentTypeFilter {
  return value.trim().toLowerCase() === 'batch' ? 'Batch' : 'Single';
}

/**
 * The server sends UTC instants, but a SQL `datetime2` read back as an unspecified-kind `DateTime` serialises
 * without an offset ("2026-10-17T08:00:00"), which `new Date` would read as local time. An instant with no offset is
 * UTC here (design §7: Transaction Date and Submitted Date are UTC).
 */
export function asUtcIso(value: string): string {
  return /(?:Z|[+-]\d{2}:?\d{2})$/i.test(value) ? value : `${value}Z`;
}

/**
 * Maps one R1 row to the grid's row. A value the server leaves null becomes an empty string: the grid renders "—" for
 * the Single-only creditor columns and its own word for a Submitted By of the system.
 */
export function toPaymentQueueRow(dto: PaymentQueueGridRowDto, isActionable: boolean): PaymentQueueRow {
  return {
    id: dto.queueEntryId,
    currentStateId: dto.currentStateId,
    stateCode: dto.stateCode,
    stageSeq: dto.stageSeq ?? null,
    subBatchNo: dto.subBatchNo ?? null,
    systemReferenceNo: dto.systemReference,
    debtorName: dto.debtorName,
    debtorAccount: dto.debtorAccount ?? '',
    creditorName: dto.creditorName ?? '',
    creditorAccount: dto.creditorAccount ?? '',
    creditorBank: dto.creditorBank ?? '',
    // A repair re-submission is shown as "<channel>-Repair" (R1 DTO, AC-PMQ-073).
    channel: dto.isRepairResubmission ? `${dto.channel}-Repair` : dto.channel,
    isRepairResubmission: dto.isRepairResubmission,
    paymentType: toPaymentType(dto.paymentType),
    rail: dto.rail,
    amount: dto.amount,
    currency: dto.currency,
    transactionDate: asUtcIso(dto.transactionDate),
    messageType: dto.messageType,
    submittedBy: dto.submittedBy?.trim() ?? '',
    submittedDate: asUtcIso(dto.submittedAt),
    queueStatus: dto.queueStatus,
    priority: toPriority(dto.priority),
    isActionable,
  };
}

/**
 * The grid's rows from one R1 page (server mode, PMQ-P7-4). R1 says per row whether the caller may act on it
 * (`isActionable`): every row of the Payment Queue tab is, and on All Queues the server looks the page's rows up, so
 * the bulk bar knows without reading the other tab. A server that sends no flag is read as the tab's own answer.
 */
export function toGridRows(items: PaymentQueueGridRowDto[], tab: PaymentQueueTabParam): PaymentQueueRow[] {
  return items.map((dto) => toPaymentQueueRow(dto, dto.isActionable ?? tab === 'actionable'));
}

/** The tab badges from R2: one count per tab (BA AC-15), no other number is invented. The screen names the tabs. */
export function toTabCounts(counts: PaymentQueueCountsDto): QueueTabCount[] {
  return [
    { key: 'all', total: counts.all },
    { key: 'payment', total: counts.actionable },
  ];
}

// ─── The drawer: R5, R8, R9, R10, R11, W1 and the Audit Trail (PMQ-P4-4, PMQ-P4-5) ───────────────────────────────────

/** R5 on the wire (`PaymentQueueItemHeaderResponse`): the popup header. */
export interface PaymentQueueHeaderDto {
  queueEntryId: string;
  systemReference: string;
  subBatchNo?: string | null;
  /** Null when the rail could not say: shown as "—". */
  corporate?: string | null;
  channel: string;
  rail: string;
  /** UTC. */
  submittedAt: string;
  /** `Batch` or `Single`. */
  paymentType: string;
  /** Item + charge + VAT (AC-PMQ-031). Null when any part is unknown: shown as "—", never as zero. */
  amount?: number | null;
  currency: string;
  /** Now − Submitted Date, whole seconds, as of the response. */
  elapsedSeconds: number;
  slaMinutes?: number | null;
  /** True only when Elapsed is strictly past a configured SLA: the only time Elapsed is red (AC-PMQ-032). */
  isPastSla: boolean;
  /** False when the rail held no row or could not be read: the header shows the "not available" banner. */
  railDataAvailable: boolean;
}

/** One R8 level on the wire (`PaymentQueueWorkflowStepResponse`). */
export interface PaymentQueueWorkflowStepDto {
  /** The level, 1…N; 0 on a workflow step, which is not a level. */
  level: number;
  /** The pinned stage code; on a workflow step, its stored step id. */
  stageCode: string;
  /** `queue` (a level of the stage set) or `workflow` (a completed step merged in from the timeline). Absent reads as `queue`. */
  source?: string;
  /** A workflow step's stored name as sent, or its step id when the name is empty; null on a queue level. */
  label?: string | null;
  roleName?: string | null;
  /** `completed`, `active`, `onHold`, `returned` or `pending`. */
  status: string;
  actorLoginId?: string | null;
  actorName?: string | null;
  /** UTC: when the level completed, or when the current state began. */
  at?: string | null;
  /** "On Hold" or "Returned to <role>" on the current level. */
  badge?: string | null;
  /** The causing action's remarks on the current level. */
  note?: string | null;
  /** A Parallel approval's place among the approvals so far (1, 2, …): a count, not a level. Absent on every other step. */
  approvalNo?: number | null;
  /** The approvals the item needs in all, beside `approvalNo`. */
  approvalsRequired?: number | null;
}

/** R8 on the wire (`PaymentQueueWorkflowResponse`). */
export interface PaymentQueueWorkflowDto {
  currentStateId: number;
  stateCode: string;
  steps: PaymentQueueWorkflowStepDto[];
  /** False when the workflow timeline could not be read: `steps` holds the queue's levels only. Absent reads as true. */
  timelineAvailable?: boolean;
}

/** One R9 row on the wire (`PaymentQueueActionHistoryRowResponse`). */
export interface PaymentQueueActionHistoryRowDto {
  actionId: number;
  actionCode: string;
  /** The label shown: an Approve on a returned state is "Resubmit". */
  actionLabel: string;
  onReturnedState: boolean;
  actorLoginId: string;
  actorName: string;
  actorRoleName: string;
  /** UTC. */
  occurredAt: string;
  remarks?: string | null;
  stageSeq?: number | null;
  targetDepartmentId?: number | null;
  bulkActionId?: string | null;
}

/** One R10 button on the wire (`PaymentQueueAvailableActionResponse`). */
export interface PaymentQueueAvailableActionDto {
  /** The code W1 accepts; never `ESCALATE`. */
  action: string;
  label: string;
  remarksMandatory: boolean;
  /** True for Reassign, which needs a department from R11. */
  requiresTargetDepartment: boolean;
}

/** R10 on the wire (`PaymentQueueAvailableActionsResponse`). An empty `actions` is the read-only footer. */
export interface PaymentQueueAvailableActionsDto {
  /** The state the actions were computed on: the value W1 must send back. */
  expectedStateId: number;
  actions: PaymentQueueAvailableActionDto[];
}

/** One R11 target on the wire (`PaymentQueueReassignTargetResponse`). */
export interface PaymentQueueReassignTargetDto {
  departmentId: number;
  departmentName: string;
  /** True when nobody there can act at the first approval level; a Reassign to it is refused 422. */
  noEligibleActor: boolean;
}

/** One Audit Trail row on the wire (`PaymentQueueAuditTrailRowResponse`), newest first. */
export interface PaymentQueueAuditTrailRowDto {
  auditId: number;
  eventType: string;
  action: string;
  /** UTC. */
  occurredAt: string;
  userId?: string | null;
  userName?: string | null;
  correlationId?: string | null;
  queueEntryId?: string | null;
  subBatchNo?: string | null;
  stageSeq?: number | null;
  fromState?: string | null;
  toState?: string | null;
  remarks?: string | null;
  targetDepartmentId?: number | null;
  bulkActionId?: string | null;
}

/** The W1 request body (`ActOnPaymentQueueItemRequest`). The tenant and the actor come from the caller, not the body. */
export interface ActOnPaymentQueueItemRequest {
  action: string;
  remarks?: string;
  /** Reassign only. */
  targetDepartmentId?: number;
  /** The state the screen showed; the server answers 409 when it is no longer current. */
  expectedStateId: number;
  /** The idempotency key (at most 64 characters). A retry of the same click sends the same value. */
  clientRequestId: string;
}

/** The W1 answer (`ActOnPaymentQueueItemResponse`): `applied`, or `alreadyApplied` for a retry of the same id. */
export interface ActOnPaymentQueueItemResultDto {
  outcome: string;
  queueEntryId: string;
  action: string;
  isResubmit: boolean;
  actionId?: number | null;
  newStateId?: number | null;
  newStateCode?: string | null;
  stageSeq?: number | null;
  statusLabel?: string | null;
  exitOutcome?: string | null;
  bulkActionId?: string | null;
}

/** R12 on the wire (`PaymentQueueUnmaskResponse`): whether this browser session's account numbers are shown in full. */
export interface PaymentQueueUnmaskDto {
  unmaskActive: boolean;
  /** UTC: when the session lapses on its own; null once it is closed. */
  expiresAtUtc?: string | null;
}

/** W2's largest selection (`BulkActOnPaymentQueueItems.MaxRecords`); the server answers 400 above it (design §6.5). */
export const BULK_MAX_RECORDS = 100;

/** The actions W2 accepts (design §6.3 Bulk column). Escalate is not one of them (Q-13). */
export type PaymentQueueBulkActionCode = 'APPROVE' | 'REJECT' | 'REASSIGN';

/** The W2 request body (`BulkActOnPaymentQueueItemsRequest`). The tenant and the actor come from the caller. */
export interface BulkActOnPaymentQueueItemsRequest {
  /** 1 to {@link BULK_MAX_RECORDS} records, each named once. */
  queueEntryIds: string[];
  action: PaymentQueueBulkActionCode;
  /** Mandatory for every bulk action, Approve included (FSD §6.1). */
  remarks: string;
  /** Reassign only. */
  targetDepartmentId?: number;
  /** The idempotency key (at most 64 characters), shared by every record's action row. A retry sends the same value. */
  clientRequestId: string;
  /** Per record, the state the screen showed (`currentStateId`): a record that moved since reports `conflict`. */
  expectedStateIds?: Record<string, number>;
}

/** One record's W2 result (`PaymentQueueBulkItemResultResponse`). */
export interface PaymentQueueBulkItemResultDto {
  queueEntryId: string;
  /** `applied`, `conflict`, `not-eligible`, `not-allowed` or `unavailable` (the Rule Engine did not answer; retry). */
  status: string;
  newStateId?: number | null;
  /** The refusal's name (for example `StateSuperseded`); null when applied or unavailable. */
  reason?: string | null;
  /** A safe, user-facing reason; null when applied. */
  message?: string | null;
}

/** The W2 answer (`BulkActOnPaymentQueueItemsResponse`): one result per record, in request order. */
export interface BulkActOnPaymentQueueItemsResultDto {
  bulkActionId: string;
  results: PaymentQueueBulkItemResultDto[];
}

/** Item-scoped routes name the item in the path; an id is encoded so it can never change the route. */
const itemPath = (queueEntryId: string) => `${BASE}/items/${encodeURIComponent(queueEntryId)}`;

const STEP_STATUS: Record<string, WorkflowStepStatus> = {
  completed: 'completed',
  active: 'active',
  onHold: 'held',
  returned: 'returned',
  pending: 'pending',
};

/**
 * Maps R8's levels to the stepper. The badge and the note are the server's (AC-PMQ-114): "Returned to Maker" for a
 * return to Level 1, "Returned to Checker" for a return to a Checker level. A status the screen does not know is
 * drawn as pending rather than as a state it did not receive. The sentence under a level is the stepper's, in the
 * reader's language; this only carries what R8 said. A step with `source` `workflow` is a completed workflow step merged
 * in from the transaction's timeline: it carries its stored name (`stepName`) as sent, which the screen never translates.
 */
export function toWorkflowSteps(workflow: PaymentQueueWorkflowDto): WorkflowStep[] {
  // The server's order is the stepper's order: the queue's levels and the workflow steps are merged by time there, so a
  // sort by level here would put every workflow step (level 0) first.
  return workflow.steps.map((step): WorkflowStep => {
    const status = STEP_STATUS[step.status] ?? 'pending';
    const badge = step.badge?.trim();
    const note = step.note?.trim();
    const actor = step.actorName?.trim() || step.actorLoginId?.trim();
    const awaitingRole = step.roleName?.trim();
    const source = step.source === 'workflow' ? 'workflow' : step.source === 'action' ? 'action' : 'queue';
    // A workflow step's name is shown exactly as stored (no trim, no rewrite); only an empty name falls back to the id.
    const stepName = source === 'workflow' ? (step.label?.trim() ? step.label : step.stageCode) : undefined;
    return {
      level: step.level,
      source,
      ...(stepName !== undefined ? { stepName } : {}),
      roleLabel: step.roleName?.trim() || step.stageCode,
      status,
      ...(actor ? { actor } : {}),
      ...(step.at ? { at: asUtcIso(step.at) } : {}),
      ...(awaitingRole ? { awaitingRole } : {}),
      ...(badge ? { badge } : {}),
      ...(note ? { note } : {}),
      ...(step.approvalNo ? { approvalNo: step.approvalNo } : {}),
      ...(step.approvalsRequired ? { approvalsRequired: step.approvalsRequired } : {}),
    };
  });
}

/** False only when R8 said the workflow timeline could not be read (the stepper then holds the queue's levels only). */
export function isWorkflowTimelineAvailable(workflow: PaymentQueueWorkflowDto): boolean {
  return workflow.timelineAvailable !== false;
}

/** A W1 refusal read from the ProblemDetails body (RFC 7807): the HTTP status and the server's own message. */
export interface PaymentQueueProblem {
  /** The HTTP status; 0 when the call got no answer (a network failure). */
  status: number;
  /** The server's `detail`, shown to the user as written; null when the body carried none. */
  detail: string | null;
}

export function paymentQueueProblem(error: unknown): PaymentQueueProblem {
  const response = (error as { response?: { status?: unknown; data?: unknown } } | null)?.response;
  const data = response?.data;
  const detail =
    data && typeof data === 'object' && typeof (data as { detail?: unknown }).detail === 'string'
      ? (data as { detail: string }).detail.trim() || null
      : null;
  return { status: typeof response?.status === 'number' ? response.status : 0, detail };
}

export const paymentQueueApi = {
  /** R1: one page of a tab. */
  grid: (p: PaymentQueueGridParams) =>
    bankingApi
      .get<PaymentQueueGridPageDto>(`${BASE}/items`, {
        params: gridQueryParams(p),
        paramsSerializer: REPEAT_KEYS,
        // The session id is how the server knows whether this browser has an open unmask session (R12).
        headers: sessionHeaders(),
      })
      .then((r) => r.data),

  /** R2: the two tab badges. */
  counts: () => bankingApi.get<PaymentQueueCountsDto>(`${BASE}/counts`).then((r) => r.data),

  /** R4: the enabled filters and their chip values, limited to the caller's scope. */
  filterOptions: () => bankingApi.get<PaymentQueueFilterOptionsDto>(`${BASE}/filter-options`).then((r) => r.data),

  /** R5 (Phase 1: header only): the popup header of one item. */
  header: (queueEntryId: string) =>
    bankingApi.get<PaymentQueueHeaderDto>(itemPath(queueEntryId)).then((r) => r.data),

  /** R8: the Workflow stepper of one item. */
  workflow: (queueEntryId: string) =>
    bankingApi.get<PaymentQueueWorkflowDto>(`${itemPath(queueEntryId)}/workflow`).then((r) => r.data),

  /** R9: the Action History of one item, oldest first. */
  actionHistory: (queueEntryId: string) =>
    bankingApi.get<PaymentQueueActionHistoryRowDto[]>(`${itemPath(queueEntryId)}/actions`).then((r) => r.data),

  /** R10: the buttons the caller may use on one item now, computed by the server (I-10). */
  availableActions: (queueEntryId: string) =>
    bankingApi.get<PaymentQueueAvailableActionsDto>(`${itemPath(queueEntryId)}/available-actions`).then((r) => r.data),

  /** R11: every other department, for a Reassign. */
  reassignTargets: (queueEntryId: string) =>
    bankingApi
      .get<PaymentQueueReassignTargetDto[]>(`${BASE}/reassign-targets`, { params: { queueEntryId } })
      .then((r) => r.data),

  /** The Audit Trail of one item, newest first (key 74 only, P1-5 ruling Z11). */
  auditTrail: (queueEntryId: string) =>
    bankingApi.get<PaymentQueueAuditTrailRowDto[]>(`${itemPath(queueEntryId)}/audit-trail`).then((r) => r.data),

  /** R12: opens this browser session's unmask (key 24, 15 minutes). A refusal is a ProblemDetails. */
  unmask: () =>
    bankingApi.post<PaymentQueueUnmaskDto>(`${BASE}/unmask`, null, { headers: sessionHeaders() }).then((r) => r.data),

  /** R12: closes it at once; harmless when none is open. */
  mask: () =>
    bankingApi.post<PaymentQueueUnmaskDto>(`${BASE}/mask`, null, { headers: sessionHeaders() }).then((r) => r.data),

  /** W1: one action on one item. A refusal is a ProblemDetails (`paymentQueueProblem` reads it). */
  act: (queueEntryId: string, body: ActOnPaymentQueueItemRequest) =>
    bankingApi.post<ActOnPaymentQueueItemResultDto>(`${itemPath(queueEntryId)}/actions`, body).then((r) => r.data),

  /**
   * W2: one action on up to {@link BULK_MAX_RECORDS} records, with a result per record. Not atomic: a partial success
   * is reported, never rolled back. A refusal of the whole request (400 / 403 / 422) is a ProblemDetails.
   */
  bulkAct: (body: BulkActOnPaymentQueueItemsRequest) =>
    bankingApi.post<BulkActOnPaymentQueueItemsResultDto>(`${BASE}/bulk-actions`, body).then((r) => r.data),
};
