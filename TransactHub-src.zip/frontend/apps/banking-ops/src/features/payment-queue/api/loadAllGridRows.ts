import { GRID_PAGE_SIZE, paymentQueueApi, toGridRows } from './paymentQueueApi';
import type { PaymentQueueGridParams } from './paymentQueueApi';
import type { PaymentQueueRow } from '../types';

/** The most records one export takes. R13 (the server export, PMQ-P7-9) replaces this client-side read. */
export const EXPORT_MAX_ROWS = 5000;

/** The filtered set is larger than {@link EXPORT_MAX_ROWS}: nothing is exported, because a part would pass for the whole. */
export class ExportTooLargeError extends Error {
  constructor(readonly total: number) {
    super(`The export covers ${total} records; the limit is ${EXPORT_MAX_ROWS}.`);
    this.name = 'ExportTooLargeError';
  }
}

/**
 * Every row of the tab under the grid's current filters and sort, read page by page through R1 (server mode, PMQ-P7-4),
 * for the grid's own CSV: the screen has always exported everything the filters leave, and with only one page in the
 * browser this is how it still does. The sort has a tie-break on the state id, so pages neither repeat nor skip a row.
 * Throws {@link ExportTooLargeError} before reading the rest when the set is over the limit.
 */
export async function loadAllGridRows(params: PaymentQueueGridParams): Promise<PaymentQueueRow[]> {
  const first = await paymentQueueApi.grid({ ...params, page: 1, size: GRID_PAGE_SIZE });
  if (first.totalCount > EXPORT_MAX_ROWS) {
    throw new ExportTooLargeError(first.totalCount);
  }

  const items = [...first.items];
  const pages = Math.ceil(first.totalCount / GRID_PAGE_SIZE);
  for (let page = 2; page <= pages; page += 1) {
    const next = await paymentQueueApi.grid({ ...params, page, size: GRID_PAGE_SIZE });
    items.push(...next.items);
  }
  return toGridRows(items, params.tab);
}
