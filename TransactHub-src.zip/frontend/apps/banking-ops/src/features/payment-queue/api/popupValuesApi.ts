import { useQuery } from '@tanstack/react-query';
import { bankingApi } from '../../../shared/api/bankingApi';
import type { PopupGridData, PopupValue, PopupValues } from '../popupValues';
import { asUtcIso } from './paymentQueueApi';
import { paymentQueueKeys } from './queryKeys';
import { sessionHeaders } from './unmaskSession';

/**
 * R6 (design §7, §8.0): the rail's values of one item by field code (Summary, Debtor, Charge Details, Posting Details) and
 * the paged Record List. The tenant and rail come from the validated caller server-side, so the request names neither.
 * The path is `/api` (the shared client's base) + `/ops/payment-queue/items/{id}/records` (the path design §7 gives R6;
 * `page` and `size` as R1). Besides the Record List page it carries the other rail values by field code.
 */
const recordsPath = (queueEntryId: string) =>
  `/ops/payment-queue/items/${encodeURIComponent(queueEntryId)}/records`;

/** The Record List's page size. The server clamps it to 1..100. */
export const RECORDS_PAGE_SIZE = 25;

/** One value on the wire (`PaymentQueuePopupCellResponse`). Only the properties of its `type` are set. */
export interface PopupCellDto {
  type: 'text' | 'number' | 'money' | 'dateTime' | 'account' | string;
  text?: string | null;
  /** The number of a `number` cell, or the amount of a `money` cell. */
  number?: number | null;
  currency?: string | null;
  /** The instant (UTC) of a `dateTime` cell. */
  instant?: string | null;
  /** The account number of an `account` cell, as the server sent it: masked unless the caller holds key 24 with an open session. */
  account?: string | null;
  /** The role of the account ("Suspense A/c"), shown beside the number. Not masked: it is not a value of the account. */
  label?: string | null;
}

/** One field code's answer (`PaymentQueuePopupFieldResponse`). */
export interface PopupFieldDto {
  /** True when the rail has no source for the code today. */
  notAvailable: boolean;
  value?: PopupCellDto | null;
}

/** One grid on the wire (`PaymentQueuePopupGridResponse`). */
export interface PopupGridDto {
  gridCode: string;
  /** True when the rail holds nothing to show (no recorded posting legs). */
  notAvailable: boolean;
  paged: boolean;
  /** 1-based. */
  page: number;
  pageSize: number;
  totalCount: number;
  rows: Array<Record<string, PopupCellDto | null | undefined>>;
}

/** R6 on the wire (`PaymentQueuePopupValuesResponse`). */
export interface PaymentQueuePopupValuesDto {
  queueEntryId: string;
  /** False when the rail held no row or could not be read in time: `fields` and `grids` are then empty. */
  railDataAvailable: boolean;
  fields: Record<string, PopupFieldDto>;
  grids: PopupGridDto[];
}

/** One cell as the renderer draws it. A missing value, or one of a type this client does not know, is null: drawn as "—". */
export function toPopupValue(cell: PopupCellDto | null | undefined): PopupValue {
  if (!cell) return null;
  switch (cell.type) {
    case 'text':
      return cell.text ?? null;
    case 'account':
      if (!cell.account) return null;
      return cell.label ? `${cell.account} — ${cell.label}` : cell.account;
    case 'number':
      return cell.number ?? null;
    case 'money':
      return cell.number == null || !cell.currency ? (cell.number ?? null) : { type: 'money', amount: cell.number, currency: cell.currency };
    case 'dateTime':
      return cell.instant ? { type: 'dateTime', value: asUtcIso(cell.instant) } : null;
    default:
      return null;
  }
}

/**
 * Maps R6's answer onto the renderer's values. A code the rail has no source for, or a value it does not hold, is null
 * ("—"); nothing is made up. A grid carries its rows by column code and, when paged, the paging the pager needs.
 */
export function toPopupValues(dto: PaymentQueuePopupValuesDto, onPageChange: (page: number) => void): PopupValues {
  const fields: Record<string, PopupValue> = {};
  for (const [code, field] of Object.entries(dto.fields ?? {})) {
    fields[code] = field.notAvailable ? null : toPopupValue(field.value);
  }

  const grids: Record<string, PopupGridData> = {};
  for (const grid of dto.grids ?? []) {
    grids[grid.gridCode] = {
      rows: grid.rows.map((row) => Object.fromEntries(Object.entries(row).map(([code, cell]) => [code, toPopupValue(cell)]))),
      notAvailable: grid.notAvailable,
      paging: grid.paged
        ? { page: grid.page, pageSize: grid.pageSize, totalCount: grid.totalCount, onPageChange }
        : undefined,
    };
  }

  return { fields, grids };
}

export const popupValuesApi = {
  /** R6: the rail's values of one item, one Record List page. A 404 is an item out of scope, like R5. */
  values: (queueEntryId: string, recordsPage: number) =>
    bankingApi
      .get<PaymentQueuePopupValuesDto>(recordsPath(queueEntryId), {
        params: { page: recordsPage, size: RECORDS_PAGE_SIZE },
        // The session id is how the server knows whether this browser has an open unmask session (R12): account numbers
        // arrive masked or in full from the server, and the unmask session's reload refetches this read.
        headers: sessionHeaders(),
      })
      .then((r) => r.data),
};

/**
 * R6 as the popup reads it: one Record List page at a time. The previous page of the same item stays on screen while the
 * next loads; another item's values are never shown in its place (the key's third part is the item).
 */
export function usePaymentQueuePopupValues(queueEntryId: string, recordsPage: number) {
  return useQuery({
    queryKey: paymentQueueKeys.popupValues(queueEntryId, recordsPage),
    queryFn: () => popupValuesApi.values(queueEntryId, recordsPage),
    placeholderData: (previous, previousQuery) => (previousQuery?.queryKey[2] === queueEntryId ? previous : undefined),
  });
}
