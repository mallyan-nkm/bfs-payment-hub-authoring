import type { PaymentQueueGridParams } from './paymentQueueApi';

/** Payment Queue query keys (React UI guideline §7). A command that changes a row invalidates `all`. */
export const paymentQueueKeys = {
  all: ['payment-queue'] as const,
  grid: (params: PaymentQueueGridParams) => ['payment-queue', 'grid', params] as const,
  counts: () => ['payment-queue', 'counts'] as const,
  /** R4: the enabled filters and their chip values (scoped to the caller). */
  filterOptions: () => ['payment-queue', 'filter-options'] as const,
  /** Everything the drawer reads about one item (R5, R8, R9, R10, R11, Audit Trail); a W1 refreshes it with `all`. */
  item: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId] as const,
  header: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId, 'header'] as const,
  workflow: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId, 'workflow'] as const,
  actionHistory: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId, 'actions'] as const,
  availableActions: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId, 'available-actions'] as const,
  reassignTargets: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId, 'reassign-targets'] as const,
  auditTrail: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId, 'audit-trail'] as const,
  layout: (queueEntryId: string) => ['payment-queue', 'item', queueEntryId, 'layout'] as const,
  /** R6: the rail's values by field code and one Record List page. Under `all`, so an unmask or mask reload refetches it. */
  popupValues: (queueEntryId: string, recordsPage: number) =>
    ['payment-queue', 'item', queueEntryId, 'popup-values', recordsPage] as const,
  /**
   * P1 (PMQ-P7-5): the user's saved filter and column layout. Deliberately **not** under `all`: an action or an unmask
   * refreshes every queue read, and a refetch here must never re-apply the saved filter over what the user has chosen.
   * The screen's own P2–P4 writes update this entry in place.
   */
  preferences: (screen: string) => ['payment-queue-preferences', screen] as const,
};
