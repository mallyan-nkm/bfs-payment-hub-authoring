import { useCallback, useEffect, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import type { ToastState } from '../../../shared/components/Toast';
import { usePaymentQueueTranslation } from '../i18n';
import {
  maskFailedToast,
  maskedToast,
  unmaskedToast,
  unmaskExpiredToast,
  unmaskRefusedToast,
} from '../paymentQueueToasts';
import { asUtcIso, paymentQueueApi, paymentQueueProblem } from './paymentQueueApi';
import { paymentQueueKeys } from './queryKeys';
import { readUnmaskExpiry, writeUnmaskExpiry } from './unmaskSession';

/**
 * The shape of `SmartGrid`'s `pii` prop (`SmartGridPiiState`, ui-common-lib), so the grid can take this hook's result
 * as it is when the screen moves to `SmartGrid` (Phase 3): `pii={useUnmaskSession(...)}`.
 */
export interface UnmaskSession {
  /** True while the server is sending account numbers in full to this browser session. */
  unmasked: boolean;
  /** Whether the caller holds the unmask key (24). False hides the control completely. */
  canUnmask: boolean;
  /** Opens (`true`) or closes (`false`) the server session, then reloads every Payment Queue read. */
  onApply: (next: boolean) => Promise<void>;
  busy: boolean;
}

interface Options {
  /** Key 24 (`bankingops:field.account-number:unmask`). Advisory: the server refuses `/unmask` without it. */
  canUnmask: boolean;
  /** Receives each outcome as a toast: opened, closed, refused, or lapsed. */
  notify?: (toast: ToastState) => void;
}

/** The expiry stored by an earlier visit, if it has not passed. */
function liveExpiry(): number | null {
  const stored = readUnmaskExpiry();
  if (stored !== null && stored > Date.now()) return stored;
  if (stored !== null) writeUnmaskExpiry(null);
  return null;
}

/**
 * The unmask session of the Payment Queue (PMQ-P4-6; design §9.4, R12).
 *
 * The browser never unmasks, caches or makes up a value: the server masks every account number and shows it in full
 * only to a caller who holds key 24 and has an open session. Ticking calls `POST /unmask`, unticking `POST /mask`,
 * and each is followed by a reload of every Payment Queue read, so what the grid shows is whatever the server then
 * sends. A refusal, or a session the server closed, leaves the values masked and the control unchecked.
 *
 * What this hook keeps is only whether a session is open and when the server said it lapses. At that moment the grid
 * is reloaded, the server sends masked values, and the control goes back to unchecked.
 */
export function useUnmaskSession({ canUnmask, notify }: Options): UnmaskSession {
  const queryClient = useQueryClient();
  const { t, i18n } = usePaymentQueueTranslation();
  const [expiresAt, setExpiresAt] = useState<number | null>(liveExpiry);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const notifyRef = useRef(notify);
  notifyRef.current = notify;
  // The latest copy and language, so a toast raised from a timer or a request speaks the language of that moment.
  const copy = useRef({ t, language: i18n.language });
  copy.current = { t, language: i18n.language };

  const reload = useCallback(
    () => queryClient.invalidateQueries({ queryKey: paymentQueueKeys.all }),
    [queryClient],
  );

  // The session lapses on the server at the time it gave. Reload then, so the grid shows what the server now sends.
  useEffect(() => {
    if (expiresAt === null) return undefined;
    const id = window.setTimeout(
      () => {
        writeUnmaskExpiry(null);
        setExpiresAt(null);
        void reload();
        notifyRef.current?.(unmaskExpiredToast(copy.current.t));
      },
      Math.max(0, expiresAt - Date.now()),
    );
    return () => window.clearTimeout(id);
  }, [expiresAt, reload]);

  const onApply = useCallback(
    async (next: boolean) => {
      if (busyRef.current) return;
      busyRef.current = true;
      setBusy(true);
      try {
        if (next) {
          const answer = await paymentQueueApi.unmask();
          const lapsesAt = answer.expiresAtUtc ? Date.parse(asUtcIso(answer.expiresAtUtc)) : Number.NaN;
          if (!answer.unmaskActive || !Number.isFinite(lapsesAt)) {
            notifyRef.current?.(unmaskRefusedToast(copy.current.t, 200, null));
            return;
          }
          writeUnmaskExpiry(lapsesAt);
          setExpiresAt(lapsesAt);
          await reload();
          notifyRef.current?.(unmaskedToast(copy.current.t, lapsesAt, copy.current.language));
        } else {
          await paymentQueueApi.mask();
          writeUnmaskExpiry(null);
          setExpiresAt(null);
          await reload();
          notifyRef.current?.(maskedToast(copy.current.t));
        }
      } catch (error) {
        const { status, detail } = paymentQueueProblem(error);
        // Opening failed: nothing changed, the values are still masked. Closing failed: the state is unknown, so the
        // control keeps showing "open" until the server confirms or the session lapses.
        const { t: tt } = copy.current;
        notifyRef.current?.(next ? unmaskRefusedToast(tt, status, detail) : maskFailedToast(tt, detail));
      } finally {
        busyRef.current = false;
        setBusy(false);
      }
    },
    [reload],
  );

  return { unmasked: canUnmask && expiresAt !== null, canUnmask, onApply, busy };
}
