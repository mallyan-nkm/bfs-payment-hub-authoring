import { useMutation, useQueryClient } from '@tanstack/react-query';
import { paymentQueueApi } from './paymentQueueApi';
import type { BulkActOnPaymentQueueItemsRequest } from './paymentQueueApi';
import { paymentQueueKeys } from './queryKeys';

/**
 * W2 as a mutation. Whatever the answer, every Payment Queue read is refetched: a whole-request failure can still
 * follow a partial write (a dropped response), and a per-record `conflict` means the grid is out of date.
 */
export function useBulkAction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: BulkActOnPaymentQueueItemsRequest) => paymentQueueApi.bulkAct(body),
    onSettled: () => queryClient.invalidateQueries({ queryKey: paymentQueueKeys.all }),
  });
}
