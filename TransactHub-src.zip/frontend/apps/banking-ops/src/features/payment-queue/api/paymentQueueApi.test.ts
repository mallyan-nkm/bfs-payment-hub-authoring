import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../../shared/api/bankingApi';
import { gridRowDto } from '../../../../test/paymentQueueFixtures';
import {
  asUtcIso,
  GRID_PAGE_SIZE,
  gridQueryParams,
  paymentQueueApi,
  toGridRows,
  toPaymentQueueRow,
  toTabCounts,
} from './paymentQueueApi';

vi.mock('../../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

beforeEach(() => {
  get.mockReset();
});

describe('toPaymentQueueRow (R1 DTO to the grid row)', () => {
  it('maps every R1 field to its grid field', () => {
    expect(toPaymentQueueRow(gridRowDto(), true)).toEqual({
      id: 'PQ-0001',
      currentStateId: 42,
      stateCode: 'PENDING',
      stageSeq: 2,
      subBatchNo: 'SB-1',
      systemReferenceNo: 'WPS-2026-00401',
      debtorName: 'Emirates Steel',
      debtorAccount: '************1234',
      creditorName: 'Sara Ali',
      creditorAccount: '************9876',
      creditorBank: 'Emirates NBD',
      channel: 'CBX',
      isRepairResubmission: false,
      paymentType: 'Single',
      rail: 'WPS',
      amount: 15250.5,
      currency: 'AED',
      transactionDate: '2026-10-17T08:30:00Z',
      messageType: 'SIF',
      submittedBy: 'Omar Rashid',
      submittedDate: '2026-10-17T08:00:00Z',
      queueStatus: 'Pending Approval',
      priority: 'High',
      isActionable: true,
    });
  });

  it('shows what the grid shows for values R1 leaves null', () => {
    const row = toPaymentQueueRow(
      gridRowDto({
        paymentType: 'Batch',
        stageSeq: null,
        subBatchNo: null,
        debtorAccount: null,
        creditorAccount: null,
        creditorName: null,
        creditorBank: null,
        priority: null,
        submittedBy: null,
      }),
      false,
    );
    expect(row).toMatchObject({
      paymentType: 'Batch',
      stageSeq: null,
      subBatchNo: null,
      debtorAccount: '',
      creditorAccount: '',
      creditorName: '',
      creditorBank: '',
      priority: 'Normal',
      submittedBy: 'System',
      isActionable: false,
    });
  });

  it('shows a repair re-submission as <channel>-Repair', () => {
    const row = toPaymentQueueRow(gridRowDto({ channel: 'IB', isRepairResubmission: true }), false);
    expect(row.channel).toBe('IB-Repair');
    expect(row.isRepairResubmission).toBe(true);
  });

  it('reads the priority case-insensitively and shows Normal for anything it does not know', () => {
    expect(toPaymentQueueRow(gridRowDto({ priority: 'URGENT' }), false).priority).toBe('Urgent');
    expect(toPaymentQueueRow(gridRowDto({ priority: 'Normal' }), false).priority).toBe('Normal');
    expect(toPaymentQueueRow(gridRowDto({ priority: 'Whenever' }), false).priority).toBe('Normal');
  });

  it('keeps the account numbers exactly as the server masked them', () => {
    const row = toPaymentQueueRow(gridRowDto({ debtorAccount: '********', creditorAccount: '************9876' }), false);
    expect(row.debtorAccount).toBe('********');
    expect(row.creditorAccount).toBe('************9876');
  });
});

describe('asUtcIso', () => {
  it('reads an instant with no offset as UTC, never as local time', () => {
    expect(asUtcIso('2026-10-17T08:30:00')).toBe('2026-10-17T08:30:00Z');
    expect(asUtcIso('2026-10-17T08:30:00.1234567')).toBe('2026-10-17T08:30:00.1234567Z');
    expect(new Date(asUtcIso('2026-10-17T08:30:00')).toISOString()).toBe('2026-10-17T08:30:00.000Z');
  });

  it('leaves an instant that names its offset alone', () => {
    expect(asUtcIso('2026-10-17T08:30:00Z')).toBe('2026-10-17T08:30:00Z');
    expect(asUtcIso('2026-10-17T12:30:00+04:00')).toBe('2026-10-17T12:30:00+04:00');
  });
});

describe('toGridRows (one R1 page)', () => {
  it('reads isActionable from each row, and from the tab when the server sent none', () => {
    const a = gridRowDto({ queueEntryId: 'A', isActionable: false });
    const b = gridRowDto({ queueEntryId: 'B', isActionable: true });
    const c = gridRowDto({ queueEntryId: 'C' });

    expect(toGridRows([a, b, c], 'all').map((r) => [r.id, r.isActionable])).toEqual([
      ['A', false],
      ['B', true],
      ['C', false],
    ]);
    expect(toGridRows([c], 'actionable')[0]?.isActionable).toBe(true);
  });

  it('is empty when the page is empty: no row is invented', () => {
    expect(toGridRows([], 'all')).toEqual([]);
  });
});

describe('gridQueryParams (R1 query string)', () => {
  it('sends only what has a value: tab, page and size alone for an unfiltered read', () => {
    expect(gridQueryParams({ tab: 'actionable' })).toEqual({ tab: 'actionable', page: 1, size: GRID_PAGE_SIZE });
  });

  it('sends the sort, its direction and every filter that has a value', () => {
    expect(
      gridQueryParams({
        tab: 'all',
        page: 3,
        size: 50,
        sort: 'amount',
        sortDirection: 'asc',
        filters: { rail: ['WPS'], status: [], amountMin: '10', amountMax: '', dateFrom: '2026-10-01' },
      }),
    ).toEqual({
      tab: 'all',
      page: 3,
      size: 50,
      sort: 'amount',
      sortDirection: 'asc',
      rail: ['WPS'],
      amountMin: '10',
      dateFrom: '2026-10-01',
    });
  });
});

describe('toTabCounts', () => {
  it('gives the two tabs one count each, from R2 only', () => {
    expect(toTabCounts({ all: 232, actionable: 47 })).toEqual([
      { key: 'all', label: 'All Queues', total: 232 },
      { key: 'payment', label: 'Payment Queue', total: 47 },
    ]);
  });
});

describe('paymentQueueApi', () => {
  it('calls R1 under the Operations prefix with the tab and the largest page, and returns the body', async () => {
    const page = { items: [gridRowDto()], page: 1, size: GRID_PAGE_SIZE, totalCount: 1 };
    get.mockResolvedValue({ data: page } as never);

    await expect(paymentQueueApi.grid({ tab: 'actionable' })).resolves.toEqual(page);
    expect(get).toHaveBeenCalledWith(
      '/ops/payment-queue/items',
      expect.objectContaining({ params: { tab: 'actionable', page: 1, size: GRID_PAGE_SIZE } }),
    );
  });

  it('asks R1 for no more rows than the server allows', () => {
    expect(GRID_PAGE_SIZE).toBe(100);
  });

  it('calls R2 under the Operations prefix and returns the body', async () => {
    get.mockResolvedValue({ data: { all: 3, actionable: 1 } } as never);

    await expect(paymentQueueApi.counts()).resolves.toEqual({ all: 3, actionable: 1 });
    expect(get).toHaveBeenCalledWith('/ops/payment-queue/counts');
  });

  it('lets a failed call reject, so no caller can mistake it for an empty queue', async () => {
    get.mockRejectedValue(new Error('Network Error'));

    await expect(paymentQueueApi.grid({ tab: 'all' })).rejects.toThrow('Network Error');
  });
});
