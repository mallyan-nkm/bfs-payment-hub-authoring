import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../../shared/api/bankingApi';
import { stepDto, workflowDto } from '../../../../test/paymentQueueFixtures';
import { paymentQueueApi, paymentQueueProblem, toWorkflowSteps } from './paymentQueueApi';

vi.mock('../../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

beforeEach(() => {
  get.mockReset();
  post.mockReset();
  get.mockResolvedValue({ data: 'x' } as never);
  post.mockResolvedValue({ data: 'y' } as never);
});

describe('toWorkflowSteps (R8 to the stepper)', () => {
  it('orders by level and maps onHold to held, keeping the server badge and note', () => {
    const steps = toWorkflowSteps(
      workflowDto([
        stepDto({ level: 2, stageCode: 'L2', roleName: 'Checker', status: 'onHold', badge: 'On Hold', note: ' Waiting ' }),
        stepDto({ level: 1, status: 'completed', actorName: 'Omar Rashid' }),
      ]),
    );
    expect(steps.map((s) => s.status)).toEqual(['completed', 'held']);
    expect(steps[1]).toMatchObject({ badge: 'On Hold', note: 'Waiting' });
    expect(steps[0]).not.toHaveProperty('badge');
    expect(steps[0]).not.toHaveProperty('note');
  });

  it('names the stage code when the role is unknown, and returned keeps the server badge', () => {
    const [step] = toWorkflowSteps(
      workflowDto([stepDto({ roleName: null, stageCode: 'L1', status: 'returned', badge: 'Returned to Checker' })]),
    );
    expect(step.status).toBe('returned');
    expect(step.badge).toBe('Returned to Checker');
  });

  it('draws an unknown status as pending', () => {
    expect(toWorkflowSteps(workflowDto([stepDto({ status: 'other' })]))[0].status).toBe('pending');
  });
});

describe('paymentQueueProblem (a refusal read from its ProblemDetails)', () => {
  it('reads the status and the server detail', () => {
    expect(paymentQueueProblem({ response: { status: 422, data: { detail: ' Remarks are mandatory. ' } } })).toEqual({
      status: 422,
      detail: 'Remarks are mandatory.',
    });
  });

  it('has no detail for a body without one, and status 0 for no answer', () => {
    expect(paymentQueueProblem({ response: { status: 500, data: {} } })).toEqual({ status: 500, detail: null });
    expect(paymentQueueProblem({ response: { status: 409, data: { detail: '  ' } } }).detail).toBeNull();
    expect(paymentQueueProblem(new Error('Network Error'))).toEqual({ status: 0, detail: null });
    expect(paymentQueueProblem(null)).toEqual({ status: 0, detail: null });
  });
});

describe('drawer routes', () => {
  it('reads each per-item route under /ops/payment-queue/items/{id}, encoding the id', async () => {
    await paymentQueueApi.header('PQ/1');
    await paymentQueueApi.workflow('PQ-1');
    await paymentQueueApi.actionHistory('PQ-1');
    await paymentQueueApi.availableActions('PQ-1');
    await paymentQueueApi.auditTrail('PQ-1');

    expect(get.mock.calls.map(([url]) => url)).toEqual([
      '/ops/payment-queue/items/PQ%2F1',
      '/ops/payment-queue/items/PQ-1/workflow',
      '/ops/payment-queue/items/PQ-1/actions',
      '/ops/payment-queue/items/PQ-1/available-actions',
      '/ops/payment-queue/items/PQ-1/audit-trail',
    ]);
  });

  it('reads R11 by query string and posts W1 to the item', async () => {
    await paymentQueueApi.reassignTargets('PQ-1');
    expect(get).toHaveBeenCalledWith('/ops/payment-queue/reassign-targets', { params: { queueEntryId: 'PQ-1' } });

    const body = { action: 'HOLD', expectedStateId: 5, clientRequestId: 'abc' };
    await paymentQueueApi.act('PQ-1', body);
    expect(post).toHaveBeenCalledWith('/ops/payment-queue/items/PQ-1/actions', body);
  });
});
