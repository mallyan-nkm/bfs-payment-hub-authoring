/**
 * The browser half of the Payment Queue's unmask session (PMQ-P4-6; design §9.4, R12).
 *
 * The server opens and closes the session and decides what every read shows. It keys the session on the caller's tenant
 * and login plus the `X-Session-Id` header (at most 128 characters), so the same id must go on every grid read and on
 * `/unmask` and `/mask`, or an open session is never matched. This file holds only that id and the time the server said
 * the session lapses. It holds no account number, and nothing in it unmasks anything.
 *
 * `sessionStorage` is one id per browser tab, which is what the server's "per browser session" means. It also survives
 * the page being left and re-entered inside the 15 minutes, so the control and the values the server still sends agree.
 */
export const SESSION_HEADER = 'X-Session-Id';

const ID_KEY = 'paymentQueue.sessionId';
const EXPIRY_KEY = 'paymentQueue.unmaskExpiresAt';

/** The id kept in memory when `sessionStorage` is unavailable (a private window, blocked site data). */
let memoryId: string | null = null;
let memoryExpiry: number | null = null;

function newSessionId(): string {
  const c = globalThis.crypto as Crypto | undefined;
  return c?.randomUUID ? c.randomUUID() : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 14)}`;
}

/** This tab's session id, made once. */
export function queueSessionId(): string {
  try {
    const stored = window.sessionStorage.getItem(ID_KEY);
    if (stored) return stored;
    const id = newSessionId();
    window.sessionStorage.setItem(ID_KEY, id);
    return id;
  } catch {
    memoryId ??= newSessionId();
    return memoryId;
  }
}

/** The header every grid read, `/unmask` and `/mask` carries. */
export function sessionHeaders(): Record<string, string> {
  return { [SESSION_HEADER]: queueSessionId() };
}

/** When the server said the open session lapses (epoch milliseconds), or null when none was opened. */
export function readUnmaskExpiry(): number | null {
  try {
    const stored = window.sessionStorage.getItem(EXPIRY_KEY);
    const value = stored === null ? NaN : Number(stored);
    return Number.isFinite(value) ? value : null;
  } catch {
    return memoryExpiry;
  }
}

export function writeUnmaskExpiry(expiresAt: number | null): void {
  memoryExpiry = expiresAt;
  try {
    if (expiresAt === null) window.sessionStorage.removeItem(EXPIRY_KEY);
    else window.sessionStorage.setItem(EXPIRY_KEY, String(expiresAt));
  } catch {
    // Kept in memory only.
  }
}
