import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { connectSse } from '@paymenthub/ui';
import { useAuthStore } from '../../../stores/authStore';
import { paymentQueueKeys } from './queryKeys';

/**
 * Live badges (PMQ-P7-7; design §6.7, §10, OD-8, NFR-3; AC-PMQ-098).
 *
 * R3 sends a payload-free nudge when a queue state is inserted in the caller's tenant and rails. The nudge carries no
 * count, so on each one the screen re-reads R2 (`/counts`) through the scoped route. Nothing crosses a scope boundary
 * on the stream.
 *
 * The screen never depends on the stream. The 60-second poll in `usePaymentQueue` stays as the fallback, so a stream
 * that never connects, drops, or is refused (no `EventSource`, a proxy that buffers it, a 4xx) costs only freshness: the
 * badges still refresh within a minute. This hook only invalidates a query; it holds no state the screen reads.
 *
 * Freshness (NFR-3, at most 5 seconds): publish and relay are in-memory and take milliseconds; the nudge is debounced
 * here to one second; the re-read of R2 is one small indexed read. The debounce is a throttle, not a reset, so a steady
 * flow of changes cannot postpone the refresh past one second.
 */
export const LIVE_STREAM_PATH = '/api/ops/payment-queue/stream';

/** Events inside this window share one refresh (the design's 1 s debounce). */
export const LIVE_DEBOUNCE_MS = 1_000;

/**
 * The stream URL. `EventSource` cannot send the `X-Tenant-Id` header the other calls carry, so the active tenant goes in
 * the `tenantId` query value; the server checks it against the caller's assignments, as it checks the header. The bearer
 * token is added by `connectSse`.
 */
export function liveStreamUrl(tenantId: string | null | undefined): string {
  return tenantId ? `${LIVE_STREAM_PATH}?tenantId=${encodeURIComponent(tenantId)}` : LIVE_STREAM_PATH;
}

/**
 * Opens R3 while the screen is mounted and refreshes the counts on each nudge. Closes the stream on unmount, and
 * reopens it when the active tenant changes. Reconnection after a drop is `connectSse`'s own (5 s, with the current
 * token).
 */
export function usePaymentQueueLiveCounts(): void {
  const queryClient = useQueryClient();
  const tenantId = useAuthStore((s) => s.activeTenantId);

  useEffect(() => {
    // No stream support (or a failure to open one) is not an error for the screen: the poll covers it.
    if (typeof EventSource === 'undefined') return undefined;

    let timer: ReturnType<typeof setTimeout> | null = null;
    const refreshCounts = () => {
      if (timer !== null) return;
      timer = setTimeout(() => {
        timer = null;
        void queryClient.invalidateQueries({ queryKey: paymentQueueKeys.counts() });
      }, LIVE_DEBOUNCE_MS);
    };

    let disconnect: (() => void) | null = null;
    try {
      disconnect = connectSse(liveStreamUrl(tenantId), refreshCounts);
    } catch {
      disconnect = null;
    }

    return () => {
      disconnect?.();
      if (timer !== null) clearTimeout(timer);
      timer = null;
    };
  }, [queryClient, tenantId]);
}
