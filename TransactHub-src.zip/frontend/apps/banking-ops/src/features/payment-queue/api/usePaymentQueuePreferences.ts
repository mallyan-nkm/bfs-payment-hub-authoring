import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PREFERENCE_SCREEN, preferencesApi } from './preferencesApi';
import type { PaymentQueueColumnLayoutEntryDto, PaymentQueuePreferencesDto, PaymentQueueSavedFilterDto } from './preferencesApi';
import { paymentQueueKeys } from './queryKeys';

/**
 * P1: the user's saved filter and column layout, read once when the screen opens (PMQ-P7-5).
 *
 * - It is read once and kept (`staleTime: Infinity`, no refetch on focus): the saved filter is applied to the panel only
 *   when the screen opens, so a later refetch has nothing to do. The screen's own writes update this entry in place.
 * - It fails safe: no retry, and an error simply means "nothing saved" (the grid's defaults, no filter). The screen
 *   says so in a notice and keeps working.
 */
export function usePaymentQueuePreferences() {
  return useQuery({
    queryKey: paymentQueueKeys.preferences(PREFERENCE_SCREEN),
    queryFn: preferencesApi.get,
    staleTime: Infinity,
    refetchOnWindowFocus: false,
    retry: false,
  });
}

/** Writes P2–P4's result into the cached P1 answer, so a return to the screen in this session opens on it. */
function useUpdateCachedPreferences() {
  const queryClient = useQueryClient();
  return (change: Partial<PaymentQueuePreferencesDto>) =>
    queryClient.setQueryData<PaymentQueuePreferencesDto>(paymentQueueKeys.preferences(PREFERENCE_SCREEN), (old) => ({
      screen: PREFERENCE_SCREEN,
      ...old,
      ...change,
    }));
}

/**
 * P2 (Save Filter, and Set Default: the one saved filter is the default, Q-16), P3 (Clear) and P4 (column layout).
 * Each rejects on failure so the caller can show its toast; the cache changes only on success.
 */
export function usePaymentQueuePreferenceCommands() {
  const update = useUpdateCachedPreferences();

  const saveFilter = useMutation({
    mutationFn: (filter: PaymentQueueSavedFilterDto) => preferencesApi.saveFilter(filter),
    onSuccess: (saved, filter) => update({ savedFilter: filter, savedFilterAt: saved.savedAt }),
  });

  const clearFilter = useMutation({
    mutationFn: () => preferencesApi.clearFilter(),
    onSuccess: (saved) => update({ savedFilter: null, savedFilterAt: saved.savedAt }),
  });

  const saveColumnLayout = (columns: PaymentQueueColumnLayoutEntryDto[]) =>
    preferencesApi.saveColumnLayout(columns).then((saved) => {
      update({ columnLayout: columns.length > 0 ? columns : null, columnLayoutAt: saved.savedAt });
      return saved;
    });

  return {
    saveFilter: saveFilter.mutateAsync,
    clearFilter: () => clearFilter.mutateAsync(),
    saveColumnLayout,
    /** A saved-filter write is in flight: the panel's Save, Set Default and Clear are disabled meanwhile. */
    savedFilterBusy: saveFilter.isPending || clearFilter.isPending,
  };
}
