import { useMemo } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  isWorkflowTimelineAvailable,
  paymentQueueApi,
  paymentQueueProblem,
  toGridRows,
  toTabCounts,
  toWorkflowSteps,
} from './paymentQueueApi';
import type { ActOnPaymentQueueItemRequest, PaymentQueueGridParams } from './paymentQueueApi';
import { paymentQueueKeys } from './queryKeys';
import { usePaymentQueueLiveCounts } from './usePaymentQueueLiveCounts';
import type { PaymentQueueRow, QueueTabCount, WorkflowStep } from '../types';

/**
 * The counts and the rows are polled. 60 s is the live stream's own fallback interval (OD-8): the R3 nudge
 * (`usePaymentQueueLiveCounts`, PMQ-P7-7) only makes the badges fresher, and the screen works the same without it.
 * A background refetch that fails keeps the last good answer on screen and sets `stale`.
 */
const POLL_MS = 60_000;

export interface PaymentQueueData {
  tabCounts: QueueTabCount[];
  /** The newest refresh failed; what is shown is the last good answer. */
  stale: boolean;
  /** Nothing has loaded yet and nothing has failed. */
  isLoading: boolean;
  /** A call failed and there is no earlier answer to show. No mock stands in for it. */
  isError: boolean;
  /** Runs again each call that failed. */
  refetch: () => void;
}

/**
 * R2 (the tab badges) and the live-count stream. The grid's rows are read by {@link usePaymentQueueGrid}, one page at a
 * time, with the tab, sort and filters of the moment (server mode, PMQ-P7-4).
 */
export function usePaymentQueue(): PaymentQueueData {
  // Best-effort live badges over R3; the poll below is the fallback and runs whether or not the stream connects.
  usePaymentQueueLiveCounts();

  const countsQ = useQuery({
    queryKey: paymentQueueKeys.counts(),
    queryFn: paymentQueueApi.counts,
    refetchInterval: POLL_MS,
  });

  const isError = countsQ.isError && countsQ.data === undefined;
  return {
    tabCounts: countsQ.data ? toTabCounts(countsQ.data) : [],
    stale: countsQ.isError && countsQ.data !== undefined,
    isLoading: !isError && countsQ.data === undefined,
    isError,
    refetch: () => {
      if (countsQ.isError) void countsQ.refetch();
    },
  };
}

/** One R1 page as the grid shows it. */
export interface PaymentQueueGridData {
  /** The page's rows; empty until the page has loaded (never rows of another page, tab or filter). */
  rows: PaymentQueueRow[];
  /** Every row of the tab under the filters, not only this page: the pager's total. */
  totalCount: number | undefined;
  /** The first answer for these parameters has not come yet. */
  isLoading: boolean;
  /** A call failed and there is no answer for these parameters. No mock stands in for it. */
  isError: boolean;
  /** A refresh failed; what is shown is the last good answer for these parameters. */
  stale: boolean;
  refetch: () => void;
}

/**
 * R1, one page, for the tab, page, size, sort and filters in `params` (server mode, PMQ-P7-4). Each distinct set of
 * parameters is its own query, so a page never shows rows read under other filters; polled every minute like the
 * counts. Rows are the server's, in the server's order; nothing is filtered, sorted or cut in the browser.
 *
 * `enabled` (PMQ-P7-5, default true): false holds the first R1 call until the screen has applied the user's saved
 * filter, so the first page is already the filtered one (design §9.2, AC-PMQ-096).
 */
export function usePaymentQueueGrid(params: PaymentQueueGridParams, enabled = true): PaymentQueueGridData {
  const query = useQuery({
    queryKey: paymentQueueKeys.grid(params),
    queryFn: () => paymentQueueApi.grid(params),
    refetchInterval: POLL_MS,
    enabled,
  });
  const data = query.data;
  const rows = useMemo(() => (data ? toGridRows(data.items, params.tab) : []), [data, params.tab]);
  return {
    rows,
    totalCount: data?.totalCount,
    isLoading: query.isLoading,
    isError: query.isError && data === undefined,
    stale: query.isError && data !== undefined,
    refetch: () => void query.refetch(),
  };
}

/** R4: the enabled filters and their chip values within the caller's scope. A failure leaves the panel on its fixed lists. */
export function usePaymentQueueFilterOptions() {
  return useQuery({
    queryKey: paymentQueueKeys.filterOptions(),
    queryFn: paymentQueueApi.filterOptions,
    // The enabled set is a tenant setting and the values follow the data in scope; a minute is fresh enough.
    staleTime: POLL_MS,
  });
}

// ─── The drawer (PMQ-P4-4, PMQ-P4-5) ─────────────────────────────────────────────────────────────────────────────────

/** R5: the popup header of one item. */
export function usePaymentQueueHeader(queueEntryId: string) {
  return useQuery({
    queryKey: paymentQueueKeys.header(queueEntryId),
    queryFn: () => paymentQueueApi.header(queueEntryId),
  });
}

/** R8 as the drawer reads it: the stepper's steps, and whether the workflow timeline behind them could be read. */
export interface PaymentQueueWorkflowView {
  steps: WorkflowStep[];
  /** False when the timeline read failed: `steps` holds the queue's levels only and the drawer says so. */
  timelineAvailable: boolean;
}

/** R8: the Workflow stepper of one item, mapped to the stepper's steps and the timeline flag. */
export function usePaymentQueueWorkflow(queueEntryId: string) {
  return useQuery({
    queryKey: paymentQueueKeys.workflow(queueEntryId),
    queryFn: () => paymentQueueApi.workflow(queueEntryId),
    select: (workflow): PaymentQueueWorkflowView => ({
      steps: toWorkflowSteps(workflow),
      timelineAvailable: isWorkflowTimelineAvailable(workflow),
    }),
  });
}

/** R9: the Action History of one item, oldest first. */
export function usePaymentQueueActionHistory(queueEntryId: string) {
  return useQuery({
    queryKey: paymentQueueKeys.actionHistory(queueEntryId),
    queryFn: () => paymentQueueApi.actionHistory(queueEntryId),
  });
}

/** R10: the footer buttons of one item for the caller. Never computed on the screen (I-10). */
export function usePaymentQueueAvailableActions(queueEntryId: string, enabled = true) {
  return useQuery({
    queryKey: paymentQueueKeys.availableActions(queueEntryId),
    queryFn: () => paymentQueueApi.availableActions(queueEntryId),
    enabled,
  });
}

/** R11: the Reassign departments. Read only while a Reassign is being filled in. */
export function usePaymentQueueReassignTargets(queueEntryId: string, enabled: boolean) {
  return useQuery({
    queryKey: paymentQueueKeys.reassignTargets(queueEntryId),
    queryFn: () => paymentQueueApi.reassignTargets(queueEntryId),
    enabled,
  });
}

/** The Audit Trail of one item, newest first. */
export function usePaymentQueueAuditTrail(queueEntryId: string) {
  return useQuery({
    queryKey: paymentQueueKeys.auditTrail(queueEntryId),
    queryFn: () => paymentQueueApi.auditTrail(queueEntryId),
  });
}

/**
 * W1. A success refreshes everything the Payment Queue shows (`paymentQueueKeys.all`). A 409 (the state moved) or a
 * 403 (the caller may no longer act) refreshes the item, so the footer shows what is offered now; a 409 also
 * refreshes the grid, whose row carries the old state.
 */
export function useActOnPaymentQueueItem(queueEntryId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: ActOnPaymentQueueItemRequest) => paymentQueueApi.act(queueEntryId, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: paymentQueueKeys.all }),
    onError: async (error) => {
      const { status } = paymentQueueProblem(error);
      if (status === 409) {
        await queryClient.invalidateQueries({ queryKey: paymentQueueKeys.all });
      } else if (status === 403) {
        await queryClient.invalidateQueries({ queryKey: paymentQueueKeys.item(queueEntryId) });
      }
    },
  });
}
