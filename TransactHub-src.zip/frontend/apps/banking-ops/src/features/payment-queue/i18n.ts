import { useTranslation } from 'react-i18next';
import type { PriorityLevel } from './types';
import { formatInstant, sessionDateTimeContext } from '@paymenthub/ui';

/**
 * The Payment Queue screen's copy: the `PAYMENT_QUEUE` block of the shared `@paymenthub/ui` translations
 * (`i18n/en.json`, `ar.json`), the same pattern as `DEPARTMENT.*` and `GL_MAPPING.*` (React UI guideline §16). Keys
 * below are relative to that block.
 *
 * What is not translated: the server's own labels (Queue Status, a workflow level's role and badge, an action's label,
 * party names, remarks) and system values (rail, channel and message-type codes). Those render as sent.
 */
export function usePaymentQueueTranslation() {
  return useTranslation('translation', { keyPrefix: 'PAYMENT_QUEUE' });
}

/** The prefixed `t`, for helpers that build copy outside a component. */
export type PaymentQueueT = ReturnType<typeof usePaymentQueueTranslation>['t'];

/** The screen's own words for the three priorities its mapper produces (a null priority is Normal). */
export const PRIORITY_KEY: Record<PriorityLevel, string> = {
  Urgent: 'PRIORITY.URGENT',
  High: 'PRIORITY.HIGH',
  Normal: 'PRIORITY.NORMAL',
};

export const PAYMENT_TYPE_KEY: Record<'Batch' | 'Single', string> = {
  Batch: 'PAYMENT_TYPE.BATCH',
  Single: 'PAYMENT_TYPE.SINGLE',
};

/**
 * The locale a date is formatted in. English is the UAE's `en-GB` day-first order; Arabic is `ar-AE` (the Department
 * and GL Mapping screens do the same).
 */
export function dateLocale(language: string | undefined): string {
  return language?.startsWith('ar') ? 'ar-AE' : 'en-GB';
}

/**
 * An instant in the session zone (UTC date-time design §6.7), `dd-MM-yyyy HH:mm:ss`, in the reader's language's digits:
 * `2026-10-17T08:00:00Z` → "17-10-2026 12:00:00" in Dubai. A thin delegate to the `@paymenthub/ui` date-time module.
 */
export function formatDateTime(iso: string, language: string | undefined): string {
  return formatInstant(iso, { timeZone: sessionDateTimeContext().timeZone, locale: dateLocale(language) });
}
