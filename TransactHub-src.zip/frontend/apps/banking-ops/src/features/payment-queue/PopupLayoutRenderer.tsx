import { useState } from 'react';
import type { ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { formatDateTime, usePaymentQueueTranslation } from './i18n';
import { fmtMoney, NOT_AVAILABLE } from './popupFormat';
import { isShown, POPUP_SLOT } from './popupLayout';
import type { PopupColumn, PopupContext, PopupField, PopupGrid, PopupLayout, PopupSection, PopupTab } from './popupLayout';
import type { PopupGridData, PopupValue, PopupValues } from './popupValues';

/** The queue-placed components a layout slot names (design §8.0). The renderer draws them where the layout says. */
export interface PopupLayoutSlots {
  /** The Workflow stepper (R8). */
  workflow: ReactNode;
  /** The Action History table (R9). */
  actionHistory: ReactNode;
}

interface Props {
  layout: PopupLayout;
  /** What the item is, for `showWhen`. */
  context: PopupContext;
  /** The values by code. A code with none is drawn as "—". */
  values: PopupValues;
  slots: PopupLayoutSlots;
}

// ─── Values ──────────────────────────────────────────────────────────────────────────────────────────────────────────

function isMissing(value: PopupValue): boolean {
  return value === null || value === undefined || (typeof value === 'string' && value.trim() === '');
}

function isObjectValue(value: PopupValue): value is Exclude<PopupValue, string | number | boolean | null | undefined> {
  return typeof value === 'object' && value !== null;
}

function isNumeric(value: PopupValue): boolean {
  return typeof value === 'number' || (isObjectValue(value) && value.type === 'money');
}

/**
 * One value as text or a node. What a code means is not known here: the value says what it is (text, a number, money, an
 * instant, a client-built node), and a missing one is "—", never blank and never zero (E30, I-13).
 */
function useRenderValue(): (value: PopupValue) => ReactNode {
  const { t, i18n } = usePaymentQueueTranslation();
  return (value) => {
    if (isMissing(value)) return NOT_AVAILABLE;
    if (typeof value === 'boolean') return value ? t('DRAWER.LAYOUT_YES') : t('DRAWER.LAYOUT_NO');
    if (typeof value === 'number') return value.toLocaleString();
    if (typeof value === 'string') return value;
    if (!isObjectValue(value)) return NOT_AVAILABLE;
    switch (value.type) {
      case 'money':
        return fmtMoney(value.amount, value.currency);
      case 'dateTime':
        return formatDateTime(value.value, i18n.language);
      default:
        return value.node;
    }
  };
}

/** The total of one grid column: money sums its amounts (in the first row's currency), numbers sum, anything else has none. */
function columnTotal(rows: PopupGridData['rows'], fieldCode: string): PopupValue {
  let sum = 0;
  let currency: string | null = null;
  let counted = 0;
  for (const row of rows) {
    const value = row[fieldCode];
    if (typeof value === 'number') {
      sum += value;
    } else if (isObjectValue(value) && value.type === 'money') {
      sum += value.amount;
      currency ??= value.currency;
    } else {
      continue;
    }
    counted += 1;
  }
  if (counted === 0) return null;
  return currency === null ? sum : { type: 'money', amount: sum, currency };
}

// ─── Pieces ──────────────────────────────────────────────────────────────────────────────────────────────────────────

/** One label/value row: label left, value right, so a section reads as one attached list. */
function FieldRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="pq-field-row">
      <span className="pq-field-row-label">{label}</span>
      <span className="pq-field-row-value">{children}</span>
    </div>
  );
}

function Fields({ fields, context, values }: { fields: PopupField[]; context: PopupContext; values: PopupValues }) {
  const render = useRenderValue();
  return (
    <>
      {fields
        .filter((f) => isShown(f.showWhen, context))
        // A code may appear twice in one section when their showWhen exclude each other, so the key is the position.
        .map((f, i) => (
          <FieldRow key={`${f.fieldCode}-${i}`} label={f.label}>
            {render(values.fields[f.fieldCode])}
          </FieldRow>
        ))}
    </>
  );
}

/** The header cells above the columns: one cell per run of columns sharing a group (a run with no group is an empty cell). */
function groupRuns(grid: PopupGrid): Array<{ label: string; span: number }> {
  const labels = new Map(grid.columnGroups.map((g) => [g.groupCode, g.label]));
  const runs: Array<{ group: string | undefined; label: string; span: number }> = [];
  for (const column of grid.columns) {
    const last = runs[runs.length - 1];
    if (last && last.group === column.group) {
      last.span += 1;
    } else {
      runs.push({ group: column.group, label: column.group ? (labels.get(column.group) ?? column.group) : '', span: 1 });
    }
  }
  return runs;
}

function GridPager({ paging }: { paging: NonNullable<PopupGridData['paging']> }) {
  const { t } = usePaymentQueueTranslation();
  const pages = Math.max(1, Math.ceil(paging.totalCount / Math.max(1, paging.pageSize)));
  return (
    <div className="pq-grid-pager">
      <button type="button" className="btn-secondary" disabled={paging.page <= 1} onClick={() => paging.onPageChange(paging.page - 1)}>
        {t('DRAWER.LAYOUT_PAGE_PREV')}
      </button>
      <span>{t('DRAWER.LAYOUT_PAGE_OF', { page: paging.page, pages })}</span>
      <button type="button" className="btn-secondary" disabled={paging.page >= pages} onClick={() => paging.onPageChange(paging.page + 1)}>
        {t('DRAWER.LAYOUT_PAGE_NEXT')}
      </button>
    </div>
  );
}

/** One grid: its column groups, its columns with the configured labels, the rows it was given, and its total row. */
function GridView({ grid, data }: { grid: PopupGrid; data: PopupGridData | undefined }) {
  const { t } = usePaymentQueueTranslation();
  const render = useRenderValue();
  const rows = data?.rows ?? [];
  const numeric = (column: PopupColumn) => rows.some((r) => isNumeric(r[column.fieldCode]));

  if (rows.length === 0) {
    // The route says the rail holds nothing (no recorded posting legs): the layout's own "Not Available", never a planned row.
    const fallback = data?.notAvailable ? t('DRAWER.LAYOUT_GRID_NOT_AVAILABLE') : t('DRAWER.LAYOUT_GRID_EMPTY');
    return <p className="pq-muted-note">{grid.emptyLabel ?? fallback}</p>;
  }

  const totalAt = grid.totalRow ? grid.columns.findIndex((c) => c.fieldCode === grid.totalRow?.fieldCode) : -1;
  const total = grid.totalRow && totalAt >= 0 ? columnTotal(rows, grid.totalRow.fieldCode) : null;

  return (
    <div className="pq-posting-wrap table-holder overflow-x-auto">
      <table>
        <thead>
          {grid.columnGroups.length > 0 && (
            <tr>
              {groupRuns(grid).map((run, i) => (
                <th key={`${run.label}-${i}`} colSpan={run.span}>
                  {run.label}
                </th>
              ))}
            </tr>
          )}
          <tr>
            {grid.columns.map((column) => (
              <th key={column.fieldCode} className={cn(numeric(column) && 'pq-num-col')}>
                {column.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, r) => (
            <tr key={r}>
              {grid.columns.map((column) => (
                <td key={column.fieldCode} className={cn(isNumeric(row[column.fieldCode]) && 'pq-num-col')}>
                  {render(row[column.fieldCode])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
        {grid.totalRow && total !== null && (
          <tfoot>
            <tr>
              {totalAt > 0 && <td colSpan={totalAt}>{grid.totalRow.label}</td>}
              <td className="pq-num-col">
                {totalAt === 0 ? `${grid.totalRow.label} ` : ''}
                {render(total)}
              </td>
              {grid.columns.slice(totalAt + 1).map((column) => (
                <td key={column.fieldCode} />
              ))}
            </tr>
          </tfoot>
        )}
      </table>
      {grid.paged && data?.paging && <GridPager paging={data.paging} />}
    </div>
  );
}

/** A section header with a thin rule underneath; sections stack one after another as one continuous panel. */
function SectionShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="pq-modal-section">
      <div className="pq-modal-section-head">
        <span className="pq-modal-section-title">{title}</span>
      </div>
      <div className="pq-modal-section-body">{children}</div>
    </section>
  );
}

function SectionView({
  section,
  open,
  onToggle,
  context,
  values,
  slots,
}: {
  section: PopupSection;
  open: boolean;
  onToggle: () => void;
  context: PopupContext;
  values: PopupValues;
  slots: PopupLayoutSlots;
}) {
  if (section.slot === POPUP_SLOT.actionHistory) {
    return <SectionShell title={section.label}>{slots.actionHistory}</SectionShell>;
  }
  if (section.slot) return null;

  const body = (
    <>
      <Fields fields={section.fields} context={context} values={values} />
      {section.grids.map((grid) => (
        <GridView key={grid.gridCode} grid={grid} data={values.grids[grid.gridCode]} />
      ))}
    </>
  );

  if (!section.expandable) return <SectionShell title={section.label}>{body}</SectionShell>;

  return (
    <section className="pq-modal-section">
      <button type="button" className="pq-more-details-toggle" onClick={onToggle} aria-expanded={open}>
        <ChevronDown size={12} className={cn('pq-more-details-caret', open && 'pq-more-details-caret-open')} /> {section.label}
      </button>
      {open && <div className="pq-more-details-body">{body}</div>}
    </section>
  );
}

function TabBody({
  tab,
  context,
  values,
  slots,
  expanded,
  onToggle,
}: {
  tab: PopupTab;
  context: PopupContext;
  values: PopupValues;
  slots: PopupLayoutSlots;
  expanded: ReadonlySet<string>;
  onToggle: (key: string) => void;
}) {
  if (tab.slot === POPUP_SLOT.workflow) return <>{slots.workflow}</>;
  if (tab.slot) return null;

  return (
    <div className="pq-modal-panel">
      {tab.sections
        .filter((s) => isShown(s.showWhen, context))
        .map((section) => {
          const key = `${tab.tabCode}/${section.sectionCode}`;
          return (
            <SectionView
              key={key}
              section={section}
              open={expanded.has(key)}
              onToggle={() => onToggle(key)}
              context={context}
              values={values}
              slots={slots}
            />
          );
        })}
    </div>
  );
}

/**
 * The popup's tabs and body, drawn from the R14 layout and nothing else (design §8.0, AC-PMQ-093): the tabs, sections,
 * fields and grids in their configured order and labels. It names no rail and no field code. Which components the queue
 * places itself (the Workflow stepper, the Action History) the layout says by slot; the footer is the drawer's.
 */
export function PopupLayoutRenderer({ layout, context, values, slots }: Props) {
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<ReadonlySet<string>>(new Set());

  const tabs = layout.tabs.filter((t) => isShown(t.showWhen, context));
  const active = tabs.find((t) => t.tabCode === activeTab) ?? tabs[0];

  const toggle = (key: string) =>
    setExpanded((current) => {
      const next = new Set(current);
      if (!next.delete(key)) next.add(key);
      return next;
    });

  return (
    <>
      <div className="pq-modal-tabs">
        {tabs.map((tab) => (
          <button
            key={tab.tabCode}
            type="button"
            className={cn('pq-modal-tab', tab.tabCode === active?.tabCode && 'pq-modal-tab-active')}
            onClick={() => setActiveTab(tab.tabCode)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="pq-modal-body">
        {active && <TabBody tab={active} context={context} values={values} slots={slots} expanded={expanded} onToggle={toggle} />}
      </div>
    </>
  );
}
