import type { RefObject } from 'react';
import { Can } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { MessageTypeBadge, PaymentTypeBadge, PriorityBadge, QueueStatusBadge, RailBadge } from './badges';
import { columnFilterFor } from './columnFilters';
import type { PanelOptions } from './filterOptions';
import { formatDateTime } from './i18n';
import type { PaymentQueueT } from './i18n';
import type { PaymentQueueRow, QueueTabKey } from './types';

/**
 * What the row buttons read at click and render time, behind a ref. SmartGrid snapshots column definitions on first
 * mount and never re-reads them, so the render closures read the live tab, permission and handlers through this ref
 * (the pattern of `DepartmentGridView`).
 */
export interface PaymentQueueGridView {
  activeTab: QueueTabKey;
  /** Key 117 (Z2). Until the permission snapshot loads this reads false, so a user briefly sees View alone. */
  canAct: boolean;
  onView: (row: PaymentQueueRow) => void;
  onAuditTrail: (row: PaymentQueueRow) => void;
}

/**
 * The grid's columns, in the order and with the labels and badges the screen has always had.
 *
 * - `sortKey` is the name R1 sorts on (`PAYMENT_QUEUE_SORT_COLUMNS`, PMQ-P7-4): the grid hands it back on a header
 *   click and the server sorts (server mode). A column with no `sortKey`
 *   (the two account columns) is not sortable, as before.
 * - `getValue` is what the grid's export writes for a cell; it defaults to the row's own field of that name, which is
 *   what the old CSV wrote. The account columns are the server's text (masked, or in full for a holder of key 24 with
 *   an open session); nothing here masks or unmasks.
 * - `filterKey` is set (through `columnFilterFor`) only on the columns R1 can filter: Queue Status, Payment Type, Rail,
 *   Channel, Priority, Amount and Transaction Date, and only while R4 keeps that filter on. The rest have no filter icon.
 */
export function buildColumns(
  view: RefObject<PaymentQueueGridView>,
  t: PaymentQueueT,
  language: string | undefined,
  options: PanelOptions,
): SmartGridColumn<PaymentQueueRow>[] {
  return [
    {
      key: 'systemReferenceNo',
      label: t('COLUMNS.SYSTEM_REFERENCE_NO'),
      sortKey: 'systemReference',
      render: (r) => <span className="pq-refno-cell">{r.systemReferenceNo}</span>,
    },
    { key: 'debtorName', label: t('COLUMNS.DEBTOR_NAME'), sortKey: 'debtorName' },
    { key: 'channel', label: t('COLUMNS.CHANNEL'), sortKey: 'channel', ...columnFilterFor('channel', options) },
    {
      key: 'paymentType',
      label: t('COLUMNS.PAYMENT_TYPE'),
      sortKey: 'paymentType',
      ...columnFilterFor('paymentType', options),
      render: (r) => <PaymentTypeBadge type={r.paymentType} />,
    },
    {
      key: 'rail',
      label: t('COLUMNS.RAIL'),
      sortKey: 'rail',
      ...columnFilterFor('rail', options),
      render: (r) => <RailBadge rail={r.rail} />,
    },
    {
      key: 'amount',
      label: t('COLUMNS.AMOUNT'),
      sortKey: 'amount',
      ...columnFilterFor('amount', options),
      numeric: true,
      render: (r) => r.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
    },
    { key: 'currency', label: t('COLUMNS.CURRENCY'), sortKey: 'currency' },
    {
      key: 'transactionDate',
      label: t('COLUMNS.TRANSACTION_DATE'),
      sortKey: 'transactionDate',
      ...columnFilterFor('transactionDate', options),
      render: (r) => formatDateTime(r.transactionDate, language),
    },
    {
      key: 'messageType',
      label: t('COLUMNS.MESSAGE_TYPE'),
      sortKey: 'messageType',
      render: (r) => <MessageTypeBadge messageType={r.messageType} />,
    },
    {
      key: 'submittedBy',
      label: t('COLUMNS.SUBMITTED_BY'),
      sortKey: 'submittedBy',
      // The server sorts on the name (System first); the cell and the export show the word "System".
      getValue: (r) => r.submittedBy || t('SYSTEM'),
      render: (r) => r.submittedBy || t('SYSTEM'),
    },
    {
      key: 'submittedDate',
      label: t('COLUMNS.SUBMITTED_DATE'),
      sortKey: 'submittedDate',
      render: (r) => formatDateTime(r.submittedDate, language),
    },
    { key: 'debtorAccount', label: t('COLUMNS.DEBTOR_ACCOUNT'), render: (r) => r.debtorAccount },
    { key: 'creditorAccount', label: t('COLUMNS.CREDITOR_ACCOUNT'), render: (r) => r.creditorAccount || '—' },
    { key: 'creditorName', label: t('COLUMNS.CREDITOR_NAME'), sortKey: 'creditorName', render: (r) => r.creditorName || '—' },
    { key: 'creditorBank', label: t('COLUMNS.CREDITOR_BANK'), sortKey: 'creditorBank', render: (r) => r.creditorBank || '—' },
    {
      key: 'queueStatus',
      label: t('COLUMNS.QUEUE_STATUS'),
      sortKey: 'queueStatus',
      ...columnFilterFor('queueStatus', options),
      render: (r) => <QueueStatusBadge status={r.queueStatus} />,
    },
    {
      key: 'priority',
      label: t('COLUMNS.PRIORITY'),
      sortKey: 'priority',
      ...columnFilterFor('priority', options),
      render: (r) => <PriorityBadge priority={r.priority} />,
    },
    {
      key: 'actions',
      label: t('COLUMNS.ACTION'),
      locked: true,
      render: (r) => (
        <div className="pq-row-actions">
          <button type="button" onClick={() => view.current.onView(r)} className="btn-secondary pq-view-action-btn">
            {view.current.activeTab === 'payment' && view.current.canAct ? t('ROW.VIEW_ACTION') : t('ROW.VIEW')}
          </button>
          {/* Z11 ruling: the Audit Trail button needs the page key only; there is no control key. */}
          <Can permission={PERM.paymentQueuePage}>
            <button type="button" onClick={() => view.current.onAuditTrail(r)} className="btn-tertiary pq-view-action-btn">
              {t('ROW.AUDIT_TRAIL')}
            </button>
          </Can>
        </div>
      ),
    },
  ];
}
