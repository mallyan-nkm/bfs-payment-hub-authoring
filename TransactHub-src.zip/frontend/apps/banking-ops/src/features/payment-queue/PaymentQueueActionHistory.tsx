import { cn } from '@paymenthub/ui';
import { asUtcIso } from './api/paymentQueueApi';
import type { usePaymentQueueActionHistory } from './api/paymentQueueQueries';
import { formatDateTime, usePaymentQueueTranslation } from './i18n';

/**
 * The colour of an action's badge (BA AC-46): approving is green, rejecting or closing is red, holding or returning is
 * amber, and reassigning or repairing is blue. An action code this screen does not know is neutral.
 */
const ACTION_TONE: Readonly<Record<string, string>> = {
  APPROVE: 'success',
  REJECT: 'error',
  CLOSE: 'error',
  HOLD: 'warn',
  RETURN: 'warn',
  REASSIGN: 'blue',
  REPAIR: 'blue',
};

function actionTone(actionCode: string): string {
  return Object.hasOwn(ACTION_TONE, actionCode) ? ACTION_TONE[actionCode] : '';
}

/**
 * The Action History table (R9, design §8.9): always drawn, empty or not, with its loading and failure states. The layout
 * places it by its `actionHistory` slot, under the section title the layout gives it. Each entry shows the user's name with
 * the role below it, the date and time, a colour-coded action badge and the remarks as entered (blank where none).
 */
export function PaymentQueueActionHistory({ query }: { query: ReturnType<typeof usePaymentQueueActionHistory> }) {
  const { t, i18n } = usePaymentQueueTranslation();
  const history = query.data ?? [];

  if (query.isError) {
    return (
      <p role="alert" className="pq-muted-note">
        {t('DRAWER.HISTORY_FAILED')}
      </p>
    );
  }

  return (
    <div className="table-holder overflow-x-auto pq-history-table">
      <table aria-label={t('DRAWER.SECTION_HISTORY')}>
        <thead>
          <tr>
            <th>{t('DRAWER.HISTORY_NAME_ROLE')}</th>
            <th>{t('DRAWER.HISTORY_DATE_TIME')}</th>
            <th>{t('DRAWER.HISTORY_ACTION')}</th>
            <th>{t('DRAWER.HISTORY_COMMENT')}</th>
          </tr>
        </thead>
        <tbody>
          {history.length === 0 ? (
            <tr>
              <td colSpan={4} className="pq-empty-cell">
                {query.isLoading ? t('DRAWER.LOADING') : t('DRAWER.HISTORY_EMPTY')}
              </td>
            </tr>
          ) : (
            history.map((a) => (
              <tr key={a.actionId}>
                <td>
                  <div className="pq-history-name">{a.actorName}</div>
                  <div className="pq-history-role">{a.actorRoleName}</div>
                </td>
                <td>{formatDateTime(asUtcIso(a.occurredAt), i18n.language)}</td>
                <td>
                  <span className={cn('status-badge', actionTone(a.actionCode))}>{a.actionLabel}</span>
                </td>
                <td>{a.remarks?.trim() ?? ''}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
