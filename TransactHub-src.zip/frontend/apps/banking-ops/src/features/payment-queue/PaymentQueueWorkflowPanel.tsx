import { CornerUpLeft, Pause } from 'lucide-react';
import { cn, LoadingSpinner } from '@paymenthub/ui';
import type { WorkflowStep } from './types';
import type { usePaymentQueueWorkflow } from './api/paymentQueueQueries';
import { formatDateTime, usePaymentQueueTranslation } from './i18n';
import type { PaymentQueueT } from './i18n';

/** The sentence under a stepper level, from what R8 said about it (nothing is invented). */
function stepDescription(t: PaymentQueueT, step: WorkflowStep, language: string | undefined): string {
  const when = step.at ? formatDateTime(step.at, language) : null;
  if (step.source === 'workflow') {
    // A completed workflow step: its time only. The step's name is the label, shown as stored.
    return when ? t('WORKFLOW.STEP_COMPLETED_AT', { when }) : t('WORKFLOW.STEP_COMPLETED');
  }
  if (step.source === 'action') {
    // A Parallel item lists what users did, never a level or a role: who did it and when.
    if (step.status === 'completed') {
      if (!step.actor) return t('WORKFLOW.COMPLETED');
      return when ? t('WORKFLOW.APPROVED_BY_AT', { who: step.actor, when }) : t('WORKFLOW.APPROVED_BY', { who: step.actor });
    }
    if (step.status === 'held') {
      if (!step.actor) return when ? t('WORKFLOW.SINCE', { when }) : '';
      return when ? t('WORKFLOW.HELD_BY_AT', { who: step.actor, when }) : t('WORKFLOW.HELD_BY', { who: step.actor });
    }
  }
  switch (step.status) {
    case 'completed':
      if (!step.actor) return t('WORKFLOW.COMPLETED');
      return when
        ? t('WORKFLOW.COMPLETED_BY_AT', { who: step.actor, when })
        : t('WORKFLOW.COMPLETED_BY', { who: step.actor });
    case 'active':
      return step.awaitingRole ? t('WORKFLOW.AWAITING', { role: step.awaitingRole }) : t('WORKFLOW.IN_PROGRESS');
    case 'held':
      return when ? t('WORKFLOW.SINCE', { when }) : '';
    case 'returned':
      if (!step.actor) return '';
      return when
        ? t('WORKFLOW.RETURNED_TO_AT', { who: step.actor, when })
        : t('WORKFLOW.RETURNED_TO', { who: step.actor });
    default:
      return t('WORKFLOW.PENDING');
  }
}

/** The name of a step: a workflow step's stored name, what the user did on a Parallel item, or the level and its role. */
function stepLabel(t: PaymentQueueT, step: WorkflowStep): string | undefined {
  if (step.source === 'workflow') return step.stepName;
  if (step.source === 'action') {
    if (step.approvalNo && step.approvalsRequired) {
      return t('WORKFLOW.ACTION_APPROVAL_OF', { n: step.approvalNo, total: step.approvalsRequired });
    }
    return t(step.status === 'held' ? 'WORKFLOW.ACTION_HELD' : step.status === 'returned' ? 'WORKFLOW.ACTION_RETURNED' : 'WORKFLOW.ACTION_APPROVED');
  }
  return t('WORKFLOW.LEVEL', { level: step.level, role: step.roleLabel });
}

/** The marker inside a stepper dot: a tick when done, the state's icon when held or returned, else the level. */
function StepMarker({ step, index }: { step: WorkflowStep; index: number }) {
  if (step.status === 'completed') return <>✓</>;
  if (step.status === 'held') return <Pause size={12} aria-hidden="true" />;
  if (step.status === 'returned') return <CornerUpLeft size={12} aria-hidden="true" />;
  return <>{index + 1}</>;
}

/** The Workflow stepper (design §8.8; BA AC-58): On Hold is amber and Returned is orange, each with a glow ring. */
function WorkflowStepper({ steps }: { steps: WorkflowStep[] }) {
  return (
    <>
      {steps.map((step, i) => (
        <WorkflowStepRow key={step.source === 'queue' ? `level-${step.level}` : `${step.source}-${i}`} step={step} index={i} isLast={i === steps.length - 1} />
      ))}
    </>
  );
}

/** One level of the stepper. The label and the sentence under it are the screen's words; the badge and note are the server's. */
function WorkflowStepRow({ step, index, isLast }: { step: WorkflowStep; index: number; isLast: boolean }) {
  const { t, i18n } = usePaymentQueueTranslation();
  const description = stepDescription(t, step, i18n.language);
  return (
    <div className={cn('pq-workflow-step', `pq-workflow-step-${step.status}`)}>
      <div className="pq-workflow-marker">
        <span className="pq-workflow-dot">
          <StepMarker step={step} index={index} />
        </span>
        {!isLast && <span className="pq-workflow-line" />}
      </div>
      <div className="pq-workflow-text">
        <p className="pq-workflow-label">
          {stepLabel(t, step)}
          {step.badge && (
            <span className={cn('status-badge pq-workflow-badge', step.status === 'held' ? 'warn' : 'pq-workflow-badge-returned')}>
              {step.badge}
            </span>
          )}
        </p>
        {description && <p className="pq-workflow-desc">{description}</p>}
        {step.note && <p className="pq-workflow-note">{step.note}</p>}
      </div>
    </div>
  );
}

/**
 * The Workflow tab's body (R8, design §8.8): the stepper, with its loading, failure, empty and "timeline unavailable"
 * states. The layout places it by its `workflow` slot; the query is the drawer's, started when it opens.
 */
export function PaymentQueueWorkflowPanel({ query }: { query: ReturnType<typeof usePaymentQueueWorkflow> }) {
  const { t } = usePaymentQueueTranslation();
  const workflow = query.data?.steps ?? [];
  const timelineAvailable = query.data?.timelineAvailable ?? true;

  return (
    <div className="pq-workflow">
      {query.isLoading && (
        <div className="flex justify-center p-6">
          <LoadingSpinner label={t('DRAWER.WORKFLOW_LOADING')} />
        </div>
      )}
      {query.isError && (
        <div role="alert" className="pq-muted-note">
          <p>{t('DRAWER.WORKFLOW_FAILED')}</p>
          <button type="button" className="btn-secondary" onClick={() => void query.refetch()}>
            {t('COMMON.RETRY')}
          </button>
        </div>
      )}
      {query.isSuccess && workflow.length === 0 && <p className="pq-muted-note">{t('DRAWER.WORKFLOW_EMPTY')}</p>}
      {query.isSuccess && !timelineAvailable && (
        <p role="status" className="pq-muted-note">
          {t('DRAWER.WORKFLOW_TIMELINE_UNAVAILABLE')}
        </p>
      )}
      <WorkflowStepper steps={workflow} />
    </div>
  );
}
