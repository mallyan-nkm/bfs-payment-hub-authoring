import { useEffect, useId, useRef, useState } from 'react';
import { ChevronDown, SlidersHorizontal } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import { PAYMENT_TYPE_KEY, PRIORITY_KEY, usePaymentQueueTranslation } from './i18n';
import type { PanelOptions } from './filterOptions';
import type { ChannelCode, PaymentTypeFilter, PriorityLevel, QueueStatus, RailCode } from './types';

export type FilterGroupMode = 'OR' | 'AND';

export interface AdvancedFilterState {
  status: QueueStatus[];
  // Match-mode fields are inert while the OR/AND toggle (pq-andor-toggle) is commented out below
  // — kept on the state shape so re-enabling the control later doesn't need a shape migration.
  statusMode: FilterGroupMode;
  paymentType: PaymentTypeFilter[];
  paymentTypeMode: FilterGroupMode;
  rail: RailCode[];
  railMode: FilterGroupMode;
  channel: ChannelCode[];
  channelMode: FilterGroupMode;
  priority: PriorityLevel[];
  priorityMode: FilterGroupMode;
  amountMin: string;
  amountMax: string;
  dateFrom: string;
  dateTo: string;
}

export const EMPTY_FILTERS: AdvancedFilterState = {
  status: [],
  statusMode: 'OR',
  paymentType: [],
  paymentTypeMode: 'OR',
  rail: [],
  railMode: 'OR',
  channel: [],
  channelMode: 'OR',
  priority: [],
  priorityMode: 'OR',
  amountMin: '',
  amountMax: '',
  dateFrom: '',
  dateTo: '',
};

// Which filters show, and every list of chip values, come from R4 (design §9.1, PMQ-P7-4): the server limits the values
// to the user's tenant, rails and departments and lists only the filters the tenant has enabled. See `filterOptions.ts`.

// The OR/AND match-mode control (.pq-andor-toggle) is disabled per request — every filtered
// field is single-valued per row, so AND vs OR never changed the result anyway. Left here,
// commented, in case a future multi-valued field makes the distinction meaningful again.
//
// function ModeToggle({ mode, onChange }: { mode: FilterGroupMode; onChange: (mode: FilterGroupMode) => void }) {
//   return (
//     <div className="pq-andor-toggle" role="group" aria-label="Match mode">
//       {(['OR', 'AND'] as const).map((m) => (
//         <button
//           key={m}
//           type="button"
//           onClick={() => onChange(m)}
//           className={cn('pq-andor-btn', mode === m && 'pq-andor-btn-active')}
//         >
//           {m}
//         </button>
//       ))}
//     </div>
//   );
// }

// Chip/pill multi-select is disabled — every filter group (Status, Payment Type, Rail, Channel,
// Priority) now uses the single-choice SelectGroup dropdown below per request. Left here in case
// a future multi-valued field needs chip-style selection again.
//
// function ChipGroup<T extends string>({
//   title,
//   options,
//   selected,
//   onToggleValue,
//   onClear,
//   allLabel = 'All',
// }: {
//   title: string;
//   options: T[];
//   selected: T[];
//   onToggleValue: (value: T) => void;
//   onClear: () => void;
//   allLabel?: string;
// }) {
//   return (
//     <div className="pq-filter-group">
//       <div className="pq-filter-group-head">
//         <span className="pq-filter-group-title">{title}</span>
//       </div>
//       <div className="pq-chip-row">
//         <button
//           type="button"
//           onClick={onClear}
//           className={cn('common-pill', selected.length === 0 && 'active-pill')}
//           aria-pressed={selected.length === 0}
//         >
//           {allLabel}
//         </button>
//         {options.map((opt) => (
//           <button
//             key={opt}
//             type="button"
//             onClick={() => onToggleValue(opt)}
//             className={cn('common-pill', selected.includes(opt) && 'active-pill')}
//             aria-pressed={selected.includes(opt)}
//           >
//             {opt}
//           </button>
//         ))}
//       </div>
//     </div>
//   );
// }

/** Single-choice dropdown for filter groups that don't need multi-select chips. `selected`
 * mirrors the array shape the rest of `AdvancedFilterState` uses (0 or 1 entries) so the
 * mapping to R1's filter parameters (`toGridFilters`) doesn't need a special case for these fields. */
function SelectGroup<T extends string>({
  title,
  options,
  selected,
  onSelect,
  optionLabel,
}: {
  title: string;
  options: T[];
  selected: T[];
  onSelect: (value: T | '') => void;
  /** The text of an option whose value the screen words itself; omitted, the value is shown as sent. */
  optionLabel?: (value: T) => string;
}) {
  const { t } = usePaymentQueueTranslation();
  const current = selected[0] ?? '';
  return (
    <div className="pq-filter-group">
      <div className="pq-filter-group-head">
        <span className="input-label">{title}</span>
      </div>
      <select
        value={current}
        onChange={(e) => onSelect(e.target.value as T | '')}
        aria-label={title}
        className="input-cls pq-filter-select"
      >
        <option value="">{t('FILTER.ALL')}</option>
        {options.map((opt) => (
          <option key={opt} value={opt}>
            {optionLabel ? optionLabel(opt) : opt}
          </option>
        ))}
      </select>
    </div>
  );
}

/**
 * Checkbox dropdown for groups that take several values at once (Rail, Channel). `selected` is the same array shape as
 * the rest of `AdvancedFilterState`; R1 combines the values of one group with OR (design §9.1). No ticked box is "All".
 */
function MultiSelectGroup<T extends string>({
  title,
  options,
  selected,
  onChange,
}: {
  title: string;
  options: T[];
  selected: T[];
  onChange: (values: T[]) => void;
}) {
  const { t } = usePaymentQueueTranslation();
  const ref = useRef<HTMLDetailsElement>(null);
  const summary = selected.length === 0 ? t('FILTER.ALL') : selected.join(', ');

  // A native <details> stays open until its summary is clicked again; close it on an outside click or Escape.
  useEffect(() => {
    const close = () => {
      if (ref.current) ref.current.open = false;
    };
    const onPointerDown = (e: PointerEvent) => {
      if (ref.current?.open && !ref.current.contains(e.target as Node)) close();
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('pointerdown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('pointerdown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, []);
  const toggle = (opt: T) =>
    onChange(selected.includes(opt) ? selected.filter((v) => v !== opt) : [...selected, opt]);
  return (
    <div className="pq-filter-group">
      <div className="pq-filter-group-head">
        <span className="input-label">{title}</span>
      </div>
      <details ref={ref} className="pq-multi-select">
        <summary className="pq-multi-summary" aria-label={title} title={summary}>
          {summary}
        </summary>
        <div className="pq-multi-menu" role="group" aria-label={title}>
          <label className="pq-multi-option">
            <input type="checkbox" checked={selected.length === 0} onChange={() => onChange([])} />
            <span>{t('FILTER.ALL')}</span>
          </label>
          {options.map((opt) => (
            <label key={opt} className="pq-multi-option">
              <input type="checkbox" checked={selected.includes(opt)} onChange={() => toggle(opt)} />
              <span>{opt}</span>
            </label>
          ))}
        </div>
      </details>
    </div>
  );
}

interface Props {
  value: AdvancedFilterState;
  onChange: (next: AdvancedFilterState) => void;
  onSaveFilter: () => void;
  onSetDefault: () => void;
  /** Which filters show and their chip values: R4's answer (PMQ-P7-4), or the fixed fallback while it is unavailable. */
  options: PanelOptions;
  /**
   * PMQ-P7-5 (Q-16): removes the one saved filter (P3), so the screen opens with no filter. Omitted, no Clear button is
   * drawn.
   */
  onClearSaved?: () => void;
  /** A saved-filter write is in flight: Save Filter, Set Default and Clear are disabled until it answers. */
  savedFilterBusy?: boolean;
}

/** How many of the enabled filters hold a value, shown on the collapsed toggle so a hidden filter is never a surprise. */
function activeFilterCount(value: AdvancedFilterState, enabled: PanelOptions['enabled']): number {
  const active = [
    enabled.has('status') && value.status.length > 0,
    enabled.has('paymentType') && value.paymentType.length > 0,
    enabled.has('rail') && value.rail.length > 0,
    enabled.has('channel') && value.channel.length > 0,
    enabled.has('priority') && value.priority.length > 0,
    enabled.has('amount') && (value.amountMin !== '' || value.amountMax !== ''),
    enabled.has('dateRange') && (value.dateFrom !== '' || value.dateTo !== ''),
  ];
  return active.filter(Boolean).length;
}

/**
 * Horizontal advanced-filter bar rendered above the queue table. It draws only the filters R4 lists as enabled, with
 * R4's chip values (limited to the user's scope); with none enabled it draws nothing at all. The filters sit behind an
 * "Advanced Filters" toggle that starts collapsed; hiding them never clears them, and the toggle shows how many are set.
 */
export function AdvancedFilterPanel({
  value,
  onChange,
  onSaveFilter,
  onSetDefault,
  options,
  onClearSaved,
  savedFilterBusy = false,
}: Props) {
  const { t } = usePaymentQueueTranslation();
  const { enabled } = options;
  const [open, setOpen] = useState(false);
  const bodyId = useId();
  if (enabled.size === 0) return null;

  const activeCount = activeFilterCount(value, enabled);

  return (
    <div className="pq-adv">
      <button
        type="button"
        className={cn('pq-adv-toggle', open && 'pq-adv-toggle-open')}
        aria-expanded={open}
        aria-controls={bodyId}
        aria-label={open ? t('FILTER.ADVANCED_HIDE') : t('FILTER.ADVANCED_SHOW')}
        onClick={() => setOpen((v) => !v)}
      >
        <SlidersHorizontal size={16} aria-hidden="true" />
        <span className="pq-adv-toggle-label">{t('FILTER.ADVANCED')}</span>
        {activeCount > 0 && <span className="pq-adv-toggle-count">{activeCount}</span>}
        <ChevronDown size={16} aria-hidden="true" className="pq-adv-toggle-chevron" />
      </button>

      {open && (
        <div className="pq-filter-panel" id={bodyId}>
          <div className="pq-filter-grid">
            {enabled.has('status') && (
              <SelectGroup<QueueStatus>
                title={t('FILTER.STATUS')}
                options={options.status}
                selected={value.status}
                onSelect={(v) => onChange({ ...value, status: v ? [v] : [] })}
              />
            )}
            {enabled.has('paymentType') && (
              <SelectGroup<PaymentTypeFilter>
                title={t('FILTER.PAYMENT_TYPE')}
                options={options.paymentType}
                optionLabel={(v) => t(PAYMENT_TYPE_KEY[v])}
                selected={value.paymentType}
                onSelect={(v) => onChange({ ...value, paymentType: v ? [v] : [] })}
              />
            )}
            {enabled.has('rail') && (
              <MultiSelectGroup<RailCode>
                title={t('FILTER.RAIL')}
                options={options.rail}
                selected={value.rail}
                onChange={(v) => onChange({ ...value, rail: v })}
              />
            )}
            {enabled.has('channel') && (
              <MultiSelectGroup<ChannelCode>
                title={t('FILTER.CHANNEL')}
                options={options.channel}
                selected={value.channel}
                onChange={(v) => onChange({ ...value, channel: v })}
              />
            )}
            {enabled.has('priority') && (
              <SelectGroup<PriorityLevel>
                title={t('FILTER.PRIORITY')}
                options={options.priority}
                optionLabel={(v) => t(PRIORITY_KEY[v])}
                selected={value.priority}
                onSelect={(v) => onChange({ ...value, priority: v ? [v] : [] })}
              />
            )}

            {enabled.has('amount') && (
              <div className="pq-filter-group">
                <div className="pq-filter-group-head">
                  <span className="input-label">{t('FILTER.AMOUNT')}</span>
                </div>
                <div className="pq-range-row">
                  <input
                    type="number"
                    min={0}
                    placeholder={t('FILTER.MIN')}
                    value={value.amountMin}
                    onChange={(e) => onChange({ ...value, amountMin: e.target.value })}
                    className="input-cls pq-range-input"
                    aria-label={t('FILTER.MIN_AMOUNT')}
                  />
                  <span className="pq-range-sep">—</span>
                  <input
                    type="number"
                    min={0}
                    placeholder={t('FILTER.MAX')}
                    value={value.amountMax}
                    onChange={(e) => onChange({ ...value, amountMax: e.target.value })}
                    className="input-cls pq-range-input"
                    aria-label={t('FILTER.MAX_AMOUNT')}
                  />
                </div>
              </div>
            )}

            {enabled.has('dateRange') && (
              <>
                <div className="pq-filter-group">
                  <div className="pq-filter-group-head">
                    <span className="input-label">{t('FILTER.START_DATE')}</span>
                  </div>
                  <div className="pq-range-row">
                    <input
                      type="date"
                      value={value.dateFrom}
                      onChange={(e) => onChange({ ...value, dateFrom: e.target.value })}
                      className="input-cls pq-range-input d-block"
                      aria-label={t('FILTER.DATE_FROM')}
                    />
                  </div>
                </div>

                <div className="pq-filter-group">
                  <div className="pq-filter-group-head">
                    <span className="input-label">{t('FILTER.END_DATE')}</span>
                  </div>
                  <div className="pq-range-row">
                    <input
                      type="date"
                      value={value.dateTo}
                      onChange={(e) => onChange({ ...value, dateTo: e.target.value })}
                      className="input-cls pq-range-input d-block"
                      aria-label={t('FILTER.DATE_TO')}
                    />
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="pq-filter-footer">
            <button type="button" onClick={() => onChange(EMPTY_FILTERS)} className="btn-tertiary h-38px">
              {t('FILTER.RESET')}
            </button>
            <div className="pq-filter-footer-actions">
              {onClearSaved && (
                <button type="button" onClick={onClearSaved} disabled={savedFilterBusy} className="btn-secondary h-38px">
                  {t('FILTER.CLEAR_SAVED')}
                </button>
              )}
              <button type="button" onClick={onSaveFilter} disabled={savedFilterBusy} className="btn-secondary h-38px">
                {t('FILTER.SAVE')}
              </button>
              <button type="button" onClick={onSetDefault} disabled={savedFilterBusy} className="btn-primary h-38px">
                {t('FILTER.SET_DEFAULT')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
