import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../../shared/api/bankingApi';
import { apiOk, renderWithProviders } from '../../../../test/renderWithProviders';
import { gridRowDto } from '../../../../test/paymentQueueFixtures';
import type { PaymentQueueGridRowDto } from '../api/paymentQueueApi';
import { PaymentQueueOutwardPage } from './PaymentQueueOutwardPage';

vi.mock('../../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

interface Answers {
  all?: PaymentQueueGridRowDto[];
  actionable?: PaymentQueueGridRowDto[];
  counts?: { all: number; actionable: number };
  allTotal?: number;
}

type Config = { params?: { tab?: string } } | undefined;

/** Answers R1 (by tab) and R2 the way the Operations API does. */
function serve({ all = [], actionable = [], counts, allTotal }: Answers) {
  get.mockImplementation(((url: string, config?: Config) => {
    if (url === '/ops/payment-queue/counts') {
      return Promise.resolve(apiOk(counts ?? { all: all.length, actionable: actionable.length }));
    }
    if (url === '/ops/payment-queue/items') {
      const isActionable = config?.params?.tab === 'actionable';
      const items = isActionable ? actionable : all;
      const totalCount = isActionable ? actionable.length : (allTotal ?? all.length);
      return Promise.resolve(apiOk({ items, page: 1, size: 100, totalCount }));
    }
    return Promise.reject(new Error(`unexpected call ${url}`));
  }) as never);
}

const ALPHA = gridRowDto({ queueEntryId: 'A', systemReference: 'WPS-2026-0001', debtorName: 'Alpha Corp' });
const BRAVO = gridRowDto({ queueEntryId: 'B', systemReference: 'IPI-2026-0002', debtorName: 'Bravo Ltd', rail: 'IPI' });

beforeEach(() => {
  get.mockReset();
});

describe('Payment Queue Outward: rows', () => {
  it('shows the R1 rows and nothing else, with the R2 counts on the two tabs', async () => {
    serve({ all: [ALPHA, BRAVO], actionable: [BRAVO], counts: { all: 2, actionable: 1 } });
    renderWithProviders(<PaymentQueueOutwardPage />);

    expect(await screen.findByText('WPS-2026-0001')).toBeInTheDocument();
    expect(screen.getByText('IPI-2026-0002')).toBeInTheDocument();
    expect(screen.getByText('Alpha Corp')).toBeInTheDocument();
    // Exactly the two R1 rows: a header row plus two body rows.
    expect(screen.getAllByRole('row')).toHaveLength(3);

    const tabs = screen.getAllByRole('tab');
    expect(tabs).toHaveLength(2);
    expect(within(tabs[0]).getByText('All Queues')).toBeInTheDocument();
    expect(within(tabs[0]).getByText('2')).toBeInTheDocument();
    expect(within(tabs[1]).getByText('Payment Queue')).toBeInTheDocument();
    expect(within(tabs[1]).getByText('1')).toBeInTheDocument();
    expect(screen.getByText('2 pending')).toBeInTheDocument();
  });

  it('reads R1 once per tab and R2 once, under /ops/payment-queue', async () => {
    serve({ all: [ALPHA], actionable: [] });
    renderWithProviders(<PaymentQueueOutwardPage />);
    await screen.findByText('WPS-2026-0001');

    const calls = get.mock.calls.map(([url, config]) => [url, (config as Config)?.params?.tab]);
    expect(calls).toEqual(
      expect.arrayContaining([
        ['/ops/payment-queue/items', 'all'],
        ['/ops/payment-queue/items', 'actionable'],
        ['/ops/payment-queue/counts', undefined],
      ]),
    );
    expect(get).toHaveBeenCalledTimes(3);
  });

  it('shows the Payment Queue tab as the actionable rows only', async () => {
    serve({ all: [ALPHA, BRAVO], actionable: [BRAVO] });
    renderWithProviders(<PaymentQueueOutwardPage />);
    await screen.findByText('WPS-2026-0001');

    await userEvent.click(screen.getByRole('tab', { name: /Payment Queue/ }));

    expect(screen.getByText('IPI-2026-0002')).toBeInTheDocument();
    expect(screen.queryByText('WPS-2026-0001')).not.toBeInTheDocument();
  });

  it('shows the grid empty state, not a mock row, for an empty queue', async () => {
    serve({ all: [], actionable: [], counts: { all: 0, actionable: 0 } });
    renderWithProviders(<PaymentQueueOutwardPage />);

    expect(await screen.findByText('No transactions match the current filters.')).toBeInTheDocument();
    expect(screen.getAllByRole('row')).toHaveLength(2);
  });

  it('says so when a tab has more rows than the page loaded', async () => {
    serve({ all: [ALPHA], actionable: [], counts: { all: 250, actionable: 0 }, allTotal: 250 });
    renderWithProviders(<PaymentQueueOutwardPage />);

    await screen.findByText('WPS-2026-0001');

    expect(screen.getByRole('status')).toHaveTextContent('Showing the first 100 records of each tab.');
  });

  it('shows no notice when every row is loaded', async () => {
    serve({ all: [ALPHA], actionable: [] });
    renderWithProviders(<PaymentQueueOutwardPage />);
    await screen.findByText('WPS-2026-0001');

    expect(screen.queryByRole('status')).not.toBeInTheDocument();
  });
});

describe('Payment Queue Outward: loading', () => {
  it('shows a loading indicator and no rows while the first answer is pending', () => {
    get.mockImplementation((() => new Promise(() => {})) as never);
    renderWithProviders(<PaymentQueueOutwardPage />);

    expect(screen.getByRole('status', { name: 'Loading payment queue' })).toBeInTheDocument();
    expect(screen.queryByRole('table')).not.toBeInTheDocument();
    expect(screen.queryByRole('alert')).not.toBeInTheDocument();
  });
});

describe('Payment Queue Outward: failure (AC-PMQ-083: no mock fallback)', () => {
  it('shows an error with Retry and no rows, no counts and no grid when the API fails', async () => {
    get.mockRejectedValue(new Error('Network Error'));
    renderWithProviders(<PaymentQueueOutwardPage />);

    const alert = await screen.findByRole('alert');
    expect(alert).toHaveTextContent('The payment queue could not be loaded.');
    expect(screen.getByRole('button', { name: 'Retry' })).toBeInTheDocument();
    expect(screen.queryByRole('table')).not.toBeInTheDocument();
    expect(screen.queryByRole('tab')).not.toBeInTheDocument();
    expect(screen.queryByText(/pending$/)).not.toBeInTheDocument();
  });

  it('shows the error when only R2 fails, rather than a grid with invented counts', async () => {
    get.mockImplementation(((url: string) =>
      url === '/ops/payment-queue/counts'
        ? Promise.reject(new Error('500'))
        : Promise.resolve(apiOk({ items: [ALPHA], page: 1, size: 100, totalCount: 1 }))) as never);
    renderWithProviders(<PaymentQueueOutwardPage />);

    expect(await screen.findByRole('alert')).toBeInTheDocument();
    expect(screen.queryByText('WPS-2026-0001')).not.toBeInTheDocument();
  });

  it('loads the rows when Retry succeeds', async () => {
    get.mockRejectedValue(new Error('Network Error'));
    renderWithProviders(<PaymentQueueOutwardPage />);
    await screen.findByRole('alert');

    serve({ all: [ALPHA], actionable: [] });
    await userEvent.click(screen.getByRole('button', { name: 'Retry' }));

    expect(await screen.findByText('WPS-2026-0001')).toBeInTheDocument();
    await waitFor(() => expect(screen.queryByRole('alert')).not.toBeInTheDocument());
  });
});
