import { Button, LoadingSpinner, PageBody, PageShell } from '@paymenthub/ui';
import { usePaymentQueue } from '../api/paymentQueueQueries';
import { usePaymentQueueTranslation } from '../i18n';
import { PaymentQueuePage } from '../PaymentQueuePage';

export function PaymentQueueOutwardPage() {
  const { t } = usePaymentQueueTranslation();
  const queue = usePaymentQueue();

  if (queue.isLoading) {
    return (
      <PageShell>
        <PageBody>
          <div className="flex h-64 items-center justify-center">
            <LoadingSpinner label={t('PAGE.LOADING')} />
          </div>
        </PageBody>
      </PageShell>
    );
  }

  // No fallback rows: a failed call shows the failure, never fabricated data (PMQ-P4-1, AC-PMQ-083).
  if (queue.isError) {
    return (
      <PageShell>
        <PageBody>
          <div role="alert" className="flex flex-col items-center gap-3 p-10 text-center text-sm text-[var(--text-2)]">
            <p>{t('PAGE.LOAD_FAILED')}</p>
            <Button type="button" variant="outline" size="sm" onClick={queue.refetch}>
              {t('COMMON.RETRY')}
            </Button>
          </div>
        </PageBody>
      </PageShell>
    );
  }

  // The rows are read by the page itself, one page at a time (server mode, PMQ-P7-4): this page only gates on the tab
  // badges, so a tab or filter change never replaces the screen with a spinner.
  return (
    <PaymentQueuePage
      direction="outward"
      title={t('PAGE.TITLE_OUTWARD')}
      tabCounts={queue.tabCounts}
      countsStale={queue.stale}
    />
  );
}
