import { useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Clock, X } from 'lucide-react';
import { cn } from '@paymenthub/ui';
import type { PaymentQueueRow, QueueAction } from './types';
import { PaymentTypeBadge } from './badges';
import { asUtcIso } from './api/paymentQueueApi';
import { usePaymentQueueActionHistory, usePaymentQueueHeader, usePaymentQueueWorkflow } from './api/paymentQueueQueries';
import { usePaymentQueuePopupLayout } from './api/popupLayoutApi';
import { formatDateTime, usePaymentQueueTranslation } from './i18n';
import { PaymentQueueActionFooter } from './PaymentQueueActionFooter';
import type { AppliedQueueAction } from './PaymentQueueActionFooter';
import { PaymentQueueActionHistory } from './PaymentQueueActionHistory';
import { PaymentQueueWorkflowPanel } from './PaymentQueueWorkflowPanel';
import { usePopupAdapterValues } from './popupAdapterValues';
import { withBadgeFields } from './popupBadges';
import { fmtElapsed, fmtMoney, NOT_AVAILABLE } from './popupFormat';
import { POPUP_SLOT } from './popupLayout';
import type { PopupContext, PopupLayout } from './popupLayout';
import { PopupLayoutRenderer } from './PopupLayoutRenderer';
import { mergePopupValues } from './popupValues';
import { buildQueuePopupValues } from './queuePopupValues';

interface Props {
  row: PaymentQueueRow;
  onClose: () => void;
  /** An action was applied by W1 (never called for a refused one). The drawer's owner closes it. */
  onAction: (action: QueueAction, comments: string, applied: AppliedQueueAction) => void;
  /**
   * The View drawer (All Queues tab, a View-only user): the footer is Close only, with no Remarks field and no
   * R10 call (AC-PMQ-081). The View & Action drawer leaves this off; R10 then decides which buttons it shows.
   */
  readOnly?: boolean;
}

/**
 * The View & Action popup. The header (R5), the Workflow tab (R8), Action History (R9) and the footer (R10) are the
 * queue's own; everything between the header and the footer is drawn from the item's R14 layout by
 * {@link PopupLayoutRenderer}, so this component names no rail and no field (design §8.0, AC-PMQ-093).
 *
 * <b>No layout (A-17, E23).</b> While R14 loads, when it fails, or when none is configured for the item's rail and
 * message type, the popup draws the queue's fallback layout: Workflow and Action History only, with a banner. The
 * footer is drawn in every case, so actions stay available.
 */
export function PaymentQueueDetailModal({ row, onClose, onAction, readOnly = false }: Props) {
  const { t, i18n } = usePaymentQueueTranslation();
  const fmtDateTime = (iso: string) => formatDateTime(iso, i18n.language);

  const headerQ = usePaymentQueueHeader(row.id);
  const workflowQ = usePaymentQueueWorkflow(row.id);
  const historyQ = usePaymentQueueActionHistory(row.id);
  const layoutQ = usePaymentQueuePopupLayout(row.id);
  const adapterValues = usePopupAdapterValues(row.id);
  const header = headerQ.data;

  const layoutState = layoutQ.data;
  const layout = layoutState?.kind === 'ready' ? layoutState.layout : null;
  const fallbackLayout = useMemo(
    () => queueFallbackLayout({ details: t('DRAWER.TAB_DETAILS'), history: t('DRAWER.SECTION_HISTORY'), workflow: t('DRAWER.TAB_WORKFLOW') }),
    [t],
  );

  // The item as `showWhen` reads it: the header's payment type once R5 answers, the row's before.
  const context: PopupContext = {
    paymentType: header ? (header.paymentType.trim().toLowerCase() === 'batch' ? 'Batch' : 'Single') : row.paymentType,
    subBatch: Boolean(header?.subBatchNo ?? row.subBatchNo),
  };
  // Adapter values come from PMQ-P7-3's routes; the queue's own codes (`queue.*`) are built from the header and the row.
  const values = mergePopupValues(withBadgeFields(adapterValues), buildQueuePopupValues(row, header, t));

  // R5's own values only: a null Corporate or Amount is "—", never a blank or a zero (AC-PMQ-077); while R5 loads,
  // nothing stands in for them.
  const pendingHeader = headerQ.isLoading ? t('DRAWER.LOADING') : NOT_AVAILABLE;
  const headerTitle = header ? header.corporate?.trim() || NOT_AVAILABLE : pendingHeader;
  const headerAmount = header
    ? header.amount == null
      ? NOT_AVAILABLE
      : fmtMoney(header.amount, header.currency)
    : pendingHeader;

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div className="pq-drawer-overlay" role="dialog" aria-modal="true" aria-label={t('DRAWER.ARIA')} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="pq-drawer-panel" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="pq-modal-header">
          <div className="pq-modal-header-main">
            <p className="pq-modal-refno">{header?.systemReference ?? row.systemReferenceNo}</p>
            <h2 className="pq-modal-title">{headerTitle}</h2>
            <p className="pq-modal-subline">
              {header?.channel ?? row.channel} · {header?.rail ?? row.rail} · {fmtDateTime(header ? asUtcIso(header.submittedAt) : row.submittedDate)}
            </p>
            <div className="pq-modal-meta-row">
              <PaymentTypeBadge type={context.paymentType === 'Batch' ? 'Batch' : 'Single'} />
              <span className="pq-modal-amount">{headerAmount}</span>
              <span className={cn('pq-modal-elapsed', header?.isPastSla && 'pq-modal-elapsed-late')}>
                <Clock size={12} /> {t('DRAWER.ELAPSED', { value: header ? fmtElapsed(t, header.elapsedSeconds) : NOT_AVAILABLE })}
              </span>
            </div>
            {header && !header.railDataAvailable && (
              <p role="status" className="pq-header-banner">
                {t('DRAWER.RAIL_UNAVAILABLE', { placeholder: NOT_AVAILABLE })}
              </p>
            )}
            {headerQ.isError && (
              <p role="alert" className="pq-header-banner">
                {t('DRAWER.HEADER_FAILED')}
              </p>
            )}
            {/* R6 failed or could not read the rail (PMQ-P7-3). Not repeated when R5 already said the rail is unavailable. */}
            {adapterValues.unavailable && header?.railDataAvailable !== false && (
              <p role="status" className="pq-header-banner">
                {t('DRAWER.VALUES_UNAVAILABLE', { placeholder: NOT_AVAILABLE })}
              </p>
            )}
            <LayoutBanner loading={layoutQ.isLoading} failed={layoutQ.isError} kind={layoutState?.kind} />
          </div>
          <button type="button" onClick={onClose} aria-label={t('DRAWER.CLOSE_ARIA')} className="pq-modal-close">
            <X size={18} />
          </button>
        </div>

        {/* Tabs and body: the layout's, or the queue's fallback when there is none */}
        <PopupLayoutRenderer
          layout={layout ?? fallbackLayout}
          context={context}
          values={values}
          slots={{
            workflow: <PaymentQueueWorkflowPanel query={workflowQ} />,
            actionHistory: <PaymentQueueActionHistory query={historyQ} />,
          }}
        />

        {/* Footer: R10's buttons, or Close only (design §8.10) */}
        <PaymentQueueActionFooter row={row} readOnly={readOnly} onClose={onClose} onApplied={onAction} />
      </div>
    </div>,
    document.body,
  );
}

/**
 * The note about the layout: loading, could not be read, or none configured (A-17). Nothing when the layout is drawn.
 * "Not configured" is a status, not an error: the popup still has its header, Workflow, Action History and actions.
 */
function LayoutBanner({ loading, failed, kind }: { loading: boolean; failed: boolean; kind: 'ready' | 'notConfigured' | 'unsupported' | undefined }) {
  const { t } = usePaymentQueueTranslation();
  if (loading) {
    return (
      <p role="status" className="pq-header-banner">
        {t('DRAWER.LOADING')}
      </p>
    );
  }
  if (failed || kind === 'unsupported') {
    return (
      <p role="alert" className="pq-header-banner">
        {t('DRAWER.LAYOUT_FAILED')}
      </p>
    );
  }
  if (kind === 'notConfigured') {
    return (
      <p role="status" className="pq-header-banner">
        {t('DRAWER.LAYOUT_NOT_CONFIGURED')}
      </p>
    );
  }
  return null;
}

/**
 * What the popup draws when there is no layout (A-17): a details tab holding only the Action History, and the Workflow
 * tab. Both are queue-placed slots, so this names no rail and no field.
 */
function queueFallbackLayout(labels: { details: string; history: string; workflow: string }): PopupLayout {
  return {
    tabs: [
      {
        tabCode: 'details',
        label: labels.details,
        order: 1,
        sections: [
          {
            sectionCode: 'actionHistory',
            label: labels.history,
            order: 1,
            expandable: false,
            slot: POPUP_SLOT.actionHistory,
            fields: [],
            grids: [],
          },
        ],
      },
      { tabCode: 'workflow', label: labels.workflow, order: 2, slot: POPUP_SLOT.workflow, sections: [] },
    ],
    footerSlot: 'actions',
  };
}
