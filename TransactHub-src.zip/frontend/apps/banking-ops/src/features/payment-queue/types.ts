// ─── Payment Queue (Outward / Inbound) ─────────────────────────────────────────
// UI model for the Payment Queue screens. These queues surface payments awaiting a
// maker/checker action before they can continue through the rail. The grid rows and
// the tab counts come from the Operations API (`api/paymentQueueApi.ts`, routes R1 and
// R2 of the Payment Queue – Outbound design §7); there is no static or mock data.

export type QueueDirection = 'outward' | 'inbound';

/** Two tabs, one badge each (B-14, N-19, BA AC-15): All Queues, and the Payment Queue. */
export type QueueTabKey = 'all' | 'payment';

/**
 * The Queue Status labels the server sends by default (R1 `queueStatus`, BA AC-24): "Pending Approval" on an
 * approval level, "Pending Action" on a channel file's Level 1, and the "Held" and "Returned" states. There is
 * no "Escalated", "Pending Maker" or "Pending Checker".
 */
export const QUEUE_STATUS_LABELS = ['Pending Approval', 'Pending Action', 'Held', 'Returned'] as const;

export type KnownQueueStatus = (typeof QUEUE_STATUS_LABELS)[number];

/**
 * Queue Status: the server's label for the current state (R1 `queueStatus`). A bank configuration can rename a
 * level's label later (design OD-11), so the type stays `string`; {@link QUEUE_STATUS_LABELS} are the defaults the
 * badge tones and the filter options know.
 */
export type QueueStatus = string;

export type PaymentTypeFilter = 'Batch' | 'Single';

/** The rail code as the server sends it (R1 `rail`); the set is configuration, not a UI enumeration. */
export type RailCode = string;

/** The channel as the server shows it (R1 `channel`, with `-Repair` appended on a repair re-submission). */
export type ChannelCode = string;

export type PriorityLevel = 'Urgent' | 'High' | 'Normal';

/** The message type code as the server sends it (R1 `messageType`). */
export type MessageType = string;

/** One row in the "Posting Details" ledger shown inside the charge breakdown. */
export interface PostingLine {
  postingType: string;
  debitAccount: string;
  debitLabel: string;
  creditAccount: string;
  creditLabel: string;
  currency: string;
  amount: number;
}

/**
 * How a stepper level is drawn: `held` (amber circle, glow ring) and `returned` (orange circle, glow ring) are the
 * current level of an On Hold or Returned item (BA AC-58, design §8.8).
 */
export type WorkflowStepStatus = 'completed' | 'active' | 'held' | 'returned' | 'pending';

/**
 * Where a stepper step comes from: `queue` is a level of the pinned stage set; `workflow` is a completed workflow step
 * merged in from the transaction's timeline (design §8.8); `action` is something a user did on a Parallel item (an
 * approval, the hold, the return), which has no ordered levels to list. The screen tells them apart by this, not by guessing.
 */
export type WorkflowStepSource = 'queue' | 'workflow' | 'action';

/**
 * One step in the "Workflow" tab's vertical progress tracker, mapped from an R8 level. It carries the facts, not the
 * sentence: the stepper builds its label and description in the reader's language (PMQ-P4-7).
 */
export interface WorkflowStep {
  level: number;
  /** `queue` for a level of the stage set, `workflow` for a completed workflow step (its `level` is 0). */
  source: WorkflowStepSource;
  /** A workflow step's stored name exactly as the server sent it (its step id when the name is empty); never translated. */
  stepName?: string;
  /** The level's role name as the server sent it, or its stage code when it sent none. */
  roleLabel: string;
  status: WorkflowStepStatus;
  /** Who completed the level, or whom the item was returned to (the server's name or login). */
  actor?: string;
  /** UTC: when the level completed, or when the current state began. */
  at?: string;
  /** The role the active level waits on. */
  awaitingRole?: string;
  /** The server's badge on the current level: "On Hold", or "Returned to <role>". Absent on every other level. */
  badge?: string;
  /** The causing action's remarks on the current level (`StateNote`). */
  note?: string;
  /** A Parallel approval's place among the approvals so far: a count, not a level. */
  approvalNo?: number;
  /** The approvals the item needs in all, beside `approvalNo`. */
  approvalsRequired?: number;
}

/** A per-component charge (e.g. "Own Customer Charge") that hit a configured floor/ceiling. */
export interface ChargeCapNote {
  capType: 'Min' | 'Max';
  /** The raw computed amount before the cap was applied. */
  calculatedAmount: number;
  /** The amount actually charged, after the cap. */
  appliedAmount: number;
}

/** One row of the "More Details" charge calculation breakdown. */
export interface ChargeLineItem {
  label: string;
  amount: number;
  cap?: ChargeCapNote;
}

export interface ChargeBreakdown {
  source: 'Global' | 'Custom';
  totalCharge: number;
  vat: number;
  vatPercent: number;
  /** Present when the computed charge exceeded the bank's configured ceiling. */
  maxChargeApplied?: { calculated: number; cappedAt: number };
  /** Own Customer / Other Bank / Per Card / Per File / CB File / VAT — the "More Details" ledger. */
  lineItems: ChargeLineItem[];
}

/**
 * One grid row, mapped from the R1 grid-row DTO by `toPaymentQueueRow` (`api/paymentQueueApi.ts`). The
 * account numbers arrive already masked by the server (design §9.4, I-6); nothing here unmasks them.
 */
export interface PaymentQueueRow {
  /** R1 `queueEntryId`: the row key, and the id every per-item route takes. */
  id: string;
  /** R1 `currentStateId`: the `expectedStateId` a W1 or W2 action names (PMQ-P4-3, P4-5). */
  currentStateId: number;
  /** R1 `stateCode`: `PENDING`, `HELD` or `RETURNED`. */
  stateCode: string;
  /** R1 `stageSeq`: the level the current state waits at. */
  stageSeq: number | null;
  /** R1 `subBatchNo`. */
  subBatchNo: string | null;
  systemReferenceNo: string;
  debtorName: string;
  debtorAccount: string;
  creditorName: string;
  creditorAccount: string;
  creditorBank: string;
  channel: ChannelCode;
  /** R1 `isRepairResubmission`; `channel` already carries the `-Repair` suffix. */
  isRepairResubmission: boolean;
  paymentType: PaymentTypeFilter;
  rail: RailCode;
  amount: number;
  currency: string;
  /** ISO 8601 UTC. */
  transactionDate: string;
  messageType: MessageType;
  /** The server's name; empty for a submission by the system, which the screen words itself (R1: null shows System). */
  submittedBy: string;
  /** ISO 8601 UTC; the start of Elapsed Time. */
  submittedDate: string;
  queueStatus: QueueStatus;
  priority: PriorityLevel;
  /** True when the row is on the Payment Queue tab (R1 `tab=actionable`); every row is on All Queues. */
  isActionable: boolean;
  /**
   * Drawer content that neither R1 nor the Phase 1 R5 (header only) carries. Absent until the Phase 3 popup layout
   * feeds it; the drawer shows only what is present and never invents the rest. The Workflow tab reads R8 and the
   * header reads R5, so neither is a field of the row.
   */
  charge?: ChargeBreakdown;
  postings?: PostingLine[];
}

/** One tab badge: the R2 count for the tab. */
export interface QueueTabCount {
  key: QueueTabKey;
  total: number;
}

/**
 * The code of an action taken from the View & Action drawer footer: one of R10's offered `action` values
 * (`APPROVE`, `REJECT`, …), never computed by the screen (I-10). There is no Escalate.
 */
export type QueueAction = string;
