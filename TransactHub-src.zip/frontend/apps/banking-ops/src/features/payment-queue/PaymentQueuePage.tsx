import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Check, Eraser, X } from 'lucide-react';
import { Button, cn, PageBody, PageShell, SmartGrid, usePermissionMode } from '@paymenthub/ui';
import type { SmartGridQueryChange } from '@paymenthub/ui';
import { PERM } from '../../shared/auth/permissionKeys';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { AdvancedFilterPanel, EMPTY_FILTERS } from './AdvancedFilterPanel';
import type { AdvancedFilterState } from './AdvancedFilterPanel';
import { PaymentQueueAuditTrail } from './PaymentQueueAuditTrail';
import { BulkActionDialog } from './BulkActionDialog';
import type { BulkAction } from './BulkActionDialog';
import { BULK_MAX_RECORDS, isPaymentQueueSortColumn, paymentQueueProblem } from './api/paymentQueueApi';
import type { PaymentQueueGridParams } from './api/paymentQueueApi';
import { ExportTooLargeError, EXPORT_MAX_ROWS, loadAllGridRows } from './api/loadAllGridRows';
import { usePaymentQueueFilterOptions, usePaymentQueueGrid } from './api/paymentQueueQueries';
import { useUnmaskSession } from './api/useUnmaskSession';
import { usePaymentQueuePreferenceCommands, usePaymentQueuePreferences } from './api/usePaymentQueuePreferences';
import { createColumnLayoutPreferences } from './api/columnLayoutPreferences';
import { fromSavedFilterDto, toSavedFilterDto } from './savedFilter';
import type { BulkActOnPaymentQueueItemsResultDto } from './api/paymentQueueApi';
import { PaymentQueueDetailModal } from './PaymentQueueDetailModal';
import type { AppliedQueueAction } from './PaymentQueueActionFooter';
import { buildColumns } from './paymentQueueColumns';
import type { PaymentQueueGridView } from './paymentQueueColumns';
import { mergeColumnFilters } from './columnFilters';
import { FALLBACK_PANEL_OPTIONS, toGridFilters, toPanelOptions } from './filterOptions';
import {
  actionAppliedToast,
  bulkActionLabel,
  bulkResultToast,
  columnLayoutSaveFailedToast,
  defaultFilterToast,
  exportFailedToast,
  exportTooLargeToast,
  filterClearedToast,
  filterClearFailedToast,
  filterSavedToast,
  filterSaveFailedToast,
  selectionCapToast,
} from './paymentQueueToasts';
import { usePaymentQueueTranslation } from './i18n';
import type { PaymentQueueT } from './i18n';
import { useBulkSelection } from './useBulkSelection';
import type { PaymentQueueRow, QueueAction, QueueDirection, QueueTabCount, QueueTabKey } from './types';

/** The first option is the grid's default page size (20, as the screen has always opened with). */
const PAGE_SIZE_OPTIONS = [20, 10, 50];

/** With no sort chosen the screen shows the newest transactions first, as it always has. */
const DEFAULT_SORT = 'transactionDate';

/** What a bulk selection needs in common (design §6.5): the server refuses a mix with 422, so the bar is disabled for one. */
function selectionMismatch(selected: PaymentQueueRow[]): boolean {
  const distinct = (pick: (r: PaymentQueueRow) => string) => new Set(selected.map(pick)).size > 1;
  return distinct((r) => r.rail) || distinct((r) => r.messageType) || distinct((r) => r.paymentType);
}

/** The tab names are the screen's own words, by tab key. */
const TAB_KEY: Record<QueueTabKey, string> = {
  all: 'TABS.ALL',
  payment: 'TABS.PAYMENT',
};

const NO_ROWS: PaymentQueueRow[] = [];

/** Two column-filter records say the same thing when their non-blank entries match (a cleared box leaves a blank). */
function sameFilters(a: Record<string, string>, b: Record<string, string>): boolean {
  const entries = (f: Record<string, string>) =>
    Object.entries(f)
      .filter(([, v]) => v.trim())
      .sort(([x], [y]) => x.localeCompare(y));
  return JSON.stringify(entries(a)) === JSON.stringify(entries(b));
}

/** The grid's own state in server mode: where it is, and how the server is asked to order it. */
interface GridQuery {
  page: number;
  pageSize: number;
  sortBy: string | null;
  sortDir: 'asc' | 'desc';
}

interface Props {
  direction: QueueDirection;
  title: string;
  tabCounts: QueueTabCount[];
  /** The tab badges' newest refresh failed: the counts shown are from the last successful load. */
  countsStale?: boolean;
}

export function PaymentQueuePage({ direction, title, tabCounts, countsStale = false }: Props) {
  const navigate = useNavigate();
  const { t, i18n } = usePaymentQueueTranslation();

  const [activeTab, setActiveTab] = useState<QueueTabKey>('all');
  const [filters, setFilters] = useState<AdvancedFilterState>(EMPTY_FILTERS);
  // The grid's inline column filters (the Filters toggle): session-only, never saved (R-16), applied on top of `filters`.
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [query, setQuery] = useState<GridQuery>({ page: 1, pageSize: PAGE_SIZE_OPTIONS[0], sortBy: null, sortDir: 'asc' });
  const [detailRow, setDetailRow] = useState<PaymentQueueRow | null>(null);
  const [auditRow, setAuditRow] = useState<PaymentQueueRow | null>(null);
  const [bulk, setBulk] = useState<{ action: BulkAction; rows: PaymentQueueRow[] } | null>(null);
  // Key 117 (Z2): View & Action and the bulk bar. Until the permission snapshot loads this reads false, so a user
  // briefly sees View alone, never an action they cannot take.
  const canAct = usePermissionMode(PERM.paymentQueueAct).granted;
  const [toast, setToast] = useState<ToastState | null>(null);
  // Key 24: the Unmask PII control. The server masks every account number and sends it in full only to a holder of the
  // key with an open session, so this screen only shows the control and what the server sends (PMQ-P4-6). The grid
  // draws the control; this hook's result is the grid's `pii` state as it is.
  const canUnmask = usePermissionMode(PERM.unmaskAccountNumber).granted;
  const unmask = useUnmaskSession({ canUnmask, notify: setToast });

  // R4: which filters show and their chip values, limited to the user's scope. Until it answers, or if it cannot, the
  // panel shows every filter on its fixed lists; the filters apply on the server either way.
  const filterOptionsQuery = usePaymentQueueFilterOptions();
  const panelOptions = useMemo(
    () => (filterOptionsQuery.data ? toPanelOptions(filterOptionsQuery.data) : FALLBACK_PANEL_OPTIONS),
    [filterOptionsQuery.data],
  );

  // P1 (PMQ-P7-5, design §9.2): the user's one saved filter is the filter the screen opens with. It is applied to the
  // panel once, before the first R1 call: R1 waits until P1 has answered (or failed: then nothing is applied) and, when
  // there is a saved filter, until R4 has too, so a filter the tenant has turned off, or a value the panel no longer
  // offers, is dropped rather than applied unseen. The selection is empty at this point, so nothing else changes.
  const preferences = usePaymentQueuePreferences();
  const preferenceCommands = usePaymentQueuePreferenceCommands();
  const savedFilter = preferences.data?.savedFilter ?? null;
  const startupSettled = !preferences.isPending && (savedFilter === null || !filterOptionsQuery.isPending);
  const [startupApplied, setStartupApplied] = useState(false);
  // A filter the user picks before the saved one could be applied wins: the saved filter never overwrites a choice.
  const filtersTouched = useRef(false);
  useEffect(() => {
    if (startupApplied || !startupSettled) return;
    if (savedFilter && !filtersTouched.current) setFilters(fromSavedFilterDto(savedFilter, panelOptions));
    setStartupApplied(true);
  }, [startupApplied, startupSettled, savedFilter, panelOptions]);

  // R1 (PMQ-P7-4): the tab, page, size, sort and filters of the moment. The server filters, sorts and pages; this page
  // holds one page of rows and the total.
  // The left panel and the column filters both narrow, so a row must pass both. When they cannot both hold (no value in
  // common, a minimum above a maximum) no row matches and R1 is not asked: the grid shows no rows.
  const merged = useMemo(
    () => mergeColumnFilters(toGridFilters(filters, panelOptions.enabled), columnFilters),
    [filters, columnFilters, panelOptions.enabled],
  );
  const gridParams = useMemo<PaymentQueueGridParams>(() => {
    const { sortBy, sortDir } = query;
    const sort = isPaymentQueueSortColumn(sortBy) ? sortBy : undefined;
    return {
      tab: activeTab === 'payment' ? 'actionable' : 'all',
      page: query.page,
      size: query.pageSize,
      sort: sort ?? DEFAULT_SORT,
      sortDirection: sort ? sortDir : 'desc',
      filters: merged.filters,
    };
  }, [activeTab, query, merged.filters]);
  const grid = usePaymentQueueGrid(gridParams, startupApplied && !merged.none);
  const gridRows = merged.none ? NO_ROWS : grid.rows;
  const total = merged.none ? 0 : (grid.totalCount ?? 0);

  // A refresh can leave fewer pages than the current page (a bulk action on the last page): show the last page.
  const lastPage = Math.max(1, Math.ceil(total / query.pageSize));
  useEffect(() => {
    if (!merged.none && grid.totalCount !== undefined && query.page > lastPage) setQuery((q) => ({ ...q, page: lastPage }));
  }, [merged.none, grid.totalCount, query.page, lastPage]);

  // The bulk selection keeps a snapshot of each ticked row (see `useBulkSelection`): the other pages are not loaded.
  const selection = useBulkSelection({
    pageRows: gridRows,
    max: BULK_MAX_RECORDS,
    onCapReached: () => setToast(selectionCapToast(t, BULK_MAX_RECORDS)),
  });
  const { selectedRows } = selection;

  // Read by the row buttons at render time: SmartGrid never re-reads its column definitions after the first mount.
  const gridView = useRef<PaymentQueueGridView>({
    activeTab,
    canAct,
    onView: setDetailRow,
    onAuditTrail: setAuditRow,
  });
  gridView.current.activeTab = activeTab;
  gridView.current.canAct = canAct;

  // Built once per language and per R4 answer (the grid is keyed by both below), because the grid snapshots the
  // definitions: the column filters offer R4's values and exist only for the filters the tenant has on.
  const columns = useMemo(() => buildColumns(gridView, t, i18n.language, panelOptions), [t, i18n.language, panelOptions]);

  // P1 / P4 (PMQ-P7-5, §9.5): the column layout on the server, in place of the grid's localStorage default. SmartGrid
  // reads `load` once, when it mounts, so the adapter is built once before startup (the grid's defaults) and once after
  // (P1's layout), and the grid is keyed on that below. A failed P4 keeps the choice for this session and says so.
  const latestT = useRef<PaymentQueueT>(t);
  latestT.current = t;
  const saveColumnLayout = useRef(preferenceCommands.saveColumnLayout);
  saveColumnLayout.current = preferenceCommands.saveColumnLayout;
  const startupLayout = startupApplied ? (preferences.data?.columnLayout ?? null) : null;
  const startupLayoutRef = useRef(startupLayout);
  startupLayoutRef.current = startupLayout;
  const columnPreferences = useMemo(
    () =>
      createColumnLayoutPreferences({
        initial: startupApplied ? startupLayoutRef.current : null,
        save: (layout) => saveColumnLayout.current(layout),
        onSaveFailed: () => setToast(columnLayoutSaveFailedToast(latestT.current)),
      }),
    [startupApplied],
  );

  // The grid remounts when the language, the startup state or R4's answer changes, which empties its own column
  // filters; the filters held here are dropped with them so the two never disagree.
  const gridKey = `${i18n.language}-${startupApplied ? 'ready' : 'opening'}-${filterOptionsQuery.isPending ? 'options' : 'scoped'}`;
  useEffect(() => {
    setColumnFilters((current) => (Object.keys(current).length > 0 ? {} : current));
  }, [gridKey]);

  function switchTab(tab: QueueTabKey) {
    setActiveTab(tab);
    setQuery((q) => ({ ...q, page: 1 }));
    selection.clear();
  }

  function updateFilters(next: AdvancedFilterState) {
    filtersTouched.current = true;
    setFilters(next);
    setQuery((q) => ({ ...q, page: 1 }));
    // A filter can hide selected rows; a bulk action must never reach a row the user cannot see.
    selection.clear();
  }

  // The grid reports a page, size, sort or column-filter change. A sort, size or filter change returns to page 1 (the
  // grid says so itself). A column filter can hide ticked rows, and a bulk action must never reach a row the user cannot
  // see, so a changed filter clears the selection (as the left panel does); a Search that changes nothing does not.
  function handleQueryChange(change: SmartGridQueryChange) {
    const next = change.filters;
    if (next !== undefined && !sameFilters(next, columnFilters)) {
      setColumnFilters(next);
      selection.clear();
    }
    setQuery((prev) => ({
      page: change.page ?? prev.page,
      pageSize: change.pageSize ?? prev.pageSize,
      sortBy: change.sortBy !== undefined ? change.sortBy : prev.sortBy,
      sortDir: change.sortDir ?? prev.sortDir,
    }));
  }

  // The toolbar's Clear (the grid clears its own sort, page and column filters first): back to All Queues, no filters,
  // no selection.
  function clearAll() {
    filtersTouched.current = true;
    setFilters(EMPTY_FILTERS);
    setColumnFilters({});
    selection.clear();
    setActiveTab('all');
  }

  // P2 (PMQ-P7-5): Save Filter and Set Default both save the panel's filter as the one saved filter, which is the
  // default the screen opens with (Q-16: one saved filter, no separate default). Only the enabled filters' values are
  // sent, and never a grid column filter (R-16). The toast says what each button promises.
  async function saveFilter(successToast: (t: PaymentQueueT) => ToastState) {
    try {
      await preferenceCommands.saveFilter(toSavedFilterDto(filters, panelOptions.enabled));
      setToast(successToast(t));
    } catch (error) {
      setToast(filterSaveFailedToast(t, paymentQueueProblem(error).detail));
    }
  }

  // P3 (PMQ-P7-5, Q-16, BR-007): Clear removes the saved filter and puts the panel back to no filter, as Reset does
  // (so the selection clears, as on any filter change). On failure nothing changes on screen.
  async function clearSavedFilter() {
    try {
      await preferenceCommands.clearFilter();
      updateFilters(EMPTY_FILTERS);
      setToast(filterClearedToast(t));
    } catch (error) {
      setToast(filterClearFailedToast(t, paymentQueueProblem(error).detail));
    }
  }

  // The grid's CSV is of every row the filters leave, in the on-screen order: read page by page through R1, bounded.
  async function loadAllRows(): Promise<PaymentQueueRow[]> {
    if (merged.none) return [];
    try {
      return await loadAllGridRows(gridParams);
    } catch (error) {
      setToast(error instanceof ExportTooLargeError ? exportTooLargeToast(t, EXPORT_MAX_ROWS) : exportFailedToast(t));
      throw error;
    }
  }

  // The drawer posts W1 itself and calls this only once the server answered 200. The grid reloads on its own (the
  // mutation invalidates every Payment Queue read); the toast names the action and the payment from W1's answer.
  function handleAction(action: QueueAction, _comments: string, applied: AppliedQueueAction) {
    if (detailRow) {
      setToast(
        actionAppliedToast(t, {
          reference: detailRow.systemReferenceNo,
          chosenAction: action,
          chosenLabel: applied.label,
          result: applied.result,
        }),
      );
    }
    setDetailRow(null);
  }

  /** Closes the confirmation: an applied record leaves the selection, one that was not applied stays ticked. */
  function closeBulk(result?: BulkActOnPaymentQueueItemsResultDto) {
    const closing = bulk;
    setBulk(null);
    if (!result) return;
    if (closing) setToast(bulkResultToast(t, closing.action, result));
    selection.removeApplied(new Set(result.results.filter((r) => r.status === 'applied').map((r) => r.queueEntryId)));
  }

  // Why the bar is off, in the order a user can fix it: permission, then the Payment Queue tab, then a uniform selection.
  // It reads the snapshots, so it holds across pages: a selection that spans pages is judged as a whole.
  const bulkBlockedReason = !canAct
    ? t('BULK_BAR.NO_PERMISSION')
    : selectedRows.some((r) => !r.isActionable)
      ? t('BULK_BAR.ACTIONABLE_ONLY')
      : selectionMismatch(selectedRows)
        ? t('BULK_BAR.MISMATCH')
        : null;

  const pendingCount = tabCounts.find((tab) => tab.key === 'all')?.total ?? total;
  const stale = countsStale || grid.stale;

  return (
    <PageShell>
      <PageBody>
        <div className="pq-page pe-2">
          {/* Breadcrumbs */}
          <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
            <button onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">
              {t('PAGE.BREADCRUMB_ROOT')}
            </button>
            {' › '}
            <span aria-current="page">{t('PAGE.BREADCRUMB')}</span>
          </p>

          {/* Title header */}
          <div className="pq-header">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">{title}</h1>
              <p className="pq-header-subtitle">{t('PAGE.SUBTITLE')}</p>
            </div>
            <div className="pq-header-meta">
              <span className="pq-live-badge">
                <span className="live-badge">
                  <span className="dot" />
                  <span className="label">{t('PAGE.LIVE')}</span>
                </span>

              </span>
              <span className="pq-pending-badge">{t('PAGE.PENDING_COUNT', { total: pendingCount.toLocaleString() })}</span>
            </div>
          </div>

          {(stale || filterOptionsQuery.isError || preferences.isError) && (
            <div role="status" className="mb-2 text-xs text-[var(--text-muted)]">
              {stale && <p>{t('PAGE.NOTICE_STALE')}</p>}
              {filterOptionsQuery.isError && <p>{t('FILTER.OPTIONS_UNAVAILABLE')}</p>}
              {preferences.isError && <p>{t('PAGE.PREFERENCES_UNAVAILABLE')}</p>}
            </div>
          )}

          {/* Queue tabs */}
          <div className="pq-tabs" role="tablist" aria-label={t('PAGE.TABS_LABEL')}>
            {tabCounts.map((tab) => (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={activeTab === tab.key}
                onClick={() => switchTab(tab.key)}
                className={cn('pq-tab', activeTab === tab.key && 'pq-tab-active')}
              >
                <span className="pq-tab-label">{t(TAB_KEY[tab.key])}</span>
                <span className="pq-tab-count">{tab.total}</span>
              </button>
            ))}
          </div>

          {/* Advanced filters — placed horizontally above the table, and above the toolbar */}
          <AdvancedFilterPanel
            value={filters}
            onChange={updateFilters}
            onSaveFilter={() => void saveFilter(filterSavedToast)}
            onSetDefault={() => void saveFilter(defaultFilterToast)}
            onClearSaved={() => void clearSavedFilter()}
            savedFilterBusy={preferenceCommands.savedFilterBusy}
            options={panelOptions}
          />

          {grid.isError ? (
            <div role="alert" className="flex flex-col items-center gap-3 p-10 text-center text-sm text-[var(--text-2)]">
              <p>{t('PAGE.LOAD_FAILED')}</p>
              <Button type="button" variant="outline" size="sm" onClick={grid.refetch}>
                {t('COMMON.RETRY')}
              </Button>
            </div>
          ) : (
            /*
              The grid (PMQ-P7-4), in server mode: R1 filters, sorts and pages, and the grid holds one page. The Filters
              toggle opens the inline column filters; the columns R1 can filter carry one, and the grid reports each
              change through `onQueryChange`, which this page sends to R1 on top of the left panel's filters (and clears
              the selection on, so a bulk action never reaches a row the user cannot see).
              The grid's header checkbox ticks the current page only; the selection spans pages through its snapshots.
              Export offers CSV, Excel and PDF of every row the filters leave (`loadAllRows`, R1 pages, bounded).
            */
            <SmartGrid<PaymentQueueRow>
              key={gridKey}
              columns={columns}
              rows={gridRows}
              loading={grid.isLoading || !startupApplied}
              getRowId={(r) => r.id}
              storageKey={`payment-queue-${direction}-columns-v1`}
              preferences={columnPreferences}
              pageSizeOptions={PAGE_SIZE_OPTIONS}
              emptyTitle={t('PAGE.EMPTY')}
              emptyMessage=""
              exportFormats={['csv', 'excel', 'pdf']}
              exportFilename={`payment-queue-${direction}`}
              loadAllRows={loadAllRows}
              onClear={clearAll}
              pii={unmask}
              server={{
                page: query.page,
                pageSize: query.pageSize,
                total,
                sortBy: query.sortBy,
                sortDir: query.sortDir,
                onQueryChange: handleQueryChange,
              }}
              selectable
              selectedIds={selection.selectedIds}
              onToggleSelect={selection.toggle}
              toolbarStart={
                selectedRows.length > 0 ? (
                  <div className="pq-selection-bar">
                    <span className="pq-selection-count">{t('BULK_BAR.SELECTED', { total: selectedRows.length })}</span>
                    <span className="pq-selection-sep" />
                    <button
                      type="button"
                      disabled={bulkBlockedReason !== null}
                      onClick={() => setBulk({ action: 'Approve', rows: selectedRows })}
                      className="pq-selection-btn pq-selection-btn-approve"
                    >
                      <Check size={14} /> {bulkActionLabel(t, 'Approve')}
                    </button>
                    <button
                      type="button"
                      disabled={bulkBlockedReason !== null}
                      onClick={() => setBulk({ action: 'Reject', rows: selectedRows })}
                      className="pq-selection-btn pq-selection-btn-reject"
                    >
                      <X size={14} /> {bulkActionLabel(t, 'Reject')}
                    </button>
                    <button
                      type="button"
                      disabled={bulkBlockedReason !== null}
                      onClick={() => setBulk({ action: 'Reassign', rows: selectedRows })}
                      className="pq-selection-btn"
                    >
                      <ArrowRight size={14} className="rtl:rotate-180" /> {bulkActionLabel(t, 'Reassign')}
                    </button>
                    {/* Clear drops the selection only; it is never blocked, so a blocked selection can always be undone. */}
                    <button type="button" onClick={selection.clear} className="pq-selection-btn">
                      <Eraser size={14} /> {t('BULK_BAR.CLEAR')}
                    </button>
                    {bulkBlockedReason && (
                      <span role="note" className="text-xs text-[var(--text-muted)]">
                        {bulkBlockedReason}
                      </span>
                    )}
                  </div>
                ) : undefined
              }
            />
          )}
        </div>
      </PageBody>

      {detailRow && (
        <PaymentQueueDetailModal
          row={detailRow}
          readOnly={!(activeTab === 'payment' && canAct)}
          onClose={() => setDetailRow(null)}
          onAction={handleAction}
        />
      )}
      {auditRow && <PaymentQueueAuditTrail row={auditRow} onClose={() => setAuditRow(null)} />}
      {bulk && <BulkActionDialog rows={bulk.rows} action={bulk.action} onClose={closeBulk} />}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}
