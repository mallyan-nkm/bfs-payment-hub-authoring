import { useEffect, useMemo, useState } from 'react';
import { toPopupValues, usePaymentQueuePopupValues } from './api/popupValuesApi';
import { EMPTY_POPUP_VALUES } from './popupValues';
import type { PopupValues } from './popupValues';

/** The values when R6 failed or could not read the rail: nothing to show, and the popup says why. */
const UNAVAILABLE_POPUP_VALUES: PopupValues = { ...EMPTY_POPUP_VALUES, unavailable: true };

/**
 * The rail adapter's values for the layout's non-`queue.*` codes, read from R6 (design §7, §8.0): fields by `fieldCode` and
 * grid rows by `gridCode`, with the Record List paged by the route. The popup shows each as the route sent it: account
 * numbers arrive masked or in full from the server, and a code with no value, no source, or a rail that could not be read
 * is drawn as "—" (E30: nothing is made up). While R6 loads the values are empty; when it fails, or the rail could not be
 * read (the A-11 timeout), they are empty and marked `unavailable`. The queue's own fields and the header are unaffected.
 *
 * Masking follows the unmask session as the grid does: the query key sits under `paymentQueueKeys.all`, which the unmask
 * session invalidates when it opens, closes or lapses, so this read is refetched with the session id header.
 *
 * The page lives here, keyed by the item, so a pager click re-reads R6 for that page while the previous page stays on screen.
 */
export function usePopupAdapterValues(queueEntryId: string): PopupValues {
  const [page, setPage] = useState(1);

  // The popup is opened for another item: start that item's Record List on its first page.
  useEffect(() => {
    setPage(1);
  }, [queueEntryId]);

  const { data, isError } = usePaymentQueuePopupValues(queueEntryId, page);
  return useMemo(() => {
    if (data) return data.railDataAvailable ? toPopupValues(data, setPage) : UNAVAILABLE_POPUP_VALUES;
    return isError ? UNAVAILABLE_POPUP_VALUES : EMPTY_POPUP_VALUES;
  }, [data, isError]);
}
