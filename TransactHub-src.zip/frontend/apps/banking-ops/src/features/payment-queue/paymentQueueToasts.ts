import type { ToastState } from '../../shared/components/Toast';
import type { ActOnPaymentQueueItemResultDto, BulkActOnPaymentQueueItemsResultDto } from './api/paymentQueueApi';
import type { BulkAction } from './BulkActionDialog';
import { dateLocale } from './i18n';
import type { PaymentQueueT } from './i18n';
import { formatInstant, sessionDateTimeContext } from '@paymenthub/ui';

/**
 * Every toast the Payment Queue raises, one small helper per message (the pattern of `submitToast` on the User
 * screen), so the copy lives in one place. The server's own words (`detail`, a per-record `message`, an action's label)
 * go in as sent; everything else is a `PAYMENT_QUEUE.*` key.
 */

/** The time of day a session lapses, in the session zone and the reader's language (`HH:mm:ss`). */
function timeOf(epochMs: number, language: string | undefined): string {
  return formatInstant(epochMs, { timeZone: sessionDateTimeContext().timeZone, locale: dateLocale(language) }, 'time');
}

// ─── Unmask PII (PMQ-P4-6) ───────────────────────────────────────────────────────────────────────────────────────────

export function unmaskedToast(t: PaymentQueueT, expiresAt: number, language: string | undefined): ToastState {
  return { tone: 'success', message: t('UNMASK.ON', { time: timeOf(expiresAt, language) }) };
}

export function maskedToast(t: PaymentQueueT): ToastState {
  return { tone: 'success', message: t('UNMASK.OFF') };
}

export function unmaskExpiredToast(t: PaymentQueueT): ToastState {
  return { tone: 'info', message: t('UNMASK.EXPIRED') };
}

/** The server's reason where it gave one; otherwise a reason from the status. Values stay masked either way. */
export function unmaskRefusedToast(t: PaymentQueueT, status: number, detail: string | null): ToastState {
  if (detail) return { tone: 'error', message: detail };
  if (status === 0) return { tone: 'error', message: t('UNMASK.REFUSED_NO_ANSWER') };
  if (status === 403) return { tone: 'error', message: t('UNMASK.REFUSED_FORBIDDEN') };
  return { tone: 'error', message: t('UNMASK.REFUSED_GENERIC') };
}

/** Closing the session failed: the server may still be sending full values, so the screen does not claim otherwise. */
export function maskFailedToast(t: PaymentQueueT, detail: string | null): ToastState {
  return { tone: 'error', message: detail ?? t('UNMASK.MASK_FAILED') };
}

// ─── After an action (PMQ-P4-8; design §8.10) ───────────────────────────────────────────────────────────────────────

/** The sentence a W1 success shows, by the stored action code: it names the payment and what happened to it. */
const DONE_KEY: Record<string, string> = {
  APPROVE: 'TOAST.DONE.APPROVE',
  REJECT: 'TOAST.DONE.REJECT',
  HOLD: 'TOAST.DONE.HOLD',
  RETURN: 'TOAST.DONE.RETURN',
  REASSIGN: 'TOAST.DONE.REASSIGN',
  REPAIR: 'TOAST.DONE.REPAIR',
  CLOSE: 'TOAST.DONE.CLOSE',
};

const RESUBMIT_KEY = 'TOAST.DONE.RESUBMIT';

interface AppliedAction {
  /** The payment's System Reference No. */
  reference: string;
  /** The code and label of the button the user pressed (R10's own). */
  chosenAction: string;
  chosenLabel: string;
  /** W1's answer. */
  result: Pick<ActOnPaymentQueueItemResultDto, 'outcome' | 'action' | 'isResubmit'>;
}

/**
 * The toast after W1 answered 200. The wording follows what the server says it recorded, not what was pressed:
 * a retry the server had already applied, or a stored action other than the chosen one, is shown as information and
 * never as the success the user expected.
 */
export function actionAppliedToast(
  t: PaymentQueueT,
  { reference, chosenAction, chosenLabel, result }: AppliedAction,
): ToastState {
  const recorded = result.action.trim().toUpperCase();
  if (result.outcome !== 'applied') {
    return { tone: 'info', message: t('TOAST.ALREADY_APPLIED', { action: chosenLabel, reference }) };
  }
  if (recorded !== chosenAction.trim().toUpperCase()) {
    return {
      tone: 'info',
      message: t('TOAST.DIFFERENT_ACTION', { reference, recorded: result.action, chosen: chosenLabel }),
    };
  }
  const key = result.isResubmit ? RESUBMIT_KEY : DONE_KEY[recorded];
  return {
    tone: 'success',
    message: key ? t(key, { reference }) : t('TOAST.DONE.GENERIC', { action: chosenLabel, reference }),
  };
}

const BULK_ACTION_KEY: Record<BulkAction, string> = {
  Approve: 'BULK.ACTION.APPROVE',
  Reject: 'BULK.ACTION.REJECT',
  Reassign: 'BULK.ACTION.REASSIGN',
};

/** The bulk action's name in the reader's language, for a title or a toast. */
export function bulkActionLabel(t: PaymentQueueT, action: BulkAction): string {
  return t(BULK_ACTION_KEY[action]);
}

/**
 * The toast when the bulk dialog closes after W2 answered: how many records were applied and how many were not.
 * W2 is not atomic, so a partial result is information and a result with nothing applied is an error.
 */
export function bulkResultToast(
  t: PaymentQueueT,
  action: BulkAction,
  result: Pick<BulkActOnPaymentQueueItemsResultDto, 'results'>,
): ToastState {
  const applied = result.results.filter((r) => r.status === 'applied').length;
  const notApplied = result.results.length - applied;
  const values = { action: bulkActionLabel(t, action), applied, notApplied };
  if (notApplied === 0) return { tone: 'success', message: t('TOAST.BULK_ALL', values) };
  if (applied === 0) return { tone: 'error', message: t('TOAST.BULK_NONE', values) };
  return { tone: 'info', message: t('TOAST.BULK_PARTIAL', values) };
}

// ─── Page-level notices ──────────────────────────────────────────────────────────────────────────────────────────────

export function selectionCapToast(t: PaymentQueueT, max: number): ToastState {
  return { tone: 'info', message: t('TOAST.SELECTION_CAP', { max }) };
}

export function filterSavedToast(t: PaymentQueueT): ToastState {
  return { tone: 'success', message: t('TOAST.FILTER_SAVED') };
}

export function defaultFilterToast(t: PaymentQueueT): ToastState {
  return { tone: 'success', message: t('TOAST.FILTER_DEFAULT') };
}

// ─── Saved filter and column layout (PMQ-P7-5) ──────────────────────────────────────────────────────────────────────

/** P2 failed: nothing was saved, and the previous saved filter (if any) still opens with the screen. */
export function filterSaveFailedToast(t: PaymentQueueT, detail: string | null): ToastState {
  return { tone: 'error', message: detail ?? t('TOAST.FILTER_SAVE_FAILED') };
}

/** P3 answered: no saved filter is left, and the panel is back to no filter. */
export function filterClearedToast(t: PaymentQueueT): ToastState {
  return { tone: 'success', message: t('TOAST.FILTER_CLEARED') };
}

/** P3 failed: the saved filter is still there. */
export function filterClearFailedToast(t: PaymentQueueT, detail: string | null): ToastState {
  return { tone: 'error', message: detail ?? t('TOAST.FILTER_CLEAR_FAILED') };
}

/** P4 failed: the columns stay as chosen for this session but will not come back on the next visit. */
export function columnLayoutSaveFailedToast(t: PaymentQueueT): ToastState {
  return { tone: 'error', message: t('TOAST.LAYOUT_SAVE_FAILED') };
}

/** The export would cover more records than one export takes: nothing was exported. */
export function exportTooLargeToast(t: PaymentQueueT, max: number): ToastState {
  return { tone: 'error', message: t('TOAST.EXPORT_TOO_LARGE', { max }) };
}

/** A page of the export could not be read: no file was written. */
export function exportFailedToast(t: PaymentQueueT): ToastState {
  return { tone: 'error', message: t('TOAST.EXPORT_FAILED') };
}
