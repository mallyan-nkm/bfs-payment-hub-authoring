import { QueueStatusBadge, RailBadge } from './badges';
import { asUtcIso } from './api/paymentQueueApi';
import type { PaymentQueueHeaderDto } from './api/paymentQueueApi';
import { fmtElapsed } from './popupFormat';
import type { PaymentQueueT } from './i18n';
import type { PopupValue } from './popupValues';
import type { PaymentQueueRow } from './types';

/**
 * The `queue.*` codes of a popup layout: values the queue core owns, for every rail (field-code contract section 3.1;
 * `PaymentQueuePopupFieldCodes` on the server). They come from what the drawer already holds: the R5 header where it has
 * the value, else the grid row. A value neither holds is `null`, drawn as "—".
 *
 * Account numbers arrive from R1 already masked by the server (design §9.4, I-6); nothing here unmasks them.
 */
export function buildQueuePopupValues(
  row: PaymentQueueRow,
  header: PaymentQueueHeaderDto | undefined,
  t: PaymentQueueT,
): Record<string, PopupValue> {
  return {
    'queue.systemReference': header?.systemReference ?? row.systemReferenceNo,
    'queue.channel': header?.channel ?? row.channel,
    'queue.rail': { type: 'node', node: <RailBadge rail={header?.rail ?? row.rail} /> },
    'queue.status': { type: 'node', node: <QueueStatusBadge status={row.queueStatus} /> },
    'queue.waitTime': header ? fmtElapsed(t, header.elapsedSeconds) : null,
    'queue.submittedBy': row.submittedBy || t('SYSTEM'),
    'queue.submittedAt': { type: 'dateTime', value: header ? asUtcIso(header.submittedAt) : row.submittedDate },
    'queue.debtorAccount': row.debtorAccount,
    'queue.creditorName': row.creditorName,
    'queue.creditorAccount': row.creditorAccount,
    'queue.creditorBank': row.creditorBank,
  };
}
