import { EMPTY_FILTERS } from './AdvancedFilterPanel';
import type { AdvancedFilterState } from './AdvancedFilterPanel';
import type { FilterCode, PanelOptions } from './filterOptions';
import type { PaymentQueueSavedFilterDto } from './api/preferencesApi';
import type { PaymentTypeFilter, PriorityLevel } from './types';

/**
 * The one saved filter (design §9.2, Q-16) and the left panel's state, both ways (PMQ-P7-5).
 *
 * **R-16.** Only the left panel's values are saved: Status, Payment Type, Rail, Channel, Priority, Amount Min / Max and
 * the date range. The grid's inline column filters are off on this screen and are never part of the saved filter; the
 * match-mode fields (`statusMode`, …) are inert and are not saved either (they always read OR).
 *
 * **The tenant's `filters.enabled` setting wins.** A filter that is off is neither saved nor applied: a saved value for
 * a filter the tenant has since turned off is ignored, and so is a chip value the panel no longer offers (it could not
 * be shown, and a filter the user cannot see must never narrow the grid).
 */

const DATE = /^\d{4}-\d{2}-\d{2}$/;

/** A list group as saved: its value(s) when the filter is on, otherwise nothing. */
function listOf(on: boolean, values: readonly string[]): string[] {
  return on ? values.filter((v) => v.trim() !== '') : [];
}

/** A text value as saved: trimmed when the filter is on and the text is not blank, otherwise null. */
function textOf(on: boolean, value: string): string | null {
  const trimmed = value.trim();
  return on && trimmed ? trimmed : null;
}

/** The panel's state as P2's body: the enabled filters' values only. */
export function toSavedFilterDto(state: AdvancedFilterState, enabled: ReadonlySet<FilterCode>): PaymentQueueSavedFilterDto {
  const on = (code: FilterCode) => enabled.has(code);
  return {
    status: listOf(on('status'), state.status),
    paymentType: listOf(on('paymentType'), state.paymentType),
    rail: listOf(on('rail'), state.rail),
    channel: listOf(on('channel'), state.channel),
    priority: listOf(on('priority'), state.priority),
    amountMin: textOf(on('amount'), state.amountMin),
    amountMax: textOf(on('amount'), state.amountMax),
    dateFrom: textOf(on('dateRange'), state.dateFrom),
    dateTo: textOf(on('dateRange'), state.dateTo),
  };
}

/**
 * A saved list group as the panel holds it: kept only while the filter is on and only the values the panel offers.
 * The panel is single-select, so at most one value is kept.
 */
function pick<T extends string>(on: boolean, saved: readonly string[] | null | undefined, offered: readonly T[]): T[] {
  if (!on || !saved) return [];
  const value = saved.find((v): v is T => offered.some((o) => o === v));
  return value ? [value] : [];
}

/** Like {@link pick}, for the multi-select groups (Rail, Channel): every saved value the panel still offers is kept. */
function pickMany<T extends string>(on: boolean, saved: readonly string[] | null | undefined, offered: readonly T[]): T[] {
  if (!on || !saved) return [];
  return offered.filter((o) => saved.includes(o));
}

function amountOf(on: boolean, saved: string | null | undefined): string {
  return on && saved != null && saved.trim() !== '' && Number.isFinite(Number(saved)) ? saved.trim() : '';
}

function dateOf(on: boolean, saved: string | null | undefined): string {
  return on && saved != null && DATE.test(saved) ? saved : '';
}

/**
 * P1's saved filter as the panel's state, under the panel options of the moment (R4's answer, or the fixed fallback when
 * R4 could not be read). Anything the tenant has turned off, or the panel does not offer, is left out.
 */
export function fromSavedFilterDto(saved: PaymentQueueSavedFilterDto, options: PanelOptions): AdvancedFilterState {
  const on = (code: FilterCode) => options.enabled.has(code);
  return {
    ...EMPTY_FILTERS,
    status: pick(on('status'), saved.status, options.status),
    paymentType: pick<PaymentTypeFilter>(on('paymentType'), saved.paymentType, options.paymentType),
    rail: pickMany(on('rail'), saved.rail, options.rail),
    channel: pickMany(on('channel'), saved.channel, options.channel),
    priority: pick<PriorityLevel>(on('priority'), saved.priority, options.priority),
    amountMin: amountOf(on('amount'), saved.amountMin),
    amountMax: amountOf(on('amount'), saved.amountMax),
    dateFrom: dateOf(on('dateRange'), saved.dateFrom),
    dateTo: dateOf(on('dateRange'), saved.dateTo),
  };
}
