import type { ReactNode } from 'react';

// The values a popup layout is filled with (Payment Queue – Outbound design §8.0; PMQ-P7-2). A layout names a field by its
// code; the value for that code comes from one of two places:
//   - the queue core, for `queue.*` codes, from data the drawer already has (`queuePopupValues.tsx`);
//   - the rail's adapter, for every other code, from R5 (fields) and R6 (grid rows), which PMQ-P7-3 serves.
// A code with no value is drawn as "—". The renderer never invents one, and it never knows what a code means.

/** An amount with its currency: the renderer prints `AED 1,234.50`. */
export interface PopupMoney {
  type: 'money';
  amount: number;
  currency: string;
}

/** An instant (ISO 8601 UTC), printed in the reader's language and time zone. */
export interface PopupDateTime {
  type: 'dateTime';
  value: string;
}

/**
 * A value the client builds itself and draws as given (a badge). It never comes from the server: the wire carries text,
 * numbers, booleans, money and instants only.
 */
export interface PopupNode {
  type: 'node';
  node: ReactNode;
}

/** One value. `null`, `undefined` and blank text all mean "the source holds nothing": drawn as "—". */
export type PopupValue = string | number | boolean | null | undefined | PopupMoney | PopupDateTime | PopupNode;

/** The paging the R6 route answers with, and the action that asks for another page. */
export interface PopupGridPaging {
  /** 1-based. */
  page: number;
  pageSize: number;
  totalCount: number;
  onPageChange: (page: number) => void;
}

/** The rows of one grid, by field code. A grid with no entry, or no rows, shows its `emptyLabel`. */
export interface PopupGridData {
  rows: Array<Record<string, PopupValue>>;
  paging?: PopupGridPaging;
  /** True when the route says the rail holds nothing to show (no recorded posting legs): the grid shows "Not Available". */
  notAvailable?: boolean;
}

/** Everything the renderer reads values from: fields by `fieldCode`, grids by `gridCode`. */
export interface PopupValues {
  fields: Record<string, PopupValue>;
  grids: Record<string, PopupGridData>;
  /**
   * True when R6 failed, or answered that the rail could not be read: every non-`queue.*` code then shows "—" and the popup
   * says why (PMQ-P7-3). Absent while R6 loads and when its values arrived.
   */
  unavailable?: boolean;
}

export const EMPTY_POPUP_VALUES: PopupValues = { fields: {}, grids: {} };

/**
 * The adapter values over the queue's own: where both name a code, the queue core wins, because the rail's adapter
 * never serves `queue.*` (contract section 1).
 */
export function mergePopupValues(adapter: PopupValues, queue: Record<string, PopupValue>): PopupValues {
  return { fields: { ...adapter.fields, ...queue }, grids: adapter.grids };
}
