import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import {
  apiError,
  apiOk,
  expectNotActionable,
  grant,
  renderWithProviders,
} from '../../../test/renderWithProviders';
import { gridRowDto } from '../../../test/paymentQueueFixtures';
import type { BulkActOnPaymentQueueItemsRequest, PaymentQueueGridRowDto } from './api/paymentQueueApi';
import { PaymentQueueOutwardPage } from './outward/PaymentQueueOutwardPage';

/**
 * PMQ-P4-3: row buttons per tab and permission (AC-PMQ-080) and the bulk bar (AC-PMQ-082): the 100-record cap, the
 * mixed-selection rule, W2's request and its per-record results.
 */

vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

const BASE = '/ops/payment-queue';

type Config = { params?: { tab?: string; queueEntryId?: string } } | undefined;

interface Served {
  all: PaymentQueueGridRowDto[];
  actionable: PaymentQueueGridRowDto[];
  targets?: { departmentId: number; departmentName: string; noEligibleActor: boolean }[];
}

/** Answers R1 (by tab), R2 and R11 the way the Operations API does. */
function serve({ all, actionable, targets = [] }: Served) {
  get.mockImplementation(((url: string, config?: Config) => {
    if (url === `${BASE}/counts`) return Promise.resolve(apiOk({ all: all.length, actionable: actionable.length }));
    if (url === `${BASE}/items`) {
      const items = config?.params?.tab === 'actionable' ? actionable : all;
      return Promise.resolve(apiOk({ items, page: 1, size: 100, totalCount: items.length }));
    }
    if (url === `${BASE}/reassign-targets`) return Promise.resolve(apiOk(targets));
    return Promise.reject(new Error(`unexpected call ${url}`));
  }) as never);
}

const row = (id: string, overrides: Partial<PaymentQueueGridRowDto> = {}) =>
  gridRowDto({ queueEntryId: id, systemReference: `REF-${id}`, debtorName: `Debtor ${id}`, ...overrides });

const A = row('A', { currentStateId: 42 });
const B = row('B', { currentStateId: 43 });

function serveActionable(...rows: PaymentQueueGridRowDto[]) {
  serve({ all: rows, actionable: rows });
}

async function openPaymentQueue(firstRef: string) {
  renderWithProviders(<PaymentQueueOutwardPage />);
  await screen.findByText(firstRef);
  await userEvent.click(screen.getByRole('tab', { name: /Payment Queue/ }));
}

const tick = (ref: string) => userEvent.click(screen.getByRole('checkbox', { name: `Select ${ref}` }));
const bar = () => document.querySelector('.pq-selection-bar') as HTMLElement;
/** The footer's Close, not the dialog corner's icon button of the same name. */
const closeResults = () =>
  userEvent.click(screen.getAllByRole('button', { name: 'Close' }).find((b) => !b.querySelector('.sr-only'))!);
const actionButtons = () => [
  within(bar()).getByRole('button', { name: /Approve/ }),
  within(bar()).getByRole('button', { name: /Reject/ }),
  within(bar()).getByRole('button', { name: /Reassign/ }),
];

beforeEach(() => {
  get.mockReset();
  post.mockReset();
  // The render policy loads with a bare `fetch`; nothing may reach a real backend from a test.
  vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('offline')));
  grant(PERM.paymentQueuePage, PERM.paymentQueueAct);
});

// ── Row buttons (AC-PMQ-080) ────────────────────────────────────────────────

describe('Row buttons (AC-PMQ-080)', () => {
  it('shows View & Action and Audit Trail on Payment Queue rows', async () => {
    serveActionable(A, B);
    await openPaymentQueue('REF-A');

    expect(screen.getAllByRole('button', { name: 'View & Action' })).toHaveLength(2);
    expect(screen.getAllByRole('button', { name: 'Audit Trail' })).toHaveLength(2);
    expect(screen.queryByRole('button', { name: 'View' })).not.toBeInTheDocument();
  });

  it('shows View and Audit Trail on All Queues rows, even to a holder of the write key', async () => {
    serveActionable(A, B);
    renderWithProviders(<PaymentQueueOutwardPage />);
    await screen.findByText('REF-A');

    expect(screen.getAllByRole('button', { name: 'View' })).toHaveLength(2);
    expect(screen.getAllByRole('button', { name: 'Audit Trail' })).toHaveLength(2);
    expect(screen.queryByRole('button', { name: 'View & Action' })).not.toBeInTheDocument();
  });

  it('shows a View-only user View and Audit Trail on every tab (page key alone)', async () => {
    grant(PERM.paymentQueuePage);
    serveActionable(A, B);
    await openPaymentQueue('REF-A');

    expect(screen.queryByRole('button', { name: 'View & Action' })).not.toBeInTheDocument();
    expect(screen.getAllByRole('button', { name: 'View' })).toHaveLength(2);
    expect(screen.getAllByRole('button', { name: 'Audit Trail' })).toHaveLength(2);
  });

  it('gates Audit Trail on the page key and View & Action on the write key, independently', async () => {
    grant(PERM.paymentQueueAct);
    serveActionable(A);
    await openPaymentQueue('REF-A');

    expect(screen.getByRole('button', { name: 'View & Action' })).toBeInTheDocument();
    expectNotActionable(screen.queryByRole('button', { name: 'Audit Trail' }));
  });

  it('has no Escalate control on the screen, with a selection open', async () => {
    serveActionable(A);
    await openPaymentQueue('REF-A');
    await tick('REF-A');

    expect(bar()).toBeInTheDocument();
    expect(screen.queryByText(/escalate/i)).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /escalate/i })).not.toBeInTheDocument();
  });
});

// ── Selection (AC-PMQ-080, 082) ──────────────────────────────────────────────

describe('Selection', () => {
  it('selects the current page only with the header checkbox', async () => {
    const rows = Array.from({ length: 30 }, (_, i) => row(`R${i}`));
    serveActionable(...rows);
    await openPaymentQueue('REF-R0');

    await userEvent.click(screen.getByRole('checkbox', { name: 'Select all rows on this page' }));

    // The default page size is 20 of the 30 rows.
    expect(within(bar()).getByText('20 records selected')).toBeInTheDocument();
  });

  it('never selects past 100 records, with the header checkbox or a single row', async () => {
    const rows = Array.from({ length: 120 }, (_, i) => row(`R${String(i).padStart(3, '0')}`));
    serveActionable(...rows);
    await openPaymentQueue('REF-R000');
    await userEvent.selectOptions(screen.getByDisplayValue('20'), '50');

    const header = () => screen.getByRole('checkbox', { name: 'Select all rows on this page' });
    const next = () => userEvent.click(screen.getByRole('button', { name: /Next/ }));
    await userEvent.click(header());
    await next();
    await userEvent.click(header());
    expect(within(bar()).getByText('100 records selected')).toBeInTheDocument();

    await next();
    await userEvent.click(header());
    expect(within(bar()).getByText('100 records selected')).toBeInTheDocument();
    expect(await screen.findByText('At most 100 records can be selected for a bulk action.')).toBeInTheDocument();

    await userEvent.click(screen.getAllByRole('checkbox', { name: /^Select REF-R/ })[0]);
    expect(within(bar()).getByText('100 records selected')).toBeInTheDocument();
  });

  it('posts the 100 selected records, no more', async () => {
    const rows = Array.from({ length: 120 }, (_, i) => row(`R${String(i).padStart(3, '0')}`));
    serveActionable(...rows);
    post.mockResolvedValue(apiOk({ bulkActionId: 'BULK-1', results: [] }));
    await openPaymentQueue('REF-R000');
    await userEvent.selectOptions(screen.getByDisplayValue('20'), '50');
    const header = () => screen.getByRole('checkbox', { name: 'Select all rows on this page' });
    for (let page = 0; page < 3; page += 1) {
      await userEvent.click(header());
      await userEvent.click(screen.getByRole('button', { name: /Next/ }));
    }

    await userEvent.click(actionButtons()[0]);
    await userEvent.type(screen.getByRole('textbox', { name: /Remarks/ }), 'ok');
    await userEvent.click(screen.getByRole('button', { name: 'Confirm Approve' }));

    await waitFor(() => expect(post).toHaveBeenCalledTimes(1));
    expect((post.mock.calls[0][1] as BulkActOnPaymentQueueItemsRequest).queueEntryIds).toHaveLength(100);
  });

  it('drops the selection when a filter changes, so nothing hidden can be acted on', async () => {
    serveActionable(A, B);
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    expect(bar()).toBeInTheDocument();

    await userEvent.selectOptions(screen.getByRole('combobox', { name: 'Status' }), 'Held');

    expect(document.querySelector('.pq-selection-bar')).not.toBeInTheDocument();
  });
});

// ── Bar eligibility (AC-PMQ-082) ─────────────────────────────────────────────

describe('Bulk bar eligibility (AC-PMQ-082)', () => {
  it('offers Approve, Reject and Reassign, enabled for a uniform selection', async () => {
    serveActionable(A, B);
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    await tick('REF-B');

    expect(within(bar()).getAllByRole('button').map((b) => b.textContent?.trim())).toEqual(['Approve', 'Reject', 'Reassign']);
    actionButtons().forEach((b) => expect(b).toBeEnabled());
    expect(within(bar()).getByText('2 records selected')).toBeInTheDocument();
  });

  it.each([
    ['rail', { rail: 'IPI' }],
    ['message type', { messageType: 'pacs.008' }],
    ['payment type', { paymentType: 'Batch' }],
  ])('disables the bar when the selection mixes %s', async (_name, overrides) => {
    serveActionable(A, row('B', overrides));
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    await tick('REF-B');

    actionButtons().forEach((b) => expect(b).toBeDisabled());
    expect(within(bar()).getByRole('note')).toHaveTextContent('same rail, message type and payment type');
  });

  it('enables the bar again when the odd record is unticked', async () => {
    serveActionable(A, row('B', { rail: 'IPI' }));
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    await tick('REF-B');
    await tick('REF-B');

    actionButtons().forEach((b) => expect(b).toBeEnabled());
  });

  it('disables the bar for a record that is not on the Payment Queue', async () => {
    serve({ all: [A, B], actionable: [A] });
    renderWithProviders(<PaymentQueueOutwardPage />);
    await screen.findByText('REF-B');
    await tick('REF-B');

    actionButtons().forEach((b) => expect(b).toBeDisabled());
    expect(within(bar()).getByRole('note')).toHaveTextContent('Payment Queue records only');
  });

  it('disables the bar for a user without the write key', async () => {
    grant(PERM.paymentQueuePage);
    serveActionable(A);
    await openPaymentQueue('REF-A');
    await tick('REF-A');

    actionButtons().forEach((b) => expect(b).toBeDisabled());
    expect(within(bar()).getByRole('note')).toHaveTextContent('do not have permission');
  });
});

// ── W2 and the results (AC-PMQ-082) ──────────────────────────────────────────

describe('Bulk confirmation and W2 (AC-PMQ-082)', () => {
  async function pickTwoAndApprove() {
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    await tick('REF-B');
    await userEvent.click(actionButtons()[0]);
    return screen.findByRole('dialog');
  }

  it('requires remarks before it will confirm, and calls nothing until then', async () => {
    serveActionable(A, B);
    const dialog = await pickTwoAndApprove();

    expect(within(dialog).getByText('2 records will be approved.')).toBeInTheDocument();
    const confirm = within(dialog).getByRole('button', { name: 'Confirm Approve' });
    expect(confirm).toBeDisabled();
    await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), '   ');
    expect(confirm).toBeDisabled();
    expect(post).not.toHaveBeenCalled();
  });

  it('posts W2 with each record and its expected state, then lists a result per record', async () => {
    serveActionable(A, B);
    post.mockResolvedValue(
      apiOk({
        bulkActionId: 'BULK-9',
        results: [
          { queueEntryId: 'A', status: 'applied', newStateId: 50, reason: null, message: null },
          {
            queueEntryId: 'B',
            status: 'conflict',
            newStateId: null,
            reason: 'StateSuperseded',
            message: 'The record changed since it was loaded.',
          },
        ],
      }),
    );
    const dialog = await pickTwoAndApprove();
    await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), 'Checked against the file');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Confirm Approve' }));

    const results = await screen.findByRole('table', { name: 'Bulk action results' });
    expect(post).toHaveBeenCalledTimes(1);
    const [url, body] = post.mock.calls[0] as [string, BulkActOnPaymentQueueItemsRequest];
    expect(url).toBe('/ops/payment-queue/bulk-actions');
    expect(body).toEqual({
      queueEntryIds: ['A', 'B'],
      action: 'APPROVE',
      remarks: 'Checked against the file',
      clientRequestId: expect.any(String),
      expectedStateIds: { A: 42, B: 43 },
    });
    expect(body.clientRequestId.length).toBeGreaterThan(0);
    expect(body.clientRequestId.length).toBeLessThanOrEqual(64);
    expect('targetDepartmentId' in body).toBe(false);

    const lines = within(results).getAllByRole('row').slice(1);
    expect(lines).toHaveLength(2);
    expect(within(lines[0]).getByText('REF-A')).toBeInTheDocument();
    expect(within(lines[0]).getByText('Applied')).toBeInTheDocument();
    expect(within(lines[1]).getByText('REF-B')).toBeInTheDocument();
    expect(within(lines[1]).getByText('Changed since loaded')).toBeInTheDocument();
    expect(within(lines[1]).getByText('The record changed since it was loaded.')).toBeInTheDocument();
    expect(screen.getByRole('status')).toHaveTextContent('1 applied, 1 not applied.');
  });

  it('refetches the grid and the counts after W2', async () => {
    serveActionable(A, B);
    post.mockResolvedValue(apiOk({ bulkActionId: 'BULK-1', results: [] }));
    const dialog = await pickTwoAndApprove();
    const before = get.mock.calls.length;
    await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), 'ok');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Confirm Approve' }));

    await screen.findByRole('table', { name: 'Bulk action results' });
    await waitFor(() => expect(get.mock.calls.length).toBe(before + 3));
    const urls = get.mock.calls.slice(before).map(([u]) => u);
    expect(urls.filter((u) => u === `${BASE}/items`)).toHaveLength(2);
    expect(urls).toContain(`${BASE}/counts`);
  });

  it('keeps a record that was not applied selected, and drops the applied one, when the results close', async () => {
    serveActionable(A, B);
    post.mockResolvedValue(
      apiOk({
        bulkActionId: 'BULK-2',
        results: [
          { queueEntryId: 'A', status: 'applied', newStateId: 50 },
          { queueEntryId: 'B', status: 'not-allowed', reason: 'ActionNotPermitted', message: 'Not allowed at this level.' },
        ],
      }),
    );
    const dialog = await pickTwoAndApprove();
    await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), 'ok');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Confirm Approve' }));
    await screen.findByRole('table', { name: 'Bulk action results' });

    await closeResults();

    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(within(bar()).getByText('1 record selected')).toBeInTheDocument();
    expect(screen.getByRole('checkbox', { name: 'Select REF-B' })).toBeChecked();
  });

  it('sends Reject with its action code', async () => {
    serveActionable(A);
    post.mockResolvedValue(apiOk({ bulkActionId: 'BULK-3', results: [{ queueEntryId: 'A', status: 'applied' }] }));
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    await userEvent.click(actionButtons()[1]);
    const dialog = await screen.findByRole('dialog');
    await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), 'Wrong beneficiary');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Confirm Reject' }));

    await waitFor(() => expect(post).toHaveBeenCalledTimes(1));
    expect((post.mock.calls[0][1] as BulkActOnPaymentQueueItemsRequest).action).toBe('REJECT');
  });

  it('sends Reassign with the chosen department, and will not offer one nobody can act in', async () => {
    serve({
      all: [A, B],
      actionable: [A, B],
      targets: [
        { departmentId: 7, departmentName: 'Treasury', noEligibleActor: false },
        { departmentId: 8, departmentName: 'Empty Desk', noEligibleActor: true },
      ],
    });
    post.mockResolvedValue(apiOk({ bulkActionId: 'BULK-4', results: [{ queueEntryId: 'A', status: 'applied' }] }));
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    await userEvent.click(actionButtons()[2]);
    const dialog = await screen.findByRole('dialog');
    await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), 'Moving to Treasury');
    const confirm = within(dialog).getByRole('button', { name: 'Confirm Reassign' });
    expect(confirm).toBeDisabled();

    const picker = await within(dialog).findByRole('combobox');
    await waitFor(() => expect(picker).toBeEnabled());
    await userEvent.click(picker);
    expect(await screen.findByRole('option', { name: 'Empty Desk (nobody can act there)' })).toHaveAttribute('aria-disabled', 'true');
    await userEvent.click(screen.getByRole('option', { name: 'Treasury' }));
    await userEvent.click(confirm);

    await waitFor(() => expect(post).toHaveBeenCalledTimes(1));
    expect(post.mock.calls[0][1]).toMatchObject({ action: 'REASSIGN', targetDepartmentId: 7 });
    expect(get).toHaveBeenCalledWith(`${BASE}/reassign-targets`, { params: { queueEntryId: 'A' } });
  });

  it('shows the server reason when W2 refuses the whole request, and sends nothing else', async () => {
    serveActionable(A, B);
    post.mockRejectedValue(apiError(422, 'Remarks are required.', 'ValidationFailed', { reason: 'RemarksInvalid' }));
    const dialog = await pickTwoAndApprove();
    await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), 'x');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Confirm Approve' }));

    expect(await within(dialog).findByRole('alert')).toHaveTextContent('Remarks are required.');
    expect(screen.queryByRole('table', { name: 'Bulk action results' })).not.toBeInTheDocument();
  });

  it('retries a request that got no answer with the same ClientRequestId, and a changed request with a new one', async () => {
    serveActionable(A, B);
    post
      .mockRejectedValueOnce(new Error('Network Error'))
      .mockRejectedValueOnce(new Error('Network Error'))
      .mockRejectedValueOnce(new Error('Network Error'))
      .mockResolvedValue(apiOk({ bulkActionId: 'BULK-5', results: [] }));
    const dialog = await pickTwoAndApprove();
    const remarks = within(dialog).getByRole('textbox', { name: /Remarks/ });
    await userEvent.type(remarks, 'first');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Confirm Approve' }));
    expect(await within(dialog).findByRole('alert')).toHaveTextContent('may or may not have been changed');

    await userEvent.click(within(dialog).getByRole('button', { name: 'Retry' }));
    await waitFor(() => expect(post).toHaveBeenCalledTimes(2));
    await within(dialog).findByRole('alert');
    await userEvent.type(remarks, ' edited');
    await userEvent.click(within(dialog).getByRole('button', { name: 'Retry' }));
    await waitFor(() => expect(post).toHaveBeenCalledTimes(3));

    const ids = post.mock.calls.map(([, body]) => (body as BulkActOnPaymentQueueItemsRequest).clientRequestId);
    expect(ids[1]).toBe(ids[0]);
    expect(ids[2]).not.toBe(ids[0]);
  });

  it('uses a fresh ClientRequestId for each new click of a new bulk action', async () => {
    serveActionable(A);
    post.mockResolvedValue(apiOk({ bulkActionId: 'BULK-6', results: [{ queueEntryId: 'A', status: 'conflict' }] }));
    await openPaymentQueue('REF-A');
    await tick('REF-A');
    for (let i = 0; i < 2; i += 1) {
      await userEvent.click(actionButtons()[0]);
      const dialog = await screen.findByRole('dialog');
      await userEvent.type(within(dialog).getByRole('textbox', { name: /Remarks/ }), 'same remarks');
      await userEvent.click(within(dialog).getByRole('button', { name: 'Confirm Approve' }));
      await screen.findByRole('table', { name: 'Bulk action results' });
      await closeResults();
      await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    }

    const ids = post.mock.calls.map(([, body]) => (body as BulkActOnPaymentQueueItemsRequest).clientRequestId);
    expect(ids).toHaveLength(2);
    expect(ids[0]).not.toBe(ids[1]);
  });
});
