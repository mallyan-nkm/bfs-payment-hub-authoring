// The popup layout (Payment Queue – Outbound design §5.8, §8.0; PMQ-P7-2): the typed shape of the R14 `layout` JSON and
// the pure functions that read it. Nothing here names a rail or a field: a layout says where a field goes and what it is
// called, and the renderer draws exactly that. The shape is schema version 1; the contract is
// `.github/implementation/payment-queue-outbound/P7-1-layout-field-codes.md` section 2.

/** The layout JSON schema version this renderer draws. A layout of any other version is not drawn (banner instead). */
export const SUPPORTED_LAYOUT_SCHEMA_VERSION = 1;

/** The components the queue places for every rail, whatever the layout says (design §8.0 slots). */
export const POPUP_SLOT = {
  workflow: 'workflow',
  actionHistory: 'actionHistory',
} as const;

/** `showWhen`: every key present must match the item. An absent `showWhen` always shows. */
export interface PopupShowWhen {
  /** `Batch` or `Single`, compared without case. */
  paymentType?: string[];
  /** True when the item is a sub-batch; false when it is not. */
  subBatch?: boolean;
}

export interface PopupField {
  fieldCode: string;
  label: string;
  order: number;
  showWhen?: PopupShowWhen;
}

export interface PopupColumn {
  fieldCode: string;
  label: string;
  order: number;
  /** A `groupCode` of the grid's `columnGroups`. */
  group?: string;
}

export interface PopupColumnGroup {
  groupCode: string;
  label: string;
  order: number;
}

export interface PopupGrid {
  gridCode: string;
  order: number;
  /** The rows arrive paged (R6): the renderer shows the pager the values carry. */
  paged: boolean;
  /** Shown instead of the table body when the grid has no rows ("Not Available" for Posting Details). */
  emptyLabel?: string;
  totalRow?: { label: string; fieldCode: string };
  columnGroups: PopupColumnGroup[];
  columns: PopupColumn[];
}

export interface PopupSection {
  sectionCode: string;
  label: string;
  order: number;
  showWhen?: PopupShowWhen;
  /** Collapsed until the user opens it ("More Details"). */
  expandable: boolean;
  /** A queue-placed component (`workflow`, `actionHistory`), instead of fields and grids. */
  slot?: string;
  fields: PopupField[];
  grids: PopupGrid[];
}

export interface PopupTab {
  tabCode: string;
  label: string;
  order: number;
  showWhen?: PopupShowWhen;
  slot?: string;
  sections: PopupSection[];
}

export interface PopupLayout {
  tabs: PopupTab[];
  /** The footer's slot (`actions`). The footer is always drawn (A-17); this is informational. */
  footerSlot?: string;
}

/** What the item is, for `showWhen`. */
export interface PopupContext {
  paymentType: string;
  subBatch: boolean;
}

// ─── Reading the JSON ────────────────────────────────────────────────────────────────────────────────────────────────

type Json = Record<string, unknown>;

const isObject = (value: unknown): value is Json => typeof value === 'object' && value !== null && !Array.isArray(value);
const asArray = (value: unknown): unknown[] => (Array.isArray(value) ? value : []);
const asString = (value: unknown): string | undefined =>
  typeof value === 'string' && value.trim() !== '' ? value : undefined;
const asNumber = (value: unknown): number => (typeof value === 'number' && Number.isFinite(value) ? value : 0);

function readShowWhen(value: unknown): PopupShowWhen | undefined {
  if (!isObject(value)) return undefined;
  const paymentType = asArray(value.paymentType).filter((p): p is string => typeof p === 'string');
  return {
    ...(Array.isArray(value.paymentType) ? { paymentType } : {}),
    ...(typeof value.subBatch === 'boolean' ? { subBatch: value.subBatch } : {}),
  };
}

/** Items by `order`, ties in the order the layout lists them. */
function byOrder<T extends { order: number }>(items: T[]): T[] {
  return items.map((item, index) => ({ item, index })).sort((a, b) => a.item.order - b.item.order || a.index - b.index).map((x) => x.item);
}

function readField(value: unknown): PopupField | null {
  if (!isObject(value)) return null;
  const fieldCode = asString(value.fieldCode);
  if (!fieldCode) return null;
  return { fieldCode, label: asString(value.label) ?? fieldCode, order: asNumber(value.order), showWhen: readShowWhen(value.showWhen) };
}

function readColumn(value: unknown): PopupColumn | null {
  if (!isObject(value)) return null;
  const fieldCode = asString(value.fieldCode);
  if (!fieldCode) return null;
  return { fieldCode, label: asString(value.label) ?? fieldCode, order: asNumber(value.order), group: asString(value.group) };
}

function readGrid(value: unknown): PopupGrid | null {
  if (!isObject(value)) return null;
  const gridCode = asString(value.gridCode);
  if (!gridCode) return null;
  const total = isObject(value.totalRow) ? value.totalRow : undefined;
  const totalCode = total ? asString(total.fieldCode) : undefined;
  return {
    gridCode,
    order: asNumber(value.order),
    paged: value.paged === true,
    emptyLabel: asString(value.emptyLabel),
    totalRow: total && totalCode ? { label: asString(total.label) ?? '', fieldCode: totalCode } : undefined,
    columnGroups: byOrder(
      asArray(value.columnGroups).flatMap((g) => {
        if (!isObject(g)) return [];
        const groupCode = asString(g.groupCode);
        return groupCode ? [{ groupCode, label: asString(g.label) ?? groupCode, order: asNumber(g.order) }] : [];
      }),
    ),
    columns: byOrder(asArray(value.columns).map(readColumn).filter((c): c is PopupColumn => c !== null)),
  };
}

function readSection(value: unknown): PopupSection | null {
  if (!isObject(value)) return null;
  const sectionCode = asString(value.sectionCode);
  if (!sectionCode) return null;
  return {
    sectionCode,
    label: asString(value.label) ?? '',
    order: asNumber(value.order),
    showWhen: readShowWhen(value.showWhen),
    expandable: value.expandable === true,
    slot: asString(value.slot),
    fields: byOrder(asArray(value.fields).map(readField).filter((f): f is PopupField => f !== null)),
    grids: byOrder(asArray(value.grids).map(readGrid).filter((g): g is PopupGrid => g !== null)),
  };
}

function readTab(value: unknown): PopupTab | null {
  if (!isObject(value)) return null;
  const tabCode = asString(value.tabCode);
  if (!tabCode) return null;
  return {
    tabCode,
    label: asString(value.label) ?? tabCode,
    order: asNumber(value.order),
    showWhen: readShowWhen(value.showWhen),
    slot: asString(value.slot),
    sections: byOrder(asArray(value.sections).map(readSection).filter((s): s is PopupSection => s !== null)),
  };
}

/**
 * Reads the R14 `layout` object. Tabs, sections, fields, grids and columns come out in their configured `order`; a node
 * with no code is dropped (it could never show a value); a missing label falls back to its code, so nothing is blank.
 * Null when there is no tab at all, which the popup treats as "not configured".
 */
export function parsePopupLayout(raw: unknown): PopupLayout | null {
  if (!isObject(raw)) return null;
  const tabs = byOrder(asArray(raw.tabs).map(readTab).filter((t): t is PopupTab => t !== null));
  if (tabs.length === 0) return null;
  const footer = isObject(raw.footer) ? asString(raw.footer.slot) : undefined;
  return { tabs, footerSlot: footer };
}

// ─── showWhen ────────────────────────────────────────────────────────────────────────────────────────────────────────

/** True when every condition of `showWhen` holds for the item. */
export function isShown(showWhen: PopupShowWhen | undefined, context: PopupContext): boolean {
  if (!showWhen) return true;
  if (showWhen.paymentType && !showWhen.paymentType.some((p) => p.trim().toLowerCase() === context.paymentType.trim().toLowerCase())) {
    return false;
  }
  if (showWhen.subBatch !== undefined && showWhen.subBatch !== context.subBatch) return false;
  return true;
}
