import { useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button, Dialog, Select, Textarea } from '@paymenthub/ui';
import { paymentQueueApi, paymentQueueProblem } from './api/paymentQueueApi';
import type {
  BulkActOnPaymentQueueItemsRequest,
  BulkActOnPaymentQueueItemsResultDto,
  PaymentQueueBulkActionCode,
} from './api/paymentQueueApi';
import { paymentQueueKeys } from './api/queryKeys';
import { useBulkAction } from './api/useBulkAction';
import { usePaymentQueueTranslation } from './i18n';
import type { PaymentQueueT } from './i18n';
import { bulkActionLabel } from './paymentQueueToasts';
import type { PaymentQueueRow } from './types';

/** The bulk bar's actions (design §6.5). Escalate is not one of them (Q-13). */
export type BulkAction = 'Approve' | 'Reject' | 'Reassign';

const ACTION_CODE: Record<BulkAction, PaymentQueueBulkActionCode> = {
  Approve: 'APPROVE',
  Reject: 'REJECT',
  Reassign: 'REASSIGN',
};

/** The §6.5 status words, as the confirmation shows them. A word the screen does not know is shown as sent. */
const RESULT_KEY: Record<string, string> = {
  applied: 'BULK.RESULT.APPLIED',
  conflict: 'BULK.RESULT.CONFLICT',
  'not-eligible': 'BULK.RESULT.NOT_ELIGIBLE',
  'not-allowed': 'BULK.RESULT.NOT_ALLOWED',
  unavailable: 'BULK.RESULT.UNAVAILABLE',
};

interface Props {
  /** The selection at the moment the bar's button was clicked. */
  rows: PaymentQueueRow[];
  action: BulkAction;
  /** Called when the dialog closes; `result` is W2's answer when one was received. */
  onClose: (result?: BulkActOnPaymentQueueItemsResultDto) => void;
}

/**
 * The bulk confirmation (design §6.5, AC-PMQ-082): remarks, a department for Reassign, then W2, then one line per
 * record with what happened to it. Not atomic: a partial success is shown as it is, never as a failure.
 */
export function BulkActionDialog({ rows, action, onClose }: Props) {
  const { t } = usePaymentQueueTranslation();
  const [remarks, setRemarks] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [failure, setFailure] = useState<string | null>(null);
  const [result, setResult] = useState<BulkActOnPaymentQueueItemsResultDto | null>(null);
  const bulk = useBulkAction();
  // One id per request content: a retry of the same click reuses it, an edited request gets a fresh one.
  const requestId = useRef<{ key: string; id: string } | null>(null);

  const isReassign = action === 'Reassign';
  const targets = useQuery({
    queryKey: paymentQueueKeys.reassignTargets(rows[0].id),
    queryFn: () => paymentQueueApi.reassignTargets(rows[0].id),
    enabled: isReassign,
  });

  const trimmed = remarks.trim();
  const ready = trimmed !== '' && (!isReassign || departmentId !== '');

  function buildRequest(): BulkActOnPaymentQueueItemsRequest {
    const key = JSON.stringify([action, trimmed, departmentId, rows.map((r) => r.id)]);
    if (requestId.current?.key !== key) requestId.current = { key, id: crypto.randomUUID() };
    return {
      queueEntryIds: rows.map((r) => r.id),
      action: ACTION_CODE[action],
      remarks: trimmed,
      ...(isReassign ? { targetDepartmentId: Number(departmentId) } : {}),
      clientRequestId: requestId.current.id,
      expectedStateIds: Object.fromEntries(rows.map((r) => [r.id, r.currentStateId])),
    };
  }

  function confirm() {
    setFailure(null);
    bulk.mutate(buildRequest(), {
      onSuccess: setResult,
      onError: (error) => {
        const { status, detail } = paymentQueueProblem(error);
        setFailure(status === 0 ? t('BULK.NO_ANSWER') : (detail ?? t('BULK.REFUSED')));
      },
    });
  }

  function close() {
    if (!bulk.isPending) onClose(result ?? undefined);
  }

  const actionName = bulkActionLabel(t, action);

  return (
    <Dialog
      open
      onOpenChange={(open) => {
        if (!open) close();
      }}
      title={result ? t('BULK.TITLE_RESULTS', { action: actionName }) : t('BULK.TITLE', { action: actionName })}
      description={result ? undefined : t('BULK.DESCRIPTION', { action: actionName, total: rows.length })}
      maxWidth="sm:max-w-2xl"
      footer={
        result ? (
          <Button size="sm" onClick={close}>
            {t('COMMON.CLOSE')}
          </Button>
        ) : (
          <>
            <Button variant="ghost" size="sm" onClick={close} disabled={bulk.isPending}>
              {t('COMMON.CANCEL')}
            </Button>
            <Button size="sm" onClick={confirm} disabled={!ready} loading={bulk.isPending}>
              {failure ? t('COMMON.RETRY') : t('BULK.CONFIRM', { action: actionName })}
            </Button>
          </>
        )
      }
    >
      {result ? (
        <BulkResults t={t} rows={rows} result={result} />
      ) : (
        <div className="flex flex-col gap-3">
          {isReassign && (
            <div className="flex flex-col gap-1">
              {targets.isError ? (
                <p role="alert" className="text-sm text-[var(--accent-red)]">
                  {t('BULK.DEPARTMENTS_FAILED')}
                </p>
              ) : (
                <Select
                  label={t('BULK.DEPARTMENT_LABEL')}
                  placeholder={targets.isPending ? t('BULK.DEPARTMENTS_LOADING') : t('BULK.SELECT_DEPARTMENT')}
                  disabled={targets.isPending}
                  value={departmentId}
                  onValueChange={setDepartmentId}
                  options={(targets.data ?? []).map((target) => ({
                    value: String(target.departmentId),
                    label: target.noEligibleActor
                      ? t('BULK.NOBODY_CAN_ACT', { name: target.departmentName })
                      : target.departmentName,
                    disabled: target.noEligibleActor,
                  }))}
                />
              )}
            </div>
          )}
          <Textarea
            label={t('BULK.REMARKS')}
            rows={3}
            required
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
            placeholder={t('BULK.REMARKS_PLACEHOLDER')}
          />
          {failure && (
            <p role="alert" className="text-sm text-[var(--accent-red)]">
              {failure}
            </p>
          )}
        </div>
      )}
    </Dialog>
  );
}

function BulkResults({
  t,
  rows,
  result,
}: {
  t: PaymentQueueT;
  rows: PaymentQueueRow[];
  result: BulkActOnPaymentQueueItemsResultDto;
}) {
  const reference = new Map(rows.map((r) => [r.id, r.systemReferenceNo]));
  const applied = result.results.filter((r) => r.status === 'applied').length;
  const notApplied = result.results.length - applied;

  return (
    <div className="flex flex-col gap-3">
      <p role="status" className="text-sm">
        {notApplied > 0 ? t('BULK.SUMMARY_PARTIAL', { applied, notApplied }) : t('BULK.SUMMARY_ALL', { applied })}
      </p>
      <div className="table-holder overflow-x-auto rounded-lg border border-[var(--border)]">
        <table aria-label={t('BULK.RESULTS_TABLE')}>
          <thead>
            <tr>
              <th>{t('BULK.RECORD')}</th>
              <th>{t('BULK.RESULT_HEAD')}</th>
              <th>{t('BULK.DETAILS')}</th>
            </tr>
          </thead>
          <tbody>
            {result.results.map((r) => (
              <tr key={r.queueEntryId}>
                <td>{reference.get(r.queueEntryId) ?? r.queueEntryId}</td>
                <td>{RESULT_KEY[r.status] ? t(RESULT_KEY[r.status]) : r.status}</td>
                <td>{r.message ?? '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
