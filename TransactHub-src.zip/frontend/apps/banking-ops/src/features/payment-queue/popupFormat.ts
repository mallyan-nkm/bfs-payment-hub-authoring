import type { PaymentQueueT } from './i18n';

/** Shown for a value the server could not supply. Never zero: a missing amount is not 0.00 (AC-PMQ-077). */
export const NOT_AVAILABLE = '—';

/** `AED 20,465.75`: two decimals, the currency code in front. */
export function fmtMoney(amount: number, currency: string): string {
  return `${currency} ${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/** R5's Elapsed (whole seconds as of the response) as "1h 5m" / "12m", the units in the reader's language. */
export function fmtElapsed(t: PaymentQueueT, seconds: number): string {
  const minutes = Math.max(0, Math.round(seconds / 60));
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return hours > 0 ? t('DRAWER.ELAPSED_HM', { hours, minutes: rest }) : t('DRAWER.ELAPSED_M', { minutes: rest });
}
