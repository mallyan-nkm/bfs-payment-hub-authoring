import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { PageBody, PageShell, cn } from '@paymenthub/ui';
import { Wallet, Globe, Landmark, Briefcase, TriangleAlert } from 'lucide-react';
import { useRailAccess } from '../../shared/auth/rails';

type Screen = 'category' | 'rail-selection';
type PaymentRail = 'IPI' | 'UAEFTS' | 'WPS' | 'IPP';

interface PaymentCategory {
  id: string;
  icon: string;
  label: string;
  description: string;
  rails: string;
  enabled: boolean;
  comingSoon?: boolean;
}

interface RailOption {
  code: PaymentRail;
  icon: React.ReactNode;
  label: string;
  description: string;
  enabled: boolean;
}

const PAYMENT_CATEGORIES: PaymentCategory[] = [
  {
    id: 'domestic',
    icon: '🏠',
    label: 'Domestic Payments',
    description: 'IPI · UAEFTS · WPS · IPP — AED transfers within UAE',
    rails: '',
    enabled: true,
  },
  {
    id: 'crossborder',
    icon: '🌍',
    label: 'Cross Border Payments',
    description: 'International AED and foreign currency transfers',
    rails: '',
    enabled: false,
    comingSoon: true,
  },
];

const RAILS: RailOption[] = [
  { code: 'IPI', icon: <Wallet size={18} />, label: 'IPI', description: 'Real-time AED', enabled: true },
  { code: 'UAEFTS', icon: <Landmark size={18} />, label: 'UAEFTS', description: 'AED interbank', enabled: true },
  { code: 'WPS', icon: <Briefcase size={18} />, label: 'WPS', description: 'Salary', enabled: true },
  { code: 'IPP', icon: <Globe size={18} />, label: 'IPP', description: 'Card & merchant', enabled: true },
];

// Rail access comes from the shared helper (shared/auth/rails.ts) so this screen, the sidebar and
// the three dashboards cannot disagree about whether the tile labelled UAEFTS is the rail coded
// FTS, or the one labelled IPP is the rail coded NPSS. Both are aliases resolved there, so the
// IPP tile answers to rail:NPSS:access. `allows()` still passes genuine non-rails through — SWIFT
// and Master Card are not gated by this mechanism rather than being hidden behind a permission
// nobody can hold.

/**
 * New Payment — category then rail selection. Port of the Angular `app-new-payment`.
 *
 * Two screens in one page: pick a payment category, then a primary rail. Only WPS has a
 * downstream initiation screen today; the other rails are selectable but not yet wired, which
 * mirrors the Angular component (its switch logs and goes nowhere for IPI / UAEFTS / IPP).
 */
export function NewPaymentPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const { allows } = useRailAccess();

  // ?category=domestic deep-links straight to rail selection, as the Angular route does.
  const initialCategory = params.get('category');
  const [screen, setScreen] = useState<Screen>(initialCategory === 'domestic' ? 'rail-selection' : 'category');
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory === 'domestic' ? 'domestic' : '');
  const [selectedRail, setSelectedRail] = useState<PaymentRail | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const selectCategory = (category: PaymentCategory) => {
    if (!category.enabled) return;
    setSelectedCategory(category.id);
    if (category.id === 'domestic') setScreen('rail-selection');
  };

  const selectRail = (rail: RailOption) => {
    // Re-checked here and not only on the tile: `disabled` is a rendering hint, and this is the
    // one path that navigates. The route guard on /wps/initiate refuses it again anyway.
    if (!rail.enabled || !allows(rail.code)) return;
    setSelectedRail(rail.code);
    if (rail.code === 'WPS') {
      navigate(`/wps/initiate?category=${selectedCategory || 'domestic'}`);
      return;
    }
    // No initiation screen exists for these rails yet — say so rather than dead-ending.
    setNotice(`${rail.label} initiation is not yet available. WPS is the only rail wired end to end today.`);
  };

  const goBack = () => {
    if (screen === 'rail-selection') {
      setScreen('category');
      setSelectedRail(null);
      setNotice(null);
    } else {
      navigate('/dashboard');
    }
  };

  return (
    <PageShell>
      <PageBody>
        {screen === 'category' ? (
          <div className="mx-auto w-full max-w-[640px] py-8">
            <div className="mb-9 text-center">
              <p className="text-[22px] font-bold text-[var(--text-primary)]">New Payment</p>
              <p className="mt-2 text-[13px] text-[var(--text-secondary)]">Select the payment type to continue</p>
            </div>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              {PAYMENT_CATEGORIES.map((category) => (
                <button
                  key={category.id}
                  type="button"
                  onClick={() => selectCategory(category)}
                  disabled={!category.enabled}
                  className={cn(
                    'flex flex-col items-center rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-6 text-center shadow-[var(--shadow-sm)] transition-colors',
                    category.enabled
                      ? 'cursor-pointer hover:border-[var(--accent)] hover:bg-[var(--bg-card-hover)]'
                      : 'cursor-not-allowed opacity-60',
                  )}
                >
                  <span className="mb-3 text-4xl" aria-hidden="true">{category.icon}</span>
                  <span className="mb-2 text-[15px] font-bold text-[var(--text-primary)]">{category.label}</span>
                  <span className="flex-1 text-xs leading-relaxed text-[var(--text-secondary)]">
                    {category.rails && <>{category.rails}<br /></>}
                    {category.description}
                  </span>
                  {category.comingSoon ? (
                    <span className="mt-4 inline-block rounded bg-[var(--bg-secondary)] px-2.5 py-1 text-[11px] font-semibold text-[var(--text-secondary)]">
                      Coming Soon
                    </span>
                  ) : (
                    <span className="mt-4 text-sm font-bold text-[var(--accent-cyan)]">Select →</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className=" w-full">
            <div className='flex gap-3 items-center py-3'>
              <button
                onClick={goBack}
                className=" plain-btn" title='Back to Category'
              >
                ←
              </button>
              <h1 className="truncate text-[18px] sm:text-[20px] lg:text-[20px] font-black text-[var(--text-primary)]">Select Primary Payment Rail</h1>
            </div>


            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {RAILS.map((rail) => {
                const active = selectedRail === rail.code;
                // Two separate reasons a tile can be dead, and they must not be conflated:
                // `enabled` is whether the rail is built, `granted` is whether this session may
                // use it. Folded into the existing disabled state rather than wrapped in <Can>
                // so there stays one rendering path for a rail tile.
                const granted = allows(rail.code);
                const usable = rail.enabled && granted;
                return (
                  <button
                    key={rail.code}
                    type="button"
                    onClick={() => selectRail(rail)}
                    disabled={!usable}
                    title={rail.enabled && !granted ? 'You do not have access to this rail.' : undefined}
                    className={cn(
                      'rail-card',
                      active ? 'rail-card-selected' : '',
                      usable ? 'cursor-pointer' : 'cursor-not-allowed',
                    )}
                  >
                    <span className="rail-icon" aria-hidden="true">
                      {rail.icon}
                    </span>
                    <span className="rail-text text-left">
                      <span className="block text-sm font-bold text-[var(--text-primary)]">{rail.label}</span>
                      <span className="block text-xs text-[var(--text-muted)]">{rail.description}</span>
                    </span>
                    {active && <span className="text-lg font-bold text-[var(--accent-green)]">✓</span>}
                    {/* A rail withheld by permission must not read as "Coming Soon" — that
                        tells the user to wait for something that already exists, and buries a
                        request they could actually make. */}
                    {!rail.enabled ? (
                      <span className="rounded bg-[var(--bg-secondary)] px-2 py-0.5 text-[10px] font-semibold text-[var(--text-muted)]">
                        Coming Soon
                      </span>
                    ) : !granted ? (
                      <span className="rounded bg-[var(--bg-secondary)] px-2 py-0.5 text-[10px] font-semibold text-[var(--text-muted)]">
                        No Access
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>


            {notice && (
              <p className="badge-warning flex gap-3 w-full mt-3">
                <span><TriangleAlert size={14} /></span>
                {notice}
              </p>

            )}
          </div>
        )}
      </PageBody>
    </PageShell>
  );
}
