/**
 * The shapes the Roles &amp; Screens administration surface returns — design §5 and §7.
 *
 * **This is not the policy surface.** That is `/api/iam/policy/*`, behind ITPS's Access Control
 * screen, where a write grants a key to a role immediately. Everything here goes through
 * `/api/iam/{roles,screens,change-requests}`, where a write is a *proposal* that changes nothing
 * until a Checker approves it — unless the action is configured Maker-only (see
 * {@link ChangeWorkflowResponse}), in which case the submit applies it at once and says so. The two are kept in separate files for the same reason they are on
 * separate prefixes: a reader who cannot tell which of the two they are looking at cannot tell
 * whether the call they are about to make takes effect.
 */

/**
 * A role's lifecycle state.
 *
 * `Pending` is a real state, not a UI flag: a role created through the Maker-Checker path exists as
 * a row from the moment it is proposed — so the list can show that somebody asked for it — and
 * `Pending` is what keeps it out of every grant path until a Checker agrees. `Deleted` never
 * reaches the browser; the list endpoint filters it.
 */
export type RoleStatus = 'Active' | 'Disabled' | 'Pending' | 'Deleted';

/** What a Maker can propose. Mirrors `AdminChangeAction` on the server. */
export type AdminChangeAction =
  | 'NewRole'
  | 'ModifyRole'
  | 'DeleteRole'
  | 'ModifyScreenMapping'
  | 'ModifyScreenConfig'
  | 'NewScreen'
  | 'ModifyScreen'
  | 'DeleteScreen'
  | 'EnableScreen'
  | 'DisableScreen'
  | 'ScreenConfig';

/**
 * Where a proposal has got to.
 *
 * `Approved` means a Checker agreed but the change carries a future `effectiveFrom`: it is
 * **scheduled**, not in force, and the server's scheduler applies it on that date. Until then it
 * holds the entity's one pending slot exactly as `Pending` does.
 */
export type AdminChangeStatus = 'Pending' | 'Approved' | 'Applied' | 'Rejected' | 'Withdrawn';

/**
 * The newest change request for an entity, whatever its state.
 *
 * "Last Action" means the last thing that *happened* to this role, so a rejection is one of those
 * things and appears here. `checkerBy` is null exactly when nobody has ruled on it yet, which is
 * also what makes the row's Edit action live — see {@link RoleRow}.
 */
export interface LastAction {
  id: number;
  action: AdminChangeAction;
  status: AdminChangeStatus;
  makerBy: string | null;
  makerAt: string | null;
  checkerBy: string | null;
  checkerAt: string | null;
}

/** One row of the Roles list — `GET /api/iam/roles`. */
export interface RoleRow {
  id: number;
  roleName: string;
  description: string | null;
  baseRole: string | null;
  status: RoleStatus;
  createdAt: string | null;
  createdBy: string | null;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;

  /**
   * Users whose assignment is currently inside its validity window.
   *
   * Counted from the assignment rows rather than from the compiled sets: a user whose assignment
   * has expired is not a user of this role, and the window is the only place that says so.
   */
  totalUsers: number;

  lastAction: LastAction | null;
}

/** The paged envelope the list endpoint returns. */
export interface RoleListResponse {
  total: number;
  page: number;
  pageSize: number;
  roles: RoleRow[];
}

/** Query parameters for the Roles list. */
export interface RoleListParams {
  /** One {@link RoleStatus}, or undefined for every status the endpoint returns. */
  status?: RoleStatus;
  page?: number;
  pageSize?: number;
}

/**
 * The base roles this release deploys — `GET /api/iam/base-roles`.
 *
 * **A base role filters; it never grants.** It decides which screens the Screen Mapping panel
 * offers a role and nothing else — it is never a bit in a compiled permission set, and it is never
 * consulted to decide a request. `editable` is always false: Screens FSD §2.3 puts the list in the
 * release, so there is no write endpoint beside the read, and the flag travels on the response so
 * the form can say why the dropdown has no "add" beside it.
 */
export interface BaseRoleListResponse {
  baseRoles: string[];
  source: string;
  editable: boolean;
}

/** Body for `POST /api/iam/roles`. */
export interface CreateRoleRequest {
  roleName: string;
  description: string | null;

  /**
   * Mandatory here though the column is nullable. The nullability exists for the roles that
   * predate the concept — every one of them maps every screen — and is not a licence to create
   * more of them.
   */
  baseRole: string;

  /** BR-ROLES-005. Whitespace is refused by the server, not merely by the form. */
  makerRemarks: string;

  /** Design §16.2: the rails the role should hold once approved. Omitted entries are left alone. */
  rails?: RailToggle[];
}

/** One rail's proposed state on a role — whether it should hold `rail:<CODE>:access`. */
export interface RailToggle {
  railCode: string;
  enable: boolean;
}

/**
 * One rail on a role's Overview — design §16.2, §16.6. Every deployed rail is listed.
 *
 * `source` says where a held rail comes from; only a `direct` (or unheld) rail on an enabled rail is
 * the role's to move, which is what `editable` already answers.
 */
export interface RoleRailAccess {
  railCode: string;
  held: boolean;
  source: 'direct' | 'inherited' | 'wildcard' | null;
  inheritedFrom: string | null;
  railEnabled: boolean;
  editable: boolean;

  /** The role holds its own row that masks or differs from the ancestor's. Absent on an older backend. */
  overridden?: boolean;
}

/**
 * What an accepted proposal returns — a 201 from every write on this surface.
 *
 * **`status` is usually `Pending`, and that is the point.** The 201 means the request was recorded,
 * never that the change happened; the role, its grants and the policy epoch move only when a
 * Checker approves. Callers render this field rather than inferring success from the status code.
 *
 * The exception is an action the deployment has configured **Maker-only** (design §6.5): the
 * server applies it inside the submit and answers `Applied` — or `Approved` when it carries a
 * future `effectiveFrom` and waits for the scheduler — with `makerOnly: true`. That is still read
 * from `status`, never assumed from the action.
 */
export interface ChangeSubmissionResponse {
  requestId: number;
  action: AdminChangeAction;
  entityKey: string;
  status: AdminChangeStatus;
  message: string;

  /** True when no Checker was involved because the action is configured Maker-only. */
  makerOnly?: boolean;

  /** The epoch an immediate apply bumped to. Null or absent when nothing was bumped. */
  epoch?: number | null;

  /** When a scheduled (`Approved`) change comes into force, when the server says. */
  effectiveFrom?: string | null;
}

/**
 * The approval workflow this deployment runs — `GET /api/iam/change-requests/workflow`.
 *
 * `makerOnlyActions` lists the actions a submit applies immediately, with no Checker; every other
 * action waits for one. `checkerPermission` is the key a Checker must hold (`iam:policy:approve`).
 */
export interface ChangeWorkflowResponse {
  makerOnlyActions: AdminChangeAction[];
  checkerPermission: string;
}

/**
 * The 409 an approve or reject gets when the caller is the request's own Maker.
 *
 * Separation of duties is enforced server-side: a Maker may withdraw their proposal, never rule on
 * it. The body names who submitted it and what to do instead.
 */
export interface MakerIsCheckerConflict {
  requestId: number;
  error: string;
  submittedBy: string;
  remedy: string;
}

/** The deployed rail codes — `GET /api/iam/rails`. What the rails picker and filter offer. */
export interface RailListResponse {
  rails: string[];
}

/**
 * The request currently holding an entity, as the detail endpoints return it.
 *
 * Its presence is the whole answer to "may I edit this?" — one pending request per entity is what
 * the server's concurrency guard enforces, and it is why {@link RoleDetail.editable} is a field
 * rather than something the browser infers from `status`.
 */
export interface PendingRequestSummary {
  id: number;
  action: AdminChangeAction;
  makerBy: string | null;
  makerAt: string | null;
  makerRemarks: string | null;
}

/** One role in full — `GET /api/iam/roles/{roleName}`. */
export interface RoleDetail {
  id: number;
  roleName: string;
  description: string | null;
  baseRole: string | null;
  /** Derived by the server from the base role. Information only — never sent in a request. */
  parentRoleId: number | null;
  isTemplate: boolean;
  isSystemRole: boolean;

  /** True when the role (or an ancestor) holds the `*` grant — every screen and element, read-only. */
  holdsWildcard: boolean;
  status: RoleStatus;
  createdAt: string | null;
  createdBy: string | null;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  deletedAt: string | null;

  /**
   * Users holding this role through an active assignment. Absent when the server does not send it
   * (an older build), which the Delete flow reads as "unknown" and leaves to the server's 409.
   */
  assignedUserCount?: number;

  /**
   * Whether a write on this role would be accepted right now. False exactly when something is
   * awaiting a Checker — read it rather than deriving one from `status`, which answers a different
   * question: a Modify or Delete proposal leaves the role `Active` throughout.
   */
  editable: boolean;
  pendingRequest: PendingRequestSummary | null;

  /** Fields no modify call accepts. `RoleName` is here because renaming detaches every grant. */
  immutableFields: string[];

  /** Rail Access (design §16.2) — every deployed rail and whether this role holds its gate. */
  rails?: RoleRailAccess[];
}

/** Body for `PUT /api/iam/roles/{roleName}`. `roleName` is absent by design. */
export interface ModifyRoleRequest {
  description: string | null;

  /** Required: a role may not be edited into having none. */
  baseRole: string;
  makerRemarks: string;

  /** `Active` or `Disabled`; omitted leaves the role's status as it is. */
  status?: 'Active' | 'Disabled';

  /** Rail toggles riding the same request (design §16.2). Only changed rails need be sent. */
  rails?: RailToggle[];
}

/** Body for `DELETE /api/iam/roles/{roleName}`. The remarks travel in the body, not the query. */
export interface DeleteRoleRequest {
  makerRemarks: string;
}

/**
 * What a role holds on a screen — design §4.2.
 *
 * Two values, not a list of keys, because this is the *intent*: `Viewer` is the page key alone and
 * `Actor` is the page key plus every live actor key the screen declares. The expansion happens
 * server-side at apply time, never here — the set a Checker approves has to be the one that holds
 * when they approve, not the one that held when the form was filled in.
 */
export type AccessPrivilege = 'Actor' | 'Viewer';

/**
 * One row of the Screen Mapping panel — `GET /api/iam/roles/{roleName}/screens`.
 *
 * A row with `mappable: false` is a registered page with no permission key: it gates nothing, so
 * it cannot be mapped. It is listed with its `reason` rather than filtered out, because silence
 * reads as a missing screen to the person hunting for it.
 */
export interface RoleScreenRow {
  app: string;
  pageCode: string;
  screenName: string | null;

  /** The screen's own base roles, comma-delimited. Null or empty means it is offered to all. */
  baseRoles: string | null;

  mappable: boolean;
  /** Why not, when `mappable` is false. Absent otherwise. */
  reason?: string;

  /** The rails the screen is labelled with — its gate rail, else the registry's filter rails. */
  rails?: string[];

  isMapped?: boolean;
  accessPrivilege?: AccessPrivilege | null;

  /**
   * The role is mapped and holds some, but not all, of the keys its privilege expands to.
   *
   * **Reported, never repaired** — design §4.3. Two legitimate routes produce it: an actor key
   * declared after the role was mapped, or a key revoked directly through the policy surface.
   * Re-saving the mapping grants the missing ones through a fresh Maker-Checker cycle; silently
   * re-granting them on read would be a permission change with no maker, no checker and no audit.
   */
  isPartial?: boolean;
  missingKeys?: string[];
  expectedKeyCount?: number;
  heldKeyCount?: number;

  /**
   * Live inheritance from the role's base-role template. An inherited row is still the role's to
   * change: the change writes an override on this role only and the template is untouched.
   */
  isInherited?: boolean;
  inheritedKeys?: string[];
  inheritedFrom?: InheritedFrom;

  /** The role holds its own row that masks or differs from the ancestor's. Absent on an older backend. */
  overridden?: boolean;
}

/** The ancestor role(s) an inherited item comes from — a name, or a list, depending on the endpoint. */
export type InheritedFrom = string | string[] | null;

/** The Screen Mapping panel's envelope. */
export interface RoleScreenListResponse {
  role: string;
  baseRole: string | null;
  screens: RoleScreenRow[];
}

/**
 * Body for `PUT /api/iam/roles/{roleName}/screens/{pageCode}/mapping`.
 *
 * `accessPrivilege` and `unmap` are mutually exclusive, and the server refuses a body that sets
 * both — an unmap carrying a privilege does not say which of the two the caller meant.
 */
export interface ScreenMappingRequest {
  accessPrivilege?: AccessPrivilege | null;
  unmap?: boolean;
  makerRemarks: string;
}

/**
 * One element on a Screen Config panel — design §5.4.
 *
 * `enable` means two different things at the two levels, deliberately. At **base** level it is
 * whether the element is live at all: the ceiling every role inherits, and a disabled one compiles
 * to zero bits however many roles hold its key. At **role** level it is whether this role holds
 * the key. A role can narrow the ceiling; it can never raise it.
 */
export interface ScreenConfigItem {
  permissionKey: string | null;

  /** `Page`, `Component`, `Rail` or `Service`. */
  kind: string;
  componentCode: string | null;

  /** What the element is — button, grid, field. `*` where the register names none. */
  componentType: string;
  category: string | null;

  /**
   * The Elements column: the element's name — `UiScreenRegistry.ScreenName`. A free-text component code is
   * never shown there; the panel falls back to it only when this is empty.
   */
  elementName?: string | null;

  /**
   * The Description column — `UiScreenRegistry.Description`. Until that column exists the API sends
   * `ScreenName` here, which carried the description before it did.
   */
  description?: string | null;

  /**
   * The Element Data List column: the child controls grouped under this element —
   * `UiScreenRegistry.ElementDataList`, a JSON array of strings, shown one per line. Always null on a Page row
   * (the screen itself), and null where the element groups nothing.
   */
  dataList?: string[] | null;

  /** Both levels: the rail a rail element stands for (`rail:WPS:access` is `WPS`). Empty for every other element. */
  rails?: string[];
  enable: boolean;

  /**
   * Role level: the render mode the grant sets. Base level: the element's default render mode
   * (`UiScreenRegistry.DefaultUiMode`), inherited by every role that sets none of its own — a
   * role-level mode wins. Null for "no opinion".
   */
  uiMode?: string | null;

  /** Role level only: the epoch the grant was written at. */
  grantedAtEpoch?: number | null;

  /**
   * Both levels: the render modes this element's component type can actually honour, read from
   * `platform.UiRenderMode`. Empty means the type has no row and no fallback — offer nothing
   * rather than all six, since a control that looks gated and is fully usable misreports a
   * restriction that does not exist.
   */
  allowedEditableModes?: string[];

  /**
   * Role level only (design §16.3): `RailAccess` when the element is a rail gate. It is granted on
   * the role's Overview, never here, so the row is read-only and the server refuses a change to it.
   */
  governedBy?: string | null;

  /** Role level only: the grant comes from the role's base-role template. Still togglable — a change is an override. */
  inherited?: boolean;
  inheritedFrom?: InheritedFrom;

  /** Role level only: the role holds its own row that masks or differs from the ancestor's. Absent on an older backend. */
  overridden?: boolean;
}

/** `GET /api/iam/roles/{roleName}/screens/{pageCode}/config`. */
export interface RoleScreenConfigResponse {
  role: string;
  app: string;
  pageCode: string;

  /** True when the role holds the `*` grant: every element is granted and nothing is editable. */
  holdsWildcard?: boolean;
  items: ScreenConfigItem[];

  /**
   * How many elements were left out because the screen has them disabled.
   *
   * A count, not the elements: showing them greyed invites a toggle the save will refuse, and an
   * unexplained shorter list is worse than either.
   */
  hiddenElementCount: number;
  hiddenElementsReason: string | null;
  screenDetailLink: string;
}

/** `GET /api/iam/screens/{pageCode}/config` — every element, disabled ones included. */
export interface ScreenBaseConfigResponse {
  app: string;
  pageCode: string;
  level: 'base';
  /** False until the database carries `DefaultUiMode`; no default mode can be offered then. */
  supportsDefaultMode?: boolean;
  items: ScreenConfigItem[];
}

/**
 * Body for both Screen Config saves.
 *
 * **Every element the panel showed, not just the changed ones.** One save per screen is what makes
 * the whole change one epoch bump instead of one per toggle — and at role level the apply
 * reconciles the screen's in-scope set rather than this payload, so an element the panel did not
 * show is left exactly as it is rather than silently revoked.
 */
export interface ScreenConfigSaveRequest {
  items: { permissionKey: string; enable: boolean; uiMode?: string | null }[];
  makerRemarks: string;
}

/**
 * The 409 a role-level save gets when it tries to enable an element the screen has disabled.
 *
 * `applied: false` is stated on the wire rather than inferred, because the natural assumption about
 * a partial failure is the opposite one — and an administrator who believes four of five toggles
 * landed will not re-save.
 */
export interface ScreenConfigConflict {
  error: string;
  elements: string[];
  reason: string;
  remedy: string;
  applied: false;
}

// ─── Change requests — the Checker's surface ─────────────────────────────────

/**
 * One change request in full — `GET /api/iam/change-requests` and `/{id}`.
 *
 * **This is the audit trail.** Every write on this feature lands here first, and the pair of
 * (maker, checker) stamps on one row is what the Audit Trail panel renders as two cards.
 */
export interface ChangeRequest {
  id: number;
  entityType: 'Role' | 'Screen';
  entityKey: string;
  action: AdminChangeAction;
  status: AdminChangeStatus;
  effectiveFrom: string | null;
  makerBy: string | null;
  makerAt: string | null;
  makerRemarks: string | null;
  checkerBy: string | null;
  checkerAt: string | null;
  checkerRemarks: string | null;

  /**
   * The epoch the apply bumped to, or null.
   *
   * Null on a request that is not applied, and also on one that was — a metadata-only screen edit
   * moves nothing the compiler reads, so there is nothing to bump and nothing to announce.
   */
  appliedEpoch: number | null;

  /** The stored proposal, verbatim. The single-request read returns it; the list only on `includePayload`. */
  payload?: string | null;
}

/** The paged envelope the change-request list returns. */
export interface ChangeRequestListResponse {
  total: number;
  page: number;
  pageSize: number;
  requests: ChangeRequest[];
}

/** Query parameters for the change-request list. */
export interface ChangeRequestListParams {
  entityType?: 'Role' | 'Screen';
  entityKey?: string;
  status?: AdminChangeStatus;
  page?: number;
  pageSize?: number;
  /** Return each request's payload too — the Audit Trail diffs consecutive proposals with it. */
  includePayload?: boolean;
}

// ─── Audit trail — platform.AdminAudit ───────────────────────────────────────

/**
 * One row of the shared user-management audit table — `GET /api/iam/roles/{roleName}/audit` and
 * `GET /api/iam/screens/{pageCode}/audit`.
 *
 * One row per event: a Maker's submission (`action` is the request's own action, e.g.
 * `ModifyScreenMapping`), or a decision on it (`Applied`, `Approved` — i.e. scheduled — `Rejected`,
 * `Withdrawn`). `oldData` / `newData` are the field → value snapshots captured when it happened;
 * a field whose value differs between them is what changed.
 */
export interface AdminAuditEntry {
  auditId: number;
  requestId: number | null;
  action: string;
  section: string;
  userId: string;
  userName: string | null;
  /** `Maker`, `Checker`, or `System` for the scheduler. */
  userRole: string;
  remarks: string;
  changedFields: string[];
  /** Null on a creation, which has no "before". */
  oldData: Record<string, string | null> | null;
  newData: Record<string, string | null> | null;
  actionDate: string;
  /** The change request the row belongs to, as it stands now — null when it has none. */
  request: {
    action: AdminChangeAction;
    status: AdminChangeStatus;
    makerBy: string | null;
    effectiveFrom: string | null;
    appliedEpoch: number | null;
  } | null;
}

/** The paged envelope the audit-trail endpoints return. */
export interface AdminAuditResponse {
  total: number;
  page: number;
  pageSize: number;
  entries: AdminAuditEntry[];
}

/** The filters and paging the audit-trail endpoints take. `from` and `to` are `yyyy-MM-dd`, inclusive. */
export interface AdminAuditQuery {
  section?: string;
  from?: string;
  to?: string;
  page?: number;
  pageSize?: number;
}

/** Body for approve, reject and withdraw. Remarks are optional and recorded when present. */
export interface CheckerVerdict {
  checkerRemarks?: string;
}

// ─── Screens ─────────────────────────────────────────────────────────────────

/**
 * A screen's state, derived rather than stored.
 *
 * `Active` when the page row is live, `Disabled` when it is retired, `Pending` while a request
 * awaits a Checker, and `Rejected` when the newest request was a refused New Screen and nothing is
 * live. Derived, because storing it would be a second copy of what the register already says.
 */
export type ScreenStatus = 'Active' | 'Disabled' | 'Pending' | 'Rejected';

/** One row of the Screens list — `GET /api/iam/screens`. */
export interface ScreenRow {
  app: string;
  screenCode: string;
  screenName: string | null;
  permissionKey: string | null;
  baseRoles: string[];

  /**
   * The catalog's **rail gate**, set by the build — never edited here.
   *
   * This is the one rail that decides access: a user without it cannot reach the screen however
   * the rails below are set. Kept apart from {@link rails} precisely so the two cannot be confused.
   */
  rail: string | null;

  /**
   * Design §17: every rail the screen is gated behind — a user holding **any one** of them reaches it. Editable
   * through Modify / New Screen. The administered set (`platform.ScreenGateRail`); empty for a screen never edited.
   */
  gateRails: string[];

  /** Kept for one release: the first of {@link gateRails}. */
  gateRail: string | null;

  /**
   * Kept for one release; now only ever echoes {@link gateRails}. The registry's rail filter column is gone.
   */
  rails: string[];

  status: ScreenStatus;

  /** The roles behind {@link subRoles} — the live roles linked under the screen's base roles, by name. */
  subRoleNames?: string[];

  /**
   * How many live roles sit under one of the screen's base roles (inherited base role included).
   * Zero when the screen names no base role.
   */
  subRoles: number;

  /** How many roles actually hold it. This is the number the delete guard blocks on. */
  mappedRoleCount: number;

  /** Administrator provenance. Null until somebody acts on the screen through this surface. */
  createdAt: string | null;
  createdBy: string | null;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;

  /** Release provenance — when the seed script last ran, and under whose version stamp. */
  lastSyncedAt: string | null;
  syncedBy: string | null;

  lastAction: LastAction | null;
}

/**
 * The newest request of a Role or Screen when it was rejected — `GET /api/iam/roles/{name}/rejection`, `/screens/{code}/rejection`
 * (204 when the newest request is not a rejection). `canFallbackClose` is true for a non-Maker only when the Maker can no
 * longer act (Admin Approval Queue design §10.3).
 */
export interface RejectedRequest {
  requestId: number;
  action: string;
  makerBy: string;
  checkerBy: string | null;
  checkerRemarks: string | null;
  isRejectedNew: boolean;
  callerIsMaker: boolean;
  canFallbackClose: boolean;
}

/** The Screens list envelope. The endpoint filters and searches server-side, and does not page. */
export interface ScreenListResponse {
  total: number;
  screens: ScreenRow[];
}

/** One element of a screen, as the detail endpoint returns it. */
export interface ScreenElementRow {
  kind: string;
  componentCode: string | null;
  componentType: string | null;
  permissionKey: string | null;
  category: string | null;
  enabled: boolean;
}

/** One screen in full — `GET /api/iam/screens/{pageCode}`. */
export interface ScreenDetail {
  app: string;
  screenCode: string;
  screenName: string | null;
  permissionKey: string | null;
  baseRoles: string[];

  /** The build-owned rail gate. Read-only — see {@link ScreenRow.rail}. */
  rail: string | null;

  /** Every gate rail, any one admits — see {@link ScreenRow.gateRails}. */
  gateRails: string[];

  /** Kept for one release: the first of {@link gateRails}. */
  gateRail: string | null;

  /** Echoes the gate rail — see {@link ScreenRow.rails}. */
  rails: string[];
  status: ScreenStatus;

  /**
   * Roles the screen is mapped to, and users it is assigned to (Screens FSD §5.5.1). Absent when the server does not
   * send them (an older build): Delete Screen then leaves the check to the server's 409.
   */
  assignedRoleCount?: number;
  assignedUserCount?: number;

  /**
   * False for a screen that has a change request but no register row in this database.
   *
   * Not an error state: a New Screen proposal for a code this database has never seeded looks
   * exactly like this, and so does a detail read against a database behind the seed script.
   */
  registered: boolean;
  message?: string;

  isRetired?: boolean;
  deletedAt?: string | null;
  createdAt?: string | null;
  createdBy?: string | null;
  lastModifiedAt?: string | null;
  lastModifiedBy?: string | null;
  lastSyncedAt?: string | null;
  syncedBy?: string | null;

  immutableFields?: string[];
  editable?: boolean;
  pendingRequest?: ChangeRequest | null;

  /** The newest request whatever its state — what the Approver Remarks banner renders from. */
  lastRequest?: ChangeRequest | null;

  items?: ScreenElementRow[];
}

/** Body for `POST /api/iam/screens`. */
export interface CreateScreenRequest {
  app: string;

  /**
   * A code the release seeded is brought live; one it did not seed is registered on approval
   * (04-10-2026). Letters, digits and hyphens, at most 100 characters.
   */
  screenCode: string;
  screenName: string;
  baseRoles: string[];

  /** Design §17: the gate rails, any one admits. Required, at least one: the picker is the only source. */
  gateRails?: string[];

  makerRemarks: string;
}

/**
 * Body for `PUT /api/iam/screens/{pageCode}`. `screenCode` is absent by design — it is the key.
 * `gateRails` (design §17) is the whole set, any one admits; omitted = unchanged, empty = ungated.
 */
export interface ModifyScreenRequest {
  app: string;
  screenName: string;
  baseRoles: string[];
  gateRails?: string[];
  makerRemarks: string;
}

/** `GET /api/iam/screens/lookup` — what New Screen would be told for a typed code (design §16.5). */
export interface ScreenLookupResponse {
  app: string;
  screenCode: string;

  /** Listed by the release in `platform.Screen`. */
  exists: boolean;

  /** Already live — a submit would be refused as a duplicate. */
  registered: boolean;
  screenName: string | null;

  /** Design §17: the gate rails the New Screen picker starts from — the screen's earlier administered rails, else empty. */
  gateRails?: string[];
  gateRail: string | null;

  /** The refusal a submit would receive, or null when it would be accepted. */
  refusal: string | null;
}

/** Body for delete, enable and disable. The app travels in the body on all three. */
export interface ScreenActionRequest {
  app: string;
  makerRemarks: string;
}

/**
 * The 409 a screen delete gets while roles still hold it.
 *
 * Deliberately a refusal rather than a cascade: the administrator deleting a screen is usually not
 * the one who granted it, and a cascade would make a deletion silently revoke permissions across
 * roles they have never looked at.
 */
export interface ScreenDeleteConflict {
  error: string;
  blockedBy: string[];
  remedy: string;
}
