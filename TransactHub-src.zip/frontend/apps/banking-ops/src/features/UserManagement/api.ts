import { bankingApi } from '../../shared/api/bankingApi';
import type {
  AdminAuditQuery,
  AdminAuditResponse,
  BaseRoleListResponse,
  ChangeRequest,
  ChangeRequestListParams,
  ChangeRequestListResponse,
  ChangeSubmissionResponse,
  ChangeWorkflowResponse,
  CheckerVerdict,
  CreateRoleRequest,
  CreateScreenRequest,
  DeleteRoleRequest,
  MakerIsCheckerConflict,
  ModifyScreenRequest,
  ModifyRoleRequest,
  RailListResponse,
  ScreenLookupResponse,
  RoleDetail,
  RoleListParams,
  RoleListResponse,
  RoleScreenConfigResponse,
  RoleScreenListResponse,
  ScreenActionRequest,
  ScreenBaseConfigResponse,
  ScreenConfigConflict,
  ScreenConfigSaveRequest,
  ScreenDetail,
  ScreenListResponse,
  ScreenMappingRequest,
  RejectedRequest,
} from './types';

/**
 * Query parameters for the Screens list. `rail` matches the screen's rail *filter* (`rails`), not
 * its build-owned gate.
 */
export interface ScreenListParams {
  app?: string;
  status?: string;
  search?: string;
  rail?: string;
}

/**
 * The Roles &amp; Screens administration surface, from the browser.
 *
 * `bankingApi` is scoped to baseURL `/api`, so paths here omit that prefix.
 *
 * **Nothing here takes effect on its own.** Every write on this surface records a
 * `platform.AdminChangeRequest` and stops; the grant rows, the status changes and the epoch bump
 * happen when a Checker approves through `/api/iam/change-requests/{id}/approve`. A 201 from any of
 * these means "recorded, awaiting approval", never "done" — and the response says so in `status`,
 * which is why callers render that field rather than inferring success from the status code.
 *
 * The one exception is an action the deployment has configured **Maker-only**
 * ({@link rolesScreensApi.getWorkflow}): the submit applies it and answers `Applied` (or `Approved`
 * when it is scheduled for a future date) with `makerOnly: true`.
 */
export const rolesScreensApi = {
  /**
   * The Roles list — `GET /api/iam/roles`.
   *
   * Soft-deleted roles are filtered server-side, so there is no client-side "hide deleted": a
   * deleted role keeps its grants and its audit history, but it is assignable to nobody, and
   * listing it invites an administrator to edit something that cannot take effect.
   */
  listRoles: (params: RoleListParams = {}) =>
    bankingApi
      .get<RoleListResponse>('/iam/roles', {
        params: {
          status: params.status,
          page: params.page,
          pageSize: params.pageSize,
        },
      })
      .then((r) => r.data),

  /**
   * The deployed base roles — `GET /api/iam/base-roles`.
   *
   * Fetched rather than hard-coded in the browser. The list is declared by the release, and a
   * second copy here would go stale the first time the release changed it — offering an
   * administrator a base role no screen has heard of, whose Screen Mapping panel is then empty
   * with nothing anywhere to say why.
   */
  listBaseRoles: () =>
    bankingApi.get<BaseRoleListResponse>('/iam/base-roles').then((r) => r.data),

  /**
   * The deployed rail codes — `GET /api/iam/rails`.
   *
   * Fetched for the same reason as the base roles: the list ships with the release, and a copy
   * here would offer a rail the server then refuses with a 400.
   */
  listRails: () => bankingApi.get<RailListResponse>('/iam/rails').then((r) => r.data),

  /**
   * Propose a new role — `POST /api/iam/roles`.
   *
   * The role row is created in `Pending` so the list can show that somebody asked for it. It
   * grants nothing, and it is not usable, until a Checker approves through
   * `/api/iam/change-requests/{id}/approve`.
   */
  createRole: (body: CreateRoleRequest) =>
    bankingApi.post<ChangeSubmissionResponse>('/iam/roles', body).then((r) => r.data),

  /**
   * One role in full — `GET /api/iam/roles/{roleName}`.
   *
   * Carries `editable` and the request holding the role, which is what the detail screen greys its
   * Edit and Delete controls on. The same condition the server's concurrency guard refuses on, so
   * the two cannot disagree about whether a write would be accepted.
   */
  getRole: (roleName: string) =>
    bankingApi.get<RoleDetail>(`/iam/roles/${encodeURIComponent(roleName)}`).then((r) => r.data),

  /**
   * Propose an edit — `PUT /api/iam/roles/{roleName}`.
   *
   * **The role stays `Active` throughout.** Moving it to `Pending` while a description edit waited
   * for a Checker would log every user of the role out of the screens it grants.
   */
  modifyRole: (roleName: string, body: ModifyRoleRequest) =>
    bankingApi
      .put<ChangeSubmissionResponse>(`/iam/roles/${encodeURIComponent(roleName)}`, body)
      .then((r) => r.data),

  /**
   * Propose a soft delete — `DELETE /api/iam/roles/{roleName}`.
   *
   * The role stays `Active` and usable until the delete is applied, and its grants stay where they
   * are afterwards: they are the record of what it held, and the only thing that makes the delete
   * reversible. The remarks travel in the body, which is why this uses axios's `data` option.
   */
  deleteRole: (roleName: string, body: DeleteRoleRequest) =>
    bankingApi
      .delete<ChangeSubmissionResponse>(`/iam/roles/${encodeURIComponent(roleName)}`, { data: body })
      .then((r) => r.data),

  /**
   * The Screen Mapping panel — `GET /api/iam/roles/{roleName}/screens`.
   *
   * **`app` is deliberately not passed.** It is optional on this route and required on the write
   * below, and every row comes back carrying its own — so the panel lists every app at once and
   * the save uses the row's app rather than a picker whose value could disagree with the row the
   * person clicked.
   *
   * The screens are already filtered to the role's base role server-side. A role with no base role
   * is offered all of them, which is the reading the roles that predate the concept need.
   */
  listRoleScreens: (roleName: string) =>
    bankingApi
      .get<RoleScreenListResponse>(`/iam/roles/${encodeURIComponent(roleName)}/screens`)
      .then((r) => r.data),

  /**
   * Propose an Access Privilege on one screen —
   * `PUT /api/iam/roles/{roleName}/screens/{pageCode}/mapping`.
   *
   * Records a proposal and moves no grant. Actor and Viewer are expanded to ordinary grant rows at
   * apply time, not here.
   */
  setScreenMapping: (
    roleName: string,
    app: string,
    pageCode: string,
    body: ScreenMappingRequest,
  ) =>
    bankingApi
      .put<ChangeSubmissionResponse>(
        `/iam/roles/${encodeURIComponent(roleName)}/screens/${encodeURIComponent(pageCode)}/mapping`,
        body,
        { params: { app } },
      )
      .then((r) => r.data),

  /**
   * Several screens of one role in one save — `PUT /api/iam/roles/{roleName}/screen-mapping`.
   *
   * One change request, one remark, applied together; all or nothing. A Disabled role is refused
   * 409, and a screen that cannot be mapped refuses the whole save with every offender named.
   */
  setScreenMappingBatch: (
    roleName: string,
    body: {
      items: Array<{ app: string; pageCode: string; accessPrivilege?: string; unmap?: boolean }>;
      makerRemarks: string;
    },
  ) =>
    bankingApi
      .put<ChangeSubmissionResponse>(`/iam/roles/${encodeURIComponent(roleName)}/screen-mapping`, body)
      .then((r) => r.data),

  /**
   * A role's element-level configuration for one screen —
   * `GET /api/iam/roles/{roleName}/screens/{pageCode}/config`.
   *
   * Elements the screen has disabled are **omitted**, not returned greyed. The screen-level Enable
   * is a ceiling no role-level save can raise, so a toggle for one would be a control whose effect
   * the save refuses. `hiddenElementCount` says how many were left out.
   */
  getRoleScreenConfig: (roleName: string, app: string, pageCode: string) =>
    bankingApi
      .get<RoleScreenConfigResponse>(
        `/iam/roles/${encodeURIComponent(roleName)}/screens/${encodeURIComponent(pageCode)}/config`,
        { params: { app } },
      )
      .then((r) => r.data),

  /** Propose a role-level Screen Config save. Refused 409 *whole* if it enables a disabled element. */
  setRoleScreenConfig: (
    roleName: string,
    app: string,
    pageCode: string,
    body: ScreenConfigSaveRequest,
  ) =>
    bankingApi
      .put<ChangeSubmissionResponse>(
        `/iam/roles/${encodeURIComponent(roleName)}/screens/${encodeURIComponent(pageCode)}/config`,
        body,
        { params: { app } },
      )
      .then((r) => r.data),

  /**
   * A screen's base-level configuration — `GET /api/iam/screens/{pageCode}/config`.
   *
   * Returns **every** element, disabled ones included. The asymmetry with the role-level read is
   * the point: switching a disabled element back on is what this panel is for, and it is the only
   * surface that can.
   */
  getScreenBaseConfig: (app: string, pageCode: string) =>
    bankingApi
      .get<ScreenBaseConfigResponse>(`/iam/screens/${encodeURIComponent(pageCode)}/config`, {
        params: { app },
      })
      .then((r) => r.data),

  /**
   * Propose a base-level Screen Config save — the ceiling every role inherits.
   *
   * Disabling an element here makes every role's grant for it inert at once **without touching a
   * grant row**: a retired register row compiles to zero bits. That is why re-enabling restores
   * every role exactly, with nobody having recorded what to restore.
   */
  setScreenBaseConfig: (app: string, pageCode: string, body: ScreenConfigSaveRequest) =>
    bankingApi
      .put<ChangeSubmissionResponse>(
        `/iam/screens/${encodeURIComponent(pageCode)}/config`,
        body,
        { params: { app } },
      )
      .then((r) => r.data),

  // ─── Screens ──────────────────────────────────────────────────────────────

  /**
   * The Screens list — `GET /api/iam/screens`.
   *
   * Filters and searches **server-side** and returns the whole matching set unpaged, which is why
   * this one has no page parameter and the Roles list does. Soft-deleted screens are excluded.
   * `rail` matches one of the screen's gate rails (`gateRails`, design §17).
   */
  listScreens: (params: ScreenListParams = {}) =>
    bankingApi.get<ScreenListResponse>('/iam/screens', { params }).then((r) => r.data),

  /**
   * Check a typed Screen Code before proposing it — `GET /api/iam/screens/lookup` (design §16.5).
   * Answers what a submit would be told, plus the release's Screen Name and any earlier administered rails.
   */
  lookupScreen: (app: string, code: string) =>
    bankingApi.get<ScreenLookupResponse>('/iam/screens/lookup', { params: { app, code } }).then((r) => r.data),

  /** One screen with its elements and its newest change request — `GET /api/iam/screens/{code}`. */
  getScreen: (app: string, pageCode: string) =>
    bankingApi
      .get<ScreenDetail>(`/iam/screens/${encodeURIComponent(pageCode)}`, { params: { app } })
      .then((r) => r.data),

  /**
   * Propose bringing a seeded screen live — `POST /api/iam/screens`.
   *
   * **No register row is written until a Checker approves.** A pending screen exists only as a
   * proposal and cannot be configured or mapped.
   */
  createScreen: (body: CreateScreenRequest) =>
    bankingApi.post<ChangeSubmissionResponse>('/iam/screens', body).then((r) => r.data),

  /**
   * Propose an edit to a screen's name or base roles — `PUT /api/iam/screens/{code}`.
   *
   * **Neither bumps the epoch**: the name is a label and the base roles filter an admin panel, so
   * nothing the compiler reads has moved. The gate rail is release-owned and not in the body.
   */
  modifyScreen: (pageCode: string, body: ModifyScreenRequest) =>
    bankingApi
      .put<ChangeSubmissionResponse>(`/iam/screens/${encodeURIComponent(pageCode)}`, body)
      .then((r) => r.data),

  /** Propose a soft delete. Refused 409 while any role still maps or holds the screen. */
  deleteScreen: (pageCode: string, body: ScreenActionRequest) =>
    bankingApi
      .delete<ChangeSubmissionResponse>(`/iam/screens/${encodeURIComponent(pageCode)}`, {
        data: body,
      })
      .then((r) => r.data),

  /**
   * Propose disabling or re-enabling a screen.
   *
   * Both are Maker-Checker, and the screen stays exactly as reachable as it is until the request
   * is applied — retirement happens at apply, never at submit.
   */
  setScreenEnabled: (pageCode: string, enabled: boolean, body: ScreenActionRequest) =>
    bankingApi
      .post<ChangeSubmissionResponse>(
        `/iam/screens/${encodeURIComponent(pageCode)}/${enabled ? 'enable' : 'disable'}`,
        body,
      )
      .then((r) => r.data),

  // ─── Change requests — where anything actually happens ────────────────────

  /**
   * The change-request trail — `GET /api/iam/change-requests`.
   *
   * The payload is not returned in the list (for some actions it is a whole screen's toggles), so
   * a panel that needs to show the proposal reads the single request.
   */
  listChangeRequests: (params: ChangeRequestListParams = {}) =>
    bankingApi.get<ChangeRequestListResponse>('/iam/change-requests', { params }).then((r) => r.data),

  /**
   * A role's or screen's audit trail — `platform.AdminAudit`, newest first, each row carrying the
   * before / after snapshot captured when it happened and the current status of its request.
   */
  listAuditTrail: (entityType: 'Role' | 'Screen', entityKey: string, query: AdminAuditQuery = {}) =>
    bankingApi
      .get<AdminAuditResponse>(
        `/iam/${entityType === 'Role' ? 'roles' : 'screens'}/${encodeURIComponent(entityKey)}/audit`,
        {
          params: {
            section: query.section || undefined,
            from: query.from || undefined,
            to: query.to || undefined,
            page: query.page,
            pageSize: query.pageSize ?? ROLE_PAGE_SIZE_CAP,
          },
        },
      )
      .then((r) => r.data),

  /** One request with its stored proposal, verbatim. */
  getChangeRequest: (id: number) =>
    bankingApi.get<ChangeRequest>(`/iam/change-requests/${id}`).then((r) => r.data),

  /**
   * The approval workflow this deployment runs — `GET /api/iam/change-requests/workflow`.
   *
   * Which actions are Maker-only (applied at submit, no Checker) and which key a Checker needs.
   */
  getWorkflow: () =>
    bankingApi.get<ChangeWorkflowResponse>('/iam/change-requests/workflow').then((r) => r.data),

  /**
   * Approve a proposal and apply it — **one transaction, one epoch bump**. With a future
   * `effectiveFrom` it is scheduled instead (`Approved`) and the server's scheduler applies it then.
   *
   * Needs `iam:policy:approve` — the Checker's key, not `iam:role:write`. Answered **409** when the
   * caller is the request's Maker ({@link MakerIsCheckerConflict}): separation of duties is the
   * server's rule, not only this screen's.
   */
  approveChangeRequest: (id: number, body: CheckerVerdict) =>
    bankingApi.post(`/iam/change-requests/${id}/approve`, body).then((r) => r.data),

  /**
   * Refuse a proposal. No epoch is bumped — nothing about the compiled policy changed. Same key and
   * same Maker 409 as approve.
   */
  rejectChangeRequest: (id: number, body: CheckerVerdict) =>
    bankingApi.post(`/iam/change-requests/${id}/reject`, body).then((r) => r.data),

  /**
   * Withdraw your own proposal, clearing the concurrency guard.
   *
   * **Only the maker may.** A Checker who disagrees rejects instead — a refusal is a recorded
   * verdict, and filing one as a withdrawal would erase it from the trail.
   */
  withdrawChangeRequest: (id: number, body: CheckerVerdict) =>
    bankingApi.post(`/iam/change-requests/${id}/withdraw`, body).then((r) => r.data),

  /**
   * Close a rejected New Screen — `POST /api/iam/screens/{code}/close` (Admin Approval Queue design §10.3).
   *
   * An applied `CloseScreen` request: the rejected New leaves the Screens grid and its code is free. The
   * Maker may close it; so may another writer once the Maker can no longer act, with remarks required.
   */
  /** The rejection a Role's panels show, or null when its newest request is not a rejection. */
  getRoleRejection: (roleName: string) =>
    bankingApi
      .get<RejectedRequest | ''>(`/iam/roles/${encodeURIComponent(roleName)}/rejection`)
      .then((r) => (r.data === '' ? null : r.data)),

  /** The rejection a Screen's panels show, or null. Works for a rejected New Screen, which has no register row. */
  getScreenRejection: (pageCode: string) =>
    bankingApi
      .get<RejectedRequest | ''>(`/iam/screens/${encodeURIComponent(pageCode)}/rejection`)
      .then((r) => (r.data === '' ? null : r.data)),

  resubmitRole: (
    roleName: string,
    body: ModifyRoleRequest & { resubmissionOf: number },
  ) => bankingApi.post<ChangeSubmissionResponse>(`/iam/roles/${encodeURIComponent(roleName)}/resubmit`, body).then((r) => r.data),

  resubmitScreen: (
    pageCode: string,
    body: { app: string; screenName: string; baseRoles: string[]; makerRemarks: string; resubmissionOf: number },
  ) => bankingApi.post<ChangeSubmissionResponse>(`/iam/screens/${encodeURIComponent(pageCode)}/resubmit`, body).then((r) => r.data),

  closeRole: (roleName: string, body: { closesRequestId: number; makerRemarks?: string }) =>
    bankingApi.post(`/iam/roles/${encodeURIComponent(roleName)}/close`, body).then((r) => r.data),

  closeScreen: (pageCode: string, body: { app: string; closesRequestId: number; makerRemarks?: string }) =>
    bankingApi.post(`/iam/screens/${encodeURIComponent(pageCode)}/close`, body).then((r) => r.data),
};

/**
 * The disabled-element 409, when that is what came back.
 *
 * Distinguished from every other 409 by the `elements` array: the concurrency guard's conflict
 * names a pending request instead, and the two need different words — one says "wait for a
 * Checker", the other says "enable it on the screen first".
 */
export function screenConfigConflict(err: unknown): ScreenConfigConflict | null {
  const response = (err as { response?: { status?: number; data?: unknown } })?.response;

  if (response?.status !== 409) return null;

  const data = response.data as Partial<ScreenConfigConflict> | undefined;

  return Array.isArray(data?.elements) && data.elements.length > 0
    ? (data as ScreenConfigConflict)
    : null;
}

/**
 * The per-field messages out of an ASP.NET `ValidationProblem`, keyed as the server keyed them.
 *
 * The shared {@link errorMessage} reads `error`, `message` and `title`, which for a validation
 * problem is the generic "One or more validation errors occurred" — true, and useless to the
 * person who has to fix one field. This reaches the `errors` dictionary so a form can put each
 * message under the input that caused it. Returns an empty object for every other error shape,
 * so a caller can fall back to the banner without checking first.
 */
export function validationErrors(err: unknown): Record<string, string> {
  const errors = (err as { response?: { data?: { errors?: unknown } } })?.response?.data?.errors;

  if (!errors || typeof errors !== 'object') return {};

  const out: Record<string, string> = {};

  for (const [field, messages] of Object.entries(errors as Record<string, unknown>)) {
    // The dictionary is field → string[]; a single string is accepted too rather than dropped,
    // because a problem-details body assembled by hand somewhere upstream is still worth showing.
    const text = Array.isArray(messages)
      ? messages.filter((m): m is string => typeof m === 'string').join(' ')
      : typeof messages === 'string'
        ? messages
        : '';

    if (text) out[field] = text;
  }

  return out;
}

/**
 * The maximum `pageSize` the list endpoint honours.
 *
 * Asked for more, the server silently falls back to 20 rather than refusing — so a caller that
 * guesses high gets a short page and no explanation. Named here so the one place that asks for a
 * large page asks for exactly the largest one that works.
 */
export const ROLE_PAGE_SIZE_CAP = 200;

/** Query keys, in one place so a write can invalidate exactly what it changed. */
export const rolesScreensKeys = {
  roles: (params: RoleListParams = {}) =>
    ['rbac', 'admin', 'roles', params.status ?? 'all', params.page ?? 1, params.pageSize ?? 20] as const,

  /** Everything under the Roles list, for a write that should refresh whatever page is on screen. */
  allRoles: ['rbac', 'admin', 'roles'] as const,

  /**
   * One role's detail. Deliberately not nested under {@link allRoles}: invalidating the list after
   * a write would then also discard the detail the write's own response just refreshed.
   */
  role: (roleName: string) => ['rbac', 'admin', 'role', roleName] as const,

  /**
   * One role's Screen Mapping panel. Separate from {@link role} because a mapping proposal changes
   * the role's `editable` flag and the panel's rows, and the two are different fetches.
   */
  roleScreens: (roleName: string) => ['rbac', 'admin', 'role-screens', roleName] as const,

  /** One role's element configuration for one screen. */
  roleScreenConfig: (roleName: string, app: string, pageCode: string) =>
    ['rbac', 'admin', 'role-screen-config', roleName, app, pageCode] as const,

  /**
   * One screen's base configuration — the ceiling. Not keyed by role, because it is the same
   * answer for all of them, and a base-level save has to invalidate every role's panel below it.
   */
  screenBaseConfig: (app: string, pageCode: string) =>
    ['rbac', 'admin', 'screen-base-config', app, pageCode] as const,

  /** Everything element-level, for a base-level save that changes what every role panel may show. */
  allScreenConfig: ['rbac', 'admin', 'role-screen-config'] as const,

  screens: (params: ScreenListParams = {}) =>
    [
      'rbac',
      'admin',
      'screens',
      params.app ?? 'all',
      params.status ?? 'all',
      params.search ?? '',
      params.rail ?? 'all',
    ] as const,

  /** Everything under the Screens list, for a write that should refresh whatever filter is on screen. */
  allScreens: ['rbac', 'admin', 'screens'] as const,

  screen: (app: string, pageCode: string) => ['rbac', 'admin', 'screen', app, pageCode] as const,

  /**
   * The change-request trail for one entity, or the whole queue when no key is given.
   *
   * Keyed on the filter because the Audit Trail panel and a future approval queue read the same
   * endpoint with different ones, and a shared key would make each invalidate the other's page.
   */
  changeRequests: (params: ChangeRequestListParams = {}) =>
    [
      'rbac',
      'admin',
      'change-requests',
      params.entityType ?? 'all',
      params.entityKey ?? 'all',
      params.status ?? 'all',
      params.page ?? 1,
      params.includePayload ? 'with-payload' : 'list',
    ] as const,

  /**
   * One entity's audit trail. Nested under {@link allChangeRequests} on purpose: every submission and
   * every verdict already invalidates that prefix, and each of them writes an audit row.
   */
  auditTrail: (entityType: 'Role' | 'Screen', entityKey: string) =>
    ['rbac', 'admin', 'change-requests', 'audit', entityType, entityKey] as const,

  /** Every change-request query, for a verdict that changes one of them and cannot know which. */
  allChangeRequests: ['rbac', 'admin', 'change-requests'] as const,

  /**
   * The deployed base roles. No parameters, and nothing invalidates it: the list changes with the
   * release, not with anything a person can do on this screen.
   */
  baseRoles: ['rbac', 'admin', 'base-roles'] as const,

  /** The deployed rail codes. Like {@link baseRoles}, it changes with the release only. */
  rails: ['rbac', 'admin', 'rails'] as const,

  /** The Maker-only / Checker configuration. Changes with deployment config, not with this screen. */
  workflow: ['rbac', 'admin', 'change-workflow'] as const,
};

/**
 * The Maker-approving-own-request 409, when that is what came back.
 *
 * Told apart from the concurrency guard's 409 by `submittedBy`.
 */
export function makerIsCheckerConflict(err: unknown): MakerIsCheckerConflict | null {
  const response = (err as { response?: { status?: number; data?: unknown } })?.response;

  if (response?.status !== 409) return null;

  const data = response.data as Partial<MakerIsCheckerConflict> | undefined;

  return typeof data?.submittedBy === 'string' && typeof data.error === 'string'
    ? (data as MakerIsCheckerConflict)
    : null;
}
