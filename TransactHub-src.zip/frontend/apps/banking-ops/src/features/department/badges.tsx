import { Badge, cn } from '@paymenthub/ui';
import { lastActionLabel, statusLabel, useDepartmentTranslation } from './i18n';
import type { DepartmentRequestAction, DepartmentRequestStatus, DepartmentStatus } from './types';

/** Modifier on the shared `.status-badge` (sass/_typography.scss) — identifies the badge's nature. */
const STATUS_MODIFIER: Record<DepartmentStatus, string> = {
  Active: 'success',
  Disabled: 'error',
  Pending: 'warn',
};

/**
 * A department's status as the shared `.status-badge`. Named for the feature so it is never mistaken for the shared
 * `StatusBadge`, which maps transaction statuses.
 */
export function DepartmentStatusBadge({ status }: { status: DepartmentStatus }) {
  const { t } = useDepartmentTranslation();
  return <span className={cn('status-badge', STATUS_MODIFIER[status])}>{statusLabel(t, status)}</span>;
}

/** Approved reads green; Pending and Rejected both still need someone's attention, so amber. "—" for none. */
export function LastActionBadge({
  action,
  status,
}: {
  action: DepartmentRequestAction | null;
  status: DepartmentRequestStatus | null;
}) {
  const { t } = useDepartmentTranslation();
  const label = lastActionLabel(t, action, status);
  if (!label) return <span className="text-[var(--text-muted)]">—</span>;
  return (
    <Badge variant={status === 'Applied' ? 'green' : 'amber'} className="whitespace-nowrap">
      {label}
    </Badge>
  );
}
