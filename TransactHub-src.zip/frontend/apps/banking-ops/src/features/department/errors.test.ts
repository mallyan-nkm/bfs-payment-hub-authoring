import { describe, expect, it } from 'vitest';
import {
  departmentErrorMessage,
  departmentFieldErrors,
  departmentProblem,
  departmentRuleCode,
  isDepartmentRule,
} from './errors';
import type { DepartmentFieldMap } from './errors';

/** An axios-shaped rejection carrying `body`. */
const failure = (body: unknown) => ({ response: { status: 400, data: body } });

const NEW_FORM: DepartmentFieldMap<'deptCode' | 'departmentName' | 'remarks'> = {
  properties: { deptCode: 'deptCode', departmentName: 'departmentName', remarks: 'remarks' },
  rules: { 'BR-DEPT-001': 'deptCode', 'BR-DEPT-004': 'remarks' },
};

const TAKEN = 'Department code already exists or is pending approval';

describe('departmentProblem', () => {
  it('reads a ProblemDetails body and ignores anything else', () => {
    expect(departmentProblem(failure({ detail: 'x', errorCode: 'Conflict' }))?.errorCode).toBe('Conflict');
    expect(departmentProblem(failure('<html>502</html>'))).toBeNull();
    expect(departmentProblem(new Error('Network Error'))).toBeNull();
    expect(departmentProblem(null)).toBeNull();
  });
});

describe('departmentRuleCode', () => {
  it('prefers the ruleCode extension', () => {
    expect(departmentRuleCode({ errorCode: 'Conflict', ruleCode: 'BR-DEPT-001' })).toBe('BR-DEPT-001');
  });

  it('accepts an errorCode that is itself a rule code, and nothing else', () => {
    expect(departmentRuleCode({ errorCode: 'BR-DEPT-002' })).toBe('BR-DEPT-002');
    expect(departmentRuleCode({ errorCode: 'Conflict' })).toBeNull();
    expect(departmentRuleCode(null)).toBeNull();
  });

  it('isDepartmentRule matches on the code', () => {
    expect(isDepartmentRule(failure({ ruleCode: 'BR-DEPT-002', detail: 'x' }), 'BR-DEPT-002')).toBe(true);
    expect(isDepartmentRule(failure({ ruleCode: 'E-7', detail: 'x' }), 'BR-DEPT-002')).toBe(false);
  });
});

describe('departmentFieldErrors (R8: by errorCode / ruleCode and the errors map, never by English text)', () => {
  it('maps the errors map case-insensitively, on the last segment of a dotted path', () => {
    const errors = departmentFieldErrors(
      failure({
        errorCode: 'ValidationFailed',
        ruleCode: 'Validation',
        detail: 'Dept Code is required.',
        errors: { DeptCode: ['Dept Code is required.'], 'request.Remarks': ['Remarks are required.', 'second'] },
      }),
      NEW_FORM,
    );

    expect(errors).toEqual([
      { field: 'deptCode', message: 'Dept Code is required.' },
      { field: 'remarks', message: 'Remarks are required.' },
    ]);
  });

  it('drops errors-map properties the form does not have', () => {
    expect(departmentFieldErrors(failure({ errors: { DepartmentId: ['Required to modify.'] } }), NEW_FORM)).toEqual([]);
  });

  it('maps a business refusal by its rule code, with the detail as the message', () => {
    expect(departmentFieldErrors(failure({ errorCode: 'Conflict', ruleCode: 'BR-DEPT-001', detail: TAKEN }), NEW_FORM)).toEqual([
      { field: 'deptCode', message: TAKEN },
    ]);
  });

  it('does not map on the message: the taken-code text under another rule is about no field', () => {
    expect(departmentFieldErrors(failure({ errorCode: 'Conflict', ruleCode: 'E-7', detail: TAKEN }), NEW_FORM)).toEqual([]);
    expect(departmentFieldErrors(failure({ errorCode: 'Conflict', detail: TAKEN }), NEW_FORM)).toEqual([]);
  });

  it('is empty for a failure with no body', () => {
    expect(departmentFieldErrors(new Error('Network Error'), NEW_FORM)).toEqual([]);
  });
});

describe('departmentErrorMessage', () => {
  it("is the server's detail, else the caller's fallback", () => {
    expect(departmentErrorMessage(failure({ detail: 'Department not found.' }), 'fallback')).toBe('Department not found.');
    expect(departmentErrorMessage(failure({ errorCode: 'Conflict' }), 'fallback')).toBe('fallback');
    expect(departmentErrorMessage(new Error('x'), 'fallback')).toBe('fallback');
  });
});
