import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Input } from '@paymenthub/ui';
import { SideSheet } from '../../shared/components/SideSheet';
import { useSaveDepartment } from './api';
import { departmentErrorMessage, departmentFieldErrors } from './errors';
import type { DepartmentFieldMap } from './errors';
import {
  FormRow,
  MAX_DEPARTMENT_NAME,
  MAX_DEPT_CODE,
  PANEL_WIDTH,
  PanelError,
  PanelFooter,
  RemarksField,
  SERVER_ERROR,
  fieldErrorText,
} from './formParts';
import { useDepartmentTranslation } from './i18n';
import { newDepartmentSchema } from './schemas';
import type { NewDepartmentForm } from './schemas';
import { DEPARTMENT_RULE_CODES } from './types';

/**
 * Which field a server refusal is about (AC-072): by the ValidationProblemDetails `errors` map, or by rule code for
 * a refusal the service raises — a taken code is BR-DEPT-001.
 */
const SERVER_FIELDS: DepartmentFieldMap<keyof NewDepartmentForm> = {
  properties: { deptCode: 'deptCode', departmentName: 'departmentName', remarks: 'remarks' },
  rules: { [DEPARTMENT_RULE_CODES.deptCodeUnique]: 'deptCode', [DEPARTMENT_RULE_CODES.remarksMandatory]: 'remarks' },
};

/**
 * New Department (FSD §5.1, design §7.2). Duplicate codes are the server's to judge: the grid is paged,
 * so the browser never holds every code, and a code held by a Pending department counts too (E-1).
 */
export function DepartmentFormSheet({ onClose, onSaved }: { onClose: () => void; onSaved: (deptCode: string) => void }) {
  const { t } = useDepartmentTranslation();
  const [panelError, setPanelError] = useState<string | null>(null);
  const save = useSaveDepartment();

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm<NewDepartmentForm>({
    resolver: zodResolver(newDepartmentSchema),
    defaultValues: { deptCode: '', departmentName: '', remarks: '' },
    // Focus moves to the first field in error, in the order the panel shows them.
    shouldFocusError: true,
  });

  const submit = handleSubmit(
    async (values) => {
      setPanelError(null);
      try {
        await save.mutateAsync({
          isUpdate: false,
          deptCode: values.deptCode,
          departmentName: values.departmentName,
          remarks: values.remarks,
        });
        onSaved(values.deptCode);
      } catch (error) {
        const fieldErrors = departmentFieldErrors(error, SERVER_FIELDS);
        if (fieldErrors.length === 0) {
          setPanelError(departmentErrorMessage(error, t('ERROR.REQUEST_FAILED')));
          return;
        }
        fieldErrors.forEach(({ field, message }, i) =>
          setError(field, { type: SERVER_ERROR, message }, { shouldFocus: i === 0 }),
        );
      }
    },
    () => setPanelError(null),
  );

  return (
    <SideSheet
      eyebrow={t('NEW.EYEBROW')}
      subtitle={t('NEW.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={
        <PanelFooter onCancel={onClose}>
          <Button type="button" variant="primary" disabled={save.isPending} onClick={() => void submit()}>
            {save.isPending ? t('FORM.SAVING') : t('FORM.SAVE')}
          </Button>
        </PanelFooter>
      }
    >
      <form noValidate onSubmit={(e) => void submit(e)} className="flex flex-col gap-4">
        <PanelError message={panelError} />

        <FormRow label={t('FORM.DEPT_CODE')} htmlFor="dept-code" required>
          <Input
            id="dept-code"
            placeholder={t('NEW.DEPT_CODE_PLACEHOLDER')}
            maxLength={MAX_DEPT_CODE}
            autoComplete="off"
            aria-required="true"
            error={fieldErrorText(t, errors.deptCode)}
            className="h-10 w-full text-xs uppercase"
            {...register('deptCode')}
          />
        </FormRow>

        <FormRow label={t('FORM.DEPARTMENT_NAME')} htmlFor="dept-name" required>
          <Input
            id="dept-name"
            placeholder={t('NEW.DEPARTMENT_NAME_PLACEHOLDER')}
            maxLength={MAX_DEPARTMENT_NAME}
            autoComplete="off"
            aria-required="true"
            error={fieldErrorText(t, errors.departmentName)}
            className="h-10 w-full text-xs"
            {...register('departmentName')}
          />
        </FormRow>

        <RemarksField
          id="dept-remarks"
          label={t('FORM.REMARKS')}
          accent="amber"
          placeholder={t('NEW.REMARKS_PLACEHOLDER')}
          error={fieldErrorText(t, errors.remarks)}
          {...register('remarks')}
        />
        {/* Enter in a text field submits, as in any form. */}
        <Button type="submit" hidden aria-hidden="true" tabIndex={-1} unstyled />
      </form>
    </SideSheet>
  );
}
