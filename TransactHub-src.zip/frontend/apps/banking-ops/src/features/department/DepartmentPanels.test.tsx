import { screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import { apiError, apiOk, expectNotActionable, grant, renderWithProviders } from '../../../test/renderWithProviders';
import { DepartmentFormSheet } from './DepartmentFormSheet';
import { DepartmentModifySheet } from './DepartmentModifySheet';
import { DeleteDepartmentSheet } from './DeleteDepartmentSheet';
import type { DepartmentDetail, DepartmentRequestSummary, DepartmentRow } from './types';

vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);
const post = vi.mocked(bankingApi.post);

const SAVED = apiOk({ departmentId: 1, requestId: 10, auditId: 100, createdAt: '2026-10-01T00:00:00Z' });

const TAKEN = 'Department code already exists or is pending approval';

beforeEach(() => {
  get.mockReset();
  post.mockReset();
  grant(PERM.departmentPage, PERM.departmentWrite);
});

// ── New Department (AC-DEPT-072) ────────────────────────────────────────────────

async function fillNew(code = 'fin', name = 'Finance', remarks = 'New team') {
  await userEvent.type(screen.getByLabelText(/Dept Code/), code);
  await userEvent.type(screen.getByLabelText(/Department Name/), name);
  await userEvent.type(screen.getByLabelText(/Remarks/), remarks);
  await userEvent.click(screen.getByRole('button', { name: 'Save' }));
}

describe('New Department panel', () => {
  it('shows the §6.1 messages on their fields and writes nothing', async () => {
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);

    await userEvent.click(screen.getByRole('button', { name: 'Save' }));

    expect(await screen.findByText('Dept Code is required.')).toBeInTheDocument();
    expect(screen.getByText('Department Name is required.')).toBeInTheDocument();
    expect(screen.getByText('Remarks are required.')).toBeInTheDocument();
    const code = screen.getByLabelText(/Dept Code/);
    expect(code).toHaveAttribute('aria-invalid', 'true');
    expect(code).toHaveAttribute('aria-describedby', 'dept-code-error');
    await waitFor(() => expect(code).toHaveFocus());
    expect(post).not.toHaveBeenCalled();
  });

  it('refuses a code with spaces or symbols', async () => {
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);

    await userEvent.type(screen.getByLabelText(/Dept Code/), 'FIN 01');
    await userEvent.click(screen.getByRole('button', { name: 'Save' }));

    expect(await screen.findByText('Dept Code must be alphanumeric with no spaces.')).toBeInTheDocument();
  });

  it('sends the code trimmed and upper-cased, and the other fields trimmed', async () => {
    post.mockResolvedValue(SAVED);
    const onSaved = vi.fn();
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={onSaved} />);

    await fillNew(' fin ', ' Finance ', ' New team ');

    await waitFor(() => expect(onSaved).toHaveBeenCalledWith('FIN'));
    expect(post).toHaveBeenCalledWith('/ops/departmentSave', {
      isUpdate: false,
      deptCode: 'FIN',
      departmentName: 'Finance',
      remarks: 'New team',
    });
  });

  it('puts a taken code (rule BR-DEPT-001) on the Dept Code field', async () => {
    post.mockRejectedValue(apiError(409, TAKEN, 'Conflict', { ruleCode: 'BR-DEPT-001' }));
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);

    await fillNew();

    const code = screen.getByLabelText(/Dept Code/);
    await waitFor(() => expect(code).toHaveAttribute('aria-invalid', 'true'));
    expect(screen.getByText(TAKEN)).toHaveAttribute('id', 'dept-code-error');
    await waitFor(() => expect(code).toHaveFocus());
  });

  it('maps by rule code, never by the text: the same words under another rule stay in the panel', async () => {
    post.mockRejectedValue(apiError(409, TAKEN, 'Conflict', { ruleCode: 'E-7' }));
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);

    await fillNew();

    expect(await screen.findByRole('alert')).toHaveTextContent(TAKEN);
    expect(screen.getByLabelText(/Dept Code/)).not.toHaveAttribute('aria-invalid');
  });

  it("puts a validator's errors-map entry on its field", async () => {
    post.mockRejectedValue(
      apiError(400, 'Department Name is too long.', 'ValidationFailed', {
        ruleCode: 'Validation',
        errors: { DepartmentName: ['Department Name is too long.'] },
      }),
    );
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);

    await fillNew();

    const name = screen.getByLabelText(/Department Name/);
    await waitFor(() => expect(name).toHaveAttribute('aria-invalid', 'true'));
    expect(screen.getByText('Department Name is too long.')).toHaveAttribute('id', 'dept-name-error');
  });

  it('shows any other refusal in the panel', async () => {
    post.mockRejectedValue(apiError(400, 'Something else went wrong.', 'ValidationFailed', { ruleCode: 'Validation' }));
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);

    await fillNew();

    expect(await screen.findByRole('alert')).toHaveTextContent('Something else went wrong.');
  });

  it('falls back to the generic message when the failure carries no body', async () => {
    post.mockRejectedValue(new Error('Network Error'));
    renderWithProviders(<DepartmentFormSheet onClose={vi.fn()} onSaved={vi.fn()} />);

    await fillNew();

    expect(await screen.findByRole('alert')).toHaveTextContent('The request failed. Try again.');
  });
});

// ── View & Modify (AC-DEPT-073, AC-DEPT-075) ──────────────────────────────────

function request(overrides: Partial<DepartmentRequestSummary>): DepartmentRequestSummary {
  return {
    requestId: 10,
    action: 'ModifyDepartment',
    status: 'Applied',
    makerBy: 'maker1',
    makerAt: '2026-09-28T10:00:00Z',
    makerRemarks: 'm',
    checkerBy: 'checker1',
    checkerAt: '2026-09-28T11:00:00Z',
    checkerRemarks: 'ok',
    ...overrides,
  };
}

function detail(overrides: Partial<DepartmentDetail> = {}): DepartmentDetail {
  return {
    departmentId: 1,
    deptCode: 'FIN',
    departmentName: 'Finance',
    status: 'Active',
    createdDate: '2026-09-01T08:00:00Z',
    createdBy: 'maker1',
    lastModifiedAt: null,
    lastModifiedBy: null,
    latestRequest: request({}),
    hasPendingRequest: false,
    isRejectedNewDepartment: false,
    canModifyOrDelete: true,
    callerIsMaker: true,
    canFallbackClose: false,
    ...overrides,
  };
}

function renderModify(d: DepartmentDetail, handlers: { onCompleted?: (m: string) => void; onConfigureRules?: () => void } = {}) {
  get.mockResolvedValue(apiOk(d));
  return renderWithProviders(
    <DepartmentModifySheet
      departmentId={d.departmentId}
      onClose={vi.fn()}
      onCompleted={handlers.onCompleted ?? vi.fn()}
      onConfigureRules={handlers.onConfigureRules ?? vi.fn()}
    />,
  );
}

describe('View & Modify panel', () => {
  it('loads the detail, with Dept Code read-only and the created date in the reader\'s locale', async () => {
    renderModify(detail());

    expect(await screen.findByRole('heading', { name: 'Finance' })).toBeInTheDocument();
    expect(get).toHaveBeenCalledWith('/ops/departmentDetail/1');
    expect(screen.getByLabelText('Dept Code')).toHaveAttribute('readonly');
    expect(screen.getByLabelText('Created On')).toHaveValue('01-09-2026 12:00:00') // session zone (Dubai), was the reader-locale UTC text;
  });

  it('disables Modify while a request is pending (Delete is on the grid row)', async () => {
    renderModify(
      detail({ hasPendingRequest: true, canModifyOrDelete: false, latestRequest: request({ status: 'Pending', checkerBy: null }) }),
    );

    expect(await screen.findByRole('button', { name: 'Save Changes' })).toBeDisabled();
    expect(screen.queryByRole('button', { name: 'Delete' })).not.toBeInTheDocument();
    expect(screen.getByRole('status')).toHaveTextContent('Modify Department - Pending (#10) by maker1');
  });

  it("shows a rejection's Checker remarks read-only", async () => {
    renderModify(detail({ latestRequest: request({ status: 'Rejected', checkerRemarks: 'Name is misspelt' }) }));

    const remarks = await screen.findByLabelText('Checker Remarks');
    expect(remarks).toHaveValue('Name is misspelt');
    expect(remarks).toHaveAttribute('readonly');
  });

  it('offers only Resubmit and Close for a rejected New Department', async () => {
    renderModify(
      detail({
        status: 'Disabled',
        isRejectedNewDepartment: true,
        canModifyOrDelete: false,
        latestRequest: request({ action: 'NewDepartment', status: 'Rejected' }),
      }),
    );

    expect(await screen.findByRole('button', { name: 'Resubmit' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Close department FIN' })).toBeEnabled();
    expect(screen.queryByRole('button', { name: 'Save Changes' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Delete' })).not.toBeInTheDocument();
  });

  it('resubmits a rejected New Department with the corrected name', async () => {
    post.mockResolvedValue(SAVED);
    const onCompleted = vi.fn();
    renderModify(
      detail({
        isRejectedNewDepartment: true,
        canModifyOrDelete: false,
        latestRequest: request({ action: 'NewDepartment', status: 'Rejected' }),
      }),
      { onCompleted },
    );

    const name = await screen.findByLabelText(/Department Name/);
    await userEvent.clear(name);
    await userEvent.type(name, 'Finance Dept');
    await userEvent.type(screen.getByLabelText(/Modification Comments/), 'Fixed the name');
    await userEvent.click(screen.getByRole('button', { name: 'Resubmit' }));

    await waitFor(() => expect(onCompleted).toHaveBeenCalledWith('Department FIN resubmitted.'));
    expect(post).toHaveBeenCalledWith('/ops/departmentResubmit/1', {
      departmentName: 'Finance Dept',
      remarks: 'Fixed the name',
      resubmissionOf: 10,
    });
  });

  it('lets the Maker close a rejected New Department with blank remarks', async () => {
    post.mockResolvedValue(SAVED);
    const onCompleted = vi.fn();
    renderModify(
      detail({
        isRejectedNewDepartment: true,
        canModifyOrDelete: false,
        latestRequest: request({ action: 'NewDepartment', status: 'Rejected' }),
      }),
      { onCompleted },
    );

    // A blank name doesn't stop a Close either: the name isn't changed by closing.
    await userEvent.clear(await screen.findByLabelText(/Department Name/));
    await userEvent.click(screen.getByRole('button', { name: 'Close department FIN' }));

    await waitFor(() => expect(onCompleted).toHaveBeenCalledWith('Department FIN closed.'));
    expect(post).toHaveBeenCalledWith('/ops/departmentClose/1', { remarks: '', closesRequestId: 10 });
  });

  it('offers a non-Maker with the fallback only Close, with remarks required and a note', async () => {
    post.mockResolvedValue(SAVED);
    const onCompleted = vi.fn();
    renderModify(
      detail({
        isRejectedNewDepartment: true,
        canModifyOrDelete: false,
        callerIsMaker: false,
        canFallbackClose: true,
        latestRequest: request({ action: 'NewDepartment', status: 'Rejected', makerBy: 'Mina Maker' }),
      }),
      { onCompleted },
    );

    const close = await screen.findByRole('button', { name: 'Close department FIN' });
    expect(screen.queryByRole('button', { name: 'Resubmit' })).not.toBeInTheDocument();
    expect(screen.getByRole('note')).toHaveTextContent(
      'The original Maker, Mina Maker, can no longer act on this request.',
    );

    await userEvent.click(close);
    const comments = screen.getByLabelText(/Modification Comments/);
    await waitFor(() => expect(comments).toHaveAttribute('aria-invalid', 'true'));
    expect(post).not.toHaveBeenCalled();

    await userEvent.type(comments, 'Maker has left');
    await userEvent.click(close);

    await waitFor(() => expect(onCompleted).toHaveBeenCalledWith('Department FIN closed.'));
    expect(post).toHaveBeenCalledWith('/ops/departmentClose/1', { remarks: 'Maker has left', closesRequestId: 10 });
  });

  it('shows a non-Maker without the fallback the rejected New read-only, with neither button', async () => {
    renderModify(
      detail({
        isRejectedNewDepartment: true,
        canModifyOrDelete: false,
        callerIsMaker: false,
        canFallbackClose: false,
        latestRequest: request({ action: 'NewDepartment', status: 'Rejected', checkerRemarks: 'No budget' }),
      }),
    );

    expect(await screen.findByLabelText('Checker Remarks')).toHaveValue('No budget');
    expect(screen.queryByRole('button', { name: 'Resubmit' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Close department FIN' })).not.toBeInTheDocument();
    expect(screen.queryByRole('note')).not.toBeInTheDocument();
  });

  it('blocks Save Changes on blank comments: red border, focus on the field, nothing written', async () => {
    renderModify(detail());

    const name = await screen.findByLabelText(/Department Name/);
    await userEvent.clear(name);
    await userEvent.type(name, 'Finance & Accounts');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    const comments = screen.getByLabelText(/Modification Comments/);
    await waitFor(() => expect(comments).toHaveAttribute('aria-invalid', 'true'));
    await waitFor(() => expect(comments).toHaveFocus());
    expect(screen.getByText('Modification Comments are required.')).toBeInTheDocument();
    expect(post).not.toHaveBeenCalled();
  });

  it('shows "Department Name is required." for a blank name', async () => {
    renderModify(detail());

    await userEvent.clear(await screen.findByLabelText(/Department Name/));
    await userEvent.type(screen.getByLabelText(/Modification Comments/), 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    expect(await screen.findByText('Department Name is required.')).toBeInTheDocument();
  });

  it('says "No changes to submit" when nothing changed, and writes nothing', async () => {
    renderModify(detail());

    await userEvent.type(await screen.findByLabelText(/Modification Comments/), 'no-op');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('No changes to submit');
    expect(post).not.toHaveBeenCalled();
  });

  it("puts the server's Remarks error on Modification Comments", async () => {
    post.mockRejectedValue(
      apiError(400, 'Remarks must be at most 1000 characters.', 'ValidationFailed', {
        ruleCode: 'BR-DEPT-004',
        errors: { Remarks: ['Remarks must be at most 1000 characters.'] },
      }),
    );
    renderModify(detail());

    const name = await screen.findByLabelText(/Department Name/);
    await userEvent.clear(name);
    await userEvent.type(name, 'Finance & Accounts');
    await userEvent.type(screen.getByLabelText(/Modification Comments/), 'why');
    await userEvent.click(screen.getByRole('button', { name: 'Save Changes' }));

    const comments = screen.getByLabelText(/Modification Comments/);
    await waitFor(() => expect(comments).toHaveAttribute('aria-invalid', 'true'));
    expect(screen.getByText('Remarks must be at most 1000 characters.')).toHaveAttribute('id', 'modify-comments-error');
  });

  it('keeps the Rule Configuration link inert: no navigation, no request (AC-075)', async () => {
    const onConfigureRules = vi.fn();
    renderModify(detail(), { onConfigureRules });

    await userEvent.click(await screen.findByRole('button', { name: /Department Rule Configuration/ }));

    expect(onConfigureRules).toHaveBeenCalledTimes(1);
    expect(get).toHaveBeenCalledTimes(1); // the detail load only
    expect(post).not.toHaveBeenCalled();
  });

  it('leaves no write control actionable without the write key (AC-077)', async () => {
    grant(PERM.departmentPage);
    renderModify(detail());

    await screen.findByRole('heading', { name: 'Finance' });
    // Absent or disabled: how a denial renders is the render policy's choice (RBAC §13).
    expectNotActionable(screen.queryByRole('button', { name: 'Save Changes' }));
    expect(screen.queryByRole('button', { name: 'Delete' })).not.toBeInTheDocument();
    expect(screen.queryByLabelText(/Modification Comments/)).not.toBeInTheDocument();
  });
});

// ── Delete (AC-DEPT-074) ────────────────────────────────────────────────────────

function row(overrides: Partial<DepartmentRow> = {}): DepartmentRow {
  return {
    departmentId: 1,
    deptCode: 'FIN',
    departmentName: 'Finance',
    status: 'Active',
    createdDate: '2026-09-01T08:00:00Z',
    createdBy: 'maker1',
    lastModifiedAt: null,
    lastModifiedBy: null,
    totalUsers: 0,
    lastRequestAction: null,
    lastRequestStatus: null,
    ...overrides,
  };
}

const HAS_USERS = 'This department has active users and cannot be deleted.';

describe('Delete panel', () => {
  it('is labelled DELETE RECORD and deletes with remarks', async () => {
    post.mockResolvedValue(SAVED);
    const onDeleted = vi.fn();
    renderWithProviders(<DeleteDepartmentSheet row={row()} onClose={vi.fn()} onDeleted={onDeleted} />);

    // The label is styled uppercase ("DELETE RECORD"); the dialog is named by its title.
    expect(screen.getByText('Delete Record')).toBeInTheDocument();
    expect(screen.getByRole('dialog', { name: 'FIN — Finance' })).toBeInTheDocument();
    expect(screen.getByText('This will remove the record and cannot be undone.')).toBeInTheDocument();

    await userEvent.type(screen.getByLabelText(/Remarks/), 'No longer used');
    await userEvent.click(screen.getByRole('button', { name: 'Delete' }));

    await waitFor(() => expect(onDeleted).toHaveBeenCalled());
    expect(post).toHaveBeenCalledWith('/ops/departmentDelete/1', { remarks: 'No longer used' });
  });

  it('blocks a delete with blank remarks', async () => {
    renderWithProviders(<DeleteDepartmentSheet row={row()} onClose={vi.fn()} onDeleted={vi.fn()} />);

    await userEvent.click(screen.getByRole('button', { name: 'Delete' }));

    const remarks = screen.getByLabelText(/Remarks/);
    await waitFor(() => expect(remarks).toHaveAttribute('aria-invalid', 'true'));
    expect(screen.getByText('Remarks are required.')).toBeInTheDocument();
    await waitFor(() => expect(remarks).toHaveFocus());
    expect(post).not.toHaveBeenCalled();
  });

  it('says a department with users cannot be deleted, and offers no Delete', () => {
    renderWithProviders(<DeleteDepartmentSheet row={row({ totalUsers: 3 })} onClose={vi.fn()} onDeleted={vi.fn()} />);

    expect(screen.getByRole('alert')).toHaveTextContent(HAS_USERS);
    expect(screen.getByRole('button', { name: 'Delete' })).toBeDisabled();
  });

  it('switches to that message when users were assigned since the grid loaded (rule BR-DEPT-002)', async () => {
    post.mockRejectedValue(apiError(400, HAS_USERS, 'ValidationFailed', { ruleCode: 'BR-DEPT-002' }));
    renderWithProviders(<DeleteDepartmentSheet row={row()} onClose={vi.fn()} onDeleted={vi.fn()} />);

    await userEvent.type(screen.getByLabelText(/Remarks/), 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Delete' }));

    expect(await screen.findByRole('alert')).toHaveTextContent(HAS_USERS);
    expect(screen.getByRole('button', { name: 'Delete' })).toBeDisabled();
    expect(screen.queryByLabelText(/Remarks/)).not.toBeInTheDocument();
  });

  it('shows another refusal in the panel and keeps the form', async () => {
    post.mockRejectedValue(apiError(409, 'This department was changed by someone else.', 'Conflict', { ruleCode: 'E-7' }));
    renderWithProviders(<DeleteDepartmentSheet row={row()} onClose={vi.fn()} onDeleted={vi.fn()} />);

    await userEvent.type(screen.getByLabelText(/Remarks/), 'x');
    await userEvent.click(screen.getByRole('button', { name: 'Delete' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('This department was changed by someone else.');
    expect(screen.getByRole('button', { name: 'Delete' })).toBeEnabled();
  });
});
