import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { bankingApi } from '../../shared/api/bankingApi';
import { departmentKeys } from './queryKeys';
import type {
  DepartmentAuditParams,
  DepartmentAuditResponse,
  DepartmentDetail,
  DepartmentExportFormat,
  DepartmentListParams,
  DepartmentListResponse,
  DepartmentSavedResponse,
  SaveDepartmentRequest,
} from './types';

/**
 * Department configuration over the Operations API (Department design §5). The tenant and the
 * acting user come from the session server-side, so no request here names either.
 */
const BASE = '/ops';

function listQuery(p: DepartmentListParams) {
  return {
    Search: p.search || undefined,
    Status: p.status || undefined,
    SortBy: p.sortBy,
    SortDirection: p.sortDirection,
  };
}

export const departmentApi = {
  list: (p: DepartmentListParams) =>
    bankingApi
      .get<DepartmentListResponse>(`${BASE}/departmentList`, {
        params: { ...listQuery(p), PageSize: p.pageSize, PageNumber: p.pageNumber },
      })
      .then((r) => r.data),

  detail: (departmentId: number) =>
    bankingApi.get<DepartmentDetail>(`${BASE}/departmentDetail/${departmentId}`).then((r) => r.data),

  audit: (departmentId: number, p: DepartmentAuditParams) =>
    bankingApi
      .get<DepartmentAuditResponse>(`${BASE}/departmentAudit/${departmentId}`, {
        params: {
          Section: p.section,
          // Days stay `yyyy-MM-dd`: these endpoints bind DateOnly days and read them in the session zone (UTC date-time T-22).
          FromDate: p.fromDate || undefined,
          ToDate: p.toDate || undefined,
          PageSize: p.pageSize,
          PageNumber: p.pageNumber,
        },
      })
      .then((r) => r.data),

  save: (body: SaveDepartmentRequest) =>
    bankingApi.post<DepartmentSavedResponse>(`${BASE}/departmentSave`, body).then((r) => r.data),

  remove: (departmentId: number, remarks: string) =>
    bankingApi
      .post<DepartmentSavedResponse>(`${BASE}/departmentDelete/${departmentId}`, { remarks })
      .then((r) => r.data),

  /** `resubmissionOf` is the rejected request being repaired: the server refuses a stale one. */
  resubmit: (departmentId: number, departmentName: string, remarks: string, resubmissionOf: number) =>
    bankingApi
      .post<DepartmentSavedResponse>(`${BASE}/departmentResubmit/${departmentId}`, {
        departmentName,
        remarks,
        resubmissionOf,
      })
      .then((r) => r.data),

  /** `closesRequestId` is the rejected request being closed: the server refuses a stale one. */
  close: (departmentId: number, remarks: string, closesRequestId: number) =>
    bankingApi
      .post<DepartmentSavedResponse>(`${BASE}/departmentClose/${departmentId}`, { remarks, closesRequestId })
      .then((r) => r.data),

  /** The whole filtered set, server-rendered; `columns` are the visible column keys in display order. */
  export: (format: DepartmentExportFormat, p: DepartmentListParams, columns: string[]) =>
    bankingApi
      .get<Blob>(`${BASE}/departmentExport/${format}`, {
        params: { ...listQuery(p), Columns: columns.join(',') },
        responseType: 'blob',
      })
      .then((r) => r.data),
};

export function useDepartmentList(params: DepartmentListParams) {
  return useQuery({
    queryKey: departmentKeys.list(params),
    queryFn: () => departmentApi.list(params),
    placeholderData: keepPreviousData,
  });
}

export function useDepartmentDetail(departmentId: number) {
  return useQuery({
    queryKey: departmentKeys.detail(departmentId),
    queryFn: () => departmentApi.detail(departmentId),
  });
}

export function useDepartmentAudit(departmentId: number, params: DepartmentAuditParams) {
  return useQuery({
    queryKey: departmentKeys.audit(departmentId, params),
    queryFn: () => departmentApi.audit(departmentId, params),
    placeholderData: keepPreviousData,
  });
}

/** Every command refreshes the grid and the department's detail and audit feed. */
function useDepartmentCommand<TArgs>(run: (args: TArgs) => Promise<DepartmentSavedResponse>) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: run,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: departmentKeys.all }),
  });
}

export const useSaveDepartment = () => useDepartmentCommand((body: SaveDepartmentRequest) => departmentApi.save(body));

export const useDeleteDepartment = () =>
  useDepartmentCommand(({ departmentId, remarks }: { departmentId: number; remarks: string }) =>
    departmentApi.remove(departmentId, remarks),
  );

export const useResubmitDepartment = () =>
  useDepartmentCommand(
    ({
      departmentId,
      departmentName,
      remarks,
      resubmissionOf,
    }: {
      departmentId: number;
      departmentName: string;
      remarks: string;
      resubmissionOf: number;
    }) => departmentApi.resubmit(departmentId, departmentName, remarks, resubmissionOf),
  );

export const useCloseDepartment = () =>
  useDepartmentCommand(
    ({ departmentId, remarks, closesRequestId }: { departmentId: number; remarks: string; closesRequestId: number }) =>
      departmentApi.close(departmentId, remarks, closesRequestId),
  );
