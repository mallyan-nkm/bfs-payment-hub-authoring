import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Can, Input, PageBody, PageShell, Select, SmartGrid, usePermissions } from '@paymenthub/ui';
import type { SmartGridQueryChange } from '@paymenthub/ui';
import { Plus } from 'lucide-react';
import { Toast } from '../../shared/components/Toast';
import type { ToastState } from '../../shared/components/Toast';
import { PERM } from '../../shared/auth/permissionKeys';
import { buildColumns } from './columns';
import type { DepartmentGridView } from './columns';
import { departmentApi, useDepartmentList } from './api';
import { statusLabel, useDepartmentTranslation } from './i18n';
import { DepartmentFormSheet } from './DepartmentFormSheet';
import { DepartmentModifySheet } from './DepartmentModifySheet';
import { DepartmentAuditTrailModal } from './DepartmentAuditTrailModal';
import { DeleteDepartmentSheet } from './DeleteDepartmentSheet';
import type {
  DepartmentExportFormat,
  DepartmentListParams,
  DepartmentRow,
  DepartmentSortBy,
  DepartmentStatus,
} from './types';

/** The grid's Status filter: All Status plus every status, Pending included (design §7.1, G-5). */
const STATUS_FILTERS: DepartmentStatus[] = ['Active', 'Disabled', 'Pending'];

const DEFAULT_PAGE_SIZE = 20;

type Sheet =
  | { kind: 'create' }
  | { kind: 'modify'; row: DepartmentRow }
  | { kind: 'audit'; row: DepartmentRow }
  | { kind: 'delete'; row: DepartmentRow };

interface GridQuery {
  page: number;
  pageSize: number;
  sortBy: string | null;
  sortDir: 'asc' | 'desc';
  status: DepartmentStatus | '';
  search: string;
}

const EMPTY_QUERY: GridQuery = { page: 1, pageSize: DEFAULT_PAGE_SIZE, sortBy: null, sortDir: 'asc', status: '', search: '' };

/**
 * Department Configuration (User Management → Administration): define and manage the departments users
 * are assigned to (Department design §7).
 *
 * The grid runs in server mode: Search, Status, sort and paging all go to `departmentList`, and export
 * asks the server for the whole filtered set. The tenant and the acting user come from the session.
 */
export function DepartmentConfigurationPage() {
  const navigate = useNavigate();
  const { t } = useDepartmentTranslation();
  const { can } = usePermissions();
  // The export routes need `ops:report:export` on top of the page key (design §8.2).
  const canExport = can(PERM.opsReportExport);

  const [statusInput, setStatusInput] = useState<DepartmentStatus | ''>('');
  const [searchInput, setSearchInput] = useState('');
  const [query, setQuery] = useState<GridQuery>(EMPTY_QUERY);
  const [sheet, setSheet] = useState<Sheet | null>(null);
  const [toast, setToast] = useState<ToastState | null>(null);

  const listParams: DepartmentListParams = useMemo(
    () => ({
      search: query.search || undefined,
      status: query.status || undefined,
      sortBy: (query.sortBy as DepartmentSortBy | null) ?? undefined,
      sortDirection: query.sortBy ? query.sortDir : undefined,
      pageSize: query.pageSize,
      pageNumber: query.page,
    }),
    [query],
  );

  const listQuery = useDepartmentList(listParams);
  const rows = listQuery.data?.items ?? [];
  const totalRecords = listQuery.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(totalRecords / query.pageSize));

  // A delete or a narrower filter can leave the operator past the last page; server mode trusts the caller to clamp.
  useEffect(() => {
    if (query.page > totalPages) setQuery((q) => ({ ...q, page: totalPages }));
  }, [query.page, totalPages]);

  const gridView = useRef<DepartmentGridView>({
    rows,
    page: query.page,
    pageSize: query.pageSize,
    onViewModify: (row) => setSheet({ kind: 'modify', row }),
    onAuditTrail: (row) => setSheet({ kind: 'audit', row }),
    onDelete: (row) => setSheet({ kind: 'delete', row }),
  });
  gridView.current.rows = rows;
  gridView.current.page = query.page;
  gridView.current.pageSize = query.pageSize;

  // Built once per language: SmartGrid never re-reads column definitions, and the closures read through the ref.
  const columns = useMemo(() => buildColumns(gridView, t), [t]);

  // Stable, so SideSheet's focus/Escape effect doesn't re-run on every page render.
  const closeSheet = useCallback(() => setSheet(null), []);

  function handleQueryChange(change: SmartGridQueryChange) {
    setQuery((prev) => ({
      ...prev,
      page: change.page ?? prev.page,
      pageSize: change.pageSize ?? prev.pageSize,
      sortBy: change.sortBy !== undefined ? change.sortBy : prev.sortBy,
      sortDir: change.sortDir ?? prev.sortDir,
    }));
  }

  function applySearch() {
    setQuery((prev) => ({ ...prev, page: 1, status: statusInput, search: searchInput.trim() }));
  }

  function clearSearch() {
    setStatusInput('');
    setSearchInput('');
    setQuery((prev) => ({ ...prev, page: 1, status: '', search: '', sortBy: null, sortDir: 'asc' }));
  }

  /** The server renders the whole filtered set, with only the columns the operator has visible (Q-9). */
  const handleExport = (format: DepartmentExportFormat, visibleColumnKeys: string[]) =>
    departmentApi.export(
      format,
      listParams,
      visibleColumnKeys.filter((k) => k !== 'slNo'),
    );

  function completed(message: string) {
    setToast({ tone: 'success', message });
    closeSheet();
  }

  return (
    <PageShell>
      <PageBody>
        <div className="pq-page pr-2">
          {/* Breadcrumb */}
          <p className="pq-breadcrumb mt-2 text-xs text-[var(--text-muted)]">
            <Button type="button" unstyled onClick={() => navigate('/dashboard')} className="pq-breadcrumb-link">
              {t('PAGE.BREADCRUMB_ROOT')}
            </Button>
            {' / '}
            <span>{t('PAGE.BREADCRUMB')}</span>
          </p>

          {/* Title header */}
          <div className="pq-header">
            <div>
              <h1 className="truncate text-[18px] font-black text-[var(--text-primary)] sm:text-[20px] lg:text-[20px]">
                {t('PAGE.TITLE')}
              </h1>
              <p className="pq-header-subtitle">{t('PAGE.SUBTITLE')}</p>
            </div>
            <div className="pq-header-meta">
              {/* What a denial looks like is the render policy's to decide, not this screen's (RBAC §13). */}
              <Can permission={PERM.departmentWrite}>
                <Button
                  type="button"
                  variant="primary"
                  onClick={() => setSheet({ kind: 'create' })}
                  icon={<Plus size={14} aria-hidden="true" />}
                >
                  {t('PAGE.NEW')}
                </Button>
              </Can>
            </div>
          </div>

          {listQuery.isError ? (
            <div role="alert" className="flex flex-col items-center gap-3 p-10 text-center text-sm text-[var(--text-2)]">
              <p>{t('PAGE.LOAD_FAILED')}</p>
              <Button type="button" variant="outline" size="sm" onClick={() => void listQuery.refetch()}>
                {t('PAGE.RETRY')}
              </Button>
            </div>
          ) : (
            <SmartGrid<DepartmentRow>
              columns={columns}
              rows={rows}
              getRowId={(r) => String(r.departmentId)}
              storageKey="department-columns-v1"
              loading={listQuery.isFetching}
              emptyTitle={t('PAGE.EMPTY_TITLE')}
              // One message for an empty tenant and an empty filter alike (AC-071).
              emptyMessage={t('PAGE.EMPTY_MESSAGE')}
              exportFilename="departments"
              onExport={canExport ? handleExport : undefined}
              exportFormats={canExport ? ['csv', 'excel', 'pdf'] : []}
              showFilterToggle={false}
              // The toolbar's own Search / Clear buttons apply and reset these two inputs.
              onSearch={applySearch}
              onClear={clearSearch}
              server={{
                page: query.page,
                pageSize: query.pageSize,
                total: totalRecords,
                sortBy: query.sortBy,
                sortDir: query.sortDir,
                onQueryChange: handleQueryChange,
              }}
              toolbarStart={
                <>
                  <label htmlFor="department-status-filter" className="sr-only">
                    {t('PAGE.STATUS_FILTER_LABEL')}
                  </label>
                  <Select
                    id="department-status-filter"
                    value={statusInput}
                    onValueChange={(v) => setStatusInput(v as DepartmentStatus | '')}
                    options={[
                      { value: '', label: t('PAGE.STATUS_ALL') },
                      ...STATUS_FILTERS.map((s) => ({ value: s, label: statusLabel(t, s) })),
                    ]}
                    className="h-38px w-36 shrink-0 px-2 text-xs"
                  />
                  <Input
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && applySearch()}
                    placeholder={t('PAGE.SEARCH_PLACEHOLDER')}
                    aria-label={t('PAGE.SEARCH_LABEL')}
                    maxLength={100}
                    className="h-38px min-w-[12rem] px-3 text-xs"
                  />
                </>
              }
            />
          )}
        </div>
      </PageBody>

      {sheet?.kind === 'create' && (
        <DepartmentFormSheet onClose={closeSheet} onSaved={(code) => completed(t('TOAST.SAVED', { code }))} />
      )}
      {sheet?.kind === 'modify' && (
        <DepartmentModifySheet
          departmentId={sheet.row.departmentId}
          onClose={closeSheet}
          onCompleted={completed}
          onConfigureRules={() => setToast({ tone: 'info', message: t('PAGE.RULE_CONFIG_REDIRECT') })}
        />
      )}
      {sheet?.kind === 'audit' && <DepartmentAuditTrailModal row={sheet.row} onClose={closeSheet} />}
      {sheet?.kind === 'delete' && (
        <DeleteDepartmentSheet row={sheet.row} onClose={closeSheet} onDeleted={() => completed(t('TOAST.DELETED'))} />
      )}

      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </PageShell>
  );
}
