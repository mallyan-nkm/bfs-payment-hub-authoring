import { z } from 'zod';

/**
 * The Department panels' forms (React UI guideline §12): one zod schema per form, the form's type inferred from it.
 * They mirror the server's FluentValidation rules (design §6.1, E-2, BR-DEPT-004); the server stays authoritative.
 *
 * A message is a key in the `DEPARTMENT` translation block, not the text, so a schema needs no language and a test
 * can assert the rule rather than the copy. The panels translate it when they show it.
 */
export const VALIDATION = {
  deptCodeRequired: 'VALIDATION.DEPT_CODE_REQUIRED',
  deptCodeNotAlphanumeric: 'VALIDATION.DEPT_CODE_NOT_ALPHANUMERIC',
  departmentNameRequired: 'VALIDATION.DEPARTMENT_NAME_REQUIRED',
  remarksRequired: 'VALIDATION.REMARKS_REQUIRED',
  modificationCommentsRequired: 'VALIDATION.MODIFICATION_COMMENTS_REQUIRED',
} as const;

/** ASCII letters and digits only: the server's `char.IsAsciiLetterOrDigit` rule (E-2). */
const ALPHANUMERIC = /^[A-Za-z0-9]+$/;

/** A required free-text field, trimmed before it is checked and before it is sent. */
const required = (message: string) => z.string().trim().min(1, message);

/** New Department (FSD §5.1). The code is stored upper-cased (Q-8). */
export const newDepartmentSchema = z.object({
  deptCode: z
    .string()
    .trim()
    .min(1, VALIDATION.deptCodeRequired)
    .regex(ALPHANUMERIC, VALIDATION.deptCodeNotAlphanumeric)
    .transform((code) => code.toUpperCase()),
  departmentName: required(VALIDATION.departmentNameRequired),
  remarks: required(VALIDATION.remarksRequired),
});

export type NewDepartmentForm = z.infer<typeof newDepartmentSchema>;

/**
 * View & Modify (FSD §5.3). Save Changes and Resubmit validate the whole form; Close validates `comments` alone,
 * because closing a rejected New Department doesn't change its name.
 */
export const modifyDepartmentSchema = z.object({
  departmentName: required(VALIDATION.departmentNameRequired),
  // Pending is shown, never chosen: a Pending New Department carries it until the Checker decides.
  status: z.enum(['Active', 'Disabled', 'Pending']),
  comments: required(VALIDATION.modificationCommentsRequired),
});

export type ModifyDepartmentForm = z.infer<typeof modifyDepartmentSchema>;

/** Delete (FSD §5.4): the mandatory reason (BR-DEPT-004). */
export const deleteDepartmentSchema = z.object({
  remarks: required(VALIDATION.remarksRequired),
});

export type DeleteDepartmentForm = z.infer<typeof deleteDepartmentSchema>;
