import type { DepartmentAuditEntry } from './types';

/** The snapshot fields an audit card can show, in display order. The card names each in the reader's language. */
export type AuditField = 'deptCode' | 'departmentName' | 'status' | 'isDeleted';

/** A snapshot value: text, a yes/no flag, or null for "none" (shown as "—"). */
export type AuditValue = string | boolean | null;

/** One "Field · Before → After" line on an audit card (FSD §5.5.3). */
export interface AuditFieldChange {
  field: AuditField;
  before: AuditValue;
  after: AuditValue;
}

/** One user line on a User Assignment card: assigned to (`added`) or removed from the department. */
export interface AuditUserChange {
  userId: string;
  userName: string | null;
  added: boolean;
}

/** Snapshot keys (the writer uses PascalCase) for each field a snapshot carries. */
const SNAPSHOT_FIELDS: { key: string; field: AuditField }[] = [
  { key: 'departmentname', field: 'departmentName' },
  { key: 'status', field: 'status' },
  { key: 'isdeleted', field: 'isDeleted' },
];

/** `o` with its keys lower-cased, so PascalCase and camelCase writers read the same. */
function lowerKeys(o: object): Record<string, unknown> {
  return Object.fromEntries(Object.entries(o as Record<string, unknown>).map(([k, v]) => [k.toLowerCase(), v]));
}

/** Parses a snapshot, reading its keys case-insensitively. */
function parse(json: string | null): Record<string, unknown> | null {
  if (!json) return null;
  try {
    const value: unknown = JSON.parse(json);
    if (!value || typeof value !== 'object') return null;
    return lowerKeys(value);
  } catch {
    return null;
  }
}

function value(v: unknown): AuditValue {
  if (typeof v === 'boolean') return v;
  return v === null || v === undefined || v === '' ? null : String(v);
}

/**
 * The field changes a card shows, from `OldData` / `NewData`. A Created row has no before-snapshot, so every
 * field reads "none" → value, with the Dept Code first; otherwise only the fields that differ are listed.
 */
export function auditFieldChanges(entry: DepartmentAuditEntry): AuditFieldChange[] {
  const before = parse(entry.oldData);
  const after = parse(entry.newData);
  if (!after) return [];

  if (!before) {
    const created: AuditFieldChange[] = entry.deptCode ? [{ field: 'deptCode', before: null, after: entry.deptCode }] : [];
    return [
      ...created,
      ...SNAPSHOT_FIELDS.filter((f) => f.field !== 'isDeleted' && f.key in after).map((f) => ({
        field: f.field,
        before: null,
        after: value(after[f.key]),
      })),
    ];
  }

  return SNAPSHOT_FIELDS.flatMap((f) => {
    const b = value(before[f.key]);
    const a = value(after[f.key]);
    return b === a ? [] : [{ field: f.field, before: b, after: a }];
  });
}

/** The users in a snapshot's `{"users":[{loginId,userName,privilege}]}` list (the User feature's apply card, UA-71). */
function usersIn(json: string | null, added: boolean): AuditUserChange[] {
  const users = parse(json)?.users;
  if (!Array.isArray(users)) return [];
  return users.flatMap((u: unknown) => {
    if (!u || typeof u !== 'object') return [];
    const { loginid, userid, username } = lowerKeys(u);
    const id = typeof loginid === 'string' ? loginid : userid;
    if (typeof id !== 'string') return [];
    return [{ userId: id, userName: typeof username === 'string' && username ? username : null, added }];
  });
}

/**
 * The user lines of a User Assignment card, or null when the row isn't one. The User feature writes the users
 * assigned in `NewData.users` and those removed in `OldData.users`; the older single-user `NewData`
 * (`{"userId","userName","change"}`) is still read.
 */
export function auditUserChanges(entry: DepartmentAuditEntry): AuditUserChange[] | null {
  if (entry.section !== 'User Assignment') return null;
  const listed = [...usersIn(entry.oldData, false), ...usersIn(entry.newData, true)];
  if (listed.length > 0) return listed;

  const data = parse(entry.newData);
  const userId = data?.userid;
  if (typeof userId !== 'string') return [];
  const userName = typeof data?.username === 'string' && data.username ? data.username : null;
  return [{ userId, userName, added: String(data?.change).toLowerCase() !== 'removed' }];
}

/** Which approval level a decision card records, and how many there are (AC-APQ-114). */
export interface AuditLevel {
  level: number;
  totalLevels: number;
}

const levelNumber = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

/** "Level k of N" for an Approval card whose `NewData` carries both numbers, or null (a card written before multi-level approval). */
export function auditLevel(entry: DepartmentAuditEntry): AuditLevel | null {
  if (entry.section !== 'Approval') return null;
  const data = parse(entry.newData);
  const level = levelNumber(data?.level);
  const totalLevels = levelNumber(data?.totallevels);
  return level !== null && totalLevels !== null ? { level, totalLevels } : null;
}
