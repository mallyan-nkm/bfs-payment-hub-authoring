import { describe, expect, it } from 'vitest';
import { auditFieldChanges, auditUserChanges } from './auditDiff';
import type { DepartmentAuditEntry } from './types';

function entry(overrides: Partial<DepartmentAuditEntry>): DepartmentAuditEntry {
  return {
    sequenceNo: 1,
    auditId: 1,
    deptCode: 'FIN',
    requestId: 10,
    action: 'Modified',
    section: 'Dept Details',
    userId: '17',
    userName: 'maker1',
    userRole: 'Maker',
    remarks: 'r',
    changedFields: null,
    oldData: null,
    newData: '{}',
    actionDate: '2026-09-28T14:15:00Z',
    ...overrides,
  };
}

// The card names each field in the reader's language (DEPARTMENT.AUDIT.FIELDS); the diff names it by id.
describe('auditFieldChanges (AC-DEPT-076: "Field · Before → After" from OldData / NewData)', () => {
  it('lists only the fields that changed', () => {
    const changes = auditFieldChanges(
      entry({
        oldData: '{"DepartmentName":"Finance","Status":"Active","IsDeleted":false}',
        newData: '{"DepartmentName":"Finance & Accounts","Status":"Active","IsDeleted":false}',
      }),
    );

    expect(changes).toEqual([{ field: 'departmentName', before: 'Finance', after: 'Finance & Accounts' }]);
  });

  it('shows a Created row as none → value, Dept Code first', () => {
    const changes = auditFieldChanges(
      entry({ action: 'Created', section: 'Dept Created', newData: '{"DepartmentName":"Finance","Status":"Pending","IsDeleted":false}' }),
    );

    expect(changes).toEqual([
      { field: 'deptCode', before: null, after: 'FIN' },
      { field: 'departmentName', before: null, after: 'Finance' },
      { field: 'status', before: null, after: 'Pending' },
    ]);
  });

  it('keeps the Deleted flag a boolean, for the card to say Yes / No', () => {
    expect(
      auditFieldChanges(entry({ oldData: '{"IsDeleted":false}', newData: '{"IsDeleted":true}' })),
    ).toEqual([{ field: 'isDeleted', before: false, after: true }]);
  });

  it('reads snapshot keys in any case and survives unreadable JSON', () => {
    expect(
      auditFieldChanges(entry({ oldData: '{"status":"Active"}', newData: '{"STATUS":"Disabled"}' })),
    ).toEqual([{ field: 'status', before: 'Active', after: 'Disabled' }]);
    expect(auditFieldChanges(entry({ oldData: 'not json', newData: 'not json' }))).toEqual([]);
  });
});

describe('auditUserChanges (AC-DEPT-076: the user lines of a User Assignment card)', () => {
  it('reads the assigned users from NewData.users and the removed ones from OldData.users', () => {
    expect(
      auditUserChanges(
        entry({
          section: 'User Assignment',
          oldData: '{"users":[{"loginId":"mlee@bank.ae","userName":"Mary Lee","privilege":"Actor"}]}',
          newData:
            '{"users":[{"loginId":"jsmith@bank.ae","userName":"John Smith"},{"loginId":"rkaur@bank.ae","userName":""}],"appliedBy":null}',
        }),
      ),
    ).toEqual([
      { userId: 'mlee@bank.ae', userName: 'Mary Lee', added: false },
      { userId: 'jsmith@bank.ae', userName: 'John Smith', added: true },
      { userId: 'rkaur@bank.ae', userName: null, added: true },
    ]);
  });

  it('still reads the single-user NewData', () => {
    expect(
      auditUserChanges(
        entry({ section: 'User Assignment', newData: '{"userId":"jsmith@bank.ae","userName":"John Smith","change":"Added"}' }),
      ),
    ).toEqual([{ userId: 'jsmith@bank.ae', userName: 'John Smith', added: true }]);

    expect(
      auditUserChanges(entry({ section: 'User Assignment', newData: '{"userId":"jsmith@bank.ae","change":"Removed"}' })),
    ).toEqual([{ userId: 'jsmith@bank.ae', userName: null, added: false }]);
  });

  it('is null for every other section', () => {
    expect(auditUserChanges(entry({ newData: '{"users":[{"loginId":"x"}]}' }))).toBeNull();
  });
});
