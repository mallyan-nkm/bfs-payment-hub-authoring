import { render, renderHook, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { DepartmentStatusBadge, LastActionBadge } from './badges';
import { lastActionLabel, useDepartmentTranslation } from './i18n';

/** The screen's `t`, as a component gets it. */
const departmentT = () => renderHook(() => useDepartmentTranslation()).result.current.t;

describe('Last Action label (AC-DEPT-070, Q-5)', () => {
  it.each([
    ['NewDepartment', 'Pending', 'New Department - Pending'],
    ['ModifyDepartment', 'Applied', 'Modify Department - Approved'],
    ['DeleteDepartment', 'Rejected', 'Delete Department - Rejected'],
  ] as const)('%s / %s reads "%s"', (action, status, label) => {
    expect(lastActionLabel(departmentT(), action, status)).toBe(label);
  });

  it('shows "—" when there is no request', () => {
    render(<LastActionBadge action={null} status={null} />);
    expect(screen.getByText('—')).toBeInTheDocument();
  });

  it('is green for Approved and amber for Pending / Rejected, always with its text', () => {
    const { rerender } = render(<LastActionBadge action="NewDepartment" status="Applied" />);
    expect(screen.getByText('New Department - Approved').className).toContain('accent-green');

    rerender(<LastActionBadge action="NewDepartment" status="Rejected" />);
    expect(screen.getByText('New Department - Rejected').className).toContain('accent-amber');
  });
});

describe('Department status badge (AC-DEPT-070)', () => {
  it('is green for Active and neutral for Disabled and Pending, on theme tokens only', () => {
    const { rerender } = render(<DepartmentStatusBadge status="Active" />);
    expect(screen.getByText('Active').className).toContain('accent-green');

    rerender(<DepartmentStatusBadge status="Pending" />);
    expect(screen.getByText('Pending').className).not.toMatch(/accent-(green|amber|red)/);

    rerender(<DepartmentStatusBadge status="Disabled" />);
    expect(screen.getByText('Disabled').className).not.toMatch(/accent-(green|amber|red)/);
    expect(screen.getByText('Disabled').className).not.toMatch(/#[0-9a-f]{3,6}/i);
  });
});
