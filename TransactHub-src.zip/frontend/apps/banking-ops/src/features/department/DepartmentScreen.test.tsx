import { screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { bankingApi } from '../../shared/api/bankingApi';
import { PERM } from '../../shared/auth/permissionKeys';
import {
  apiOk,
  chooseOption,
  expectNotActionable,
  grant,
  optionsOf,
  renderWithProviders,
} from '../../../test/renderWithProviders';
import { DepartmentConfigurationPage } from './DepartmentConfigurationPage';
import { DepartmentAuditTrailModal } from './DepartmentAuditTrailModal';
import type { DepartmentAuditEntry, DepartmentRow } from './types';

vi.mock('../../shared/api/bankingApi', () => ({ bankingApi: { get: vi.fn(), post: vi.fn() } }));

const get = vi.mocked(bankingApi.get);

const ROW: DepartmentRow = {
  departmentId: 1,
  deptCode: 'FIN',
  departmentName: 'Finance',
  status: 'Active',
  createdDate: '2026-09-01T08:00:00Z',
  createdBy: 'maker1',
  lastModifiedAt: null,
  lastModifiedBy: null,
  totalUsers: 4,
  lastRequestAction: 'NewDepartment',
  lastRequestStatus: 'Applied',
};

function listOf(items: DepartmentRow[]) {
  return apiOk({ items, pageNumber: 1, pageSize: 20, totalRecords: items.length, totalPages: 1 });
}

beforeEach(() => {
  get.mockReset();
});

// ── Grid (AC-DEPT-069, 070, 071, 077) ──────────────────────────────────────────

describe('Department grid', () => {
  it('shows the FSD columns in order, with the filter bar and server paging', async () => {
    grant(PERM.departmentPage, PERM.departmentWrite, PERM.opsReportExport);
    get.mockResolvedValue(listOf([ROW]));
    renderWithProviders(<DepartmentConfigurationPage />);

    await screen.findByText('FIN');
    const headers = within(screen.getAllByRole('row')[0])
      .getAllByRole('columnheader')
      .map((h) => h.textContent?.trim() ?? '');
    const expected = ['Sl', 'Dept Code', 'Department Name', 'Created', 'Created By', 'Last Modified', 'Last Modified By', 'Total Users', 'Status', 'Last Action', 'Actions'];
    const positions = expected.map((label) => headers.findIndex((h) => h.startsWith(label)));
    expect(positions.every((p) => p >= 0)).toBe(true);
    expect([...positions].sort((a, b) => a - b)).toEqual(positions);

    const status = screen.getByRole('combobox', { name: 'Filter by status' });
    expect(status).toHaveTextContent('All Status');
    expect(await optionsOf(status)).toEqual(['All Status', 'Active', 'Disabled', 'Pending']);
    expect(screen.getByPlaceholderText('Search by department code or name…')).toBeInTheDocument();
    expect(screen.getByText('New Department - Approved')).toBeInTheDocument();
    expect(get).toHaveBeenCalledWith('/ops/departmentList', { params: expect.objectContaining({ PageSize: 20, PageNumber: 1 }) });
  });

  it('sends Status and Search to the server when Search is pressed', async () => {
    grant(PERM.departmentPage);
    get.mockResolvedValue(listOf([ROW]));
    renderWithProviders(<DepartmentConfigurationPage />);
    await screen.findByText('FIN');

    await chooseOption(screen.getByRole('combobox', { name: 'Filter by status' }), 'Pending');
    await userEvent.type(screen.getByPlaceholderText('Search by department code or name…'), 'fin{Enter}');

    await waitFor(() =>
      expect(get).toHaveBeenLastCalledWith('/ops/departmentList', {
        params: expect.objectContaining({ Status: 'Pending', Search: 'fin', PageNumber: 1 }),
      }),
    );
  });

  it('shows the empty state', async () => {
    grant(PERM.departmentPage);
    get.mockResolvedValue(listOf([]));
    renderWithProviders(<DepartmentConfigurationPage />);

    expect(await screen.findByText('No departments')).toBeInTheDocument();
    expect(screen.getByText('No departments match the current filters.')).toBeInTheDocument();
  });

  it('makes New, Delete and Export actionable only for holders of their keys, and offers no Approve or Reject', async () => {
    grant(PERM.departmentPage);
    get.mockResolvedValue(listOf([ROW]));
    const { unmount } = renderWithProviders(<DepartmentConfigurationPage />);
    await screen.findByText('FIN');

    // Absent or disabled: how a denial renders is the render policy's choice (RBAC §13).
    expectNotActionable(screen.queryByRole('button', { name: /New Department/ }));
    expectNotActionable(screen.queryByRole('button', { name: 'Delete FIN' }));
    expect(screen.queryByRole('button', { name: /Export/ })).not.toBeInTheDocument();
    unmount();

    grant(PERM.departmentPage, PERM.departmentWrite, PERM.opsReportExport);
    renderWithProviders(<DepartmentConfigurationPage />);
    await screen.findByText('FIN');

    expect(screen.getByRole('button', { name: /New Department/ })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Delete FIN' })).toBeEnabled();
    expect(screen.getByRole('button', { name: /Export/ })).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /Approve|Reject/ })).not.toBeInTheDocument();
  });
});

describe('Grid row Delete (AC-DEPT-073, with FSD §5.3: Delete is on the grid)', () => {
  it('is disabled while a request is pending and for a rejected New Department, and enabled otherwise', async () => {
    grant(PERM.departmentPage, PERM.departmentWrite);
    get.mockResolvedValue(
      listOf([
        { ...ROW, departmentId: 1, deptCode: 'PEND', lastRequestAction: 'ModifyDepartment', lastRequestStatus: 'Pending' },
        { ...ROW, departmentId: 2, deptCode: 'REJN', status: 'Disabled', lastRequestAction: 'NewDepartment', lastRequestStatus: 'Rejected' },
        { ...ROW, departmentId: 3, deptCode: 'OKAY', lastRequestAction: 'ModifyDepartment', lastRequestStatus: 'Rejected' },
      ]),
    );
    renderWithProviders(<DepartmentConfigurationPage />);
    await screen.findByText('PEND');

    expect(screen.getByRole('button', { name: 'Delete PEND' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Delete PEND' })).toHaveAttribute('title', 'A request on this department is pending approval.');
    expect(screen.getByRole('button', { name: 'Delete REJN' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Delete REJN' })).toHaveAttribute(
      'title',
      'A rejected New Department can only be resubmitted or closed.',
    );
    expect(screen.getByRole('button', { name: 'Delete OKAY' })).toBeEnabled();
  });
});

// ── Audit Trail (AC-DEPT-076) ──────────────────────────────────────────────────

function auditEntry(overrides: Partial<DepartmentAuditEntry>): DepartmentAuditEntry {
  return {
    sequenceNo: 1,
    auditId: 1,
    deptCode: 'FIN',
    requestId: 10,
    action: 'Modified',
    section: 'Dept Details',
    userId: '17',
    userName: 'maker1',
    userRole: 'Maker',
    remarks: 'Renamed per circular',
    changedFields: '["DepartmentName"]',
    oldData: '{"DepartmentName":"Finance","Status":"Active","IsDeleted":false}',
    newData: '{"DepartmentName":"Finance & Accounts","Status":"Active","IsDeleted":false}',
    actionDate: '2026-09-28T14:15:00Z',
    ...overrides,
  };
}

function auditOf(items: DepartmentAuditEntry[], totalRecords = items.length) {
  return apiOk({ departmentId: 1, items, pageNumber: 1, pageSize: 10, totalRecords, totalPages: 1 });
}

describe('Audit Trail panel', () => {
  beforeEach(() => grant(PERM.departmentPage));

  it('shows the header, the Section options in order and a card with its diff', async () => {
    get.mockResolvedValue(auditOf([auditEntry({})]));
    renderWithProviders(<DepartmentAuditTrailModal row={ROW} onClose={vi.fn()} />);

    expect(screen.getByRole('heading', { name: 'Audit History' })).toBeInTheDocument();
    expect(screen.getByText('All recorded changes for this record')).toBeInTheDocument();

    // 14:15Z in the session zone (Asia/Dubai with no provider mounted), through shared/utils/formatDate.ts
    // (UTC date-time design §6.1, AC-UT-I15). It used to print the UTC wall clock, "28-Sep-2026 02:15 PM".
    expect(await screen.findByText('28-09-2026 18:15:00')).toBeInTheDocument();
    expect(screen.getByText('Dept Name')).toBeInTheDocument();
    expect(screen.getByText('Finance & Accounts')).toBeInTheDocument();
    expect(screen.getByText('1–1 of 1')).toBeInTheDocument();
    expect(get).toHaveBeenCalledWith('/ops/departmentAudit/1', { params: expect.objectContaining({ PageSize: 10, PageNumber: 1 }) });

    expect(await optionsOf(screen.getByRole('combobox', { name: 'Section' }))).toEqual([
      'All Sections',
      'Dept Details',
      'User Assignment',
      'Status Change',
      'Dept Created',
      'Approval',
    ]);
  });

  it('pages with Prev / Next buttons whose arrows mirror under RTL', async () => {
    get.mockResolvedValue(auditOf([auditEntry({})], 25));
    renderWithProviders(<DepartmentAuditTrailModal row={ROW} onClose={vi.fn()} />);
    await screen.findByText('1–1 of 25');

    const pages = screen.getByRole('navigation', { name: 'Audit pages' });
    expect(within(pages).getByRole('button', { name: 'Prev' })).toBeDisabled();
    const next = within(pages).getByRole('button', { name: 'Next' });
    // No ← / → glyphs in the copy; the icons are lucide's and flip with the reading direction.
    expect(pages.textContent).not.toMatch(/[←→]/);
    expect(next.querySelector('svg')).toHaveClass('rtl:rotate-180');

    await userEvent.click(next);
    await waitFor(() =>
      expect(get).toHaveBeenLastCalledWith('/ops/departmentAudit/1', { params: expect.objectContaining({ PageNumber: 2 }) }),
    );
  });

  it('shows one + / − user line on a User Assignment card', async () => {
    get.mockResolvedValue(
      auditOf([
        auditEntry({
          section: 'User Assignment',
          action: 'UserUnassigned',
          oldData: null,
          newData: '{"userId":"jsmith@bank.ae","userName":"John Smith","change":"Removed"}',
        }),
      ]),
    );
    renderWithProviders(<DepartmentAuditTrailModal row={ROW} onClose={vi.fn()} />);

    expect(await screen.findByText(/jsmith@bank\.ae — John Smith/)).toBeInTheDocument();
    expect(screen.getByLabelText('Removed')).toHaveTextContent('−');
  });

  it('lists every assigned user, and every removed one, on a User Assignment card written by the User feature', async () => {
    get.mockResolvedValue(
      auditOf([
        auditEntry({
          section: 'User Assignment',
          action: 'NewUser',
          oldData: null,
          newData:
            '{"users":[{"loginId":"jsmith@bank.ae","userName":"John Smith","privilege":"Actor"},{"loginId":"rkaur@bank.ae","userName":"Ranjit Kaur","privilege":"Actor"}],"appliedBy":null}',
        }),
        auditEntry({
          auditId: 2,
          section: 'User Assignment',
          action: 'ModifyUser',
          oldData: '{"users":[{"loginId":"mlee@bank.ae","userName":"Mary Lee","privilege":"Actor"}]}',
          newData: '{"users":[],"appliedBy":null}',
        }),
      ]),
    );
    renderWithProviders(<DepartmentAuditTrailModal row={ROW} onClose={vi.fn()} />);

    expect(await screen.findByText(/jsmith@bank\.ae — John Smith/)).toBeInTheDocument();
    expect(screen.getByText(/rkaur@bank\.ae — Ranjit Kaur/)).toBeInTheDocument();
    expect(screen.getAllByLabelText('Added')).toHaveLength(2);
    expect(screen.getByText(/mlee@bank\.ae — Mary Lee/)).toBeInTheDocument();
    expect(screen.getByLabelText('Removed')).toHaveTextContent('−');
    expect(screen.queryByText('Dept Code')).not.toBeInTheDocument();
  });

  it('disables Search while To is before From, and filters on the server', async () => {
    get.mockResolvedValue(auditOf([auditEntry({})]));
    renderWithProviders(<DepartmentAuditTrailModal row={ROW} onClose={vi.fn()} />);

    await userEvent.type(screen.getByLabelText('From'), '2026-09-10');
    await userEvent.type(screen.getByLabelText('To'), '2026-09-01');
    expect(screen.getByRole('button', { name: 'Search' })).toBeDisabled();
    expect(screen.getByLabelText('To')).toHaveAttribute('aria-invalid', 'true');
    expect(screen.getByText("To Date can't be earlier than From Date.")).toBeInTheDocument();

    await userEvent.clear(screen.getByLabelText('To'));
    await userEvent.type(screen.getByLabelText('To'), '2026-09-30');
    await chooseOption(screen.getByRole('combobox', { name: 'Section' }), 'Approval');
    await userEvent.click(screen.getByRole('button', { name: 'Search' }));

    await waitFor(() =>
      expect(get).toHaveBeenLastCalledWith('/ops/departmentAudit/1', {
        params: expect.objectContaining({ Section: 'Approval', FromDate: '2026-09-10', ToDate: '2026-09-30', PageNumber: 1 }),
      }),
    );
  });

  it('says so when nothing matches', async () => {
    get.mockResolvedValue(auditOf([]));
    renderWithProviders(<DepartmentAuditTrailModal row={ROW} onClose={vi.fn()} />);

    expect(await screen.findByText('No records match the selected filter.')).toBeInTheDocument();
  });
});
