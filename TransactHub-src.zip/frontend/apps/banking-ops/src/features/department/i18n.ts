import { useTranslation } from 'react-i18next';
import type { AuditSection, DepartmentRequestAction, DepartmentRequestStatus, DepartmentStatus } from './types';

/**
 * The Department screen's copy: the `DEPARTMENT` block of the shared `@paymenthub/ui` translations (`i18n/en.json`,
 * `ar.json`), the same pattern as `WPS.*` (React UI guideline §16). Keys below are relative to that block.
 */
export function useDepartmentTranslation() {
  return useTranslation('translation', { keyPrefix: 'DEPARTMENT' });
}

/** The prefixed `t`, for helpers that build copy outside a component (column definitions, labels). */
export type DepartmentT = ReturnType<typeof useDepartmentTranslation>['t'];

export const STATUS_KEY: Record<DepartmentStatus, string> = {
  Active: 'STATUS.ACTIVE',
  Disabled: 'STATUS.DISABLED',
  Pending: 'STATUS.PENDING',
};

export const ACTION_KEY: Record<DepartmentRequestAction, string> = {
  NewDepartment: 'LAST_ACTION.ACTION_NEW',
  ModifyDepartment: 'LAST_ACTION.ACTION_MODIFY',
  DeleteDepartment: 'LAST_ACTION.ACTION_DELETE',
};

/** `Applied` reads "Approved" (Q-5). */
export const OUTCOME_KEY: Record<DepartmentRequestStatus, string> = {
  Pending: 'LAST_ACTION.OUTCOME_PENDING',
  Applied: 'LAST_ACTION.OUTCOME_APPROVED',
  Rejected: 'LAST_ACTION.OUTCOME_REJECTED',
};

/** The Audit Trail's Section labels; the value sent to the server stays the stored `AdminAudit.Section`. */
export const SECTION_KEY: Record<AuditSection, string> = {
  'Dept Details': 'AUDIT.SECTIONS.DEPT_DETAILS',
  'User Assignment': 'AUDIT.SECTIONS.USER_ASSIGNMENT',
  'Status Change': 'AUDIT.SECTIONS.STATUS_CHANGE',
  'Dept Created': 'AUDIT.SECTIONS.DEPT_CREATED',
  Approval: 'AUDIT.SECTIONS.APPROVAL',
};

/** A department status in the reader's language. */
export function statusLabel(t: DepartmentT, status: DepartmentStatus): string {
  return t(STATUS_KEY[status]);
}

/**
 * The FSD's Last Action text (Q-5): `<New|Modify|Delete> Department - <Pending|Approved|Rejected>`; null when there
 * is no request. The export builds the same label server-side.
 */
export function lastActionLabel(
  t: DepartmentT,
  action: DepartmentRequestAction | null,
  status: DepartmentRequestStatus | null,
): string | null {
  return action && status
    ? t('LAST_ACTION.LABEL', { action: t(ACTION_KEY[action]), outcome: t(OUTCOME_KEY[status]) })
    : null;
}
