import { afterEach, describe, expect, it } from 'vitest';
import { formatInstant, setSessionDateTime } from '@paymenthub/ui';
import { formatPanelDateTime } from './format';

// UTC date-time design §6.7 (T-23): the panel date is an instant shown in the session zone through the
// @paymenthub/ui module, dd-MM-yyyy HH:mm:ss, in the reader's locale digits. With no provider mounted the zone is
// the bank default, Asia/Dubai (UTC+04:00); it no longer forces UTC.

afterEach(() => setSessionDateTime(null));

describe('formatPanelDateTime (FSD §5.3, React UI guideline §16: a locale formatter, not string slicing)', () => {
  it('formats in English day-first order, in the session zone whatever the browser zone', () => {
    expect(formatPanelDateTime('2026-09-28T14:15:30Z', 'en')).toBe('28-09-2026 18:15:30');
    expect(formatPanelDateTime('2026-09-28T23:59:59Z', 'en')).toBe('29-09-2026 03:59:59');
    setSessionDateTime({ timeZone: 'Asia/Kolkata', locale: 'en', provided: true });
    expect(formatPanelDateTime('2026-09-28T14:15:30Z', 'en')).toBe('28-09-2026 19:45:30');
  });

  it('takes an explicit zone', () => {
    expect(formatPanelDateTime('2026-09-28T14:15:30Z', 'en', 'UTC')).toBe('28-09-2026 14:15:30');
  });

  it("formats for the Arabic locale through the module, in that locale's digits", () => {
    expect(formatPanelDateTime('2026-09-28T14:15:30Z', 'ar')).toBe(
      formatInstant('2026-09-28T14:15:30Z', { timeZone: 'Asia/Dubai', locale: 'ar-AE' }),
    );
  });

  it('shows "—" for no date or an unreadable one', () => {
    expect(formatPanelDateTime(null)).toBe('—');
    expect(formatPanelDateTime('not a date')).toBe('—');
  });
});
