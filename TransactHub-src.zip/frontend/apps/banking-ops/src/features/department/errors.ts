import { DEPARTMENT_RULE_CODES } from './types';
import type { DepartmentProblemDetails } from './types';

/**
 * Reading a Department refusal (design §5). A refusal is put on the field it is about by its `errors` map or its rule
 * code — never by matching its English text, which is copy and may be reworded or translated.
 */

/** The ProblemDetails body of a failed call, or null when the failure carried none (a network error, a 5xx page). */
export function departmentProblem(error: unknown): DepartmentProblemDetails | null {
  const data = (error as { response?: { data?: unknown } } | null)?.response?.data;
  if (!data || typeof data !== 'object') return null;
  return 'errorCode' in data || 'detail' in data || 'errors' in data ? (data as DepartmentProblemDetails) : null;
}

/**
 * The rule a refusal enforces: the `ruleCode` extension, or `errorCode` when that already is a rule code. Null when
 * the body names no rule.
 */
export function departmentRuleCode(problem: DepartmentProblemDetails | null): string | null {
  if (!problem) return null;
  if (problem.ruleCode) return problem.ruleCode;
  const known: readonly string[] = Object.values(DEPARTMENT_RULE_CODES);
  return problem.errorCode && known.includes(problem.errorCode) ? problem.errorCode : null;
}

/** True when the refusal enforces `rule`. */
export function isDepartmentRule(error: unknown, rule: string): boolean {
  return departmentRuleCode(departmentProblem(error)) === rule;
}

/** The message to show for a failed call: the server's `detail`, else the caller's (translated) fallback. */
export function departmentErrorMessage(error: unknown, fallback: string): string {
  return departmentProblem(error)?.detail || fallback;
}

/** How a form names its fields to the server: by property (`errors` map keys) and by rule code. */
export interface DepartmentFieldMap<F extends string> {
  /** Server property name → form field. Matched case-insensitively, on the last segment of a dotted path. */
  properties: Partial<Record<string, F>>;
  /** Rule code → form field, for a refusal that has no `errors` map (a business rule raised by the service). */
  rules?: Partial<Record<string, F>>;
}

export interface DepartmentFieldError<F extends string> {
  field: F;
  message: string;
}

/**
 * The field errors a refusal carries, in the order the server listed them. Empty when it is about no field of this
 * form, in which case the caller shows `departmentErrorMessage` at the top of the panel.
 */
export function departmentFieldErrors<F extends string>(
  error: unknown,
  map: DepartmentFieldMap<F>,
): DepartmentFieldError<F>[] {
  const problem = departmentProblem(error);
  if (!problem) return [];

  const properties = Object.fromEntries(
    Object.entries(map.properties).map(([name, field]) => [name.toLowerCase(), field]),
  ) as Partial<Record<string, F>>;

  const found: DepartmentFieldError<F>[] = [];
  for (const [property, messages] of Object.entries(problem.errors ?? {})) {
    const field = properties[property.split('.').pop()?.toLowerCase() ?? ''];
    const message = messages?.find((m) => Boolean(m));
    if (field && message && !found.some((f) => f.field === field)) found.push({ field, message });
  }
  if (found.length > 0) return found;

  const rule = departmentRuleCode(problem);
  const field = rule ? map.rules?.[rule] : undefined;
  return field && problem.detail ? [{ field, message: problem.detail }] : [];
}
