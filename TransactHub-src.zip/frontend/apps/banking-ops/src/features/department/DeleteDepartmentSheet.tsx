import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@paymenthub/ui';
import { Info } from 'lucide-react';
import { SideSheet } from '../../shared/components/SideSheet';
import { useDeleteDepartment } from './api';
import { departmentErrorMessage, departmentFieldErrors, isDepartmentRule } from './errors';
import type { DepartmentFieldMap } from './errors';
import { PANEL_WIDTH, PanelError, PanelFooter, RemarksField, SERVER_ERROR, fieldErrorText } from './formParts';
import { useDepartmentTranslation } from './i18n';
import { deleteDepartmentSchema } from './schemas';
import type { DeleteDepartmentForm } from './schemas';
import { DEPARTMENT_RULE_CODES } from './types';
import type { DepartmentRow } from './types';

const SERVER_FIELDS: DepartmentFieldMap<keyof DeleteDepartmentForm> = {
  properties: { remarks: 'remarks' },
  rules: { [DEPARTMENT_RULE_CODES.remarksMandatory]: 'remarks' },
};

/**
 * Delete confirmation (FSD §5.4, design §7.2): a narrow right slide-in, not a centred dialog. A department
 * with users assigned can't be deleted, so the panel says so up front and offers no Delete (FSD
 * pre-condition); the server refuses it too (BR-DEPT-002), in case users were assigned since the grid loaded.
 */
export function DeleteDepartmentSheet({
  row,
  onClose,
  onDeleted,
}: {
  row: DepartmentRow;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const { t } = useDepartmentTranslation();
  const [panelError, setPanelError] = useState<string | null>(null);
  const [hasUsers, setHasUsers] = useState(row.totalUsers > 0);
  const remove = useDeleteDepartment();

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm<DeleteDepartmentForm>({
    resolver: zodResolver(deleteDepartmentSchema),
    defaultValues: { remarks: '' },
    shouldFocusError: true,
  });

  const confirm = handleSubmit(
    async ({ remarks }) => {
      setPanelError(null);
      try {
        await remove.mutateAsync({ departmentId: row.departmentId, remarks });
        onDeleted();
      } catch (error) {
        if (isDepartmentRule(error, DEPARTMENT_RULE_CODES.deleteWithUsers)) {
          setHasUsers(true);
          return;
        }
        const [first] = departmentFieldErrors(error, SERVER_FIELDS);
        if (first) setError(first.field, { type: SERVER_ERROR, message: first.message }, { shouldFocus: true });
        else setPanelError(departmentErrorMessage(error, t('ERROR.REQUEST_FAILED')));
      }
    },
    () => setPanelError(null),
  );

  const hasUsersText = t('VALIDATION.HAS_ACTIVE_USERS');

  return (
    <SideSheet
      eyebrow={t('DELETE.EYEBROW')}
      title={t('DELETE.TITLE', { code: row.deptCode, name: row.departmentName })}
      subtitle={t('DELETE.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={
        <PanelFooter onCancel={onClose}>
          <Button
            type="button"
            variant="danger"
            disabled={hasUsers || remove.isPending}
            title={hasUsers ? hasUsersText : undefined}
            onClick={() => void confirm()}
          >
            {remove.isPending ? t('DELETE.DELETING') : t('DELETE.DELETE')}
          </Button>
        </PanelFooter>
      }
    >
      {hasUsers ? (
        <div
          role="alert"
          className="flex gap-2 rounded-lg border border-[var(--accent-amber)]/40 bg-[var(--accent-amber)]/10 px-3 py-2 text-sm text-[var(--text-primary)]"
        >
          <Info size={16} className="mt-0.5 shrink-0 text-[var(--accent-amber)]" aria-hidden="true" />
          {hasUsersText}
        </div>
      ) : (
        <>
          <PanelError message={panelError} />
          <RemarksField
            id="delete-remarks"
            label={t('FORM.REMARKS')}
            accent="red"
            placeholder={t('DELETE.REMARKS_PLACEHOLDER')}
            hint={t('DELETE.AUDIT_HINT')}
            error={fieldErrorText(t, errors.remarks)}
            {...register('remarks')}
          />
        </>
      )}
    </SideSheet>
  );
}
