import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Can, Input, Select, Textarea, cn, usePermissions, useSessionDateTime } from '@paymenthub/ui';
import { Info, Settings } from 'lucide-react';
import { SideSheet } from '../../shared/components/SideSheet';
import { PERM } from '../../shared/auth/permissionKeys';
import { useCloseDepartment, useDepartmentDetail, useResubmitDepartment, useSaveDepartment } from './api';
import { departmentErrorMessage, departmentFieldErrors } from './errors';
import type { DepartmentFieldMap } from './errors';
import {
  FormRow,
  MAX_DEPARTMENT_NAME,
  PANEL_WIDTH,
  PanelError,
  PanelFooter,
  ReadOnlyInput,
  RemarksField,
  SERVER_ERROR,
  fieldErrorText,
  formatPanelDateTime,
} from './formParts';
import { lastActionLabel, statusLabel, useDepartmentTranslation } from './i18n';
import { modifyDepartmentSchema } from './schemas';
import type { ModifyDepartmentForm } from './schemas';
import { DEPARTMENT_RULE_CODES, EDITABLE_STATUSES } from './types';
import type { DepartmentDetail, DepartmentStatus } from './types';

/** The server names the Maker's comments `Remarks`; on this panel they are Modification Comments. */
const SERVER_FIELDS: DepartmentFieldMap<keyof ModifyDepartmentForm> = {
  properties: { departmentName: 'departmentName', status: 'status', remarks: 'comments' },
  rules: { [DEPARTMENT_RULE_CODES.remarksMandatory]: 'comments' },
};

const isEditable = (s: DepartmentStatus) => (EDITABLE_STATUSES as readonly DepartmentStatus[]).includes(s);

/**
 * View & Modify (FSD §5.3, design §7.2). The panel reads `departmentDetail`, not the grid row, because the
 * buttons depend on the newest request:
 * - a Pending request locks the department: nothing can be changed until the Checker decides (BR-DEPT-010);
 * - a Rejected request shows the Checker's remarks read-only, so the Maker can see why (FSD §6 note);
 * - a rejected New Department can only be resubmitted with a corrected name or closed (G-1, E-17).
 * The footer is the FSD's (§5.3): Cancel, Save Changes, or Close / Resubmit. Delete is on the grid row.
 */
export function DepartmentModifySheet({
  departmentId,
  onClose,
  onCompleted,
  onConfigureRules,
}: {
  departmentId: number;
  onClose: () => void;
  onCompleted: (message: string) => void;
  onConfigureRules: () => void;
}) {
  const { t } = useDepartmentTranslation();
  const detailQuery = useDepartmentDetail(departmentId);
  const detail = detailQuery.data;

  if (detail) {
    return (
      <ModifyForm
        // Remount on a refetch after a command, so the form starts from the department's new state.
        key={`${detail.departmentId}-${detail.latestRequest?.requestId ?? 0}-${detail.latestRequest?.status ?? ''}`}
        detail={detail}
        onClose={onClose}
        onCompleted={onCompleted}
        onConfigureRules={onConfigureRules}
      />
    );
  }

  return (
    <SideSheet
      eyebrow={t('MODIFY.EYEBROW')}
      title={t('MODIFY.LOADING_TITLE')}
      subtitle={t('MODIFY.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={
        <Button type="button" variant="secondary" onClick={onClose}>
          {t('FORM.CANCEL')}
        </Button>
      }
    >
      {detailQuery.isError ? (
        <div className="flex flex-col items-center gap-3">
          <PanelError message={departmentErrorMessage(detailQuery.error, t('ERROR.REQUEST_FAILED'))} />
          <Button type="button" variant="outline" size="sm" onClick={() => void detailQuery.refetch()}>
            {t('MODIFY.RETRY')}
          </Button>
        </div>
      ) : (
        <p role="status" className="p-6 text-center text-sm text-[var(--text-2)]">
          {t('MODIFY.LOADING')}
        </p>
      )}
    </SideSheet>
  );
}

/** The loaded panel, with its own footer. */
function ModifyForm({
  detail,
  onClose,
  onCompleted,
  onConfigureRules,
}: {
  detail: DepartmentDetail;
  onClose: () => void;
  onCompleted: (message: string) => void;
  onConfigureRules: () => void;
}) {
  const { t, i18n } = useDepartmentTranslation();
  const { timeZone } = useSessionDateTime();
  const { can } = usePermissions();
  const canWrite = can(PERM.departmentWrite);
  const [panelError, setPanelError] = useState<string | null>(null);

  const save = useSaveDepartment();
  const resubmit = useResubmitDepartment();
  const close = useCloseDepartment();
  const busy = save.isPending || resubmit.isPending || close.isPending;

  const {
    register,
    control,
    handleSubmit,
    trigger,
    getValues,
    setError,
    watch,
    formState: { errors },
  } = useForm<ModifyDepartmentForm>({
    resolver: zodResolver(modifyDepartmentSchema),
    defaultValues: { departmentName: detail.departmentName, status: detail.status, comments: '' },
    shouldFocusError: true,
  });

  // A refusal is about what was submitted; editing anything clears it.
  useEffect(() => {
    const subscription = watch(() => setPanelError(null));
    return () => subscription.unsubscribe();
  }, [watch]);

  const request = detail.latestRequest;
  const pending = detail.hasPendingRequest;
  const rejectedNew = detail.isRejectedNewDepartment;
  // A rejected New: the Maker resubmits or closes; failing that a fallback closer may Close, with remarks (design §10.5).
  const makerActs = rejectedNew && detail.callerIsMaker;
  const fallbackClose = rejectedNew && !detail.callerIsMaker && detail.canFallbackClose;
  // Modify / Delete only while nothing is pending and the department isn't a rejected New Department.
  const canModify = canWrite && detail.canModifyOrDelete;
  const nameEditable = canModify || (canWrite && makerActs);

  // A Pending New Department carries the Pending status; keep it as the shown option rather than offer it.
  const statusOptions: DepartmentStatus[] = isEditable(detail.status)
    ? [...EDITABLE_STATUSES]
    : [detail.status, ...EDITABLE_STATUSES];

  function fail(error: unknown) {
    const fieldErrors = departmentFieldErrors(error, SERVER_FIELDS);
    if (fieldErrors.length === 0) {
      setPanelError(departmentErrorMessage(error, t('ERROR.REQUEST_FAILED')));
      return;
    }
    fieldErrors.forEach(({ field, message }, i) =>
      setError(field, { type: SERVER_ERROR, message }, { shouldFocus: i === 0 }),
    );
  }

  /** Name is required where it is editable; comments always (BR-DEPT-004). Focus goes to the first error. */
  const saveChanges = handleSubmit(async (values) => {
    if (values.departmentName === detail.departmentName && values.status === detail.status) {
      setPanelError(t('MODIFY.NO_CHANGES'));
      return;
    }
    try {
      await save.mutateAsync({
        isUpdate: true,
        departmentId: detail.departmentId,
        deptCode: detail.deptCode,
        departmentName: values.departmentName,
        status: values.status,
        remarks: values.comments,
      });
      onCompleted(t('TOAST.CHANGES_SAVED', { code: detail.deptCode }));
    } catch (error) {
      fail(error);
    }
  });

  const resubmitNew = handleSubmit(async (values) => {
    if (!request) return;
    try {
      await resubmit.mutateAsync({
        departmentId: detail.departmentId,
        departmentName: values.departmentName,
        remarks: values.comments,
        resubmissionOf: request.requestId,
      });
      onCompleted(t('TOAST.RESUBMITTED', { code: detail.deptCode }));
    } catch (error) {
      fail(error);
    }
  });

  /** Closing keeps the name as it is: only the comments are checked, and only for a fallback close (Maker: optional). */
  async function closeNew() {
    if (!request) return;
    if (fallbackClose && !(await trigger('comments', { shouldFocus: true }))) return;
    try {
      await close.mutateAsync({
        departmentId: detail.departmentId,
        remarks: getValues('comments').trim(),
        closesRequestId: request.requestId,
      });
      onCompleted(t('TOAST.CLOSED', { code: detail.deptCode }));
    } catch (error) {
      fail(error);
    }
  }

  const disabledReason = pending ? t('BLOCKED.PENDING') : rejectedNew ? t('BLOCKED.REJECTED_NEW') : undefined;

  // Each control is gated on its own: <Can> applies a denial to its one child, and a fragment can't carry one.
  const footer = (
    <PanelFooter onCancel={onClose}>
      {rejectedNew ? (
        <>
          {(makerActs || fallbackClose) && (
            <Can permission={PERM.departmentWrite}>
              <Button
                type="button"
                variant="secondary"
                disabled={busy}
                onClick={() => void closeNew()}
                // The header's ✕ is also named "Close"; this one closes the rejected department, not the panel.
                aria-label={t('MODIFY.CLOSE_LABEL', { code: detail.deptCode })}
              >
                {t('MODIFY.CLOSE')}
              </Button>
            </Can>
          )}
          {makerActs && (
            <Can permission={PERM.departmentWrite}>
              <Button type="button" variant="primary" disabled={busy} onClick={() => void resubmitNew()}>
                {t('MODIFY.RESUBMIT')}
              </Button>
            </Can>
          )}
        </>
      ) : (
        <Can permission={PERM.departmentWrite}>
          <Button
            type="button"
            variant="primary"
            disabled={!canModify || busy}
            title={canModify ? undefined : disabledReason}
            onClick={() => void saveChanges()}
          >
            {save.isPending ? t('FORM.SAVING') : t('MODIFY.SAVE_CHANGES')}
          </Button>
        </Can>
      )}
    </PanelFooter>
  );

  return (
    <SideSheet
      eyebrow={t('MODIFY.EYEBROW')}
      title={detail.departmentName}
      subtitle={t('MODIFY.SUBTITLE')}
      width={PANEL_WIDTH}
      onClose={onClose}
      footer={footer}
    >
      <div>
        <PanelError message={panelError} />

        {pending && request && (
          <div
            role="status"
            className="mb-4 flex gap-2 rounded-lg border border-[var(--accent-amber)]/40 bg-[var(--accent-amber)]/10 px-3 py-2 text-xs text-[var(--text-primary)]"
          >
            <Info size={14} className="mt-0.5 shrink-0 text-[var(--accent-amber)]" aria-hidden="true" />
            <span>
              {t('MODIFY.PENDING_NOTICE', {
                label: lastActionLabel(t, request.action, request.status),
                requestId: request.requestId,
                makerBy: request.makerBy,
              })}
            </span>
          </div>
        )}

        {request?.status === 'Rejected' && (
          <section
            aria-labelledby="checker-remarks-heading"
            className="mb-4 rounded-lg border border-[var(--accent-red)]/40 bg-[var(--accent-red)]/5 px-3 py-2"
          >
            <h3 id="checker-remarks-heading" className="text-xs font-bold uppercase tracking-wider text-[var(--accent-red)]">
              {lastActionLabel(t, request.action, request.status)}
            </h3>
            <p className="mt-1 text-[11px] text-[var(--text-muted)]">
              {t('MODIFY.CHECKER', {
                checker: request.checkerBy ?? '—',
                at: formatPanelDateTime(request.checkerAt, i18n.language, timeZone),
              })}
            </p>
            <label htmlFor="checker-remarks" className="mt-2 block text-xs font-semibold text-[var(--text-primary)]">
              {t('MODIFY.CHECKER_REMARKS')}
            </label>
            <Textarea
              id="checker-remarks"
              value={request.checkerRemarks ?? ''}
              readOnly
              rows={3}
              className="input-cls mt-1 w-full cursor-default resize-none bg-[var(--bg-secondary)] text-xs text-[var(--text-2)]"
            />
          </section>
        )}

        {fallbackClose && request && (
          <div
            role="note"
            className="mb-4 flex gap-2 rounded-lg border border-[var(--accent-amber)]/40 bg-[var(--accent-amber)]/10 px-3 py-2 text-xs text-[var(--text-primary)]"
          >
            <Info size={14} className="mt-0.5 shrink-0 text-[var(--accent-amber)]" aria-hidden="true" />
            <span>{t('MODIFY.MAKER_INELIGIBLE', { makerBy: request.makerBy })}</span>
          </div>
        )}

        <div className="flex flex-col gap-3">
          <FormRow label={t('FORM.DEPT_CODE')} htmlFor="modify-dept-code">
            <ReadOnlyInput id="modify-dept-code" value={detail.deptCode} mono />
          </FormRow>
          <FormRow label={t('FORM.DEPARTMENT_NAME')} htmlFor="modify-dept-name" required={nameEditable}>
            <Input
              id="modify-dept-name"
              maxLength={MAX_DEPARTMENT_NAME}
              readOnly={!nameEditable}
              aria-required={nameEditable}
              error={fieldErrorText(t, errors.departmentName)}
              className={cn(
                'h-10 w-full text-xs',
                !nameEditable && 'cursor-not-allowed bg-[var(--bg-secondary)] text-[var(--text-2)]',
              )}
              {...register('departmentName')}
            />
          </FormRow>
          <FormRow label={t('FORM.STATUS')} htmlFor="modify-dept-status">
            <Controller
              control={control}
              name="status"
              render={({ field }) => (
                <Select
                  id="modify-dept-status"
                  value={field.value}
                  onValueChange={(v) => field.onChange(v as DepartmentStatus)}
                  disabled={!canModify}
                  options={statusOptions.map((s) => ({ value: s, label: statusLabel(t, s), disabled: !isEditable(s) }))}
                  className="h-10 w-full text-xs"
                />
              )}
            />
          </FormRow>
          <FormRow label={t('MODIFY.CREATED_ON')} htmlFor="modify-created-on">
            <ReadOnlyInput id="modify-created-on" value={formatPanelDateTime(detail.createdDate, i18n.language, timeZone)} />
          </FormRow>
          <FormRow label={t('MODIFY.CREATED_BY')} htmlFor="modify-created-by">
            <ReadOnlyInput id="modify-created-by" value={detail.createdBy} />
          </FormRow>
          <FormRow label={t('MODIFY.LAST_MODIFIED')} htmlFor="modify-last-modified">
            <ReadOnlyInput id="modify-last-modified" value={formatPanelDateTime(detail.lastModifiedAt, i18n.language, timeZone)} />
          </FormRow>
          <FormRow label={t('MODIFY.LAST_MODIFIED_BY')} htmlFor="modify-last-modified-by">
            <ReadOnlyInput id="modify-last-modified-by" value={detail.lastModifiedBy ?? '—'} />
          </FormRow>
        </div>

        {/* Department Rule Configuration: an inert stub until that screen exists (design §7.3, AC-075). */}
        <Button
          type="button"
          unstyled
          onClick={onConfigureRules}
          className="mt-5 flex w-full items-center gap-3 rounded-xl border border-[var(--primary-blue)]/30 bg-[var(--primary-blue)]/5 px-4 py-3 text-start"
        >
          <Settings size={16} className="shrink-0 text-[var(--text-primary)]" aria-hidden="true" />
          <span className="min-w-0 flex-1">
            <span className="block text-sm font-semibold text-[var(--primary-blue)]">{t('MODIFY.RULE_CONFIG_TITLE')}</span>
            <span className="block text-xs text-[var(--primary-blue)]/80">{t('MODIFY.RULE_CONFIG_SUBTITLE')}</span>
          </span>
        </Button>

        {canWrite && (canModify || makerActs || fallbackClose) && (
          <div className="mt-5">
            <RemarksField
              id="modify-comments"
              label={t('MODIFY.COMMENTS')}
              accent="amber"
              placeholder={t('MODIFY.COMMENTS_PLACEHOLDER')}
              error={fieldErrorText(t, errors.comments)}
              {...register('comments')}
            />
          </div>
        )}
      </div>
    </SideSheet>
  );
}
