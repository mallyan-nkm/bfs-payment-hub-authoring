import type { RefObject } from 'react';
import { Button, Can, sessionInstant } from '@paymenthub/ui';
import type { SmartGridColumn } from '@paymenthub/ui';
import { DepartmentStatusBadge, LastActionBadge } from './badges';
import { lastActionLabel, statusLabel } from './i18n';
import type { DepartmentT } from './i18n';
import { PERM } from '../../shared/auth/permissionKeys';
import type { DepartmentRow } from './types';

/**
 * Handlers and the live page, behind a ref. SmartGrid snapshots column definitions on first mount and
 * never re-reads them (see `SlNoView` in the technical exception columns), so the render closures must
 * read through a ref to see today's page and handlers.
 */
export interface DepartmentGridView {
  rows: DepartmentRow[];
  page: number;
  pageSize: number;
  onViewModify: (row: DepartmentRow) => void;
  onAuditTrail: (row: DepartmentRow) => void;
  onDelete: (row: DepartmentRow) => void;
}

/**
 * Why a row can't be deleted right now — a `DEPARTMENT` translation key — or null when it can (AC-DEPT-073, read
 * with FSD §5.3: Delete lives on the grid, not in View & Modify). A pending request locks the department
 * (BR-DEPT-010), and a rejected New Department can only be resubmitted or closed (G-1). The server refuses both
 * anyway; this saves the operator the round trip.
 */
export function deleteBlockedReason(r: DepartmentRow): string | null {
  if (r.lastRequestStatus === 'Pending') return 'BLOCKED.PENDING';
  if (r.lastRequestAction === 'NewDepartment' && r.lastRequestStatus === 'Rejected') {
    return 'BLOCKED.REJECTED_NEW';
  }
  return null;
}

/**
 * Column keys double as the export's column keys (DepartmentExportMapper), and `sortKey` is the backend's
 * sort whitelist name (`DepartmentListSort`). Total Users has no sort: it is counted after the query.
 */
export function buildColumns(view: RefObject<DepartmentGridView>, t: DepartmentT): SmartGridColumn<DepartmentRow>[] {
  return [
    {
      key: 'slNo',
      label: t('COLUMNS.SL'),
      locked: true,
      numeric: true,
      render: (r) => {
        const { rows, page, pageSize } = view.current;
        const index = rows.indexOf(r);
        return index < 0 ? '—' : (page - 1) * pageSize + index + 1;
      },
    },
    {
      key: 'deptCode',
      label: t('COLUMNS.DEPT_CODE'),
      sortKey: 'DeptCode',
      getValue: (r) => r.deptCode,
      render: (r) => <span className="pq-refno-cell font-mono font-bold">{r.deptCode}</span>,
    },
    {
      key: 'departmentName',
      label: t('COLUMNS.DEPARTMENT_NAME'),
      sortKey: 'DepartmentName',
      getValue: (r) => r.departmentName,
    },
    {
      key: 'createdDate',
      label: t('COLUMNS.CREATED'),
      sortKey: 'CreatedDate',
      getValue: (r) => sessionInstant(r.createdDate, 'date'),
    },
    {
      key: 'createdBy',
      label: t('COLUMNS.CREATED_BY'),
      sortKey: 'CreatedBy',
      getValue: (r) => r.createdBy,
    },
    {
      key: 'lastModifiedAt',
      label: t('COLUMNS.LAST_MODIFIED'),
      sortKey: 'LastModifiedAt',
      getValue: (r) => sessionInstant(r.lastModifiedAt, 'date'),
    },
    {
      key: 'lastModifiedBy',
      label: t('COLUMNS.LAST_MODIFIED_BY'),
      sortKey: 'LastModifiedBy',
      getValue: (r) => r.lastModifiedBy ?? '—',
    },
    {
      key: 'totalUsers',
      label: t('COLUMNS.TOTAL_USERS'),
      numeric: true,
      align: 'right',
      getValue: (r) => String(r.totalUsers),
    },
    {
      key: 'status',
      label: t('COLUMNS.STATUS'),
      sortKey: 'Status',
      getValue: (r) => statusLabel(t, r.status),
      render: (r) => <DepartmentStatusBadge status={r.status} />,
    },
    {
      key: 'lastAction',
      label: t('COLUMNS.LAST_ACTION'),
      // The FSD labels are longer than the mockup's; the badge is nowrap, so the column widens to fit.
      getValue: (r) => lastActionLabel(t, r.lastRequestAction, r.lastRequestStatus) ?? '—',
      render: (r) => <LastActionBadge action={r.lastRequestAction} status={r.lastRequestStatus} />,
    },
    {
      key: 'actions',
      label: t('COLUMNS.ACTIONS'),
      locked: true,
      render: (r) => {
        const blocked = deleteBlockedReason(r);
        return (
          <div className="pq-row-actions">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                view.current.onViewModify(r);
              }}
              aria-label={t('ROW.VIEW_MODIFY_LABEL', { code: r.deptCode })}
            >
              {t('ROW.VIEW_MODIFY')}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                view.current.onAuditTrail(r);
              }}
              aria-label={t('ROW.AUDIT_LABEL', { code: r.deptCode })}
            >
              {t('ROW.AUDIT')}
            </Button>
            {/* What a denial looks like is the render policy's to decide, not this screen's (RBAC §13). */}
            <Can permission={PERM.departmentWrite}>
              <Button
                type="button"
                variant="danger"
                size="sm"
                disabled={blocked !== null}
                title={blocked ? t(blocked) : undefined}
                onClick={(e) => {
                  e.stopPropagation();
                  view.current.onDelete(r);
                }}
                aria-label={t('ROW.DELETE_LABEL', { code: r.deptCode })}
              >
                {t('ROW.DELETE')}
              </Button>
            </Can>
          </div>
        );
      },
    },
  ];
}
