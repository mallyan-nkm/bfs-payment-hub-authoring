/**
 * Locale-aware date formatting for the Department panels (React UI guideline §16; UTC date-time design §6.7, task
 * T-23). The API sends UTC instants; they are shown in the **session zone**, `dd-MM-yyyy HH:mm:ss`, in the reader's
 * locale digits, through the `@paymenthub/ui` date-time module.
 */
import { formatInstant, sessionDateTimeContext } from '@paymenthub/ui';

/**
 * The locale a date is formatted in. English is the UAE's `en-GB` day-first order, which the FSD's `dd-MM-yyyy`
 * follows; Arabic is `ar-AE`.
 */
export function dateLocale(language: string | undefined): string {
  if (language?.startsWith('ar')) return 'ar-AE';
  return 'en-GB';
}

/**
 * `2026-09-28T14:15:30Z` → `28-09-2026 18:15:30` in Dubai (the View & Modify panel's date and time, FSD §5.3), in the
 * reader's locale and the session zone (or `timeZone` when given). "—" when absent or unreadable.
 */
export function formatPanelDateTime(iso: string | null, language?: string, timeZone?: string): string {
  return formatInstant(iso, { timeZone: timeZone ?? sessionDateTimeContext().timeZone, locale: dateLocale(language) });
}
