/**
 * Department configuration types, mirroring the Operations API DTOs (Department design §5).
 * Field names are the API's camelCase JSON.
 */

/** A department's status. `Pending` is a workflow state: a New Department awaiting the Checker. */
export type DepartmentStatus = 'Active' | 'Disabled' | 'Pending';

/** The two statuses a Maker may choose on Modify. */
export const EDITABLE_STATUSES = ['Active', 'Disabled'] as const satisfies readonly DepartmentStatus[];

/** AdminChangeRequest.Action for a Department request. */
export type DepartmentRequestAction = 'NewDepartment' | 'ModifyDepartment' | 'DeleteDepartment';

/** AdminChangeRequest.Status. `Applied` is shown as "Approved" (Q-5). */
export type DepartmentRequestStatus = 'Pending' | 'Applied' | 'Rejected';

/** One grid row (`departmentList`). */
export interface DepartmentRow {
  departmentId: number;
  deptCode: string;
  departmentName: string;
  status: DepartmentStatus;
  createdDate: string;
  createdBy: string;
  /** Null until the department has been modified (AC-070). */
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  totalUsers: number;
  /** The newest request, raw; null when there is none. The label is built by `lastActionLabel`. */
  lastRequestAction: DepartmentRequestAction | null;
  lastRequestStatus: DepartmentRequestStatus | null;
}

export interface DepartmentListResponse {
  items: DepartmentRow[];
  pageNumber: number;
  pageSize: number;
  totalRecords: number;
  totalPages: number;
}

/** The backend's sort whitelist (`DepartmentListSort`). Total Users can't be sorted. */
export type DepartmentSortBy =
  | 'DeptCode'
  | 'DepartmentName'
  | 'CreatedDate'
  | 'CreatedBy'
  | 'LastModifiedAt'
  | 'LastModifiedBy'
  | 'Status';

export interface DepartmentListParams {
  search?: string;
  status?: DepartmentStatus;
  sortBy?: DepartmentSortBy;
  sortDirection?: 'asc' | 'desc';
  pageSize: number;
  pageNumber: number;
}

export interface DepartmentRequestSummary {
  requestId: number;
  action: DepartmentRequestAction;
  status: DepartmentRequestStatus;
  makerBy: string;
  makerAt: string;
  makerRemarks: string;
  checkerBy: string | null;
  checkerAt: string | null;
  checkerRemarks: string | null;
}

/** `departmentDetail/{id}`: the current values plus the newest request. */
export interface DepartmentDetail {
  departmentId: number;
  deptCode: string;
  departmentName: string;
  status: DepartmentStatus;
  createdDate: string;
  createdBy: string;
  lastModifiedAt: string | null;
  lastModifiedBy: string | null;
  latestRequest: DepartmentRequestSummary | null;
  hasPendingRequest: boolean;
  /** The newest request is a rejected New Department: only Resubmit and Close apply (G-1). */
  isRejectedNewDepartment: boolean;
  canModifyOrDelete: boolean;
  /** The signed-in user is the Maker of the latest request (design §10.5). */
  callerIsMaker: boolean;
  /** The Maker is no longer eligible and the caller may Close the rejected New Department in their place (R-3). */
  canFallbackClose: boolean;
}

/** AdminAudit.Section values, in the Audit Trail filter's order (design §7.4, G-9). */
export const AUDIT_SECTIONS = [
  'Dept Details',
  'User Assignment',
  'Status Change',
  'Dept Created',
  'Approval',
] as const;

export type AuditSection = (typeof AUDIT_SECTIONS)[number];

/** One `departmentAudit` card. `oldData` / `newData` are JSON text. */
export interface DepartmentAuditEntry {
  sequenceNo: number;
  auditId: number;
  deptCode: string | null;
  requestId: number | null;
  action: string;
  section: AuditSection;
  userId: string;
  userName: string | null;
  userRole: string;
  remarks: string;
  changedFields: string | null;
  oldData: string | null;
  newData: string;
  actionDate: string;
}

export interface DepartmentAuditResponse {
  departmentId: number;
  items: DepartmentAuditEntry[];
  pageNumber: number;
  pageSize: number;
  totalRecords: number;
  totalPages: number;
}

export interface DepartmentAuditParams {
  section?: AuditSection;
  /** `yyyy-MM-dd`, an inclusive UTC day. */
  fromDate?: string;
  toDate?: string;
  pageSize: number;
  pageNumber: number;
}

export interface SaveDepartmentRequest {
  isUpdate: boolean;
  departmentId?: number | null;
  deptCode?: string | null;
  departmentName: string;
  status?: DepartmentStatus | null;
  remarks: string;
}

export interface DepartmentSavedResponse {
  departmentId: number;
  requestId: number;
  auditId: number;
  createdAt: string;
}

/** `errorCode`: the refusal's class (`DepartmentEndpoints.ErrorCodes`). */
export type DepartmentErrorCode =
  | 'ValidationFailed'
  | 'Unauthorized'
  | 'Forbidden'
  | 'NotFound'
  | 'Conflict'
  | 'PendingRequestExists'
  | 'ADMIN_REPAIR_NOT_REJECTED'
  | 'ADMIN_REPAIR_DIFFERENT_ENTITY'
  | 'ADMIN_REPAIR_ACTION_NOT_REPAIRABLE'
  | 'ADMIN_REPAIR_SUPERSEDED'
  | 'ADMIN_REPAIR_DIFFERENT_MAKER'
  | 'ADMIN_APPROVAL_REMARKS_REQUIRED'
  | 'ADMIN_APPROVAL_POLICY_UNAVAILABLE'
  | 'ADMIN_APPROVAL_ENTITY_CONFLICT';

/**
 * `ruleCode`: the rule a refusal enforces (`DepartmentRuleCodes`, design §6, §11). A refusal tied to no single named
 * rule carries its generic class (Validation, Forbidden, NotFound, Conflict) instead.
 */
export const DEPARTMENT_RULE_CODES = {
  deptCodeUnique: 'BR-DEPT-001',
  deleteWithUsers: 'BR-DEPT-002',
  remarksMandatory: 'BR-DEPT-004',
  transactionsInProgress: 'BR-DEPT-009',
  onePendingRequest: 'BR-DEPT-010',
  noChanges: 'E-4',
  changedConcurrently: 'E-7',
  makerIsChecker: 'E-8',
  dateRangeInverted: 'E-10',
  otherTenantOrUnknown: 'E-14',
  rejectedNewDepartment: 'E-17',
  notARejectedNewDepartment: 'G-1',
} as const;

export type DepartmentRuleCode = (typeof DEPARTMENT_RULE_CODES)[keyof typeof DEPARTMENT_RULE_CODES];

/**
 * Every Department refusal: an RFC 7807 ProblemDetails (design §5). `detail` is the user-facing message; the
 * extensions carry `errorCode`, `ruleCode` and `traceId`, and on a pending-lock 409 `requestId`, `action` and
 * `makerBy`. A FluentValidation failure is a ValidationProblemDetails whose `errors` map names each failing
 * property (`DeptCode`, `Remarks`, …) with its messages.
 */
export interface DepartmentProblemDetails {
  type?: string;
  title?: string;
  status?: number;
  detail?: string;
  instance?: string;
  errorCode?: DepartmentErrorCode | (string & {});
  ruleCode?: DepartmentRuleCode | (string & {});
  traceId?: string;
  requestId?: number | null;
  action?: string | null;
  makerBy?: string | null;
  errors?: Record<string, string[]>;
}

export type DepartmentExportFormat = 'csv' | 'excel' | 'pdf';
