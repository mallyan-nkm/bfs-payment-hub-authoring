import { useState } from 'react';
import { Badge, Button, Input, Select, cn, useSessionDateTime } from '@paymenthub/ui';
import type { BadgeVariant } from '@paymenthub/ui';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { SideSheet } from '../../shared/components/SideSheet';
import { useDepartmentAudit } from './api';
import { auditFieldChanges, auditLevel, auditUserChanges } from './auditDiff';
import type { AuditField, AuditValue } from './auditDiff';
import { departmentErrorMessage } from './errors';
import { PANEL_WIDTH_XL, PanelError } from './formParts';
import { SECTION_KEY, useDepartmentTranslation } from './i18n';
import type { DepartmentT } from './i18n';
import { AUDIT_SECTIONS } from './types';
import type { AuditSection, DepartmentAuditEntry, DepartmentRow } from './types';

/** Fixed at 10, the mockup's page size, not the FSD's selectable one (G-11). */
const PAGE_SIZE = 10;

/** Badge variant and heading colour per section — blue, green, amber, grey and purple — all theme tokens. */
const SECTION_TONE: Record<AuditSection, { badge: BadgeVariant; heading: string; bar: string }> = {
  'Dept Details': {
    badge: 'blue',
    heading: 'text-[var(--accent-blue)]',
    bar: 'bg-[var(--accent-blue)]',
  },
  'User Assignment': {
    badge: 'green',
    heading: 'text-[var(--accent-green)]',
    bar: 'bg-[var(--accent-green)]',
  },
  'Status Change': {
    badge: 'amber',
    heading: 'text-[var(--accent-amber)]',
    bar: 'bg-[var(--accent-amber)]',
  },
  'Dept Created': {
    badge: 'outline',
    heading: 'text-[var(--text-2)]',
    bar: 'bg-[var(--text-muted)]',
  },
  Approval: {
    badge: 'purple',
    heading: 'text-[var(--accent-purple)]',
    bar: 'bg-[var(--accent-purple)]',
  },
};

const FIELD_KEY: Record<AuditField, string> = {
  deptCode: 'AUDIT.FIELDS.DEPT_CODE',
  departmentName: 'AUDIT.FIELDS.DEPT_NAME',
  status: 'AUDIT.FIELDS.DEPT_STATUS',
  isDeleted: 'AUDIT.FIELDS.DELETED',
};

/** A snapshot value as text: "—" for none, Yes / No for a flag. */
function valueText(t: DepartmentT, v: AuditValue): string {
  if (v === null) return '—';
  if (typeof v === 'boolean') return v ? t('AUDIT.YES') : t('AUDIT.NO');
  return v;
}

interface Filters {
  section: AuditSection | '';
  fromDate: string;
  toDate: string;
}

const NO_FILTERS: Filters = { section: '', fromDate: '', toDate: '' };

/** Icons that point along the reading direction mirror under RTL (React UI guideline §15). */
const FLIP_IN_RTL = 'rtl:rotate-180';

/**
 * Audit Trail (FSD §5.5, design §7.4): every recorded change to one department, newest first, as cards.
 * Section and the From / To days are applied by the server (`departmentAudit`), ten cards a page.
 */
/** The department the trail is of; the Admin Activity Audit Log opens it from just the key and the code. */
export type DepartmentAuditTarget = Pick<DepartmentRow, 'departmentId' | 'deptCode'>;

export function DepartmentAuditTrailModal({ row, onClose }: { row: DepartmentAuditTarget; onClose: () => void }) {
  const { t } = useDepartmentTranslation();
  const [draft, setDraft] = useState<Filters>(NO_FILTERS);
  const [applied, setApplied] = useState<Filters>(NO_FILTERS);
  const [page, setPage] = useState(1);

  const auditQuery = useDepartmentAudit(row.departmentId, {
    section: applied.section || undefined,
    fromDate: applied.fromDate || undefined,
    toDate: applied.toDate || undefined,
    pageSize: PAGE_SIZE,
    pageNumber: page,
  });

  const entries = auditQuery.data?.items ?? [];
  const total = auditQuery.data?.totalRecords ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const start = (page - 1) * PAGE_SIZE;

  // `yyyy-MM-dd` strings compare in date order.
  const invertedRange = Boolean(draft.fromDate && draft.toDate && draft.toDate < draft.fromDate);

  function search() {
    setApplied(draft);
    setPage(1);
  }

  const sectionOptions = [
    { value: '', label: t('AUDIT.ALL_SECTIONS') },
    ...AUDIT_SECTIONS.map((s) => ({ value: s, label: t(SECTION_KEY[s]) })),
  ];

  const filterLabel = 'text-[11px] font-semibold text-[var(--text-2)]';

  return (
    <SideSheet
      eyebrow={t('AUDIT.EYEBROW', { code: row.deptCode })}
      title={t('AUDIT.TITLE')}
      subtitle={t('AUDIT.SUBTITLE')}
      width={PANEL_WIDTH_XL}
      onClose={onClose}
      toolbar={
        <form
          noValidate
          className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1fr_1fr_auto] sm:items-start"
          onSubmit={(e) => {
            e.preventDefault();
            if (!invertedRange) search();
          }}
        >
          <div className="flex min-w-0 flex-col gap-1">
            <label htmlFor="audit-section" className={filterLabel}>
              {t('AUDIT.SECTION')}
            </label>
            <Select
              id="audit-section"
              value={draft.section}
              onValueChange={(v) => setDraft((d) => ({ ...d, section: v as AuditSection | '' }))}
              options={sectionOptions}
              className="h-10 min-w-0 px-2 text-xs"
            />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <label htmlFor="audit-from" className={filterLabel}>
              {t('AUDIT.FROM')}
            </label>
            <Input
              id="audit-from"
              type="date"
              value={draft.fromDate}
              onChange={(e) => setDraft((d) => ({ ...d, fromDate: e.target.value }))}
              className="h-10 min-w-0 px-2 text-xs"
            />
          </div>
          <div className="flex min-w-0 flex-col gap-1">
            <label htmlFor="audit-to" className={filterLabel}>
              {t('AUDIT.TO')}
            </label>
            <Input
              id="audit-to"
              type="date"
              value={draft.toDate}
              onChange={(e) => setDraft((d) => ({ ...d, toDate: e.target.value }))}
              // The shared Input ties the message to the field (aria-invalid, aria-describedby).
              error={invertedRange ? t('AUDIT.RANGE_INVERTED') : undefined}
              className="h-10 min-w-0 px-2 text-xs"
            />
          </div>
          <div className="flex flex-col gap-1">
            {/* Keeps the button level with the controls, under the labels' row. */}
            <span className={cn(filterLabel, 'invisible')} aria-hidden="true">
              {t('AUDIT.SEARCH')}
            </span>
            <Button type="submit" variant="primary" disabled={invertedRange} className="h-10">
              {t('AUDIT.SEARCH')}
            </Button>
          </div>
        </form>
      }
      footer={
        <div className="flex w-full items-center justify-between gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>
            {t('AUDIT.CLOSE')}
          </Button>
          <nav aria-label={t('AUDIT.PAGES')} className="flex items-center gap-2 text-xs text-[var(--text-2)]">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={page <= 1 || auditQuery.isFetching}
              onClick={() => setPage((p) => p - 1)}
              icon={<ChevronLeft size={14} className={FLIP_IN_RTL} aria-hidden="true" />}
            >
              {t('AUDIT.PREV')}
            </Button>
            <span aria-live="polite">
              {t('AUDIT.RANGE', {
                from: total === 0 ? 0 : start + 1,
                to: total === 0 ? 0 : start + entries.length,
                total,
              })}
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={page >= totalPages || auditQuery.isFetching}
              onClick={() => setPage((p) => p + 1)}
            >
              {t('AUDIT.NEXT')}
              <ChevronRight size={14} className={FLIP_IN_RTL} aria-hidden="true" />
            </Button>
          </nav>
        </div>
      }
    >
      {auditQuery.isError ? (
        <PanelError message={departmentErrorMessage(auditQuery.error, t('ERROR.REQUEST_FAILED'))} />
      ) : auditQuery.isPending ? (
        <p role="status" className="p-6 text-center text-sm text-[var(--text-2)]">
          {t('AUDIT.LOADING')}
        </p>
      ) : entries.length === 0 ? (
        <p role="status" className="p-6 text-center text-sm text-[var(--text-2)]">
          {t('AUDIT.EMPTY')}
        </p>
      ) : (
        <ol className="flex flex-col gap-4" aria-label={t('AUDIT.LIST_LABEL')}>
          {entries.map((entry) => (
            <AuditCard key={entry.auditId} entry={entry} />
          ))}
        </ol>
      )}
    </SideSheet>
  );
}

function AuditCard({ entry }: { entry: DepartmentAuditEntry }) {
  const { t } = useDepartmentTranslation();
  const { formatInstant } = useSessionDateTime();
  const tone = SECTION_TONE[entry.section] ?? SECTION_TONE['Dept Details'];
  const sectionText = SECTION_KEY[entry.section] ? t(SECTION_KEY[entry.section]) : entry.section;
  const userChanges = auditUserChanges(entry);
  const changes = userChanges ? [] : auditFieldChanges(entry);
  const decision = entry.section === 'Approval' ? entry.action : null;
  const level = auditLevel(entry);

  return (
    <li className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
      <div className="flex items-start justify-between gap-3 border-b border-[var(--border)] bg-[var(--bg-secondary)]/50 px-4 py-3">
        <div className="flex items-center gap-3">
          <span
            className="grid size-7 shrink-0 place-items-center rounded-full bg-[var(--bg-3)] text-xs font-bold text-[var(--text-2)]"
            aria-label={t('AUDIT.ENTRY', { n: entry.sequenceNo })}
          >
            {entry.sequenceNo}
          </span>
          <div>
            <p className="text-sm font-bold text-[var(--primary-blue)]">
              {entry.userName ?? entry.userId}
              <span className="ms-2 text-[11px] font-normal text-[var(--text-muted)]">{entry.userRole}</span>
            </p>
            <p className="text-[11px] text-[var(--text-muted)]">{formatInstant(entry.actionDate)}</p>
          </div>
        </div>
        <Badge variant={tone.badge} className="whitespace-nowrap">
          {sectionText}
        </Badge>
      </div>

      <div className="px-4 py-3">
        <p className={cn('mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider', tone.heading)}>
          <span className={cn('h-3.5 w-[3px] rounded', tone.bar)} aria-hidden="true" />
          {sectionText}
        </p>

        {decision && (
          <p className="py-1 text-sm text-[var(--text-primary)]">
            {t('AUDIT.DECISION')}{' '}
            <span className="font-semibold">{decision === 'LevelApproved' ? t('AUDIT.LEVEL_APPROVED') : decision}</span>
            {level && (
              <span className="ms-2 text-xs text-[var(--text-2)]">
                {t('AUDIT.LEVEL_OF', { level: level.level, total: level.totalLevels })}
              </span>
            )}
          </p>
        )}

        {changes.map((c) => (
          <div key={c.field} className="flex flex-wrap items-center gap-2 py-1 text-sm">
            <span className="text-[var(--text-primary)]">{t(FIELD_KEY[c.field])}</span>
            {/* A New has no before-snapshot: show the created value alone, not a dash and an arrow. */}
            {c.before !== null && (
              <>
                <span className="rounded bg-[var(--accent-red)]/10 px-2 py-0.5 text-xs font-semibold text-[var(--accent-red)]">
                  <span className="sr-only">{t('AUDIT.FROM_SR')} </span>
                  {valueText(t, c.before)}
                </span>
                <ArrowRight size={14} className={cn('shrink-0 text-[var(--text-muted)]', FLIP_IN_RTL)} aria-hidden="true" />
              </>
            )}
            <span className="rounded bg-[var(--accent-green)]/10 px-2 py-0.5 text-xs font-semibold text-[var(--accent-green)]">
              <span className="sr-only">{t('AUDIT.TO_SR')} </span>
              {valueText(t, c.after)}
            </span>
          </div>
        ))}

        {userChanges?.map((u) => (
          <p
            key={`${u.added ? '+' : '-'}${u.userId}`}
            className={cn(
              'flex items-center gap-2 py-1 text-sm',
              u.added ? 'text-[var(--accent-green)]' : 'text-[var(--accent-red)]',
            )}
          >
            <span className="font-bold" aria-label={u.added ? t('AUDIT.ADDED') : t('AUDIT.REMOVED')}>
              {u.added ? '+' : '−'}
            </span>
            {u.userId}
            {u.userName ? ` — ${u.userName}` : ''}
          </p>
        ))}
      </div>

      <p className="border-t border-[var(--border)] bg-[var(--bg-secondary)]/50 px-4 py-2 text-xs text-[var(--text-2)]">
        <span className="font-semibold text-[var(--text-primary)]">{t('AUDIT.COMMENTS')}</span> {entry.remarks}
      </p>
    </li>
  );
}
