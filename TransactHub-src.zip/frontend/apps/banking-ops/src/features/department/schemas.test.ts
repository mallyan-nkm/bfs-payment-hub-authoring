import { describe, expect, it } from 'vitest';
import { VALIDATION, deleteDepartmentSchema, modifyDepartmentSchema, newDepartmentSchema } from './schemas';

/** The first message for `path`, or undefined when that field passed. */
function messageFor(result: { success: boolean; error?: { issues: { path: (string | number)[]; message: string }[] } }, path: string) {
  return result.error?.issues.find((i) => i.path[0] === path)?.message;
}

describe('New Department schema (FSD §5.1, E-2, Q-8, BR-DEPT-004)', () => {
  it('requires every field, trimming before it checks', () => {
    const result = newDepartmentSchema.safeParse({ deptCode: '  ', departmentName: ' ', remarks: '\t' });

    expect(result.success).toBe(false);
    expect(messageFor(result, 'deptCode')).toBe(VALIDATION.deptCodeRequired);
    expect(messageFor(result, 'departmentName')).toBe(VALIDATION.departmentNameRequired);
    expect(messageFor(result, 'remarks')).toBe(VALIDATION.remarksRequired);
  });

  it.each(['FIN 01', 'FIN-01', 'FIN_01', 'FÍN', 'ＦＩＮ'])('refuses %j: ASCII letters and digits only', (deptCode) => {
    const result = newDepartmentSchema.safeParse({ deptCode, departmentName: 'Finance', remarks: 'r' });

    expect(messageFor(result, 'deptCode')).toBe(VALIDATION.deptCodeNotAlphanumeric);
  });

  it('reports a blank code as required, not as non-alphanumeric', () => {
    const result = newDepartmentSchema.safeParse({ deptCode: '', departmentName: 'Finance', remarks: 'r' });

    expect(messageFor(result, 'deptCode')).toBe(VALIDATION.deptCodeRequired);
  });

  it('upper-cases the code and trims every field', () => {
    expect(newDepartmentSchema.parse({ deptCode: ' fin01 ', departmentName: ' Finance ', remarks: ' New team ' })).toEqual({
      deptCode: 'FIN01',
      departmentName: 'Finance',
      remarks: 'New team',
    });
  });
});

describe('Modify schema (FSD §5.3, BR-DEPT-004)', () => {
  it('requires the name and the modification comments', () => {
    const result = modifyDepartmentSchema.safeParse({ departmentName: ' ', status: 'Active', comments: '' });

    expect(messageFor(result, 'departmentName')).toBe(VALIDATION.departmentNameRequired);
    expect(messageFor(result, 'comments')).toBe(VALIDATION.modificationCommentsRequired);
  });

  it('accepts only the three department statuses', () => {
    expect(modifyDepartmentSchema.safeParse({ departmentName: 'F', status: 'Pending', comments: 'c' }).success).toBe(true);
    expect(modifyDepartmentSchema.safeParse({ departmentName: 'F', status: 'Deleted', comments: 'c' }).success).toBe(false);
  });
});

describe('Delete schema (FSD §5.4, BR-DEPT-004)', () => {
  it('requires remarks and sends them trimmed', () => {
    expect(messageFor(deleteDepartmentSchema.safeParse({ remarks: '   ' }), 'remarks')).toBe(VALIDATION.remarksRequired);
    expect(deleteDepartmentSchema.parse({ remarks: ' No longer used ' })).toEqual({ remarks: 'No longer used' });
  });
});
