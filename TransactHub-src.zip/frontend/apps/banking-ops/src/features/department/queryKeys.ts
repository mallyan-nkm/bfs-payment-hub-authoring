import type { DepartmentAuditParams, DepartmentListParams } from './types';

/** Department query keys (React UI guideline §7). Every command invalidates `all`. */
export const departmentKeys = {
  all: ['departments'] as const,
  list: (params: DepartmentListParams) => ['departments', 'list', params] as const,
  detail: (departmentId: number) => ['departments', 'detail', departmentId] as const,
  audit: (departmentId: number, params: DepartmentAuditParams) => ['departments', 'audit', departmentId, params] as const,
};
