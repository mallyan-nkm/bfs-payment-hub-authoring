# RBAC & Authorization Architecture — PaymentHub

> Status: **Revision 2 — architecture of record** · Author: Architecture · Date: 2026-08-25
> Supersedes: revision 1 (2026-08-16, uncommitted). Revision 1 was a *proposal*; this revision is
> the design **as built**, plus the work that remains.
> Audience: backend, frontend and platform engineers extending authorization in PaymentHub.
> Companion: `identity-federation-security-broker-design.md` — *who is the caller*. This document
> starts after that handoff has produced a role-set.
> Register entry: **TDR-021** (not TDR-019 — see §11.1).
> Implementation status detail: [RBAC-Implementation-Status.md](RBAC-Implementation-Status.md).

---

## 0. How to read this revision

Revision 1 described a system that did not exist yet. Most of it now does, and the act of building
it changed nine things — some because the proposal was wrong about the codebase, some because
implementation found a stronger mechanism, and two because a proposed mechanism turned out to be
unnecessary.

**This document is now the authority.** Where revision 1 and this revision disagree, this one is
correct and the code matches it. §4 lists every disagreement explicitly, with the reason, so that
nobody reconstructs the old shape from the old document. The status doc quoted "§5.5 / §5.8 / R8"
against a design that was not in the repository; those references now resolve here.

Three things are deliberately **out of scope** for this revision and are named but not designed:
governance (SoD, limit matrices, elevation/PIM, delegation, recertification), policy versioning
with rollback, and session role activation. §10 says what state they are in so the next phase has a
starting point, and no more than that.

**One caveat on the baseline.** The entire authorization stack — `PaymentHub.Shared/Authorization/`,
the ten `db-script/rbac-*.sql` files, the frontend permission store — is *untracked* on `dev` as of
this date. Everything §3 describes is real and runs; none of it is committed. Committing it, this
document, and the status doc together is the first task of the next phase, not part of it.

---

## 1. Executive summary

**The model held.** Authorization is RBAC with role hierarchy and additive/subtractive overlays,
compiled to a dense permission bitset at policy-publish time, cached by **role-set hash × tenant-set
× policy epoch** rather than by user, and enforced by bit tests at six points. Ten thousand users
collapse onto a few hundred cache entries; a decision is a shift, a mask and one hash lookup. None
of that changed under implementation.

**What changed is where the intelligence sits.** Three mechanisms moved out of the compiled set and
into the places that could not forget them:

- **The rail became a gate inside `PermissionSet.Has()`** rather than a resource dimension checked
  per endpoint. Revoking `rail:WPS:access` switches off every WPS page, control, action and field in
  one row, with no call site opting in (§5.2).
- **Field masking became a property attribute plus a JSON serialization modifier** rather than an
  obligations dictionary on the compiled set. Masking is a property of the *value*, applied wherever
  that value is serialized (§5.4).
- **Tenant scope became a request filter** that resolves the caller's tenant before the handler
  runs, rather than a predicate each query remembers to apply (§5.5).

The common shape of all three: *a control that each call site can forget is not a control.* That
sentence is the single most useful thing implementation taught this design, and it is the reason to
prefer a chokepoint over a convention every time the choice comes up.

**What is broken and comes first:** the L2 cache tier. As wired it is not a cross-process tier at
all when Redis is absent, and it turns a cache fault into a 500 on every gated endpoint when Redis
is present. L2 becomes a **pluggable provider with exactly one implementation active**, defaulting
to a memory-optimized `SCHEMA_ONLY` table in the database the compiler already reads — the
filegroup and four precedent tables exist today. D-8 and §9.0.

**What is not built, and is in scope after that:** write-authority for request payloads (R6) beyond
per-operation checks, correlated-field masking groups, the edge enforcement point, and coverage for
the gateway and the internal services (§9).

**What is not built and is explicitly next, not now:** everything in §10.

---

## 2. Load-bearing principles

Unchanged from revision 1, with three additions earned during implementation. When a design question
is not answered explicitly below, resolve it against these.

1. **Compile, don't interpret.** Policy resolves to a bitset when an administrator publishes. Never
   during a request.
2. **Key the cache by role-set, not by user.** Users holding the same *valid* roles in the same
   tenants share one cached decision set.
3. **The server enforces; the client only reflects.** A hidden or disabled control is a usability
   affordance, never a security control.
4. **Deny by default, and deny overrides allow.** An unknown permission key denies. A `Deny` row
   anywhere in the composition outranks every `Allow`.
   *Amended 2026-11-06:* "anywhere" now means across a user's separately assigned roles and
   overlays. **Inside one role's parent chain the nearest role holding a live row decides** — a sub
   role's own `Allow` overrides its template's `Deny` and vice versa (Screens FSD: a Sub Role
   "inherit[s] all properties of the base role, but can override"). See D-13.
5. **Prefer a chokepoint to a convention.** If a rule can be forgotten at a call site, move it
   somewhere that cannot forget — `Has()`, an endpoint filter, a serialization modifier. *(New.)*
6. **One implementation of policy resolution.** Anything that answers "what may this caller do"
   resolves through `IPermissionSetStore`. A second implementation that mirrors the compiler
   faithfully will still disagree with it. *(New — see §5.8.)*
7. **A stale deny is a support ticket; a stale allow is a security incident.** Bias every ambiguity
   toward the ticket. *(Promoted from a footnote — it decides the epoch rules, the masking fallback,
   the snapshot fallback and the role-window intersection.)*

---

## 3. Baseline — what is built and enforced

This replaces revision 1 §2 ("Where PaymentHub is today"), which is now obsolete in every row.

### 3.1 The stack

| Capability | Where | Grain |
|---|---|---|
| Permission catalog — 63 entries, index-stable, append-only | `PermissionCatalog.cs` | 11 Page · 3 Control · 39 Action · 4 Field · 6 Rail |
| Compilation to a bitset; role hierarchy; overlays; deny-overrides | `PermissionCompiler.CompileAsync` | 2 × 64-bit words (16 B) |
| Administrator `'*'` wildcard, expanded against the catalog at compile time | `PermissionCatalog.SetAllBits` | — |
| L0/L1 cache keyed `psh:epoch`; single-flight; jittered TTL | `PermissionSetStore` | — |
| L2 cross-process tier | `ICacheService` — **defective as wired, see §9.0** | to be replaced per D-8 |
| Endpoint gate (point 2) | `RequirePermissionExtensions.RequirePermission` | **87 endpoint registrations, 6 services** |
| Payload-operation authority (point 3) | `RequirePayloadPermissionAsync` | in-handler |
| Tenant scope (point 4) | `TenantScopeExtensions` | `RequireTenantScope` / `RequireTenantReadScope` |
| Response field masking (point 5) | `FieldMasking` + `[Sensitive]` | serialization-time |
| UI gates (point 6, advisory) | `usePermissions()` · `<Can>` · `PermissionRoute` | route · control · column |
| Rail cascade | `PermissionDefinition.Rail` + `PermissionSet.Has` | 6 rails |
| Time-bounded grants (R5) | `GetUserGrantWindowAsync` + role filtering before the hash | per user |
| Sub-second invalidation | `PolicyEpochSubscriber` + `TryAdoptEpoch` over MQTT | estate-wide |
| Browser staleness detection | `X-Policy-Epoch` header + `observePolicyEpoch` | per response |
| Catalog↔database drift detection | `PermissionCatalogDriftCheck` | startup |
| Coverage ratchet | `PermissionCoverage` + `tools/scripts/authz-coverage.ps1` | per service |
| Append-only decision log (R18) | `AuthorizationDecisionSink` → `platform.AuthorizationDecisionLog` | batched |
| Explain / simulate (R19) | `PolicyAdministrationEndpoints` | API only, no UI |
| Service-principal admission | `IsServicePrincipal()` / `AllowsServicePrincipal()` | internal callers |

### 3.2 Coverage, honestly stated

From `tools/authz-coverage-baseline.json` (2026-09-05), the static count CI enforces:

| Service | Kind | Registrations | Declared | Undeclared |
|---|---|---|---|---|
| Operations | user-facing | 128 | 127 | **0** |
| Routing | user-facing | 36 | 35 | **0** |
| Configuration | user-facing | 12 | 11 | **0** |
| WpsBusiness | user-facing | 11 | 11 | **0** |
| ParticipantDirectory | user-facing | 7 | 6 | **0** |
| IAM | user-facing | 30 | 23 | 3 |
| **ApiGateway** | user-facing | 22 | 0 | **21** |
| WorkflowEngine · MessageProcessing · SmartIntegration · AI · Projection.Ingest · CoreServices · Identity | internal | 132 | 0 | 124 |
| Simulator | tool | 52 | 0 | 51 |
| | | | | **199 total** |

Declared plus undeclared does not equal registrations on most rows: health probes and the login
endpoint are excluded from both, because a probe is reachable before anyone has an identity and
requiring a permission to log in is circular. `PermissionCoverageTests` pins that exclusion.

Every user-facing service reached zero except the gateway and two IAM endpoints. The internal
services are the remaining bulk and are a different problem (§9.2).

### 3.3 Data model as built

```
platform.Rail                    (RailCode ← business key, SchemaName, DisplayName,
                                  UiLabel, IsActive)                                   rail master
platform.PermissionPage          (PermissionKey, [Index], Category Page|Rail, App, PageCode,
                                  GateRailId → Rail.Id, RailId → Rail.Id, IsRetired, …)
platform.PermissionPageItem      (PermissionKey, [Index], Category Control|Action|Field, App,
                                  PageId → PermissionPage.Id, PageCode, GateRailId → Rail.Id, …)
platform.Permission              (VIEW over the two — the catalog read contract)
platform.Roles                   (+ ParentRoleId, IsSystemRole, IsTemplate)          R9
platform.RolePermissions         (+ PermissionKey, Effect Allow|Deny,
                                  PermissionPageId →     PermissionPage.Id,
                                  PermissionPageItemId → PermissionPageItem.Id)      R8
platform.PermissionSet           (overlay header)                                    R10
platform.PermissionSetItem       (PermissionKey, Effect)                             R10
platform.PermissionSetAssignment (PermissionSetId, RoleId, UserId ← reserved, unread) R10
platform.UserRoles               (+ TenantId, ValidFrom, ValidTo — the ONLY window)   R5
platform.UserTenantAssignments   (TenantId, EntityId; '*' = every tenant)            R14
platform.PolicyEpoch             (single row, monotonic BIGINT, disk-based)          cache key
platform.AuthorizationDecisionLog(append-only; 3 indexes inc. one filtered)          R18
```

`BIGINT IDENTITY` PKs, no DB-level FKs, soft references by business ID, append-only for the log —
consistent with the repo constraints. The tables revision 1 named and this does not
(`ElevationGrant`, `SodConstraint`, `AuthorizationLimit`) belong to §10.

**The catalog is two tables, read as one.** `platform.Permission` was a single flat table whose
only structure was a `Category` string, which answered "what keys exist" and nothing else — the
question §9.5 has to answer is "here is every control on this page and its state for this role",
and a page was not a row anything could point at.
`db-script/incremental/rbac-permission-page-split-01092026.sql` splits it: `PermissionPage` holds
every page and every rail gate, `PermissionPageItem` holds every component, action and field with
`PageId` pointing at the page it belongs to. The control registry is now a JOIN rather than a
convention about how keys are spelled.

Four things about it are load-bearing:

- **`platform.Permission` survives as a view** over both, with an `INSTEAD OF INSERT`/`UPDATE` pair
  routing writes by `Category`. `PermissionCompiler` and `PermissionCatalogDriftCheck` only ever
  `SELECT` from it, so enforcement is untouched — the UNION ALL's two seeks are paid on the compile
  path, never on a request that hits cache. The view still exposes a `Rail` column, now reached
  through `platform.Rail` from `GateRailId`, because the drift check compares it against
  `PermissionDefinition.Rail` key by key. It exposes no `Id`: two `IDENTITY` ranges cannot be merged
  without inventing collisions, and nothing read it.
- **`[Index]` uniqueness now spans two tables**, which no unique index can enforce. §9 of the
  script raises on a bit position claimed twice and on a key present in both tables. The drift
  check still catches per-key index disagreement against code.
- **`PageId` is a surrogate reference, and `PageCode` is not a duplicate of it.** `PageId` points at
  `PermissionPage.Id` — the page's key was 200 bytes repeated on every item that named it. It is
  recoverable rather than fragile: `(App, PageCode)` is the page's business key, it carries a unique
  index, and §9 of the script rebuilds every `PageId` from it, so a page reseeded under new identity
  values is repaired by re-running the script.

  `PageCode` is a different fact from `PageId`, not the same one twice. It is the page the
  permission *key* claims, while `PageId` is what that claim resolved to. `PageCode` set with
  `PageId` NULL is the useful state: a key naming a screen that owns no page permission —
  `bankingops:wps.sif:upload` on `wps-initiate`, whose route is gated on `rail:WPS:access` alone,
  plus the retired index-16 tombstone on the same screen. Collapsing the two into one nullable Id
  would make that indistinguishable from a genuinely cross-page action.

- **Both columns are derived from `PermissionCatalog.Page`, and are NULL for most items on
  purpose.** `rbac-streamline-catalog-and-roles-07092026.sql` re-derives them from the code
  declarations, because while they were hand-typed three of the four populated rows were wrong:
  `corporate:create` / `:edit` named `corporate-registration` when both controls are rendered by
  `CorporateListPage`, and `ops:observability:manage` named a screen that exists in no React app.

  Six of the 46 live items carry a `PageCode`; the other 40 are NULL, which is the correct value
  rather than a gap. **The key→screen relation is one-to-many**, so a scalar column cannot express
  it: `config:setting:read` guards twelve screens in the banking-ops router, `ops:report:read` six,
  `ops:exception:read` three, `ops:page.dashboard:view` four; the field keys appear on every screen
  rendering an account number; and `routing:*`, `config:*`, `directory:*` and the two `:ingest`
  keys guard no screen at all. Electing one "primary" page for any of those would store a value
  wrong for most callers and give an administrator a screen list that is quietly incomplete.

  The many-to-many map is **`platform.UiScreenRegistry`**, which is row-per-screen with a nullable,
  *non-unique* `PermissionKey` — six screens share one key there without any being demoted to a
  footnote. These two columns keep only the 1:1 cases, where they are the only thing that can carry
  the fact.

  **The register is developer-seeded, in a dated script.** It formerly synced itself from the
  compiled catalog at every service start, and that was withdrawn for two reasons. It made the
  register exactly as wide as the catalog, when its whole purpose is to be wider — it answers *what
  exists in the product*, of which the gateable subset is a small part, so a register derived from
  the catalog cannot answer the question an administrator brings to it. And an automatic writer
  adopted a misspelled `Component` code as a real row on the next deploy, indistinguishable from a
  correct one, which made coverage unreviewable precisely because upkeep was automatic.
  `UiScreenRegistrySync` remains as an opt-in diagnostic (`Authorization:SyncUiScreenRegistry`,
  default **false**); rows a developer authored carry `Source = 'Manual'` and it neither overwrites
  nor retires them.

  A row with a **NULL `PermissionKey` is the common case, not a gap**: the screen or control exists
  and nothing gates it. `Kind` is `Page`, `Component` or `Field` — a field is distinguished from a
  component because it is gated by a `:view` / `:unmask` pair and masked at the API boundary, so
  offering it a button's disable/hide modes would be the wrong question about a value that has
  already arrived masked.

  **Linking is one-directional and gated on code.** Promoting a register row into
  `platform.PermissionPage` / `PermissionPageItem` is what makes it grantable, and
  `/iam/policy/permission-pages/register` refuses any key the deployed build does not declare in
  `PermissionCatalog`. That is not a limitation to route around: an index is a bit position in a
  compiled `PermissionSet`, so it cannot originate in a table without silently re-pointing every
  cached set. The register can therefore say "this control exists and a developer must catalogue it
  first", which is a more useful thing for an administrator to read than a link button that fails.
- **The rail is an Id reference into `platform.Rail`, not a string on the row.** See below.

**`platform.Rail` is the rail master.** The rail used to be a bare `NVARCHAR` repeated on every
gated row with nothing saying which values were legal, and the failure mode that allows is worse
than an ordinary broken reference: the cascade in §5.2 matches the code exactly, so `'WSP'` for
`'WPS'` produces a permission gated behind a rail nobody can hold. It denies every caller including
an administrator, and the only symptom is a screen missing for everyone. There is no error to read.

`IRailIdentifier` stays the authority on what a rail is; the table is its SQL-side projection,
carrying `SchemaName` (TDR-004) and the UI label for the one rail whose screen name differs from its
code — FTS is shown as UAEFTS. Two columns reference it by `Id`, and keeping them apart matters: a
page's `GateRailId` is the gate it sits *behind*, a gate row's `RailId` is the rail it *is*.
Collapsing them would make "everything behind the WPS gate" return the WPS gate itself.

No permission row holds a rail string any more, so the code exists in exactly one place. The Id is
rebuildable rather than fragile, the same way `PageId` is: §10 of the script re-resolves every rail
reference from the declared catalog in §5, which states the rail of all 63 keys by code. Re-running
the script is the repair after a master reseed.

There is no `FOREIGN KEY` — the repo removes them — so `PermissionCompiler.GetCatalogDriftAsync` is
where the reference is actually enforced. Alongside the index and rail-tag checks it reports a
declared rail missing from the master, a master rail this build does not declare, a `SchemaName`
disagreeing with `RailSchemaResolver`, a permission gated behind a rail the master does not hold,
and — read from the tables rather than the view — any `GateRailId`/`RailId` pointing at no row at
all. That last one needs its own query precisely because the view hides it: a dangling Id arrives
through the `LEFT JOIN` as a NULL rail, which is indistinguishable from a permission that is
genuinely rail-independent. The two are opposites — one is reachable by nobody, the other by
everybody — and on a *gated* row a lost reference silently **widens** access. The migration reports
the same set at apply time, and the view's `INSTEAD OF` triggers refuse a write naming a rail the
master does not hold, rather than letting it resolve to NULL.

Two things the master deliberately does not hold. **The gate permission key** is derivable —
`PermissionPage` already has one `Category = 'Rail'` row per rail carrying `RailId` — and a second
copy is a second thing to keep in step for no new answer. **Alias spellings** (`AANI`→IPI,
`IPP`→NPSS, `SWIFT`/`XBDR`/`CBFTLO`/`CBFTHI`→CBFT) stay in `RailSchemaResolver.SchemaMap`: they
match payment schemes, never permissions, and seeding them here would create a second alias registry
that could disagree with the resolver — the exact failure the master exists to remove. If SQL ever
needs them they belong in a `platform.RailAlias` child of this table, sourced from the same map.

---

## 4. Deviations from revision 1 — these are the design now

Fourteen changes. Each is a decision, not a shortcut, and each is the shape to build against.

### D-1 · Permission identity is app-scoped throughout, including fields

Revision 1 proposed a global `field:` scope (`field:iban:unmask`). As built, field keys carry the
owning app's scope like every other key: `bankingops:field.account-number:unmask`. Only rail gates
are globally scoped, because a rail is a platform concept:

```
<scope>:<resource>[.<qualifier>]:<action>        rail:<CODE>:access

bankingops:page.sif-summary:view                  rail:WPS:access
bankingops:ctrl.sif-summary.export:enable         rail:IPI:access
bankingops:field.account-number:unmask
ops:report:execute        routing:rule:write      config:tenant:write      iam:role:write
```

**Why.** A global `field:` namespace implies one masking policy per field name across every app,
which is exactly the coupling that made "who may see an account number" unanswerable. Scoping the
key to the app that owns the screen keeps the answer local. Cross-app fields are handled by *not*
rail-tagging them (§5.2), not by a shared namespace.

Scopes in use: `bankingops:` · `ops:` · `routing:` · `config:` · `iam:` · `directory:` · `rail:`.

### D-2 · The rail is a gate enforced inside `Has()`, not a dimension checked per endpoint

The single most important change. See §5.2 for the mechanism.

**Why.** Before the cascade, `POST /api/wps/UploadSIFFile` tested `wps.sif:upload` and never looked
at the rail, so a caller granted upload but denied WPS could still start a payment workflow. Any
per-endpoint scheme has that failure mode the first time someone forgets a line. Principle 5.

### D-3 · `PermissionSet.Masks` is replaced by `[Sensitive]` + a JSON `TypeInfo` modifier

Revision 1 put a `FrozenDictionary<int, FieldObligation> Masks` on the compiled set. As built, the
compiled set is a pure bitset and masking is declared on the property:

```csharp
[Sensitive("bankingops:field.account-number:unmask",
           MaskStyle.AccountNumber,
           ViewPermissionKey = "bankingops:field.account-number:view")]
public string? AccountNumber { get; init; }
```

**Why.** An obligations dictionary still needs something to *apply* it, and that something was going
to be per-handler. Declaring masking on the property makes it a property of the value, applied by a
modifier no endpoint opts into. The masking *decision* is then just an ordinary bit test on the two
field keys, so nothing is lost from the compiled set — the mask table was carrying information the
bitset already had.

Consequences: XACML's *obligation* framing is retained conceptually (a decision plus a
transformation) but not as a data structure. `FieldObligation`, `MaskMode` and the per-index mask map
do not exist.

### D-4 · Field disclosure has three levels, not two

`ViewPermissionKey` (may see it at all) and `UnmaskPermissionKey` (may see it in full) are
independent questions. A caller holding neither receives `********` — not a partial mask, because
`****1234` still discloses length and last four. Revision 1 modelled only the second question.

`MaskStyle` — `Full` · `AccountNumber` · `Iban` · `Email` · `Phone` · `Name`. Revision 1's `Omit` is
**deliberately not built**: dropping a property changes the response shape per caller and breaks
clients typed against it. Withholding the *value* is the security property. `Tokenized` and its
audited reveal endpoint are not built and are not in scope now.

### D-5 · `WritableBits` is not built; payload authority is per-operation

Revision 1 gave the compiled set a second bitset for write authority. As built, enforcement point 3
is an explicit in-handler check where the *operation* a request performs is decided by its payload
rather than its route — `CorporateRegistrationEndpoints.AuthorizeIsEditAsync` is the worked case: one
endpoint serving create and edit, admitted by `RequireAnyPermission`, then split by
`RequirePayloadPermissionAsync`.

**Why the change.** Nothing in the estate yet has a DTO whose *field-level* writability varies by
caller. Building a second bitset for a case that does not exist would have added a compile-time
concept nobody could test against real policy. The per-operation check covers what actually exists
and records its refusals.

**What this leaves open.** Over-posting is only closed for operations, not fields. §9.1 carries the
remaining work and states the trigger for building `WritableBits` after all.

### D-6 · The ABAC conditional tail is empty, and moves to the governance phase

The "under 5% conditional" budget currently reads 0%. Every genuinely record-dependent rule the
requirements name — amount ≤ limit, own branch, maker ≠ checker — is a governance rule. There is
therefore nothing for a conditional evaluator to evaluate until §10 opens.

Revision 1's open decision ("built-in expression evaluator or embedded OPA") is **deferred, not
answered**. Deciding it now would commit to a runtime dependency for a feature with no first
consumer.

### D-7 · Tenant scope is a request filter, and reads differ from writes

Revision 1 said "scope pushed into SQL `WHERE`". As built, scope enforcement resolves the tenant
*before* the handler, and TDR-004 schema isolation does the physical separation:

- `RequireTenantScope` — for an endpoint acting on **one** tenant's data. Resolves to exactly one
  canonical tenant id or refuses.
- `RequireTenantReadScope` — for a register, dashboard or report. "No tenant" legitimately means
  "every tenant" for a wildcard holder, and is `Ambiguous` for a multi-tenant caller without one.

Both return the **stored** spelling of the tenant, not the requested one, so downstream schema
resolution cannot be steered by request casing. `ScopeFilter.AllTenants = "*"` mirrors the permission
wildcard for platform-wide operators.

**Why.** `ScopeFilter.Tenants` was compiled from claims and read by nothing, while every tenant-scoped
endpoint took its tenant from the `X-Tenant-Id` header and substituted a literal `"DIB"` when absent.
A caller authenticated for one bank could read another's data by editing one header. Principle 5
again: one filter no endpoint can forget, rather than a predicate in 132 handlers.

**Still open:** the entity and branch levels of R14. `UserTenantAssignments.EntityId` exists and is
unread. §9.4.

### D-8 · L2 is a pluggable provider; the default is a memory-optimized `SCHEMA_ONLY` table

**This supersedes the first draft of this revision, which recommended keeping Redis. That
recommendation rested on two premises and both are false against the codebase:**

- *"A memory-optimized filegroup would have to be added."* It does not: the database already
  declares `FILEGROUP [PaymentHub_InMemory] CONTAINS MEMORY_OPTIMIZED_DATA` **as the DEFAULT
  filegroup**, and already carries five memory-optimized tables — `platform.TransactionHotCache`,
  `platform.ReportSnapshotHotCache`, `platform.FtsInwardDuplicateCache`,
  `platform.ParticipantDirectoryCache` (all `SCHEMA_AND_DATA`) and **`platform.RateLimitCounters`
  (`SCHEMA_ONLY`)** — several with natively compiled upsert procedures. In-Memory OLTP is an
  established pattern here, not a new dependency. `platform.RateLimitCounters` is precisely the
  shape revision 1 specified for the permission cache.
- *"Redis is already in the stack, so reuse it."* `ICacheService` has exactly **one** consumer
  outside its own definition and DI: `PermissionSetStore`. There is no reuse to preserve, and no
  other caller to disturb by changing it.

Meanwhile the Redis path as wired is worse than either option — see §9.0/F-1: with no Redis
connection string, `AddPaymentHubCaching(null)` registers `AddDistributedMemoryCache()` and *still*
registers `ICacheService → RedisCacheService`, so "L2" silently becomes a second in-process
dictionary in the same process as L1. No warning is logged. The tier appears to work and shares
nothing.

**The design.** L2 becomes an explicit, single-purpose provider abstraction with exactly one
implementation active per deployment, chosen by configuration and **announced at startup**:

```csharp
/// L2 — the cross-process tier. Exactly one provider is registered.
public interface IPermissionSetCache
{
    /// Returns null on miss AND on any failure. Never throws: L2 is an optimisation,
    /// and an L2 fault must degrade to a compile, never to a failed request (F-2).
    Task<PermissionSetDto?> TryGetAsync(string key, CancellationToken ct);

    /// Best-effort write. Never throws.
    Task SetAsync(string key, PermissionSetDto value, TimeSpan ttl, CancellationToken ct);

    /// Name and mode, for the startup log line and the health endpoint.
    string Describe();
}
```

| `Authorization:PermissionSetCache:Provider` | Implementation | When |
|---|---|---|
| `SqlInMemory` **(default)** | `platform.PermissionSetCache`, memory-optimized `SCHEMA_ONLY` | Default. No infrastructure beyond the database the compiler already reads |
| `Redis` | `RedisPermissionSetCache` over `IDistributedCache` | Estates already running Redis for other reasons |
| `None` | `NullPermissionSetCache` | Single-instance and local development. L1-only, **explicitly** |

Four rules make this "plug and play" rather than "plug and hope":

1. **Exactly one provider is registered**, resolved from configuration at startup. A missing or
   misspelled value **fails startup** rather than defaulting — an authorization cache that quietly
   picks a different tier than the operator intended is the defect this replaces.
2. **The choice is logged once at startup** (`Describe()`) and exposed on the health endpoint. The
   current silent substitution is only possible because nothing says which tier is live.
3. **No provider ever throws.** `TryGetAsync` returns null on any fault and logs; the store falls
   through to compile. This is what makes the tier genuinely optional and is the fix for F-2.
4. **`None` is a first-class choice, not a fallback.** Degrading to L1-only is legitimate for a
   single-instance deployment; doing it by accident is not.

**Why `SqlInMemory` is the default.** Three reasons, in order of weight:

- **It removes an infrastructure dependency from the packaging.** PaymentHub ships per customer
  (TDR-019). "Requires Redis" is a deployment prerequisite; "uses the database it already needs"
  is not. A customer estate that does not run Redis gets a real L2 tier rather than `None`.
- **The compiler already holds a SQL connection to that database.** L2 costs no new client, no new
  credential in Vault, no new network path, no new failure mode in the readiness probe.
- **`SCHEMA_ONLY` is exactly the right durability.** No transaction logging, no checkpoint file I/O,
  instant recovery, no contribution to failover RTO — because the content is derived and the
  compiler rebuilds it on demand. Losing the whole tier on restart costs one compile per role-set
  and no security state at all.

#### The table

```sql
CREATE TABLE platform.PermissionSetCache
(
    CacheKey    NVARCHAR(64)   NOT NULL,          -- psh:epoch
    Psh         VARCHAR(16)    NOT NULL,
    Epoch       BIGINT         NOT NULL,
    Payload     VARBINARY(900) NOT NULL,          -- serialized PermissionSetDto
    ExpiresAt   DATETIME2(3)   NOT NULL,
    WrittenAt   DATETIME2(3)   NOT NULL,

    CONSTRAINT PK_PermissionSetCache PRIMARY KEY NONCLUSTERED HASH (CacheKey)
        WITH (BUCKET_COUNT = 4096),
    INDEX IX_PermissionSetCache_Expiry NONCLUSTERED (ExpiresAt)
)
WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_ONLY);
```

Four details that are load-bearing:

- **Hash index, not range**, on `CacheKey`: every read is a point lookup on the exact key.
  `BUCKET_COUNT` should be ~1–2× the expected distinct `(role-set × tenant-set)` count rounded to a
  power of two; 4096 is generous at the current role count. Under-sizing a hash bucket count
  degrades to chained scans, and it cannot be changed without a table rebuild.
- **A range index on `ExpiresAt`** exists solely for the sweep below.
- **`VARBINARY(900)`, not `NVARCHAR(MAX)`.** Memory-optimized rows are capped at 8,060 bytes and
  LOB columns force off-row storage; the payload is a 16-byte bitset plus a short scope list, so a
  bounded binary column is both sufficient and cheaper than JSON text.
- **A natively compiled upsert** (`platform.usp_UpsertPermissionSetCache`), following the existing
  `platform.usp_UpsertTransactionHotCache` precedent.

**Expiry is our job, not SQL's.** This is the one operational cost of choosing a table over Redis
and it must not be forgotten: a memory-optimized table has **no TTL**. Rows accumulate in RAM, and
every epoch bump orphans the entire previous generation at once. So:

- The provider filters on `ExpiresAt > SYSUTCDATETIME()` on read — a row past its expiry is a miss,
  never a hit, whatever the sweep has managed to delete.
- A sweep deletes `WHERE ExpiresAt < SYSUTCDATETIME()` on an interval, and deletes
  `WHERE Epoch < @currentEpoch` on an epoch bump. Cheap: both are small sets against a small table.
- The table is **bounded by design** — one row per distinct role-set × tenant-set × live epoch, so
  hundreds of rows of a few hundred bytes. If it is ever large, the cache key is wrong (keyed by
  user, §5.1), and that is worth alerting on.

#### Durability, per table — memory-optimized is not the answer everywhere

| Table | Storage | Why |
|---|---|---|
| `platform.PermissionSetCache` | **Memory-optimized, `SCHEMA_ONLY`** | Derived; rebuilt on demand; no logging or checkpoint I/O; instant recovery |
| `platform.PolicyEpoch` | Disk-based | Must survive restart — a reset epoch makes stale L1 entries look current, which fails **open**. Read once per 30 s per process, so disk costs nothing. Memory-optimized `SCHEMA_AND_DATA` would also be correct; it buys nothing measurable and adds a startup-streaming cost |
| `Permission`, `Roles`, `RolePermissions`, `UserRoles`, `PermissionSet*` | Disk-based | **Deliberate exclusion.** `ALTER` on a memory-optimized table is an offline full-table rebuild needing roughly twice the table's memory transiently — a poor fit for a permission catalog that gains entries with every feature. They are small and read only at compile time |
| `platform.AuthorizationDecisionLog` | Disk-based | **Must not be memory-optimized.** Append-only, unbounded, retained for audit: pinning it in RAM trades an audit trail for memory pressure, and it is written in batches where disk is the right medium |

That third row is the answer to "should the tables be in-memory tables?": **the cache table yes, the
policy and audit tables no** — and for reasons specific to each, not as a blanket preference. If the
intent is to make the policy source tables memory-optimized as well, say so and it can be revisited,
but the `ALTER`-cost argument should be defeated explicitly rather than by omission.

#### The tiers, as they must be

| Tier | Where | Key | TTL | Purpose |
|---|---|---|---|---|
| **L0** | `HttpContext.Items` | — | request | Resolve once in the filter; every later check is a bare bit test |
| **L1** | `IMemoryCache` | `perm:set:{psh}:{epoch}` | **`min(5 min jittered, set.ExpiresAt)`** — see F-3 | Steady state |
| **L1′** | `IMemoryCache` | `perm:window:{username}` | 60 s, or to the next grant boundary | Per-user validity window (§5.6) |
| **L1″** | `IMemoryCache` | `perm:epoch` | 30 s | This process's view of the policy generation |
| **L2** | `IPermissionSetCache` — one of `SqlInMemory` \| `Redis` \| `None` | `perm:set:{psh}:{epoch}` | 5 min, enforced on read | Cold start, scale-out, deploys; absorbs stampede fan-in |
| **L3** | Policy tables (SQL, disk) | role-set | — | Compile only |

Single-flight is a per-key `SemaphoreSlim` — see F-4 for the race in the current implementation.

### D-9 · Invalidation adopts the epoch rather than sweeping the cache

`TryAdoptEpoch(long)` believes any strictly-newer epoch and writes it to `perm:epoch`. Because the
epoch is half of every cache key, that alone makes every entry compiled under the old one
unreachable — no key enumeration, no eviction sweep. Stale entries age out on their own TTL.
Strictly-newer-only, so a replayed or reordered message cannot walk the epoch backwards and
resurrect a revoked set.

MQTT topic is **`paymenthub/policy/epoch-changed`**, following this repo's
`paymenthub/{domain}/{event-type}` convention (TDR-005) rather than revision 1's literal
`policy.epoch.changed`.

Correctness never depends on delivery. A lost message costs staleness bounded by the 30 s epoch TTL
and the 5 min set TTL, never a wrong decision.

### D-9a · Grants are append-only, and the epoch bump is answered by a delta

*(`rbac-append-only-role-permissions-26082026.sql`, phase 5.)*

D-9 makes invalidation cheap; it did not make **re-**validation cheap. Adopting an epoch orphans
every cached entry at once, so the first request for each role-set afterwards recompiled that
role-set's entire grant list. In an estate with hundreds of distinct role-sets, one administrator
granting one permission cost hundreds of full compiles inside the seconds after the announcement.
Two changes fix that, and the first is required by the platform's append-only rule anyway.

**`platform.RolePermissions` is insert-only.** Changing an effect appends a row; revoking appends a
row with `IsRevoked = 1`. The grant in force for a `(RoleId, PermissionKey)` pair is the row with
the highest `Id`, and only when that row is not a tombstone. `UNIQUE (RoleId, Resource, Action)` is
dropped — it was what made in-place mutation the only option the schema allowed.

`Resource` and `Action` themselves are dropped too, by
`rbac-streamline-catalog-and-roles-07092026.sql`. Across every grant row in the estate `Resource`
held a verbatim copy of `PermissionKey` and `Action` held its last colon-delimited segment, so
neither carried a fact the key did not, while both were `NOT NULL` and had to be invented on every
insert. A grant is identified by its key alone.

In their place a grant carries `PermissionPageId` and `PermissionPageItemId` — soft references to
the two catalog tables, resolved once at grant time from the key. Exactly one is set per catalogued
grant; both are null on the `*` wildcard, which owns no bit and therefore no row. They exist so the
administration surface can list a role against the page and item rows without re-deriving the
key→surface split on every request, and they are business-id columns with no DB-level foreign key,
per the estate's referential-integrity rule.

| Invariant | Why it is not a detail |
|---|---|
| Ordered by `Id`, never `ChangedAt` | Identity is monotonic and needs no clock. Two versions written in the same millisecond still have an unambiguous winner |
| `ROW_NUMBER` partitions by `(RoleId, PermissionKey)`, not by key alone | A caller holding Allow on one role and Deny on another must see both rows. Collapsing per key turns deny-overrides (R8) into last-writer-wins |
| `IsRevoked` filtered **after** the ranking | Filtering first promotes the version the revocation replaced, so revoking a permission would restore the grant before it |
| Revocation is a tombstone, not a `DELETE` | A deleted row is stamped in no epoch, so it is invisible to every delta — a revocation that silently does not take |

**Every grant row carries `EpochFrom`**, the epoch it became effective at, stamped from the bump
made in the same transaction. "What changed since the generation I hold" is then exactly
`EpochFrom > cachedEpoch`. Deliberately *not* `PolicyEpoch.UpdatedAt`: that is a wall clock on the
database and the cached set's is a wall clock in the service, and a window computed across two
clocks can exclude a row that landed inside the skew — a revocation that never took effect. The
epoch is a counter and has neither problem. `ChangedAt` is still stamped, as audit metadata.

**`platform.PolicyEpochHistory` records what each epoch changed** (`PolicyChangeScope`), because a
delta is only sound when every epoch it skips is one the delta can see. An epoch bumped for a role
assignment, a hierarchy edit, an overlay or a catalog seed produces *no* grant rows, so "nothing
changed" would be true and the set would still be stale — the one fail-open outcome this design
refuses. `PermissionCompiler.TryCompileDeltaAsync` therefore takes the incremental path only when
it can account for **every** epoch in the window and all of them are `RolePermission`-scoped. An
unlogged epoch fails the check by arithmetic; an unrecognised scope fails it by exact match.

The delta re-derives each changed key from **every** source — all effective roles, overlays, and a
live wildcard — rather than applying the changed rows. Applying changed rows cannot be correct
under deny-overrides: removing a Deny on one role must restore an Allow that a different, unchanged
role still holds, and that Allow is nowhere in the delta. Recomputing per key makes the incremental
result identical to a full compile by construction, which is what keeps this an optimisation rather
than a second authorization model. A wildcard change inside the window is refused outright — it
moves every bit in the catalog.

Every refusal lands on the full compile, which is what the estate did before this existed. That
asymmetry is the design: a refusal costs one compile, a wrong acceptance serves a stale set that
looks current.

**Cost, both paths.** Steady state (L1 hit) is untouched — no database at all. After a bump, the
delta is *one* round trip, the same as a full compile, because the gate, the changed-key list and
the current state are one batched command with three result sets; the saving is in what the server
reads. Two indexes carry it: `IX_RolePermissions_Current (RoleId, PermissionKey, Id DESC) INCLUDE
(Effect, IsRevoked)` lets the latest-row filter stream as a segment/top with no Sort and no lookup,
and `IX_RolePermissions_EpochFrom` turns the delta into a seek over a range that normally holds the
single row just written. A grant that asks for the state a role is already in writes nothing and
bumps nothing, so a no-op API call no longer sends the estate off to recompile.

### D-10 · The browser learns about policy changes from a response header

Revision 1 left the session snapshot refreshed by nothing, so a granted permission reached every
server in under a second and reached the *user* at their next login. As built:

- Every request that resolves a set stamps **`X-Policy-Epoch`** on the response.
- The API client hands each one to `observePolicyEpoch(epoch, token)`.
- A newer epoch than the snapshot's triggers `revalidatePermissionSnapshot`, which refetches
  **without clearing** — keeping the current keys on screen for the round trip, because blanking
  every gated control on a working screen is worse than a briefly stale advisory copy.
- Adoption is monotonic client-side too, so a response from a process that has not heard the bump
  cannot walk the snapshot backwards.

This costs no extra request and is a genuine addition to the design, not a deviation.

### D-11 · Service principals are a first-class subject type

Absent from revision 1 entirely. Internal pipeline callers — activities recording TAT violations,
the Routing duplicate-check and transaction-save path — authenticate as service principals, hold no
roles and therefore have no compiled set.

- An endpoint must opt in with `AllowServicePrincipal()`; otherwise a verified internal caller is
  **refused** with `service-principal-not-allowed`.
- Admission is recorded in the decision log as an `Allow` with reason `service-principal`.
- Their surfaces carry their own keys — `ops:report:ingest`, `routing:transaction:ingest` — so a
  worker is never admitted by an operator's permission and an operator can never drive the
  pipeline's endpoints by holding a screen.
- `RequireTenantScope` short-circuits for them: the tenant such a request acts on comes from its
  payload, and refusing the pipeline with "no tenant assignment" would be true and useless.

### D-12 · Deny-by-default is a committed ratchet, not a build gate

Revision 1 required an endpoint with no declared permission to fail the build. On an estate with
~400 registrations that stops everything compiling — an accurate measure of the gap and a useless
gate. As built, two halves:

- **Static, in CI:** `tools/scripts/authz-coverage.ps1 -CheckBaseline` counts declarations from
  source against `tools/authz-coverage-baseline.json`. A count may fall and must never rise, so a
  new endpoint cannot be added without either a permission or a visible baseline change in the same
  commit. Approximate by construction (a permission-carrying route group counts per group), and
  deterministic — no database, Redis or container needed.
- **Exact, at startup:** `PermissionCoverage.Measure` reads endpoint metadata, so it is the number
  to trust when setting a baseline. `ReportCoverage` logs it; `EnforceCoverageBaseline` throws.

`EnforceCoverageBaseline` exists and **no service calls it yet** — every host is on `ReportCoverage`.
Flipping the five services already at zero is §9.2, and is what turns the ratchet into revision 1's
gate for those services without waiting for the estate.

### D-13 · Composition is one result set; overlays attach to roles, never users

Role hierarchy walks `ParentRoleId` in a recursive CTE with a depth cap of 8 and
`OPTION (MAXRECURSION 16)`. Direct grants and overlay items arrive in **one** result set, and the
compiler unions every allow then subtracts every deny **once, at the end**.

> **Amended 2026-11-06 — nearest role wins inside a chain.** The walk reads the *effective* parent
> (`platform.vw_RoleCurrent`: the newest `RoleTimeline.ParentRoleId`, else the as-inserted column),
> and before the union each claimed role's chain is reduced to one decision per key: the role nearest
> the claimed role holding a live row wins (a tombstone is no entry and falls through). The union and
> the subtract-denies-last step are unchanged, so deny-overrides now holds **across** a user's
> separately assigned roles and overlays, not within one chain. Why: the Screens FSD makes a sub role
> a live derivative of its base role that may override it; under deny-anywhere a child could narrow
> its template but never widen it, and the admin surface had to refuse half of the overrides the FSD
> asks for (D6, now reversed). Overlays and `'*'` are unchanged. The parent is derived by IAM from the
> base role's template and lives on the role timeline. Rules: PaymentHub-RBAC-Guidelines §12.1.

Inheritance runs **upward**: the CTE starts at the roles a user holds and walks to their ancestors,
so a child holds everything its parent holds plus its own grants. `rbac-streamline-catalog-and-roles-07092026.sql`
is the first script to populate the columns — the compiler had honoured the hierarchy since phase 5
while every role in the estate sat unparented, so the mechanism was live and unused. Every rail
Maker held the same five keys and every rail Checker the same six, differing only in the rail gate;
those move to `maker-base` / `checker-base` templates (`IsTemplate = 1`, assigned to nobody) and
the rail roles keep their gate plus what is genuinely theirs. That took the estate from 174 stored
grant rows to 66 **with byte-identical effective access** for every surviving user — verified
key-for-key against the pre-change rows, with zero permissions gained anywhere.

**Why one result set matters.** Composing source by source would let the *last source* win. Deny
must outrank allow across all of them: a `Deny` written on a parent role, or in an overlay, beats an
`Allow` written anywhere else. That is R8, and it only holds if the subtraction is last.

**Why overlays attach to a role and not a user.** A user-attached overlay is invisible to the
permission-set hash, which is computed over roles and tenants — so two users with the same roles
would share one cache entry while holding different policy. This is a cache-correctness constraint,
not a modelling preference. `PermissionSetAssignment.UserId` exists, is reserved, and is read by
nothing; leave it that way until the hash changes.

Both hierarchy and overlays are **feature-probed** (`COL_LENGTH`, `OBJECT_ID`) rather than assumed,
so a service running against a database one script behind compiles the policy it can see instead of
failing. Missing support degrades to the flat role-grant model.

### D-14 · The edge enforcement point is unbuilt, and the gateway is YARP

Revision 1 drew enforcement point 1 as Envoy. The gateway is **YARP** (TDR-002); Envoy exists only
as an undecided option in docs and Helm charts. The three hardcoded policies revision 1 flagged —
`AdminOnly` / `Operator` / `Viewer`, matched on a `role` claim — have been **removed**, not reseeded
as permission-composed roles. That resolves revision 1's open decision 5 by deletion: a role-name
claim match could override a compiled decision, which is a second authorization model.

The gateway today does authentication, routing and rate limiting. Coarse rail-level route denial at
the edge is a **latency optimisation, not a control**, and is not in scope now. What *is* in scope is
the gateway's own 21 undeclared endpoints (§9.2).

### D-15 · Validity belongs to the role assignment, and to nothing else

`ValidFrom`/`ValidTo` live on **`platform.UserRoles`** — the user's role assignment — and nowhere
else. A permission grant, an overlay item, an overlay attachment and an account carry no window.

This is a revision of an earlier D-15, which put a window at four further levels (the role's grant,
the overlay pair, the account, and a per-user-per-key table). That was built, ran for a day, and was
removed deliberately. It is recorded here rather than deleted because the reasoning is the useful
part:

- **The question it answered was already answered.** "Until when may this person do this?" is a
  statement about which roles they hold. Expressing it per permission gave one fact four homes and
  four ways to disagree, and made "is this key held right now" a question no single row could answer.
- **It cost two enforcement points, not one.** Role-scoped windows had to be filtered inside the
  compile and clamp the shared entry's lifetime; user-scoped ones had to be a mask on the returned
  copy, because principle 2 keys the cache by role-set and not by user. Every future change to
  either had to keep both halves honest.
- **It was hard to see when it worked.** A withheld bit is simply absent, which is indistinguishable
  from a permission that was never granted — so "the window fired" and "the window was ignored"
  looked the same from outside, and diagnosing one live case took three rounds.

What one level keeps: filtering the caller's claimed roles against their assignments **before** the
permission-set hash, so the cache stays keyed on the role-set actually in force; `GrantExpiresAt` on
the returned copy carrying that boundary to the browser, which refreshes at the instant rather than
waiting for an epoch bump that a per-user expiry never produces; and the entry's own lifetime
clamped to it. All of that is §5.6 and is unchanged.

**Two things learned here outlived the feature and are still in the code.** Both were bugs the
windows exposed rather than caused:

1. A `UiMode` on a grant describes **how a denial renders** — the admin screen says exactly that —
   so it must not apply to a key the caller holds. `resolveControlMode` applied it regardless, so an
   `Allow` carrying `hide` hid the control from the people it had just been granted to, and `Allow`
   and `Deny` produced identical screens.
2. That same function returned `render` for a control whose key the caller does **not** hold when no
   mode was written for it — fail-open, and inconsistent with `<Can permission>`, which had always
   resolved a mode-less denial to `hide`.

**An epoch bump is still not how a lapse is noticed.** A window opening or closing with the clock
bumps nothing; it is answered by the per-user entry's own expiry, which is clamped to the boundary.
**Authoring** one is an ordinary policy write and bumps like any other.

---

## 5. The model as built

### 5.1 The compiled set

```csharp
public sealed class PermissionSet
{
    public string           Hash      { get; }   // psh — over roles + tenants, never the user id
    public long             Epoch     { get; }   // policy generation
    public ScopeFilter      Scope     { get; }   // tenants (claims) + rails (derived from bits)
    public DateTimeOffset   ExpiresAt { get; }   // min(TTL, caller's next grant boundary)

    public bool Has(int permissionIndex);        // bit test, then the rail gate above it
    public bool Has(string permissionKey);       // unknown keys deny, never ignored
    public bool HasAny(params string[] keys);
    public ImmutableArray<string> ToKeys();      // the browser snapshot
}
```

63 permissions → `WordCount = 2` → **16 bytes of bitset**. Sized from the highest index in use, not
the entry count, so retired slots keep their positions.

Three properties from revision 1 are gone: `AllowBits` is private (the type exposes no array),
`WritableBits` (D-5), `Masks` (D-3) and `Conditionals` (D-6) do not exist. `ExpiresAt` is populated
and clamped correctly and is still **read by nothing** — expiry is enforced upstream by role
filtering (§5.6), which is the mechanism that actually closes R5.

### 5.2 The rail cascade

```csharp
public bool Has(int permissionIndex)
{
    if (permissionIndex < 0) return false;

    var word = permissionIndex >> 6;
    if (word >= _allowBits.Length ||
        (_allowBits[word] & (1UL << (permissionIndex & 63))) == 0) return false;

    var rail = PermissionCatalog.RailOf(permissionIndex);
    return rail is null || _rails.Contains(rail);      // ← the gate
}
```

A decision is therefore *two* operations: a shift-and-mask, then — for rail-tagged keys only — one
`FrozenSet<string>` lookup. Still nanoseconds.

Four rules make the cascade sound:

- **`ScopeFilter.Rails` is derived from the gate bits inside the constructor**, not trusted from the
  caller. A set whose bits and scope disagree cannot be constructed. Getting that wrong would be
  silent and total: every rail-tagged permission denies, and the only symptom is a user who cannot
  do anything on a rail they plainly hold.
- **The six rail codes mirror `IRailIdentifier`**, which is the authority on what a rail is.
  `RailCascadeTests` asserts the two agree by reflection, because the first version of the catalog
  took its rails from UI tiles instead — shipping a `uaefts` that should have been `FTS` and an
  `ipp` that is not a rail at all.
- **Aliases are gated by the rail they name, never by a gate of their own.** `RailSchemaResolver` is
  the authority: `AANI`→`ipi`, `UAEFTS`→`fts`, `IPP`→`npss`, `SWIFT`/`XBDR`→`cbft`. A label sharing a
  schema shares the dataset, so it must share the gate. A `rail:IPP:access` would sit over the same
  `npss` rows `rail:NPSS:access` already governs — deny one while holding the other and identical
  data comes back. That is a gate that does not gate.
- **Introducing a gate over existing grants takes access away by default.** Any role already holding
  a rail-tagged key needs the gate added *in the same publish* or it loses that key at the next
  epoch bump.

**Cross-rail surfaces are deliberately untagged.** The dashboard filters by rail from a query
parameter; the transaction register spans all of them; an account number appears on WPS screens and
on the corporate register. Tagging those to one rail would gate a cross-rail screen on a single
rail's gate — which reads as tighter security and behaves as a broken screen.

### 5.3 The catalog

63 entries, declared in code, seeded to `platform.PermissionPage` and
`platform.PermissionPageItem`, never free-text-editable by administrators. Admins compose roles
*from* the catalog.

**What earns a place.** Screens (one per sidebar destination), the six rail gates, and the
server-side operations behind them. A key belongs here when something on the server refuses a caller
who lacks it — an endpoint filter, a field-masking rule, an in-handler check. Component-level keys
are declared per screen by the team that owns the screen, against the standard in §5.9a; the
proof-of-concept set that used to sit here was retired in
`rbac-trim-component-permissions-04092026.sql`.

**Index stability is a compatibility contract.** A compiled set stores nothing but bit positions.
An index must never be reused for a different key, and the list must never be renumbered to close
gaps — either silently re-points every cached set at a different meaning with no error anywhere.
Indexes 2, 3, 16, 17 and 900–911 are **spent**; `PermissionCatalog.cs` carries a retirement note at
each site and new entries append from 67.

`PermissionCatalogDriftCheck` compares code against the seeded rows at startup and reports four
kinds of disagreement: declared-but-unseeded, index mismatch, declared-but-retired, and rail
mismatch. `Authorization:FailOnCatalogDrift` makes it fatal — note that this also makes the policy
database a hard startup dependency.

**Read/write are separate keys per surface, not one key per endpoint.** 132 Operations endpoints
would make the catalog unreadable and the role grants unreviewable. The distinction that matters
operationally is who may *change* something — which is why `ops:report:execute`,
`ops:report:export`, `ops:dlq:replay`, `ops:report-config:approve` and `ops:observability:manage`
are keys of their own rather than folded into a read key.

**Advisory keys.** No entry carries `IsAdvisory: true` any more, and a new one needs a strong
reason. Two used to — `bankingops:ctrl.wps-initiate.check-balance:enable` and
`bankingops:field.account-balance:unmask` — and both were **retired** rather than kept, along with
their indexes 16 and 17. Nothing server-side refused either: the WPS balance is a client-side demo
constant, so the eye toggle hid a number the page already held.

The flag stays on `PermissionDefinition` because an unenforceable key is otherwise
indistinguishable from an enforced one — in the database, in a role report, to an auditor reading
`platform.RolePermissions`. But marking one is the second-best answer. The first is not to catalog
the key until something server-side refuses it, which is what the retirement above chose. When a
real balance endpoint lands it carries a fresh key at a fresh index and masks the figure itself.

`bankingops:ctrl.sif-summary.export:enable` had also left the advisory list earlier, for the
opposite reason: ten server-side export routes now carry it, so re-enabling the button earns a 403
rather than a file. It belongs in an exfiltration review.

### 5.4 Field masking

A `JsonTypeInfo` modifier wraps the getter of every property carrying `[Sensitive]`. That is the
last point at which the platform still knows both the value and who asked for it, and it is one
place rather than one per handler.

Three levels, resolved in this order:

1. Caller holds `UnmaskPermissionKey` → the full value, **and an `Allow` is recorded** with reason
   `field-unmasked`, deduplicated per key per request. This is the audit half of R4 and it is
   deliberately on the allow: "who saw the account numbers" cannot be answered from refusals, and a
   grid of two hundred rows is one act of looking, not two hundred.
2. `ViewPermissionKey` declared and not held → `********`.
3. Otherwise → the styled mask (`****1234`).

Four rules:

- **Fail closed.** No resolved set in `HttpContext.Items` — an ungated or unauthenticated endpoint —
  masks in full. A sensitive field reachable without a gate is the case most in need of masking, not
  least.
- **Mask at the API boundary, never in the UI.** Sending unmasked PII to a browser and hiding it with
  CSS puts it in the network trace, the browser cache and any client-side logging.
- **Declared keys are validated at startup.** `FieldMasking.ValidateDeclaredKeys(assemblies)` fails
  the service when a `[Sensitive]` names a key the catalog does not declare — the same rule
  `RequirePermission` applies to endpoints, and for the same reason: an unknown key would mask a
  field for everyone, permanently and silently.
- **`DeclareSensitive<T>()` for types you do not own.** Some responses serialize *domain* types
  directly, and the domain projects reference nothing. Declaring those in the composition root keeps
  the dependency pointing the right way; it validates the key and the property name, so a renamed
  property fails startup rather than quietly stopping being masked.

**Hoist the decision out of the row loop.** The masking decision is per field-name per request (25
decisions), not per cell (2,500). Only the string transformation runs per cell.

**Not built: correlated-field groups.** Revision 1's `Group = "account-identity"` does not exist. A
UAE IBAN is `AE` + 2 check digits + 3-digit bank code + **the 16-digit account number**, so granting
sight of one while denying the other denies nothing. §9.3 carries this; it is the highest-value
remaining masking work.

### 5.5 Enforcement points

```mermaid
flowchart TD
  U[Caller] --> E["1 · YARP edge<br/>authn · routing · rate limit<br/><b>no permission check — §9.2</b>"]
  E --> EP["2 · Endpoint filter<br/>RequirePermission → bit test + rail gate<br/><b>87 registrations</b>"]
  EP --> TS["3 · Tenant scope filter<br/>requested tenant vs. assignments"]
  TS --> CV["4 · Payload authority<br/>RequirePayloadPermissionAsync per operation"]
  CV --> Q["5 · Handler + TDR-004 schema isolation<br/>canonical tenant only"]
  Q --> F["6 · Response masking<br/>[Sensitive] at serialization"]
  F --> UI["7 · UI — advisory only<br/>route · control · column"]

  style EP fill:#1f6f43,color:#fff
  style TS fill:#1f6f43,color:#fff
  style CV fill:#1f6f43,color:#fff
  style Q  fill:#1f6f43,color:#fff
  style F  fill:#1f6f43,color:#fff
  style E  fill:#6b2b2b,color:#fff
  style UI fill:#8a6d1f,color:#fff
```

Server-side enforcement is mandatory. Client-side enforcement is cosmetic. **This distinction is
the most important sentence in the document.**

Point 2 resolves the set into `HttpContext.Items` (L0) and stamps `X-Policy-Epoch`, so points 3–6
reuse it rather than resolving again. A response of 100 rows × 25 fields would otherwise re-resolve
the context 2,500 times.

`RequireAnyPermission(...)` admits a caller to an endpoint serving several separately-authorized
operations; the handler then splits by payload at point 4. Every key passed to either is validated
against the catalog **at registration**, so a typo throws at startup rather than denying silently.

Every refusal at points 2, 3 and 4 is written to the decision log **before** it is returned.
Without that a 403 leaves nothing behind but a ProblemDetails response the caller keeps and nobody
else sees.

### 5.6 Time-bounded grants (R5) — the mechanism is not the obvious one

The cache is keyed by `psh = hash(roles, tenants)`, deliberately not the user id. Validity windows
live on `platform.UserRoles` and are **per user**. Baking one caller's expiry into a role-set-shared
entry would hand it to everyone sharing that entry.

So expiry is expressed by **filtering the role list before the hash is computed**, not by rewriting
the bitset:

1. The token asserts the roles held at login; `platform.UserRoles` is the authority on which are
   still in force. The effective set is the **intersection** — fail-closed in both directions, a
   role must be both claimed and current.
2. That intersection is what `psh` is computed over, so the cache stays shared among callers with
   the same *valid* roles, and a caller whose grant lapses simply moves to a different key.
3. The window is cached per user for 60 s, or less when a boundary falls sooner — one indexed read
   per user per minute, not per request. A window that has not opened yet is as much a boundary as
   one about to close.
4. `ExpiresAt` on the returned copy is clamped to the next boundary, and `GrantExpiresAt` carries
   it whether or not it falls inside the TTL — the browser's snapshot outlives the cache many times
   over, so a boundary beyond the TTL is exactly the one it needs told about.

If the assignment store cannot be read, the caller falls back to token claims and a warning is
logged. Denying everybody because one query failed would turn a database blip into an estate-wide
outage.

### 5.7 Token and session

```jsonc
{ "sub": "...", "role": ["banking-ops:approver"], "tenant": ["ADIB"],
  "psh": "a3f2c9",   // permission-set hash
  "pe":  10427 }     // policy epoch at issue
```

Per-permission claims are gone. `TokenService` stamps `psh` using the same
`PermissionSetStore.ComputeHash` the resolver uses, so the token and the cache cannot disagree about
the key.

**Fail-closed epoch rule.** A request bearing `pe` *newer* than the epoch this process has cached
forces a fresh key rather than serving a stale set — Zanzibar's zookie applied to our epoch.

`GET /api/iam/effective-permissions` carries **no permission key**, deliberately: requiring a
permission to read your own permissions is circular. It does carry the estate's only mid-session
account check — a token stays valid for its lifetime, so this is the one place a deactivated user is
turned away before their session ends.

### 5.8 The snapshot *is* the compiled set

`/effective-permissions` resolves through `IPermissionSetStore` and returns
`{ psh, epoch, permissions: set.ToKeys(), scope: { tenants, rails } }`.

It used to rebuild the answer by hand — union the allows, subtract the denies, expand the wildcard,
re-apply the rail cascade — and it mirrored the compiler faithfully in all of those and *still*
disagreed with it, because it never applied the one thing the compiler does that a grant table
cannot express: the assignment validity window. A user whose grant had lapsed was handed keys every
endpoint then refused.

This is principle 6, and it is the reason to resist a "read-only view of policy" that assembles its
own answer. Explain and simulate (§10) obey the same rule: they explain the verdict, they do not
compute it.

### 5.9 Frontend

```tsx
const { can, canAny, isResolved } = usePermissions();   // one Set<string>, O(1)

<Can permission={CONTROL_PERM.sifSummaryExport} mode="disable">
  <Button onClick={exportCsv}>Export</Button>
</Can>
```

- One snapshot per session, held in an **external store** outside React and subscribed through
  `useSyncExternalStore`. It has to be: it is written from a Zustand action and from module scope on
  rehydrate, neither of which can set React state. Before it was subscribable, a gated control
  rendered once against an empty snapshot and never re-rendered when the fetch landed.
- **`isResolved` is not `can(...) === false`.** While the snapshot is loading every key reads as
  denied, and acting on that redirects a permitted user away from their own landing page. A route
  guard must wait, not deny.
- **Status is fail-closed but not fail-silent.** A failed fetch leaves the snapshot empty; gated
  controls stay hidden and the server refuses the matching calls anyway.
- **`PermissionRoute` replaced `ScopeGuard`.** `ScopeGuard` did two jobs: a per-route check and a
  role-string scope check carrying an `Admin` bypass and a shim matching any role name ending in
  `Maker` or `Checker`. That second job was a whole second authorization model in the same router,
  so "what gates this screen?" depended on which wrapper the screen happened to get — and the
  `Admin` bypass meant a role *name* could override a compiled decision.
- **`UNGATED.NO_BACKEND`** marks a placeholder screen explicitly rather than leaving it
  accidentally open. An authenticated user from another app reaching one reaches an empty screen.
- **`permissionKeys.ts` is each app's key manifest.** banking-ops splits into `PERM` (screens, rails
  and the operations behind them) and `CONTROL_PERM` (the three server-enforced SIF controls); ITPS
  exports `PERM` alone, holding the four `iam:*` keys the Access Control screen names. The
  `ADVISORY_PERM` group is gone with the two advisory keys it held — see §5.3.
  `PermissionKeyManifestTests` reads **both** files and asserts every key exists in the catalog, that
  none is advisory, that no catalog key is written as a literal elsewhere under `src`, that the two
  apps do not both claim the same key, and that a third app with a manifest cannot appear without
  being added to the fixture. Without it a rename on one side alone hides the control from everyone,
  because `<Can permission=…>` fails **closed** for an unknown key.
- **`rails.ts` is the only place a rail maps to its permission key.** Five call sites needed the
  mapping and the first two disagreed about whether the code was `FTS` or `UAEFTS`. It carries the
  same alias table as `RailSchemaResolver`; `SWIFT` and `XBDR` resolve to null and stay ungated
  until someone owns that decision.
- **`mode="disable"`** renders the control visibly disabled — the user learns the capability exists
  and can request it. `mode="hide"` removes it, for capabilities that should not be advertised.

**Not built:** the UI control manifest revision 1 wanted — a per-page static registry of control ids
yielding a build-time completeness check *and* the catalog an admin UI renders. `permissionKeys.ts`
is the closest thing and is a flat list. §9.5.

### 5.9a Gating a screen — the standard

The catalog holds **screens, rails and the server-side operations behind them**, and nothing
smaller. It was trimmed back to that in `rbac-trim-component-permissions-04092026.sql`: the
proof-of-concept that proved this machinery reached down to individual components — a sandbox screen
with one control of every widget kind, two corporate-grid control keys, two advisory keys — and all
of it is gone. The machinery is not: `Can`, `PageScope`, the gated primitives, `useGatedItems`,
`platform.UiRenderMode` and the whole render-mode resolution path are untouched and are what the
per-screen work builds on.

Component-level keys are therefore **each screen team's to declare**, not something shipped
centrally. Half-populating them centrally is worse than shipping none, because a key in
`platform.RolePermissions` that no screen names and no endpoint enforces still reads as a real
control to an auditor. That is precisely what went wrong during the proof of concept: three keys
typed straight into the tables, never declared in `PermissionCatalog`, ended up with live `Deny`
rows that hid the corporate registration screen's Account & Address block and masked Trade License
No for every non-admin role — with nothing in the codebase that could explain why.

**Reach for the coarsest gate that is honest.** In order of preference:

1. **The page key.** A sidebar destination gets one `Page` entry and the route guard tests it. This
   covers most of what a screen needs, and it is the only gate the sidebar itself may use — gating a
   menu link on anything the route guard does not test puts a link in the menu that the guard then
   refuses, which reads to a user as a bug rather than a permission.
2. **The action key the endpoint already enforces.** A button whose endpoint requires
   `bankingops:corporate:create` names that key. No new catalog entry, and the two cannot drift.
   `CorporateListPage` is the worked example: its New Registration button and View / Edit row action
   name `:create` and `:edit` rather than control keys of their own.
3. **A control key of its own** — only when the control is separately authorized server-side and no
   existing key expresses it. The three surviving `ctrl.sif-summary.*` keys qualify: the export,
   360-view and audit-trail routes in Operations carry them.

**Declaring a control key** costs four things, and skipping any of them fails **open**:

```csharp
new(67, "bankingops:ctrl.my-screen.approve:enable", PermissionCategory.Control,
    Page: "my-screen", Component: "approveBtn", ComponentType: UiComponentTypes.Button),
```

1. `Component` must match the `code` prop in the JSX **exactly**. Nothing checks this — a rename on
   one side leaves the control ungated, which is the one direction principle 7 forbids.
2. Something server-side must enforce the key. A key the browser can re-enable with no consequence
   is not a control; see §5.3 on advisory keys and why both were retired rather than marked.
3. Seed the row into `platform.PermissionPageItem`, or no administrator can grant it.
4. Add it to `permissionKeys.ts`, and change both halves in the same commit.

**Never reuse an index.** 2, 3, 16, 17 and the whole 900–911 block are spent. A compiled
`PermissionSet` stores bit positions only, so reusing one silently re-points every cached set at a
different meaning with nothing raised anywhere. Append from 67.

**Rail-tag with care, and never a cross-rail screen.** A rail-tagged key is ignored unless the caller
also holds `rail:<CODE>:access`, so tagging a cross-rail screen to one rail reads like tighter
security and behaves like a broken screen. The corollary bites in the other direction too: granting
a rail-tagged page without its gate produces a role that looks configured and does nothing — the
trim script's validation section checks exactly this, and caught two roles holding the NPSS-tagged
IPP report with no NPSS gate.

### 5.10 Decision log (R18)

`platform.AuthorizationDecisionLog`, append-only, batched: a bounded channel (10,000), flushed every
second in batches of up to 500, dropping on overflow rather than blocking the request path and
saying so with a running count. That is a deliberate trade — availability of the enforcement path
over completeness of its record — and the reason the capacity is generous: at 10,000 queued
decisions something is already very wrong.

Recorded: every denial (`permission-missing`, `unauthenticated`, `tenant-*`,
`payload-operation-missing`, `service-principal-not-allowed`, `rail-not-held`), plus two kinds of
allow — `service-principal` and `field-unmasked`. Ordinary allows are deliberately **not** recorded:
at request volume they would bury the refusals, and this is a decision record, not a request log.

Three read patterns, three indexes: by time window, by subject, and "show me the cross-tenant
attempts" — the third a small slice of a large table, so a filtered index on
`ReasonCode = 'tenant-not-entitled'` rather than a scan.

---

## 6. Performance — revised with real shapes

| Approach | Decisions on one page | Per decision | Total |
|---|---|---|---|
| DB query per decision | ~2,566 | ~1 ms | ~2.5 s |
| Cached rules, interpreted | ~2,566 | ~1–10 µs | ~3–26 ms |
| **As built: bit test + rail lookup, context resolved once** | ~2,566 | **~2–10 ns** | **~5–25 µs** |

*(Order-of-magnitude analysis from component costs, not measured on PaymentHub. The relative
ordering is the load-bearing claim and is robust to being wrong by an order of magnitude either
way.)*

Memory, with real numbers rather than revision 1's estimate:

```
63 permissions   →  2 × 64-bit words   =  16 bytes of bitset
+ FrozenSet<string> rails, scope, header, hash  →  ~1–2 KB per entry (object overhead dominates)
× distinct (role-set × tenant-set) at the current epoch
```

At the estate's current role count this is **kilobytes**, not megabytes, per service process. The
cache is not merely viable — it is free, which is why it is replicated into every service rather
than centralised behind a network call.

### Where the real bottlenecks are

| Risk | State |
|---|---|
| Unindexed scope predicates | Live risk. A data-modelling problem, not an authz one |
| Post-filtering in application memory | Forbidden. Push predicates into SQL; in-memory filtering also breaks paging counts |
| Chatty per-control UI calls | Structurally impossible now — one snapshot per session |
| JWT bloat | **Fixed** (D-9 / §5.7) |
| Compile stampede after an epoch bump | **Partly fixed** — per-key single-flight + jittered TTL, but the lock is racy (F-4) and L2 fan-in absorption depends on there being a real L2 tier (F-1) |
| Conditional (ABAC) rules per row | Not applicable — the tail is empty (D-6) |
| Cold start after deploy | **Open.** Nothing warms L1 from L2 asynchronously on startup. Low priority: the first request per role-set pays one Redis read |

---

## 7. Requirements traceability

### Functional

| # | Requirement | State | Where |
|---|---|---|---|
| R1 | Enforce on rails | **Built** | Rail cascade in `Has()` (§5.2) |
| R2 | Enforce on pages | **Built** | 11 Page keys · `PermissionRoute` |
| R3 | Enforce on controls | **Built** | 6 Control keys · `<Can>` |
| R4 | Field visibility / masking | **Built**, minus correlated groups | `[Sensitive]` (§5.4), §9.3 |
| R5 | Time-bounded role grants | **Built** | Role filtering before the hash (§5.6) |
| R5a | Time-bounded grants per permission | **Withdrawn** | Built, then removed — validity is a property of the role assignment (D-15) |
| R6 | Payload validation | **Partial** | Per-operation authority built; field-level write authority not (D-5, §9.1) |
| R7 | Default RBAC per role, extensible | **Built** | Templates + `ParentRoleId` + overlays (D-13) |

### Derived

| # | Requirement | State |
|---|---|---|
| R8 | Deny beats allow | **Built** — one result set, denies subtracted last |
| R9 | Role hierarchy | **Built** — recursive CTE, depth 8, feature-probed |
| R10 | Permission-set overlays | **Built** — role-attached only |
| R11 | Session role activation | **Not built.** No demand. Deferred with §10 |
| R12 | Separation of Duty | **Not built** → §10 |
| R13 | Limit / threshold authorization | **Not built** → §10 |
| R14 | Scope hierarchy | **Partial** — tenant + rail built; entity/branch not (§9.4) |
| R15 | Just-in-time elevation | **Not built** → §10 |
| R16 | Delegation | **Not built** → §10 |
| R17 | Access recertification | **Not built** → §10 |
| R18 | Decision audit log | **Built** (§5.10) |
| R19 | Simulation and explain | **Partial** — endpoints built behind `iam:policy:simulate`; no admin UI |
| R20 | Versioned policy, rollback, lockdown | **Not built.** The epoch is a generation counter, not a version history |

---

## 8. Invariants — break these and the failure is silent

Every one of these was learned by nearly getting it wrong. None is enforced by the compiler alone.

1. **Catalog indexes are never reused or renumbered.** Retire with `IsRetired = 1`; leave the slot
   empty; always append.
2. **Role names are immutable.** `RoleName` is the join key the whole stack resolves on:
   `platform.RolePermissions` is reached through it, `psh` is computed over it, tokens carry it as a
   claim. A rename silently detaches every grant and invalidates every unexpired token naming it,
   with no error anywhere. `CreateRoleRequest` has no rename field and any future
   `PUT /api/roles/{id}` must keep it that way. A genuine rename is: create, re-grant, reassign,
   retire.
3. **Every policy write bumps the epoch inside the same transaction, and announces only after
   commit.** Bumping outside it is not equivalent: a rollback after a bump discards every cache for
   nothing, and a bump that fails after a commit leaves the change live and invisible.
4. **Epoch adoption is monotonic**, server-side and client-side.
5. **Rails on a `PermissionSet` are derived from its bits**, never supplied.
6. **Overlays attach to roles, not users**, until `psh` covers user-level policy.
   `PermissionSetAssignment.UserId` exists, is reserved, and is read by nothing.
7. **Unknown permission keys deny.** Never ignore, never allow.
8. **Every permission key named in code is validated against the catalog at registration or
   startup** — endpoints, `[Sensitive]` properties, `DeclareSensitive` calls, the frontend manifest.
9. **Introducing a rail gate over existing grants removes access.** Retrofit the gate in the same
   publish.
10. **A second implementation of policy resolution is a bug**, however faithful.
11. **Advisory keys stay marked.** An unenforceable key that looks enforced will be quoted as a
    control in an audit.

---

## 9. Remaining work — in scope now

Non-governance. Ordered by value over risk. Each is independently shippable.

### 9.0 Cache-tier defects — **fixed, 2026-08-25**

Found auditing `PermissionSetStore` / `CachingDependencyInjection` line by line, rather than reading
them as architecture. F-1 and F-2 were availability defects in the authorization path.

All seven are addressed in code. New: `PermissionSetCache.cs` (`IPermissionSetCache`,
`NullPermissionSetCache`, `RedisPermissionSetCache`, `PermissionSetCacheAnnouncer`),
`SqlPermissionSetCache.cs` (provider + `PermissionSetCacheSweeper`),
`db-script/rbac-permission-set-cache-l2-25082026.sql`, and
`tests/PaymentHub.SecurityTests/PermissionSetCacheTests.cs` (14 cases). Changed:
`PermissionSetStore`, `PermissionCompiler`, `AuthorizationDependencyInjection`,
`UserAuthorizationSetup`, `IamModule`. Full solution builds clean; SecurityTests 170/170.

**F-1 · L2 is silently not a tier when Redis is unconfigured.** *(Fixed — D-8 provider model.)* `AddPaymentHubCaching(null)`
registers `AddDistributedMemoryCache()` — an **in-process** `IDistributedCache` — and still binds
`ICacheService → RedisCacheService`. Consequences: two copies of every compiled set in the same
process with different TTLs; no cross-instance sharing whatsoever; and no signal that any of this is
happening, because the L2 write "succeeds". `UserAuthorizationSetup` documents this path as
degrading "to a warning and a per-process compile" — it logs no warning and does not degrade to a
compile. Fixed by D-8: one named provider, chosen explicitly, logged at startup, with `None` as a
first-class choice.

**F-2 · An L2 fault becomes a 500 on every gated endpoint.** *(Fixed — `IPermissionSetCache` never throws; the store no longer guesses provider exception types.)* `TryReadDistributedAsync` and the L2
write catch only `InvalidOperationException`. StackExchange.Redis throws `RedisConnectionException`
(← `Exception`) and `RedisTimeoutException` (← `TimeoutException`); a payload that no longer
deserializes throws `JsonException`. None is caught, so the exception propagates out of
`IPermissionSetStore.GetAsync`, out of the endpoint filter, and every permission-gated request in
the estate returns 500 for as long as the cache is unhealthy. **A cache outage must never be an
authorization outage.** Fixed by the `IPermissionSetCache` contract in D-8: never throw, return null,
log, fall through to compile.

**F-3 · The staleness bound is 2× the intended TTL.** *(Fixed — `PermissionSetStore.L1Lifetime` clamps to `set.ExpiresAt`.)* A set read from L2 at age 4:59 is written to
L1 with a *fresh* `JitteredTtl()`, so worst-case staleness is ~10 minutes, not the 5 the design
claims — and the whole point of the TTL is to bound how long a missed MQTT message can hide a policy
change. `PermissionSetDto.ExpiresAt` already carries the true expiry and is currently used for
nothing here. Set the L1 entry to `min(jittered TTL, set.ExpiresAt − now)`.

**F-4 · Single-flight is racy under exactly the condition it exists for.** *(Fixed — 64 striped `SemaphoreSlim` gates, allocated once, never removed.)* `CompileLocks.TryRemove`
runs in the `finally` while other threads may still be queued on that semaphore instance: thread B
waits on instance X, thread A removes X from the dictionary and releases it, thread C `GetOrAdd`s a
*new* instance Y — and B and C both compile. It degrades to duplicate compiles precisely during an
epoch-bump stampede. Either keep the semaphore for the process lifetime (bounded by distinct
role-sets, which is small) or reference-count removal. §6's "stampede: fixed" row is optimistic
until this is closed.

**F-5 · A newer token epoch re-hits SQL on every request.** *(Fixed — the adopted epoch is written to `perm:epoch`.)* When `pe > storedEpoch`,
`ResolveEpochAsync` removes `perm:epoch` and returns the token's epoch **without caching it** — so
every subsequent request repeats `SELECT TOP 1 Epoch FROM platform.PolicyEpoch` until something else
repopulates the key. During a rollout, where every fresh token carries the new epoch, that is one
synchronous SQL round trip per request on the hot path. Cache the adopted value with `EpochTtl`, the
same way `TryAdoptEpoch` does.

**F-6 · L3 pays two schema probes per compile.** *(Fixed — memoized for the process lifetime.)* `HasRoleHierarchySql` and `HasOverlaysSql` run on
every `CompileAsync`. The schema does not change under a running process; probe once and memoize for
the process lifetime.

**F-7 · An empty grant-window empties the role set.** *(Addressed, deliberately without changing the outcome — see below.)* `GetUserGrantWindowAsync` returns a non-null
window with an empty `ValidRoles` when the user has **no rows at all** in `platform.UserRoles` —
indistinguishable, downstream, from "assignments exist and none is currently valid". The
intersection then drops every claimed role and the caller compiles to an all-zero bitset.

**Resolved as: keep denying, but stop being silent.** `UserGrantWindow` now carries `AccountFound`,
sourced from a `LEFT JOIN` so the account row returns even with no assignments, and the store logs a
distinct warning for the unknown-account case. The outcome is unchanged **on purpose**: falling back
to the token's own role claims for an identity the policy database has never heard of would be the
one fail-open path in the whole design, and a token asserting roles is exactly what a stolen or
forged-but-valid token presents. Revocation in this estate also works by *deleting* the
`platform.UserRoles` row (`DELETE /api/iam/users/{username}/roles/{roleName}`), so "no rows" is a
legitimate way to say "holds nothing" — treating it as "unknown, trust the token" would make
revocation ineffective until token expiry.

What the flag buys is diagnosability: the two causes were previously indistinguishable downstream,
and the unknown-account case is the shape a federated identity never mirrored into
`platform.Users` would take. The federation companion document owns that other half.

### 9.1 Payload write authority beyond operations (R6)
Point 4 authorizes the *operation*; nothing rejects a field the caller may see but not change. Build
the narrow version first: on the DTOs that already have caller-varying operations, reject any field
present in the payload that the caller's operation does not permit, rather than silently ignoring it
— which also surfaces integration bugs early. Build `WritableBits` only when a DTO appears whose
field-level writability genuinely varies by role; state that trigger in the PR rather than
pre-building for it (D-5).

### 9.2 Close the coverage gap
Three distinct pieces of work, not one:
- **Gateway (21 undeclared).** The gateway's own endpoints — not proxied routes — need keys. This is
  the largest single user-facing hole.
- **Flip the five services at zero to `EnforceCoverageBaseline(0)`.** That turns the ratchet into
  revision 1's deny-by-default gate for Operations, Routing, Configuration, WpsBusiness and
  ParticipantDirectory without waiting for the estate.
- **Internal services (~100).** WorkflowEngine, MessageProcessing, SmartIntegration, AI,
  Projection.Ingest. These are the service-principal surface (D-11): the right answer is an ingest
  key per pipeline surface plus `AllowServicePrincipal`, not an operator permission. Simulator is a
  tool and should be excluded from the baseline by kind, explicitly.

### 9.3 Correlated-field masking groups (R4)
Add a `Group` to `[Sensitive]` such that unmasking any member requires the group's permission, so an
IBAN and an account number cannot be separated. **Model the secret, not the column.** A design
review should ask, for every masked field, *"what other field in this response reconstructs it?"*
The same trap applies to full name vs. initials, card PAN vs. last-4 plus BIN, Emirates ID vs. its
scanned document.

### 9.4 Entity and branch scope (R14)
`UserTenantAssignments.EntityId` exists and is unread. Extend `ScopeFilter` and the tenant filters
down the hierarchy tenant → entity → branch, with inheritance, and push the predicates into SQL with
covering indexes. Do this before any governance rule needs "own branch", because that rule reads
this scope.

### 9.5 The UI control manifest and the admin PAP
`/explain` and `/simulate` exist as endpoints with no surface. The admin UI cannot yet render "here
is every control on this page and its current state for this role", because no per-page control
registry exists to enumerate. Build the registry first — it yields a build-time completeness check
*and* the catalog the admin screen renders — then the PAP on top of it. Admins pick from discovered
controls; they never type identifiers.

**Half of this landed with the catalog split (§3.3).** `platform.PermissionPageItem.PageId` is the
registry's storage: the admin screen's query is one seek on an 8-byte key rather than a `LIKE` over
key text. What is still missing is the *code* half — the registry is seeded from a hand-written list
in the split script, so a control added to a React page and to `PermissionCatalog` without a page
mapping lands with `PageId` NULL and nothing fails. The build-time completeness check has to come
from declaring the page on the catalog entry itself, not from the seed.

The runtime check belongs here too, not in `GetCatalogDriftAsync`. A dangling `PageId` costs a
control its place on the admin screen — an admin cannot grant what they cannot see — but it changes
no authorization decision, which is what that check is for. §11 of the migration reports it at apply
time; the PAP should report it at read time when it exists.

### 9.6 Retire the remaining advisory keys — done
Both advisory keys are gone, and their indexes (16, 17) with them. They were waiting on a real
balance endpoint that carries `check-balance` and withholds the figure from callers lacking
`unmask`; rather than keep two unenforceable keys marked indefinitely, they were retired. The
endpoint, when it lands, declares fresh keys at fresh indexes.

### 9.7 Small, known, cheap
- `PermissionSet.ExpiresAt` has no consumer. Either read it or document it as diagnostic.
- The two undeclared IAM endpoints.
- `SWIFT` / `XBDR` rail aliases resolve to null in `rails.ts` and are ungated.
- No L1 warm-from-L2 on startup (§6).
- `PermissionSetAssignment.UserId` is reserved and unread — keep it that way (invariant 6).

---

## 10. Deferred — the governance phase

**Not designed here, by decision.** Named so the next phase has a starting point, and no more.

| Requirement | Current state |
|---|---|
| R12 Separation of Duty, maker ≠ checker | No `SodConstraint` table. `ops:report-config:approve` is split from `:write` so authorship and approval are not one grant — that is the seam SoD will attach to |
| R13 Limit / threshold matrices | No `AuthorizationLimit` table |
| R15 JIT elevation, dual approval, `act` claim | No `ElevationGrant` table. The `psh` mechanism already handles the cache interaction correctly: a grant changes the hash, so the next request resolves a different key with no explicit invalidation. R5's plumbing (§5.6) is what elevation will reuse |
| R16 Delegation | Nothing |
| R17 Recertification campaigns | Nothing. The decision log (§5.10) is the evidence source |
| R11 Session role activation | Nothing |
| R20 Policy versioning, rollback, lockdown | The epoch is a monotonic counter with no history |
| ABAC conditional tail | Empty (D-6). Its first consumers are R12 and R13, so the evaluator decision belongs to this phase |
| DSL `required_permission` on manual steps | Nothing. A Temporal signal is an API call, so the signal handler must validate the caller's permission before accepting it — otherwise the approval UI is guarded and the signal endpoint is not. Authorization then versions with the payment definition, which is right for a workflow-driven hub |

Two things already built belong to governance and should be treated as *existing assets* rather than
new work when that phase opens: the append-only decision log (R18) and the explain/simulate
endpoints (R19).

---

## 11. Open decisions

### 11.1 TDR number — resolved: **TDR-021**
Revision 1 claimed TDR-019. That number is taken by *Customer-Specific Release Artifact Packaging*,
and TDR-020 by *Monorepository Versioning and Selective Container Build*. The register's own rule is
"take the next sequential number (currently TDR-021)". Every reference to TDR-019-as-RBAC in code
comments, review notes and the status doc needs correcting.

### 11.2 Still open
1. **When does the coverage ratchet become a build gate?** Recommendation: per-service, as each
   reaches zero (§9.2) — not estate-wide at a date.
2. **Edge enforcement at the gateway** — worth it as a latency optimisation, or does it just add a
   second place to forget a rule? Recommendation: no, until a measured need appears. The endpoint
   filter is the floor and it is cheap.
3. **Conditional-tail policy language** — deferred with §10, deliberately unanswered.
4. **Bucket count for `platform.PermissionSetCache`.** 4096 is a starting figure, not a measurement.
   Size it from the observed distinct `(role-set × tenant-set)` count once the PAP exists and role
   counts stop moving — a hash bucket count cannot be changed without a table rebuild.
5. **Should the policy source tables be memory-optimized too?** Recommendation: **no**, on the
   `ALTER`-cost argument in D-8. Recorded as open rather than closed because the question was put
   directly; if it is to change, that argument should be defeated on the merits.

### 11.3 Resolved by implementation
- *Does `psh` belong in the token?* **Yes** — it is what makes staleness detectable.
- *Snapshot delivery: one call or per-page slices?* **One call.** Per-page slicing reintroduces the
  chattiness the design exists to prevent.
- *Does the L2 tier stay Redis?* **No — reversed within this revision.** L2 becomes a pluggable
  provider defaulting to a memory-optimized `SCHEMA_ONLY` table (D-8): the filegroup and four
  precedent tables already exist, `ICacheService` had one consumer, and the Redis wiring was
  silently not a cross-process tier at all (F-1).
- *Do the gateway's `AdminOnly` / `Operator` / `Viewer` policies become seeded roles?* **No — they
  were deleted.** A role-name claim match that can override a compiled decision is a second
  authorization model, not a coarse first cut.
