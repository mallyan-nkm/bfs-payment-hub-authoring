# Architecture Documentation — Index

Documents are grouped by **area**. Find the area first, then the document.

| Folder | What lives here |
|---|---|
| [overview/](overview/) | System-wide architecture: the master document, specification, conceptual view, component guide, system diagram |
| [tdrs/](tdrs/) | Technical Design Records — the decision register (one folder per TDR) |
| [governance/](governance/) | Architecture governance: usage guide, architecture-vs-development split, EDA council, policies, registers |
| [workflow-engine/](workflow-engine/) | Temporal / DSL engine: composition patterns, engine evaluation and alternatives |
| [integration/](integration/) | Integration platform and central-bank edge integration |
| [security/](security/) | Authentication, identity federation / security brokers, RBAC authorization |
| [observability/](observability/) | OpenTelemetry / SigNoz telemetry path |
| [resilience/](resilience/) | Resilience architecture, guidelines and current-state assessment |
| [data/](data/) | Data projection during workflow execution, self-service NL reporting |
| [packaging/](packaging/) | Worker-per-product packaging (component/scale diagrams) |
| [diagrams/](diagrams/) | Diagram sources (`.mmd`) and renders, grouped by subject |

API documentation (OpenAPI conventions, the per-service documents, and how they are generated and
validated) lives outside this tree at [../api/README.md](../api/README.md).

---

## overview/ — system-wide architecture

| Document | Purpose |
|---|---|
| [PaymentHub-Master-Architecture-Document.md](overview/PaymentHub-Master-Architecture-Document.md) | The consolidated architecture document (HTML mirror alongside it) |
| [PaymentHub-Architecture-Specification.md](overview/PaymentHub-Architecture-Specification.md) | Formal architecture specification |
| [PaymentHub-Conceptual-Architecture.md](overview/PaymentHub-Conceptual-Architecture.md) | Architect walkthrough of the conceptual design |
| [PaymentHub-Components-Guide.md](overview/PaymentHub-Components-Guide.md) | Component-by-component guide |
| [PaymentHub-System-Architecture.svg / .png](overview/PaymentHub-System-Architecture.svg) | System architecture diagram |

## tdrs/ — technical design records

The single decision register. Start at [tdrs/README.md](tdrs/README.md). Each record is a folder with
`index.md` + `concept-tdr.md` + `design-tdr.md` + `evaluation-tdr.md`. **Left unchanged by this
reorganization** — the wiki sync (`tools/wiki/sync-wiki-gateway.py`) mirrors these paths.

## governance/ — how architecture decisions are made and tracked

| Item | Purpose |
|---|---|
| [PaymentHub-Architecture-Governance-Usage-Guide.md](governance/PaymentHub-Architecture-Governance-Usage-Guide.md) | How to use the governance artifacts |
| [Architecture-vs-Development-Responsibility.md](governance/Architecture-vs-Development-Responsibility.md) | Split of responsibility between architecture and development |
| [council/](governance/council/) | EDA council charter, process standards, review records, review tracker |
| [policies/](governance/policies/) | POLICY-001/002 — versioning, patterns & practices, supply chain, ADR compliance log |
| [registers/](governance/registers/) | Risk register, spikes risk register, pending-tasks tracker |

## workflow-engine/ — Temporal and the DSL engine

| Document | Purpose |
|---|---|
| [Temporal-Workflow-Composition-Patterns.md](workflow-engine/Temporal-Workflow-Composition-Patterns.md) | Child workflows, parallel/fan-out, signals, saga composition patterns |
| [workflow-engine-evaluation-and-recommendation.md](workflow-engine/workflow-engine-evaluation-and-recommendation.md) | Engine selection evaluation and recommendation |
| [temporal-vs-dtfx-mssql-comparison.md](workflow-engine/temporal-vs-dtfx-mssql-comparison.md) | Temporal vs Durable Task Framework on SQL Server |
| [pluggable-workflow-engine-feasibility.md](workflow-engine/pluggable-workflow-engine-feasibility.md) | Feasibility of a per-customer engine switch (Temporal / DTFx+MSSQL / Elsa): coupling inventory, three-port adaptor design, activity impact, profile sizing |
| [../../specs/](../../specs/README.md) | Spec-driven feature artifacts (spec / plan / tasks); `001-workflow-engine-seam-and-dtfx` executes the pluggable-engine feasibility |
| [pugh-matrix-workflow-engines-v3.xlsx](workflow-engine/pugh-matrix-workflow-engines-v3.xlsx) | Scoring matrix behind the evaluation |

## integration/ — integration platform and bank/CB edges

| Item | Purpose |
|---|---|
| [PaymentHub-Integration-Platform-Guide.md](integration/PaymentHub-Integration-Platform-Guide.md) | Integration platform (adaptors, Smart Integration) guide |
| [cb-edge/](integration/cb-edge/) | Central-bank edge flows: IPI/NPSS online, WPS file |

## security/ — identity and access

| Document | Purpose |
|---|---|
| [authentication-architecture-overview.md](security/authentication-architecture-overview.md) | Authentication architecture overview |
| [identity-federation-security-broker-design.md](security/identity-federation-security-broker-design.md) | Identity federation / security broker design (see TDR-020) |
| [rbac-authorization-design.md](security/rbac-authorization-design.md) | RBAC authorization design (see TDR-019) |

## observability/ — telemetry

[observability-telemetry-path.md](observability/observability-telemetry-path.md) — end-to-end OTel →
collector → SigNoz path (HTML mirror alongside).

## resilience/ — failure handling

| Document | Purpose |
|---|---|
| [PaymentHub-Resilience-Architecture.md](resilience/PaymentHub-Resilience-Architecture.md) | Resilience architecture overview |
| [PaymentHub-Resilience-Guidelines-and-Policies.md](resilience/PaymentHub-Resilience-Guidelines-and-Policies.md) | The failure-handling standard |
| [PaymentHub-Resilience-Current-State-Assessment.md](resilience/PaymentHub-Resilience-Current-State-Assessment.md) | Gaps against the standard |

## data/ — data flow and reporting

| Document | Purpose |
|---|---|
| [data-projection-during-workflow-execution.md](data/data-projection-during-workflow-execution.md) | CQRS append-only projection during workflow execution |
| [self-service-nl-reporting.md](data/self-service-nl-reporting.md) | Natural-language self-service reporting |

## packaging/ — worker-per-product packaging

[component-diagram.md](packaging/component-diagram.md) plus its [diagrams/](packaging/diagrams/)
(component packaging, surge scale-up).

## diagrams/ — diagram sources and renders

| Group | Contents |
|---|---|
| [workflow-execution/](diagrams/workflow-execution/) | DSL workflow execution flow, workflow invocation & bottlenecks, WPS outward Temporal execution |
| [integration-config/](diagrams/integration-config/) | Integration-config backend design, data model, cache tiers, message pipeline, approval and screen flows |
| [smart-integration/](diagrams/smart-integration/) | Smart Integration interface flows: inbound channel, outbound adaptor, async status pattern |
| [service-flow/](diagrams/service-flow/) | Request flow, service flow, service-flow poster, component map |

Each group keeps the `.md` write-up next to its `.mmd` source and `.png`/`.jpg` renders, so relative
image links inside the documents stay valid.

---

### Conventions

- **Diagram sources are `.mmd` (Mermaid);** `.png`/`.jpg` are generated renders — edit the `.mmd`,
  not the image.
- **`.html` / `.docx` / `.pdf` files are export mirrors** of the `.md` next to them. The `.md` is the
  source of truth.
- **Several folders are git-ignored** (`diagrams/`, `governance/council/`, `governance/policies/`,
  `packaging/`) — see `.gitignore`. They are local/working artifacts, not committed.
- **New documents go into the area folder they belong to**, not into this root. If no area fits,
  propose a new folder rather than dropping a file at the top level.
