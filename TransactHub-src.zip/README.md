# iPayHub — Payment Hub Platform

A multi-tenant, workflow-driven payment hub built on .NET 10, Temporal, and Docker.  
Supports IPI (Instant Payment Infrastructure), FTS (Fund Transfer System), and batch settlement workflows.   

---

## Project Structure  

| Folder | Responsibility |
|---|---|
| `db-script/` | SQL schema and seed scripts, dated by release (`ddMMyyyy`) |
| `docs/` | Developer guides, architecture docs, workflow docs |
| `docs/dev-setup-help/` | Step-by-step guides for local dev setup, URLs, credentials |
| `dsl/` | DSL workflow JSON definitions and JSON schema |
| `frontend/` | React Admin Portal |
| `infra/` | Docker Compose stack, infrastructure configs (OTEL, HAProxy, Vault, Mosquitto) |
| `infra/docker/` | All compose files + `start.ps1` / `stop.ps1` |
| `services/` | .NET 10 microservices solution root |
| `services/core/` | API Gateway, Routing, Workflow Engine, Message Processing |
| `services/platform/` | Audit, Configuration, Notification, Operations, Reporting |
| `services/financial/` | Batch Processing, Exception Handler, Settlement |
| `services/ecosystem/` | IAM, Participant Directory, Smart Integration |
| `services/shared/` | Shared libraries and domain contracts |
| `tests/` | Unit, Integration, Contract, Performance, and Chaos tests |
| `tools/scripts/` | Developer utility scripts (PowerShell + Python) |
| `docs/architecture/tdrs/` | Technical Design Records (single register, TDR-001…015) |
| `specs/` | Spec-driven feature artifacts (spec / plan / tasks per feature) — see [specs/README.md](specs/README.md) |
| `docs/architecture/` | Architecture blueprints and component guides |
| `.github/design/` | System design and sequence diagrams per service |
| `.github/requirements/` | User, system, and microservice requirements |
| `.github/quality/` | FMEA, test cases, observability log registry |
| `.github/security/` | Threat model, scan results (AI, 3P, privacy) |

---

## Developer Guides

| Guide | Description |
|---|---|
| [Getting Started](docs/dev-setup-help/project-start.md) | Full local setup walkthrough — Docker, DB, prerequisites |
| [Service URLs & Credentials](docs/dev-setup-help/service-urls.md) | Every local URL — the UIs, the edge, each service's Swagger UI, and where credentials come from |
| [DB Scripts](db-script/) | Schema and seed SQL files |
| [AI Governance](.github/AI-GOVERNANCE.md) | How the architecture guidelines reach **both** GitHub Copilot and Claude Code, and how they are enforced at edit, commit and PR time. **Run `pwsh tools/ai-assets/install-git-hooks.ps1` once per clone.** |

---

## Architecture & Design

| Document | Description |
|---|---|
| [Master Architecture Document](docs/architecture/overview/PaymentHub-Master-Architecture-Document.md) | Full system architecture |
| [Architecture Specification](docs/architecture/overview/PaymentHub-Architecture-Specification.md) | Detailed spec |
| [Components Guide](docs/architecture/overview/PaymentHub-Components-Guide.md) | Per-component breakdown |
| [Integration Platform Guide](docs/architecture/integration/PaymentHub-Integration-Platform-Guide.md) | IPI integration details |
| [API Documentation](docs/api/README.md) | OpenAPI conventions, per-service documents, generation and validation |
| [Conceptual Architecture](PaymentHub-Conceptual-Architecture.md) | Platform thinking & decisions (walkthrough) |
| [System Design](.github/design/01-system-design.md) | High-level system design |
| [Sequence Diagrams](.github/design/02-sequence-diagrams.md) | Key workflow sequences |
| [Deployment Architecture](.github/deployment/01-deployment-architecture.md) | Container topology and deployment tiers |

---

## Service Designs

| Service | Design Doc |
|---|---|
| API Gateway | [ApiGateway-DESIGN.md](.github/design/ApiGateway-DESIGN.md) |
| Workflow Engine | [WorkflowEngine-DESIGN.md](.github/design/WorkflowEngine-DESIGN.md) |
| Message Processing | [MessageProcessing-DESIGN.md](.github/design/MessageProcessing-DESIGN.md) |
| IAM | [IAM-DESIGN.md](.github/design/IAM-DESIGN.md) |
| RBAC & Authorization *(cross-cutting)* | [RBAC-DESIGN.md](.github/design/RBAC-DESIGN.md) · [tasks](.github/design/RBAC-IMPLEMENTATION-TASKS.md) |
| Routing | [Routing-DESIGN.md](.github/design/Routing-DESIGN.md) |
| Configuration | [Configuration-DESIGN.md](.github/design/Configuration-DESIGN.md) |
| Operations | [Operations-DESIGN.md](.github/design/Operations-DESIGN.md) |
| Smart Integration | [SmartIntegration-DESIGN.md](.github/design/SmartIntegration-DESIGN.md) |
| Participant Directory | [ParticipantDirectory-DESIGN.md](.github/design/ParticipantDirectory-DESIGN.md) |
| Bank Worker (ADIB), retired Nov 2026 | [Worker.Bank-DESIGN.md](.github/design/Worker.Bank-DESIGN.md) (historical: bank activities now run on Worker.Shell, TDR-018) |
| Platform Worker | [Worker.Platform-DESIGN.md](.github/design/Worker.Platform-DESIGN.md) |

---

## Technical Design Records

All TDRs live in a single register at [`docs/architecture/tdrs/`](docs/architecture/tdrs/README.md)
(TDR-001…015: foundation 001–007 & 012–013, domain/UI 008–011 & 014–015). Each TDR lives in a
per-TDR folder with a parent `index.md` plus `concept-tdr.md`, `design-tdr.md`, and
`evaluation-tdr.md` phase documents. All are currently **Implemented - Pending EDA Approval**.

| TDR | Decision |
|---|---|
| [TDR-001](docs/architecture/tdrs/TDR-001-temporal-over-elsa/index.md) | Temporal over Elsa for workflow orchestration |
| [TDR-002](docs/architecture/tdrs/TDR-002-envoy-api-gateway/index.md) | Envoy as the API gateway |
| [TDR-003](docs/architecture/tdrs/TDR-003-adaptor-interface-pattern/index.md) | Adaptor interface pattern for bank integrations |
| [TDR-004](docs/architecture/tdrs/TDR-004-multi-tenant-schema-isolation/index.md) | Multi-tenant SQL schema isolation |
| [TDR-005](docs/architecture/tdrs/TDR-005-mqtt-tiered-messaging/index.md) | MQTT tiered messaging |
| [TDR-006](docs/architecture/tdrs/TDR-006-framework-driven-product-architecture/index.md) | Framework-driven product architecture |
| [TDR-007](docs/architecture/tdrs/TDR-007-activity-architecture-scheme-bank-isolation/index.md) | Activity architecture — scheme/bank isolation |
| [TDR-008](docs/architecture/tdrs/TDR-008-otel-two-collector-topology/index.md) | Two-collector OpenTelemetry topology |
| [TDR-009](docs/architecture/tdrs/TDR-009-integration-profile-schema/index.md) | Integration profile schema as first-class entity |
| [TDR-010](docs/architecture/tdrs/TDR-010-three-apps-separation/index.md) | Three-apps architecture (BankingOps / ServiceOps / ITPS) |
| [TDR-011](docs/architecture/tdrs/TDR-011-ui-component-library/index.md) | UI component library selection |
| [TDR-012](docs/architecture/tdrs/TDR-012-dsl-interpreter-pattern/index.md) | DSL interpreter pattern for payment workflows |
| [TDR-013](docs/architecture/tdrs/TDR-013-temporal-signals-queries/index.md) | Temporal signals & queries for workflow control |
| [TDR-014](docs/architecture/tdrs/TDR-014-ai-workflow-builder-nl-to-dsl/index.md) | AI workflow builder — natural language to DSL |
| [TDR-015](docs/architecture/tdrs/TDR-015-bank-simulator-as-code/index.md) | Bank simulator-as-code via FDIR knowledge extraction |

---

## Requirements & Quality

| Document | Description |
|---|---|
| [User Requirements](.github/requirements/01-user-requirements.md) | Business-level user requirements |
| [System Requirements](.github/requirements/02-system-requirements.md) | Functional and security requirements |
| [Microservice Requirements](.github/requirements/03-microservice-requirements.md) | Per-service requirements |
| [FMEA](.github/quality/01-fmea.md) | Failure Mode and Effects Analysis |
| [Test Cases](.github/quality/02-test-cases.md) | Test case registry |
| [Observability Log Registry](.github/quality/log.md) | All logs, traces, and metrics |

---

## Security

| Document | Description |
|---|---|
| [Threat Model](.github/security/01-threat-model.md) | STRIDE + OWASP threat model |
| [AI Scan Results](.github/security/ai-scan-results.md) | AI-driven code security scan |
| [3P Scan Results](.github/security/3p-scan-results.md) | Third-party dependency vulnerabilities |
| [Privacy Scan Results](.github/security/privacy-scan-results.md) | PII and data privacy audit |

---

## Development Standards

### Done-Done Checklist
Every PR **must** satisfy all six done-done dimensions before merge.
See [`docs/quality/done-done-checklist.md`](docs/quality/done-done-checklist.md).

The PR template ([`.github/PULL_REQUEST_TEMPLATE.md`](.github/PULL_REQUEST_TEMPLATE.md)) includes the verification checklist and is auto-populated by GitHub on every new PR.

### Gap Closure Programme
The 30-day gap-closure programme status is tracked in [`docs/quality/GAP-CLOSURE-PROGRESS.md`](docs/quality/GAP-CLOSURE-PROGRESS.md).

