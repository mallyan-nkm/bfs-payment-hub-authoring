# CBX Salary Files — QA Pack (v1.0)

Everything needed to test **DIB WPS salary files that arrive through the CBX channel**. Written so a tester needs no coding
knowledge, and so a developer can hand the same pack to an AI agent and have the implementation validated against it.

**Business sources:** `docs/Payment-Workflow/Bank/DIB/Rail/WPS/WF_DIB_WPS_Outward_CBX_v1.0.md` (what the bank asked for)
· `.github/design/wps/us-5001-cbx-channel-sif-upload.md` and `us-5001-cbx-flow-diagrams.md` (how it was built).

> **Developer with an AI agent?** Start at [AI-Validation-Guide.md](AI-Validation-Guide.md): safety rules, the pre-flight, a
> start prompt, and what the code and database already show before the first run.

---

## Read in this order

| # | Document | What it gives you |
|---|---|---|
| 1 | [AI-Validation-Guide.md](AI-Validation-Guide.md) | How a developer and an AI agent run this pack: hard limits, layers, modes, how to judge a result. |
| 2 | [Test-Environment.md](Test-Environment.md) | What runs where, folders, who answers for the Central Bank, the configuration the tests depend on, and the **pre-flight checklist**. |
| 3 | [Acceptance-Criteria.md](Acceptance-Criteria.md) | What the system must do, in plain words. The yardstick for every test. |
| 4 | [Validation-Rules.md](Validation-Rules.md) | Every check on a file, the configured values, the exact message, **where the reason is written**, the file that tests it, and the differences from the bank document. |
| 5 | [Verification-Recipes.md](Verification-Recipes.md) | How to **observe** every result without a screen: folders, error file, status journey, money, logs, health. Test cases name these recipes. |
| 6 | [Background-Service-Test-Cases.md](Background-Service-Test-Cases.md) | Tests of the parts that run on their own: the folder pick-up and the Central Bank reply pick-up. |
| 7 | [Service-Test-Cases.md](Service-Test-Cases.md) | Tests of the processing: checks, debit, the Central Bank file, accept / reject, money returned. |
| 8 | [API-Test-Cases.md](API-Test-Cases.md) | Tests of the upload and status-enquiry APIs, including the security refusals. |
| 9 | [Resilience-and-Operability-Test-Cases.md](Resilience-and-Operability-Test-Cases.md) | What happens when something goes wrong, and whether monitoring shows it. |
| 10 | [IB-Regression-Test-Cases.md](IB-Regression-Test-Cases.md) | Proof that the shared code still serves IB exactly as before. |
| 11 | [Traceability-Matrix.md](Traceability-Matrix.md) | **The one place** that says which test proves which requirement, scenario and bank-flow step. |
| 12 | [test-data/Test-Data-README.md](test-data/Test-Data-README.md) | The test files, how to make fresh ones, and the expected results. |
| 13 | [rounds/](rounds/) | One folder per test round: plan, results, defects, summary, evidence. Copy `rounds/_template` for a new round. |

Every test case has a **Mode**: **Auto** (an agent can run it alone), **Assisted** (needs a credential, a screen or a restart that
the developer provides) or **Developer-only** (a setting or service has to change, and the developer changes it and puts it back).

---

## The flow in one picture

```mermaid
flowchart LR
    A[CBX drops a salary file<br/>in the shared folder] --> B{Name and<br/>employer OK?}
    B -- No --> R1[File stays in the folder<br/>+ line in the error file]
    B -- Yes --> C[File moved to 'done'<br/>processing starts]
    C --> D{Content OK?}
    D -- No --> R2[Validation-Failed<br/>+ line in the error file<br/>nothing debited]
    D -- Yes --> E[Charges, balance check,<br/>corporate account debited]
    E --> F[New file built and sent<br/>to the Central Bank]
    F --> G{Central Bank reply}
    G -- ACK --> H[ACKReceived → ChannelNotified → Settled]
    G -- NAK --> I[NAKReceived → money returned<br/>→ Reversed]
```

## Words used in this pack

| Word | Meaning |
|---|---|
| **SIF** | Salary Information File — the corporate's salary file. One line per employee, one control line at the end. |
| **CBX** | The channel these files come through: a shared folder, not the internet-banking screen. |
| **MOL id** | The employer's Ministry of Labour establishment id — the first 13 digits of the file name. |
| **Control record (SCR)** | The last line of a SIF: employer, month, number of employees, total amount, debit account. |
| **Employee record (EDR / EVP)** | One line per employee (pay), and an extra line for variable pay. |
| **ACK / NAK** | The Central Bank's reply: ACK = accepted, NAK = rejected. |
| **Drop folder / done folder** | Where CBX files arrive (`in`) and where accepted files are moved (`done`). |
| **Error file** | `CBX_yyyyMMdd.txt` — one line for every rejected file that day, read by DIB operations. |
| **Transaction id** | `CBX-<n>` for a file the folder pick-up submitted; it is also the workflow id in Temporal. |
| **Recipe (R-nn)** | A way of looking at a result without a screen, in [Verification-Recipes.md](Verification-Recipes.md). |

## Where things are

The full list, with the container names, the host folders and the two ways the Central Bank is reached, is in
[Test-Environment.md](Test-Environment.md). In short:

| What | Location |
|---|---|
| Drop folder / done folder | `infra/docker/data/wps-cbx/in` / `…/done` (both must exist before the watcher starts) |
| Error file | `infra/docker/data/wps-cbx-errorlog/CBX_yyyyMMdd.txt` |
| Staging folder (API tests only) | `infra/docker/data/wps-inbound/CBX-FILES` |
| Central Bank outbox and reply folders | set by `SFTP_MODE` and `CB_SFTP_*` in `infra/docker/.env` |
| Status screen / exceptions screen | Banking Ops `http://localhost:3001` → **Reports → SIF Summary** / **Technical Exceptions** |
| Workflow / traces | Temporal UI `http://localhost:8088` / SigNoz `http://localhost:3301` |

> **Timing:** the drop folder is checked every 15 seconds, and a file is taken only when it is at least 10 seconds
> old. Allow **about 1 minute** before checking a result.

---

## Source baseline

This pack was written against these versions of its three sources. If a fingerprint no longer matches, **a source has changed:
re-read the changed parts before trusting the pack**, and update this table.

| Source | Lines | Fingerprint | Checked |
|---|---|---|---|
| `docs/Payment-Workflow/Bank/DIB/Rail/WPS/WF_DIB_WPS_Outward_CBX_v1.0.md` | 2667 | `fddcd7d6b45c` | 2026-10-14 |
| `.github/design/wps/us-5001-cbx-channel-sif-upload.md` | 1057 | `37be7ea2854c` | 2026-10-14 |
| `.github/design/wps/us-5001-cbx-flow-diagrams.md` | 305 | `1044dcd03b75` | 2026-10-14 |

Recompute with `tr -d '\r' < <file> | sha256sum | cut -c1-12` (the carriage returns are removed so a checkout setting does not matter).
